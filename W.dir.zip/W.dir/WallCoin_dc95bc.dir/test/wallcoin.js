const WallCoin = artifacts.require( "./WallCoin.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "WallCoin" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x23CF6Ba6595155b771d848Bb37132510dEDc95bC", "0xD74Eba397F02ab3aD65fFF5389be70434a776e74", "0xdA031d73fb28E12884dEa52f80058F3408d5C6de", "0x9AF3a7396110588983C918abfBe89CbADde330a8", "0x72edD2c74e04523cC06862C47C95D2E3cE062d10", "0x077542f030D3375eE5EbED9d3b9b8670A85e37DA", "0x6bA47051CA16958bF5572bb657Df176878152613", "0xA1547b8c82439CEeC49617A8395558F1c5A707C6", "0x173e2625E46eA520629087C2C9d4c04D6d3E428f", "0xe726AD1231585F4d0E173eea3b8f24f13405cca7", "0xD819E6FcD3f07B04B330657196Dc0d72Ef2c6669", "0x04a90b4d138921Cd1B24d9EeaE90DE9d6985394f", "0xab343C090c74d2642Cb32460CAB905Da92badee5", "0x5502eC934c88C96516Df603A434eb377d9Cd30b1", "0x3615A3A6D83c4f760A1B5708597dCE1833b74987", "0xad8b938114ecd3ECd8eDc32724fe06DC153113FC", "0xe81DfdCc5c02b974aec36d02447e422CB85dDeAB", "0xC370c26EECA4DF6E9d8F6a8FaB4df56868a3F374", "0x27eA2466d18A7795F9dFDf1931cBab543d980dF1", "0x9a7Fa10b539008Bc82fCd75a8b0Ee9c89a6251E2", "0xd0BAC48046D0b824674781Cd35b09aE64769f552", "0xd6D28598949cb7093b7b457AcC3EDF87709B993a", "0x7D3e929bf00709E1f05Aa563a34e70f6af6Ba407", "0x8F365479B059173B0BFE1739A529445Ab2ab180C", "0x13435BA55BDf4B85E6BB890871D284f11B5c5244", "0x7Fb9De01ddD122eEc549D19Fb4B4A9bA669fBbca", "0x5aE302D7823032E48F12cff6BD67dA6840717703", "0xcF02c814202b4F2bbFC6999c2e0cEcc83d63C0BB", "0xFcB19a31d4125Dd41f92cFcFd8d7A33229017775", "0x06aE05F6E3D83395b6fD388C5975A780cb91b769"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "standard", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Burn", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)", "Burn(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0xcc16f5dbb4873280815c1ee09dbd06736cffcc184412cf7a71a0fdb75d397ca5"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3981783 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4282337 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "WallCoin", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "standard", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "standard()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "WallCoin", function( accounts ) {

	it( "TEST: WallCoin(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3981783", timeStamp: "1499324207", hash: "0x664ad74525b4b23c1f6783b812ab76b0865f6caba128f86e1babc56db7dbe581", nonce: "4", blockHash: "0xca127ce8445bcef3e78f8dbec17b4d242d392d99f83e8efff89ea1594edbfa3d", transactionIndex: "1", from: "0xd74eba397f02ab3ad65fff5389be70434a776e74", to: 0, value: "0", gas: "1063475", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0x890c6848", contractAddress: "0x23cf6ba6595155b771d848bb37132510dedc95bc", cumulativeGasUsed: "1016027", gasUsed: "963474", confirmations: "3696889"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "WallCoin", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = WallCoin.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1499324207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = WallCoin.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "21000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"3800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3981799", timeStamp: "1499324456", hash: "0xca8ed4532b20c85a524345e76f51b9a0cf43c31199b52885ac92a59a827464e5", nonce: "5", blockHash: "0x8e1d51c72ed727befbedd5d7b99f7b254677af7b4144a836ceba6c81772eca09", transactionIndex: "5", from: "0xd74eba397f02ab3ad65fff5389be70434a776e74", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "152070", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000da031d73fb28e12884dea52f80058f3408d5c6de0000000000000000000000000000000000000000001f6ed020b26b45e6000000", contractAddress: "", cumulativeGasUsed: "142070", gasUsed: "37070", confirmations: "3696873"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "38000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "38000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1499324456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xd74eba397f02ab3ad65fff5389be70434a776e74"}, {name: "to", type: "address", value: "0xda031d73fb28e12884dea52f80058f3408d5c6de"}, {name: "value", type: "uint256", value: "38000000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "21000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3988356", timeStamp: "1499436643", hash: "0xe3aab27aa380df3c640876b60f02ab72109d781a59f362e264b1fe285dfba681", nonce: "3", blockHash: "0xdf43a36eb773eeca1a28f1e077676e1d421ccce06764324a14d6370bbd0d04c9", transactionIndex: "158", from: "0xda031d73fb28e12884dea52f80058f3408d5c6de", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "21888949886", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009af3a7396110588983c918abfbe89cbadde330a800000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "5366275", gasUsed: "52006", confirmations: "3690316"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "1000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1499436643 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xda031d73fb28e12884dea52f80058f3408d5c6de"}, {name: "to", type: "address", value: "0x9af3a7396110588983c918abfbe89cbadde330a8"}, {name: "value", type: "uint256", value: "1000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "125422491658878" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3988601", timeStamp: "1499440891", hash: "0x9b6753596e78a3bf44e549630c03accde7810dbbb623a8d5695eb0c8b3435d99", nonce: "0", blockHash: "0x19961ba4b421e84406231e7e0f3b912e91163a7428c097ed8bb571e50ffbb797", transactionIndex: "12", from: "0x9af3a7396110588983c918abfbe89cbadde330a8", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52006", gasPrice: "21888949886", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000072edd2c74e04523cc06862c47c95d2e3ce062d1000000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "383742", gasUsed: "37006", confirmations: "3690071"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "1000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1499440891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x9af3a7396110588983c918abfbe89cbadde330a8"}, {name: "to", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "value", type: "uint256", value: "1000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "583994994061278" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"3799900000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3988619", timeStamp: "1499441223", hash: "0x451cc99e813274d64eaa992f68d35fb86abc4aaec6cd9eb030d094f738623632", nonce: "10", blockHash: "0x24c7fa8292d2c62cb988ae60d310b05a6504ad65e15b9e7737de58040534a59b", transactionIndex: "27", from: "0xda031d73fb28e12884dea52f80058f3408d5c6de", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "21888949886", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009af3a7396110588983c918abfbe89cbadde330a80000000000000000000000000000000000000000001f6e99eae8bd8007600000", contractAddress: "", cumulativeGasUsed: "997085", gasUsed: "37134", confirmations: "3690053"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "37999000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "37999000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1499441223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xda031d73fb28e12884dea52f80058f3408d5c6de"}, {name: "to", type: "address", value: "0x9af3a7396110588983c918abfbe89cbadde330a8"}, {name: "value", type: "uint256", value: "37999000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "125422491658878" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"3799900000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3988814", timeStamp: "1499444434", hash: "0x6105dd790f0caa8eec39ac5b5c12d2190c05f40767409e7076c37c4e58bca731", nonce: "1", blockHash: "0x96f3ec21e648a1487099483e81ef8e65b3388a9ba67f12c64fb04f47d701f269", transactionIndex: "24", from: "0x9af3a7396110588983c918abfbe89cbadde330a8", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37134", gasPrice: "25172292369", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000072edd2c74e04523cc06862c47c95d2e3ce062d100000000000000000000000000000000000000000001f6e99eae8bd8007600000", contractAddress: "", cumulativeGasUsed: "808532", gasUsed: "22134", confirmations: "3689858"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "37999000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "37999000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1499444434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x9af3a7396110588983c918abfbe89cbadde330a8"}, {name: "to", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "value", type: "uint256", value: "37999000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "583994994061278" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"99000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4015559", timeStamp: "1499929535", hash: "0x6b1e84512aedb8c488ac2abeaa5fef160629fe87bfa4c80e4d4bdafc460641ac", nonce: "901", blockHash: "0x87ab4cd2829848f033f789d700496321f8ac6631d3ad5c73a4d7fc0525074d8a", transactionIndex: "20", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "23247420931", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000077542f030d3375ee5ebed9d3b9b8670a85e37da0000000000000000000000000000000000000000000000055de6a779bbac0000", contractAddress: "", cumulativeGasUsed: "1037805", gasUsed: "52006", confirmations: "3663113"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_value", value: "99000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "99000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1499929535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x077542f030d3375ee5ebed9d3b9b8670a85e37da"}, {name: "value", type: "uint256", value: "99000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"4950000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4015559", timeStamp: "1499929535", hash: "0x5b072573ba889465d3cd16c8f42651927328d7a0e4337437dcf72d0233f69a72", nonce: "902", blockHash: "0x87ab4cd2829848f033f789d700496321f8ac6631d3ad5c73a4d7fc0525074d8a", transactionIndex: "21", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52071", gasPrice: "23247420931", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000006ba47051ca16958bf5572bb657df176878152613000000000000000000000000000000000000000000000a7b667f19c28bf00000", contractAddress: "", cumulativeGasUsed: "1089875", gasUsed: "52070", confirmations: "3663113"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "49500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "49500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1499929535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "value", type: "uint256", value: "49500000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1980000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4015575", timeStamp: "1499929791", hash: "0x2c59db4d5a386c879e15e02d2dee0d573f5e5f22ae6ea582b4165e2e85e833bb", nonce: "903", blockHash: "0xc1389486582b1adfbc9a797ea2f50408e32d9b1724f3bb80ad4d33730c5ab5ed", transactionIndex: "70", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37071", gasPrice: "20420072280", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000006ba47051ca16958bf5572bb657df1768781526130000000000000000000000000000000000000000000029ed99fc670a2fc00000", contractAddress: "", cumulativeGasUsed: "2132859", gasUsed: "37070", confirmations: "3663097"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "198000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "198000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1499929791 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "value", type: "uint256", value: "198000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1980000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4015591", timeStamp: "1499930149", hash: "0xe22138f2c863f68328aaa7bd215ffdfd5eddd4fd7fd5f8ccbedf05519f70def9", nonce: "905", blockHash: "0x43464aa3b91bd064b886a131622b626622745af16d069808f1b9cf64ecbb93fe", transactionIndex: "5", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37071", gasPrice: "20200556502", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000006ba47051ca16958bf5572bb657df1768781526130000000000000000000000000000000000000000000029ed99fc670a2fc00000", contractAddress: "", cumulativeGasUsed: "142070", gasUsed: "37070", confirmations: "3663081"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "198000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "198000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1499930149 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "value", type: "uint256", value: "198000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4015599", timeStamp: "1499930328", hash: "0xa2f4d71ef4ae08f6b5406b0f2bdd207b8309dc4a7d0fdd8f9b74a2e9f24fa7e3", nonce: "0", blockHash: "0x4ee507756937e4d27ae418d240a09b7264c89aedc35598cb3aceca104ef99292", transactionIndex: "46", from: "0x077542f030d3375ee5ebed9d3b9b8670a85e37da", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000006ba47051ca16958bf5572bb657df1768781526130000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "4001763", gasUsed: "36942", confirmations: "3663073"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "5000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1499930328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x077542f030d3375ee5ebed9d3b9b8670a85e37da"}, {name: "to", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "value", type: "uint256", value: "5000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1541286345312500000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"2376000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4015620", timeStamp: "1499930691", hash: "0xa75a959fb157769cabb18e66163cd783b1f1080a5a3e1a76e2a8b64493f6db3e", nonce: "906", blockHash: "0xe0fff17e49c3fcbca470ae7bcba27077bfe9b4788d51fe163d972ddb1f9b617e", transactionIndex: "63", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37071", gasPrice: "20420072280", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000006ba47051ca16958bf5572bb657df1768781526130000000000000000000000000000000000000000000032505262153f6c800000", contractAddress: "", cumulativeGasUsed: "2006955", gasUsed: "37070", confirmations: "3663052"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "237600000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "237600000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1499930691 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "value", type: "uint256", value: "237600000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"6000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4048878", timeStamp: "1500561966", hash: "0x2bb92d0e0cb58f46f86af4c5affe1f44b6e74b811ed9fcd45590ce544c063ac1", nonce: "1", blockHash: "0xac02da2393f0854df27dc84f01f02c3f0b8fc9d44fb4653e910e35dc58076574", transactionIndex: "92", from: "0x6ba47051ca16958bf5572bb657df176878152613", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000a1547b8c82439ceec49617a8395558f1c5a707c6000000000000000000000000000000000000000000000cb49b44ba602d800000", contractAddress: "", cumulativeGasUsed: "3947758", gasUsed: "52070", confirmations: "3629794"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "60000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "60000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1500561966 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "to", type: "address", value: "0xa1547b8c82439ceec49617a8395558f1c5a707c6"}, {name: "value", type: "uint256", value: "60000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "247585320500000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"7500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4048919", timeStamp: "1500562794", hash: "0x19e65c5ecf7a64f0285f6abbc50de85970c5cc15bb99defa1bde87d7606d45e8", nonce: "2", blockHash: "0x411932bcea5059b3a83e93f10afc4ee916f96891de1466aae41bbb84ff76968c", transactionIndex: "3", from: "0x6ba47051ca16958bf5572bb657df176878152613", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000a1547b8c82439ceec49617a8395558f1c5a707c6000000000000000000000000000000000000000000000fe1c215e8f838e00000", contractAddress: "", cumulativeGasUsed: "498861", gasUsed: "37070", confirmations: "3629753"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "75000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "75000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1500562794 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "to", type: "address", value: "0xa1547b8c82439ceec49617a8395558f1c5a707c6"}, {name: "value", type: "uint256", value: "75000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "247585320500000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"480000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4048948", timeStamp: "1500563349", hash: "0x0818c49afd66c044f94f9b2273caedd46590428dbfa946e4fcc80d39ddc6aacb", nonce: "3", blockHash: "0x8b34c6b7f0492c93f14bc5db39446868967b4a21d3b3d75dd2c3cae2c8483222", transactionIndex: "30", from: "0x6ba47051ca16958bf5572bb657df176878152613", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000173e2625e46ea520629087c2c9d4c04d6d3e428f000000000000000000000000000000000000000000000a2a15d09519be000000", contractAddress: "", cumulativeGasUsed: "1458280", gasUsed: "52006", confirmations: "3629724"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "48000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "48000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1500563349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "to", type: "address", value: "0x173e2625e46ea520629087c2c9d4c04d6d3e428f"}, {name: "value", type: "uint256", value: "48000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "247585320500000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"620360000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4048959", timeStamp: "1500563451", hash: "0xa1d61d28ddd757a73c7f9caf9b65dea8b775f76026720bc470aa6d139061ea61", nonce: "4", blockHash: "0x4608df07cbd41d02bca513504042234726f227118062e74ac4df7c793a541761", transactionIndex: "29", from: "0x6ba47051ca16958bf5572bb657df176878152613", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000173e2625e46ea520629087c2c9d4c04d6d3e428f000000000000000000000000000000000000000000000d22fa71c72f74d00000", contractAddress: "", cumulativeGasUsed: "4924857", gasUsed: "37070", confirmations: "3629713"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "62036000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "62036000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1500563451 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "to", type: "address", value: "0x173e2625e46ea520629087c2c9d4c04d6d3e428f"}, {name: "value", type: "uint256", value: "62036000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "247585320500000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"380690000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4048975", timeStamp: "1500563718", hash: "0x81d94d136b61c7a5a2831da0e01f8528486f94f7e42a572b1c808f4bb4ed5edd", nonce: "5", blockHash: "0x68c016dbaf55e96ba7a5a9c17647beae85e5ff4bf4bb8a2d43b02210619bc0ae", transactionIndex: "33", from: "0x6ba47051ca16958bf5572bb657df176878152613", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000e726ad1231585f4d0e173eea3b8f24f13405cca700000000000000000000000000000000000000000000080fb98109cb29b40000", contractAddress: "", cumulativeGasUsed: "2046438", gasUsed: "52070", confirmations: "3629697"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "38069000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "38069000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1500563718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "to", type: "address", value: "0xe726ad1231585f4d0e173eea3b8f24f13405cca7"}, {name: "value", type: "uint256", value: "38069000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "247585320500000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"421530000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4048981", timeStamp: "1500563825", hash: "0x6bb875748193a30c82b15e1fadb211b163454dbda9e62ff748ab0bb720248b2e", nonce: "6", blockHash: "0x9be315d233d4325abca240870d230813aec0d2940049d222280e96805ca600da", transactionIndex: "30", from: "0x6ba47051ca16958bf5572bb657df176878152613", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000e726ad1231585f4d0e173eea3b8f24f13405cca70000000000000000000000000000000000000000000008ed1e63b3d591040000", contractAddress: "", cumulativeGasUsed: "1123499", gasUsed: "37070", confirmations: "3629691"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "42153000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "42153000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1500563825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x6ba47051ca16958bf5572bb657df176878152613"}, {name: "to", type: "address", value: "0xe726ad1231585f4d0e173eea3b8f24f13405cca7"}, {name: "value", type: "uint256", value: "42153000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "247585320500000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1350000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4048994", timeStamp: "1500564081", hash: "0x9695b71e8b6a4526d7cd8dd4ba0fdb14107b0192564be79e2206a8cd72284246", nonce: "0", blockHash: "0x0e3c048691613aa2866cd176b1f70631d6c89c3040b1108e24a864175924bb33", transactionIndex: "28", from: "0xa1547b8c82439ceec49617a8395558f1c5a707c6", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37070", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000072edd2c74e04523cc06862c47c95d2e3ce062d10000000000000000000000000000000000000000000001c965d5aa35866600000", contractAddress: "", cumulativeGasUsed: "1038253", gasUsed: "22070", confirmations: "3629678"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "135000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "135000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1500564081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xa1547b8c82439ceec49617a8395558f1c5a707c6"}, {name: "to", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "value", type: "uint256", value: "135000000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "300020000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"8022200000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4049054", timeStamp: "1500565236", hash: "0xe06d9463ebf8f7fd31fcad77f4c5b1662f5d2330490978f340d7e332bafd6855", nonce: "0", blockHash: "0x9382182df343798f74c7620354f50974ae16b29bb13a4874ce2557544cced161", transactionIndex: "50", from: "0xe726ad1231585f4d0e173eea3b8f24f13405cca7", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37070", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000072edd2c74e04523cc06862c47c95d2e3ce062d100000000000000000000000000000000000000000000010fcd7e4bda0bab80000", contractAddress: "", cumulativeGasUsed: "1542405", gasUsed: "22070", confirmations: "3629618"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "80222000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "80222000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1500565236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xe726ad1231585f4d0e173eea3b8f24f13405cca7"}, {name: "to", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "value", type: "uint256", value: "80222000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "300000000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1100360000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4049054", timeStamp: "1500565236", hash: "0xae94a1f9c2ae2491f096eecda6d313c46d06eefeca707e0950c23eb6c2af9779", nonce: "0", blockHash: "0x9382182df343798f74c7620354f50974ae16b29bb13a4874ce2557544cced161", transactionIndex: "55", from: "0x173e2625e46ea520629087c2c9d4c04d6d3e428f", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37070", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000072edd2c74e04523cc06862c47c95d2e3ce062d1000000000000000000000000000000000000000000000174d10425c4932d00000", contractAddress: "", cumulativeGasUsed: "1668318", gasUsed: "22070", confirmations: "3629618"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "110036000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "110036000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1500565236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x173e2625e46ea520629087c2c9d4c04d6d3e428f"}, {name: "to", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "value", type: "uint256", value: "110036000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "300000000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"497500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4239460", timeStamp: "1504577066", hash: "0x0fcfde76fa5ec37cb8a7a417b75b3dbbc425f4adf2d13cf8ac85803cf5f65bf3", nonce: "3844", blockHash: "0x6af99b181a00be3b88e374a9a734255daa719d02108dffd436223a60ca474d70", transactionIndex: "40", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "27221063327", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d819e6fcd3f07b04b330657196dc0d72ef2c666900000000000000000000000000000000000000000000010db1fe8d52005c0000", contractAddress: "", cumulativeGasUsed: "1250118", gasUsed: "52006", confirmations: "3439212"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "4975000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "4975000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1504577066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xd819e6fcd3f07b04b330657196dc0d72ef2c6669"}, {name: "value", type: "uint256", value: "4975000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"614153800000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4246620", timeStamp: "1504752118", hash: "0xd4a21b6c3c1a1ca7fe454aa42927a3412ef7d8bb202f4dc3746ed7d1a4ec12a7", nonce: "4262", blockHash: "0x9da989d236beed7bbc4cf5275142ffb21daeeb80b0c1649a0d72a7ed5eab8d57", transactionIndex: "36", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52071", gasPrice: "35500000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000004a90b4d138921cd1b24d9eeae90de9d6985394f0000000000000000000000000000000000000000000000214b189b2c784c8000", contractAddress: "", cumulativeGasUsed: "1250837", gasUsed: "52070", confirmations: "3432052"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "614153800000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "614153800000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1504752118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x04a90b4d138921cd1b24d9eeae90de9d6985394f"}, {name: "value", type: "uint256", value: "614153800000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"155220000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4246776", timeStamp: "1504755913", hash: "0x6d50a7821caf7157a4c697843c2d8850f29697d9b51f4273e6b854e2d8aa6e28", nonce: "4280", blockHash: "0xff1d0d18fd3db3e68e2fc81925f4f1c332ba639a0052032a79656943180f5649", transactionIndex: "48", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "35500000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ab343c090c74d2642cb32460cab905da92badee5000000000000000000000000000000000000000000000054251a2c1789540000", contractAddress: "", cumulativeGasUsed: "1650192", gasUsed: "52006", confirmations: "3431896"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "1552200000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[14], "1552200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1504755913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xab343c090c74d2642cb32460cab905da92badee5"}, {name: "value", type: "uint256", value: "1552200000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1552200000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4248473", timeStamp: "1504797614", hash: "0xd6c850d5693bfceee7e2e2135bd5e37bf5f32f8590cc52e116908fa84c68c18a", nonce: "0", blockHash: "0x9c530cc8ea5cbad6918c6d9ee10bd9f994a2c40622b9c84c7dd2c043bd8128db", transactionIndex: "36", from: "0xab343c090c74d2642cb32460cab905da92badee5", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37006", gasPrice: "37585215805", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000072edd2c74e04523cc06862c47c95d2e3ce062d10000000000000000000000000000000000000000000000054251a2c1789540000", contractAddress: "", cumulativeGasUsed: "1430912", gasUsed: "22006", confirmations: "3430199"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "1552200000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "1552200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1504797614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xab343c090c74d2642cb32460cab905da92badee5"}, {name: "to", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "value", type: "uint256", value: "1552200000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "563778237075000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"49750000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4257222", timeStamp: "1505009004", hash: "0x32528b8fb9ee0c9411287d3019b9977287fd2fa64c638ff80ffce0ff5d8fd08a", nonce: "4703", blockHash: "0x0cad88f00f43c05c1fb389565b88c3979022aac36ca649c31a729f4071df4ac5", transactionIndex: "19", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000005502ec934c88c96516df603a434eb377d9cd30b1000000000000000000000000000000000000000000000002b26b8169c7af0000", contractAddress: "", cumulativeGasUsed: "692818", gasUsed: "52006", confirmations: "3421450"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "49750000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "49750000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1505009004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x5502ec934c88c96516df603a434eb377d9cd30b1"}, {name: "value", type: "uint256", value: "49750000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"995000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4257728", timeStamp: "1505021107", hash: "0x82dbe00ad4bd9c45bc327c1bd95b5acc566dd55f55f7e723b90059fb8559af27", nonce: "4827", blockHash: "0xf33ccfb8ef360d5d50c3af036e47abbfd53ea9aeb13ef7bed9933796d2b32353", transactionIndex: "13", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "26765082494", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000003615a3a6d83c4f760a1b5708597dce1833b74987000000000000000000000000000000000000000000000035f0661c4399ac0000", contractAddress: "", cumulativeGasUsed: "551801", gasUsed: "52006", confirmations: "3420944"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "995000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "995000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1505021107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x3615a3a6d83c4f760a1b5708597dce1833b74987"}, {name: "value", type: "uint256", value: "995000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"278600000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4258085", timeStamp: "1505030152", hash: "0x54fcf7cf676a579bae9013c1f006273790ff1c5940995717ef012e9bba106805", nonce: "4968", blockHash: "0x767719389151b0d7de337075615106a490a915d1b1e4db57564afaf33e4bf8cb", transactionIndex: "36", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "27675578466", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ad8b938114ecd3ecd8edc32724fe06dc153113fc00000000000000000000000000000000000000000000009707844f23ae480000", contractAddress: "", cumulativeGasUsed: "1618288", gasUsed: "52006", confirmations: "3420587"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "2786000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "2786000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1505030152 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xad8b938114ecd3ecd8edc32724fe06dc153113fc"}, {name: "value", type: "uint256", value: "2786000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"199000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4258261", timeStamp: "1505034709", hash: "0xb81efde0adcb6b6736a63ab5fd6de8603663aa611c6a3c6e70b302b74d5b571d", nonce: "5000", blockHash: "0x8bb6e7d6b9075fe578e7826faefd3ab63ecbec3f92fa023e056a8c74a471fa2d", transactionIndex: "79", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37007", gasPrice: "39500000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ad8b938114ecd3ecd8edc32724fe06dc153113fc00000000000000000000000000000000000000000000006be0cc388733580000", contractAddress: "", cumulativeGasUsed: "2411139", gasUsed: "37006", confirmations: "3420411"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "1990000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "1990000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1505034709 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xad8b938114ecd3ecd8edc32724fe06dc153113fc"}, {name: "value", type: "uint256", value: "1990000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"99500000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4262400", timeStamp: "1505134825", hash: "0x167e9c2a2b4ec06b5df29d1039aaac35f8c7789adf1dcdc92ecad685763f4877", nonce: "5455", blockHash: "0x86c0ae8894876883958209cc61e4a05e31ccce95f01fe74522ae2a39cc234526", transactionIndex: "25", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000e81dfdcc5c02b974aec36d02447e422cb85ddeab00000000000000000000000000000000000000000000000564d702d38f5e0000", contractAddress: "", cumulativeGasUsed: "1250747", gasUsed: "52006", confirmations: "3416272"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "99500000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "99500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1505134825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xe81dfdcc5c02b974aec36d02447e422cb85ddeab"}, {name: "value", type: "uint256", value: "99500000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[19], \"1293500000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4275130", timeStamp: "1505441028", hash: "0x219868f6383068ef8202f7fae31a1a07886c980d0fd412035745bc73567bb26a", nonce: "5838", blockHash: "0x5510cd9b358d5fa227c46efe307b99085a2f998b7fa5437541c39231012b98be", transactionIndex: "61", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "26000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000c370c26eeca4df6e9d8f6a8fab4df56868a3f37400000000000000000000000000000000000000000000000011f36f6590f7c000", contractAddress: "", cumulativeGasUsed: "5445727", gasUsed: "52006", confirmations: "3403542"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "1293500000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[19], "1293500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1505441028 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xc370c26eeca4df6e9d8f6a8fab4df56868a3f374"}, {name: "value", type: "uint256", value: "1293500000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"387868293100000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4275749", timeStamp: "1505456418", hash: "0xefec8c0eba4b0f10a2b4f563a26c9ff6f0fe60f844635c7dd5b74adf347260ba", nonce: "5945", blockHash: "0x98cadc3d81b0e422eaf3b65a996bff683e9ec3e92a3578633de767bba3ccfd6b", transactionIndex: "34", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52071", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000027ea2466d18a7795f9dfdf1931cbab543d980df10000000000000000000000000000000000000000000000d24389e79a01f23000", contractAddress: "", cumulativeGasUsed: "2407578", gasUsed: "52070", confirmations: "3402923"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "3878682931000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "3878682931000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1505456418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x27ea2466d18a7795f9dfdf1931cbab543d980df1"}, {name: "value", type: "uint256", value: "3878682931000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[21], \"49750000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4277139", timeStamp: "1505489744", hash: "0xca0cff0febce38ae7e519983f47acde48ebba56f259a83e572178a914be23840", nonce: "6043", blockHash: "0xea108c175924110f4c958a2302c220ffca45bcd516a05ff1f046a43f28a9957b", transactionIndex: "99", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000009a7fa10b539008bc82fcd75a8b0ee9c89a6251e2000000000000000000000000000000000000000000000002b26b8169c7af0000", contractAddress: "", cumulativeGasUsed: "5617381", gasUsed: "52006", confirmations: "3401533"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "49750000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[21], "49750000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1505489744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x9a7fa10b539008bc82fcd75a8b0ee9c89a6251e2"}, {name: "value", type: "uint256", value: "49750000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"424984400000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4279436", timeStamp: "1505544561", hash: "0xed6ecc2e74d78f8a422311a2513a4b46fdc27bb37f8d73f9045d2c29332faeed", nonce: "6155", blockHash: "0xcd3323180771bd5fbf95dde6bbcb9a5617494a02851d30fa6ff869e152717aa4", transactionIndex: "20", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52071", gasPrice: "50000000001", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d0bac48046d0b824674781cd35b09ae64769f5520000000000000000000000000000000000000000000008ffd8551d9d5bf40000", contractAddress: "", cumulativeGasUsed: "1049012", gasUsed: "52070", confirmations: "3399236"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "42498440000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "42498440000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1505544561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xd0bac48046d0b824674781cd35b09ae64769f552"}, {name: "value", type: "uint256", value: "42498440000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"535230400000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4279436", timeStamp: "1505544561", hash: "0xd8d10c6dc8535768eb944c2915c9f5694a026c719424ab7bcc68c7473a4c3151", nonce: "6161", blockHash: "0xcd3323180771bd5fbf95dde6bbcb9a5617494a02851d30fa6ff869e152717aa4", transactionIndex: "54", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52071", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d0bac48046d0b824674781cd35b09ae64769f552000000000000000000000000000000000000000000000b557d6456c7cf700000", contractAddress: "", cumulativeGasUsed: "2267179", gasUsed: "37070", confirmations: "3399236"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "53523040000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "53523040000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1505544561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xd0bac48046d0b824674781cd35b09ae64769f552"}, {name: "value", type: "uint256", value: "53523040000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"175558795000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4279442", timeStamp: "1505544696", hash: "0xf491ae37c033aa70e0217d7f8e0a210b308dd36efc88077061089b6b766faa88", nonce: "6167", blockHash: "0xe3e86e6c73289fead5812178269a292262af8b81f87e7c08fe0f4f0c56bc883a", transactionIndex: "71", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52135", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d6d28598949cb7093b7b457acc3edf87709b993a00000000000000000000000000000000000000000000252d0fb46e23bfc78000", contractAddress: "", cumulativeGasUsed: "1724505", gasUsed: "52134", confirmations: "3399230"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "175558795000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "175558795000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1505544696 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xd6d28598949cb7093b7b457acc3edf87709b993a"}, {name: "value", type: "uint256", value: "175558795000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"167498300000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4279530", timeStamp: "1505546999", hash: "0x00edd71cc72c1b756e7ff633b018b3539558d07d046ed09900b8c527a362a705", nonce: "6188", blockHash: "0x983f25af1e2561944b22498b71d5f97c77f5418e4965ab0bf62f5bba9a481249", transactionIndex: "56", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37071", gasPrice: "50000000001", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d0bac48046d0b824674781cd35b09ae64769f55200000000000000000000000000000000000000000000038c02962898e5270000", contractAddress: "", cumulativeGasUsed: "1526345", gasUsed: "37070", confirmations: "3399142"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "16749830000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "16749830000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1505546999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xd0bac48046d0b824674781cd35b09ae64769f552"}, {name: "value", type: "uint256", value: "16749830000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"498425350000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4279530", timeStamp: "1505546999", hash: "0xc47a7800b60d2b046d82c377fe9e6ccf1ee3bb90f652463cf83413a07adec06f", nonce: "6191", blockHash: "0x983f25af1e2561944b22498b71d5f97c77f5418e4965ab0bf62f5bba9a481249", transactionIndex: "59", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37135", gasPrice: "50000000001", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d0bac48046d0b824674781cd35b09ae64769f552000000000000000000000000000000000000000000000a8df81fe16e865d8000", contractAddress: "", cumulativeGasUsed: "1667427", gasUsed: "37134", confirmations: "3399142"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "49842535000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "49842535000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1505546999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xd0bac48046d0b824674781cd35b09ae64769f552"}, {name: "value", type: "uint256", value: "49842535000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"175558000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4279573", timeStamp: "1505548034", hash: "0x9d03a070b77409d6d090d16e02bc217477e933a5802c38a17bdf2b4ad8038f2c", nonce: "0", blockHash: "0x0fb74f21587f126a2f50262511e913602d2ceb269310110582ba6d3dcbb83e29", transactionIndex: "60", from: "0xd6d28598949cb7093b7b457acc3edf87709b993a", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "60000", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d0bac48046d0b824674781cd35b09ae64769f55200000000000000000000000000000000000000000000252d04ac05da0b580000", contractAddress: "", cumulativeGasUsed: "1887554", gasUsed: "37070", confirmations: "3399099"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "175558000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "175558000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1505548034 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xd6d28598949cb7093b7b457acc3edf87709b993a"}, {name: "to", type: "address", value: "0xd0bac48046d0b824674781cd35b09ae64769f552"}, {name: "value", type: "uint256", value: "175558000000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "396500000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"246292786810000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4279821", timeStamp: "1505554170", hash: "0x01fd6b55b9f9f2cc078fdc71bf959d00e2973c67ed733681f47977674ecaf4d1", nonce: "6230", blockHash: "0x1d784c8583301a659175233d0d452072ae3015f1dc21c7fa2d928543252ad1b3", transactionIndex: "4", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52135", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000007d3e929bf00709e1f05aa563a34e70f6af6ba40700000000000000000000000000000000000000000000053727e744dbc25a9000", contractAddress: "", cumulativeGasUsed: "165644", gasUsed: "52134", confirmations: "3398851"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "24629278681000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "24629278681000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1505554170 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x7d3e929bf00709e1f05aa563a34e70f6af6ba407"}, {name: "value", type: "uint256", value: "24629278681000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"99500000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4279897", timeStamp: "1505556078", hash: "0xf86caadc64cc829131520e560ad94fc728ff559beb7d83738141be0a4bdc94f4", nonce: "6238", blockHash: "0x60052a686bf38fdccd944ea9159e8296f5f290f69ac29ceb0833cc65afb0a926", transactionIndex: "28", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000008f365479b059173b0bfe1739a529445ab2ab180c00000000000000000000000000000000000000000000000564d702d38f5e0000", contractAddress: "", cumulativeGasUsed: "968418", gasUsed: "52006", confirmations: "3398775"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "99500000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "99500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1505556078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x8f365479b059173b0bfe1739a529445ab2ab180c"}, {name: "value", type: "uint256", value: "99500000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"49750000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4280051", timeStamp: "1505559604", hash: "0x4b15e327fdcaba944c9d8e5ee9e510bff81cb1fc60a509c0d9fb66771d75f8ce", nonce: "6261", blockHash: "0x04cbd05a018fd74d1a8de238bc2e13c539ec19c3443b2466d1f2ade8c623a48b", transactionIndex: "62", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "28000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000013435ba55bdf4b85e6bb890871d284f11b5c5244000000000000000000000000000000000000000000000002b26b8169c7af0000", contractAddress: "", cumulativeGasUsed: "1527029", gasUsed: "52006", confirmations: "3398621"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "49750000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "49750000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1505559604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x13435ba55bdf4b85e6bb890871d284f11b5c5244"}, {name: "value", type: "uint256", value: "49750000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"528948903310000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4280110", timeStamp: "1505560707", hash: "0x81361d77a24594f2a39f3902c8465fdd513298be0db5f033f189ecb97dac197e", nonce: "6274", blockHash: "0xa1dd1fa08b6ac1ac8bd7b437f95cc05f7316145eceda3f8f8664509adcbdebaf", transactionIndex: "51", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37135", gasPrice: "31680001925", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000013435ba55bdf4b85e6bb890871d284f11b5c5244000000000000000000000000000000000000000000000b3370106ae7933cb000", contractAddress: "", cumulativeGasUsed: "1526981", gasUsed: "37134", confirmations: "3398562"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "52894890331000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "52894890331000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1505560707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x13435ba55bdf4b85e6bb890871d284f11b5c5244"}, {name: "value", type: "uint256", value: "52894890331000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"718788000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4280114", timeStamp: "1505560822", hash: "0xcb0378ead0f4140a282336ed228de3acd26ca1f11b5fbaf9a9973b0b82839029", nonce: "6278", blockHash: "0x8197d1c4e3bccde5b227ff385491c7d6ece1b9f557e132e65f00ff9e77d02163", transactionIndex: "51", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "31680001925", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000007fb9de01ddd122eec549d19fb4b4a9ba669fbbca000000000000000000000000000000000000000000000026f72ff5b2ad7a0000", contractAddress: "", cumulativeGasUsed: "1749466", gasUsed: "52006", confirmations: "3398558"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "718788000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "718788000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1505560822 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x7fb9de01ddd122eec549d19fb4b4a9ba669fbbca"}, {name: "value", type: "uint256", value: "718788000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"522823227600000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4280180", timeStamp: "1505562542", hash: "0x17f2f71a407b9a65abacebd43e930372c399530da5627be9b9ddb82cdc961b51", nonce: "6286", blockHash: "0xfdfd5efdc21c5b91456193171e31e84995a266fc06a0125b5ccf583fd5e28596", transactionIndex: "176", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52135", gasPrice: "50000000001", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000005ae302d7823032e48f12cff6bd67da684071770300000000000000000000000000000000000000000000011b6c4c52a904094000", contractAddress: "", cumulativeGasUsed: "6644217", gasUsed: "52134", confirmations: "3398492"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "5228232276000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "5228232276000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1505562542 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x5ae302d7823032e48f12cff6bd67da6840717703"}, {name: "value", type: "uint256", value: "5228232276000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"52735000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4280337", timeStamp: "1505566591", hash: "0x310563e4fe4e3d7184ed77b2f16567369173cb1a62527b626b728673a294b4e8", nonce: "6316", blockHash: "0x6ed87489b1054cb74ad198411c9c9a47dc6d43f35a6944ba9a3b43e60be44d1b", transactionIndex: "92", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52071", gasPrice: "31680001925", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000cf02c814202b4f2bbfc6999c2e0cecc83d63c0bb000000000000000000000000000000000000000000000002dbd85b1916398000", contractAddress: "", cumulativeGasUsed: "5392512", gasUsed: "52070", confirmations: "3398335"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "52735000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "52735000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1505566591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xcf02c814202b4f2bbfc6999c2e0cecc83d63c0bb"}, {name: "value", type: "uint256", value: "52735000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"5228232276000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4280683", timeStamp: "1505575219", hash: "0xb98e21dd702c12ba99a5a8d1fe5c3cdcca42bc42b57f538a5c8ab00289fb464c", nonce: "0", blockHash: "0x324045a44ce144098670cb565695cc403d25f853762839d97b5ae8fb8545fc32", transactionIndex: "15", from: "0x5ae302d7823032e48f12cff6bd67da6840717703", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37134", gasPrice: "31680001925", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000072edd2c74e04523cc06862c47c95d2e3ce062d1000000000000000000000000000000000000000000000011b6c4c52a904094000", contractAddress: "", cumulativeGasUsed: "2416126", gasUsed: "22134", confirmations: "3397989"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "5228232276000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "5228232276000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1505575219 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x5ae302d7823032e48f12cff6bd67da6840717703"}, {name: "to", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "value", type: "uint256", value: "5228232276000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "475200028875000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"581080000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4282298", timeStamp: "1505613254", hash: "0x792286719bc46de43eacd21aa6c4c30512c6da6cee8657ac4bc4696da4ba678b", nonce: "6361", blockHash: "0x009e5fa076f8c34791c821103c055ca34e2c3e874f16c277b81b193ab490c72a", transactionIndex: "32", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "44000002674", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000fcb19a31d4125dd41f92cfcfd8d7a3322901777500000000000000000000000000000000000000000000001f801add4e63fc0000", contractAddress: "", cumulativeGasUsed: "1297091", gasUsed: "52006", confirmations: "3396374"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "581080000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "581080000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1505613254 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xfcb19a31d4125dd41f92cfcfd8d7a33229017775"}, {name: "value", type: "uint256", value: "581080000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"338300000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4282336", timeStamp: "1505614238", hash: "0x2a2838bc6d08baaa34fd90ac2487d24ecccd8167a3c2fe045fc479b3e642d63a", nonce: "6378", blockHash: "0x8fdb1c94c99f919f85bbc5ee94e24c946f3fd797d3fde52a90b23704678694ba", transactionIndex: "36", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "52007", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000006ae05f6e3d83395b6fd388c5975a780cb91b76900000000000000000000000000000000000000000000001256db099c1aa60000", contractAddress: "", cumulativeGasUsed: "911673", gasUsed: "52006", confirmations: "3396336"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "338300000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[31], "338300000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1505614238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0x06ae05f6e3d83395b6fd388c5975a780cb91b769"}, {name: "value", type: "uint256", value: "338300000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"149429100000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4282337", timeStamp: "1505614300", hash: "0x4ce79cf0f32da81b4f92029059219eb3ea0fe35af98903bfe486ae5e5d21947e", nonce: "6382", blockHash: "0x13f224916350960c58414bc3e3b6d7516e95e235a6e0f4667ba16a5d5299b008", transactionIndex: "161", from: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10", to: "0x23cf6ba6595155b771d848bb37132510dedc95bc", value: "0", gas: "37071", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000d0bac48046d0b824674781cd35b09ae64769f55200000000000000000000000000000000000000000000032a0e88c211d8530000", contractAddress: "", cumulativeGasUsed: "4260046", gasUsed: "37070", confirmations: "3396335"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "14942910000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "14942910000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1505614300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x72edd2c74e04523cc06862c47c95d2e3ce062d10"}, {name: "to", type: "address", value: "0xd0bac48046d0b824674781cd35b09ae64769f552"}, {name: "value", type: "uint256", value: "14942910000000000000000"}], address: "0x23cf6ba6595155b771d848bb37132510dedc95bc"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "979967835285599148" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
