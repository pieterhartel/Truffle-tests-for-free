const Tiles = artifacts.require( "./Tiles.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Tiles" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xCa9B7047a30B48942F61a729eCB1905E4b2a98DC", "0xB0623C91c65621df716aB8aFE5f66656B21A9108", "0xD88e34c9894a69b7302e2B09ac9b9c30Aa2751fC", "0x5026AEB37648038848f353470E0e22bA86ff2Fb4", "0x3AaC333b9687703a3A653f8f6dCCe890Cde4C5Fa", "0x836a082e4cc4Fb986A364F9bda12F019b85A6F45", "0x9FBb3cDfa041fD10D784acb6f66C614D57DC21E1", "0x2f830f627b00E3fA7aC4265308AF93804A066E49", "0xdD41a4108D31830BD4e8A9B9e453585227A5f295", "0xE5c02DB036331423A2d02804d187Fa291e2aA326", "0x9a4d5aA3D95e2Ff3cf9BAAC5be82cD4126042aa4", "0x1d7dE94188275A9cF6c069e1B3dA0eF599f80564", "0x535880B59738B860Dd51b7D0D2D8350EFDd79A3a", "0xb0eDE7A3D575A9903DB89A7AdfFbf67df2255Dc8", "0x5F7089e7a7D976703C1A1317e878da5f0098Eb4f", "0x6Ac2e5b1Dc2EDEae128d4bC8084962A339BacF5A"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "gameStopped", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numTilesClaimed", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentGameBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "NUM_TILES", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "DEFAULT_GAME_COST", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "tiles", outputs: [{name: "gameClaimed", type: "uint256"}, {name: "claimedBy", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "willChangeCost", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentGameNumber", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentGameCost", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "gameEarnings", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "gameToWinner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "nextGameCost", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pendingWithdrawals", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GameWon", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "claimedBy", type: "address"}, {indexed: true, name: "amountClaimed", type: "uint256"}], name: "WinningsClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "claimedBy", type: "address"}, {indexed: true, name: "amountToClaim", type: "uint256"}], name: "FailedToClaim", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "xCoord", type: "uint256"}, {indexed: false, name: "yCoord", type: "uint256"}], name: "PrintWinningInfo", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["GameWon(uint256,address)", "TileClaimed(uint256,uint256,uint256,address)", "WinningsClaimed(address,uint256)", "FailedToClaim(address,uint256)", "PrintWinningInfo(bytes32,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4dc08ce212d967a2959e5901a545b00fd4f86c108a0de62a8d906b7b0793c6d6", "0xa2a6aa11b3e307a3a2d16bed2bb47047a2e5a2301bf7d76bbeab835e9ec1b1cd", "0x1a31e733a172afcf46074b3106c17f0c298e226442682a03c1e99ce256139ec2", "0x7b2c89054c35e58ab5007ab56302305b6cde18f1968b6cd028f77ef6beec7fea", "0x37790454cc96774de45d3b27e3aea1849e97730e54e83a5a7177de0b2840083d"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4524160 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4537282 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Tiles", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "gameStopped", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameStopped()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numTilesClaimed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numTilesClaimed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentGameBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentGameBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "NUM_TILES", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "NUM_TILES()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DEFAULT_GAME_COST", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DEFAULT_GAME_COST()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "tiles", outputs: [{name: "gameClaimed", type: "uint256"}, {name: "claimedBy", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tiles(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "willChangeCost", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "willChangeCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentGameNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentGameNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentGameCost", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentGameCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gameEarnings", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameEarnings()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "gameToWinner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameToWinner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextGameCost", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextGameCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pendingWithdrawals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pendingWithdrawals(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Tiles", function( accounts ) {

	it( "TEST: Tiles(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4524160", timeStamp: "1510290081", hash: "0x3ba3d47f04bcd9fd0b30720435560a17ce15b42fc381256e55d46bcc3023e4b5", nonce: "38", blockHash: "0x1abb9d683b5a4aa873058babb9c4e862ac2cd01ba7bb3c97b5a92a12d5f4dd4b", transactionIndex: "30", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: 0, value: "0", gas: "1458004", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xedd99026", contractAddress: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", cumulativeGasUsed: "3266009", gasUsed: "1458004", confirmations: "3213422"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Tiles", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Tiles.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510290081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Tiles.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525508", timeStamp: "1510308670", hash: "0xfe2f01a34e2f451322ab90a5937fece5f80fd175888a385d528ff8b6d1097c92", nonce: "39", blockHash: "0x0e93d4cb4814acdda8b3199c3efcb615845cf12f3ce68b80894d00d24023f9e8", transactionIndex: "33", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "161001", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1995443", gasUsed: "107334", confirmations: "3212074"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510308670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0xb0623c91c65621df716ab8afe5f66656b21a9108"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525510", timeStamp: "1510308689", hash: "0x005f87262814164eec007c4d43d2cb31c75dac566051181f1167d546b05af70f", nonce: "11", blockHash: "0x6b762631dee4067d52a830eb86cc07b822c025242b8f2d0df814b07d9b5ca304", transactionIndex: "23", from: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "928019", gasUsed: "77270", confirmations: "3212072"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510308689 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "2854361344719998" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525931", timeStamp: "1510314836", hash: "0x5ae6413ff530135387ae50cc701ea8b8dcb81452d4bfea6c7a242923cfc48ca3", nonce: "6", blockHash: "0x026695d9d46d1f8927a8ced3153cd3a332510f9aa2ae2aab6434ae6db1ba376a", transactionIndex: "35", from: "0x5026aeb37648038848f353470e0e22ba86ff2fb4", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1226920", gasUsed: "77334", confirmations: "3211651"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510314836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0x5026aeb37648038848f353470e0e22ba86ff2fb4"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "14354496505678080" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"4\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525934", timeStamp: "1510314852", hash: "0x00587c06ca4afcef2de505fb5dbd8f49959c628445555b42193013c34a2d46a2", nonce: "7", blockHash: "0x3746604764d5a6d8a817c143f360ca108a55ae411587dbf834d361277648fee2", transactionIndex: "81", from: "0x5026aeb37648038848f353470e0e22ba86ff2fb4", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2117212", gasUsed: "77334", confirmations: "3211648"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "4"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "4", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510314852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "4"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0x5026aeb37648038848f353470e0e22ba86ff2fb4"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "14354496505678080" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525936", timeStamp: "1510314961", hash: "0xf4cab2bd4f8fe058eea888cf1a46264ca707af2cbbe301fd4bcb9abada984764", nonce: "8", blockHash: "0x162dfbe5c25f9884f783bc752e69c947436d58103067055c5a28ce2f4c4bcddd", transactionIndex: "183", from: "0x5026aeb37648038848f353470e0e22ba86ff2fb4", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "17000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5083064", gasUsed: "77334", confirmations: "3211646"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "1"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510314961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "1"}, {name: "claimedBy", type: "address", value: "0x5026aeb37648038848f353470e0e22ba86ff2fb4"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "14354496505678080" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525942", timeStamp: "1510315023", hash: "0x7b57d7fec71ae26c043ac760e7193a5fff6e13e61ffc7d0f0cc2f49b768e0a01", nonce: "9", blockHash: "0x4599affaa0ad0f6a09af7877ea9bdc8bff4da4bcf3ec1b21f95dc3ce6aa3acd4", transactionIndex: "27", from: "0x5026aeb37648038848f353470e0e22ba86ff2fb4", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "14702135296", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1288917", gasUsed: "77270", confirmations: "3211640"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510315023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x5026aeb37648038848f353470e0e22ba86ff2fb4"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "14354496505678080" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525948", timeStamp: "1510315086", hash: "0x5ac6fcc84e63aa729f4143153f1b0fbc4a68d32c7f72ef6cd2cb161294a2e00a", nonce: "10", blockHash: "0xe71036b6eed79692aa2e56adf9f6b6a3ecf7db4e4914e84db2ee752711bebe76", transactionIndex: "38", from: "0x5026aeb37648038848f353470e0e22ba86ff2fb4", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1247977", gasUsed: "77334", confirmations: "3211634"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510315086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0x5026aeb37648038848f353470e0e22ba86ff2fb4"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "14354496505678080" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"4\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525982", timeStamp: "1510315666", hash: "0xce774911767c03b5fb31e62a1b1e767567aaa005974d6ba91aacc24533cb3160", nonce: "8", blockHash: "0xf6c8df338841a7308698c01e215615fd575927aea291c119ceef3681ed139ea0", transactionIndex: "36", from: "0x3aac333b9687703a3a653f8f6dcce890cde4c5fa", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1154415", gasUsed: "77334", confirmations: "3211600"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "4"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "4", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510315666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "4"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x3aac333b9687703a3a653f8f6dcce890cde4c5fa"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "2670375435069445" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525983", timeStamp: "1510315676", hash: "0x6296a107034f969df9443e6be76eea24ed7a8e087ded1d9f5dcd33c441207711", nonce: "9", blockHash: "0x42ea675fa21efa5d8b12ec0844a7ace873bbcebc073a48c66161ad9613174eeb", transactionIndex: "43", from: "0x3aac333b9687703a3a653f8f6dcce890cde4c5fa", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1156201", gasUsed: "77270", confirmations: "3211599"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510315676 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0x3aac333b9687703a3a653f8f6dcce890cde4c5fa"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "2670375435069445" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4525984", timeStamp: "1510315684", hash: "0x042be6a718fcb79b3fb24756637999a66bfa8cf16201b29a3b2afc851bfe59f4", nonce: "10", blockHash: "0x6a8cc9a439a5a70cb93aa1d90bbee36202b674b5ad758c65f817294b4ca222db", transactionIndex: "14", from: "0x3aac333b9687703a3a653f8f6dcce890cde4c5fa", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "551671", gasUsed: "77270", confirmations: "3211598"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510315684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0x3aac333b9687703a3a653f8f6dcce890cde4c5fa"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "2670375435069445" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"4\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4526740", timeStamp: "1510326391", hash: "0xf075f9173a1a2c7587c31c19c480d7665cfb116deaddce89825bb3a463569ce3", nonce: "5", blockHash: "0xa7c216bde7496a0262e9873ffe7ebd696281666bf78a0c292f45d40d053209b1", transactionIndex: "51", from: "0x836a082e4cc4fb986a364f9bda12f019b85a6f45", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "17850000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2106292", gasUsed: "77270", confirmations: "3210842"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "4"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "4", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510326391 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "4"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0x836a082e4cc4fb986a364f9bda12f019b85a6f45"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "29582666700000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4526756", timeStamp: "1510326546", hash: "0xaf27e0ee8fd139e5677de99912a242f033438bc9739da42accb10ae441a40b12", nonce: "7", blockHash: "0xce54873d4021599fcb28093cfdf500f2256aabe5584fda92b23c55b98fb7438c", transactionIndex: "129", from: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115809", gasPrice: "17850000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3922167", gasUsed: "77206", confirmations: "3210826"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510326546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1976425738888888" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4526760", timeStamp: "1510326623", hash: "0x6ba6a50b1ffb92e884239de7b376c9a5d963f924343cac9ffe4b1b2b5b947825", nonce: "8", blockHash: "0x0d51622e759590fe02c8eb1218b2022714c2d7a55fbc089e5e41a4a497dfed8b", transactionIndex: "33", from: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1256461", gasUsed: "77270", confirmations: "3210822"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510326623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1976425738888888" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4527025", timeStamp: "1510330066", hash: "0xe5c86a628c347908da6557e7fe4a7b8dcb4e2bb18e94229a55f65493014c180b", nonce: "0", blockHash: "0xbc485b3b5bac71801f4777ca1b0836b65fc6206cd2efa49153b924d51d398159", transactionIndex: "59", from: "0x2f830f627b00e3fa7ac4265308af93804a066e49", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1987434", gasUsed: "77270", confirmations: "3210557"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "1"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510330066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "1"}, {name: "claimedBy", type: "address", value: "0x2f830f627b00e3fa7ac4265308af93804a066e49"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2747956999900000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4527042", timeStamp: "1510330250", hash: "0xee73fc13bdc2d05c09ef3a2bf7004d5534048a3150336658c3fe8ddfa4a4b888", nonce: "84", blockHash: "0x025fcb0caca8fdf4b93ac161725a8d7d63f5eee6a442f929e52c005d8c034bdc", transactionIndex: "121", from: "0xdd41a4108d31830bd4e8a9b9e453585227a5f295", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "15000000200", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3585756", gasUsed: "77334", confirmations: "3210540"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510330250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0xdd41a4108d31830bd4e8a9b9e453585227a5f295"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "586360652137014433" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4527671", timeStamp: "1510338958", hash: "0x451e98a7787f018810df89f40c495848cdb2432d64948d03f3df60ed23d0cdba", nonce: "40", blockHash: "0x76804d16dc5f2bc7197e3810f88610908de23a2ffec09b0fccc1c3ff56e3d2f1", transactionIndex: "42", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1421921", gasUsed: "77334", confirmations: "3209911"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510338958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0xb0623c91c65621df716ab8afe5f66656b21a9108"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4527672", timeStamp: "1510338988", hash: "0x3e3435453fb141bd047d424fe5ec3b604cce772e329a6660948309c7e094e03e", nonce: "41", blockHash: "0xd9e504ee68b7f2cffbe984e752eebc70218cc49d24aceb2cf6256398e0ba12d0", transactionIndex: "71", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2233009", gasUsed: "77334", confirmations: "3209910"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510338988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0xb0623c91c65621df716ab8afe5f66656b21a9108"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4529673", timeStamp: "1510366164", hash: "0x407d5be5c364e75f10c46e39853e7e505741dd412448d04f2524257b5b5b00df", nonce: "12", blockHash: "0x4d675dce68a360b491c13b7cced34757f9e9832441703a4b2f6e6021b1e3a297", transactionIndex: "37", from: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1323820", gasUsed: "77334", confirmations: "3207909"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510366164 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "2854361344719998" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4529673", timeStamp: "1510366164", hash: "0x5e179abc21ac2330eb3b5008107887de57fa04f414c26a6a89d3c3bfdd74ed28", nonce: "13", blockHash: "0x4d675dce68a360b491c13b7cced34757f9e9832441703a4b2f6e6021b1e3a297", transactionIndex: "48", from: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1835729", gasUsed: "77334", confirmations: "3207909"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510366164 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "2854361344719998" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4529674", timeStamp: "1510366173", hash: "0x4e9dc97585958a88432880dd4262f21905bd048e30a9534b6a152ec425498531", nonce: "14", blockHash: "0x3c532b2f3842f3ab133359ac7838a8f85400877e5aadf0ddfcdd8a50dce1aea3", transactionIndex: "10", from: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "437214", gasUsed: "77334", confirmations: "3207908"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510366173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "2854361344719998" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4529818", timeStamp: "1510368267", hash: "0x97df09c692e4332a493001a3e558f538cd3d5a226588158ec68cd0c4e1013ba0", nonce: "8", blockHash: "0x96dd72a06a5fc3d56f13ccb383c31b7033dacd499052df635de51673cc8eda9f", transactionIndex: "35", from: "0xe5c02db036331423a2d02804d187fa291e2aa326", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1250514", gasUsed: "77334", confirmations: "3207764"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510368267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0xe5c02db036331423a2d02804d187fa291e2aa326"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "428088288425928" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4529822", timeStamp: "1510368312", hash: "0x7432b567db06e3ab73b178cb0177e6183cdfe02250ad46f870543ebf89b538e3", nonce: "9", blockHash: "0x2388dd9b9220e691a24549025e8d64d5eeb668255bd3719ae35f384364a500ea", transactionIndex: "49", from: "0xe5c02db036331423a2d02804d187fa291e2aa326", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1453311", gasUsed: "77334", confirmations: "3207760"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510368312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0xe5c02db036331423a2d02804d187fa291e2aa326"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "428088288425928" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4529915", timeStamp: "1510369729", hash: "0x2ef265f1a277c7a5297be52cd2aac5a1cfdeecc82d352121f1d809d3bc856787", nonce: "42", blockHash: "0x093b22bf1df8cc94eeb1f0022bec7bf8bd6305133f528b1cc77e15dc6dbd6357", transactionIndex: "28", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "935776", gasUsed: "77270", confirmations: "3207667"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510369729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0xb0623c91c65621df716ab8afe5f66656b21a9108"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"4\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4529924", timeStamp: "1510369895", hash: "0xfb317524789fce86a09f681a711d1a332393b23e81c51ecd44c533f56b1bf23a", nonce: "43", blockHash: "0x836b0de447601e4a1a13e0d909920c1c37099e0c821560c50a76d1c882cc4d5e", transactionIndex: "85", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2833134", gasUsed: "77334", confirmations: "3207658"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "4"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "4", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510369895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "4"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0xb0623c91c65621df716ab8afe5f66656b21a9108"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4531579", timeStamp: "1510392598", hash: "0x4a4ec208ce81f34a7cf1f586771728b89a849064b1e2bf1fbff56289a38ceb8a", nonce: "6", blockHash: "0x6a86ae8bea31d1d98ed4b0ecfede2807b847777de1c214d17b2a81b918738dbc", transactionIndex: "62", from: "0x9a4d5aa3d95e2ff3cf9baac5be82cd4126042aa4", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2076719", gasUsed: "77334", confirmations: "3206003"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510392598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0x9a4d5aa3d95e2ff3cf9baac5be82cd4126042aa4"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "1504980317584540495" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"4\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4533088", timeStamp: "1510413419", hash: "0xce52ff5a6c4ce52ef181823f1e108c7ba8d4150d251ee057bec128688bfef171", nonce: "18", blockHash: "0xb1cf3b78f0ea41148db607c52f1b246a4dff0996f1942985fee916025d842922", transactionIndex: "39", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1087871", gasUsed: "77334", confirmations: "3204494"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "4"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "4", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510413419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "4"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4533088", timeStamp: "1510413419", hash: "0x08d3ab4e29d6383fe57cedcbc5c2ed2ec8f0f2b40aaf8bf17b18304d522cae55", nonce: "19", blockHash: "0xb1cf3b78f0ea41148db607c52f1b246a4dff0996f1942985fee916025d842922", transactionIndex: "60", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1903883", gasUsed: "77334", confirmations: "3204494"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510413419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4533088", timeStamp: "1510413419", hash: "0x510c3e54083673b9263f33ba9e9f536d52ca3fb81fdcb5b9109c3eb0c0ccb2fb", nonce: "20", blockHash: "0xb1cf3b78f0ea41148db607c52f1b246a4dff0996f1942985fee916025d842922", transactionIndex: "64", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2066162", gasUsed: "77334", confirmations: "3204494"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510413419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4533088", timeStamp: "1510413419", hash: "0x168ed575fd7b70c84bcd7a595b530d8202ca554dbdd3042b3e6fceae3ceb787c", nonce: "21", blockHash: "0xb1cf3b78f0ea41148db607c52f1b246a4dff0996f1942985fee916025d842922", transactionIndex: "66", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2164496", gasUsed: "77334", confirmations: "3204494"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510413419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4533088", timeStamp: "1510413419", hash: "0x788cca840e5038c5629f362d5040440b19afd8737860a1f6d1616930b6d1d458", nonce: "22", blockHash: "0xb1cf3b78f0ea41148db607c52f1b246a4dff0996f1942985fee916025d842922", transactionIndex: "68", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2262830", gasUsed: "77334", confirmations: "3204494"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510413419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4533139", timeStamp: "1510414091", hash: "0xcac9fde5b54ddadc17ecf50f82c110a02b6bf89d3aa6a505ca75e75c0d27c9b0", nonce: "0", blockHash: "0xb85fd8b5ba1ef9cef0c56897a2df39050ef1170c31abf65be0901c85f79b02e8", transactionIndex: "42", from: "0x535880b59738b860dd51b7d0d2d8350efdd79a3a", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1153201", gasUsed: "77334", confirmations: "3204443"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510414091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0x535880b59738b860dd51b7d0d2d8350efdd79a3a"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1080320000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4534421", timeStamp: "1510431559", hash: "0xbefa4d09acae5389cc81bf4a6a76704c14281e85e457ac9653b839f73b19ca55", nonce: "0", blockHash: "0x4dad0f46ce2ff37164a8bb07ee33a31136b61e0e8084ee135bd98a56928b318b", transactionIndex: "15", from: "0xb0ede7a3d575a9903db89a7adffbf67df2255dc8", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "444299", gasUsed: "77334", confirmations: "3203161"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510431559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0xb0ede7a3d575a9903db89a7adffbf67df2255dc8"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "726660000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4535555", timeStamp: "1510446977", hash: "0xdeb4342aa8a71e6e1b967d5b55f861b2394a4d11b222bc54cbc9425e0e80ce88", nonce: "0", blockHash: "0xe3652b96b238695ee9e20e2e245220c58c87db53344311e850c150295892399a", transactionIndex: "13", from: "0x5f7089e7a7d976703c1a1317e878da5f0098eb4f", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "596180", gasUsed: "77334", confirmations: "3202027"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510446977 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x5f7089e7a7d976703c1a1317e878da5f0098eb4f"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "9177196220334417" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"4\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4536863", timeStamp: "1510465048", hash: "0x0414c4ea1d3499294f9e3552f7b39d9efbaa39b164b5864459719169cf895d3e", nonce: "1", blockHash: "0xd79fcd67ef45408ec1276189b093b261be99258ebd9222fff78871543cd95788", transactionIndex: "33", from: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1108082", gasUsed: "77334", confirmations: "3200719"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "4"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "4", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510465048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "4"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "671792000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4536863", timeStamp: "1510465048", hash: "0x86cbb33bd83237d2004b7a9fe069f6ae2a49477ccebff8403e8478dcad59e18e", nonce: "2", blockHash: "0xd79fcd67ef45408ec1276189b093b261be99258ebd9222fff78871543cd95788", transactionIndex: "181", from: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6473527", gasUsed: "77270", confirmations: "3200719"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510465048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "671792000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4536872", timeStamp: "1510465167", hash: "0x9cb434db58183520f95056e01f406d5c30171b92349908ed5f2891a3eef3d6da", nonce: "3", blockHash: "0x55a44ae0f8bde5359e872a3c7ea38b3dc0c45d6020c095e5239587963ba6763a", transactionIndex: "7", from: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "306534", gasUsed: "77334", confirmations: "3200710"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "1"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510465167 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "1"}, {name: "claimedBy", type: "address", value: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "671792000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4536888", timeStamp: "1510465408", hash: "0x3d4b93d426680ed21c76dfdea9e825d89f890a2da0eaf68f4cb392e958cf4ce8", nonce: "8", blockHash: "0xb2ec3b1811d03a2bb725072c74444509169f60bd65052232309084a9ff1d9dd6", transactionIndex: "22", from: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "948035", gasUsed: "77270", confirmations: "3200694"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510465408 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "671792000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4536889", timeStamp: "1510465415", hash: "0x9d032ba1dec6bd7b62f372cb66705827b3322c579784576e4bc399ea0068374c", nonce: "9", blockHash: "0x796311810aeea0dd9b0c82d9414cb3168d5b88131649488be5767a1d97e4ecee", transactionIndex: "9", from: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "489142", gasUsed: "77334", confirmations: "3200693"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510465415 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0x6ac2e5b1dc2edeae128d4bc8084962a339bacf5a"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "671792000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537279", timeStamp: "1510470215", hash: "0x8803066e068114ffda183309ee9a2abca36556611c46d4495ad5e6dd082ae208", nonce: "23", blockHash: "0xc45c44d2ff34dfa82402084d608c3115e16cf7676687f1e4670999176e315699", transactionIndex: "77", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3171516", gasUsed: "77334", confirmations: "3200303"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510470215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537279", timeStamp: "1510470215", hash: "0x6d753544774e7489ade776f465c2a8a742fda905e306fe95b9a04fef295c94b6", nonce: "24", blockHash: "0xc45c44d2ff34dfa82402084d608c3115e16cf7676687f1e4670999176e315699", transactionIndex: "123", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4692704", gasUsed: "77334", confirmations: "3200303"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510470215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537279", timeStamp: "1510470215", hash: "0x47ef06673939c26d42c83b577dc4835628b996de015fa3c766a79b0c8a92a3a7", nonce: "25", blockHash: "0xc45c44d2ff34dfa82402084d608c3115e16cf7676687f1e4670999176e315699", transactionIndex: "128", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4916901", gasUsed: "77334", confirmations: "3200303"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510470215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537279", timeStamp: "1510470215", hash: "0xa75906a0d67df7f6d5b4f56c92f7e4415755adb381cde4ae7fded30356ba37dc", nonce: "26", blockHash: "0xc45c44d2ff34dfa82402084d608c3115e16cf7676687f1e4670999176e315699", transactionIndex: "131", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5045684", gasUsed: "77334", confirmations: "3200303"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510470215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537279", timeStamp: "1510470215", hash: "0x19b8abc532552927a31093c8bb1fc19d9d9f3f0485a8803d9d1d8d9c75bd0e6b", nonce: "27", blockHash: "0xc45c44d2ff34dfa82402084d608c3115e16cf7676687f1e4670999176e315699", transactionIndex: "134", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5174029", gasUsed: "77334", confirmations: "3200303"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510470215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537279", timeStamp: "1510470215", hash: "0xe850abf6914623ce09cd215314e283c245544286bfd1e9cf6df178e6720e9ad4", nonce: "28", blockHash: "0xc45c44d2ff34dfa82402084d608c3115e16cf7676687f1e4670999176e315699", transactionIndex: "137", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5302812", gasUsed: "77334", confirmations: "3200303"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510470215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537280", timeStamp: "1510470218", hash: "0x8a61862e71161c1fea0e1ce1f96bed306f5d67f91259c11458425dde28a644f2", nonce: "29", blockHash: "0x7cf79d3f0542eda84caa10f75e187a9f30136510d13158c36493295126a5e111", transactionIndex: "4", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "195289", gasUsed: "77334", confirmations: "3200302"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "1"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510470218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "1"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537282", timeStamp: "1510470241", hash: "0x038dc609d7e9a5ebc7ee1a543459ab9655a3f1fc79ee21464ace2f637d690f8b", nonce: "30", blockHash: "0x64b9c6816d72b8d2feaf04c94cc2addea835c7f851fb7ed4c8c7b9cbd342d1ef", transactionIndex: "19", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "710020", gasUsed: "77334", confirmations: "3200300"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510470241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537282", timeStamp: "1510470241", hash: "0xb51bb7049f89c63a175e99502215e477e4f2c5ebb8f483c24cc245682d3eb3b7", nonce: "31", blockHash: "0x64b9c6816d72b8d2feaf04c94cc2addea835c7f851fb7ed4c8c7b9cbd342d1ef", transactionIndex: "71", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2388281", gasUsed: "77334", confirmations: "3200300"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510470241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537282", timeStamp: "1510470241", hash: "0x1bc3928aca413605e79f3474f1e6f18cc030c3ffbb49f36663b928a6aeab93e3", nonce: "32", blockHash: "0x64b9c6816d72b8d2feaf04c94cc2addea835c7f851fb7ed4c8c7b9cbd342d1ef", transactionIndex: "78", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2624684", gasUsed: "77334", confirmations: "3200300"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510470241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4537282", timeStamp: "1510470241", hash: "0x23ec27e5799867d91fede3b5d988f704da401311bb3ad94cad961ab86473f61a", nonce: "33", blockHash: "0x64b9c6816d72b8d2feaf04c94cc2addea835c7f851fb7ed4c8c7b9cbd342d1ef", transactionIndex: "83", from: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564", to: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc", value: "5000000000000000", gas: "115905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2816768", gasUsed: "77270", confirmations: "3200300"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510470241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0x1d7de94188275a9cf6c069e1b3da0ef599f80564"}], address: "0xca9b7047a30b48942f61a729ecb1905e4b2a98dc"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "701078345000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "64000000000000182" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
