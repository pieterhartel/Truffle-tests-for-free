const TradexOne = artifacts.require( "./TradexOne.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TradexOne" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xF61a285eDf078536a410a5fBC28013F9660E54A8", "0x862596bcB5a42e19897C2026D0B35ad953324347", "0x0c64Fb52EAd79EB7e71bD375da4d2A3de78A9a5c", "0xA3114B268fF4327525fBc0DD5C48e0b4304D07b9", "0x59A2fe695011542c1A2c2Ab546A279c739F60337", "0x62D41E56c017609dF9095cE8c105228Ec64651e0", "0x32b8f720E05021bC6fBdBe77CF6aEF1332a9b5A7", "0x43393bc08091cE0c9fEcc5c86083871fbb6E0549", "0xe35ffb3752f6fB15a07ecFA8A1BB65EC51029718"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "bytes32"}], name: "orderFills", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "feeTake", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenGet", type: "address"}, {name: "amountGet", type: "uint256"}, {name: "tokenGive", type: "address"}, {name: "amountGive", type: "uint256"}, {name: "expires", type: "uint256"}, {name: "nonce", type: "uint256"}, {name: "user", type: "address"}, {name: "v", type: "uint8"}, {name: "r", type: "bytes32"}, {name: "s", type: "bytes32"}], name: "amountFilled", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "tokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "activeTokens", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "feeAccount", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenGet", type: "address"}, {name: "amountGet", type: "uint256"}, {name: "tokenGive", type: "address"}, {name: "amountGive", type: "uint256"}, {name: "expires", type: "uint256"}, {name: "nonce", type: "uint256"}, {name: "user", type: "address"}, {name: "v", type: "uint8"}, {name: "r", type: "bytes32"}, {name: "s", type: "bytes32"}, {name: "amount", type: "uint256"}, {name: "sender", type: "address"}], name: "testTrade", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "token", type: "address"}], name: "isTokenActive", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "feeWithdraw", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "bytes32"}], name: "orders", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokensMinAmountBuy", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokensMinAmountSell", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "feeDeposit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "token", type: "address"}, {name: "user", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "admin", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "feeMake", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenGet", type: "address"}, {name: "amountGet", type: "uint256"}, {name: "tokenGive", type: "address"}, {name: "amountGive", type: "uint256"}, {name: "expires", type: "uint256"}, {name: "nonce", type: "uint256"}, {name: "user", type: "address"}, {name: "v", type: "uint8"}, {name: "r", type: "bytes32"}, {name: "s", type: "bytes32"}], name: "availableVolume", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "v", type: "uint8"}, {indexed: false, name: "r", type: "bytes32"}, {indexed: false, name: "s", type: "bytes32"}], name: "Cancel", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "get", type: "address"}, {indexed: false, name: "give", type: "address"}], name: "Trade", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Withdraw", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "symbol", type: "string"}], name: "ActivateToken", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "symbol", type: "string"}], name: "DeactivateToken", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Order(address,uint256,address,uint256,uint256,uint256,address)", "Cancel(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32)", "Trade(address,uint256,address,uint256,address,address)", "Deposit(address,address,uint256,uint256)", "Withdraw(address,address,uint256,uint256)", "ActivateToken(address,string)", "DeactivateToken(address,string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x3f7f2eda73683c21a15f9435af1028c93185b5f1fa38270762dc32be606b3e85", "0x1e0b760c386003e9cb9bcf4fcf3997886042859d9b6ed6320e804597fcdb28b0", "0x6effdda786735d5033bfad5f53e5131abcced9e52be6c507b62d639685fbed6d", "0xdcbc1c05240f31ff3ad067ef1ee35ce4997762752e3a095284754544f4c709d7", "0xf341246adaac6f497bc2a656f546ab9e182111d630394f0c57c710a59a2cb567", "0x83ff0783aa7c78faf153742c858060e70207ace0311b2780ff79cb472fac2fe1", "0x51d96293e9103a3afaab55a4bc892be52943b1ab2e34b6415e8ede080be764af"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6593954 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6635110 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "admin_", value: 3}, {type: "address", name: "feeAccount_", value: 4}], name: "TradexOne", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "orderFills", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "orderFills(address,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "feeTake", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeTake(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "amountGet", value: random.range( maxRandom )}, {type: "address", name: "tokenGive", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "amountGive", value: random.range( maxRandom )}, {type: "uint256", name: "expires", value: random.range( maxRandom )}, {type: "uint256", name: "nonce", value: random.range( maxRandom )}, {type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint8", name: "v", value: random.range( maxRandom )}, {type: "bytes32", name: "r", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "s", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "amountFilled", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "amountFilled(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value,methodCall.inputs[ 4 ].value,methodCall.inputs[ 5 ].value,methodCall.inputs[ 6 ].value,methodCall.inputs[ 7 ].value,methodCall.inputs[ 8 ].value,methodCall.inputs[ 9 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokens(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "activeTokens", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "activeTokens(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feeAccount", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeAccount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "amountGet", value: random.range( maxRandom )}, {type: "address", name: "tokenGive", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "amountGive", value: random.range( maxRandom )}, {type: "uint256", name: "expires", value: random.range( maxRandom )}, {type: "uint256", name: "nonce", value: random.range( maxRandom )}, {type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint8", name: "v", value: random.range( maxRandom )}, {type: "bytes32", name: "r", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "s", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "uint256", name: "amount", value: random.range( maxRandom )}, {type: "address", name: "sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "testTrade", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "testTrade(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32,uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value,methodCall.inputs[ 4 ].value,methodCall.inputs[ 5 ].value,methodCall.inputs[ 6 ].value,methodCall.inputs[ 7 ].value,methodCall.inputs[ 8 ].value,methodCall.inputs[ 9 ].value,methodCall.inputs[ 10 ].value,methodCall.inputs[ 11 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "token", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isTokenActive", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isTokenActive(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "feeWithdraw", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeWithdraw(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "orders", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "orders(address,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokensMinAmountBuy", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensMinAmountBuy(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokensMinAmountSell", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensMinAmountSell(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "feeDeposit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeDeposit(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "token", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "admin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "admin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "feeMake", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeMake(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "amountGet", value: random.range( maxRandom )}, {type: "address", name: "tokenGive", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "amountGive", value: random.range( maxRandom )}, {type: "uint256", name: "expires", value: random.range( maxRandom )}, {type: "uint256", name: "nonce", value: random.range( maxRandom )}, {type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint8", name: "v", value: random.range( maxRandom )}, {type: "bytes32", name: "r", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "s", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "availableVolume", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "availableVolume(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value,methodCall.inputs[ 4 ].value,methodCall.inputs[ 5 ].value,methodCall.inputs[ 6 ].value,methodCall.inputs[ 7 ].value,methodCall.inputs[ 8 ].value,methodCall.inputs[ 9 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TradexOne", function( accounts ) {

	it( "TEST: TradexOne( addressList[3], addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6593954", blockHash: "0x72661c18ab1a193eab01e95ab22efa6186d638422380cd5a5de7fb4ac1390bd0", timeStamp: "1540655337", hash: "0x6b9baa935c43e0f08a4e65ade191420e51aa945784519bae2a7a036c97561e11", nonce: "0", transactionIndex: "5", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: 0, value: "0", gas: "5016716", gasPrice: "6000000000", input: "0x5a061a7a000000000000000000000000862596bcb5a42e19897c2026d0b35ad9533243470000000000000000000000000c64fb52ead79eb7e71bd375da4d2a3de78a9a5c", contractAddress: "0xf61a285edf078536a410a5fbc28013f9660e54a8", cumulativeGasUsed: "5159083", txreceipt_status: "1", gasUsed: "5016715", confirmations: "1140853", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin_", value: addressList[3]}, {type: "address", name: "feeAccount_", value: addressList[4]}], name: "TradexOne", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TradexOne.new( addressList[3], addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540655337 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TradexOne.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: activateToken( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6593963", blockHash: "0xca2ace058896c91f38c2325675442aa7ee47ae3d6b865d05c771e492dfeb9672", timeStamp: "1540655466", hash: "0x81507205ea0ddb362f8a0780e3b8a84cb67303dc3db6f6f95576bae43902e450", nonce: "1", transactionIndex: "77", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "49201", gasPrice: "4000000000", input: "0x0d1ce2d2000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9", contractAddress: "", cumulativeGasUsed: "4678733", txreceipt_status: "1", gasUsed: "49201", confirmations: "1140844", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}], name: "activateToken", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateToken(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540655466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "symbol", type: "string"}], name: "ActivateToken", type: "event"} ;
		console.error( "eventCallOriginal[1,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ActivateToken", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "symbol", type: "string", value: "SPECT"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[1,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenFeeDeposit( addressList[5], \"15000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6594087", blockHash: "0x146e7360aee3f6ace05def73d04414b0438c44cbc10881c7fe2cb7448e28678d", timeStamp: "1540657125", hash: "0x9c4e2c2c330654b4e60d75d06ca5902b7d7e07f0c2a1a1e028a9fbc6226dcbc1", nonce: "2", transactionIndex: "81", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "44392", gasPrice: "5000000000", input: "0xe41763f2000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000354a6ba7a18000", contractAddress: "", cumulativeGasUsed: "5101627", txreceipt_status: "1", gasUsed: "44392", confirmations: "1140720", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "feeDeposit_", value: "15000000000000000"}], name: "setTokenFeeDeposit", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenFeeDeposit(address,uint256)" ]( addressList[5], "15000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540657125 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenFeeMake( addressList[5], \"15000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6594104", blockHash: "0x39c2e51bc0f7150974acb5d278172b72a7cd8d5d9a7f2a657e3c2468dc297519", timeStamp: "1540657285", hash: "0x4f33e8da46a184f987de7e552a50514259888e39ec916d3fa34aa88e020d145a", nonce: "3", transactionIndex: "176", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "44524", gasPrice: "5000000000", input: "0xfdae6a92000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000354a6ba7a18000", contractAddress: "", cumulativeGasUsed: "7631266", txreceipt_status: "1", gasUsed: "44524", confirmations: "1140703", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "feeMake_", value: "15000000000000000"}], name: "setTokenFeeMake", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenFeeMake(address,uint256)" ]( addressList[5], "15000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540657285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenFeeTake( addressList[5], \"15000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6594104", blockHash: "0x39c2e51bc0f7150974acb5d278172b72a7cd8d5d9a7f2a657e3c2468dc297519", timeStamp: "1540657285", hash: "0x802bfb6dcca4e834516905ef63c7ba1053c2cdf589a75c7e4a5d1e7cfc6fbc17", nonce: "4", transactionIndex: "177", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "43974", gasPrice: "5000000000", input: "0x2a179054000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000354a6ba7a18000", contractAddress: "", cumulativeGasUsed: "7675240", txreceipt_status: "1", gasUsed: "43974", confirmations: "1140703", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "feeTake_", value: "15000000000000000"}], name: "setTokenFeeTake", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenFeeTake(address,uint256)" ]( addressList[5], "15000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540657285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenFeeWithdraw( addressList[5], \"15000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6594107", blockHash: "0xe70c5fcd81489bdea4f01d49b9ea66af99de118b070e316c8991095898e419aa", timeStamp: "1540657319", hash: "0x3abe00f5c54a093d823c8d96c9a051cba3976194c655e0aa7046c650992000d0", nonce: "5", transactionIndex: "190", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "43908", gasPrice: "5000000000", input: "0x1e14c48c000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000354a6ba7a18000", contractAddress: "", cumulativeGasUsed: "7762449", txreceipt_status: "1", gasUsed: "43908", confirmations: "1140700", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "feeWithdraw_", value: "15000000000000000"}], name: "setTokenFeeWithdraw", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenFeeWithdraw(address,uint256)" ]( addressList[5], "15000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540657319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenMinAmountBuy( addressList[5], \"100\" )", async function( ) {
		const txOriginal = {blockNumber: "6594111", blockHash: "0xa0c53e707b015a8d18fb6d443cf7b703180a2be3513affe8a8ad08da46adb41e", timeStamp: "1540657410", hash: "0xe800f3f1c05a401c0b73e0fa2f573aff3ee0ee35ac2c23b9d89de00b5013dbfe", nonce: "6", transactionIndex: "168", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "43610", gasPrice: "5000000000", input: "0x1f9c381e000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b90000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "7646853", txreceipt_status: "1", gasUsed: "43610", confirmations: "1140696", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "100"}], name: "setTokenMinAmountBuy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenMinAmountBuy(address,uint256)" ]( addressList[5], "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540657410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenMinAmountSell( addressList[5], \"100\" )", async function( ) {
		const txOriginal = {blockNumber: "6594115", blockHash: "0x470dd3f5359c954808cd2e62877e95b39d5b0b0bc13ead42041ba47d36753f99", timeStamp: "1540657436", hash: "0x4d7bba71e3804cb8a44f31daf1e7a16a7dbf1ee34931558b0b1ab15a2f658ad7", nonce: "7", transactionIndex: "74", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "43786", gasPrice: "5000000000", input: "0x5b8d8807000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b90000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "2696505", txreceipt_status: "1", gasUsed: "43786", confirmations: "1140692", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "100"}], name: "setTokenMinAmountSell", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenMinAmountSell(address,uint256)" ]( addressList[5], "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540657436 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[5], \"500\" )", async function( ) {
		const txOriginal = {blockNumber: "6607041", blockHash: "0x8bd75a4a3621994a3d99a9a091832957d5bb07d5a8c6daebd58b4cdb1ea15e19", timeStamp: "1540840419", hash: "0x6c81eb045d387b030d83d6775f28b0560fa7af07de07224991056dda5b86aa21", nonce: "7", transactionIndex: "72", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "156775", gasPrice: "2600000000", input: "0x338b5dea000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000001f4", contractAddress: "", cumulativeGasUsed: "7032444", txreceipt_status: "1", gasUsed: "89517", confirmations: "1127766", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "500"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[5], "500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540840419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}, {name: "amount", type: "uint256", value: "500"}, {name: "balance", type: "uint256", value: "493"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"10\", addressList[0], ... )", async function( ) {
		const txOriginal = {blockNumber: "6607090", blockHash: "0x0d03def35d0f776ba358090128bc840398abde492c632a54da705b12f7b8541a", timeStamp: "1540840917", hash: "0x62d30d4b1b2796df8ae4090dc69837f29c6f2432620a17fb54b29edceea1908d", nonce: "8", transactionIndex: "6", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "7600027", gasPrice: "3120000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001cd7a44c2500000000000000000000000000000000000000000000000000000000000065ab1c30000000000000000000000000000000000000000000000000000000bd8c7ddfe", contractAddress: "", cumulativeGasUsed: "250833", txreceipt_status: "0", gasUsed: "25553", confirmations: "1127717", isError: "1"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "10"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "507400000000000"}, {type: "uint256", name: "expires", value: "106607043"}, {type: "uint256", name: "nonce", value: "50881617406"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "10", addressList[0], "507400000000000", "106607043", "50881617406", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540840917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[5], \"100\" )", async function( ) {
		const txOriginal = {blockNumber: "6607110", blockHash: "0x8b831d039389f054f445ee90e24c5701f762b514373237e781dd7eefc4cdb054", timeStamp: "1540841154", hash: "0xa29497f9bb76dbe5fe16431de8dd535912ca755bdc37b6dee931581620356c8c", nonce: "7", transactionIndex: "97", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "111679", gasPrice: "2500000000", input: "0x338b5dea000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b90000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "6347568", txreceipt_status: "1", gasUsed: "44453", confirmations: "1127697", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "100"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[5], "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540841154 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "user", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}, {name: "amount", type: "uint256", value: "100"}, {name: "balance", type: "uint256", value: "99"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[5], \"500\" )", async function( ) {
		const txOriginal = {blockNumber: "6607150", blockHash: "0x2e3245391c5dd30747b8dd1eed2d5475b5a1285193827a25ea180b3394bc850b", timeStamp: "1540841662", hash: "0xd430ab170ccc38d1bcf344740f2b69f1bc858716f47c33ae91a0b6f3cf26c326", nonce: "1", transactionIndex: "102", from: "0x32b8f720e05021bc6fbdbe77cf6aef1332a9b5a7", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "111775", gasPrice: "3000000000", input: "0x338b5dea000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000001f4", contractAddress: "", cumulativeGasUsed: "6164567", txreceipt_status: "1", gasUsed: "59517", confirmations: "1127657", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "500"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[5], "500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540841662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "user", type: "address", value: "0x32b8f720e05021bc6fbdbe77cf6aef1332a9b5a7"}, {name: "amount", type: "uint256", value: "500"}, {name: "balance", type: "uint256", value: "493"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "8403179738683723" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"100\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6607168", blockHash: "0x63fd592c11c975663ea8bfc3d1d44d859a578302cd22897bab131b5733c048dd", timeStamp: "1540841843", hash: "0x0973b1c1357c706b1fa51e43566b6d268ffe78d7b3277769ecf84e6b2f81aa29", nonce: "2", transactionIndex: "61", from: "0x32b8f720e05021bc6fbdbe77cf6aef1332a9b5a7", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75457", gasPrice: "2500000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000018de76816d7fff00000000000000000000000000000000000000000000000000000000006a0ec60000000000000000000000000000000000000000000000000000000e56e86163", contractAddress: "", cumulativeGasUsed: "6544798", txreceipt_status: "1", gasUsed: "50305", confirmations: "1127639", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "100"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "6999999999999999"}, {type: "uint256", name: "expires", value: "6950598"}, {type: "uint256", name: "nonce", value: "61587612003"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "100", addressList[0], "6999999999999999", "6950598", "61587612003", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540841843 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "100"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "6999999999999999"}, {name: "expires", type: "uint256", value: "6950598"}, {name: "nonce", type: "uint256", value: "61587612003"}, {name: "user", type: "address", value: "0x32b8f720e05021bc6fbdbe77cf6aef1332a9b5a7"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "8403179738683723" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[5], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "6607215", blockHash: "0x7e87d5a9ba24d330d253d9f7d882f22611ea5c41ed836beb87c0b2df8a4ffc51", timeStamp: "1540842648", hash: "0xf0b783aab71e55751295ffd52fae7c1a12ce2453b28706275a8307c4da122dd5", nonce: "12", transactionIndex: "88", from: "0x43393bc08091ce0c9fecc5c86083871fbb6e0549", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "111679", gasPrice: "3360000000", input: "0x338b5dea000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "4149892", txreceipt_status: "1", gasUsed: "59453", confirmations: "1127592", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "200"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[5], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540842648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "user", type: "address", value: "0x43393bc08091ce0c9fecc5c86083871fbb6e0549"}, {name: "amount", type: "uint256", value: "200"}, {name: "balance", type: "uint256", value: "197"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2759988309541496" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[5], \"500\" )", async function( ) {
		const txOriginal = {blockNumber: "6607216", blockHash: "0xf651b001f696e693e8b1c1b365223fbcf96451943378e6773bd3965bda9cd3a0", timeStamp: "1540842657", hash: "0x845c23f79c4c6b345dcbc83fcc0484b4f3019ba5be9a956b7d39aa800f4fa1b1", nonce: "4", transactionIndex: "64", from: "0x32b8f720e05021bc6fbdbe77cf6aef1332a9b5a7", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "89275", gasPrice: "2530000100", input: "0x338b5dea000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000001f4", contractAddress: "", cumulativeGasUsed: "6597973", txreceipt_status: "1", gasUsed: "29759", confirmations: "1127591", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "500"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[5], "500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540842657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "user", type: "address", value: "0x32b8f720e05021bc6fbdbe77cf6aef1332a9b5a7"}, {name: "amount", type: "uint256", value: "500"}, {name: "balance", type: "uint256", value: "986"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "8403179738683723" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "6609556", blockHash: "0xbfb4dd5f858093b1b2c5229d88f9710145683bb66d64d467905a22309cfb6975", timeStamp: "1540876129", hash: "0xa556afa53454a37969b282740d64114d39ab171c097ad896abb2cd86224a470f", nonce: "9", transactionIndex: "157", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "10000000000000000", gas: "77640", gasPrice: "3000000000", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "6358459", txreceipt_status: "1", gasUsed: "51760", confirmations: "1125251", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540876129 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "balance", type: "uint256", value: "10000000000000000"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"60\", addressList[0], ... )", async function( ) {
		const txOriginal = {blockNumber: "6609688", blockHash: "0x3a662d0d26c29649f30579e3fc9787dbfda7d3bfcb29e9b955228c08123df399", timeStamp: "1540878008", hash: "0xd0d0df17e28d86804a518fd62dc44aef1364a21015ee483182bd1cb472637516", nonce: "10", transactionIndex: "7", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "7600027", gasPrice: "3812500000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000eebe0b40e80000000000000000000000000000000000000000000000000000000000000686dc90000000000000000000000000000000000000000000000000000000e8ca419d9", contractAddress: "", cumulativeGasUsed: "222238", txreceipt_status: "0", gasUsed: "25489", confirmations: "1125119", isError: "1"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "60"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "4200000000000000"}, {type: "uint256", name: "expires", value: "6843849"}, {type: "uint256", name: "nonce", value: "62489106905"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "60", addressList[0], "4200000000000000", "6843849", "62489106905", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540878008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[5], \"500\" )", async function( ) {
		const txOriginal = {blockNumber: "6612954", blockHash: "0x9113493e8f97452c194dc484262452d9107e8b98356e6ac001fda30d79f82eca", timeStamp: "1540924409", hash: "0xb2fe06d5052e3694c3cc683d42b4560bde834411dd4dfcf51229dbae67461583", nonce: "9", transactionIndex: "102", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "89275", gasPrice: "3000000000", input: "0x338b5dea000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000001f4", contractAddress: "", cumulativeGasUsed: "6911445", txreceipt_status: "1", gasUsed: "44517", confirmations: "1121853", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "500"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[5], "500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540924409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "user", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}, {name: "amount", type: "uint256", value: "500"}, {name: "balance", type: "uint256", value: "592"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"100\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6612996", blockHash: "0xf906f468b01ab4df0121233b685cba56ebdb12ab01c5c83733283e43ce5ab39c", timeStamp: "1540925056", hash: "0x2fcb8983838f2ad94597077647ded6f8c63c5680ffa2152dec0b99d93b587b7a", nonce: "10", transactionIndex: "55", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "2730000100", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000019ef4fb2dc40000000000000000000000000000000000000000000000000000000000000650ef20000000000000000000000000000000000000000000000000000000ec0025fcd", contractAddress: "", cumulativeGasUsed: "7691104", txreceipt_status: "1", gasUsed: "50241", confirmations: "1121811", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "100"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "7300000000000000"}, {type: "uint256", name: "expires", value: "6622962"}, {type: "uint256", name: "nonce", value: "63350923213"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "100", addressList[0], "7300000000000000", "6622962", "63350923213", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540925056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "100"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "7300000000000000"}, {name: "expires", type: "uint256", value: "6622962"}, {name: "nonce", type: "uint256", value: "63350923213"}, {name: "user", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"400\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6613085", blockHash: "0xd88691271df936c71938d5a21329ced36ee20e081f2ce5d96ff48e2549d44806", timeStamp: "1540926283", hash: "0x05acd126fd062e22654a4807b6bcd4dc8ff4413e30dcf70bbaf2a8eb3facb5d2", nonce: "12", transactionIndex: "70", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "2000000001", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b90000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f195a3c4ba0000000000000000000000000000000000000000000000000000000000000072a35c000000000000000000000000000000000000000000000000000000152309078c", contractAddress: "", cumulativeGasUsed: "7968407", txreceipt_status: "1", gasUsed: "50241", confirmations: "1121722", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "400"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "68000000000000000"}, {type: "uint256", name: "expires", value: "7512924"}, {type: "uint256", name: "nonce", value: "90782107532"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "400", addressList[0], "68000000000000000", "7512924", "90782107532", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540926283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "400"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "68000000000000000"}, {name: "expires", type: "uint256", value: "7512924"}, {name: "nonce", type: "uint256", value: "90782107532"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"8000000000000000\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "6613087", blockHash: "0x69e31e5771ce54c6a8c7b795ce2c48ae427bfc434691c214df41d5d04b792a67", timeStamp: "1540926313", hash: "0xaa61b12f998a09793aa084ce667ad1861b03845ba6aaae69b6ea059be16cf34a", nonce: "13", transactionIndex: "64", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "5000000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001c6bf526340000000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000fd7e4d0000000000000000000000000000000000000000000000000000000ead7845f8", contractAddress: "", cumulativeGasUsed: "3241030", txreceipt_status: "1", gasUsed: "50241", confirmations: "1121720", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "8000000000000000"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "1000"}, {type: "uint256", name: "expires", value: "16612941"}, {type: "uint256", name: "nonce", value: "63039882744"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "8000000000000000", addressList[5], "1000", "16612941", "63039882744", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540926313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "8000000000000000"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "1000"}, {name: "expires", type: "uint256", value: "16612941"}, {name: "nonce", type: "uint256", value: "63039882744"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "6613087", blockHash: "0x69e31e5771ce54c6a8c7b795ce2c48ae427bfc434691c214df41d5d04b792a67", timeStamp: "1540926313", hash: "0x4b40f422e520c04a88fbac3425baedbdaa8ef0248c2e4dc98102826de35b8f6a", nonce: "14", transactionIndex: "108", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "20000000000000000", gas: "55140", gasPrice: "3000000000", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "6296143", txreceipt_status: "1", gasUsed: "36760", confirmations: "1121720", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540926313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}, {name: "amount", type: "uint256", value: "20000000000000000"}, {name: "balance", type: "uint256", value: "30000000000000000"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"17640000000000000\", a... )", async function( ) {
		const txOriginal = {blockNumber: "6615759", blockHash: "0x76f3d67ff181c58fd10b1a3bca6c45c1f18a367a4e7f7dcbbd7e26658b4c0fb3", timeStamp: "1540963736", hash: "0x4a74b739e4760eb1302c0ff86c558a1b93f1db61636b3c9fb92b01e2f19d7909", nonce: "17", transactionIndex: "9", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "59000000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003eab7c8dd68000000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000f5000000000000000000000000000000000000000000000000000000000072ae6b0000000000000000000000000000000000000000000000000000000f3289f96a", contractAddress: "", cumulativeGasUsed: "404350", txreceipt_status: "1", gasUsed: "50241", confirmations: "1119048", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "17640000000000000"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "245"}, {type: "uint256", name: "expires", value: "7515755"}, {type: "uint256", name: "nonce", value: "65272412522"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "17640000000000000", addressList[5], "245", "7515755", "65272412522", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540963736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "17640000000000000"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "245"}, {name: "expires", type: "uint256", value: "7515755"}, {name: "nonce", type: "uint256", value: "65272412522"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: changeAdmin( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6630598", blockHash: "0x7e10ab03405f7387b74c2a60dcb25adff357a133e6f494e3fedeb355f9b6d0d5", timeStamp: "1541174780", hash: "0x09d71f1f7743255df2b67184dc3a748f8a928e42d5a8f130f64896e67358c1f4", nonce: "11", transactionIndex: "186", from: "0x862596bcb5a42e19897c2026d0b35ad953324347", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "43290", gasPrice: "10000000000", input: "0x8f2839700000000000000000000000000c64fb52ead79eb7e71bd375da4d2a3de78a9a5c", contractAddress: "", cumulativeGasUsed: "5123214", txreceipt_status: "1", gasUsed: "28860", confirmations: "1104209", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin_", value: addressList[4]}], name: "changeAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeAdmin(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541174780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "529107923969972926" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"330\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6633873", blockHash: "0x3577b5f39e4de4fc76946e386407db6adcb9408e8a9685a64b7f107cac5dd0e8", timeStamp: "1541221631", hash: "0x49b7aca421b19394fb4fabba34f86714cb6bf2cd38e84616185e7de1323c6e73", nonce: "19", transactionIndex: "93", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75553", gasPrice: "3000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000014a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004713941089a40000000000000000000000000000000000000000000000000000000000000744c850000000000000000000000000000000000000000000000000000000c5ab869f9", contractAddress: "", cumulativeGasUsed: "6921517", txreceipt_status: "1", gasUsed: "50369", confirmations: "1100934", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "330"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "320100000000000000"}, {type: "uint256", name: "expires", value: "7621765"}, {type: "uint256", name: "nonce", value: "53061642745"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "330", addressList[0], "320100000000000000", "7621765", "53061642745", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541221631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "330"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "320100000000000000"}, {name: "expires", type: "uint256", value: "7621765"}, {name: "nonce", type: "uint256", value: "53061642745"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"199\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6633899", blockHash: "0xe1f1c0034f1e57c980b4eeb5afdceb63ce0778f749b2e258b82944eaf925f819", timeStamp: "1541222077", hash: "0x7d8b7eff69c4fe93e29fe1411dbab4a23ac13d30dd94d7ab11fa8dbcbe4c49b0", nonce: "21", transactionIndex: "109", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "5000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000c70000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000026714d155f6a000000000000000000000000000000000000000000000000000000000000072f54800000000000000000000000000000000000000000000000000000004d72af300", contractAddress: "", cumulativeGasUsed: "7422488", txreceipt_status: "1", gasUsed: "50241", confirmations: "1100908", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "199"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "173130000000000000"}, {type: "uint256", name: "expires", value: "7533896"}, {type: "uint256", name: "nonce", value: "20789785344"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "199", addressList[0], "173130000000000000", "7533896", "20789785344", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541222077 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "199"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "173130000000000000"}, {name: "expires", type: "uint256", value: "7533896"}, {name: "nonce", type: "uint256", value: "20789785344"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"10620000000000001\", a... )", async function( ) {
		const txOriginal = {blockNumber: "6633911", blockHash: "0x68cde3d7945ded376c374c9d43d68c9be52298a5f1c6764aaf7afd125feac327", timeStamp: "1541222214", hash: "0x8adea72d1f28b765681fa1f8fefb494469ab96d1ef88e691daec9ca8d87926aa", nonce: "22", transactionIndex: "97", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75457", gasPrice: "4000000000", input: "0x0b92766600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025bad56f83c001000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000b10000000000000000000000000000000000000000000000000000000000fdd03300000000000000000000000000000000000000000000000000000001c209d856", contractAddress: "", cumulativeGasUsed: "5555200", txreceipt_status: "1", gasUsed: "50305", confirmations: "1100896", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "10620000000000001"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "177"}, {type: "uint256", name: "expires", value: "16633907"}, {type: "uint256", name: "nonce", value: "7550392406"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "10620000000000001", addressList[5], "177", "16633907", "7550392406", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541222214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "10620000000000001"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "177"}, {name: "expires", type: "uint256", value: "16633907"}, {name: "nonce", type: "uint256", value: "7550392406"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"14200000000000000\", a... )", async function( ) {
		const txOriginal = {blockNumber: "6633933", blockHash: "0x3fb1739825e7203109c698f23106b3c24c82bbec9687bea3d1344b5d1e889678", timeStamp: "1541222489", hash: "0x0f2f607ebd6f8bf0442569913908065a502b5632c2e7a8318806b44811f35fef", nonce: "23", transactionIndex: "2", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "20000000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003272d323cf8000000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000c8000000000000000000000000000000000000000000000000000000000072f56800000000000000000000000000000000000000000000000000000009c75c9006", contractAddress: "", cumulativeGasUsed: "92241", txreceipt_status: "1", gasUsed: "50241", confirmations: "1100874", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "14200000000000000"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "200"}, {type: "uint256", name: "expires", value: "7533928"}, {type: "uint256", name: "nonce", value: "41999437830"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "14200000000000000", addressList[5], "200", "7533928", "41999437830", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541222489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "14200000000000000"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "200"}, {name: "expires", type: "uint256", value: "7533928"}, {name: "nonce", type: "uint256", value: "41999437830"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"6324000000000000\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "6634041", blockHash: "0xd900a1a02b2abcb8c24e0a19502b618bc36e8163cacefd1621cc32ab2fdd1fe2", timeStamp: "1541224005", hash: "0xcb1725899611804ab9f9d3f539fb8ccef49bd600be8b68da575219abf928b680", nonce: "24", transactionIndex: "5", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "24000000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001677a4fd8f4000000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000007c0000000000000000000000000000000000000000000000000000000000fdcc5e000000000000000000000000000000000000000000000000000000035ca2e0f9", contractAddress: "", cumulativeGasUsed: "186079", txreceipt_status: "1", gasUsed: "50241", confirmations: "1100766", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "6324000000000000"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "124"}, {type: "uint256", name: "expires", value: "16632926"}, {type: "uint256", name: "nonce", value: "14439080185"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "6324000000000000", addressList[5], "124", "16632926", "14439080185", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541224005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "6324000000000000"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "124"}, {name: "expires", type: "uint256", value: "16632926"}, {name: "nonce", type: "uint256", value: "14439080185"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"8249999999999999\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "6634735", blockHash: "0xd9ed3f8b9655abb351860ea32e89188f14417f181cab2fd8e5588e4ed01760b9", timeStamp: "1541233860", hash: "0xbe3af465094dc466f7e9a3136d8ef62a355efe5268700178e8d83176ac32efc1", nonce: "11", transactionIndex: "135", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75457", gasPrice: "7000000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001d4f54cf659fff000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000006e0000000000000000000000000000000000000000000000000000000000747f280000000000000000000000000000000000000000000000000000000c11da76fa", contractAddress: "", cumulativeGasUsed: "4688909", txreceipt_status: "1", gasUsed: "50305", confirmations: "1100072", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "8249999999999999"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "110"}, {type: "uint256", name: "expires", value: "7634728"}, {type: "uint256", name: "nonce", value: "51839137530"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "8249999999999999", addressList[5], "110", "7634728", "51839137530", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541233860 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "8249999999999999"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "110"}, {name: "expires", type: "uint256", value: "7634728"}, {name: "nonce", type: "uint256", value: "51839137530"}, {name: "user", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: trade( addressList[0], \"8249999999999999\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "6634779", blockHash: "0x86a667c0c926e1291ceaa7a9c87d2be74765aed5202d45fcc86b586cf0a1435f", timeStamp: "1541234305", hash: "0x8022b1ecf392f07462c1767783b5bc7c144ecde0125a9af3b7748ee6f86892a2", nonce: "26", transactionIndex: "43", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "149040", gasPrice: "7000000000", input: "0x0a19b14a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001d4f54cf659fff000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000006e0000000000000000000000000000000000000000000000000000000000747f280000000000000000000000000000000000000000000000000000000c11da76fa00000000000000000000000062d41e56c017609df9095ce8c105228ec64651e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001d4f54cf659fff", contractAddress: "", cumulativeGasUsed: "4217196", txreceipt_status: "1", gasUsed: "99360", confirmations: "1100028", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "8249999999999999"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "110"}, {type: "uint256", name: "expires", value: "7634728"}, {type: "uint256", name: "nonce", value: "51839137530"}, {type: "address", name: "user", value: addressList[7]}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "amount", value: "8249999999999999"}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32,uint256)" ]( addressList[0], "8249999999999999", addressList[5], "110", "7634728", "51839137530", addressList[7], "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "8249999999999999", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541234305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "get", type: "address"}, {indexed: false, name: "give", type: "address"}], name: "Trade", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Trade", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "8249999999999999"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "110"}, {name: "get", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}, {name: "give", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"9594000000000000\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "6634803", blockHash: "0x117f9c57c174b03ccec76278d0023c2072bab0e6a939ee34231f0c91ffdd9a7c", timeStamp: "1541234698", hash: "0x32ec955cf7d2b7cbca276f23d782442d68843a4374e659804889e43ea8d92dbe", nonce: "27", transactionIndex: "154", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75457", gasPrice: "7000000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002215b131f9a000000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000007b00000000000000000000000000000000000000000000000000000000065b1e2f0000000000000000000000000000000000000000000000000000000371a047d3", contractAddress: "", cumulativeGasUsed: "7212020", txreceipt_status: "1", gasUsed: "50305", confirmations: "1100004", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "9594000000000000"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "123"}, {type: "uint256", name: "expires", value: "106634799"}, {type: "uint256", name: "nonce", value: "14791231443"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "9594000000000000", addressList[5], "123", "106634799", "14791231443", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541234698 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "9594000000000000"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "123"}, {name: "expires", type: "uint256", value: "106634799"}, {name: "nonce", type: "uint256", value: "14791231443"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"7810000000000000\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "6634846", blockHash: "0xffcbcf2f9ddd5540bf2c026220dd44c9a6d84211c1982362cb2853728b722b5b", timeStamp: "1541235246", hash: "0x908e1b20c15289592e2206e0102d8f5ea357127ae332e753ed626c0fd9f067a2", nonce: "12", transactionIndex: "55", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "8000000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001bbf2753b22000000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000006e0000000000000000000000000000000000000000000000000000000000747f9a00000000000000000000000000000000000000000000000000000010e7986b48", contractAddress: "", cumulativeGasUsed: "7698268", txreceipt_status: "1", gasUsed: "50241", confirmations: "1099961", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "7810000000000000"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "110"}, {type: "uint256", name: "expires", value: "7634842"}, {type: "uint256", name: "nonce", value: "72605002568"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "7810000000000000", addressList[5], "110", "7634842", "72605002568", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541235246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "7810000000000000"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "110"}, {name: "expires", type: "uint256", value: "7634842"}, {name: "nonce", type: "uint256", value: "72605002568"}, {name: "user", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "6634874", blockHash: "0x1a28e11d8380b49f2197ab15a7c3e1d8d11da9fba904291c08a2f877850b0296", timeStamp: "1541235604", hash: "0x302c749a383f81975efa79561c249cf760344492263c624fd62fa2ca52734954", nonce: "0", transactionIndex: "53", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "10000000000000000", gas: "77640", gasPrice: "7300000000", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "2888038", txreceipt_status: "1", gasUsed: "51760", confirmations: "1099933", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541235604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "balance", type: "uint256", value: "10000000000000000"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[0], \"7739000000000000\", ad... )", async function( ) {
		const txOriginal = {blockNumber: "6634884", blockHash: "0x9db77e4bedfa6a80bfec87f98000063b9de0774222dd89f107ac28a3807ff456", timeStamp: "1541235708", hash: "0x8316e9dac31e716b09feee2827909501026ab29fb2e181046e30454696f2eb72", nonce: "1", transactionIndex: "36", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75457", gasPrice: "7300000000", input: "0x0b9276660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b7e9459eab000000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000006d0000000000000000000000000000000000000000000000000000000035fabcc7000000000000000000000000000000000000000000000000000000106cc6cd8f", contractAddress: "", cumulativeGasUsed: "4074076", txreceipt_status: "1", gasUsed: "50305", confirmations: "1099923", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[0]}, {type: "uint256", name: "amountGet", value: "7739000000000000"}, {type: "address", name: "tokenGive", value: addressList[5]}, {type: "uint256", name: "amountGive", value: "109"}, {type: "uint256", name: "expires", value: "905624775"}, {type: "uint256", name: "nonce", value: "70544444815"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[0], "7739000000000000", addressList[5], "109", "905624775", "70544444815", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541235708 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGet", type: "uint256", value: "7739000000000000"}, {name: "tokenGive", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGive", type: "uint256", value: "109"}, {name: "expires", type: "uint256", value: "905624775"}, {name: "nonce", type: "uint256", value: "70544444815"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"390\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6634893", blockHash: "0xe0debeb2eba26e9ded56c87a991c9c16fccf8caa1d48c0313d98427e739cadad", timeStamp: "1541235897", hash: "0xe8b0aa8a1f11fce0c3f87c84a8fe166316fd9b203b11848785abc9ac3a3d0f66", nonce: "28", transactionIndex: "71", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "9000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000001860000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011bc3292b8000000000000000000000000000000000000000000000000000000000000747fc900000000000000000000000000000000000000000000000000000006a05bd81c", contractAddress: "", cumulativeGasUsed: "6000560", txreceipt_status: "1", gasUsed: "50241", confirmations: "1099914", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "390"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "19500000000000"}, {type: "uint256", name: "expires", value: "7634889"}, {type: "uint256", name: "nonce", value: "28460177436"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "390", addressList[0], "19500000000000", "7634889", "28460177436", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541235897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "390"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "19500000000000"}, {name: "expires", type: "uint256", value: "7634889"}, {name: "nonce", type: "uint256", value: "28460177436"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: trade( addressList[5], \"390\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6634918", blockHash: "0x2ec811c5bb15761f48e191d7b8be9a1d562b20ed5530a3b077811f8c7fb06e96", timeStamp: "1541236145", hash: "0x636ece79b48f748cd19a40c91a273143699bd4410faa9fd5a2eb1813a30d477a", nonce: "13", transactionIndex: "26", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "125868", gasPrice: "8400000000", input: "0x0a19b14a000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000001860000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011bc3292b8000000000000000000000000000000000000000000000000000000000000747fc900000000000000000000000000000000000000000000000000000006a05bd81c00000000000000000000000059a2fe695011542c1a2c2ab546a279c739f603370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "2107327", txreceipt_status: "1", gasUsed: "83912", confirmations: "1099889", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "390"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "19500000000000"}, {type: "uint256", name: "expires", value: "7634889"}, {type: "uint256", name: "nonce", value: "28460177436"}, {type: "address", name: "user", value: addressList[6]}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "amount", value: "100"}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32,uint256)" ]( addressList[5], "390", addressList[0], "19500000000000", "7634889", "28460177436", addressList[6], "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541236145 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "get", type: "address"}, {indexed: false, name: "give", type: "address"}], name: "Trade", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Trade", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "100"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "5000000000000"}, {name: "get", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}, {name: "give", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"150\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6634928", blockHash: "0x38baa9428d8d5d9537bed6634a352f15d015b6f7fc1d115073a95ee4413bdc14", timeStamp: "1541236338", hash: "0x2c6b405a5a63e5a0ba58cd1e65f462d2ae326527d8c4ffe3d78582ba2e6de0fe", nonce: "14", transactionIndex: "73", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "7475000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000009600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000024c545296ce0000000000000000000000000000000000000000000000000000000000000747fe7000000000000000000000000000000000000000000000000000000073b11278e", contractAddress: "", cumulativeGasUsed: "7393745", txreceipt_status: "1", gasUsed: "50241", confirmations: "1099879", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "150"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "10350000000000000"}, {type: "uint256", name: "expires", value: "7634919"}, {type: "uint256", name: "nonce", value: "31055751054"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "150", addressList[0], "10350000000000000", "7634919", "31055751054", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541236338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "150"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "10350000000000000"}, {name: "expires", type: "uint256", value: "7634919"}, {name: "nonce", type: "uint256", value: "31055751054"}, {name: "user", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: depositToken( addressList[5], \"400\" )", async function( ) {
		const txOriginal = {blockNumber: "6634960", blockHash: "0xa0b3f7595fb539ad79e337b34c61873d79171b10e1d7eaeafe388faf5f8566ec", timeStamp: "1541236815", hash: "0x6a352ac7dd6ef7469c75b5310e1e24dbba7e45a820afb5ce3a67ce84b3c36d58", nonce: "4", transactionIndex: "42", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "111775", gasPrice: "8000000000", input: "0x338b5dea000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b90000000000000000000000000000000000000000000000000000000000000190", contractAddress: "", cumulativeGasUsed: "5748296", txreceipt_status: "1", gasUsed: "44517", confirmations: "1099847", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "token", value: addressList[5]}, {type: "uint256", name: "amount", value: "400"}], name: "depositToken", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToken(address,uint256)" ]( addressList[5], "400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541236815 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}, {name: "amount", type: "uint256", value: "400"}, {name: "balance", type: "uint256", value: "394"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"150\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6634968", blockHash: "0xbd69676e4fdc1f909518e581ca70898f3fd888b49f9f0244bb5bd4780cf9afc5", timeStamp: "1541236978", hash: "0xdb65f6a5fca5e354aebad86b4b9def291ade72ae15fe4645c6842e5ced7b971d", nonce: "15", transactionIndex: "28", from: "0x62d41e56c017609df9095ce8c105228ec64651e0", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75265", gasPrice: "8000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000009600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015d3ef7980000000000000000000000000000000000000000000000000000000000007480120000000000000000000000000000000000000000000000000000000e3a13788d", contractAddress: "", cumulativeGasUsed: "7359151", txreceipt_status: "1", gasUsed: "50177", confirmations: "1099839", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "150"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "1500000000000"}, {type: "uint256", name: "expires", value: "7634962"}, {type: "uint256", name: "nonce", value: "61103896717"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "150", addressList[0], "1500000000000", "7634962", "61103896717", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541236978 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "150"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "1500000000000"}, {name: "expires", type: "uint256", value: "7634962"}, {name: "nonce", type: "uint256", value: "61103896717"}, {name: "user", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3411733289975900" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"188\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6634968", blockHash: "0xbd69676e4fdc1f909518e581ca70898f3fd888b49f9f0244bb5bd4780cf9afc5", timeStamp: "1541236978", hash: "0x5d42bd11370b045d0367a901ea0db5f0540d98976745fa4831f1bb173c9c8145", nonce: "5", transactionIndex: "30", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75265", gasPrice: "8000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000bc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000088c9ba93000000000000000000000000000000000000000000000000000000000000072f5800000000000000000000000000000000000000000000000000000001264dff942", contractAddress: "", cumulativeGasUsed: "7430328", txreceipt_status: "1", gasUsed: "50177", confirmations: "1099839", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "188"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "9400000000000"}, {type: "uint256", name: "expires", value: "7533952"}, {type: "uint256", name: "nonce", value: "79001811266"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "188", addressList[0], "9400000000000", "7533952", "79001811266", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541236978 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "188"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "9400000000000"}, {name: "expires", type: "uint256", value: "7533952"}, {name: "nonce", type: "uint256", value: "79001811266"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: deposit(  )", async function( ) {
		const txOriginal = {blockNumber: "6634988", blockHash: "0x1da3f14e213041e7f44fdb9478ac638a1fbc23de2d04791d93445029e2ad46ec", timeStamp: "1541237286", hash: "0xaee8fe1d2fdff880cad1a64334165fc103ff016299839793fe7bdbf2da877eea", nonce: "6", transactionIndex: "111", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "10000000000000000", gas: "55140", gasPrice: "7000000000", input: "0xd0e30db0", contractAddress: "", cumulativeGasUsed: "5543561", txreceipt_status: "1", gasUsed: "36760", confirmations: "1099819", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541237286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: false, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "balance", type: "uint256", value: "20000000000000000"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"211\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6634998", blockHash: "0x194f7f1ffb7dd3ce4950795ab3fe9e64b808174bcd14d59e57a32baf827d4ff3", timeStamp: "1541237414", hash: "0xc7e3f4ee2c3933f10826bca8664d7fc4682c122e20782daa5db5225d6bd5e3f5", nonce: "7", transactionIndex: "62", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75265", gasPrice: "5434285714", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000d30000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007ad1733b000000000000000000000000000000000000000000000000000000000000072f59a0000000000000000000000000000000000000000000000000000001634d86419", contractAddress: "", cumulativeGasUsed: "7067181", txreceipt_status: "1", gasUsed: "50177", confirmations: "1099809", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "211"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "8440000000000"}, {type: "uint256", name: "expires", value: "7533978"}, {type: "uint256", name: "nonce", value: "95375877145"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "211", addressList[0], "8440000000000", "7533978", "95375877145", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541237414 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "211"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "8440000000000"}, {name: "expires", type: "uint256", value: "7533978"}, {name: "nonce", type: "uint256", value: "95375877145"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: trade( addressList[5], \"150\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6635023", blockHash: "0xd9553dcbcd252d9f198fcfa0e0505fd75cd0babf9613129cdb2547a4524cb4b2", timeStamp: "1541237851", hash: "0x651d4310cecb4aaf9284e394b7024b38c422bfb7a15bad6a37e0942c2707b7c2", nonce: "8", transactionIndex: "32", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "125772", gasPrice: "5000000000", input: "0x0a19b14a000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000009600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015d3ef7980000000000000000000000000000000000000000000000000000000000007480120000000000000000000000000000000000000000000000000000000e3a13788d00000000000000000000000062d41e56c017609df9095ce8c105228ec64651e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000096", contractAddress: "", cumulativeGasUsed: "4197477", txreceipt_status: "1", gasUsed: "83848", confirmations: "1099784", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "150"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "1500000000000"}, {type: "uint256", name: "expires", value: "7634962"}, {type: "uint256", name: "nonce", value: "61103896717"}, {type: "address", name: "user", value: addressList[7]}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "amount", value: "150"}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32,uint256)" ]( addressList[5], "150", addressList[0], "1500000000000", "7634962", "61103896717", addressList[7], "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "150", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541237851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "get", type: "address"}, {indexed: false, name: "give", type: "address"}], name: "Trade", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Trade", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "150"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "1500000000000"}, {name: "get", type: "address", value: "0x62d41e56c017609df9095ce8c105228ec64651e0"}, {name: "give", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"235\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6635029", blockHash: "0x03c803d9a0316914ec79ef7e0275ddead661044deb0c7d678893eec0c45cdb11", timeStamp: "1541237907", hash: "0xe7e369d0fc0c97a750df69479ad147d342a85109aaae50fd94fdea300d4fcda9", nonce: "9", transactionIndex: "150", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75169", gasPrice: "8000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000eb0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004464dd4980000000000000000000000000000000000000000000000000000000000007480530000000000000000000000000000000000000000000000000000000db42c7b00", contractAddress: "", cumulativeGasUsed: "7877423", txreceipt_status: "1", gasUsed: "50113", confirmations: "1099778", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "235"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "4700000000000"}, {type: "uint256", name: "expires", value: "7635027"}, {type: "uint256", name: "nonce", value: "58857388800"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "235", addressList[0], "4700000000000", "7635027", "58857388800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541237907 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "235"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "4700000000000"}, {name: "expires", type: "uint256", value: "7635027"}, {name: "nonce", type: "uint256", value: "58857388800"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: trade( addressList[5], \"390\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6635032", blockHash: "0x080a1f16d34c57de5db541e31ec591e1126f6e2b7475b9349f7923aa15190b1d", timeStamp: "1541237999", hash: "0xdd894b3de97e31f174c7071fbc78d4bd65ca308a3acc9cbc361fff0f2ad87238", nonce: "10", transactionIndex: "160", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "103368", gasPrice: "8000000000", input: "0x0a19b14a000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000001860000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011bc3292b8000000000000000000000000000000000000000000000000000000000000747fc900000000000000000000000000000000000000000000000000000006a05bd81c00000000000000000000000059a2fe695011542c1a2c2ab546a279c739f603370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000070", contractAddress: "", cumulativeGasUsed: "6811658", txreceipt_status: "1", gasUsed: "68912", confirmations: "1099775", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "390"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "19500000000000"}, {type: "uint256", name: "expires", value: "7634889"}, {type: "uint256", name: "nonce", value: "28460177436"}, {type: "address", name: "user", value: addressList[6]}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "amount", value: "112"}], name: "trade", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "trade(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32,uint256)" ]( addressList[5], "390", addressList[0], "19500000000000", "7634889", "28460177436", addressList[6], "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "112", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541237999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "get", type: "address"}, {indexed: false, name: "give", type: "address"}], name: "Trade", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Trade", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "112"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "5600000000000"}, {name: "get", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}, {name: "give", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"367\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6635033", blockHash: "0x2a1c42994b444a928193302ff4852d047ada462bc010df365456424388723a03", timeStamp: "1541238006", hash: "0xbe1dc97b776552d66aa79736e8736cc2e85f3c806f48915a48590445423de5bb", nonce: "30", transactionIndex: "42", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "7000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000016f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003567d0bdc00000000000000000000000000000000000000000000000000000000000072f5c3000000000000000000000000000000000000000000000000000000157367737a", contractAddress: "", cumulativeGasUsed: "5674355", txreceipt_status: "1", gasUsed: "50241", confirmations: "1099774", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "367"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "3670000000000"}, {type: "uint256", name: "expires", value: "7534019"}, {type: "uint256", name: "nonce", value: "92130472826"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "367", addressList[0], "3670000000000", "7534019", "92130472826", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541238006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "367"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "3670000000000"}, {name: "expires", type: "uint256", value: "7534019"}, {name: "nonce", type: "uint256", value: "92130472826"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"120\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6635061", blockHash: "0x8883efada508fd2e50100ec67a0a3e9def367acef35e30ced7dd9ce3efa46343", timeStamp: "1541238315", hash: "0xd7f584135ea8cb7305f5cbad54412eb5ea646ae049667f49c2c21c273745e971", nonce: "11", transactionIndex: "121", from: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75265", gasPrice: "9000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000007800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034630b8a000000000000000000000000000000000000000000000000000000000000072f5e000000000000000000000000000000000000000000000000000000001c097a1d6", contractAddress: "", cumulativeGasUsed: "7060895", txreceipt_status: "1", gasUsed: "50177", confirmations: "1099746", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "120"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "3600000000000"}, {type: "uint256", name: "expires", value: "7534048"}, {type: "uint256", name: "nonce", value: "7526130134"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "120", addressList[0], "3600000000000", "7534048", "7526130134", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541238315 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "120"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "3600000000000"}, {name: "expires", type: "uint256", value: "7534048"}, {name: "nonce", type: "uint256", value: "7526130134"}, {name: "user", type: "address", value: "0xe35ffb3752f6fb15a07ecfa8a1bb65ec51029718"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "452269785728622" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"211\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6635106", blockHash: "0x4255378f140e569619ae79d8dfb665bc9b8551a7b980d79d1bfca0d7e6de92fb", timeStamp: "1541239043", hash: "0xc7503da3ed0759b1abe0c833344102cf880d308483c44924422730290a641513", nonce: "31", transactionIndex: "97", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75361", gasPrice: "5000000000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b900000000000000000000000000000000000000000000000000000000000000d30000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007ad1733b0000000000000000000000000000000000000000000000000000000000005c0fe3c000000000000000000000000000000000000000000000000000000068607352e", contractAddress: "", cumulativeGasUsed: "6950946", txreceipt_status: "1", gasUsed: "50241", confirmations: "1099701", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "211"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "8440000000000"}, {type: "uint256", name: "expires", value: "96534076"}, {type: "uint256", name: "nonce", value: "28018423086"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "211", addressList[0], "8440000000000", "96534076", "28018423086", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541239043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "211"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "8440000000000"}, {name: "expires", type: "uint256", value: "96534076"}, {name: "nonce", type: "uint256", value: "28018423086"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: order( addressList[5], \"123\", addressList[0],... )", async function( ) {
		const txOriginal = {blockNumber: "6635110", blockHash: "0x65144c3bdfce10415c7a33bb8bcc1337a7d3f63cc0ba44ca0b69b0b7082b4c54", timeStamp: "1541239073", hash: "0x835da56562c3d143bf9e832ae65e8a4dc36e16da3fdc0dd5bdec02dbc9feb245", nonce: "32", transactionIndex: "32", from: "0x59a2fe695011542c1a2c2ab546a279c739f60337", to: "0xf61a285edf078536a410a5fbc28013f9660e54a8", value: "0", gas: "75265", gasPrice: "4281250000", input: "0x0b927666000000000000000000000000a3114b268ff4327525fbc0dd5c48e0b4304d07b9000000000000000000000000000000000000000000000000000000000000007b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006b64a474800000000000000000000000000000000000000000000000000000000000072f5fe0000000000000000000000000000000000000000000000000000000aa32a2b8e", contractAddress: "", cumulativeGasUsed: "4901932", txreceipt_status: "1", gasUsed: "50177", confirmations: "1099697", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenGet", value: addressList[5]}, {type: "uint256", name: "amountGet", value: "123"}, {type: "address", name: "tokenGive", value: addressList[0]}, {type: "uint256", name: "amountGive", value: "7380000000000"}, {type: "uint256", name: "expires", value: "7534078"}, {type: "uint256", name: "nonce", value: "45687122830"}], name: "order", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "order(address,uint256,address,uint256,uint256,uint256)" ]( addressList[5], "123", addressList[0], "7380000000000", "7534078", "45687122830", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541239073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenGet", type: "address"}, {indexed: false, name: "amountGet", type: "uint256"}, {indexed: false, name: "tokenGive", type: "address"}, {indexed: false, name: "amountGive", type: "uint256"}, {indexed: false, name: "expires", type: "uint256"}, {indexed: false, name: "nonce", type: "uint256"}, {indexed: false, name: "user", type: "address"}], name: "Order", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Order", events: [{name: "tokenGet", type: "address", value: "0xa3114b268ff4327525fbc0dd5c48e0b4304d07b9"}, {name: "amountGet", type: "uint256", value: "123"}, {name: "tokenGive", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amountGive", type: "uint256", value: "7380000000000"}, {name: "expires", type: "uint256", value: "7534078"}, {name: "nonce", type: "uint256", value: "45687122830"}, {name: "user", type: "address", value: "0x59a2fe695011542c1a2c2ab546a279c739f60337"}], address: "0xf61a285edf078536a410a5fbc28013f9660e54a8"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "72293368672033832" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "686402000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
