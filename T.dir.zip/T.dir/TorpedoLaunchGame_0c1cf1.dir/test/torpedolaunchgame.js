const TorpedoLaunchGame = artifacts.require( "./TorpedoLaunchGame.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TorpedoLaunchGame" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xDeF439cB500CFbA0b66D29592776cB2df40c1Cf1", "0x8942a5995bd168f347F7Ec58F25a54A9a064F882", "0xf77444cE64f3F46ba6b63F6b9411dF9c589E3319", "0x8F7C64C3068c95B26cC9472771cb108bFa45b7fB", "0x05cFB777df05B06Bb3e479AA8210C8C956c4458c", "0x5Fb7a1Ca8F72dF631174d6c1cAa8b19a731C2Fba", "0x8Da4F82Dc4D03c5421BB2087F858750c650d8571", "0xAeC539A116fa75E8BdcF016D3C146a25bC1af93b", "0x20CA0D6FE51d06946f5cC90F9F4f297D398dD6DB", "0xa42015Da9E346E4c9F2CA5bB71b9D1a885810713"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "view_get_Treasure", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_maintenanceMode", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_gameStates", outputs: [{name: "grnd", type: "uint256"}, {name: "turnround", type: "uint32"}, {name: "minimumshare", type: "uint256"}, {name: "blockNumber", type: "uint256"}, {name: "blockNumberTimeout", type: "uint256"}, {name: "blockNumberCurrent", type: "uint256"}, {name: "blockTimeAvg", type: "uint256"}, {name: "highscores", type: "uint32[8]"}, {name: "addresses", type: "address[8]"}, {name: "names", type: "bytes32[8]"}, {name: "myname", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_player", type: "address"}], name: "view_get_registeredNames", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "signerAuthority", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_gameHighScores", outputs: [{name: "highscores", type: "uint32[8]"}, {name: "addresses", type: "address[8]"}, {name: "names", type: "bytes32[8]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_Gains", outputs: [{name: "gains", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_gameData", outputs: [{name: "sharePrice", type: "uint256"}, {name: "sharePots", type: "uint256"}, {name: "shareSupply", type: "uint256"}, {name: "shareEthBalance", type: "uint256"}, {name: "totalPlayers", type: "uint32"}, {name: "shares", type: "uint256"}, {name: "treasureSupply", type: "uint256"}, {name: "torpedoBatchID", type: "uint256"}, {name: "torpedoBatchMultiplier", type: "uint32"}, {name: "torpedoBatchBlockTimeout", type: "uint256"}, {name: "score", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_ResultData", outputs: [{name: "TotalPlayer", type: "uint32"}, {name: "TotalPayout", type: "uint256"}, {name: "MyTokenValue", type: "uint256"}, {name: "MyToken", type: "uint256"}, {name: "MyGains", type: "uint256"}, {name: "MyScore", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_blockNumbers", outputs: [{name: "b1", type: "uint256"}, {name: "b2", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "view_get_gameTorpedoData", outputs: [{name: "torpedoBatchID", type: "uint256"}, {name: "torpedoBatchMultiplier", type: "uint32"}, {name: "torpedoBatchBlockTimeout", type: "uint256"}, {name: "score", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "previousOwner", type: "address"}, {indexed: false, name: "nextOwner", type: "address"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "previous", type: "address"}, {indexed: false, name: "next", type: "address"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "HDXcontractChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdrawGains", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumber", type: "uint256"}], name: "onNewCampaign", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "mode", type: "bool"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onMaintenance", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}], name: "onCloseEntry", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "blocktimeavg", type: "uint256"}], name: "onChangeBlockTimeAverage", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "minimum", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onChangeMinimumPrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["OwnershipTransferred(address,address,uint256)", "HDXcontractChanged(address,address,uint256)", "onWithdrawGains(address,uint256,uint256)", "onNewScore(uint256,uint256,uint256,address,bool,bool)", "onNewCampaign(uint256,uint256)", "onBuyTorpedo(address,uint256,uint256,uint256,uint256,uint32)", "onMaintenance(bool,uint256)", "onCloseEntry(uint256)", "onChangeBlockTimeAverage(uint256)", "onChangeMinimumPrice(uint256,uint256)", "onNewName(address,bytes32,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc13a1166d81cd3b0b352a367aebab95f3a6f6bc695fdab8e9a9d335239c3861b", "0x87ab77b91a9a6a5a04a748607e0ee38d580963c4e21fe45d2e79ffeef26bc55e", "0x8ea11b70a47e5aaa4024df0985799a384faaaf34e6da0aadbadcae0fbfca45ac", "0x2628150fa1da4e0b851fdaa0287546130f9fd453be51323b489a81f6c4bf0067", "0xae4bf3465111e7661119cb02fb9f8d726b606da9622ebcd75cabb5d611a0d04b", "0x5ac0b4edd12a08f65800ba1acbf27d7c2be5f7c546be8a7406ac44db6a2cc29f", "0xb04e455982e111d37c1d6ff02f82a465d673bb8931f9595e16b3aaf421001e56", "0x4eb04f9aed2df935e25cbec04051b51a0d2dedf786d3ef9ef4cfcb717ff8115f", "0x6c1cf48245a0a91e114596b04dfcbe443303e5f72fab6771794891112fe4395f", "0x96aff3d0ee4748c300128c53ba5612b8363232b00ab841ce27937cd52c8e0f28", "0xcf9e039b89f14b39579de014cbb7196367b18bd199b38836c8f1177d72de3f10"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6786777 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6790326 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "TorpedoLaunchGame", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "view_get_Treasure", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_Treasure()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_maintenanceMode", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_maintenanceMode()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_gameStates", outputs: [{name: "grnd", type: "uint256"}, {name: "turnround", type: "uint32"}, {name: "minimumshare", type: "uint256"}, {name: "blockNumber", type: "uint256"}, {name: "blockNumberTimeout", type: "uint256"}, {name: "blockNumberCurrent", type: "uint256"}, {name: "blockTimeAvg", type: "uint256"}, {name: "highscores", type: "uint32[8]"}, {name: "addresses", type: "address[8]"}, {name: "names", type: "bytes32[8]"}, {name: "myname", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_gameStates()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "view_get_registeredNames", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_registeredNames(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "signerAuthority", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "signerAuthority()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalEthereumBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_gameHighScores", outputs: [{name: "highscores", type: "uint32[8]"}, {name: "addresses", type: "address[8]"}, {name: "names", type: "bytes32[8]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_gameHighScores()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_Gains", outputs: [{name: "gains", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_Gains()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_gameData", outputs: [{name: "sharePrice", type: "uint256"}, {name: "sharePots", type: "uint256"}, {name: "shareSupply", type: "uint256"}, {name: "shareEthBalance", type: "uint256"}, {name: "totalPlayers", type: "uint32"}, {name: "shares", type: "uint256"}, {name: "treasureSupply", type: "uint256"}, {name: "torpedoBatchID", type: "uint256"}, {name: "torpedoBatchMultiplier", type: "uint32"}, {name: "torpedoBatchBlockTimeout", type: "uint256"}, {name: "score", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_gameData()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_ResultData", outputs: [{name: "TotalPlayer", type: "uint32"}, {name: "TotalPayout", type: "uint256"}, {name: "MyTokenValue", type: "uint256"}, {name: "MyToken", type: "uint256"}, {name: "MyGains", type: "uint256"}, {name: "MyScore", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_ResultData()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_blockNumbers", outputs: [{name: "b1", type: "uint256"}, {name: "b2", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_blockNumbers()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "view_get_gameTorpedoData", outputs: [{name: "torpedoBatchID", type: "uint256"}, {name: "torpedoBatchMultiplier", type: "uint32"}, {name: "torpedoBatchBlockTimeout", type: "uint256"}, {name: "score", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "view_get_gameTorpedoData()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TorpedoLaunchGame", function( accounts ) {

	it( "TEST: TorpedoLaunchGame(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6786777", blockHash: "0x7f45efe5de1b99096f1df97dff0c7016d4785357cbe2ae1e2be8f0b39a4268d1", timeStamp: "1543387942", hash: "0x107bcf1115f971ac3d7c6b1aa309708bc61d8d95de7bb1d82d83bf5b1348f1c0", nonce: "46", transactionIndex: "44", from: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb", to: 0, value: "0", gas: "3186633", gasPrice: "4000000000", input: "0xe882eeba", contractAddress: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", cumulativeGasUsed: "5319441", txreceipt_status: "1", gasUsed: "3186633", confirmations: "916030", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "TorpedoLaunchGame", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TorpedoLaunchGame.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543387942 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TorpedoLaunchGame.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "353955403563190423" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: initCampaign(  )", async function( ) {
		const txOriginal = {blockNumber: "6786925", blockHash: "0xff5f81972d20c709063f960a76c1733dad7ef8c42a96d49053618af5cdb40d8e", timeStamp: "1543390053", hash: "0xd116cb56876ba97120cffcad2cf518c0f77535638b6617c4cb7442f0fdcab8f7", nonce: "48", transactionIndex: "78", from: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "300000", gasPrice: "16000000000", input: "0xea27e845", contractAddress: "", cumulativeGasUsed: "3255460", txreceipt_status: "1", gasUsed: "126226", confirmations: "915882", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "initCampaign", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initCampaign()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543390053 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumber", type: "uint256"}], name: "onNewCampaign", type: "event"} ;
		console.error( "eventCallOriginal[1,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewCampaign", events: [{name: "gRND", type: "uint256", value: "1"}, {name: "blockNumber", type: "uint256", value: "6786925"}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[1,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "353955403563190423" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: initCampaign(  )", async function( ) {
		const txOriginal = {blockNumber: "6786981", blockHash: "0x0a485999eb8d4acbd7d1ca9e0a5050d8e12b3aa53207eb42f732f44567e79d49", timeStamp: "1543390811", hash: "0xa973afc8938d3cfb3668f73c92776210e70f5c8038d88fb2e3fbb06aac45e1e7", nonce: "49", transactionIndex: "178", from: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "300000", gasPrice: "19000000000", input: "0xea27e845", contractAddress: "", cumulativeGasUsed: "4204072", txreceipt_status: "1", gasUsed: "111226", confirmations: "915826", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "initCampaign", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initCampaign()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543390811 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumber", type: "uint256"}], name: "onNewCampaign", type: "event"} ;
		console.error( "eventCallOriginal[2,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewCampaign", events: [{name: "gRND", type: "uint256", value: "2"}, {name: "blockNumber", type: "uint256", value: "6786981"}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[2,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "353955403563190423" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: ChargeTreasure(  )", async function( ) {
		const txOriginal = {blockNumber: "6787036", blockHash: "0xc84a22871c62963e50ec33d7eacfbb6a6cb6ee65d5928e8e30cfe00aade26d5a", timeStamp: "1543391669", hash: "0x8bb783171841ff6131f1e6397a3373dc0b6bc1553012f0e001b71db1e196c3e1", nonce: "50", transactionIndex: "93", from: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "1000000000000000000", gas: "42249", gasPrice: "9000000000", input: "0xfee13823", contractAddress: "", cumulativeGasUsed: "3698373", txreceipt_status: "1", gasUsed: "42249", confirmations: "915771", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "ChargeTreasure", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ChargeTreasure()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543391669 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "353955403563190423" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: initCampaign(  )", async function( ) {
		const txOriginal = {blockNumber: "6787040", blockHash: "0x8289fde544b9c6621532092a84890ea70b8f03a227758290a2ba8c44f29595b2", timeStamp: "1543391748", hash: "0x3fd1b403c793d23af72818f883de7ac4b88012d9d8fec6611be77c2183d8cb65", nonce: "51", transactionIndex: "124", from: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "300000", gasPrice: "16000000000", input: "0xea27e845", contractAddress: "", cumulativeGasUsed: "6509936", txreceipt_status: "1", gasUsed: "141328", confirmations: "915767", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "initCampaign", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initCampaign()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543391748 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumber", type: "uint256"}], name: "onNewCampaign", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewCampaign", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumber", type: "uint256", value: "6787040"}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "353955403563190423" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6787125", blockHash: "0xe656843ba0dae5ef1a242a968a92a9744b08bbf9326c5f3e6d7ee9b60c13d99d", timeStamp: "1543393119", hash: "0x4b183a4d904e115bcd927a71eaf5e76c99cfc0b921a02a4417077cf2ac3fee87", nonce: "52", transactionIndex: "86", from: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "503565", gasPrice: "8000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6639192", txreceipt_status: "1", gasUsed: "335710", confirmations: "915682", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543393119 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "55231314608070701823380091384486515649039606193203487773177158320370078002638"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6788085"}, {name: "nbToken", type: "uint256", value: "351878097498963708"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "353955403563190423" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"2655\", \"5523131460807070182338009138... )", async function( ) {
		const txOriginal = {blockNumber: "6787147", blockHash: "0xa6efc87716d4c94f588f7ec37e48b458eb5e77bdf21ccf31f7fd413b0d49fcf5", timeStamp: "1543393366", hash: "0xda30ed9c4e71daf52b7b9d4e65608db8f45778f319e3c71dfa85cd1c57ed7c1c", nonce: "53", transactionIndex: "19", from: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "167070", gasPrice: "11000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000a5f7a1bd0f68c4ee35967dd4a2b203f26b31aae3ef2c81f1dcd809bd9c91f792dce2aecbfc47bff223cfdcc38bf577fc163aeaff0126ee6dcf00affd2d4663344c0018e4d107b13d3778961a5cd1aaf29b579eccf4f95d8c7c898fd1f68cd62dcc6000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "1098274", txreceipt_status: "1", gasUsed: "96380", confirmations: "915660", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "2655"}, {type: "uint256", name: "torpedoBatchID", value: "55231314608070701823380091384486515649039606193203487773177158320370078002638"}, {type: "bytes32", name: "r", value: "0x2aecbfc47bff223cfdcc38bf577fc163aeaff0126ee6dcf00affd2d4663344c0"}, {type: "bytes32", name: "s", value: "0x018e4d107b13d3778961a5cd1aaf29b579eccf4f95d8c7c898fd1f68cd62dcc6"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "2655", "55231314608070701823380091384486515649039606193203487773177158320370078002638", "0x2aecbfc47bff223cfdcc38bf577fc163aeaff0126ee6dcf00affd2d4663344c0", "0x018e4d107b13d3778961a5cd1aaf29b579eccf4f95d8c7c898fd1f68cd62dcc6", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543393366 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6792907"}, {name: "score", type: "uint256", value: "2655"}, {name: "customerAddress", type: "address", value: "0x8f7c64c3068c95b26cc9472771cb108bfa45b7fb"}, {name: "newHighScore", type: "bool", value: true}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "353955403563190423" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6787363", blockHash: "0xf8b9a7f5d065c2855839d810277f93fd672d818411509e8d9190026bf089704b", timeStamp: "1543396564", hash: "0x19d43f9194b6037c49e633eb8e1dd88198f1d590a5fcaa4d61cadd7c5370b0c9", nonce: "604", transactionIndex: "67", from: "0x05cfb777df05b06bb3e479aa8210c8c956c4458c", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "397993", gasPrice: "9600000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6623167", txreceipt_status: "1", gasUsed: "265329", confirmations: "915444", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543396564 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x05cfb777df05b06bb3e479aa8210c8c956c4458c"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "99253856266946708156285261474423265905587683176013928869262058967103886805593"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6788323"}, {name: "nbToken", type: "uint256", value: "351360114293237425"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96891230424468778" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1140\", \"9925385626694670815628526147... )", async function( ) {
		const txOriginal = {blockNumber: "6787385", blockHash: "0x6c5bb37f80616151cc6a785e600083f28c7b7dcb60826ad43aab537c25f31377", timeStamp: "1543396907", hash: "0xcafb91b181292748cef3e6d7c83c9862805af03a3b319a58138bb2ced8d43c50", nonce: "605", transactionIndex: "89", from: "0x05cfb777df05b06bb3e479aa8210c8c956c4458c", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "106149", gasPrice: "8000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000474db6fb11d72b2bf05d4bcea14342957a29d74668291cf7a830d7018382e134a5994f48fc17b7e63c9db6c419fe591317089318d67b4e147d72594391190ede58545842e2621cdd2acc8c85661c127570b796eec639b8b48b4e8c52d3de598a502000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "4624235", txreceipt_status: "1", gasUsed: "55766", confirmations: "915422", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1140"}, {type: "uint256", name: "torpedoBatchID", value: "99253856266946708156285261474423265905587683176013928869262058967103886805593"}, {type: "bytes32", name: "r", value: "0x94f48fc17b7e63c9db6c419fe591317089318d67b4e147d72594391190ede585"}, {type: "bytes32", name: "s", value: "0x45842e2621cdd2acc8c85661c127570b796eec639b8b48b4e8c52d3de598a502"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1140", "99253856266946708156285261474423265905587683176013928869262058967103886805593", "0x94f48fc17b7e63c9db6c419fe591317089318d67b4e147d72594391190ede585", "0x45842e2621cdd2acc8c85661c127570b796eec639b8b48b4e8c52d3de598a502", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543396907 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6792907"}, {name: "score", type: "uint256", value: "1140"}, {name: "customerAddress", type: "address", value: "0x05cfb777df05b06bb3e479aa8210c8c956c4458c"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96891230424468778" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6787906", blockHash: "0x7346686009c79e0090a641b3aae3eb53751095fbadc8a2e5a80025c1621ec58f", timeStamp: "1543404347", hash: "0x1bb62aed72355abbfb51906ce2f30869330ff17d409662bd7a5a16c104e96260", nonce: "113", transactionIndex: "27", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "100000000000000000", gas: "398322", gasPrice: "6000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2956892", txreceipt_status: "1", gasUsed: "265548", confirmations: "914901", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543404347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "39200226758225844244669735748941557393005097718931082610303775029539614946971"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6788866"}, {name: "nbToken", type: "uint256", value: "3512570458983093205"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 1, c: [10]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"2290\", \"3920022675822584424466973574... )", async function( ) {
		const txOriginal = {blockNumber: "6787933", blockHash: "0x4b7b8df10290ea1991e1538acea30af1ae00d531bf1790c82de73ad0e9bcea47", timeStamp: "1543404694", hash: "0x0e920e1bf9a49f95081093bc5091169fed0280ed617099f53842375cdcccf020", nonce: "114", transactionIndex: "123", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "122382", gasPrice: "10000000000", input: "0x4af0616a00000000000000000000000000000000000000000000000000000000000008f256aa8ac5ffe1286f268556380e3b829f95e13559c8d3d30bedaba698f1caf69bb50eeaf897e0e7af5f5e7c4f8c4f7b9ef23121e01a5d46abb3bdaf320d7129dd5a6efc37e392da22fa48486fde20628aeadc4084b12dca5f53ca2c8c88dbf18c000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "7333974", txreceipt_status: "1", gasUsed: "66588", confirmations: "914874", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "2290"}, {type: "uint256", name: "torpedoBatchID", value: "39200226758225844244669735748941557393005097718931082610303775029539614946971"}, {type: "bytes32", name: "r", value: "0xb50eeaf897e0e7af5f5e7c4f8c4f7b9ef23121e01a5d46abb3bdaf320d7129dd"}, {type: "bytes32", name: "s", value: "0x5a6efc37e392da22fa48486fde20628aeadc4084b12dca5f53ca2c8c88dbf18c"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "2290", "39200226758225844244669735748941557393005097718931082610303775029539614946971", "0xb50eeaf897e0e7af5f5e7c4f8c4f7b9ef23121e01a5d46abb3bdaf320d7129dd", "0x5a6efc37e392da22fa48486fde20628aeadc4084b12dca5f53ca2c8c88dbf18c", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543404694 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "22900"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: true}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788097", blockHash: "0xef2674699680894ba8a9fd846a63a05d00bb9a8099065f0afad3c97aaef45ac1", timeStamp: "1543406881", hash: "0x12d1c10a76f4fcbedbc944e5621c590cb6dab2cdfd9843d9d7f47e7a9615375a", nonce: "115", transactionIndex: "121", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "6000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6308962", txreceipt_status: "1", gasUsed: "153523", confirmations: "914710", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543406881 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "22471663100965704328963389150630354115140834707197564299613186760397676066391"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789057"}, {name: "nbToken", type: "uint256", value: "351256883917280997"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"2010\", \"2247166310096570432896338915... )", async function( ) {
		const txOriginal = {blockNumber: "6788112", blockHash: "0x538daad6113d4b03545184b47c6b2c3a60ce7b621e9358c9f14476fe6ba49a2f", timeStamp: "1543407116", hash: "0xf145ed74287b8b267a2c93cdd72fe829598d9e5f99f3c4bf3dfee9beaa860da0", nonce: "116", transactionIndex: "110", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "98086", gasPrice: "5000000000", input: "0x4af0616a00000000000000000000000000000000000000000000000000000000000007da31ae82b5e71c4dc81fb199e1a8e6ff1bf4ee1c990e329d85fce2a30a6cebb6574d0db4ad3c2c11722b5c865432a08f92a58e14677d42e5ea754dd1aa85f5178b23bd34bff70de7ae122d143981449a5125c62cea1a4a4cc22c6ca55112999828000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "5617434", txreceipt_status: "1", gasUsed: "50391", confirmations: "914695", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "2010"}, {type: "uint256", name: "torpedoBatchID", value: "22471663100965704328963389150630354115140834707197564299613186760397676066391"}, {type: "bytes32", name: "r", value: "0x4d0db4ad3c2c11722b5c865432a08f92a58e14677d42e5ea754dd1aa85f5178b"}, {type: "bytes32", name: "s", value: "0x23bd34bff70de7ae122d143981449a5125c62cea1a4a4cc22c6ca55112999828"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "2010", "22471663100965704328963389150630354115140834707197564299613186760397676066391", "0x4d0db4ad3c2c11722b5c865432a08f92a58e14677d42e5ea754dd1aa85f5178b", "0x23bd34bff70de7ae122d143981449a5125c62cea1a4a4cc22c6ca55112999828", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543407116 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "24910"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: BuyName( \"0x5445524d494e41544f520000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788152", blockHash: "0xc91eae29440100e07e442e600ecf17e2caff5958169f6c93472253e9e6b508eb", timeStamp: "1543407740", hash: "0xf894f16d327ac598f95d8a3054409415516c71fdbe0400ba082b366ee3ce960a", nonce: "117", transactionIndex: "26", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "100000000000000000", gas: "168309", gasPrice: "6000000000", input: "0x576bcd3f5445524d494e41544f5200000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1777760", txreceipt_status: "1", gasUsed: "112206", confirmations: "914655", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "name", value: "0x5445524d494e41544f5200000000000000000000000000000000000000000000"}], name: "BuyName", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyName(bytes32)" ]( "0x5445524d494e41544f5200000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543407740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[13,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "name", type: "bytes32", value: "0x5445524d494e41544f5200000000000000000000000000000000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543407740"}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[13,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: WithdrawGains(  )", async function( ) {
		const txOriginal = {blockNumber: "6788197", blockHash: "0xd9e9cb5e1f8dfe6e75a503e72d6ac3c0d3695dbc9a8e92932fd41cb4d5f63a6c", timeStamp: "1543408381", hash: "0xdfd50ad77c46d4ed0da460aabdd2f1174422f1423f8ae6d0de0b6da0d06a8e92", nonce: "118", transactionIndex: "135", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "86629", gasPrice: "5000000000", input: "0xbd679ab2", contractAddress: "", cumulativeGasUsed: "7397106", txreceipt_status: "1", gasUsed: "55502", confirmations: "914610", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "WithdrawGains", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "WithdrawGains()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543408381 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdrawGains", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdrawGains", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "ethereumWithdrawn", type: "uint256", value: "22302752137334378"}, {name: "timeStamp", type: "uint256", value: "1543408381"}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788518", blockHash: "0x42dae7acb891dc703d31df8ca454e4bb1374e9d255042842b796457226157f1a", timeStamp: "1543413075", hash: "0x6f4934074a6818c76687021263589cb63731fec24781bf67a2b0c5fb2004108f", nonce: "3898", transactionIndex: "64", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "100000000000000000", gas: "398322", gasPrice: "12000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4273566", txreceipt_status: "1", gasUsed: "265548", confirmations: "914289", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543413075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "28098328511921776038955313236238585623159603436808310439362359019209379869168"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789478"}, {name: "nbToken", type: "uint256", value: "3512018056956194896"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 1, c: [10]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"830\", \"28098328511921776038955313236... )", async function( ) {
		const txOriginal = {blockNumber: "6788539", blockHash: "0x5315dba4ff10f513c86708ecb7fd4e0a69c6672cf9c1e86d944875a81a7369a9", timeStamp: "1543413363", hash: "0xdb3f41e40c6639be9d7f73c7c1a17d16e6b3fdff079f0a307066452d7e9a13f6", nonce: "3899", transactionIndex: "103", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "106332", gasPrice: "11000000000", input: "0x4af0616a000000000000000000000000000000000000000000000000000000000000033e3e1f172167913d2673c929266e4aebcd0ac2332c6efb0a1b9ab2725d4868f1f05126fd71b10459cd3481041a5e537e2a523b45d48ae96e05ba0eba8ea722a1677c109bb1d83c1ef7fd4b3c2c379f9ea9a782aa81dc8dda9c3da67f2a73e4d0ba000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "5865493", txreceipt_status: "1", gasUsed: "55888", confirmations: "914268", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "830"}, {type: "uint256", name: "torpedoBatchID", value: "28098328511921776038955313236238585623159603436808310439362359019209379869168"}, {type: "bytes32", name: "r", value: "0x5126fd71b10459cd3481041a5e537e2a523b45d48ae96e05ba0eba8ea722a167"}, {type: "bytes32", name: "s", value: "0x7c109bb1d83c1ef7fd4b3c2c379f9ea9a782aa81dc8dda9c3da67f2a73e4d0ba"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "830", "28098328511921776038955313236238585623159603436808310439362359019209379869168", "0x5126fd71b10459cd3481041a5e537e2a523b45d48ae96e05ba0eba8ea722a167", "0x7c109bb1d83c1ef7fd4b3c2c379f9ea9a782aa81dc8dda9c3da67f2a73e4d0ba", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543413363 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "8300"}, {name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: WithdrawGains(  )", async function( ) {
		const txOriginal = {blockNumber: "6788541", blockHash: "0x8545f7edf062303e605adf1038e90aebdbd41eb5f3980466578a251da11d8d6a", timeStamp: "1543413400", hash: "0xc622b4a0d3d2e31671d2b264d6f93d9b06cc4867d5da5df13422a0c105cfaa47", nonce: "3900", transactionIndex: "31", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "86629", gasPrice: "12000000000", input: "0xbd679ab2", contractAddress: "", cumulativeGasUsed: "1935495", txreceipt_status: "1", gasUsed: "55502", confirmations: "914266", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "WithdrawGains", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "WithdrawGains()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543413400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdrawGains", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdrawGains", events: [{name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "ethereumWithdrawn", type: "uint256", value: "20249272953884503"}, {name: "timeStamp", type: "uint256", value: "1543413400"}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788807", blockHash: "0xbc779da3ed93f41c9f5ba58bb2edbd29a6dc1fed4d85fd73ec73af40c1a6ce7b", timeStamp: "1543417298", hash: "0xd30617017003d42a4593dc2944baa6e428e5b42666ef1686250c6123356cb411", nonce: "119", transactionIndex: "98", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "8000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6651070", txreceipt_status: "1", gasUsed: "153523", confirmations: "914000", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543417298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "65976691999464292669166091430526166116027213349783589119181065550803820150632"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789767"}, {name: "nbToken", type: "uint256", value: "351201643792057078"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1280\", \"6597669199946429266916609143... )", async function( ) {
		const txOriginal = {blockNumber: "6788830", blockHash: "0x73cf77ba0168da2ac52ea8c010b9b2b55e3029723d64e4ef58746c631ef3c8c3", timeStamp: "1543417637", hash: "0x17cd73b24d3b105ebf36ad209e07dc007be850a7f6a099fbbb13fee02fd5eb57", nonce: "120", transactionIndex: "219", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "97990", gasPrice: "8000000000", input: "0x4af0616a000000000000000000000000000000000000000000000000000000000000050091dd7bfdaa0aad0713213fa0efa5db7a92ed9e96e907d71a24d2377bf384ff68c986f7f23d44cf399f31a22e62331aedf1c4142cc492d1594e05daddb3589e3d330383bb426e85879186af62a995dac5d6a8734e53b44d11f8892ebe800a2f4e000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "7334973", txreceipt_status: "1", gasUsed: "50327", confirmations: "913977", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1280"}, {type: "uint256", name: "torpedoBatchID", value: "65976691999464292669166091430526166116027213349783589119181065550803820150632"}, {type: "bytes32", name: "r", value: "0xc986f7f23d44cf399f31a22e62331aedf1c4142cc492d1594e05daddb3589e3d"}, {type: "bytes32", name: "s", value: "0x330383bb426e85879186af62a995dac5d6a8734e53b44d11f8892ebe800a2f4e"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1280", "65976691999464292669166091430526166116027213349783589119181065550803820150632", "0xc986f7f23d44cf399f31a22e62331aedf1c4142cc492d1594e05daddb3589e3d", "0x330383bb426e85879186af62a995dac5d6a8734e53b44d11f8892ebe800a2f4e", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543417637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "26190"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788848", blockHash: "0x859a255cd8727ec68c48f4f2edeeb8e8f54607c1297200633833643d3eb1bd01", timeStamp: "1543417921", hash: "0x6418e57828ee018b6b7fbac86820d325a6febd94f9e1072e077b426a7cc52765", nonce: "121", transactionIndex: "45", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "10000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2215033", txreceipt_status: "1", gasUsed: "153523", confirmations: "913959", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543417921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "70640240397899309335049367798474719236896118570522548946806121193263214754517"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789808"}, {name: "nbToken", type: "uint256", value: "351201627601732919"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1715\", \"7064024039789930933504936779... )", async function( ) {
		const txOriginal = {blockNumber: "6788864", blockHash: "0x8b227bc2dbedb14f3a93fa9fa7902dbdeb0eeebfdd148718654d5f35876fad33", timeStamp: "1543418260", hash: "0x47a1819658983ba12a350977c5332b161d6c8d3c3c12a34e08b44c19bc0a228b", nonce: "122", transactionIndex: "78", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "98086", gasPrice: "8000000000", input: "0x4af0616a00000000000000000000000000000000000000000000000000000000000006b39c2cf58db302d1ca78e9fe0d096321ab6f25355d848a459ce761dc7f5f2dfad5e4d32dcbcff66cd0aa27df3eec47ace43ed7d5e1d44bf488f70adbe4ecb14f5217d705e170608fdcc97d1c09464f7f061f4430cce04c123b9cc2445c06d3022a000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "7057140", txreceipt_status: "1", gasUsed: "50391", confirmations: "913943", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1715"}, {type: "uint256", name: "torpedoBatchID", value: "70640240397899309335049367798474719236896118570522548946806121193263214754517"}, {type: "bytes32", name: "r", value: "0xe4d32dcbcff66cd0aa27df3eec47ace43ed7d5e1d44bf488f70adbe4ecb14f52"}, {type: "bytes32", name: "s", value: "0x17d705e170608fdcc97d1c09464f7f061f4430cce04c123b9cc2445c06d3022a"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1715", "70640240397899309335049367798474719236896118570522548946806121193263214754517", "0xe4d32dcbcff66cd0aa27df3eec47ace43ed7d5e1d44bf488f70adbe4ecb14f52", "0x17d705e170608fdcc97d1c09464f7f061f4430cce04c123b9cc2445c06d3022a", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543418260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "27905"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788898", blockHash: "0xa1fe0b93ec1d14868ed4b41471cabae292ed404d1fa4a5a4d1c2f79b73d11a22", timeStamp: "1543418768", hash: "0x977575ea4564a0e49697b3bdabe591480e5eff04d9725a3e382656d97cdbaa48", nonce: "123", transactionIndex: "127", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "8000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6974954", txreceipt_status: "1", gasUsed: "153523", confirmations: "913909", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543418768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "60629326541353359194970411933616693901851750885761343254719403491083189738460"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789858"}, {name: "nbToken", type: "uint256", value: "351201611411434150"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788899", blockHash: "0x923205567eaed6762c58749d10b2c0d219b5b56b514e955603e933a4dd01ff53", timeStamp: "1543418771", hash: "0xb9b1ef1c20f2f7b09193e328885b35b1bd2ee2c9ac96a4ebb105c4fbe574a02d", nonce: "6686", transactionIndex: "26", from: "0xaec539a116fa75e8bdcf016d3c146a25bc1af93b", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "397993", gasPrice: "7000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6017634", txreceipt_status: "1", gasUsed: "265329", confirmations: "913908", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543418771 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0xaec539a116fa75e8bdcf016d3c146a25bc1af93b"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "72637829208226126741717401889716870628085349406068803624193597813278421866336"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789859"}, {name: "nbToken", type: "uint256", value: "351201595221160772"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1019230707980454800" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1380\", \"6062932654135335919497041193... )", async function( ) {
		const txOriginal = {blockNumber: "6788920", blockHash: "0x2dc6bedb99a86a78223d25d9439379b16811411b9fb35107bf800b8666f3b24c", timeStamp: "1543419035", hash: "0x1f2c0685700073c2717048ce8bce54186b671362e4e8e4f08a635c37c7e83a44", nonce: "124", transactionIndex: "65", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "97990", gasPrice: "8000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000564860afb953136a4d421a78088921902ef384822b0992b3826c5796a223f2bdbdc43725f190d3e7494dd9213b07aef160b1bbb25e0f71ad75a30c6a9a5705100cf41903878f9634069f82750a8133de2c73068edfe23f7510577f3f9d692a007ef000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "3874908", txreceipt_status: "1", gasUsed: "50327", confirmations: "913887", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1380"}, {type: "uint256", name: "torpedoBatchID", value: "60629326541353359194970411933616693901851750885761343254719403491083189738460"}, {type: "bytes32", name: "r", value: "0x43725f190d3e7494dd9213b07aef160b1bbb25e0f71ad75a30c6a9a5705100cf"}, {type: "bytes32", name: "s", value: "0x41903878f9634069f82750a8133de2c73068edfe23f7510577f3f9d692a007ef"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1380", "60629326541353359194970411933616693901851750885761343254719403491083189738460", "0x43725f190d3e7494dd9213b07aef160b1bbb25e0f71ad75a30c6a9a5705100cf", "0x41903878f9634069f82750a8133de2c73068edfe23f7510577f3f9d692a007ef", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543419035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "29285"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"855\", \"72637829208226126741717401889... )", async function( ) {
		const txOriginal = {blockNumber: "6788948", blockHash: "0xbb9ec96935c930deed235601e6ea9dacaa42755407475161152a1df28fb24af6", timeStamp: "1543419378", hash: "0x8b75768152543850e574e42e62fb940925e1425670eef6e644ec84f590c540ef", nonce: "6687", transactionIndex: "101", from: "0xaec539a116fa75e8bdcf016d3c146a25bc1af93b", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "299833", gasPrice: "6000000000", input: "0x0908c7fa0000000000000000000000000000000000000000000000000000000000000357a0978decb7a41a80d0c638bb31e1ec6a66dfee5a72a5a66ed4cfd1c361bcd7600000000000000000000000000000000000000000000000000000000000000000e81ccbaef75ed59f22be29bef9738a8366907728b7589d7c25a5341fe89cf069478876e3686c4e41fccef4ca6d672b53185abbaf0b54c18712b84af764acf61d000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "5932734", txreceipt_status: "1", gasUsed: "184889", confirmations: "913859", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "855"}, {type: "uint256", name: "torpedoBatchID", value: "72637829208226126741717401889716870628085349406068803624193597813278421866336"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0xe81ccbaef75ed59f22be29bef9738a8366907728b7589d7c25a5341fe89cf069"}, {type: "bytes32", name: "s", value: "0x478876e3686c4e41fccef4ca6d672b53185abbaf0b54c18712b84af764acf61d"}, {type: "uint8", name: "v", value: "28"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "855", "72637829208226126741717401889716870628085349406068803624193597813278421866336", addressList[0], "0xe81ccbaef75ed59f22be29bef9738a8366907728b7589d7c25a5341fe89cf069", "0x478876e3686c4e41fccef4ca6d672b53185abbaf0b54c18712b84af764acf61d", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543419378 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "855"}, {name: "customerAddress", type: "address", value: "0xaec539a116fa75e8bdcf016d3c146a25bc1af93b"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0xaec539a116fa75e8bdcf016d3c146a25bc1af93b"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "50765012327503529396940832578299272063663848206922700914953466444652844249235"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789908"}, {name: "nbToken", type: "uint256", value: "351201579030912784"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1019230707980454800" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6788978", blockHash: "0x7cac352f372f302cce3494ef288c37e3210f61e6554d87f173f0f55ea3a48e97", timeStamp: "1543419846", hash: "0x0827056ce5fc618c13939ff9aed8b669cdfa8cde89e8b4f0ec41818112455375", nonce: "1896", transactionIndex: "49", from: "0x20ca0d6fe51d06946f5cc90f9f4f297d398dd6db", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "397993", gasPrice: "5010000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5672505", txreceipt_status: "1", gasUsed: "265329", confirmations: "913829", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543419846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x20ca0d6fe51d06946f5cc90f9f4f297d398dd6db"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "29165778396075385456283108862220296906069232569290631622602575609317711534460"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789938"}, {name: "nbToken", type: "uint256", value: "351201562840689929"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "58391971622198343" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1035\", \"5076501232750352939694083257... )", async function( ) {
		const txOriginal = {blockNumber: "6788989", blockHash: "0x9a57a8b98e1b3306803b3e4f70ae4daac86a256e6c5a53f962b6124f1ab36065", timeStamp: "1543419990", hash: "0xde0fe1abd7cea57aa257d2df943a69b2f8af731cb2821c87e5a65276e96ef15f", nonce: "6688", transactionIndex: "87", from: "0xaec539a116fa75e8bdcf016d3c146a25bc1af93b", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "97741", gasPrice: "10000000000", input: "0x4af0616a000000000000000000000000000000000000000000000000000000000000040b703bfa8fa6241e023d4a7638822d1265d50b080419ce6d15848948df06ad7093f03f6c8359e2c1e9a209e3a95b994e6294c2c381092ba551f1ea89aab3bfa39b08f308c71311774018f07a7ab41af211c63418dbc703877fb302977f4c012646000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "4082888", txreceipt_status: "1", gasUsed: "50161", confirmations: "913818", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1035"}, {type: "uint256", name: "torpedoBatchID", value: "50765012327503529396940832578299272063663848206922700914953466444652844249235"}, {type: "bytes32", name: "r", value: "0xf03f6c8359e2c1e9a209e3a95b994e6294c2c381092ba551f1ea89aab3bfa39b"}, {type: "bytes32", name: "s", value: "0x08f308c71311774018f07a7ab41af211c63418dbc703877fb302977f4c012646"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1035", "50765012327503529396940832578299272063663848206922700914953466444652844249235", "0xf03f6c8359e2c1e9a209e3a95b994e6294c2c381092ba551f1ea89aab3bfa39b", "0x08f308c71311774018f07a7ab41af211c63418dbc703877fb302977f4c012646", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543419990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "1890"}, {name: "customerAddress", type: "address", value: "0xaec539a116fa75e8bdcf016d3c146a25bc1af93b"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1019230707980454800" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"880\", \"29165778396075385456283108862... )", async function( ) {
		const txOriginal = {blockNumber: "6789008", blockHash: "0xb4773a1a2797acfe4519c8394bb7a4f6a618e218675c2f1b1778c5643be30a53", timeStamp: "1543420284", hash: "0x2be8f5175514a1988b2e91bbc7871fc0fc61dd5af56985ada428ddf634354f9a", nonce: "1897", transactionIndex: "52", from: "0x20ca0d6fe51d06946f5cc90f9f4f297d398dd6db", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "106332", gasPrice: "5010000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000370407b3ede29c05adfa62f329ed12ac46cd72fa03cc6bb8fe9b5afa4996081d97c5511d3536b8338b5cbd9eced0c3d9c9e37797c0311e172f8241ae334f2b9d69c5f04503a033bfec06e3b66c90d6cc3bb6e7efa42f39b14bafc663ddd33af7109000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "6583509", txreceipt_status: "1", gasUsed: "55888", confirmations: "913799", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "880"}, {type: "uint256", name: "torpedoBatchID", value: "29165778396075385456283108862220296906069232569290631622602575609317711534460"}, {type: "bytes32", name: "r", value: "0x5511d3536b8338b5cbd9eced0c3d9c9e37797c0311e172f8241ae334f2b9d69c"}, {type: "bytes32", name: "s", value: "0x5f04503a033bfec06e3b66c90d6cc3bb6e7efa42f39b14bafc663ddd33af7109"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "880", "29165778396075385456283108862220296906069232569290631622602575609317711534460", "0x5511d3536b8338b5cbd9eced0c3d9c9e37797c0311e172f8241ae334f2b9d69c", "0x5f04503a033bfec06e3b66c90d6cc3bb6e7efa42f39b14bafc663ddd33af7109", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543420284 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "880"}, {name: "customerAddress", type: "address", value: "0x20ca0d6fe51d06946f5cc90f9f4f297d398dd6db"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "58391971622198343" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789013", blockHash: "0xd3e48e84f891ece3ea33bb387ac66cc90be12d0a88e7b618c868b0c1b0530a5c", timeStamp: "1543420331", hash: "0x1a87194752997bd94ca9f03cc53c740231658e6b315f149c2f825b3f877ca584", nonce: "125", transactionIndex: "68", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "8000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5018728", txreceipt_status: "1", gasUsed: "153523", confirmations: "913794", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543420331 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "112438236559923020351274257995771908141939428581001738067456075377685908538458"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6789973"}, {name: "nbToken", type: "uint256", value: "351201546650492722"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"2165\", \"1124382365599230203512742579... )", async function( ) {
		const txOriginal = {blockNumber: "6789035", blockHash: "0xcbf30ec5f94d8b2c8d4c3328d38b13da11c7c326f4ebb53df7b7756978fa2f62", timeStamp: "1543420617", hash: "0xc05d080e5d39d270db57bc0c0a3ebc8edbd2dd676169b4ce67bc3d4b32b48985", nonce: "126", transactionIndex: "82", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "98140", gasPrice: "8000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000875f895c9623483e5a82d7e7969b81bf1de241833a40c27bd3c9b11c938d891c45a4d54403147e84f0cfff4dccb1a7eb85737e1c23c10a62b5ad790663621c7cf182ee1b8c5257084c9ed6fbc0a148921e02a35f5de9f6405516c63c87037abb299000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "5296145", txreceipt_status: "1", gasUsed: "50427", confirmations: "913772", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "2165"}, {type: "uint256", name: "torpedoBatchID", value: "112438236559923020351274257995771908141939428581001738067456075377685908538458"}, {type: "bytes32", name: "r", value: "0x4d54403147e84f0cfff4dccb1a7eb85737e1c23c10a62b5ad790663621c7cf18"}, {type: "bytes32", name: "s", value: "0x2ee1b8c5257084c9ed6fbc0a148921e02a35f5de9f6405516c63c87037abb299"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "2165", "112438236559923020351274257995771908141939428581001738067456075377685908538458", "0x4d54403147e84f0cfff4dccb1a7eb85737e1c23c10a62b5ad790663621c7cf18", "0x2ee1b8c5257084c9ed6fbc0a148921e02a35f5de9f6405516c63c87037abb299", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543420617 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "31450"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789265", blockHash: "0x5de5aaed97c2e82d7dd7d7eaa03fe22960c4861f2710ca1bfe26a5cf389ce2f1", timeStamp: "1543424010", hash: "0xcc4a3b2d7cab3f310274c11fdefb5e85c6c9e568d502edf2540ebed0ac032d5a", nonce: "127", transactionIndex: "69", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "8000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2468644", txreceipt_status: "1", gasUsed: "153523", confirmations: "913542", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543424010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "1048139302952233539119077875582266388302534873573834856377412715139508538093"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790225"}, {name: "nbToken", type: "uint256", value: "351201530460320905"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1635\", \"1048139302952233539119077875... )", async function( ) {
		const txOriginal = {blockNumber: "6789318", blockHash: "0x469ce4b85067a19356749a483e566cd59d9ad76ec4d610dd4a5750333ee0fff5", timeStamp: "1543424911", hash: "0x47dd6b02d2723dda32c6a01ed6aabe293ff1b30293a44e1bf6f8bff99a7a67e0", nonce: "128", transactionIndex: "95", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "98140", gasPrice: "7000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000663025139cf7e2d27b2c98c7081b081aacd9375be9c2c15606dd31ca67787190aed951c272266ecea1b1a67d80767bcbfb9df1833109df6eff21d8dab42afc4ae7d17f0eeb370b6fed68761e11fff4148cd7eb4e9e62b8ad4fadf0ae14e54e7d06f000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "7685962", txreceipt_status: "1", gasUsed: "50427", confirmations: "913489", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1635"}, {type: "uint256", name: "torpedoBatchID", value: "1048139302952233539119077875582266388302534873573834856377412715139508538093"}, {type: "bytes32", name: "r", value: "0x951c272266ecea1b1a67d80767bcbfb9df1833109df6eff21d8dab42afc4ae7d"}, {type: "bytes32", name: "s", value: "0x17f0eeb370b6fed68761e11fff4148cd7eb4e9e62b8ad4fadf0ae14e54e7d06f"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1635", "1048139302952233539119077875582266388302534873573834856377412715139508538093", "0x951c272266ecea1b1a67d80767bcbfb9df1833109df6eff21d8dab42afc4ae7d", "0x17f0eeb370b6fed68761e11fff4148cd7eb4e9e62b8ad4fadf0ae14e54e7d06f", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543424911 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "33085"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789360", blockHash: "0xbf51f22a6007d3afbc2ce14e010c7e8d0062943ac6eef06fa7c27a279c907f03", timeStamp: "1543425470", hash: "0x962b1f2f05fd2a7eb00aadb24237042ac84c937197f2cf441db377d425677926", nonce: "129", transactionIndex: "43", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "10000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2522662", txreceipt_status: "1", gasUsed: "153523", confirmations: "913447", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543425470 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "34213667095843985054448024174110978351183113825554115971027612505028534573552"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790320"}, {name: "nbToken", type: "uint256", value: "351201514270174478"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1630\", \"3421366709584398505444802417... )", async function( ) {
		const txOriginal = {blockNumber: "6789380", blockHash: "0x6bb817f2c03313db7bd085a1805c023345fac6358504dad0839b5731dfcf5723", timeStamp: "1543425738", hash: "0xd7f354c32126d56e0cf806abb62b9417157b9ab11030d42555a6fa9c7322c079", nonce: "130", transactionIndex: "101", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "98044", gasPrice: "10000000000", input: "0x4af0616a000000000000000000000000000000000000000000000000000000000000065e4ba43fd44b759fca0f535f8fa0c1e7e4be41354a095be6a1d4a90059bc5d99f07757b804c48d43b0383308ae94387ff5c0274d7bdeb9dfe5abf9ae06182e3569484a6bb69563eaceb715a05819b9a92a8eecc5c793a670c6cca6d9b73c04ea78000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "5366651", txreceipt_status: "1", gasUsed: "50363", confirmations: "913427", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1630"}, {type: "uint256", name: "torpedoBatchID", value: "34213667095843985054448024174110978351183113825554115971027612505028534573552"}, {type: "bytes32", name: "r", value: "0x7757b804c48d43b0383308ae94387ff5c0274d7bdeb9dfe5abf9ae06182e3569"}, {type: "bytes32", name: "s", value: "0x484a6bb69563eaceb715a05819b9a92a8eecc5c793a670c6cca6d9b73c04ea78"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1630", "34213667095843985054448024174110978351183113825554115971027612505028534573552", "0x7757b804c48d43b0383308ae94387ff5c0274d7bdeb9dfe5abf9ae06182e3569", "0x484a6bb69563eaceb715a05819b9a92a8eecc5c793a670c6cca6d9b73c04ea78", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543425738 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "34715"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789436", blockHash: "0x2e462ffbb8771b5f3d120d21f4d367bda2450884ef9a41361a533373b995157a", timeStamp: "1543426527", hash: "0x3b0dcb106854b765db6f264ef43e47fbb270b2e4246fdc632b343af27ef762d5", nonce: "3906", transactionIndex: "76", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "10000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5514995", txreceipt_status: "1", gasUsed: "153523", confirmations: "913371", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543426527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "33025652811804559395138791705925413438690848748888726150335666183316411464778"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790396"}, {name: "nbToken", type: "uint256", value: "350470292527359085"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1600\", \"3302565281180455939513879170... )", async function( ) {
		const txOriginal = {blockNumber: "6789458", blockHash: "0x3c1e8811f5145b3c29ecc8b554932e96b2d3ddf8ea9d8dff694027bbcea84606", timeStamp: "1543426881", hash: "0x6dca4aae7de7f4eebb492a68201f39da37848724b9c0aea555e7d13ba3064660", nonce: "3907", transactionIndex: "33", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "97741", gasPrice: "10000000000", input: "0x4af0616a00000000000000000000000000000000000000000000000000000000000006404903db69666eca9c0f72965fd61b28df2f41dd0941368551ee830c192d9b3c4a0587301e2c1bac7db7e0b9d7ba9eb1819aa5e98b7578c51c498119fc5c46604340db6961d3274e96610c56a6a2ddc09f51c4eb765e0486794df9a3032e5328e3000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "1869759", txreceipt_status: "1", gasUsed: "50161", confirmations: "913349", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1600"}, {type: "uint256", name: "torpedoBatchID", value: "33025652811804559395138791705925413438690848748888726150335666183316411464778"}, {type: "bytes32", name: "r", value: "0x0587301e2c1bac7db7e0b9d7ba9eb1819aa5e98b7578c51c498119fc5c466043"}, {type: "bytes32", name: "s", value: "0x40db6961d3274e96610c56a6a2ddc09f51c4eb765e0486794df9a3032e5328e3"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1600", "33025652811804559395138791705925413438690848748888726150335666183316411464778", "0x0587301e2c1bac7db7e0b9d7ba9eb1819aa5e98b7578c51c498119fc5c466043", "0x40db6961d3274e96610c56a6a2ddc09f51c4eb765e0486794df9a3032e5328e3", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543426881 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "9900"}, {name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789529", blockHash: "0x91f83270617d7b9f86a42bb1b09f5c5b99d273bab802d26aed99cc6e8d73c483", timeStamp: "1543427778", hash: "0x5731afe12f676342b61a72b32b31446466d0a2180eab7bf106487df387d31994", nonce: "3913", transactionIndex: "35", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "100000000000000000", gas: "230613", gasPrice: "10000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1894946", txreceipt_status: "1", gasUsed: "153742", confirmations: "913278", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543427778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "36768293757289501118699401511856991489478896071857900027730932411050115171802"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790489"}, {name: "nbToken", type: "uint256", value: "3503990580159303218"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 1, c: [10]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789531", blockHash: "0x184e846cfd5ae2189434f68f69ddca359dcf71db16c5551d7d0689051804f6c4", timeStamp: "1543427848", hash: "0x351d191c650de5eec3718799c3e33f84bac17ca8de37bd7bb772c8e09d2de2bd", nonce: "131", transactionIndex: "111", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "10000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7037669", txreceipt_status: "1", gasUsed: "153523", confirmations: "913276", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543427848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "103600697838686796732804724870879870059635460489443672064074282300111656369590"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790491"}, {name: "nbToken", type: "uint256", value: "350398884723820802"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"2015\", \"3676829375728950111869940151... )", async function( ) {
		const txOriginal = {blockNumber: "6789546", blockHash: "0xee7779ff819b134143a01f98fe21fc24a35619f13fc824e8586631e4409c04f5", timeStamp: "1543428119", hash: "0x0a14b368f62da01f712f999ad23c1b3e95c9fcbbeaab65660457d76e582abbc4", nonce: "3915", transactionIndex: "10", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "291243", gasPrice: "9000000000", input: "0x0908c7fa00000000000000000000000000000000000000000000000000000000000007df514a1de58c56ecaecdf53854dd8cb6edebdde9f79f191618571e1bb92ccb85da0000000000000000000000000000000000000000000000000000000000000000b83dfd0d4d225c0407e64a777c746a643cb3b797723ee09718ae26976fb9b34a6a4fc514560a9021d1186488d496f215156e7901e89a8a64ec5685bc0577d9e1000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "862994", txreceipt_status: "1", gasUsed: "179162", confirmations: "913261", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "2015"}, {type: "uint256", name: "torpedoBatchID", value: "36768293757289501118699401511856991489478896071857900027730932411050115171802"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0xb83dfd0d4d225c0407e64a777c746a643cb3b797723ee09718ae26976fb9b34a"}, {type: "bytes32", name: "s", value: "0x6a4fc514560a9021d1186488d496f215156e7901e89a8a64ec5685bc0577d9e1"}, {type: "uint8", name: "v", value: "28"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "2015", "36768293757289501118699401511856991489478896071857900027730932411050115171802", addressList[0], "0xb83dfd0d4d225c0407e64a777c746a643cb3b797723ee09718ae26976fb9b34a", "0x6a4fc514560a9021d1186488d496f215156e7901e89a8a64ec5685bc0577d9e1", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543428119 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "30050"}, {name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "26946222371495729332736513880330312748067453549970188367302360541181969145230"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790506"}, {name: "nbToken", type: "uint256", value: "350398867394646570"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1635\", \"1036006978386867967328047248... )", async function( ) {
		const txOriginal = {blockNumber: "6789550", blockHash: "0x410737d7f5a7ea279981fc1aed38c75f478283073ff210a79b57b72b242b4002", timeStamp: "1543428142", hash: "0xf4286380e4d7d936d7c89afd45c32e95f4b95b9851debff8a85761988c6308c1", nonce: "132", transactionIndex: "15", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "98140", gasPrice: "8000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000663e50beac0633dc1f2ce04290a910dde4dd8765f71881158807611c7a3163cbdb689465f0c064abfb6b373d8885c84114d97a88011cea7301d3e2165b07eac73a0208aec89920764bb729c34e673655e70b765e3641d0385458e3b6e0b567fde17000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "934174", txreceipt_status: "1", gasUsed: "50427", confirmations: "913257", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1635"}, {type: "uint256", name: "torpedoBatchID", value: "103600697838686796732804724870879870059635460489443672064074282300111656369590"}, {type: "bytes32", name: "r", value: "0x89465f0c064abfb6b373d8885c84114d97a88011cea7301d3e2165b07eac73a0"}, {type: "bytes32", name: "s", value: "0x208aec89920764bb729c34e673655e70b765e3641d0385458e3b6e0b567fde17"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1635", "103600697838686796732804724870879870059635460489443672064074282300111656369590", "0x89465f0c064abfb6b373d8885c84114d97a88011cea7301d3e2165b07eac73a0", "0x208aec89920764bb729c34e673655e70b765e3641d0385458e3b6e0b567fde17", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543428142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "36350"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1515\", \"2694622237149572933273651388... )", async function( ) {
		const txOriginal = {blockNumber: "6789594", blockHash: "0xd27d70bf1ec036d48786c62ccb775bfd77b47de6020c6eb9e8e0bce22ed01276", timeStamp: "1543428597", hash: "0x24c9b5a7b77d01ff542dfed681efb62d213b9bdefdbcd707b12806bacb4202f5", nonce: "3919", transactionIndex: "23", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "97645", gasPrice: "9000000000", input: "0x4af0616a00000000000000000000000000000000000000000000000000000000000005eb3b93057994d890e4255a95accda7c0b2429334a2b725cd7d8970c16ba1839d8e378c1fe864c1797ce253bcfb7b42370fa3c5d246d09a6ac8876e8ce22e2d00f3522f26050acee1dcf0d1b89949882a34da860658217bef05d40d111eab256429000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "1584975", txreceipt_status: "1", gasUsed: "50097", confirmations: "913213", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1515"}, {type: "uint256", name: "torpedoBatchID", value: "26946222371495729332736513880330312748067453549970188367302360541181969145230"}, {type: "bytes32", name: "r", value: "0x378c1fe864c1797ce253bcfb7b42370fa3c5d246d09a6ac8876e8ce22e2d00f3"}, {type: "bytes32", name: "s", value: "0x522f26050acee1dcf0d1b89949882a34da860658217bef05d40d111eab256429"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1515", "26946222371495729332736513880330312748067453549970188367302360541181969145230", "0x378c1fe864c1797ce253bcfb7b42370fa3c5d246d09a6ac8876e8ce22e2d00f3", "0x522f26050acee1dcf0d1b89949882a34da860658217bef05d40d111eab256429", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543428597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6793693"}, {name: "score", type: "uint256", value: "31565"}, {name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789604", blockHash: "0x544ff2c86e973b150d77a4f7441988b8ab0f82a113789fc7062bf909db09e97d", timeStamp: "1543428699", hash: "0xd32e194b8c17eb893c16f7b42e9c385ca655fa4e196a7ef193b49c864367e913", nonce: "3920", transactionIndex: "157", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "100000000000000000", gas: "268684", gasPrice: "8000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7252733", txreceipt_status: "1", gasUsed: "179123", confirmations: "913203", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543428699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "108287564243225529831640506079550267389279049953790214979551521407141473410981"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790564"}, {name: "nbToken", type: "uint256", value: "3502002224648036836"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 1, c: [10]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"2130\", \"1082875642432255298316405060... )", async function( ) {
		const txOriginal = {blockNumber: "6789663", blockHash: "0x2df8d88fa530f8f9dfc74b1286109a3facd243f922e387c9d337f576616e34eb", timeStamp: "1543429379", hash: "0x1518006e8525a231347025055611d4e356660b74e6fee1ab41c90ed7664f6e5d", nonce: "3921", transactionIndex: "47", from: "0x8da4f82dc4d03c5421bb2087f858750c650d8571", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "113920", gasPrice: "7000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000852ef6896e156dd4b6223e4a09e1f48284bccd8d14781a9e27d4f6aace2c6fbdfa5d8219db69aa932be69bec88791b0a644ccc5b3625985f5a34aca93caea1367e767cee1e1802fbaac9666d9274a8b71a49ded6b2977da6eb49e3ae1059e31cc4b000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "2928945", txreceipt_status: "1", gasUsed: "60947", confirmations: "913144", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "2130"}, {type: "uint256", name: "torpedoBatchID", value: "108287564243225529831640506079550267389279049953790214979551521407141473410981"}, {type: "bytes32", name: "r", value: "0xd8219db69aa932be69bec88791b0a644ccc5b3625985f5a34aca93caea1367e7"}, {type: "bytes32", name: "s", value: "0x67cee1e1802fbaac9666d9274a8b71a49ded6b2977da6eb49e3ae1059e31cc4b"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "2130", "108287564243225529831640506079550267389279049953790214979551521407141473410981", "0xd8219db69aa932be69bec88791b0a644ccc5b3625985f5a34aca93caea1367e7", "0x67cee1e1802fbaac9666d9274a8b71a49ded6b2977da6eb49e3ae1059e31cc4b", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543429379 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6795423"}, {name: "score", type: "uint256", value: "52865"}, {name: "customerAddress", type: "address", value: "0x8da4f82dc4d03c5421bb2087f858750c650d8571"}, {name: "newHighScore", type: "bool", value: true}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "669865954869907265" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789772", blockHash: "0x6e9e7364901b5c03708d5a3bd133479a0f717aedd7ca7e09cd3cdbd63d7a8582", timeStamp: "1543430903", hash: "0xa22a18e1f076d7a1171682c9ac5b3d4764287b761a1629c73226b018fd9dc667", nonce: "133", transactionIndex: "87", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "8000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3044467", txreceipt_status: "1", gasUsed: "153523", confirmations: "913035", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543430903 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[44,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "84936723270400841607138718735986230682034856777222838963278722087983752150751"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790732"}, {name: "nbToken", type: "uint256", value: "350083392697216989"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[44,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"2415\", \"8493672327040084160713871873... )", async function( ) {
		const txOriginal = {blockNumber: "6789804", blockHash: "0x77cc06d7fc1f1da26d32c81b48310a555cebbbfab85bff1e88b618d650bbd1e8", timeStamp: "1543431337", hash: "0xff792bb018cbc17d69a4a175b4c8d708e939d77b839f45ef8c439c5c44ad615e", nonce: "134", transactionIndex: "92", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "97795", gasPrice: "6000000000", input: "0x4af0616a000000000000000000000000000000000000000000000000000000000000096fbbc87b53bcf1a7693f0324cd8c16a93b125884d54ec1a88f64d6aad8b897fedf2a562acfdd3a165e0568c767cd78e2360efdb44b9606ee2ce9ea0e16636261262c0365e30f2132953b45dd56ab320c3bff358aa25be8bc36b5161b65258cb7b5000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "5543984", txreceipt_status: "1", gasUsed: "50197", confirmations: "913003", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "2415"}, {type: "uint256", name: "torpedoBatchID", value: "84936723270400841607138718735986230682034856777222838963278722087983752150751"}, {type: "bytes32", name: "r", value: "0x2a562acfdd3a165e0568c767cd78e2360efdb44b9606ee2ce9ea0e1663626126"}, {type: "bytes32", name: "s", value: "0x2c0365e30f2132953b45dd56ab320c3bff358aa25be8bc36b5161b65258cb7b5"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "2415", "84936723270400841607138718735986230682034856777222838963278722087983752150751", "0x2a562acfdd3a165e0568c767cd78e2360efdb44b9606ee2ce9ea0e1663626126", "0x2c0365e30f2132953b45dd56ab320c3bff358aa25be8bc36b5161b65258cb7b5", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543431337 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6795423"}, {name: "score", type: "uint256", value: "38765"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6789971", blockHash: "0x78d72520cbaf0990663903bff5ac09008e23a10b439981e2249c7471f36a10b8", timeStamp: "1543433796", hash: "0x0893b32de2b743dbe8bd9057f1794d705df6aa154b4156641b567301c3bf40c8", nonce: "135", transactionIndex: "126", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "230284", gasPrice: "7000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7565732", txreceipt_status: "1", gasUsed: "153523", confirmations: "912836", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543433796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "96280806821308123400904601192216154141684130414846431833097213758905962486776"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6790931"}, {name: "nbToken", type: "uint256", value: "350083375078902037"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"1655\", \"9628080682130812340090460119... )", async function( ) {
		const txOriginal = {blockNumber: "6789995", blockHash: "0x7fcfbeec90d4200cec79f497ccc637b7eaedc81eb928ee9648ae99ca57ed72cd", timeStamp: "1543434081", hash: "0xa4d0fda830d6aaa68437bbfe01496f0540d6efb5a7a1f494422acd5c2fe741ab", nonce: "136", transactionIndex: "101", from: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "97795", gasPrice: "8000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000677d4dd01688c24b7f09f83299720266d425d793302d064cd303166ac03bbfc5bf8cd2b21dd6c25559e1dceeb246743d8b57cb29e29ec40b9ae3d5ac2bca3fc6a8b179c4be79b9e9e8f4d1bd6996feb4e8f3177d52a6f9bb6acf09dcf3b7dfce3b1000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "5898006", txreceipt_status: "1", gasUsed: "50197", confirmations: "912812", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "1655"}, {type: "uint256", name: "torpedoBatchID", value: "96280806821308123400904601192216154141684130414846431833097213758905962486776"}, {type: "bytes32", name: "r", value: "0xcd2b21dd6c25559e1dceeb246743d8b57cb29e29ec40b9ae3d5ac2bca3fc6a8b"}, {type: "bytes32", name: "s", value: "0x179c4be79b9e9e8f4d1bd6996feb4e8f3177d52a6f9bb6acf09dcf3b7dfce3b1"}, {type: "uint8", name: "v", value: "28"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "1655", "96280806821308123400904601192216154141684130414846431833097213758905962486776", "0xcd2b21dd6c25559e1dceeb246743d8b57cb29e29ec40b9ae3d5ac2bca3fc6a8b", "0x179c4be79b9e9e8f4d1bd6996feb4e8f3177d52a6f9bb6acf09dcf3b7dfce3b1", "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543434081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6795423"}, {name: "score", type: "uint256", value: "40420"}, {name: "customerAddress", type: "address", value: "0x5fb7a1ca8f72df631174d6c1caa8b19a731c2fba"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "62572886458037216" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: BuyTorpedo( \"0\", \"0\", addressList[0], \"0x000000... )", async function( ) {
		const txOriginal = {blockNumber: "6790287", blockHash: "0xcf4facac69b9efd803acadc20a98c7c885466c01efceda50ba7da59df1054d86", timeStamp: "1543438475", hash: "0xa47473fa59515d10b31f0fe8c55042d1ff9d41e7a2eaec33c5f6c4e8a769bbd5", nonce: "1389", transactionIndex: "5", from: "0xa42015da9e346e4c9f2ca5bb71b9d1a885810713", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "10000000000000000", gas: "420493", gasPrice: "7000000000", input: "0x0908c7fa000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4816119", txreceipt_status: "1", gasUsed: "280329", confirmations: "912520", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "0"}, {type: "uint256", name: "torpedoBatchID", value: "0"}, {type: "address", name: "_referrer_address", value: addressList[0]}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "uint8", name: "v", value: "0"}], name: "BuyTorpedo", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyTorpedo(int256,uint256,address,bytes32,bytes32,uint8)" ]( "0", "0", addressList[0], "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543438475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "torpedoBatchID", type: "uint256"}, {indexed: false, name: "torpedoBatchBlockTimeout", type: "uint256"}, {indexed: false, name: "nbToken", type: "uint256"}, {indexed: false, name: "torpedoBatchMultiplier", type: "uint32"}], name: "onBuyTorpedo", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onBuyTorpedo", events: [{name: "customerAddress", type: "address", value: "0xa42015da9e346e4c9f2ca5bb71b9d1a885810713"}, {name: "gRND", type: "uint256", value: "3"}, {name: "torpedoBatchID", type: "uint256", value: "26001947453954272690698673120885389345853035577208729065180686453681351625167"}, {name: "torpedoBatchBlockTimeout", type: "uint256", value: "6791247"}, {name: "nbToken", type: "uint256", value: "350083357460617456"}, {name: "torpedoBatchMultiplier", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "57188593985875" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: ValidTorpedoScore( \"105\", \"26001947453954272690698673120... )", async function( ) {
		const txOriginal = {blockNumber: "6790326", blockHash: "0xb993fba014c47529e0e13755cf1ac0bad742df0d8659370967721ef77b26e643", timeStamp: "1543438980", hash: "0x11709b9889b794b1a77a5f3cab9cbae74f3a8894a508a6f65f55cba3f972e4a1", nonce: "1390", transactionIndex: "71", from: "0xa42015da9e346e4c9f2ca5bb71b9d1a885810713", to: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1", value: "0", gas: "106248", gasPrice: "7000000000", input: "0x4af0616a0000000000000000000000000000000000000000000000000000000000000069397c94aa42b595717d7c76054f8090ee14488e75d3512cc8f43af3dfe9a909cfafb86ec3e0ba6073770776f3c48078e235a0fce99f7ec575ea90ba814665c7ab67d2dd07671e0d00a2a9852ed87dd0c1ef84c7ab0f309af30f21e44cb2229cf4000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "4830478", txreceipt_status: "1", gasUsed: "55832", confirmations: "912481", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "int256", name: "score", value: "105"}, {type: "uint256", name: "torpedoBatchID", value: "26001947453954272690698673120885389345853035577208729065180686453681351625167"}, {type: "bytes32", name: "r", value: "0xafb86ec3e0ba6073770776f3c48078e235a0fce99f7ec575ea90ba814665c7ab"}, {type: "bytes32", name: "s", value: "0x67d2dd07671e0d00a2a9852ed87dd0c1ef84c7ab0f309af30f21e44cb2229cf4"}, {type: "uint8", name: "v", value: "27"}], name: "ValidTorpedoScore", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ValidTorpedoScore(int256,uint256,bytes32,bytes32,uint8)" ]( "105", "26001947453954272690698673120885389345853035577208729065180686453681351625167", "0xafb86ec3e0ba6073770776f3c48078e235a0fce99f7ec575ea90ba814665c7ab", "0x67d2dd07671e0d00a2a9852ed87dd0c1ef84c7ab0f309af30f21e44cb2229cf4", "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543438980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gRND", type: "uint256"}, {indexed: false, name: "blockNumberTimeout", type: "uint256"}, {indexed: false, name: "score", type: "uint256"}, {indexed: false, name: "customerAddress", type: "address"}, {indexed: false, name: "newHighScore", type: "bool"}, {indexed: false, name: "highscoreChanged", type: "bool"}], name: "onNewScore", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewScore", events: [{name: "gRND", type: "uint256", value: "3"}, {name: "blockNumberTimeout", type: "uint256", value: "6795423"}, {name: "score", type: "uint256", value: "105"}, {name: "customerAddress", type: "address", value: "0xa42015da9e346e4c9f2ca5bb71b9d1a885810713"}, {name: "newHighScore", type: "bool", value: false}, {name: "highscoreChanged", type: "bool", value: true}], address: "0xdef439cb500cfba0b66d29592776cb2df40c1cf1"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "57188593985875" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "192403154120942446" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
