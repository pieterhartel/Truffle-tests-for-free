const TokenSale = artifacts.require( "./TokenSale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TokenSale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xCcA36039cfDd0753D3aA9F1B4Bf35b606c8Ed971", "0x73f53131aDda8D9755b850b3B55241D16368d79D", "0x5d60d8d7eF6d37E16EBABc324de3bE57f135e0BC", "0xd9d2B28E09921A38aD7aB1B4138357408bda8EBD", "0xFd1E4b568Bb3bcF706b0bac5960d4B91BacFF96F", "0xe1E7c7BD0d986aAc61033E31e28F769f999D8e5b", "0x50F06a6Fe481eeAfcF19C8ADBbd9F2F7d312DCd8", "0xAFC4337A972eADf0D5736e9c15E7ede2875D24F1", "0xa7A13659692239c143daE313a0116D5b5C18d26C", "0x5d8d5184B35F0569B79d7E169be0aeee21A3C078", "0x06E9cF430221C06ACE6345944038eAf21E7E85fA", "0x99A8e2c1385BE6DDE6Fe6DBABa52b89499415ddA"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_day", type: "uint16"}], name: "getTotalWeiContributed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_contributor", type: "address"}, {name: "_days", type: "uint16[]"}], name: "getTotalTokensOwed", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_contributor", type: "address"}, {name: "_day", type: "uint16"}], name: "getTokensOwed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentDay", outputs: [{name: "", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_day", type: "uint16"}], name: "duringSale", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "mybitFoundation", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "developmentFund", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensPerDay", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_day", type: "uint16"}], name: "dayFinished", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint16"}], name: "day", outputs: [{name: "totalWeiContributed", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "start", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_day", type: "uint16"}, {name: "_contributor", type: "address"}], name: "getWeiContributed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_timestamp", type: "uint256"}], name: "dayFor", outputs: [{name: "", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_owner", type: "address"}, {indexed: false, name: "_mybFoundation", type: "address"}, {indexed: false, name: "_developmentFund", type: "address"}, {indexed: false, name: "_totalMYB", type: "uint256"}, {indexed: false, name: "_startTime", type: "uint256"}], name: "LogSaleStarted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_mybFoundation", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_day", type: "uint16"}], name: "LogFoundationWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensCollected", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogSaleStarted(address,address,address,uint256,uint256)", "LogFoundationWithdraw(address,uint256,uint16)", "LogTokensPurchased(address,uint256,uint16)", "LogTokensCollected(address,uint256,uint16)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8374e91c2472351bc5eb07c7e6292d3b801d821ce30fefbff40e013a94af7f94", "0xe56726172348e334b8fff79c722777489b247ed7148d44486ab67b65c1a54f1f", "0xd498819977fb9763f29bab6e4eee516c4cf59053922eb6a9fe59370a7bc28b3d", "0x33a4ae6c0627280fcb7aaf7e07deb59bbce49aa4808ee5457f8622f77ab5d28c"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6910644 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6968662 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_mybToken", value: 4}, {type: "address", name: "_mybFoundation", value: 5}, {type: "address", name: "_developmentFund", value: 6}], name: "TokenSale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint16", name: "_day", value: random.range( maxRandom )}], name: "getTotalWeiContributed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotalWeiContributed(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_contributor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint16[]", name: "_days", value: [random.range( maxRandom )]}], name: "getTotalTokensOwed", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotalTokensOwed(address,uint16[])" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_contributor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint16", name: "_day", value: random.range( maxRandom )}], name: "getTokensOwed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokensOwed(address,uint16)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentDay", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentDay()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "_day", value: random.range( maxRandom )}], name: "duringSale", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "duringSale(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "mybitFoundation", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "mybitFoundation()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "developmentFund", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "developmentFund()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensPerDay", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensPerDay()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "_day", value: random.range( maxRandom )}], name: "dayFinished", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dayFinished(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "", value: random.range( maxRandom )}], name: "day", outputs: [{name: "totalWeiContributed", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "day(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "start", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "start()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "_day", value: random.range( maxRandom )}, {type: "address", name: "_contributor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getWeiContributed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getWeiContributed(uint16,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_timestamp", value: random.range( maxRandom )}], name: "dayFor", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dayFor(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TokenSale", function( accounts ) {

	it( "TEST: TokenSale( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6910644", timeStamp: "1545160175", hash: "0xad4ebbe7beb1454a4c5d3bb3f419f4885cc9d5802f90382267b41e326f3982cf", nonce: "10", blockHash: "0x86a46247a1f95f087efb3f0ca43b50ba5ee5d23aec4b6dbae6bdabc84a4e192a", transactionIndex: "0", from: "0x73f53131adda8d9755b850b3b55241d16368d79d", to: 0, value: "0", gas: "8000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x07f5b7a20000000000000000000000005d60d8d7ef6d37e16ebabc324de3be57f135e0bc000000000000000000000000d9d2b28e09921a38ad7ab1b4138357408bda8ebd000000000000000000000000fd1e4b568bb3bcf706b0bac5960d4b91bacff96f", contractAddress: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", cumulativeGasUsed: "1209306", gasUsed: "1209306", confirmations: "765904"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_mybToken", value: addressList[4]}, {type: "address", name: "_mybFoundation", value: addressList[5]}, {type: "address", name: "_developmentFund", value: addressList[6]}], name: "TokenSale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TokenSale.new( addressList[4], addressList[5], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1545160175 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TokenSale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "610852758100123304" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: startSale( \"1546344000\" )", async function( ) {
		const txOriginal = {blockNumber: "6910790", timeStamp: "1545162219", hash: "0x583c679576fd3774b2168173f94ae9decb19ed6e990b2ea2dcd9118356ce7bf3", nonce: "11", blockHash: "0x23c800f99525142dfbaad28eef90a5d1b39b6dc61c5a4ee63bdd4594d7785a17", transactionIndex: "20", from: "0x73f53131adda8d9755b850b3b55241d16368d79d", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "0", gas: "300000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x0e3ab61d000000000000000000000000000000000000000000000000000000005c2b5640", contractAddress: "", cumulativeGasUsed: "775869", gasUsed: "295733", confirmations: "765758"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_timestamp", value: "1546344000"}], name: "startSale", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startSale(uint256)" ]( "1546344000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1545162219 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "610852758100123304" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: startSale( \"1546344000\" )", async function( ) {
		const txOriginal = {blockNumber: "6910971", timeStamp: "1545164647", hash: "0xbb57a5255cdbe87eb031e64100c5e38815e469e35ec5cf3787d85435ca15f4a8", nonce: "14", blockHash: "0x517ca108c31c5b9f0d6b848d212555b7293c72166455c1ce029491ad162a4a13", transactionIndex: "0", from: "0x73f53131adda8d9755b850b3b55241d16368d79d", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "0", gas: "500000", gasPrice: "79027707934", isError: "0", txreceipt_status: "1", input: "0x0e3ab61d000000000000000000000000000000000000000000000000000000005c2b5640", contractAddress: "", cumulativeGasUsed: "51279", gasUsed: "51279", confirmations: "765577"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_timestamp", value: "1546344000"}], name: "startSale", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startSale(uint256)" ]( "1546344000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1545164647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_owner", type: "address"}, {indexed: false, name: "_mybFoundation", type: "address"}, {indexed: false, name: "_developmentFund", type: "address"}, {indexed: false, name: "_totalMYB", type: "uint256"}, {indexed: false, name: "_startTime", type: "uint256"}], name: "LogSaleStarted", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogSaleStarted", events: [{name: "_owner", type: "address", value: "0x73f53131adda8d9755b850b3b55241d16368d79d"}, {name: "_mybFoundation", type: "address", value: "0xd9d2b28e09921a38ad7ab1b4138357408bda8ebd"}, {name: "_developmentFund", type: "address", value: "0xfd1e4b568bb3bcf706b0bac5960d4b91bacff96f"}, {name: "_totalMYB", type: "uint256", value: "36500000000000000000000000"}, {name: "_startTime", type: "uint256", value: "1546344000"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "610852758100123304" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6911288", timeStamp: "1545169124", hash: "0xc9ea5d42d7a6b7693e830536c16d2369200aeed3cb3487abb84962086dd14017", nonce: "8", blockHash: "0xebf142e02809d92a6e8fabcf6743f69548df9fb8b234eab68edd940bada72c60", transactionIndex: "9", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "170000000000000000", gas: "7607448", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "350590", gasUsed: "21319", confirmations: "765260"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "170000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1545169124 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: batchFund( [\"5\",\"6\"] )", async function( ) {
		const txOriginal = {blockNumber: "6912131", timeStamp: "1545181580", hash: "0x7a4bcb65d6d991fe456135e2c370283c79860c717f8efac4ce2d736d9fc126ba", nonce: "87", blockHash: "0x42299373b9ba2434ffae1278156663dd9bfcd2b27008825f257535ee390325ef", transactionIndex: "173", from: "0x50f06a6fe481eeafcf19c8adbbd9f2f7d312dcd8", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "60000000000000000", gas: "164820", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x1ca899530000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "7843009", gasUsed: "109880", confirmations: "764417"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16[]", name: "_day", value: ["5","6"]}], name: "batchFund", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchFund(uint16[])" ]( ["5","6"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1545181580 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x50f06a6fe481eeafcf19c8adbbd9f2f7d312dcd8"}, {name: "_amount", type: "uint256", value: "30000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000005"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}, {name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x50f06a6fe481eeafcf19c8adbbd9f2f7d312dcd8"}, {name: "_amount", type: "uint256", value: "30000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000006"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5016893105968680034" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6914043", timeStamp: "1545210071", hash: "0x66b16d43fbd1d234d3bbede0a8331dbb5513a9fa967f0b71d3392bbed86d2bea", nonce: "1", blockHash: "0xb846ff9e42c19cd31f6e39383cd06cc620adbe3fc2ec8285e90fded7b47bfc82", transactionIndex: "61", from: "0xafc4337a972eadf0d5736e9c15e7ede2875d24f1", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "100000000000", gas: "65439", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5951790", gasUsed: "65439", confirmations: "762505"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "0"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1545210071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xafc4337a972eadf0d5736e9c15e7ede2875d24f1"}, {name: "_amount", type: "uint256", value: "100000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6914631", timeStamp: "1545218745", hash: "0x3d44aab884322ff826870236eb6ef52be57d72d167ada84c1fedf7b9537fb07a", nonce: "2", blockHash: "0x8f418db05103a728cbecbdd43af1faa4ee8ee4aeffabce242d72cdfb06bd95e6", transactionIndex: "98", from: "0xafc4337a972eadf0d5736e9c15e7ede2875d24f1", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "100000000000", gas: "65503", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7994964", gasUsed: "65503", confirmations: "761917"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "1"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1545218745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xafc4337a972eadf0d5736e9c15e7ede2875d24f1"}, {name: "_amount", type: "uint256", value: "100000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6914705", timeStamp: "1545219731", hash: "0x980f4b88fcc917086f75ff30bf9849d47f44fa1dd402a3b08014159a3c78bde0", nonce: "9", blockHash: "0xc51278082e99db63833cadbf960d20866fb343e5003c17f09640f63ffc67c62c", transactionIndex: "145", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "170000000000000000", gas: "50439", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5354733", gasUsed: "50439", confirmations: "761843"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "170000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "0"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1545219731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "170000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6914714", timeStamp: "1545219877", hash: "0xc694dae70fffe360b847d184f7094a41c653bdfd57710eee8c42c3b9cedd6dc8", nonce: "10", blockHash: "0xbb456a8e10658ab176a5b92653752e45d31fb592b30fc6029998c49cf8e7298b", transactionIndex: "110", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "250000000000000000", gas: "50503", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4294190", gasUsed: "50503", confirmations: "761834"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "1"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1545219877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "250000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6914724", timeStamp: "1545220046", hash: "0xee7ce3c025ccb76b5308333e7209d0e8b3d390c6005a482ce2a0249b481a556e", nonce: "11", blockHash: "0xf23bf4abed834264955809588b3d8c195e55e6a2b890d6633eef6fc44dfc6da1", transactionIndex: "61", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "1000000000000000000", gas: "35439", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5461996", gasUsed: "35439", confirmations: "761824"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "0"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1545220046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6914726", timeStamp: "1545220070", hash: "0x3a03829a1f6c18da752db010755fad073df5e3d49b82c55963741fc885b47239", nonce: "12", blockHash: "0xec198d963ecb0002775a68e6c0ab97e2b21be7317fe676198cf821a2ba32fc90", transactionIndex: "81", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "40000000000000000", gas: "65503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3520620", gasUsed: "65503", confirmations: "761822"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "2"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1545220070 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "40000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000002"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6914727", timeStamp: "1545220097", hash: "0xe4704e6ccfa9d1d01b3489cb912a794fac6b88668c87eb4855620c2b115f03e2", nonce: "13", blockHash: "0x2b7f27d9bd85d0bc52e3d8924c00d6dc64c55dbc9e8820a215f1234ed5ddc723", transactionIndex: "159", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "20000000000000000", gas: "65503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7918656", gasUsed: "65503", confirmations: "761821"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "3"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1545220097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "20000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000003"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6914731", timeStamp: "1545220138", hash: "0x112d5dae3cd9134dcf3b1078078a9988be4bb0fb593bfae474eb4ba8cd23a6a5", nonce: "14", blockHash: "0x88c4b5333f59a6cfa1816d24879a4db7d9d2c5a76575d5063999f4463c30e4bf", transactionIndex: "158", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "560000000000000000", gas: "65503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "6510896", gasUsed: "65503", confirmations: "761817"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "560000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "4"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1545220138 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "560000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000004"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6914743", timeStamp: "1545220281", hash: "0xa559d5cf0383636fedbf1ee0b6d420096f9dd11a636c45f36a4bc2bc507e1ddb", nonce: "194", blockHash: "0xb2e87518dee2ff2317272ed966013ab908c3f23b5ea7fb82604fce0192aff7e2", transactionIndex: "89", from: "0xa7a13659692239c143dae313a0116d5b5c18d26c", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "100000000000000000", gas: "50503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3330007", gasUsed: "50503", confirmations: "761805"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "1"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1545220281 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xa7a13659692239c143dae313a0116d5b5c18d26c"}, {name: "_amount", type: "uint256", value: "100000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "47782839542883132" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6914747", timeStamp: "1545220381", hash: "0x3a8505088c575606902649603b6b6b1d655c59e199e43c3aeb57e68611c39d6f", nonce: "195", blockHash: "0x897ee46ee374dd75bc22c1f9bf3753ad7f2c4cceeae9c0e788bedda0f34c52d7", transactionIndex: "145", from: "0xa7a13659692239c143dae313a0116d5b5c18d26c", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "7603029", gasUsed: "65503", confirmations: "761801"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "7"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1545220381 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xa7a13659692239c143dae313a0116d5b5c18d26c"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000007"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "47782839542883132" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6914779", timeStamp: "1545220923", hash: "0xe97428b47d82c0f945f00b354ee5e1c864cf118e3d402a68097f1f0c635ae4fe", nonce: "15", blockHash: "0x1b3a76af90b6b56b60f36e41aeb67922f942b154ebeaf800b9aae81922714483", transactionIndex: "78", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "100000000000000000", gas: "50503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "7909633", gasUsed: "50503", confirmations: "761769"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "5"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1545220923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "100000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000005"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6914779", timeStamp: "1545220923", hash: "0x0bf6422de73868932ade6bcaca606a2642c44bba7d60d4a572c6d7004d423602", nonce: "196", blockHash: "0x1b3a76af90b6b56b60f36e41aeb67922f942b154ebeaf800b9aae81922714483", transactionIndex: "79", from: "0xa7a13659692239c143dae313a0116d5b5c18d26c", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "50503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7960136", gasUsed: "50503", confirmations: "761769"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "2"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1545220923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xa7a13659692239c143dae313a0116d5b5c18d26c"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000002"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "47782839542883132" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6914789", timeStamp: "1545221067", hash: "0xb1a5d1dbb980d29af024d1aebda5f05f31db6774939224a9a89f4199a2d11c05", nonce: "197", blockHash: "0xd05862483d064b09b64968cfc3b18f7f57c881a74bf950b239ea290a5d8c1b50", transactionIndex: "93", from: "0xa7a13659692239c143dae313a0116d5b5c18d26c", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "50503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "8006920", gasUsed: "50503", confirmations: "761759"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "3"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1545221067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xa7a13659692239c143dae313a0116d5b5c18d26c"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000003"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "47782839542883132" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "6914797", timeStamp: "1545221199", hash: "0xd03c284eed01c335e41990367da5946b261eed3c1c8630fba4949092ed42e205", nonce: "198", blockHash: "0x0fe232cc08d6da008471b811024c20f93af544d7241f32c3834256c082fa0f48", transactionIndex: "202", from: "0xa7a13659692239c143dae313a0116d5b5c18d26c", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "7978532", gasUsed: "65503", confirmations: "761751"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "8"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1545221199 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xa7a13659692239c143dae313a0116d5b5c18d26c"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000008"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "47782839542883132" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "6914985", timeStamp: "1545224107", hash: "0x3b44e1c984e489ece5ee007f34b663b2e7996760ff65719c8ee9b825f172fa08", nonce: "199", blockHash: "0xd32dba46e75e1f7c1b826b5319ee0da2cfab9ea556c4ea31bbf6ab582f9cb7da", transactionIndex: "54", from: "0xa7a13659692239c143dae313a0116d5b5c18d26c", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "1421556", gasUsed: "65503", confirmations: "761563"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "17"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1545224107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xa7a13659692239c143dae313a0116d5b5c18d26c"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000011"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "47782839542883132" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "6914991", timeStamp: "1545224173", hash: "0xca05ad7f374593c2a5b91a176cc4b957e8372080e761f5ebd695c0954a890471", nonce: "16", blockHash: "0xf4f9d9f107a9e433632dd150129249fdfe9aacb63b48f6d5d1de9d0ec50c3c59", transactionIndex: "99", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "45000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "7590525", gasUsed: "50503", confirmations: "761557"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "45000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "8"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545224173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "45000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000008"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "6914991", timeStamp: "1545224173", hash: "0x0ef8aaa6af2cb488aef301fd8f84256adc4971d398c9aefdb32039c5d1d85c62", nonce: "200", blockHash: "0xf4f9d9f107a9e433632dd150129249fdfe9aacb63b48f6d5d1de9d0ec50c3c59", transactionIndex: "101", from: "0xa7a13659692239c143dae313a0116d5b5c18d26c", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "1000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "7647028", gasUsed: "35503", confirmations: "761557"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "17"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545224173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xa7a13659692239c143dae313a0116d5b5c18d26c"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000011"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "47782839542883132" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6915722", timeStamp: "1545234962", hash: "0x38a35748d8ed1b75e0f1dacfc8e07c95db2ac568d362f6c0aeb67564b6b4fa11", nonce: "17", blockHash: "0x2a8c7518b8232d93c3af82dbe26d2ce6382ad9db08f1fc206dda142f0ce5984c", transactionIndex: "140", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "100000000000000000", gas: "50503", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "7582961", gasUsed: "50503", confirmations: "760826"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "6"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545234962 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "100000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000006"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6915725", timeStamp: "1545234998", hash: "0x8471cb378ec93ce4e2b801d52b12b34f9e257bd273486751464cb0011abf2adc", nonce: "18", blockHash: "0xad65678c026ebaff0d023a666c8d8bcf839cd400b5919d33567157a3273299fe", transactionIndex: "11", from: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "50000000000000000", gas: "50503", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "1078235", gasUsed: "50503", confirmations: "760823"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "7"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545234998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xe1e7c7bd0d986aac61033e31e28f769f999d8e5b"}, {name: "_amount", type: "uint256", value: "50000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000007"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6971092686232089" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6916291", timeStamp: "1545243245", hash: "0x31aebe24d076a2f436adb575bcac292abcec6893f8b54b69fe58aed856d8cc5a", nonce: "3", blockHash: "0x00a87b2726bed3959bc69ff7cc46bc9ee7ed07cb517b98d835e8c55b9b127a6b", transactionIndex: "27", from: "0xafc4337a972eadf0d5736e9c15e7ede2875d24f1", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "100000000000", gas: "50503", gasPrice: "2900000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1144814", gasUsed: "50503", confirmations: "760257"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "2"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545243245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0xafc4337a972eadf0d5736e9c15e7ede2875d24f1"}, {name: "_amount", type: "uint256", value: "100000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000002"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6952396", timeStamp: "1545772495", hash: "0x71f476162f5cf2b0c40ae10052ead097570140c1ec42a536ebe7c676b474da09", nonce: "126", blockHash: "0x6ed9461dd11a3ae23a80e12976c313797475ed3b3b0517c6a76bbf93876cf9f8", transactionIndex: "82", from: "0x5d8d5184b35f0569b79d7e169be0aeee21a3c078", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "30000000000000000", gas: "50439", gasPrice: "2600000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7767758", gasUsed: "50439", confirmations: "724152"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "0"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1545772495 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x5d8d5184b35f0569b79d7e169be0aeee21a3c078"}, {name: "_amount", type: "uint256", value: "30000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "20573122563101918" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6963140", timeStamp: "1545929404", hash: "0x3b47995e88f1c3e256258014a9f7264f41cd149024b6fa80783c077fbe33915c", nonce: "0", blockHash: "0x78da1cd1f9e0012426f8add79c8d8d57067124f2619109334250541ca4489294", transactionIndex: "97", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "30000000000000000", gas: "50503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7889411", gasUsed: "50503", confirmations: "713408"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "3"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1545929404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "30000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000003"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6963143", timeStamp: "1545929481", hash: "0xb3fe7b616480dd279e66b2d6a0268ca85df047d40049527b81a856766fd631c4", nonce: "1", blockHash: "0x22e46232ab47eac0aaa44139ba60cf91adc7628f715a324e01f03ba440e01cb6", transactionIndex: "47", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "50000000000000000", gas: "50503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3908144", gasUsed: "50503", confirmations: "713405"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "2"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1545929481 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "50000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000002"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6963144", timeStamp: "1545929493", hash: "0xd6af86a2671f2a1bfb7e448c4ca2270a2ab770370c5801bd6318cf8be5058c50", nonce: "2", blockHash: "0xe1d9f156301a7f22cce1108fc60a2980e72dda3cedc4fa4a6a8c8d7793f060da", transactionIndex: "56", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "60000000000000000", gas: "50503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "2758492", gasUsed: "50503", confirmations: "713404"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "7"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1545929493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000007"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "6963151", timeStamp: "1545929632", hash: "0x046b8f4ab63f8825bf0c07698debd036e0c3a0e2161628795937cc012d0bb06e", nonce: "3", blockHash: "0xd3469934932294a7a7379d8428dd01fa0d03414b21d500e50ecc7e90b7703175", transactionIndex: "111", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "7478257", gasUsed: "65503", confirmations: "713397"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "9"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1545929632 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000009"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6963154", timeStamp: "1545929728", hash: "0x77cc4ac8617d04ffe00b9ff84a0bb8206e00a6e56fccedbdca3b20c2e49fb9de", nonce: "4", blockHash: "0x78e126da96b648a35969abd7decf8b56d48fc5f00fc7eebf7d16d5d1f576ded6", transactionIndex: "82", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a65000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "7293222", gasUsed: "65503", confirmations: "713394"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "10"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1545929728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000000a"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "6963154", timeStamp: "1545929728", hash: "0x2e60115b41bcf3050137d803b77078571eb6e204adb3d341e2abce75a1af38e8", nonce: "5", blockHash: "0x78e126da96b648a35969abd7decf8b56d48fc5f00fc7eebf7d16d5d1f576ded6", transactionIndex: "84", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a65000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "7379725", gasUsed: "65503", confirmations: "713394"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "11"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1545929728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000000b"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "6963155", timeStamp: "1545929742", hash: "0xa889a73aef40131c5fc039df780d834291232df6f79bba59852dc5a40ae875ae", nonce: "6", blockHash: "0x10bb2e12f1cba6c209bbffe79da286d371d28146478d7d73e49e84df78d3439d", transactionIndex: "98", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a65000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "6492137", gasUsed: "65503", confirmations: "713393"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "12"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1545929742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000000c"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "6963157", timeStamp: "1545929761", hash: "0xc8755cecb5317c2ef13ff7b3c2b25d6f6b90a68de5ce139bf28949d7f96b6a24", nonce: "7", blockHash: "0x5050f56fab2d39ae677cf232ac4837657147990ad9625caa67ea9337148de330", transactionIndex: "45", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a65000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "2472959", gasUsed: "65503", confirmations: "713391"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "13"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545929761 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000000d"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"14\" )", async function( ) {
		const txOriginal = {blockNumber: "6963159", timeStamp: "1545929769", hash: "0xad935b6c5a61f09e997e1f2eed102f5962feea32e0014da8baf1a88bac736461", nonce: "8", blockHash: "0x73606a87ba1a8a2fa5f6fe1e0777d8de739a562448526f948f358ed29aca7075", transactionIndex: "14", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a65000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "785923", gasUsed: "65503", confirmations: "713389"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "14"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545929769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000000e"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "6963163", timeStamp: "1545929823", hash: "0x61fe553d6de417af0a6f176f30099520ba133a0ead0606aede97e616e88a1978", nonce: "9", blockHash: "0xa53535212bda5186c588c13b4af70ba5057ec628e6da5af404eede5d9651b214", transactionIndex: "136", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "55000000000000000", gas: "50503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "5303366", gasUsed: "50503", confirmations: "713385"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "8"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545929823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "55000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000008"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"15\" )", async function( ) {
		const txOriginal = {blockNumber: "6963182", timeStamp: "1545930150", hash: "0x928d6b383312661547d2a8b6a456d19f40e0c359108f64b4db24901914fa8db5", nonce: "10", blockHash: "0x2813a92d6e270f1060d5cf721e37827936c37413258cbe72c4c308a19c05b22c", transactionIndex: "128", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a65000000000000000000000000000000000000000000000000000000000000000f", contractAddress: "", cumulativeGasUsed: "7873838", gasUsed: "65503", confirmations: "713366"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "15"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "15", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1545930150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000000f"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"16\" )", async function( ) {
		const txOriginal = {blockNumber: "6963184", timeStamp: "1545930182", hash: "0xf41d7849c209fa6acee0f621444b1c9e1d5117bcbb20b51116ea80a0223c6a35", nonce: "11", blockHash: "0x10903d21607915418d19a180b3d331995632a07c6ffbd3c463c5c16ec3cd5166", transactionIndex: "103", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000010", contractAddress: "", cumulativeGasUsed: "7574396", gasUsed: "65503", confirmations: "713364"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "16"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545930182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000010"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "6963184", timeStamp: "1545930182", hash: "0xa8744e37ddeca4177523037c9fa1ddabf19ff964d499d2e6e6ebdfb0c5188817", nonce: "12", blockHash: "0x10903d21607915418d19a180b3d331995632a07c6ffbd3c463c5c16ec3cd5166", transactionIndex: "105", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "11000000000000000", gas: "50503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "7727905", gasUsed: "50503", confirmations: "713364"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "11000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "17"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545930182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "11000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000011"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6963186", timeStamp: "1545930196", hash: "0xce2ea7c9ac8dddf2848a3dd9f70a8712eee2eab1296c3631cd3cbe032d392a4c", nonce: "13", blockHash: "0x7eb01e61721a10aaaa1aa081c910beb4c00b6b3cbe6800b97cccec3b5b949bb8", transactionIndex: "108", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "130000000000000000", gas: "50503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "7167416", gasUsed: "50503", confirmations: "713362"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "130000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "6"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545930196 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "130000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000006"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6963186", timeStamp: "1545930196", hash: "0x0d61f47947100b0ca35e27e40a3e57772802bb2de472e3d695572cdc881f8ccf", nonce: "14", blockHash: "0x7eb01e61721a10aaaa1aa081c910beb4c00b6b3cbe6800b97cccec3b5b949bb8", transactionIndex: "110", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "130000000000000000", gas: "50503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "7326457", gasUsed: "50503", confirmations: "713362"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "130000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "5"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545930196 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "130000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000005"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "6963210", timeStamp: "1545930660", hash: "0x97b6bb66d8c2794ed64c84cd49ffcb576d81857a85e2673c0f7f15e59f2286ee", nonce: "15", blockHash: "0x025f76fac1ecb326ab997e02efaca0b3dd64a1fb4f4153b0598d356fa12432e5", transactionIndex: "148", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "7995991", gasUsed: "65503", confirmations: "713338"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "18"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545930660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000012"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"19\" )", async function( ) {
		const txOriginal = {blockNumber: "6963212", timeStamp: "1545930697", hash: "0x293b477640081fd86ee0b4073ff586d1335e46828af1cd06f996cee7ec226d18", nonce: "16", blockHash: "0x7b921c72ff7a32556e47a7c1c09821a5c953af7f1d889058bb95332ffbf4129e", transactionIndex: "25", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "7884542", gasUsed: "65503", confirmations: "713336"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "19"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545930697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000013"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"19\" )", async function( ) {
		const txOriginal = {blockNumber: "6963212", timeStamp: "1545930697", hash: "0x081b812a523863f2390499cfb9ec90bccf12b0620333189ca1cdaa81ee6237e0", nonce: "17", blockHash: "0x7b921c72ff7a32556e47a7c1c09821a5c953af7f1d889058bb95332ffbf4129e", transactionIndex: "27", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "7949866", gasUsed: "35503", confirmations: "713336"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "19"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545930697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000013"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6963213", timeStamp: "1545930705", hash: "0x66cda9bfb47e1baa599f54c6ddd9437dc54a09ed8593fcc132c2f5a8d6cb2239", nonce: "18", blockHash: "0x68765702b6707aa22b3d73fa898c6a28498b29abbcf65cdac406d53ac90cdc22", transactionIndex: "57", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "7920741", gasUsed: "65503", confirmations: "713335"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "20"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545930705 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000014"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"21\" )", async function( ) {
		const txOriginal = {blockNumber: "6963213", timeStamp: "1545930705", hash: "0x95900b5ce77b1d7820afb9a2159ce70964afa469225ed2100516b392ec62d24f", nonce: "19", blockHash: "0x68765702b6707aa22b3d73fa898c6a28498b29abbcf65cdac406d53ac90cdc22", transactionIndex: "58", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000015", contractAddress: "", cumulativeGasUsed: "7986244", gasUsed: "65503", confirmations: "713335"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "21"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "21", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545930705 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000015"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"22\" )", async function( ) {
		const txOriginal = {blockNumber: "6963215", timeStamp: "1545930715", hash: "0xdce508a01909f31c9a367d22610c4f20989ad6814b18e21c134bf4442893b83b", nonce: "20", blockHash: "0x6ae1c6b27464208b7ebef16b2fb886b533d11d5f3205d56fc4b6d53ea1c3c419", transactionIndex: "57", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000016", contractAddress: "", cumulativeGasUsed: "5542858", gasUsed: "65503", confirmations: "713333"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "22"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "22", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545930715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000016"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"23\" )", async function( ) {
		const txOriginal = {blockNumber: "6963218", timeStamp: "1545930757", hash: "0x20c74d9eb419b0fe5ce6540d8688297eaeda02450b1e11da65348b6ee2fba6bc", nonce: "21", blockHash: "0x8488630c656fb584f67be2b171fd17e3b98b587f2e7e72745501930896cbfb94", transactionIndex: "121", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "6945647", gasUsed: "65503", confirmations: "713330"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "23"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "23", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545930757 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000017"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"24\" )", async function( ) {
		const txOriginal = {blockNumber: "6963221", timeStamp: "1545930812", hash: "0x340ffdc848f91a9240c90ac62b0774e0d00bd8f7601d38b054144ad0a84d1b56", nonce: "22", blockHash: "0x6a87ab2575ddeed4df4adcae17c72a0e6eb60155815a3642cd5e5b10d1bb1de8", transactionIndex: "104", from: "0x06e9cf430221c06ace6345944038eaf21e7e85fa", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "65503", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000018", contractAddress: "", cumulativeGasUsed: "7621361", gasUsed: "65503", confirmations: "713327"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "24"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "24", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545930812 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x06e9cf430221c06ace6345944038eaf21e7e85fa"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000018"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: fund( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6968662", timeStamp: "1546010479", hash: "0xeba7c86e1445b3c0a7d2ba4af7d346ed97e9aceaa3f0796ebf968b3418922a7e", nonce: "0", blockHash: "0x532787debdc45ac592587d906b12f35b57e835051551c53b258c66eb442a555c", transactionIndex: "10", from: "0x99a8e2c1385be6dde6fe6dbaba52b89499415dda", to: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971", value: "10000000000000000", gas: "50503", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0xce347a650000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5709749", gasUsed: "50503", confirmations: "707886"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_day", value: "1"}], name: "fund", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fund(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1546010479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_contributor", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: true, name: "_day", type: "uint16"}], name: "LogTokensPurchased", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokensPurchased", events: [{name: "_contributor", type: "address", value: "0x99a8e2c1385be6dde6fe6dbaba52b89499415dda"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_day", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0xcca36039cfdd0753d3aa9f1b4bf35b606c8ed971"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "826298100000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7033240515364918401" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
