const TerraformReserve = artifacts.require( "./TerraformReserve.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TerraformReserve" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xCCA95E580BbbD04851EBFB85F77FD46C9b91f11C", "0x11d072f4fA63b4fe002731db50c1F17c931Dd670", "0x0F5D2fB29fb7d3CFeE444a200298f468908cC942", "0xee9E30fcE5F0b8e78F0a131AD91c2e496beFE889", "0xE705f7b08eb1a6b5119d3CD80B676172C7589EcB", "0x6ED8CD17EE5453E17eb731a6B2004aF53eA1f26a", "0x5DbcaEBe214A851A59253Aa2De1b657D72162396", "0x07Fe51d38d24D727F636A03e36FBFe64d9b93D3d", "0x54694Ce70c213dbE9169D545D94A688135b60240", "0x9DEBe18e89AC80A1825894de507bBc201f980C7C", "0xb739566aa9a4918B4736228FB6E1fE954cF6c436", "0x194DCD36b9bb245d23A3Ab9978ABeED686d4d99E", "0x4246Fe50186C57818160DC63f4B0E13D251578A3", "0x920fBA25c6e266930cA3fBaF958c0d5145CB6a50", "0x2D61BC51631E2845695FC1f0C9b953aD0c835A59", "0xe69F6106453d5Ea8DD813FB86c7E38ED6B8DCdD8", "0xc870267646650966f0C74eB43B00A6CF2A1eA132", "0xa925cA5B762d037357683250D33a4794c3D2A86f", "0x47a02f835f1fbDfBE45341DEe9aa0b8Da86d6a4b", "0x8aa43108d3685F6c3F10FC1c63ee35DC744FE81D", "0xea8DA8eA74971f0b2666B82a75bd0c255a2b9c4B", "0xD51A5dE939Ab52E1A1428d022D7fD0C30241310A", "0xe703f231aB056eCb99C92a1232cC1020ACFC72f8", "0x0f8b68ae0940314E1cFe948831E3F7E1c28F0D54", "0x1E138ACb3B9DB2F9Fa3f7C1BaE4BD8Ef4Da4200e", "0x827C1d889e3d85A4e6b771e98d8678FB3f0Bc89D", "0xa99FEB7b084eDEd2De4B51B37a31C1D8564c66A4", "0x9686B715c13A005C20eCC30B0BbC3e15e4203ac0", "0x5C70A7951d771f67EF52c5374D0442E7f0516057", "0xe3214C2ef2655d366161B92E85Aa1e9FF4C9A1bF", "0x1C3B20c12Decc473aC0E897a4C1625C71B655427", "0xa5dA57311bC233B112Ab817c732804D2a4c0297c", "0xF11dE9f660c2Bba83771d7DAb1A8e3d8816cF1D2", "0x431Aaa37A3134Ce0c520F2fB6Fa96cB1a5B18A79", "0xFAe8D67cb17034365480568C351148e52044Cd09", "0x7151fC80479caE33a33397a507257ff70dAdA0A1", "0xfFfc3acE60051d7b09E78cd329D7003711C2Ed0C", "0xBD46378F0abAbaE3B59420b640Cc8A3D4A417a17", "0xb23ac74C4C50De1b1722c3575061267F66A628F9", "0x5DacBDD20B9eAFAaA30BFAD3B2Af1793036D65f3", "0x84D96968235A6A60d4F7BFAA77112bCF02e739ca", "0x1255B77FF2cc2D3543ca100de03266E60e96019a", "0x9174041c14E680790d7aDa3daf5E33851C3dE9f6", "0xbA9a7BF08Aad49E3c46a6A9Cef85ecc42b0B1CfB", "0xe3a576E1E3f0d8519B617C01191712d8658Ec96A", "0x3c0ccC803468F8b071fCc27B192752dAbC625755", "0xc81d30440C361135CC53b17834418bfB5a293Bbf", "0xeb4c20B3318F76766bDF5F91451487B75843a986", "0xF90b358824095281709681c99dc53946941d79Bb", "0x6E129C4BEF43EB234A10B969F15Bc564511BeC6C", "0x0Bb75bEf057da63a0ae4B25fe9aDaFd35cd92B87"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "totalLocked", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "manaToken", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "landClaim", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "lockedBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "acceptingDeposits", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "target", type: "address"}], name: "LandClaimContractSet", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "LandClaimExecuted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_acceptingDeposits", type: "bool"}], name: "AcceptingDepositsChanged", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LockedBalance(address,uint256)", "LandClaimContractSet(address)", "LandClaimExecuted(address,uint256,bytes)", "AcceptingDepositsChanged(bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xebfb816221eaf798e256b970818c54755242a19e3e1a2b5b2060f9d22ecbf46d", "0x53e0b78f8befdee4500f015571e9fc9e272eea929617a296cc4dfbd6f94ab7a9", "0x2d4e4472321d4584d854885fee42f303ddb35b089283fda947924b7bd6510126", "0xf3c7809150929110a2f541a06b6e5504f96d2a64b6d23a11af57dceda35a6f2a"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4321454 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4322818 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}], name: "TerraformReserve", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "totalLocked", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalLocked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "manaToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "manaToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "landClaim", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "landClaim()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "lockedBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockedBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "acceptingDeposits", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "acceptingDeposits()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TerraformReserve", function( accounts ) {

	it( "TEST: TerraformReserve( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4321454", timeStamp: "1506676159", hash: "0xb8afa58bb39acd6d519c6b1d1f6fceb5563a10336ad1308bc90a8a20d1e3c7fa", nonce: "289", blockHash: "0x0a989ad83a89295795f9cc128dd00be1e6b430a86137cce4bbf66c3f015fb0b7", transactionIndex: "97", from: "0x11d072f4fa63b4fe002731db50c1f17c931dd670", to: 0, value: "0", gas: "2000000", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xcc66ec470000000000000000000000000f5d2fb29fb7d3cfee444a200298f468908cc942", contractAddress: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", cumulativeGasUsed: "4153967", gasUsed: "517533", confirmations: "3388872"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}], name: "TerraformReserve", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TerraformReserve.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1506676159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TerraformReserve.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "383976687614683800" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[6], \"1100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0x9d3ade712e2db80bf891c5668ff8165de9b4e38a6f8a4164423c32eb2c9b4bf5", nonce: "0", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "93", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000e705f7b08eb1a6b5119d3cd80b676172c7589ecb0000000000000000000000000000000000000000000002544faa778090e00000", contractAddress: "", cumulativeGasUsed: "3765546", gasUsed: "72444", confirmations: "3387605"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[6]}, {type: "uint256", name: "mana", value: "11000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[6], "11000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xe705f7b08eb1a6b5119d3cd80b676172c7589ecb"}, {name: "mana", type: "uint256", value: "11000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[7], \"2000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0x038030477e97e41e0f96214c559b55d3fe39f4d284da7214ffa71552572a79ad", nonce: "1", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "94", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000006ed8cd17ee5453e17eb731a6b2004af53ea1f26a00000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "3822862", gasUsed: "57316", confirmations: "3387605"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[7]}, {type: "uint256", name: "mana", value: "2000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[7], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x6ed8cd17ee5453e17eb731a6b2004af53ea1f26a"}, {name: "mana", type: "uint256", value: "2000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[8], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0x4d54c98217e6aea05a930aec686899dd9558727d195db9f716c734646e4f002b", nonce: "2", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "95", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000005dbcaebe214a851a59253aa2de1b657d7216239600000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "3865242", gasUsed: "42380", confirmations: "3387605"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[8]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[8], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x5dbcaebe214a851a59253aa2de1b657d72162396"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[9], \"2000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0x06be2cf6561c4cbb22f6c507e40cb6f4240492476a6d4c51cc355e38ad605c42", nonce: "3", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "96", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d700000000000000000000000007fe51d38d24d727f636a03e36fbfe64d9b93d3d00000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "3922622", gasUsed: "57380", confirmations: "3387605"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[9]}, {type: "uint256", name: "mana", value: "2000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[9], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x07fe51d38d24d727f636a03e36fbfe64d9b93d3d"}, {name: "mana", type: "uint256", value: "2000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[10], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0xa2702e9dcb72f9fc36672b3c3fb20892d580825890f5380f1f95da1dd0dd5c5b", nonce: "4", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "97", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d700000000000000000000000054694ce70c213dbe9169d545d94a688135b6024000000000000000000000000000000000000000000000032d26d12e980b600000", contractAddress: "", cumulativeGasUsed: "3965066", gasUsed: "42444", confirmations: "3387605"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[10]}, {type: "uint256", name: "mana", value: "15000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[10], "15000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x54694ce70c213dbe9169d545d94a688135b60240"}, {name: "mana", type: "uint256", value: "15000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[11], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0x9cfa371a03db6fec37898b2f90e32363efb966b6b8cdfb133751f29b652ae3b8", nonce: "5", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "98", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000009debe18e89ac80a1825894de507bbc201f980c7c00000000000000000000000000000000000000000000010f0cf064dd59200000", contractAddress: "", cumulativeGasUsed: "4022510", gasUsed: "57444", confirmations: "3387605"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[11]}, {type: "uint256", name: "mana", value: "5000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[11], "5000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x9debe18e89ac80a1825894de507bbc201f980c7c"}, {name: "mana", type: "uint256", value: "5000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[12], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0x9f4af28e72c9216ec95c4cbfd82116438821b3cd1e05f51512f1e8148573dac4", nonce: "6", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "99", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000b739566aa9a4918b4736228fb6e1fe954cf6c43600000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "4079890", gasUsed: "57380", confirmations: "3387605"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[12]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[12], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xb739566aa9a4918b4736228fb6e1fe954cf6c436"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[13], \"800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322721", timeStamp: "1506713935", hash: "0xec837da4b325efb59ad02ca61446eb8fdc1502a6528b5fffa803ceb19c65ba54", nonce: "7", blockHash: "0xddff1b42482ee871edef163ca498d2848207ec9e6d985c94c60e68b145a18188", transactionIndex: "100", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000194dcd36b9bb245d23a3ab9978abeed686d4d99e0000000000000000000000000000000000000000000001b1ae4d6e2ef5000000", contractAddress: "", cumulativeGasUsed: "4152270", gasUsed: "72380", confirmations: "3387605"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "uint256", name: "mana", value: "8000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[13], "8000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1506713935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x194dcd36b9bb245d23a3ab9978abeed686d4d99e"}, {name: "mana", type: "uint256", value: "8000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[14], \"800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322722", timeStamp: "1506713937", hash: "0x1971fde84e8597d1e912d290936f75b9d1c9451e9344f0ba2cfd2cc09091cbd1", nonce: "8", blockHash: "0xced1a0ebae53106b0f946cd7dba86904f550ef78a88b443eaa9306895568d80c", transactionIndex: "6", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000004246fe50186c57818160dc63f4b0e13d251578a30000000000000000000000000000000000000000000001b1ae4d6e2ef5000000", contractAddress: "", cumulativeGasUsed: "397380", gasUsed: "42380", confirmations: "3387604"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[14]}, {type: "uint256", name: "mana", value: "8000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[14], "8000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1506713937 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x4246fe50186c57818160dc63f4b0e13d251578a3"}, {name: "mana", type: "uint256", value: "8000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[15], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322723", timeStamp: "1506713943", hash: "0x835ae73977af807638bf47de66af978335f127ad85739d8fb709cdf680b7e7c0", nonce: "9", blockHash: "0x9f248b325a798e5e927cce6b0818fc805dcb01103ca503cd2cb1bf3a74b23d94", transactionIndex: "3", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000920fba25c6e266930ca3fbaf958c0d5145cb6a500000000000000000000000000000000000000000000000d8d726b7177a800000", contractAddress: "", cumulativeGasUsed: "120380", gasUsed: "57380", confirmations: "3387603"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[15]}, {type: "uint256", name: "mana", value: "4000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[15], "4000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1506713943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x920fba25c6e266930ca3fbaf958c0d5145cb6a50"}, {name: "mana", type: "uint256", value: "4000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[16], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322724", timeStamp: "1506714056", hash: "0xa36ee0cca969f3461a1e2d325fe4caf9bf4e815bb8cdd05576114399248f2848", nonce: "10", blockHash: "0x3564b56132e20bd2264cbb761255792fa7ac7587e101979eea285fc216e92a11", transactionIndex: "65", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000002d61bc51631e2845695fc1f0c9b953ad0c835a5900000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "3234722", gasUsed: "57380", confirmations: "3387602"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[16]}, {type: "uint256", name: "mana", value: "2000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[16], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1506714056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x2d61bc51631e2845695fc1f0c9b953ad0c835a59"}, {name: "mana", type: "uint256", value: "2000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[17], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322726", timeStamp: "1506714200", hash: "0xa1177962b388eeb8b8becaa4406caed2114764e2d1a2623a225780c4b4f5a81b", nonce: "11", blockHash: "0x54288cc3b81d4b2069c6f46157aa30b911795a33fc864c13ca0b68ce86d20d71", transactionIndex: "106", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000e69f6106453d5ea8dd813fb86c7e38ed6b8dcdd800000000000000000000000000000000000000000000043c33c1937564800000", contractAddress: "", cumulativeGasUsed: "6494700", gasUsed: "57444", confirmations: "3387600"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[17]}, {type: "uint256", name: "mana", value: "20000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[17], "20000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1506714200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xe69f6106453d5ea8dd813fb86c7e38ed6b8dcdd8"}, {name: "mana", type: "uint256", value: "20000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[18], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322727", timeStamp: "1506714218", hash: "0x5e250ed573b5d690fca33f0c6e2e959e9231fdf23b9268b3a0c2d383ba6e3232", nonce: "12", blockHash: "0x95a86d0f41c8b5b2a3e92fd8e232c2ee46535ba1153107b4f4a4a4117dd59321", transactionIndex: "34", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000c870267646650966f0c74eb43b00a6cf2a1ea1320000000000000000000000000000000000000000000000a2a15d09519be00000", contractAddress: "", cumulativeGasUsed: "3306504", gasUsed: "72316", confirmations: "3387599"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[18]}, {type: "uint256", name: "mana", value: "3000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[18], "3000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1506714218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xc870267646650966f0c74eb43b00a6cf2a1ea132"}, {name: "mana", type: "uint256", value: "3000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[19], \"800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322727", timeStamp: "1506714218", hash: "0xe16c40f84d2bbfae51c2cd3f835ceda52c1890a6f352f92830845f8f69ee2bb9", nonce: "13", blockHash: "0x95a86d0f41c8b5b2a3e92fd8e232c2ee46535ba1153107b4f4a4a4117dd59321", transactionIndex: "129", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000a925ca5b762d037357683250d33a4794c3d2a86f0000000000000000000000000000000000000000000001b1ae4d6e2ef5000000", contractAddress: "", cumulativeGasUsed: "5879542", gasUsed: "42380", confirmations: "3387599"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[19]}, {type: "uint256", name: "mana", value: "8000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[19], "8000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1506714218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xa925ca5b762d037357683250d33a4794c3d2a86f"}, {name: "mana", type: "uint256", value: "8000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[20], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322774", timeStamp: "1506715465", hash: "0x1ef8da194b6cee18369eb00564daf7fae5813d55f33ad1a203efad1d43a63b90", nonce: "14", blockHash: "0xd9882c2d14b7799c20c060bc012d3a9e5313d63d33a39f1f494fceb6aceb9a6f", transactionIndex: "25", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d700000000000000000000000047a02f835f1fbdfbe45341dee9aa0b8da86d6a4b00000000000000000000000000000000000000000000043c33c1937564800000", contractAddress: "", cumulativeGasUsed: "1204203", gasUsed: "57444", confirmations: "3387552"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[20]}, {type: "uint256", name: "mana", value: "20000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[20], "20000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1506715465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x47a02f835f1fbdfbe45341dee9aa0b8da86d6a4b"}, {name: "mana", type: "uint256", value: "20000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[21], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322776", timeStamp: "1506715528", hash: "0x7b933a7efb065a4e415ea1933f430450e564b00152f69aa7ce6e8c0f243aa7b6", nonce: "15", blockHash: "0x02fabb97c8849b3360a8969759e0e25825d4d0746f76e04857ffdea183663960", transactionIndex: "30", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000008aa43108d3685f6c3f10fc1c63ee35dc744fe81d00000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "2021274", gasUsed: "72380", confirmations: "3387550"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[21]}, {type: "uint256", name: "mana", value: "2000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[21], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1506715528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x8aa43108d3685f6c3f10fc1c63ee35dc744fe81d"}, {name: "mana", type: "uint256", value: "2000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[22], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322777", timeStamp: "1506715616", hash: "0x56d292b6d2837de2f45845f9441b1ca36dbff32fd02a4b41f25ba958f025836c", nonce: "16", blockHash: "0x6b21673a24232827be57fe02f2ac625084b3dacdbd776ef78d990408c8097a5e", transactionIndex: "73", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000ea8da8ea74971f0b2666b82a75bd0c255a2b9c4b00000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "3541804", gasUsed: "57380", confirmations: "3387549"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[22]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[22], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1506715616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xea8da8ea74971f0b2666b82a75bd0c255a2b9c4b"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[23], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322778", timeStamp: "1506715632", hash: "0x0dafaadc64dc12a79bd121f82f0982791756e7819a7dd7cd2040cea8c3b36978", nonce: "17", blockHash: "0x092bd83f642eb3c6cab8fc33479ce73be13fc31ca8229681950acd0215a50720", transactionIndex: "18", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000d51a5de939ab52e1a1428d022d7fd0c30241310a000000000000000000000000000000000000000000003f870857a3e0e3800000", contractAddress: "", cumulativeGasUsed: "1404832", gasUsed: "120000", confirmations: "3387548"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[23]}, {type: "uint256", name: "mana", value: "300000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[24], \"750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322779", timeStamp: "1506715685", hash: "0xc05a45ef5fd0bbdd505917f6cacc949bbebf27f24a7c8ca75e2e2c0048a8c27d", nonce: "18", blockHash: "0x2d14cca5fd054867ae7daea855b7279998a4b6342f8b040a75489737e37ac78c", transactionIndex: "44", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000e703f231ab056ecb99c92a1232cc1020acfc72f8000000000000000000000000000000000000000000000fe1c215e8f838e00000", contractAddress: "", cumulativeGasUsed: "2611413", gasUsed: "57444", confirmations: "3387547"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[24]}, {type: "uint256", name: "mana", value: "75000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[24], "75000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1506715685 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xe703f231ab056ecb99c92a1232cc1020acfc72f8"}, {name: "mana", type: "uint256", value: "75000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[25], \"140000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322782", timeStamp: "1506715731", hash: "0x2673dee247971f6e14ba6ef5c64dc6c7ec0c7e444f00fc4c4a424ab534e5e1d5", nonce: "19", blockHash: "0x70568baf98d6c65a8025edd462f076b9a2855d08117aa73758cb7a32e2deba5c", transactionIndex: "27", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000000f8b68ae0940314e1cfe948831e3f7e1c28f0d540000000000000000000000000000000000000000000002f6f10780d22cc00000", contractAddress: "", cumulativeGasUsed: "1664301", gasUsed: "57444", confirmations: "3387544"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[25]}, {type: "uint256", name: "mana", value: "14000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[25], "14000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1506715731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x0f8b68ae0940314e1cfe948831e3f7e1c28f0d54"}, {name: "mana", type: "uint256", value: "14000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[26], \"401000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322782", timeStamp: "1506715731", hash: "0x233f927b30ee3e617b63d40a6dbdea56f06d3ef69675dacadca661c1900bee64", nonce: "20", blockHash: "0x70568baf98d6c65a8025edd462f076b9a2855d08117aa73758cb7a32e2deba5c", transactionIndex: "74", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000001e138acb3b9db2f9fa3f7c1bae4bd8ef4da4200e0000000000000000000000000000000000000000000054ea40e932f1b8a00000", contractAddress: "", cumulativeGasUsed: "4509026", gasUsed: "57444", confirmations: "3387544"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[26]}, {type: "uint256", name: "mana", value: "401000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[26], "401000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1506715731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x1e138acb3b9db2f9fa3f7c1bae4bd8ef4da4200e"}, {name: "mana", type: "uint256", value: "401000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[27], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322782", timeStamp: "1506715731", hash: "0xed19743a7bc4600caca0b96efb828798abdee5d7e1aed45421771bfa53fcc089", nonce: "21", blockHash: "0x70568baf98d6c65a8025edd462f076b9a2855d08117aa73758cb7a32e2deba5c", transactionIndex: "92", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000827c1d889e3d85a4e6b771e98d8678fb3f0bc89d00000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "5960574", gasUsed: "72380", confirmations: "3387544"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[27]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[27], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1506715731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x827c1d889e3d85a4e6b771e98d8678fb3f0bc89d"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[28], \"250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322797", timeStamp: "1506716228", hash: "0x1db0e0bb510d36c74ef38b9b8b266da40907dd9a4c6e7c028b96689f8223ed96", nonce: "22", blockHash: "0x488180247008c8cd039163d39ccbf1850c0f52cee3c6031415fa78e1292a992c", transactionIndex: "56", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000a99feb7b084eded2de4b51b37a31c1d8564c66a400000000000000000000000000000000000000000000054b40b1f852bda00000", contractAddress: "", cumulativeGasUsed: "3095226", gasUsed: "57444", confirmations: "3387529"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[28]}, {type: "uint256", name: "mana", value: "25000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[28], "25000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1506716228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xa99feb7b084eded2de4b51b37a31c1d8564c66a4"}, {name: "mana", type: "uint256", value: "25000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[29], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322799", timeStamp: "1506716264", hash: "0xd8e9c14675648fdef3573190d439775f8e55027e1186028c71525cbf06ea99ee", nonce: "23", blockHash: "0x0198fc1891e84ccb0ec3951fc58f4038bc700a7431737a185e75327b8f1bbe16", transactionIndex: "46", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000009686b715c13a005c20ecc30b0bbc3e15e4203ac000000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "1526678", gasUsed: "72380", confirmations: "3387527"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[29]}, {type: "uint256", name: "mana", value: "10000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[29], "10000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1506716264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x9686b715c13a005c20ecc30b0bbc3e15e4203ac0"}, {name: "mana", type: "uint256", value: "10000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[30], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322800", timeStamp: "1506716297", hash: "0x51026a3f72d25825cfe09b19305318a04a9cacee907827eb41b0ccedceaf88de", nonce: "24", blockHash: "0x1bfcc69c01cbee84d6fe077b62dff97ecacd0af14a6cda13565cc3d105134e75", transactionIndex: "71", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000005c70a7951d771f67ef52c5374d0442e7f051605700000000000000000000000000000000000000000000152d02c7e14af6800000", contractAddress: "", cumulativeGasUsed: "2745110", gasUsed: "57444", confirmations: "3387526"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[30]}, {type: "uint256", name: "mana", value: "100000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[30], "100000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1506716297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x5c70a7951d771f67ef52c5374d0442e7f0516057"}, {name: "mana", type: "uint256", value: "100000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[31], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322803", timeStamp: "1506716383", hash: "0xa9cfb38d10fc292b9dcd8de305a7a1158e0f3740b49cd8d6b9376369efb518ac", nonce: "25", blockHash: "0xf10ebfc164f9462da1e794928a7583d2e9df4c1c601a9db8f08d1cdb17d382f1", transactionIndex: "30", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000e3214c2ef2655d366161b92e85aa1e9ff4c9a1bf00000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "1817784", gasUsed: "42380", confirmations: "3387523"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[31]}, {type: "uint256", name: "mana", value: "2000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[31], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1506716383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xe3214c2ef2655d366161b92e85aa1e9ff4c9a1bf"}, {name: "mana", type: "uint256", value: "2000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[32], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322805", timeStamp: "1506716419", hash: "0xb8b2417725891e5450282e3d04a21d793f661e52b13964daa12c380297cd82af", nonce: "26", blockHash: "0xd24cd9a8ee2861e013c7f8a35cdde41ce62eb394ed6d7476b20544743c60b8cd", transactionIndex: "81", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000001c3b20c12decc473ac0e897a4c1625c71b655427000000000000000000000000000000000000000000000a968163f0a57b400000", contractAddress: "", cumulativeGasUsed: "6634762", gasUsed: "57444", confirmations: "3387521"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[32]}, {type: "uint256", name: "mana", value: "50000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[32], "50000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1506716419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x1c3b20c12decc473ac0e897a4c1625c71b655427"}, {name: "mana", type: "uint256", value: "50000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[33], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322806", timeStamp: "1506716423", hash: "0xc0da1dcb8c556a0eaa57ed5a531964b4cbcda4455e334dbbc0adccf184b3d212", nonce: "27", blockHash: "0xe4f33b4637dc29aee6807c6d7898f41b06eed71810a5e23de10ce753f41637d6", transactionIndex: "186", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000a5da57311bc233b112ab817c732804d2a4c0297c00000000000000000000000000000000000000000000043c33c1937564800000", contractAddress: "", cumulativeGasUsed: "5969037", gasUsed: "57444", confirmations: "3387520"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[33]}, {type: "uint256", name: "mana", value: "20000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[33], "20000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1506716423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xa5da57311bc233b112ab817c732804d2a4c0297c"}, {name: "mana", type: "uint256", value: "20000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[13], \"800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322806", timeStamp: "1506716423", hash: "0x19c0d17f56b5cac0081009347dade8e85c000ec912a13e5159265baf23fca979", nonce: "28", blockHash: "0xe4f33b4637dc29aee6807c6d7898f41b06eed71810a5e23de10ce753f41637d6", transactionIndex: "187", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000194dcd36b9bb245d23a3ab9978abeed686d4d99e0000000000000000000000000000000000000000000001b1ae4d6e2ef5000000", contractAddress: "", cumulativeGasUsed: "6089037", gasUsed: "120000", confirmations: "3387520"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "uint256", name: "mana", value: "8000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[34], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322806", timeStamp: "1506716423", hash: "0x6694ab5f92abc7647b7fe4b8b5ce2957b047433bc80823606f5d7efd5c9f4428", nonce: "29", blockHash: "0xe4f33b4637dc29aee6807c6d7898f41b06eed71810a5e23de10ce753f41637d6", transactionIndex: "188", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000f11de9f660c2bba83771d7dab1a8e3d8816cf1d200000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "6146417", gasUsed: "57380", confirmations: "3387520"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[34]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[34], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1506716423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xf11de9f660c2bba83771d7dab1a8e3d8816cf1d2"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[35], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322806", timeStamp: "1506716423", hash: "0x3e053e667723d498ddf6f19626997bd635e4c34fda861c9070f8345782627806", nonce: "30", blockHash: "0xe4f33b4637dc29aee6807c6d7898f41b06eed71810a5e23de10ce753f41637d6", transactionIndex: "189", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000431aaa37a3134ce0c520f2fb6fa96cb1a5b18a7900000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "6203797", gasUsed: "57380", confirmations: "3387520"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[35]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[35], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1506716423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x431aaa37a3134ce0c520f2fb6fa96cb1a5b18a79"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[36], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322808", timeStamp: "1506716481", hash: "0xce07b0264a112d84cfd4e2458f4bf8735b7f819f910a0602476dd4af9a6a47e0", nonce: "31", blockHash: "0x317f83c3bddbd6c8f1b5d9276704bea3c98c09379bc9860ef8b8b2e05456da72", transactionIndex: "55", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000fae8d67cb17034365480568c351148e52044cd0900000000000000000000000000000000000000000000043c33c1937564800000", contractAddress: "", cumulativeGasUsed: "2916381", gasUsed: "42444", confirmations: "3387518"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[36]}, {type: "uint256", name: "mana", value: "20000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[36], "20000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1506716481 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xfae8d67cb17034365480568c351148e52044cd09"}, {name: "mana", type: "uint256", value: "20000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[37], \"140000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322811", timeStamp: "1506716495", hash: "0x8e226f3af3e968af24e4236e33e4cbe4f71c4cda751d9af3bc96925d9467acb0", nonce: "32", blockHash: "0x52d4ab3e85d32c46bfc9061aef14abd455f7f571d7817dafc0155cc8f1ee504b", transactionIndex: "52", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000007151fc80479cae33a33397a507257ff70dada0a10000000000000000000000000000000000000000000002f6f10780d22cc00000", contractAddress: "", cumulativeGasUsed: "2178821", gasUsed: "57444", confirmations: "3387515"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[37]}, {type: "uint256", name: "mana", value: "14000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[37], "14000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1506716495 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x7151fc80479cae33a33397a507257ff70dada0a1"}, {name: "mana", type: "uint256", value: "14000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[38], \"900000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322814", timeStamp: "1506716550", hash: "0x13cd0a475961fee788709157a49ee89dea1226069ad85019e37d6685dd2e5dff", nonce: "33", blockHash: "0xf79898517960cfb537e87c0435d4f6944ec32a68f5649ef8160fe743edf2106d", transactionIndex: "10", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000fffc3ace60051d7b09e78cd329d7003711c2ed0c0000000000000000000000000000000000000000000001e7e4171bf4d3a00000", contractAddress: "", cumulativeGasUsed: "924853", gasUsed: "57380", confirmations: "3387512"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[38]}, {type: "uint256", name: "mana", value: "9000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[38], "9000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1506716550 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xfffc3ace60051d7b09e78cd329d7003711c2ed0c"}, {name: "mana", type: "uint256", value: "9000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[39], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0xdfc039f8923beb345a6e7fa86d6b40b26b6246d9fe6be5ab630a5977fa8bf082", nonce: "34", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "75", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000bd46378f0ababae3b59420b640cc8a3d4a417a1700000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "3321188", gasUsed: "57444", confirmations: "3387509"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[39]}, {type: "uint256", name: "mana", value: "10000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[39], "10000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1506716619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xbd46378f0ababae3b59420b640cc8a3d4a417a17"}, {name: "mana", type: "uint256", value: "10000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[40], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x46f14019e0b44f400cb88bb3f23dacd7c48ec21ea323e5bd1400827cc9ced2a7", nonce: "35", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "92", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000b23ac74c4c50de1b1722c3575061267f66a628f9000000000000000000000000000000000000000000000a968163f0a57b400000", contractAddress: "", cumulativeGasUsed: "4295650", gasUsed: "57444", confirmations: "3387509"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[40]}, {type: "uint256", name: "mana", value: "50000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[40], "50000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1506716619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xb23ac74c4c50de1b1722c3575061267f66a628f9"}, {name: "mana", type: "uint256", value: "50000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[41], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x1f2980721efd01097cf9b2529ee5c8428124204514f479263e10cc0717dc4dde", nonce: "36", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "102", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000005dacbdd20b9eafaaa30bfad3b2af1793036d65f300000000000000000000000000000000000000000000065a4da25d3016c00000", contractAddress: "", cumulativeGasUsed: "4972267", gasUsed: "57444", confirmations: "3387509"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[41]}, {type: "uint256", name: "mana", value: "30000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[41], "30000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1506716619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x5dacbdd20b9eafaaa30bfad3b2af1793036d65f3"}, {name: "mana", type: "uint256", value: "30000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[42], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x489c71831c3a4703544553f6f461a297279aa9aec3479344cb31576ca92a6efb", nonce: "37", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "110", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d700000000000000000000000084d96968235a6a60d4f7bfaa77112bcf02e739ca00000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "5472958", gasUsed: "57380", confirmations: "3387509"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[42]}, {type: "uint256", name: "mana", value: "2000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[42], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1506716619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x84d96968235a6a60d4f7bfaa77112bcf02e739ca"}, {name: "mana", type: "uint256", value: "2000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[43], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x2adbdc6f91193994c18cb904f885989ec39dff8ab13ecd0937809b4025c845d2", nonce: "38", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "115", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000001255b77ff2cc2d3543ca100de03266e60e96019a00000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "5847192", gasUsed: "57380", confirmations: "3387509"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[43]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[43], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1506716619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x1255b77ff2cc2d3543ca100de03266e60e96019a"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[44], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x61d714d2e3db0129cb2002448fba325ef3dfad296af33a9b5b54de5c3801be16", nonce: "39", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "123", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000009174041c14e680790d7ada3daf5e33851c3de9f600000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "6112616", gasUsed: "57380", confirmations: "3387509"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[44]}, {type: "uint256", name: "mana", value: "2000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[44], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1506716619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x9174041c14e680790d7ada3daf5e33851c3de9f6"}, {name: "mana", type: "uint256", value: "2000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[45], \"110000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x712aaa2af535e8a30cd6632ac1dfae8bcb7853e274a887b88091cb906a407768", nonce: "40", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "125", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000ba9a7bf08aad49e3c46a6a9cef85ecc42b0b1cfb0000000000000000000000000000000000000000000002544faa778090e00000", contractAddress: "", cumulativeGasUsed: "6269138", gasUsed: "120000", confirmations: "3387509"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[45]}, {type: "uint256", name: "mana", value: "11000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[46], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x4f81979d0a13816462bb1461893a922538c0269e537c000c0a9044d1497f5486", nonce: "41", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "129", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000e3a576e1e3f0d8519b617c01191712d8658ec96a00000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "6389582", gasUsed: "57444", confirmations: "3387509"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[46]}, {type: "uint256", name: "mana", value: "10000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[46], "10000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1506716619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xe3a576e1e3f0d8519b617c01191712d8658ec96a"}, {name: "mana", type: "uint256", value: "10000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[32], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322817", timeStamp: "1506716619", hash: "0x2416e63026b503171f4813d2216509e26677c31647304749ec87d45d1df53bf2", nonce: "42", blockHash: "0xbdb0355fd76a99b70a87f44503c55c34f26a980203bdcccc46741063429f954e", transactionIndex: "132", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x6b7006d70000000000000000000000001c3b20c12decc473ac0e897a4c1625c71b65542700000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "6567104", gasUsed: "120000", confirmations: "3387509"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[32]}, {type: "uint256", name: "mana", value: "10000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[47], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322818", timeStamp: "1506716630", hash: "0xacf235ae51336722a67ba54eb65f77c9b01af47fa224c4476674c45936adc8a7", nonce: "43", blockHash: "0x857f27879e6bcc807fd365b2b4ec869b9549127b26b485905ac6c86e14b9369f", transactionIndex: "12", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000003c0ccc803468f8b071fcc27b192752dabc62575500000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "631780", gasUsed: "57380", confirmations: "3387508"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[47]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[47], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1506716630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x3c0ccc803468f8b071fcc27b192752dabc625755"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[48], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322818", timeStamp: "1506716630", hash: "0xb8d526f359a5326a45dce7f86f7b62b73f888caf638d8af9c958e3035fb8fede", nonce: "44", blockHash: "0x857f27879e6bcc807fd365b2b4ec869b9549127b26b485905ac6c86e14b9369f", transactionIndex: "13", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000c81d30440c361135cc53b17834418bfb5a293bbf000000000000000000000000000000000000000000000a968163f0a57b400000", contractAddress: "", cumulativeGasUsed: "689224", gasUsed: "57444", confirmations: "3387508"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[48]}, {type: "uint256", name: "mana", value: "50000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[48], "50000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1506716630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xc81d30440c361135cc53b17834418bfb5a293bbf"}, {name: "mana", type: "uint256", value: "50000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[49], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322818", timeStamp: "1506716630", hash: "0x7ed522bdd2ab2daa513a22d059721932f18a584152e06bbd178f7419052126c0", nonce: "45", blockHash: "0x857f27879e6bcc807fd365b2b4ec869b9549127b26b485905ac6c86e14b9369f", transactionIndex: "14", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000eb4c20b3318f76766bdf5f91451487b75843a98600000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "746604", gasUsed: "57380", confirmations: "3387508"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[49]}, {type: "uint256", name: "mana", value: "1000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[49], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1506716630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xeb4c20b3318f76766bdf5f91451487b75843a986"}, {name: "mana", type: "uint256", value: "1000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[50], \"350000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322818", timeStamp: "1506716630", hash: "0x2523ad389eb7ad0e6f78146010d6323de35bfe9842a713a5fa497d6924cb9301", nonce: "46", blockHash: "0x857f27879e6bcc807fd365b2b4ec869b9549127b26b485905ac6c86e14b9369f", transactionIndex: "15", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d7000000000000000000000000f90b358824095281709681c99dc53946941d79bb0000000000000000000000000000000000000000000007695a92c20d6fe00000", contractAddress: "", cumulativeGasUsed: "804048", gasUsed: "57444", confirmations: "3387508"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[50]}, {type: "uint256", name: "mana", value: "35000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[50], "35000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1506716630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0xf90b358824095281709681c99dc53946941d79bb"}, {name: "mana", type: "uint256", value: "35000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[51], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322818", timeStamp: "1506716630", hash: "0x4149ec79fe1400da7dda7fbba68daff2d649c7d01817e4ebd5dded1c201d2b7b", nonce: "47", blockHash: "0x857f27879e6bcc807fd365b2b4ec869b9549127b26b485905ac6c86e14b9369f", transactionIndex: "16", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000006e129c4bef43eb234a10b969f15bc564511bec6c0000000000000000000000000000000000000000000000d8d726b7177a800000", contractAddress: "", cumulativeGasUsed: "861428", gasUsed: "57380", confirmations: "3387508"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[51]}, {type: "uint256", name: "mana", value: "4000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[51], "4000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1506716630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x6e129c4bef43eb234a10b969f15bc564511bec6c"}, {name: "mana", type: "uint256", value: "4000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: lockMana( addressList[52], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4322818", timeStamp: "1506716630", hash: "0x58f0b57919ff970956a616be33f1726c75b5c2e0eaa7331f501bc2d4433cf34c", nonce: "48", blockHash: "0x857f27879e6bcc807fd365b2b4ec869b9549127b26b485905ac6c86e14b9369f", transactionIndex: "17", from: "0xee9e30fce5f0b8e78f0a131ad91c2e496befe889", to: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c", value: "0", gas: "120000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6b7006d70000000000000000000000000bb75bef057da63a0ae4b25fe9adafd35cd92b8700000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "918872", gasUsed: "57444", confirmations: "3387508"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[52]}, {type: "uint256", name: "mana", value: "10000000000000000000000"}], name: "lockMana", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockMana(address,uint256)" ]( addressList[52], "10000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1506716630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "mana", type: "uint256"}], name: "LockedBalance", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LockedBalance", events: [{name: "user", type: "address", value: "0x0bb75bef057da63a0ae4b25fe9adafd35cd92b87"}, {name: "mana", type: "uint256", value: "10000000000000000000000"}], address: "0xcca95e580bbbd04851ebfb85f77fd46c9b91f11c"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "776778950287396510" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
