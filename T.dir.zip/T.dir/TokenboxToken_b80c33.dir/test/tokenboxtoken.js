const TokenboxToken = artifacts.require( "./TokenboxToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TokenboxToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x4B24f0C8230C06e0D7caF722aCe3f22BA5b80c33", "0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF", "0x1111111111111111111111111111111111111111", "0x2222222222222222222222222222222222222222", "0xBA091db085EAC2055400C934c8dc989B500113a2", "0x9db07C8da33A2FCd6Ef2E727a2EcC5198d9BC7c8", "0xAd8eA3B0215e6efd9d2F2AA22bAF6d494DbF7662", "0x2f2466cF8BA78119E66B860143cd47d48A77fb69", "0x7e5cE10826eE167de897D262fCC9976F609ECd2B", "0x41103544fa950378618B9b6496fA355BEcffaC23", "0x882B32D5AD4Fe21D581049A95d710Fa66f1B8053", "0x32Bf5dfeb37eAA7E6fd8Ee148712F4364D6F941e", "0x0aD9Fb61a07BAC25625382B63693644497f1B204", "0x9F943Cc255b1D1475eb8b050E5c3Ce1c0Ff07d84", "0xEAA18aA58d6327a39334c6c5890CD972e06D428e", "0xB3B5b2A7D19BeD40Dd908a238536609C509A53E2", "0x9Acf50AB22004cf09b2461C71447f1d776188fa8", "0xdD6e34eABfb4f1691AF7d3180243649BE50d7C81", "0x081c08a6D3dAAe19599B6AC17836B17FDBb70C6f", "0xB431e8B22fe44e373f00d82bf6b3C6020cF295aa", "0x2bA6e55b6Ec4f998F1ab1Fb912DBa30fadd15E3A", "0x4EB03162D506Acba7a9C25A6042C59fcE6594d37", "0xeE471E97c7CC2630675069a649E191F52C240fC8", "0xB9Ac4c66ECfc0069D44f812344B085a92a9E64ed", "0x113277849a9e06F6E2a10c5F1f43945c7AA65F5A", "0x1aD68BD2f0c2F734fb710A0Fb97f14A468B2BD57", "0x8E5b7B6b82486264B9F812Ff75A9525FA337b05a", "0xa8bCa83967ACF16319E56396278ce36d9B84def0", "0x91b8c82bb797922B4e0a2837A60147d15eC13B34", "0xBC9d3654dAa986E10a45727eFD26529011889734", "0x007254A766d6034bAD30AC467F4956f7fdff4BCe", "0xaE28CaB1F51040AA0F7eeDAfEF7d6d8c6d47a6be", "0x7d715A33de1EeB55e4256Df7305706378E3EE93A", "0xFb5a9e8b362CA6834e999A126352AC9D957da747", "0x1Bb50952006fbb3C64ec2bC41B9FCF3F17fC436a", "0xC9212Ef53B74420D6De6351489e9089D76608988", "0xA3d380242DAf8B37cEA8D1b0B50533603cbcF1e6", "0x77BD4834b25d4876b6457a2820176A458d770cf2", "0x1EE5511F2664FdB36fA2713F35D2405aa7bAb444", "0xDf8BbAf50A72ae3C58315341F0a1E1f6140cDd40", "0xC5609Fdb1458FbaFeD356953eF5465e00E0B2AB7", "0x7A588Cb4bCb155D79c884552A678d2Ce5c9D188b", "0x52Ebf59A2B2e5b932d7740C1A59083aE66a32fD8", "0x9cab23bD562Fb7070848A0F4111A94370B39D8F2", "0x1C1Bb5915cEc7dA52985a2765519Fc23483C93B0", "0xBaC5C96D896D150643873f06c3e72b07474C4d35", "0x6d01d64742A0B5F5fD8CfCD2D811B00E6C1846CE", "0xB24835D833392351Ef03822DaF5AF3DaA5bc23a4", "0x7D5631437526f1d87269c21055E9b8388DC34586", "0x16a43C6EFBb1a2110AE9d2716e6BD5fC1e8F5b8f", "0x15f450B2F6663732421897ff5309AA82D3ae2E75", "0x3c7a0daeA2862020307bad8441E5d94B57cc65D1", "0x47083f0e3fEb6a5C28950a827E423Df2CEB29461", "0xBf7F755C73026d8f1c7D816fc0BdC3a5cb75F7a8", "0x88301044890a87aFdffAcFf1351ed71B2d8405c3", "0xA18CFe7bA4638420602735cdbB9ECDCa1D715c0B", "0x25a319DBD8a644B3ee3cD3BE7A7439632eB262B7", "0x9703Cf02A914Ff1513194B7214F11c6a33A48727", "0xE1cF28e17Cd517F296D648938D5791C447E6FADc", "0xBb9bBD1910FEE5bE1537a2b10544b4506dab8eE3", "0x88341bD03d188Df01Ba89765C5dC0150107e23C2", "0x871b234fC63523D45def3b8F1753C2cF7975e830", "0x107924dA640E4136540A87AB5A6A92124373672d", "0xe9B8DE5a33BB189EE862fA2d38Df9Cf9c12a238e", "0x5183f49B4e88AD23e541b1Daf7Ed1e5f462063BC", "0x6E732aE8F126C0a41FB22FA06566e9806005f57d", "0x19D2C72Ecf6c8D65f85cBFF4486CE85Da6322C89", "0x5F2f6E9d1dE9820d26752A8dAC3Ff802dB507f21", "0xc94dc73a2677E012FB6260c680CE5344E3AEAaB8", "0x1C12BA97B2C310efef6EC41c4972AB84570fe69E", "0xD215506A796b506E87996a8f5D815C80D5937e35", "0x5A1a7a7019C1236FAD4f65C595bf5AfE76A956D0", "0x670bEf8fB4447A1199f282e25f349D4e18CCd719", "0x7c648174a504ce293609AF04203D9C3c0FEA53Db", "0x46486a69B524aEa40Eb62513AfFfc9a771B009A0", "0xC206146350163E5aEdC0112190Cdc53959218C68"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "totalPicoUSD", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startDate", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "duration", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "finalised", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "signer", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multisig", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "icoAllocation", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "foundationReserve", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "usdDecimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "potentialOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalUSD", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "creationTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "vestingDateEnd", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "preIcoAllocation", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInWei", type: "uint256"}, {indexed: false, name: "investedInWei", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}], name: "InvestmentInETH", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInPicoUsd", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}], name: "InvestmentInUSD", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}], name: "PresaleInvestment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "old", type: "address"}, {indexed: false, name: "current", type: "address"}], name: "NewOwner", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "old", type: "address"}, {indexed: false, name: "potential", type: "address"}], name: "NewPotentialOwner", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Issuance", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["InvestmentInETH(address,uint256,uint256,uint256,uint256,bytes32)", "InvestmentInBTC(address,uint256,uint256,uint256,uint256,string)", "InvestmentInUSD(address,uint256,uint256,uint256)", "PresaleInvestment(address,uint256,uint256)", "NewOwner(address,address)", "NewPotentialOwner(address,address)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "Issuance(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xcb3c951de24132b3780674d63a0aefa2e2a83f07ce943397a2880f607b5fa3c3", "0xd73e30d68edcaf46f57313bec669121749b4e2928c2e98cd232bded2d6569fad", "0x938eae3834e37728fc8579189aaf02cb629d18822ea1bdbb21264d620e1e13ab", "0x43fca754f16e3c99f62c2e37af54a5ff17ff2b96dfbd3294dfa88bfaf85b817e", "0x70aea8d848e8a90fb7661b227dc522eb6395c3dac71b63cb59edd5c9899b2364", "0x8a95addc59dddee94a894365b5c66c6c2473b7084d3fd1df9f503db4a2cd6dcc", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x9cb9c14f7bc76e3a89b796b091850526236115352a198b1e472f00e91376bbcb"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4550784 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4558568 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_signer", value: 7}, {type: "address", name: "_multisig", value: 8}, {type: "uint256", name: "_preIcoTokens", value: "1495855"}], name: "TokenboxToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "totalPicoUSD", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalPicoUSD()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startDate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startDate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "duration", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "duration()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalised", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "signer", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "signer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multisig", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multisig()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "icoAllocation", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "icoAllocation()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "foundationReserve", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "foundationReserve()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "usdDecimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "usdDecimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "potentialOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "potentialOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalUSD", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalUSD()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "creationTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "creationTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "vestingDateEnd", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "vestingDateEnd()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "preIcoAllocation", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "preIcoAllocation()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TokenboxToken", function( accounts ) {

	it( "TEST: TokenboxToken( addressList[7], addressList[8], \"149585... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4550784", timeStamp: "1510658499", hash: "0x5c45023461e87b5139536ea5becb3e42cae2bfbafaa12efd118abf9d8e8956fd", nonce: "1169", blockHash: "0x7adc8d566a82981d1db31a99ed0b53df377344797df52d84cbefa38d71a144fe", transactionIndex: "23", from: "0xba091db085eac2055400c934c8dc989b500113a2", to: 0, value: "0", gas: "3253058", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x95d416ac0000000000000000000000009db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8000000000000000000000000ad8ea3b0215e6efd9d2f2aa22baf6d494dbf7662000000000000000000000000000000000000000000000000000000000016d32f", contractAddress: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", cumulativeGasUsed: "4004175", gasUsed: "3253058", confirmations: "3188393"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_signer", value: addressList[7]}, {type: "address", name: "_multisig", value: addressList[8]}, {type: "uint256", name: "_preIcoTokens", value: "1495855"}], name: "TokenboxToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TokenboxToken.new( addressList[7], addressList[8], "1495855", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510658499 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TokenboxToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "91774433659013928" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[10], \"833333333299\", \"512... )", async function( ) {
		const txOriginal = {blockNumber: "4550971", timeStamp: "1510661186", hash: "0x74a72ea21493ee2fdc7df13aa889f6806a88cac5f5b112da792332b0cf427f3c", nonce: "0", blockHash: "0xaafed048f7caa496313dcd6c5888df354cb579c2d869752cf48fd903cf535f51", transactionIndex: "20", from: "0x2f2466cf8ba78119e66b860143cd47d48a77fb69", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "2120716000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000007e5ce10826ee167de897d262fcc9976f609ecd2b000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000001231439a2cf800ed5bfd58c457b103bc750670f1d88849b6d4b6c587aa727ce613339c5ded58a0000000000000000000000000000000000000000000000000000000000000001c532737622ec06f382b12b7451ec859f42d38de8f3f6defcbccd56911c1a4cd902a0485a8303d32c177f3028ea82da099e265e9ca3e7f1d0260d8993908f6509e000000000000000000000000000000000000000000000000000ad8ff8e4bac2d", contractAddress: "", cumulativeGasUsed: "760282", gasUsed: "32837", confirmations: "3188206"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "2120716000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[10]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "5120716000000000"}, {type: "bytes32", name: "hash", value: "0xed5bfd58c457b103bc750670f1d88849b6d4b6c587aa727ce613339c5ded58a0"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x532737622ec06f382b12b7451ec859f42d38de8f3f6defcbccd56911c1a4cd90"}, {type: "bytes32", name: "s", value: "0x2a0485a8303d32c177f3028ea82da099e265e9ca3e7f1d0260d8993908f6509e"}, {type: "uint256", name: "WeiToUSD", value: "3053341882690605"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[10], "833333333299", "5120716000000000", "0xed5bfd58c457b103bc750670f1d88849b6d4b6c587aa727ce613339c5ded58a0", "28", "0x532737622ec06f382b12b7451ec859f42d38de8f3f6defcbccd56911c1a4cd90", "0x2a0485a8303d32c177f3028ea82da099e265e9ca3e7f1d0260d8993908f6509e", "3053341882690605", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510661186 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "728567000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[12], \"833333333299\", \"371... )", async function( ) {
		const txOriginal = {blockNumber: "4550992", timeStamp: "1510661572", hash: "0xbf6e3e27576fb8fb07215fc383a97a47e63e31e7555e524d660ccc9ab885e6d1", nonce: "0", blockHash: "0xb5124d4459dcee8065357a37dc358e4be66fceae73fdbf49fa7aadbee99bac2b", transactionIndex: "4", from: "0x41103544fa950378618b9b6496fa355becffac23", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "368251950000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000882b32d5ad4fe21d581049a95d710fa66f1b8053000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000526f3ae79ebcc0096a3615a628a4fcae63e9937ce45fe703b9c4500b9568f53b11e03eff947d4e5000000000000000000000000000000000000000000000000000000000000001b889e7bcc8c0f046920c69f55d90ee2cbb06c1613a4cd7d574864807f7ccb009f7beb09ba8cf1d420d03db70e5d416df762978afc7cab79271e4aa75cb6a47838000000000000000000000000000000000000000000000000000aea517861ae03", contractAddress: "", cumulativeGasUsed: "180673", gasUsed: "32773", confirmations: "3188185"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "368251950000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[12]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "371251950000000000"}, {type: "bytes32", name: "hash", value: "0x96a3615a628a4fcae63e9937ce45fe703b9c4500b9568f53b11e03eff947d4e5"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x889e7bcc8c0f046920c69f55d90ee2cbb06c1613a4cd7d574864807f7ccb009f"}, {type: "bytes32", name: "s", value: "0x7beb09ba8cf1d420d03db70e5d416df762978afc7cab79271e4aa75cb6a47838"}, {type: "uint256", name: "WeiToUSD", value: "3072385400024579"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[12], "833333333299", "371251950000000000", "0x96a3615a628a4fcae63e9937ce45fe703b9c4500b9568f53b11e03eff947d4e5", "27", "0x889e7bcc8c0f046920c69f55d90ee2cbb06c1613a4cd7d574864807f7ccb009f", "0x7beb09ba8cf1d420d03db70e5d416df762978afc7cab79271e4aa75cb6a47838", "3072385400024579", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510661572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "730551000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[14], \"833333333299\", \"512... )", async function( ) {
		const txOriginal = {blockNumber: "4550994", timeStamp: "1510661594", hash: "0x81db9708c323066b8749bac3f1988037f29b6829b74c9b037f8becd68200b613", nonce: "0", blockHash: "0x34bee70d4798e865157495ea625b8abeba90cb4f3dce92593cee60dd8c6152e9", transactionIndex: "53", from: "0x32bf5dfeb37eaa7e6fd8ee148712f4364d6f941e", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "48207166664618300", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000000ad9fb61a07bac25625382b63693644497f1b204000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000000b5eca592ffb13cd9caa5318827540af6a3df7a0825b6ea118008971515f562a5333d355c6597cf000000000000000000000000000000000000000000000000000000000000001b59f338e0aa111196a1d6310bea0a05664399627f5debfb85c8e3e4958dda15896d34663ac4222dd3bf07fea1152d068e5e7348e6ce9043f7db16831c9c841db2000000000000000000000000000000000000000000000000000aea517861ae03", contractAddress: "", cumulativeGasUsed: "1973158", gasUsed: "32901", confirmations: "3188183"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "48207166664618300" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[14]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "51207166664618300"}, {type: "bytes32", name: "hash", value: "0xd9caa5318827540af6a3df7a0825b6ea118008971515f562a5333d355c6597cf"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x59f338e0aa111196a1d6310bea0a05664399627f5debfb85c8e3e4958dda1589"}, {type: "bytes32", name: "s", value: "0x6d34663ac4222dd3bf07fea1152d068e5e7348e6ce9043f7db16831c9c841db2"}, {type: "uint256", name: "WeiToUSD", value: "3072385400024579"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[14], "833333333299", "51207166664618300", "0xd9caa5318827540af6a3df7a0825b6ea118008971515f562a5333d355c6597cf", "27", "0x59f338e0aa111196a1d6310bea0a05664399627f5debfb85c8e3e4958dda1589", "0x6d34663ac4222dd3bf07fea1152d068e5e7348e6ce9043f7db16831c9c841db2", "3072385400024579", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510661594 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"243... )", async function( ) {
		const txOriginal = {blockNumber: "4551003", timeStamp: "1510661723", hash: "0x50807abe4cd206dc94bcee9cea51e9269c7ae31e3df3f42ce4692a67ca433554", nonce: "0", blockHash: "0x7625c69fbacd89a1825dc0274d97afe453b28b78aa3830e67706ef81f02ab5a0", transactionIndex: "2", from: "0x9f943cc255b1d1475eb8b050e5c3ce1c0ff07d84", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "243231041656937300000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000d2f8ce82d8450402042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000aea517861ae03", contractAddress: "", cumulativeGasUsed: "118753", gasUsed: "33029", confirmations: "3188174"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "243231041656937300000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "243234041656937300000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3072385400024579"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "243234041656937300000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3072385400024579", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510661723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "968940000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"192... )", async function( ) {
		const txOriginal = {blockNumber: "4551007", timeStamp: "1510661815", hash: "0xbdee371cf51d8a5980343ec704de451d9e4219a1ae71f3230e5358e81e5edb90", nonce: "0", blockHash: "0xa245eaa03b5f66dd44d40c799ca9ae51c84209537e91c08f6faaf33fa6ec7aa2", transactionIndex: "116", from: "0xb3b5b2a7d19bed40dd908a238536609c509a53e2", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "192639499992294300000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000a7173a5144be49960cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "3284636", gasUsed: "32901", confirmations: "3188170"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "192639499992294300000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "192642499992294300000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "192642499992294300000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510661815 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"192... )", async function( ) {
		const txOriginal = {blockNumber: "4551015", timeStamp: "1510661925", hash: "0xcb0fb085ff3d03122f7519f58292fcc816c420508d3c27ab298cad6133f5b0b2", nonce: "0", blockHash: "0x893e025dfeb5a7c95ac3033a5e9eb4baf7ca12547cdd81cabf3082ca59bd40a5", transactionIndex: "23", from: "0xdd6e34eabfb4f1691af7d3180243649be50d7c81", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "19261249999229430000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000010b585d4ed463a8f0cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "971914", gasUsed: "32901", confirmations: "3188162"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "19261249999229430000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "19264249999229430000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "19264249999229430000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510661925 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"249... )", async function( ) {
		const txOriginal = {blockNumber: "4551022", timeStamp: "1510662013", hash: "0x6d2ba771af6a5c62f9f49f96de8427000a945aafae0c401c0e59478109cc1e5f", nonce: "0", blockHash: "0xe97ad52a87cae35d27781f8d654217ecb9576175caf39a267556808a583aac17", transactionIndex: "8", from: "0x081c08a6d3daae19599b6ac17836b17fdbb70c6f", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "24912096665670060000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000159c434695dc887e042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "248704", gasUsed: "33029", confirmations: "3188155"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "24912096665670060000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "24915096665670060000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "24915096665670060000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510662013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "968940000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"642... )", async function( ) {
		const txOriginal = {blockNumber: "4551028", timeStamp: "1510662080", hash: "0xedda6a2c714d5037075e171590b5a753e1cdc447072da9b5bb29a35dd3832856", nonce: "0", blockHash: "0x212ab22c1e5b354c46f45d925500c7eec55f001a26c2062b18f09b7750d3fac5", transactionIndex: "11", from: "0xb431e8b22fe44e373f00d82bf6b3c6020cf295aa", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "6418416666409810000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000591d746f9c213850cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "330275", gasUsed: "32837", confirmations: "3188149"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "6418416666409810000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "6421416666409810000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "6421416666409810000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510662080 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "893567000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"179... )", async function( ) {
		const txOriginal = {blockNumber: "4551029", timeStamp: "1510662082", hash: "0x890e646db07cbbc0ffb621cedf9f3ed7670a2baf156ba03fee47ac16ccf82ab2", nonce: "0", blockHash: "0xe09880052a50ff19be7f68bc55164ff639dae649d4ee0ed45875463040fa33f8", transactionIndex: "8", from: "0x2ba6e55b6ec4f998f1ab1fb912dba30fadd15e3a", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "17976966665947470000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000f985ac6bb529d8b042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "241487", gasUsed: "32965", confirmations: "3188148"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "17976966665947470000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "17979966665947470000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "17979966665947470000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510662082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "889599000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"125... )", async function( ) {
		const txOriginal = {blockNumber: "4551036", timeStamp: "1510662206", hash: "0x344a3d131ac1c778c0aa10762bdb7b1368a14b599b66789f245cc05965e373c0", nonce: "0", blockHash: "0x6b7cbc020308274c52b8a225e5ba340a7dd34b398cd90061595f9337f990ba3d", transactionIndex: "41", from: "0x4eb03162d506acba7a9c25a6042c59fce6594d37", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "12582976666163228000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000aeaa5f183203ad60cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "1228468", gasUsed: "32837", confirmations: "3188141"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "12582976666163228000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "12585976666163228000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "12585976666163228000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510662206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "893567000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"847... )", async function( ) {
		const txOriginal = {blockNumber: "4551037", timeStamp: "1510662213", hash: "0x2da37b4e0ab6fc2b2756556f7e6269c31bb59ebdb77378a89d80b67ee8d0c0e5", nonce: "0", blockHash: "0xd5e246f4a262b4b55c990602a5c44a8a995d16d4074794589c58aa20782909d4", transactionIndex: "24", from: "0xee471e97c7cc2630675069a649e191f52c240fc8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "8473269999660950000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000075a1c2a7ce1761f042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "2923451", gasUsed: "32965", confirmations: "3188140"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "8473269999660950000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "8476269999660950000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "8476269999660950000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510662213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "889599000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[26], \"833333333299\", \"385... )", async function( ) {
		const txOriginal = {blockNumber: "4551042", timeStamp: "1510662343", hash: "0x5693ded029b5705b128d83f974c5af1f88d564743ba7b9a1f85ec448db9d879c", nonce: "0", blockHash: "0xa2ff60cf24f472ae11231a7128122d46137b8f6ae453487379edec31e5e536ac", transactionIndex: "70", from: "0xb9ac4c66ecfc0069d44f812344b085a92a9e64ed", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "382284999984588000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000113277849a9e06f6e2a10c5f1f43945c7aa65f5a000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000558ceaa895e24e00e07d3148eb0e3120626e825264418e379b1496f0849b03db3da8163cc9d0847000000000000000000000000000000000000000000000000000000000000001cc6a0e4af07a2ef8d039956a2647ea784f65c2e1544959e2c104e5c3b6b3806c12cf3d23c362e404af841c7fb189e349440659fbafb2890e724c876876c98d9b3000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "3191482", gasUsed: "32965", confirmations: "3188135"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "382284999984588000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[26]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "385284999984588000"}, {type: "bytes32", name: "hash", value: "0x0e07d3148eb0e3120626e825264418e379b1496f0849b03db3da8163cc9d0847"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc6a0e4af07a2ef8d039956a2647ea784f65c2e1544959e2c104e5c3b6b3806c1"}, {type: "bytes32", name: "s", value: "0x2cf3d23c362e404af841c7fb189e349440659fbafb2890e724c876876c98d9b3"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[26], "833333333299", "385284999984588000", "0x0e07d3148eb0e3120626e825264418e379b1496f0849b03db3da8163cc9d0847", "28", "0xc6a0e4af07a2ef8d039956a2647ea784f65c2e1544959e2c104e5c3b6b3806c1", "0x2cf3d23c362e404af841c7fb189e349440659fbafb2890e724c876876c98d9b3", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510662343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "889599000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[28], \"833333333299\", \"976... )", async function( ) {
		const txOriginal = {blockNumber: "4551045", timeStamp: "1510662356", hash: "0xac87c604eb12268c9c3947559f0bd693ed2a4a8f6ecedfcded4f7b2400bd0716", nonce: "0", blockHash: "0x8d856029b167935b7608775c3beebc11a0013cee02c0178036a87da3f761f56f", transactionIndex: "4", from: "0x1ad68bd2f0c2f734fb710a0fb97f14a468b2bd57", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "94605533329429000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000008e5b7b6b82486264b9f812ff75a9525fa337b05a000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000015ac3b726369208e3fd492c43e2be40636729b883d902c7992cab3397bfea413c9b1f3a89c0cce0000000000000000000000000000000000000000000000000000000000000001ce866c0ee417aa2e011baf98122273efb20b52765b9f3291c884bff8a286be5bb1941a799cbdde41ee6ee52b9b210ad0e0366b6f789796628a67752d4ec371aa7000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "148479", gasUsed: "32965", confirmations: "3188132"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "94605533329429000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[28]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "97605533329429000"}, {type: "bytes32", name: "hash", value: "0xe3fd492c43e2be40636729b883d902c7992cab3397bfea413c9b1f3a89c0cce0"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xe866c0ee417aa2e011baf98122273efb20b52765b9f3291c884bff8a286be5bb"}, {type: "bytes32", name: "s", value: "0x1941a799cbdde41ee6ee52b9b210ad0e0366b6f789796628a67752d4ec371aa7"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[28], "833333333299", "97605533329429000", "0xe3fd492c43e2be40636729b883d902c7992cab3397bfea413c9b1f3a89c0cce0", "28", "0xe866c0ee417aa2e011baf98122273efb20b52765b9f3291c884bff8a286be5bb", "0x1941a799cbdde41ee6ee52b9b210ad0e0366b6f789796628a67752d4ec371aa7", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510662356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "724599000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"308... )", async function( ) {
		const txOriginal = {blockNumber: "4551045", timeStamp: "1510662356", hash: "0x53ca6feb798ba49c81a05c5646d764896c4d4782a2f76dceacdb2d9eb6d0eca3", nonce: "0", blockHash: "0x8d856029b167935b7608775c3beebc11a0013cee02c0178036a87da3f761f56f", transactionIndex: "5", from: "0xa8bca83967acf16319e56396278ce36d9b84def0", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "30819799998767090000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000001abc0954aed6c4950cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "181380", gasUsed: "32901", confirmations: "3188132"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "30819799998767090000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "30822799998767090000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "30822799998767090000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510662356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"254... )", async function( ) {
		const txOriginal = {blockNumber: "4551048", timeStamp: "1510662379", hash: "0xbfd229e78b076e7ae6b1f63bf2d438d6801cb969364f6eb24ee901a0856de31d", nonce: "0", blockHash: "0x4a1427029e4afec6e2563d6da9d70c9a43232f6024e1de8ce198a1361051e2f1", transactionIndex: "9", from: "0x91b8c82bb797922b4e0a2837a60147d15ec13b34", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "22486166665647000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000005a8b8896cad39842deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "351866", gasUsed: "32901", confirmations: "3188129"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "22486166665647000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "25486166665647000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "25486166665647000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510662379 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"688... )", async function( ) {
		const txOriginal = {blockNumber: "4551057", timeStamp: "1510662464", hash: "0x1ab0cd79935dceecc545fdedc1994f0495db56d222af80033b41d6eb26e7827e", nonce: "0", blockHash: "0x8e72a365049203c0f33be7446a82912c6bc93388b8806679433b0b690cbb96da", transactionIndex: "5", from: "0xbc9d3654daa986e10a45727efd26529011889734", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "65812649997247000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000000f478bd9723a21842deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "288848", gasUsed: "32901", confirmations: "3188120"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "65812649997247000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "68812649997247000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "68812649997247000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510662464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[33], \"833333333299\", \"101... )", async function( ) {
		const txOriginal = {blockNumber: "4551060", timeStamp: "1510662475", hash: "0x1467effc3d5bc761d6be536c00ac26a8eecb44e278ef75f44ba2ea29e9a80abd", nonce: "0", blockHash: "0xd990c1b91e54d34f5b66d1629d82f2bf44313dc3dccee169d89f629f8fca9ec5", transactionIndex: "12", from: "0x007254a766d6034bad30ac467f4956f7fdff4bce", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "1016446666625888800", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000ae28cab1f51040aa0f7eedafef7d6d8c6d47a6be000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000e25cd578fb132204aafcf8517e32adad0809f198a66cb3e384bb57a0a9b31822d1f1c6eae152dac000000000000000000000000000000000000000000000000000000000000001cf447e647703bd588ce00bf983c748f026826379c8b89d7abb259ba920d29798f1f672acd66d77f9722a9975a2b6726f45209023fbfa7b729183909d5903a3654000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "389509", gasUsed: "32901", confirmations: "3188117"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "1016446666625888800" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[33]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "1019446666625888800"}, {type: "bytes32", name: "hash", value: "0x4aafcf8517e32adad0809f198a66cb3e384bb57a0a9b31822d1f1c6eae152dac"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xf447e647703bd588ce00bf983c748f026826379c8b89d7abb259ba920d29798f"}, {type: "bytes32", name: "s", value: "0x1f672acd66d77f9722a9975a2b6726f45209023fbfa7b729183909d5903a3654"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[33], "833333333299", "1019446666625888800", "0x4aafcf8517e32adad0809f198a66cb3e384bb57a0a9b31822d1f1c6eae152dac", "28", "0xf447e647703bd588ce00bf983c748f026826379c8b89d7abb259ba920d29798f", "0x1f672acd66d77f9722a9975a2b6726f45209023fbfa7b729183909d5903a3654", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510662475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "726583000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[35], \"833333333299\", \"764... )", async function( ) {
		const txOriginal = {blockNumber: "4551064", timeStamp: "1510662513", hash: "0x23f1d783920f96a62f9c850c4c5f30779f0a75d783dbe6a153934066cdaa883d", nonce: "0", blockHash: "0xa9138b65818e6de7a1d6b2752bd6a8c755e0fbae1cd3fa288f73fa9cb91de39e", transactionIndex: "6", from: "0x7d715a33de1eeb55e4256df7305706378e3ee93a", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "761584999969416000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000fb5a9e8b362ca6834e999a126352ac9d957da747000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000a9c5a01abc4e340d585104177f37d2f636ba6632f296d87445bd6a015978a4687170fc85e9ad6ae000000000000000000000000000000000000000000000000000000000000001b7365b804f82c3a9da3b008b60d4501f08a3a24f4beec9a18fc856b59fc2bf9f6745525f422697528b2544930708fab60fc654e19c5a9b291e5799bbd07e01144000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "248976", gasUsed: "32965", confirmations: "3188113"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "761584999969416000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[35]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "764584999969416000"}, {type: "bytes32", name: "hash", value: "0xd585104177f37d2f636ba6632f296d87445bd6a015978a4687170fc85e9ad6ae"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7365b804f82c3a9da3b008b60d4501f08a3a24f4beec9a18fc856b59fc2bf9f6"}, {type: "bytes32", name: "s", value: "0x745525f422697528b2544930708fab60fc654e19c5a9b291e5799bbd07e01144"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[35], "833333333299", "764584999969416000", "0xd585104177f37d2f636ba6632f296d87445bd6a015978a4687170fc85e9ad6ae", "27", "0x7365b804f82c3a9da3b008b60d4501f08a3a24f4beec9a18fc856b59fc2bf9f6", "0x745525f422697528b2544930708fab60fc654e19c5a9b291e5799bbd07e01144", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510662513 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "724599000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[37], \"833333333299\", \"917... )", async function( ) {
		const txOriginal = {blockNumber: "4551071", timeStamp: "1510662618", hash: "0x1f7cdeaa4b7219b34973f112ee1931d2d12054ed892de01346939e775f28b0d7", nonce: "0", blockHash: "0x183c2619138024c1ebfe01e50744305612a170ddc8514e60df63b181b7e90f0b", transactionIndex: "8", from: "0x1bb50952006fbb3c64ec2bc41b9fcf3f17fc436a", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "914501999963300000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000c9212ef53b74420d6de6351489e9089d76608988000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000cbb9f353485e0a0c1b13dcbe02219a4cb1aba0a26dffb79be97013efdf6b41520697bd7ff252f2f000000000000000000000000000000000000000000000000000000000000001c592c878b365904cd1b38c2e87ec16d178c94a1c34396d5a1c3da3ed35ead174151d6ad8b111a8196f8b3923ee97957b0e5012640bccfd9c270e9be72db523d02000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "218997", gasUsed: "32965", confirmations: "3188106"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "914501999963300000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[37]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "917501999963300000"}, {type: "bytes32", name: "hash", value: "0xc1b13dcbe02219a4cb1aba0a26dffb79be97013efdf6b41520697bd7ff252f2f"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x592c878b365904cd1b38c2e87ec16d178c94a1c34396d5a1c3da3ed35ead1741"}, {type: "bytes32", name: "s", value: "0x51d6ad8b111a8196f8b3923ee97957b0e5012640bccfd9c270e9be72db523d02"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[37], "833333333299", "917501999963300000", "0xc1b13dcbe02219a4cb1aba0a26dffb79be97013efdf6b41520697bd7ff252f2f", "28", "0x592c878b365904cd1b38c2e87ec16d178c94a1c34396d5a1c3da3ed35ead1741", "0x51d6ad8b111a8196f8b3923ee97957b0e5012640bccfd9c270e9be72db523d02", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510662618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "724599000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"637... )", async function( ) {
		const txOriginal = {blockNumber: "4551077", timeStamp: "1510662743", hash: "0x10b41a03cc57d185ba37671ce3a559d55b351b10500cc89e54f247a716a770ea", nonce: "0", blockHash: "0xee1877fb1563d924946afba99cad2915d36f7bfc11c0c4785c248bb2c04aee5b", transactionIndex: "51", from: "0xa3d380242daf8b37cea8d1b0b50533603cbcf1e6", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "63712416664118050000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000003743aa1e094c2bcd0cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "2469342", gasUsed: "32901", confirmations: "3188100"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "63712416664118050000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "63715416664118050000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "63715416664118050000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510662743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[26], \"833333333299\", \"127... )", async function( ) {
		const txOriginal = {blockNumber: "4551080", timeStamp: "1510662805", hash: "0x657f3e4b3e92cedb0fa475f5c17969980d579921c965689df21b763efc70e814", nonce: "0", blockHash: "0x268e2a8ef1d4a7f7dda08d98ad89eaae1097eab5654b00ff2cc97c85969407ce", transactionIndex: "69", from: "0x77bd4834b25d4876b6457a2820176a458d770cf2", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "124430833328236100", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000113277849a9e06f6e2a10c5f1f43945c7aa65f5a000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000001c4b9aaf1f626440e07d3148eb0e3120626e825264418e379b1496f0849b03db3da8163cc9d0847000000000000000000000000000000000000000000000000000000000000001cc6a0e4af07a2ef8d039956a2647ea784f65c2e1544959e2c104e5c3b6b3806c12cf3d23c362e404af841c7fb189e349440659fbafb2890e724c876876c98d9b3000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "2428336", gasUsed: "32965", confirmations: "3188097"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "124430833328236100" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[26]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "127430833328236100"}, {type: "bytes32", name: "hash", value: "0x0e07d3148eb0e3120626e825264418e379b1496f0849b03db3da8163cc9d0847"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc6a0e4af07a2ef8d039956a2647ea784f65c2e1544959e2c104e5c3b6b3806c1"}, {type: "bytes32", name: "s", value: "0x2cf3d23c362e404af841c7fb189e349440659fbafb2890e724c876876c98d9b3"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[26], "833333333299", "127430833328236100", "0x0e07d3148eb0e3120626e825264418e379b1496f0849b03db3da8163cc9d0847", "28", "0xc6a0e4af07a2ef8d039956a2647ea784f65c2e1544959e2c104e5c3b6b3806c1", "0x2cf3d23c362e404af841c7fb189e349440659fbafb2890e724c876876c98d9b3", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510662805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "724599000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"254... )", async function( ) {
		const txOriginal = {blockNumber: "4551084", timeStamp: "1510662858", hash: "0x9128fe2f67e8160349443bcc5366ac0f22c36de675827f7c84a4d60ed0ca7c9a", nonce: "0", blockHash: "0x8088afeb12f3a1840b641ca19f3ed36652a0597b75a523633172ba2ce297a58b", transactionIndex: "34", from: "0x1ee5511f2664fdb36fa2713f35d2405aa7bab444", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "2545616666564722000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000235e815ae73afd5042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000add7fde4855ae", contractAddress: "", cumulativeGasUsed: "957388", gasUsed: "32965", confirmations: "3188093"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "2545616666564722000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "2548616666564722000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3058291026974126"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "2548616666564722000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3058291026974126", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510662858 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "889599000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[42], \"833333333299\", \"192... )", async function( ) {
		const txOriginal = {blockNumber: "4551092", timeStamp: "1510662944", hash: "0xd71058ef0f7d4e858c50d19544ecf4805bb083598c639dd79843afb498f93107", nonce: "0", blockHash: "0x537168a6bdfb97a6ea5203d522d3f634c6f2602e5a495c9d5398b988b288ba9e", transactionIndex: "22", from: "0xdf8bbaf50a72ae3c58315341f0a1e1f6140cdd40", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "189642499992294300", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000c5609fdb1458fbafed356953ef5465e00e0b2ab7000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000002ac675544af139c3cc86a91abf4a2cc65875432ceca5c28d7b3f3f1be3015891cce063c01a1af59000000000000000000000000000000000000000000000000000000000000001c4bb8bbcd830f03c4ce124f34ffd9489194722776dce3e8e82ac022f4b8477cb3447ea5fc23c2d0822cbd7641a89fec23c0eba6d9f8f405dcd414f83e8c713472000000000000000000000000000000000000000000000000000af34686e02d93", contractAddress: "", cumulativeGasUsed: "1079952", gasUsed: "32965", confirmations: "3188085"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "189642499992294300" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[42]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "192642499992294300"}, {type: "bytes32", name: "hash", value: "0x3cc86a91abf4a2cc65875432ceca5c28d7b3f3f1be3015891cce063c01a1af59"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x4bb8bbcd830f03c4ce124f34ffd9489194722776dce3e8e82ac022f4b8477cb3"}, {type: "bytes32", name: "s", value: "0x447ea5fc23c2d0822cbd7641a89fec23c0eba6d9f8f405dcd414f83e8c713472"}, {type: "uint256", name: "WeiToUSD", value: "3082234003205523"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[42], "833333333299", "192642499992294300", "0x3cc86a91abf4a2cc65875432ceca5c28d7b3f3f1be3015891cce063c01a1af59", "28", "0x4bb8bbcd830f03c4ce124f34ffd9489194722776dce3e8e82ac022f4b8477cb3", "0x447ea5fc23c2d0822cbd7641a89fec23c0eba6d9f8f405dcd414f83e8c713472", "3082234003205523", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510662944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "724599000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"815... )", async function( ) {
		const txOriginal = {blockNumber: "4551092", timeStamp: "1510662944", hash: "0xe44ab81dd02ab29a632de77b312e5cb902874170a28c8657e55d6cf79c18a44d", nonce: "0", blockHash: "0x537168a6bdfb97a6ea5203d522d3f634c6f2602e5a495c9d5398b988b288ba9e", transactionIndex: "23", from: "0x7a588cb4bcb155d79c884552a678d2ce5c9d188b", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "8152573333007110000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000712e6abc7d898f70cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "1112789", gasUsed: "32837", confirmations: "3188085"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "8152573333007110000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "8155573333007110000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "8155573333007110000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510662944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "893567000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"833333333299\", \"317... )", async function( ) {
		const txOriginal = {blockNumber: "4551101", timeStamp: "1510663057", hash: "0x9d8dd42510a5d51f7d433f22d5e20a858652a0ec291c8dda418275c20a1e54c7", nonce: "0", blockHash: "0xd7fdbae606c823548f73aaf8e1da8f108713cd279a053c0dfac160e6cdf4a2d9", transactionIndex: "24", from: "0x52ebf59a2b2e5b932d7740c1a59083ae66a32fd8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "31766270832062553000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000009acf50ab22004cf09b2461c71447f1d776188fa8000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000001b8e31f803e445ba8cb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe000000000000000000000000000000000000000000000000000000000000001c6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e025c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "913188", gasUsed: "32901", confirmations: "3188076"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "31766270832062553000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "31769270832062553000"}, {type: "bytes32", name: "hash", value: "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02"}, {type: "bytes32", name: "s", value: "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[18], "833333333299", "31769270832062553000", "0xcb0f430a0ef9c3e2f31c9aa61c9668c45de183f9b006980d43a97c0774525efe", "28", "0x6320314fa0ccd8ebd500c88398ab1cdba0b27aafca5e70900590cd8a094a5e02", "0x5c392e2b5ff54c35c7cc524fc42c8b2c28cf93a36ab92d78594bd5bf3be0065a", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510663057 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[46], \"833333333299\", \"406... )", async function( ) {
		const txOriginal = {blockNumber: "4551115", timeStamp: "1510663303", hash: "0xc52d4115b633ff5d4668a362a89c4220998154fd7d9c3d845c7e14db37e35dbc", nonce: "0", blockHash: "0x3dd9a66f0eb1372226ca54dfeb9e9dd8d25e8720391f77534510b5e1c8b0be3f", transactionIndex: "120", from: "0x9cab23bd562fb7070848a0f4111a94370b39d8f2", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "403646670000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000001c1bb5915cec7da52985a2765519fc23483c93b0000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000005a4b2fdea720c001abae1775f62d77750a301ee2ffa23e1445c58d9e7210bd3006bfbbf13a020b3000000000000000000000000000000000000000000000000000000000000001b30d0074879cc61cbc11037e8d5c42248d97626f6aecead2ed51d129ccc97491c620c9e57beac5f5c5d4ad43909c1353f18991b44cf9a09078540e1f9f213db03000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "3509637", gasUsed: "32837", confirmations: "3188062"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "403646670000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[46]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "406646670000000000"}, {type: "bytes32", name: "hash", value: "0x1abae1775f62d77750a301ee2ffa23e1445c58d9e7210bd3006bfbbf13a020b3"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x30d0074879cc61cbc11037e8d5c42248d97626f6aecead2ed51d129ccc97491c"}, {type: "bytes32", name: "s", value: "0x620c9e57beac5f5c5d4ad43909c1353f18991b44cf9a09078540e1f9f213db03"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[46], "833333333299", "406646670000000000", "0x1abae1775f62d77750a301ee2ffa23e1445c58d9e7210bd3006bfbbf13a020b3", "27", "0x30d0074879cc61cbc11037e8d5c42248d97626f6aecead2ed51d129ccc97491c", "0x620c9e57beac5f5c5d4ad43909c1353f18991b44cf9a09078540e1f9f213db03", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510663303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "728567000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"254... )", async function( ) {
		const txOriginal = {blockNumber: "4551123", timeStamp: "1510663449", hash: "0x7aaba64e2b891ae4f60a88af7866b86819e3c1116c577e07fe68a3132a80140a", nonce: "0", blockHash: "0x4fa1c729d74afb50623fbd05303a65f4c4a9de0ee3d39bef7be698e05e6fa15c", transactionIndex: "32", from: "0xbac5c96d896d150643873f06c3e72b07474c4d35", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "251154166656500000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000386efde35bf012042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "1433209", gasUsed: "32965", confirmations: "3188054"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "251154166656500000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "254154166656500000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "254154166656500000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510663449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "889599000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[49], \"833333333299\", \"304... )", async function( ) {
		const txOriginal = {blockNumber: "4551124", timeStamp: "1510663456", hash: "0xa680eb9469fe817a9a94ab352b4e430725a97398c2f4b08a7b120fdc484b07ff", nonce: "0", blockHash: "0x359622ccf6d90ebc83ae5d3af4e43ca7c0a02329596745d52ef600a7420badd4", transactionIndex: "20", from: "0x6d01d64742a0b5f5fd8cfcd2d811b00e6c1846ce", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "3046850000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000b24835d833392351ef03822daf5af3daa5bc23a4000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000002a533e6a8c39a000d82d8744992d65ad5a742115397a65643ccd844026cfd6e6e4e9c9e184e0c854000000000000000000000000000000000000000000000000000000000000001b660e6fe15d455bc681581557df2e5c133f1b48e2e7df07e78b8bd8c63fafe63e0d977ae136583219afd95bc47265478480c6a4b07650086b7d61a667a2cec006000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "872604", gasUsed: "32901", confirmations: "3188053"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "3046850000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[49]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "3049850000000000000"}, {type: "bytes32", name: "hash", value: "0xd82d8744992d65ad5a742115397a65643ccd844026cfd6e6e4e9c9e184e0c854"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x660e6fe15d455bc681581557df2e5c133f1b48e2e7df07e78b8bd8c63fafe63e"}, {type: "bytes32", name: "s", value: "0x0d977ae136583219afd95bc47265478480c6a4b07650086b7d61a667a2cec006"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[49], "833333333299", "3049850000000000000", "0xd82d8744992d65ad5a742115397a65643ccd844026cfd6e6e4e9c9e184e0c854", "27", "0x660e6fe15d455bc681581557df2e5c133f1b48e2e7df07e78b8bd8c63fafe63e", "0x0d977ae136583219afd95bc47265478480c6a4b07650086b7d61a667a2cec006", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510663456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "726583000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[51], \"833333333299\", \"203... )", async function( ) {
		const txOriginal = {blockNumber: "4551125", timeStamp: "1510663463", hash: "0x951d98dbb9d0cceeb70615ecdd384efb6cc153ec3cc0dd3719386d0da011fccd", nonce: "0", blockHash: "0x8e1c33735deba7fe20a0159000ec4f1edd0b1b37962cb8224fabac827684581f", transactionIndex: "9", from: "0x7d5631437526f1d87269c21055e9b8388dc34586", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "200323340000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f00000000000000000000000016a43c6efbb1a2110ae9d2716e6bd5fc1e8f5b8f000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000002d259801f3ef800ef0819925e7e4b7c159b803e94d96b671fc508a3fbdaa5beee60919f8fd26e26000000000000000000000000000000000000000000000000000000000000001b4373daa2963e04033baf00ebd2385a4af1e0d79b59ffc7f7838e1c0abfe1c6426ee71bd317a6b797368ec93c8b3197d9e9fe51a79fe21b55e61348bb3bc74bbe000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "747295", gasUsed: "32837", confirmations: "3188052"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "200323340000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[51]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "203323340000000000"}, {type: "bytes32", name: "hash", value: "0xef0819925e7e4b7c159b803e94d96b671fc508a3fbdaa5beee60919f8fd26e26"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x4373daa2963e04033baf00ebd2385a4af1e0d79b59ffc7f7838e1c0abfe1c642"}, {type: "bytes32", name: "s", value: "0x6ee71bd317a6b797368ec93c8b3197d9e9fe51a79fe21b55e61348bb3bc74bbe"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[51], "833333333299", "203323340000000000", "0xef0819925e7e4b7c159b803e94d96b671fc508a3fbdaa5beee60919f8fd26e26", "27", "0x4373daa2963e04033baf00ebd2385a4af1e0d79b59ffc7f7838e1c0abfe1c642", "0x6ee71bd317a6b797368ec93c8b3197d9e9fe51a79fe21b55e61348bb3bc74bbe", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510663463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "728567000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"221... )", async function( ) {
		const txOriginal = {blockNumber: "4551127", timeStamp: "1510663487", hash: "0x0155278cfd0c3b14928d79de62cee32b4b61a79834b217b9c8bd2965c1a15f18", nonce: "0", blockHash: "0xd9cdefaa817cf2afaaf589b67e4fc82c9431b284b070ff59ab2b4959301d1f90", transactionIndex: "24", from: "0x15f450b2f6663732421897ff5309aa82d3ae2e75", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "218114130000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000003118e213578340042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "1030813", gasUsed: "32901", confirmations: "3188050"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[52], to: addressList[2], value: "218114130000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "221114130000000000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "221114130000000000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510663487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[52], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[52], balance: ( await web3.eth.getBalance( addressList[52], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[54], \"833333333299\", \"254... )", async function( ) {
		const txOriginal = {blockNumber: "4551128", timeStamp: "1510663494", hash: "0x40c04cfd844ff27bced16a18794dd3ced52e1a154f53aee76eac783661b5005b", nonce: "0", blockHash: "0xf12c35c5e8d6bb041c521b2cc9bf3b0add4ab9af2396a4ac81ac7c55fda132fd", transactionIndex: "19", from: "0x3c7a0daea2862020307bad8441e5d94b57cc65d1", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "251154170000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f00000000000000000000000047083f0e3feb6a5c28950a827e423df2ceb29461000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000386efdefd08c400e08ccfab71ad88a729a3d609f36be26c09b92f153dd287611b0737957c053528000000000000000000000000000000000000000000000000000000000000001ce1923ea1b4b36460b481bdb52cd1f14e1f53f79b72909f0937201de1a4c35cc87d147c7f21e5a0b7b201a3e36f745cfd5bb8f956682500eba2bec45af25fcfff000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "609722", gasUsed: "32837", confirmations: "3188049"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[53], to: addressList[2], value: "251154170000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[54]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "254154170000000000"}, {type: "bytes32", name: "hash", value: "0xe08ccfab71ad88a729a3d609f36be26c09b92f153dd287611b0737957c053528"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xe1923ea1b4b36460b481bdb52cd1f14e1f53f79b72909f0937201de1a4c35cc8"}, {type: "bytes32", name: "s", value: "0x7d147c7f21e5a0b7b201a3e36f745cfd5bb8f956682500eba2bec45af25fcfff"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[54], "833333333299", "254154170000000000", "0xe08ccfab71ad88a729a3d609f36be26c09b92f153dd287611b0737957c053528", "28", "0xe1923ea1b4b36460b481bdb52cd1f14e1f53f79b72909f0937201de1a4c35cc8", "0x7d147c7f21e5a0b7b201a3e36f745cfd5bb8f956682500eba2bec45af25fcfff", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510663494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[53], balance: "728567000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[53], balance: ( await web3.eth.getBalance( addressList[53], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[56], \"833333333299\", \"152... )", async function( ) {
		const txOriginal = {blockNumber: "4551131", timeStamp: "1510663522", hash: "0x5a7e6c0c40ddc84beb52adda91d872d40635439a42a6f54b4e416300f5c7d05d", nonce: "0", blockHash: "0x743a880cfa911e5f7536a6c95fde992533ffbe5e8fa396e93cde31bbcc7429e5", transactionIndex: "14", from: "0xbf7f755c73026d8f1c7d816fc0bdc3a5cb75f7a8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "1521925000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f00000000000000000000000088301044890a87afdffacff1351ed71b2d8405c3000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000015299f35461cd000e7ad3d99a60a2e8cc425d6394506f4accf13594174f2132edcd6d01c385b9040000000000000000000000000000000000000000000000000000000000000001b07c820afc7f52cb81aca8b1aa1c4dd97984af693d7e5e0eca0e8de98cccba1a228d4bb8aa929f63bf137ea3d519415eba3391094efdef137b32b1e7e4dc50ae2000000000000000000000000000000000000000000000000000ad5dd51c5ff30", contractAddress: "", cumulativeGasUsed: "554064", gasUsed: "32901", confirmations: "3188046"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "1521925000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[56]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "1524925000000000000"}, {type: "bytes32", name: "hash", value: "0xe7ad3d99a60a2e8cc425d6394506f4accf13594174f2132edcd6d01c385b9040"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x07c820afc7f52cb81aca8b1aa1c4dd97984af693d7e5e0eca0e8de98cccba1a2"}, {type: "bytes32", name: "s", value: "0x28d4bb8aa929f63bf137ea3d519415eba3391094efdef137b32b1e7e4dc50ae2"}, {type: "uint256", name: "WeiToUSD", value: "3049896303525680"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[56], "833333333299", "1524925000000000000", "0xe7ad3d99a60a2e8cc425d6394506f4accf13594174f2132edcd6d01c385b9040", "27", "0x07c820afc7f52cb81aca8b1aa1c4dd97984af693d7e5e0eca0e8de98cccba1a2", "0x28d4bb8aa929f63bf137ea3d519415eba3391094efdef137b32b1e7e4dc50ae2", "3049896303525680", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510663522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "726583000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"137... )", async function( ) {
		const txOriginal = {blockNumber: "4551136", timeStamp: "1510663633", hash: "0x345829a700990b967270fdab4606c0a608019da0f33aafffeea9c8726daeccd9", nonce: "0", blockHash: "0x0922ecf1bd2279d2020ef62174a83982da952f16056aeacc445b84d806932e60", transactionIndex: "48", from: "0xa18cfe7ba4638420602735cdbb9ecdca1d715c0b", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "1369432500000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000130bdc1658b3880042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000ac60ce762c59f", contractAddress: "", cumulativeGasUsed: "2051679", gasUsed: "32901", confirmations: "3188041"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[57], to: addressList[2], value: "1369432500000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "1372432500000000000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3032508491023775"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "1372432500000000000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3032508491023775", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510663633 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[57], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[57], balance: ( await web3.eth.getBalance( addressList[57], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"302... )", async function( ) {
		const txOriginal = {blockNumber: "4551144", timeStamp: "1510663729", hash: "0xddccb0cc1308ef0776a74114a142a0feaaf79b62ca751b355bcb94bc7b54d18e", nonce: "0", blockHash: "0x4756db28d79a3cda942a3967d42eaa583497a3e0febb4bc54b737135bd2a0551", transactionIndex: "64", from: "0x25a319dbd8a644b3ee3cd3be7a7439632eb262b7", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "30208900000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000001a3463afb019fc00042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000ac60ce762c59f", contractAddress: "", cumulativeGasUsed: "2344800", gasUsed: "32965", confirmations: "3188033"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[58], to: addressList[2], value: "30208900000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "30211900000000000000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3032508491023775"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "30211900000000000000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3032508491023775", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510663729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[58], balance: "889599000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[58], balance: ( await web3.eth.getBalance( addressList[58], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[60], \"833333333299\", \"402... )", async function( ) {
		const txOriginal = {blockNumber: "4551151", timeStamp: "1510663847", hash: "0x77a20d9f30d96aee230aed28c3b2fe76c1d884953af749daa2b57b2f2fdf02da", nonce: "0", blockHash: "0x226ecca3bc760866530147ddce949fd046244d9d600d4358dc682b824d053d61", transactionIndex: "33", from: "0x9703cf02a914ff1513194b7214f11c6a33a48727", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "4025253340000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000e1cf28e17cd517f296d648938d5791c447e6fadc000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000037e73b11f3fb1800ad03ea09f07c34f8bd3b19335c9bfc091aaab8d915342fd5f0214ca04a6bdbf5000000000000000000000000000000000000000000000000000000000000001b410b5b0b25baf042ddea8f6060125397d1e2c94cb505e9cc509c68d379a72bd9600a4a147f234cb11dfb8411b044b1eec3d78bc8978802423f60b286c8165441000000000000000000000000000000000000000000000000000ac60ce762c59f", contractAddress: "", cumulativeGasUsed: "1450404", gasUsed: "32901", confirmations: "3188026"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[59], to: addressList[2], value: "4025253340000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[60]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "4028253340000000000"}, {type: "bytes32", name: "hash", value: "0xad03ea09f07c34f8bd3b19335c9bfc091aaab8d915342fd5f0214ca04a6bdbf5"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x410b5b0b25baf042ddea8f6060125397d1e2c94cb505e9cc509c68d379a72bd9"}, {type: "bytes32", name: "s", value: "0x600a4a147f234cb11dfb8411b044b1eec3d78bc8978802423f60b286c8165441"}, {type: "uint256", name: "WeiToUSD", value: "3032508491023775"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[60], "833333333299", "4028253340000000000", "0xad03ea09f07c34f8bd3b19335c9bfc091aaab8d915342fd5f0214ca04a6bdbf5", "27", "0x410b5b0b25baf042ddea8f6060125397d1e2c94cb505e9cc509c68d379a72bd9", "0x600a4a147f234cb11dfb8411b044b1eec3d78bc8978802423f60b286c8165441", "3032508491023775", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510663847 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[59], balance: "726583000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[59], balance: ( await web3.eth.getBalance( addressList[59], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"833333333299\", \"365... )", async function( ) {
		const txOriginal = {blockNumber: "4551152", timeStamp: "1510663874", hash: "0xa7d8444bacdbb5b6526e311fe3cd5199bdf7554c4436d878d88e6afdcbdd8b32", nonce: "0", blockHash: "0x67a8da24b0380b940f67f7657879ce1306c42e758aabf484507fc93a20eade2b", transactionIndex: "41", from: "0xbb9bbd1910fee5be1537a2b10544b4506dab8ee3", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "362060460000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000eaa18aa58d6327a39334c6c5890cd972e06d428e000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000510f48ddfd7380042deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e000000000000000000000000000000000000000000000000000000000000001ba1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347000000000000000000000000000000000000000000000000000abbb7d783c850", contractAddress: "", cumulativeGasUsed: "1724615", gasUsed: "32901", confirmations: "3188025"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[61], to: addressList[2], value: "362060460000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "365060460000000000"}, {type: "bytes32", name: "hash", value: "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a"}, {type: "bytes32", name: "s", value: "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347"}, {type: "uint256", name: "WeiToUSD", value: "3021148036253776"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[16], "833333333299", "365060460000000000", "0x42deb09dec45dc6b3ec5aa5bcdc910a828a25911444e1d85f0fe88e9ab5cbd0e", "27", "0xa1fc9f1fd0d3503af90cc2a063b406570c4e7acda537d80b9830a976814a150a", "0x6a17c471193e11b838540c1f2c81402f1019fbd6e374b4bc2ef4a538ba8e6347", "3021148036253776", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510663874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[61], balance: "891583000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[61], balance: ( await web3.eth.getBalance( addressList[61], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[63], \"833333333299\", \"755... )", async function( ) {
		const txOriginal = {blockNumber: "4551162", timeStamp: "1510663985", hash: "0xa7c84ad4c4072b1f3a11d9fbd8c1714b3e4a9a130164d27fbb930aeeb250829b", nonce: "0", blockHash: "0x870fb6d6a773334e053db863db64aaeeccd58ce09d5e43e10924eaaa8db3c7a9", transactionIndex: "61", from: "0x88341bd03d188df01ba89765c5dc0150107e23c2", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "752297500000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000871b234fc63523d45def3b8f1753c2cf7975e830000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000a7b5b13133d9800d828a13e5c178be6700c3d683f942497708535f00ad19d8d90d209770fd86a3e000000000000000000000000000000000000000000000000000000000000001c98747a8ceb524161fcbe70f8f23eb52ecd0d3cbd96a14276dfa552e3c3ab7b2e414102a2dc8e731ed49b8831378e86e46ef50a678826ebb7bd475faaf35b958d000000000000000000000000000000000000000000000000000abbb7d783c850", contractAddress: "", cumulativeGasUsed: "1675393", gasUsed: "32901", confirmations: "3188015"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[62], to: addressList[2], value: "752297500000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[63]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "755297500000000000"}, {type: "bytes32", name: "hash", value: "0xd828a13e5c178be6700c3d683f942497708535f00ad19d8d90d209770fd86a3e"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x98747a8ceb524161fcbe70f8f23eb52ecd0d3cbd96a14276dfa552e3c3ab7b2e"}, {type: "bytes32", name: "s", value: "0x414102a2dc8e731ed49b8831378e86e46ef50a678826ebb7bd475faaf35b958d"}, {type: "uint256", name: "WeiToUSD", value: "3021148036253776"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[63], "833333333299", "755297500000000000", "0xd828a13e5c178be6700c3d683f942497708535f00ad19d8d90d209770fd86a3e", "28", "0x98747a8ceb524161fcbe70f8f23eb52ecd0d3cbd96a14276dfa552e3c3ab7b2e", "0x414102a2dc8e731ed49b8831378e86e46ef50a678826ebb7bd475faaf35b958d", "3021148036253776", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510663985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[62], balance: "726583000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[62], balance: ( await web3.eth.getBalance( addressList[62], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[65], \"833333333299\", \"629... )", async function( ) {
		const txOriginal = {blockNumber: "4551177", timeStamp: "1510664118", hash: "0x9bc77ac1a9639c59fa7675134fca9d36c5b2f45a19242ae98d3ffcf8c7d3990c", nonce: "0", blockHash: "0x667320fd0c97a9458f2d8e53144590445874fecc4844dda4bf6465001a393841", transactionIndex: "33", from: "0x107924da640e4136540a87ab5a6a92124373672d", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "626414590000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f000000000000000000000000e9b8de5a33bb189ee862fa2d38df9cf9c12a238e000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000008bc213c1d65ec00f5b0b838ff2ef9417a03d6894eff8f21fab0fd580a48e177cd3f149394d23ca1000000000000000000000000000000000000000000000000000000000000001cb47e2bc236c30b0cebc4277865456dba11fba4d86f80db517288d06cfbfe627c662f02933ebac17c1db5dc58823740ebc6788717653c85d714f8e9fd4526c767000000000000000000000000000000000000000000000000000abbb7d783c850", contractAddress: "", cumulativeGasUsed: "1170390", gasUsed: "32901", confirmations: "3188000"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[64], to: addressList[2], value: "626414590000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[65]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "629414590000000000"}, {type: "bytes32", name: "hash", value: "0xf5b0b838ff2ef9417a03d6894eff8f21fab0fd580a48e177cd3f149394d23ca1"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xb47e2bc236c30b0cebc4277865456dba11fba4d86f80db517288d06cfbfe627c"}, {type: "bytes32", name: "s", value: "0x662f02933ebac17c1db5dc58823740ebc6788717653c85d714f8e9fd4526c767"}, {type: "uint256", name: "WeiToUSD", value: "3021148036253776"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[65], "833333333299", "629414590000000000", "0xf5b0b838ff2ef9417a03d6894eff8f21fab0fd580a48e177cd3f149394d23ca1", "28", "0xb47e2bc236c30b0cebc4277865456dba11fba4d86f80db517288d06cfbfe627c", "0x662f02933ebac17c1db5dc58823740ebc6788717653c85d714f8e9fd4526c767", "3021148036253776", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510664118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[64], balance: "726583000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[64], balance: ( await web3.eth.getBalance( addressList[64], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[67], \"833333333299\", \"984... )", async function( ) {
		const txOriginal = {blockNumber: "4551190", timeStamp: "1510664241", hash: "0x19b1f64c3da2d84467e663009f143db9ce68c753d93a307887348606778ebbcd", nonce: "0", blockHash: "0x6f4cc6b86d290e221ff343d68e2284bc06d4015d2d36d3b8f40f557768869b23", transactionIndex: "21", from: "0x5183f49b4e88ad23e541b1daf7ed1e5f462063bc", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "981506250000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000006e732ae8f126c0a41fb22fa06566e9806005f57d000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000da9ab37de66e40077e467ef61349ff37a3b2432f6a85fb7b9214e14b1638b1c6bf4dfd42d02c98d000000000000000000000000000000000000000000000000000000000000001b9e40acccb8201f76082d524191d07ed57ae8dfdb58677b0e5c6c81433d762bc10832b6f9f62b8ea75690b64454f6ea7f3ddaf6c036db1f463a9efd153ef4d848000000000000000000000000000000000000000000000000000ac30aef8235e9", contractAddress: "", cumulativeGasUsed: "596111", gasUsed: "32901", confirmations: "3187987"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "981506250000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[67]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "984506250000000000"}, {type: "bytes32", name: "hash", value: "0x77e467ef61349ff37a3b2432f6a85fb7b9214e14b1638b1c6bf4dfd42d02c98d"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x9e40acccb8201f76082d524191d07ed57ae8dfdb58677b0e5c6c81433d762bc1"}, {type: "bytes32", name: "s", value: "0x0832b6f9f62b8ea75690b64454f6ea7f3ddaf6c036db1f463a9efd153ef4d848"}, {type: "uint256", name: "WeiToUSD", value: "3029201502483945"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[67], "833333333299", "984506250000000000", "0x77e467ef61349ff37a3b2432f6a85fb7b9214e14b1638b1c6bf4dfd42d02c98d", "27", "0x9e40acccb8201f76082d524191d07ed57ae8dfdb58677b0e5c6c81433d762bc1", "0x0832b6f9f62b8ea75690b64454f6ea7f3ddaf6c036db1f463a9efd153ef4d848", "3029201502483945", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510664241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "726583000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[69], \"833333333299\", \"302... )", async function( ) {
		const txOriginal = {blockNumber: "4551197", timeStamp: "1510664412", hash: "0x3e30e76baddc38e7cbf4370d83fbb5cbf4297aa13de054e8ea26f0fc8149549d", nonce: "0", blockHash: "0x3aac46c6ad126145a5433c54c426a5033e52518e5c415482a2e8be65755e5872", transactionIndex: "36", from: "0x19d2c72ecf6c8d65f85cbff4486ce85da6322c89", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "27292500000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x6e3ac99f0000000000000000000000005f2f6e9d1de9820d26752a8dac3ff802db507f21000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000006b9ede45dbc8008eebacc45596257c24597a5e7d2f89d933a6b9e3cf616e96b2ebb4c93aa53004000000000000000000000000000000000000000000000000000000000000001c1fbbd059b96cf92ce18625fd2d26b368e43cc95e020a884a9b0b909bb02305957440e5d5ef82ddeb4dd4dac7a224f3936b944186945e69c44640f9ac28a550d5000000000000000000000000000000000000000000000000000ac30aef8235e9", contractAddress: "", cumulativeGasUsed: "1082141", gasUsed: "32837", confirmations: "3187980"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[68], to: addressList[2], value: "27292500000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[69]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInWei", value: "30292500000000000"}, {type: "bytes32", name: "hash", value: "0x8eebacc45596257c24597a5e7d2f89d933a6b9e3cf616e96b2ebb4c93aa53004"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x1fbbd059b96cf92ce18625fd2d26b368e43cc95e020a884a9b0b909bb0230595"}, {type: "bytes32", name: "s", value: "0x7440e5d5ef82ddeb4dd4dac7a224f3936b944186945e69c44640f9ac28a550d5"}, {type: "uint256", name: "WeiToUSD", value: "3029201502483945"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256,uint256,bytes32,uint8,bytes32,bytes32,uint256)" ]( addressList[69], "833333333299", "30292500000000000", "0x8eebacc45596257c24597a5e7d2f89d933a6b9e3cf616e96b2ebb4c93aa53004", "28", "0x1fbbd059b96cf92ce18625fd2d26b368e43cc95e020a884a9b0b909bb0230595", "0x7440e5d5ef82ddeb4dd4dac7a224f3936b944186945e69c44640f9ac28a550d5", "3029201502483945", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510664412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[68], balance: "893567000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[68], balance: ( await web3.eth.getBalance( addressList[68], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[70], \"833333333299\", \"461... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0x03a52e82b6d7a465f57bc2ea34ae3eba38a610d528b4b00631705f7a4c82766c", nonce: "25", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "176", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d000000000000000000000000c94dc73a2677e012fb6260c680ce5344e3aeaab8000000000000000000000000000000000000000000000000000000c206898d330000000000000000000000000000000000000000000000000000000000466d4b00000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bc60000000000000000000000000000000000000000000000000000000000000022314745333573694b65797444327876346a35656e546a6d435a3262586a71514d625a000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6123265", gasUsed: "81486", confirmations: "3180610"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[70]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "4615499"}, {type: "string", name: "btcAddress", value: `1GE35siKeytD2xv4j5enTjmCZ2bXjqQMbZ`}, {type: "uint256", name: "satoshiToUSD", value: "15302"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[70], "833333333299", "4615499", `1GE35siKeytD2xv4j5enTjmCZ2bXjqQMbZ`, "15302", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0xc94dc73a2677e012fb6260c680ce5344e3aeaab8"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12751"}, {name: "investedInSatoshi", type: "uint256", value: "4615499"}, {name: "investedInPicoUsd", type: "uint256", value: "301627172918572"}, {name: "tokensNumber", type: "uint256", value: "361971531644576895929"}, {name: "btcAddress", type: "string", value: "1GE35siKeytD2xv4j5enTjmCZ2bXjqQMbZ"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0xc94dc73a2677e012fb6260c680ce5344e3aeaab8"}, {name: "value", type: "uint256", value: "361971531644576895929"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[71], \"833333333299\", \"127... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0x88487862c7396f31228298fe02329529f495d7552f84d9ab00f601d4374aab39", nonce: "26", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "177", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d0000000000000000000000001c12ba97b2c310efef6ec41c4972ab84570fe69e000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000000000000000031cd00000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bc600000000000000000000000000000000000000000000000000000000000000223132504e707952743439397a33587054757769505231646333695831773576334c58000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6189687", gasUsed: "66422", confirmations: "3180610"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[71]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "12749"}, {type: "string", name: "btcAddress", value: `12PNpyRt499z3XpTuwiPR1dc3iX1w5v3LX`}, {type: "uint256", name: "satoshiToUSD", value: "15302"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[71], "833333333299", "12749", `12PNpyRt499z3XpTuwiPR1dc3iX1w5v3LX`, "15302", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0x1c12ba97b2c310efef6ec41c4972ab84570fe69e"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12751"}, {name: "investedInSatoshi", type: "uint256", value: "12749"}, {name: "investedInPicoUsd", type: "uint256", value: "833159064174"}, {name: "tokensNumber", type: "uint256", value: "999843149556897498"}, {name: "btcAddress", type: "string", value: "12PNpyRt499z3XpTuwiPR1dc3iX1w5v3LX"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0x1c12ba97b2c310efef6ec41c4972ab84570fe69e"}, {name: "value", type: "uint256", value: "999843149556897498"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[72], \"833333333299\", \"407... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0x64db8598bc508205be3c4477168cba22f47a9bfea17f66a6eeb6e8a05ec100c5", nonce: "27", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "178", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d000000000000000000000000d215506a796b506e87996a8f5d815c80d5937e35000000000000000000000000000000000000000000000000000000c206898d3300000000000000000000000000000000000000000000000000000000003e417f00000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bb90000000000000000000000000000000000000000000000000000000000000022313551545076456d3361514378586541334e34744b72795a545231586e676d704179000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6256173", gasUsed: "66486", confirmations: "3180610"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[72]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "4079999"}, {type: "string", name: "btcAddress", value: `15QTPvEm3aQCxXeA3N4tKryZTR1XngmpAy`}, {type: "uint256", name: "satoshiToUSD", value: "15289"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[72], "833333333299", "4079999", `15QTPvEm3aQCxXeA3N4tKryZTR1XngmpAy`, "15289", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0xd215506a796b506e87996a8f5d815c80d5937e35"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12740"}, {name: "investedInSatoshi", type: "uint256", value: "4079999"}, {name: "investedInPicoUsd", type: "uint256", value: "266858460330956"}, {name: "tokensNumber", type: "uint256", value: "320251098901098901098"}, {name: "btcAddress", type: "string", value: "15QTPvEm3aQCxXeA3N4tKryZTR1XngmpAy"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0xd215506a796b506e87996a8f5d815c80d5937e35"}, {name: "value", type: "uint256", value: "320251098901098901098"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[43,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[73], \"833333333299\", \"191... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0x11f4e6a81772e3dedb3f0517e842edced6966d8cbcfe9ec4b2e2150f0ef9f6ac", nonce: "28", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "179", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d0000000000000000000000005a1a7a7019c1236fad4f65c595bf5afe76a956d0000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000000000000002eb1100000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bd50000000000000000000000000000000000000000000000000000000000000022314c4336676957576342334b374267777276533842333934664d43335346794e776e000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6322659", gasUsed: "66486", confirmations: "3180610"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[73]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "191249"}, {type: "string", name: "btcAddress", value: `1LC6giWWcB3K7BgwrvS8B394fMC3SFyNwn`}, {type: "uint256", name: "satoshiToUSD", value: "15317"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[73], "833333333299", "191249", `1LC6giWWcB3K7BgwrvS8B394fMC3SFyNwn`, "15317", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0x5a1a7a7019c1236fad4f65c595bf5afe76a956d0"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12764"}, {name: "investedInSatoshi", type: "uint256", value: "191249"}, {name: "investedInPicoUsd", type: "uint256", value: "12486061239146"}, {name: "tokensNumber", type: "uint256", value: "14983469131933563146"}, {name: "btcAddress", type: "string", value: "1LC6giWWcB3K7BgwrvS8B394fMC3SFyNwn"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0x5a1a7a7019c1236fad4f65c595bf5afe76a956d0"}, {name: "value", type: "uint256", value: "14983469131933563146"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[44,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[74], \"833333333299\", \"231... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0x6a6266b857bf615da6b4a1871fbb998be17bba7df06180feb699ba6b758c54c3", nonce: "29", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "180", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d000000000000000000000000670bef8fb4447a1199f282e25f349d4e18ccd719000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000000000000003884b00000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bd50000000000000000000000000000000000000000000000000000000000000022313861424358486a66687477704a636f736f45674d57654e70396574795064633555000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6389145", gasUsed: "66486", confirmations: "3180610"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[74]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "231499"}, {type: "string", name: "btcAddress", value: `18aBCXHjfhtwpJcosoEgMWeNp9etyPdc5U`}, {type: "uint256", name: "satoshiToUSD", value: "15317"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[74], "833333333299", "231499", `18aBCXHjfhtwpJcosoEgMWeNp9etyPdc5U`, "15317", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0x670bef8fb4447a1199f282e25f349d4e18ccd719"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12764"}, {name: "investedInSatoshi", type: "uint256", value: "231499"}, {name: "investedInPicoUsd", type: "uint256", value: "15113860416530"}, {name: "tokensNumber", type: "uint256", value: "18136869319962394233"}, {name: "btcAddress", type: "string", value: "18aBCXHjfhtwpJcosoEgMWeNp9etyPdc5U"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0x670bef8fb4447a1199f282e25f349d4e18ccd719"}, {name: "value", type: "uint256", value: "18136869319962394233"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[45,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[75], \"833333333299\", \"127... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0x8fd686a585aaa6f06e52e5da2e94a565bc5191b96316dd55e310d84ef4eb9580", nonce: "30", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "181", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d0000000000000000000000007c648174a504ce293609af04203d9c3c0fea53db000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000000000000013747700000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bd500000000000000000000000000000000000000000000000000000000000000223135316b32484838435673744b70544d626f514b4a675a5335696f7537667658736d000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6455631", gasUsed: "66486", confirmations: "3180610"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[75]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "1274999"}, {type: "string", name: "btcAddress", value: `151k2HH8CVstKpTMboQKJgZS5iou7fvXsm`}, {type: "uint256", name: "satoshiToUSD", value: "15317"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[75], "833333333299", "1274999", `151k2HH8CVstKpTMboQKJgZS5iou7fvXsm`, "15317", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0x7c648174a504ce293609af04203d9c3c0fea53db"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12764"}, {name: "investedInSatoshi", type: "uint256", value: "1274999"}, {name: "investedInPicoUsd", type: "uint256", value: "83240778220278"}, {name: "tokensNumber", type: "uint256", value: "99890238169852710748"}, {name: "btcAddress", type: "string", value: "151k2HH8CVstKpTMboQKJgZS5iou7fvXsm"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0x7c648174a504ce293609af04203d9c3c0fea53db"}, {name: "value", type: "uint256", value: "99890238169852710748"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[46,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[76], \"833333333299\", \"611... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0x5a07633cfb0c1c76d66782955aca349f2647bab8bd60ae81e374267cd2a3270b", nonce: "31", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "182", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d00000000000000000000000046486a69b524aea40eb62513afffc9a771b009a0000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000000000000009569f00000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bd50000000000000000000000000000000000000000000000000000000000000022314b33536539436743645867524732656a427048536435696f765748444e4b426739000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6522117", gasUsed: "66486", confirmations: "3180610"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[76]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "611999"}, {type: "string", name: "btcAddress", value: `1K3Se9CgCdXgRG2ejBpHSd5iovWHDNKBg9`}, {type: "uint256", name: "satoshiToUSD", value: "15317"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[76], "833333333299", "611999", `1K3Se9CgCdXgRG2ejBpHSd5iovWHDNKBg9`, "15317", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0x46486a69b524aea40eb62513afffc9a771b009a0"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12764"}, {name: "investedInSatoshi", type: "uint256", value: "611999"}, {name: "investedInPicoUsd", type: "uint256", value: "39955539596526"}, {name: "tokensNumber", type: "uint256", value: "47947273581949232215"}, {name: "btcAddress", type: "string", value: "1K3Se9CgCdXgRG2ejBpHSd5iovWHDNKBg9"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0x46486a69b524aea40eb62513afffc9a771b009a0"}, {name: "value", type: "uint256", value: "47947273581949232215"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[47,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[77], \"833333333299\", \"127... )", async function( ) {
		const txOriginal = {blockNumber: "4558567", timeStamp: "1510767782", hash: "0xde9b9d6ccf5b51a6c43dd6c7cb43a398ff10d31c392e1125582e4fc94b569913", nonce: "32", blockHash: "0x58821ce2eaa323cd48aab73ed5144fc6d0579deeaa2534bdad73ef55791f1bc9", transactionIndex: "183", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d000000000000000000000000c206146350163e5aedc0112190cdc53959218c68000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000000000000013747700000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bd50000000000000000000000000000000000000000000000000000000000000022314b6a344d6933626a36324652417132656253315851444c4e364545624b544b7973000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6588603", gasUsed: "66486", confirmations: "3180610"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[77]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "1274999"}, {type: "string", name: "btcAddress", value: `1Kj4Mi3bj62FRAq2ebS1XQDLN6EEbKTKys`}, {type: "uint256", name: "satoshiToUSD", value: "15317"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[77], "833333333299", "1274999", `1Kj4Mi3bj62FRAq2ebS1XQDLN6EEbKTKys`, "15317", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510767782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0xc206146350163e5aedc0112190cdc53959218c68"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12764"}, {name: "investedInSatoshi", type: "uint256", value: "1274999"}, {name: "investedInPicoUsd", type: "uint256", value: "83240778220278"}, {name: "tokensNumber", type: "uint256", value: "99890238169852710748"}, {name: "btcAddress", type: "string", value: "1Kj4Mi3bj62FRAq2ebS1XQDLN6EEbKTKys"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0xc206146350163e5aedc0112190cdc53959218c68"}, {name: "value", type: "uint256", value: "99890238169852710748"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[48,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: investInBTC( addressList[14], \"833333333299\", \"637... )", async function( ) {
		const txOriginal = {blockNumber: "4558568", timeStamp: "1510767799", hash: "0x257949bf407be2874ae371f576aac5625c2bb9b37359aece7b2e6316ac1d0081", nonce: "33", blockHash: "0xfff08e827c95c6c580a46fa15f3053730d84a63a72f96ccc1140523a3ad6235d", transactionIndex: "14", from: "0x9db07c8da33a2fcd6ef2e727a2ecc5198d9bc7c8", to: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33", value: "0", gas: "150000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6a93413d0000000000000000000000000ad9fb61a07bac25625382b63693644497f1b204000000000000000000000000000000000000000000000000000000c206898d33000000000000000000000000000000000000000000000000000000000009ba3b00000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000003bcd0000000000000000000000000000000000000000000000000000000000000022313552694333723976754b4a4c626a36427979387576524462636139466b43547a75000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "565275", gasUsed: "66486", confirmations: "3180609"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[14]}, {type: "uint256", name: "tokenPriceInPicoUsd", value: "833333333299"}, {type: "uint256", name: "investedInSatoshi", value: "637499"}, {type: "string", name: "btcAddress", value: `15RiC3r9vuKJLbj6Byy8uvRDbca9FkCTzu`}, {type: "uint256", name: "satoshiToUSD", value: "15309"}], name: "investInBTC", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investInBTC(address,uint256,uint256,string,uint256)" ]( addressList[14], "833333333299", "637499", `15RiC3r9vuKJLbj6Byy8uvRDbca9FkCTzu`, "15309", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510767799 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenPriceInSatoshi", type: "uint256"}, {indexed: false, name: "investedInSatoshi", type: "uint256"}, {indexed: false, name: "investedInPicoUsd", type: "uint256"}, {indexed: false, name: "tokensNumber", type: "uint256"}, {indexed: false, name: "btcAddress", type: "string"}], name: "InvestmentInBTC", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestmentInBTC", events: [{name: "investor", type: "address", value: "0x0ad9fb61a07bac25625382b63693644497f1b204"}, {name: "tokenPriceInSatoshi", type: "uint256", value: "12757"}, {name: "investedInSatoshi", type: "uint256", value: "637499"}, {name: "investedInPicoUsd", type: "uint256", value: "41642105950747"}, {name: "tokensNumber", type: "uint256", value: "49972485694128713647"}, {name: "btcAddress", type: "string", value: "15RiC3r9vuKJLbj6Byy8uvRDbca9FkCTzu"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1111111111111111111111111111111111111111"}, {name: "to", type: "address", value: "0x0ad9fb61a07bac25625382b63693644497f1b204"}, {name: "value", type: "uint256", value: "49972485694128713647"}], address: "0x4b24f0c8230c06e0d7caf722ace3f22ba5b80c33"}] ;
		console.error( "eventResultOriginal[49,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "819486439264250000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
