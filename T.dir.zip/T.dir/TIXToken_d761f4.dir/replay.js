var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "TIXToken"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xEa1f346faF023F974Eb5adaf088BbCdf02d761F4","0x00E0689e16232945F97C27BdE102A054E2108670","0x6750C97aa8a1b388Ed560a06AeFd64d457455bA7","0xFAc32D9dAcaE98b7d14408b0122aA7917baD8a67","0xB9E34aB79C29F182F4ff40399d6e1885ABE23067","0x006CF81F9aDb68d134a28847b42f746D6Bd926aa","0xf7C2387B3D387A042084ecA33D622119Bfd28963","0x47B10f4680fa24B1DDA05Ed14661f687C67cA438","0xe2e8Bcb2124580765676B0852c928D4d39EEE9ea","0xC41AE00fdD597f87957462eeb0201FcdAf3AbC2c","0xaf51971af8DA2C7a2C543894cEdA858810Df868b","0x6A691cf2fB2c66863cbfF7c6AED7A53B2d1423ce","0x00F10de5bf1Ed8d8359De2A5696C9Dd0C2988558","0x6165027e094edb51714DA40fc2eDe80154aD907E","0xA280c9673E1E2804Ca1B2c900A328e653a507cfC","0xf7997C41C50D28A77125546c9811628dCc131235","0xB5eB97ACCdc1Ad786a8b3B090457c4Ef6F2CC476","0xEcEB1e7B77e430fB771f9222ec2941E4D734c9B1","0xc4AD0b9174DBe86CBFB53a218074607CC261dF6d","0xC05ECc0237cD9742607043710372FE4B1f30B60d","0x832Fd0BBC5b277Dde794365459E69c828D9f051B","0xe287E1421e7e00a97d25712288767b89a7e814e4","0xC84623e8BCD7Ad3fed1b638E38F66065528C857f","0x5EB1Ca2D9d250Ffad144c7B6F0191FAFC97ae1EE","0x3F9698750a24C02Fb97B0C51f7468028A435c513","0x93e0890C89d36E8789b0Bd064e2429C46D8e8141","0x6DD4E0d75069B6F7721B677C926BdD73Cfe3f375","0xCdB14d72970fD8caD810639B9e63C21F969FC01E","0xfCB4cf5EA91Dc8A59Fb0aE575BAb599cFbd8EA5c","0x46eA4CA293c74232961702156541869660975f13","0xe4fE9d9B6D1a69F0Fc5Ef21b1e6b525782054AA5","0x4a61DD80d1715DB0b03Eb4C62FBbCe21990DF633","0x763C2424Aa9C1CaEfFbecF25513BA7627f4D177e","0x56283F0Cf361e8eB712DcC48B2bF374300A3e728","0x00138888221A216e5c865986a6E421eF6deF30ea","0x50aF176098BD850D053dB21e2220f49F225f21F4","0x525cfC07F5E47a100D157a29B7250590F8d258Ea","0x08207c9CF23b8d379B43B947701dFdDe5A6d28Fe","0x09E00cDF78B1d595d32c8B3433002675B1942bD5","0xBeb0A51DCB08D844689aBAA3adB328421850403B","0x97Df0f036aBa23CF427e45Dd4B9B7914FA38b2fC","0x83098B378E17Ad65B757176731615372f1CCe1Ef","0x40486a01E98842821Dd628084a99F67d9A80eBD2","0xa9807657aC5Da7527F42E678CcAF2Ab867e83cB5","0x0C22A65DA50Ff23a3b8e236D586FE7e3e01dDbA5","0x9a3D6B710c1F85Cb4f44DDb40871D987233b8728","0xFB713BaF73588aB2c9Af035546C8fdf4DD154DE0","0xCF65Ee3e20CDE83b516976735A3ab49FadfCd1e1","0xfc040516A6A113dfd010F43c273Aa8d0F90Cd6bd","0xf7165fa3371f99aE47991Ba98A4Fd5A769b5C2F8","0xC3907B84a23a9077A2db5FDf39F48Ff38927FD56","0x0A4f9f2bA507788803cd48a0e19C3d45DF897482"]
addressListOriginal.length = 54
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"tixGenerationContract","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"endTime","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"who","type":"address"}],"name":"hasConverted","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"tokenExchangeRate","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"version","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"startTime","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"isFinalized","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"ethFundDeposit","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"tokenGenerationCap","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"remaining","type":"uint256"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"_to","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"CreateTIX","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]
eventSignatureListOriginal = ["CreateTIX(address,uint256)","Approval(address,address,uint256)","Transfer(address,address,uint256)"]
topicListOriginal = ["0x88034bc50ada5f0c75211395735d93a888fdf6ee77d30b9b4637c67d4f8e2404","0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925","0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"]
nBlocksOriginal = 50
fromBlockOriginal = 3998293
toBlockOriginal = 3998332
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"_tixGenerationContract","value":4}],"name":"TIXToken","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"3998293","timeStamp":"1499605735","hash":"0xd04cb53c983095312e7356df1a5573118bd1553a1f6b1e6d32cdfe22a9667d53","nonce":"3","blockHash":"0xc797790d0ef077f6d6b6061786df3c2fbbed007b0f28d8ceba89d53a9dd467b9","transactionIndex":"60","from":"0x00e0689e16232945f97c27bde102a054e2108670","to":0,"value":"0","gas":"1416538","gasPrice":"20887260762","isError":"0","txreceipt_status":"","input":"0x169fab660000000000000000000000006750c97aa8a1b388ed560a06aefd64d457455ba7","contractAddress":"0xea1f346faf023f974eb5adaf088bbcdf02d761f4","cumulativeGasUsed":"4235624","gasUsed":"1180448","confirmations":"3680892"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"address","name":"_tixGenerationContract","value":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"}],"name":"TIXToken","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
