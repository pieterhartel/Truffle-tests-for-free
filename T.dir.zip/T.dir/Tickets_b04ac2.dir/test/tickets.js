const Tickets = artifacts.require( "./Tickets.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Tickets" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x2B0067E8a59A66a4Fbf370b70d21133400b04AC2", "0x6847Ad605d8A17e97434cF8c7D37082241d4F7f5", "0x363c42De26a47B05ffca269bb2202851FD8725D2", "0x4C3343bbFa7daC896CD0e3795F46187134ab28BB", "0x6A5F3CC68F323AA306c018b21EFb3c23Db2d46D5", "0x52862F49349596e9754dE2D9640feAa590342C3D", "0x4E7fB090B8cF9A09e72AC8d9281E504c5d8d0Efb", "0xd68Cd4339AD6792369B6c7F5dF7646cdC6a5296E", "0x025109BE24Cd6DDb4AB070a875Fc4874A0855ba8", "0x16eA592D189B1448BeC5D99D09649eaa372417FC", "0x9421190982099698c06EefdCf718Dba2C7e591aD", "0xDfE3aB8ABC253f1cE1aE54a3D0EFb1dD270F692A", "0xDA535208eAC6101bDf381b4BFFE70e38c403e602"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "uint256"}], name: "bookingList", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "Ticket_Price", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "holders", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "uint256"}], name: "seatsList", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "booking", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "usedTickets", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "seatsCount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "amountOfBooked", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "Rate_Eth", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "additionalInfo", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "limitPerHolder", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogRedeemTicket", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogBookTicket", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}], name: "LogCancelReservation", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogAllocateTicket(uint256,address,string)", "LogTransfer(address,address,uint256,string)", "LogRedeemTicket(uint256,address,string)", "LogBookTicket(uint256,address,string)", "LogCancelReservation(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x325da1c079ba1ad1c87a7106a02612c9583e98e5b035774f64266a59dbba7f35", "0x203fec235ea7d9663d02624ce0cc0c799e634d70b9252743f7508c5784335c90", "0xf0d89e6782f49465766ea9956ba87b1405461ad7478d2d1472d728ca935a0d95", "0x5124367685c9bcfde61c6ba0ec714955a0dda99a7a95516b13a86e4b87fdbbd6", "0xa6f204457119ac6f8ae49e90892ef56e7ee3939a4042419a6acd3c7fc6e4af29"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4490207 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4546169 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_ManagerForRate", value: 4}, {type: "address", name: "_Manager", value: 5}, {type: "address", name: "_Company", value: 6}], name: "Tickets", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "bookingList", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bookingList(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "Ticket_Price", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "Ticket_Price()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "holders", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "holders(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "seatsList", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seatsList(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "booking", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "booking(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "usedTickets", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "usedTickets(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seatsCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seatsCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "amountOfBooked", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "amountOfBooked(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "Rate_Eth", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "Rate_Eth()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "additionalInfo", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "additionalInfo(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "limitPerHolder", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "limitPerHolder()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Tickets", function( accounts ) {

	it( "TEST: Tickets( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4490207", timeStamp: "1509819475", hash: "0xe86d15afedd468af3c570c76496b56be63ce364f35a648e311d455d8908b9da6", nonce: "1", blockHash: "0xce06717c0590505fe33110fb9c2a7404c6cab864bc7eccc5aaaf7a30bf4c941a", transactionIndex: "21", from: "0x6847ad605d8a17e97434cf8c7d37082241d4f7f5", to: 0, value: "0", gas: "2820332", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x67fb8bab000000000000000000000000363c42de26a47b05ffca269bb2202851fd8725d20000000000000000000000004c3343bbfa7dac896cd0e3795f46187134ab28bb0000000000000000000000006a5f3cc68f323aa306c018b21efb3c23db2d46d5", contractAddress: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", cumulativeGasUsed: "4479991", gasUsed: "2820332", confirmations: "3244728"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_ManagerForRate", value: addressList[4]}, {type: "address", name: "_Manager", value: addressList[5]}, {type: "address", name: "_Company", value: addressList[6]}], name: "Tickets", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Tickets.new( addressList[4], addressList[5], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509819475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Tickets.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "672062754000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"1\", addressList[7], `тест большой зал... )", async function( ) {
		const txOriginal = {blockNumber: "4507023", timeStamp: "1510052600", hash: "0xc39af2268fb055e9d3be4786fbb7c1bebcf56068863a406657715c08376b87a1", nonce: "0", blockHash: "0x17471f9710a174c9a90e98ab9c95cc795624edbead09dda6ed810969c48b6127", transactionIndex: "15", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000100000000000000000000000052862f49349596e9754de2d9640feaa590342c3d00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000043d182d0b5d181d18220d0b1d0bed0bbd18cd188d0bed0b920d0b7d0b0d0bb20357c414d593138383236357c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "642787", gasUsed: "175414", confirmations: "3227912"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "1"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `тест большой зал 5|AMY188265||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "1", addressList[7], `тест большой зал 5|AMY188265||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510052600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "1"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188265||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"2\", addressList[7], `тест большой зал... )", async function( ) {
		const txOriginal = {blockNumber: "4507025", timeStamp: "1510052646", hash: "0xa03e5a312391a4409b3fd8d43730ca50e8899df4b22b1c8cc7fd26a402407cfd", nonce: "1", blockHash: "0x0bba1020d1b2f16f4edaf22a9c5634315e92e712e97ab4cda352d7b3fcc13be8", transactionIndex: "6", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000200000000000000000000000052862f49349596e9754de2d9640feaa590342c3d00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000043d182d0b5d181d18220d0b1d0bed0bbd18cd188d0bed0b920d0b7d0b0d0bb20357c414d593138383236377c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "381006", gasUsed: "161028", confirmations: "3227910"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "2"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `тест большой зал 5|AMY188267||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "2", addressList[7], `тест большой зал 5|AMY188267||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510052646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "2"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188267||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"3\", addressList[8], `тест большой зал... )", async function( ) {
		const txOriginal = {blockNumber: "4507049", timeStamp: "1510052953", hash: "0x8d773eecd2bb47959fb6960c3b59c7075322207a15ca1b2c20b6cc3f23fbbfc5", nonce: "2", blockHash: "0x1f259ff2e6dbb8b3d8b430308f5494f6169f5ba4b58f73b20e755f6d4412603e", transactionIndex: "2", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x7856684500000000000000000000000000000000000000000000000000000000000000030000000000000000000000004e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000043d182d0b5d181d18220d0b1d0bed0bbd18cd188d0bed0b920d0b7d0b0d0bb20357c414d593138383236397c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "279515", gasUsed: "175414", confirmations: "3227886"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "3"}, {type: "address", name: "buyer", value: addressList[8]}, {type: "string", name: "infoString", value: `тест большой зал 5|AMY188269||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "3", addressList[8], `тест большой зал 5|AMY188269||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510052953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "3"}, {name: "_buyer", type: "address", value: "0x4e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188269||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"4\", addressList[7], `тест большой зал... )", async function( ) {
		const txOriginal = {blockNumber: "4507051", timeStamp: "1510052961", hash: "0x2d88cd284468d455f22ca0b091d8fab2363e2541a738821204ead4e033cec95c", nonce: "3", blockHash: "0x948c013c9512b89b5b909511d24e3a82dc6b4b85a31de7e6adb70cc3a1ab8068", transactionIndex: "1", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000400000000000000000000000052862f49349596e9754de2d9640feaa590342c3d00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000043d182d0b5d181d18220d0b1d0bed0bbd18cd188d0bed0b920d0b7d0b0d0bb20357c414d593138383236367c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "182693", gasUsed: "161642", confirmations: "3227884"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "4"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `тест большой зал 5|AMY188266||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "4", addressList[7], `тест большой зал 5|AMY188266||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510052961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "4"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188266||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: redeemTicket( \"3\", addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "4507053", timeStamp: "1510052994", hash: "0x18c19259030a6db837b7b433a811867a8c88ea31c5e7a28429c77d02bcf2b7cc", nonce: "4", blockHash: "0xcdb4f86057f7c95d1f5a84bcf6ced456b9744e76a19d0e50387196d4f9ac76ff", transactionIndex: "9", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xba02021d00000000000000000000000000000000000000000000000000000000000000030000000000000000000000004e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb", contractAddress: "", cumulativeGasUsed: "457222", gasUsed: "49111", confirmations: "3227882"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "3"}, {type: "address", name: "holder", value: addressList[8]}], name: "redeemTicket", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "redeemTicket(uint256,address)" ]( "3", addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510052994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogRedeemTicket", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogRedeemTicket", events: [{name: "_seatID", type: "uint256", value: "3"}, {name: "_holder", type: "address", value: "0x4e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188269||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"5\", addressList[9], `Crypto on stage|... )", async function( ) {
		const txOriginal = {blockNumber: "4507182", timeStamp: "1510054817", hash: "0x8744f634b12966bd9e8c19530a0571882795b27672ab95ece82b8fe66919c468", nonce: "5", blockHash: "0xaa5a6ac5271328247a7f63b6b1e511171d1556910c04b4a07e6c361e06484c57", transactionIndex: "94", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x785668450000000000000000000000000000000000000000000000000000000000000005000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000005d43727970746f206f6e2073746167657c4358583134343531377cd09fd0b0d180d182d0b5d1802c20d09fd180d0b0d0b2d0b0d18f20d181d182d0bed180d0bed0bdd0b07c31307c31307cd094d0b5d182d18fd0bc7c3330303030525542000000", contractAddress: "", cumulativeGasUsed: "4507702", gasUsed: "177286", confirmations: "3227753"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "5"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `Crypto on stage|CXX144517|Партер, Правая сторона|10|10|Детям|30000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "5", addressList[9], `Crypto on stage|CXX144517|Партер, Правая сторона|10|10|Детям|30000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510054817 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "5"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX144517|Партер, Правая сторона|10|10|Детям|30000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"6\", addressList[9], `Crypto on stage|... )", async function( ) {
		const txOriginal = {blockNumber: "4507184", timeStamp: "1510054875", hash: "0x5575f27823fa46addfbe9dd40e09c0034aa6f9b653bf517d835521a4d0c83c0f", nonce: "6", blockHash: "0x059a2b832d629945f01f06af07c88c7306cb811c5a19c899f9ce5a6003428cc8", transactionIndex: "45", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x785668450000000000000000000000000000000000000000000000000000000000000006000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000006043727970746f206f6e2073746167657c4358583134323036367cd090d0bcd184d0b8d182d0b5d0b0d182d1802c20d09bd0b5d0b2d0b0d18f20d181d182d0bed180d0bed0bdd0b07c357c31387cd094d0b5d182d18fd0bc7c3130303030525542", contractAddress: "", cumulativeGasUsed: "1233252", gasUsed: "163116", confirmations: "3227751"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "6"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `Crypto on stage|CXX142066|Амфитеатр, Левая сторона|5|18|Детям|10000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "6", addressList[9], `Crypto on stage|CXX142066|Амфитеатр, Левая сторона|5|18|Детям|10000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510054875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "6"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX142066|Амфитеатр, Левая сторона|5|18|Детям|10000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"7\", addressList[9], `Crypto on stage|... )", async function( ) {
		const txOriginal = {blockNumber: "4507186", timeStamp: "1510054889", hash: "0x460fd54d56a3804c06e1e151fc97b934c5d2a678bc2c57ac6db1889bf44e4318", nonce: "7", blockHash: "0xc3e0fa239d35d2b6580ac2ea52218f0a56eece593461500d9bf0259e6cadb14b", transactionIndex: "3", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x785668450000000000000000000000000000000000000000000000000000000000000007000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000006143727970746f206f6e2073746167657c4358583134323332387cd090d0bcd184d0b8d182d0b5d0b0d182d1802c20d09fd180d0b0d0b2d0b0d18f20d181d182d0bed180d0bed0bdd0b07c387c327cd094d0b5d182d18fd0bc7c323030303052554200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "319919", gasUsed: "184006", confirmations: "3227749"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "7"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `Crypto on stage|CXX142328|Амфитеатр, Правая сторона|8|2|Детям|20000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "7", addressList[9], `Crypto on stage|CXX142328|Амфитеатр, Правая сторона|8|2|Детям|20000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510054889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "7"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX142328|Амфитеатр, Правая сторона|8|2|Детям|20000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"8\", addressList[9], `Crypto on stage|... )", async function( ) {
		const txOriginal = {blockNumber: "4507190", timeStamp: "1510054933", hash: "0x4b80996c52599c62619b4e332d231bce98102db0431004ce527061fdb0ca4cad", nonce: "8", blockHash: "0xe5104ca323cd48094ac1ee01de3f5c523cc4027e0dc66ddf5b50f6d10d4fc406", transactionIndex: "4", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x785668450000000000000000000000000000000000000000000000000000000000000008000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000006143727970746f206f6e2073746167657c4358583134323532357cd090d0bcd184d0b8d182d0b5d0b0d182d1802c20d09fd180d0b0d0b2d0b0d18f20d181d182d0bed180d0bed0bdd0b07c357c337cd094d0b5d182d18fd0bc7c323030303052554200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "365998", gasUsed: "184620", confirmations: "3227745"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "8"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `Crypto on stage|CXX142525|Амфитеатр, Правая сторона|5|3|Детям|20000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "8", addressList[9], `Crypto on stage|CXX142525|Амфитеатр, Правая сторона|5|3|Детям|20000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510054933 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "8"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX142525|Амфитеатр, Правая сторона|5|3|Детям|20000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"9\", addressList[9], `Crypto on stage|... )", async function( ) {
		const txOriginal = {blockNumber: "4507195", timeStamp: "1510054983", hash: "0x412281914bbbfb22c66fc83b7290d221f7f1b5692f2757cbc7c45d2ea3336e04", nonce: "9", blockHash: "0xec34c9f8597b00154529224e62517a2a90a3fd4749045c931bdd79149b932228", transactionIndex: "1", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x785668450000000000000000000000000000000000000000000000000000000000000009000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000005c43727970746f206f6e2073746167657c4358583134313835337cd090d0bcd184d0b8d182d0b5d0b0d182d1802c20d09bd0b5d0b2d0b0d18f20d181d182d0bed180d0bed0bdd0b07c367c31317cd094d0b5d182d18fd0bc7c3052554200000000", contractAddress: "", cumulativeGasUsed: "216128", gasUsed: "164670", confirmations: "3227740"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "9"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `Crypto on stage|CXX141853|Амфитеатр, Левая сторона|6|11|Детям|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "9", addressList[9], `Crypto on stage|CXX141853|Амфитеатр, Левая сторона|6|11|Детям|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510054983 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "9"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX141853|Амфитеатр, Левая сторона|6|11|Детям|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"10\", addressList[9], `test 1|KTY14281... )", async function( ) {
		const txOriginal = {blockNumber: "4507469", timeStamp: "1510058825", hash: "0x1ed0c35876eb23a7cfc9a765030be16a08999f9caddffd65ddef41e8ae4284e7", nonce: "10", blockHash: "0xb3754b019cb0cf2fdd31ff9b7966e8880cfa73c3840e02f0265c061c0451c4e6", transactionIndex: "6", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000317465737420317c4b54593134323831377cd09fd0b0d180d182d0b5d1807c317c317cd09cd183d0b7d0b5d0b87c30525542000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "456112", gasUsed: "141984", confirmations: "3227466"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "10"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `test 1|KTY142817|Партер|1|1|Музеи|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "10", addressList[9], `test 1|KTY142817|Партер|1|1|Музеи|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510058825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "10"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "test 1|KTY142817|Партер|1|1|Музеи|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"11\", addressList[9], `test 1|KTY14282... )", async function( ) {
		const txOriginal = {blockNumber: "4507471", timeStamp: "1510058881", hash: "0x480453461e7f0b507cc4acdccfa4826a09a197631d66f05c8163e6ab8ddbbae8", nonce: "11", blockHash: "0xc9ba7c0311f3b233b936ed6685d550e440edebc7cdd018b6b69d1f4baa807073", transactionIndex: "20", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000377465737420317c4b54593134323832387cd09fd0b0d180d182d0b5d1807c317c31327cd09cd183d0b7d0b5d0b87c313030303030525542000000000000000000", contractAddress: "", cumulativeGasUsed: "1473550", gasUsed: "143030", confirmations: "3227464"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "11"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `test 1|KTY142828|Партер|1|12|Музеи|100000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "11", addressList[9], `test 1|KTY142828|Партер|1|12|Музеи|100000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510058881 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "11"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "test 1|KTY142828|Партер|1|12|Музеи|100000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], addressList[8], \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "4507480", timeStamp: "1510059013", hash: "0xf1a7564818156cfe2a5bdd0d041e64bad47dd7671789e9d6c0c4cb9156bb1aee", nonce: "12", blockHash: "0x52c9c2a394800c125b0075cef15d3ddcc0e93b2259bb38717b45135af96c5d66", transactionIndex: "2", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc8000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e0000000000000000000000004e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "156927", gasUsed: "68022", confirmations: "3227455"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[9]}, {type: "address", name: "receiver", value: addressList[8]}, {type: "uint256", name: "seatID", value: "11"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[9], addressList[8], "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510059013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_receiver", type: "address", value: "0x4e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb"}, {name: "_seatID", type: "uint256", value: "11"}, {name: "_infoStringt", type: "string", value: "test 1|KTY142828|Партер|1|12|Музеи|100000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"12\", addressList[9], `test 1|KTY14296... )", async function( ) {
		const txOriginal = {blockNumber: "4507485", timeStamp: "1510059063", hash: "0x6bb6092f10ae7c99253d14e8cf842aea3d76617636641a4038ad74bf51917d32", nonce: "13", blockHash: "0xd6d58ba4c926590bf6ff867b1ee97bb15125031d37562f889bb406e4fb7a12c7", transactionIndex: "1", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000377465737420317c4b54593134323936357cd09fd0b0d180d182d0b5d1807c367c31357cd09cd183d0b7d0b5d0b87c313030303030525542000000000000000000", contractAddress: "", cumulativeGasUsed: "164030", gasUsed: "143030", confirmations: "3227450"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "12"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `test 1|KTY142965|Партер|6|15|Музеи|100000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "12", addressList[9], `test 1|KTY142965|Партер|6|15|Музеи|100000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510059063 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "12"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "test 1|KTY142965|Партер|6|15|Музеи|100000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: redeemTicket( \"9\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "4507496", timeStamp: "1510059197", hash: "0x34f6efb00b5aabe140ba08e295051c708dfba186bf557b1c93c427019831b908", nonce: "14", blockHash: "0xa75310473322318b78cf6950941798f6df90a1e55fe4b60e310498f686c924b7", transactionIndex: "17", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xba02021d0000000000000000000000000000000000000000000000000000000000000009000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e", contractAddress: "", cumulativeGasUsed: "1323688", gasUsed: "49111", confirmations: "3227439"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "9"}, {type: "address", name: "holder", value: addressList[9]}], name: "redeemTicket", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "redeemTicket(uint256,address)" ]( "9", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510059197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogRedeemTicket", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogRedeemTicket", events: [{name: "_seatID", type: "uint256", value: "9"}, {name: "_holder", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX141853|Амфитеатр, Левая сторона|6|11|Детям|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"13\", addressList[9], `test 1|KTY14281... )", async function( ) {
		const txOriginal = {blockNumber: "4507498", timeStamp: "1510059248", hash: "0x481d54196c3fd7324edadb13e2861c3466408ff228547cb446260bc0a4d9ddaa", nonce: "15", blockHash: "0x3ca538846eb00efa7ac6af5efac81c16d9529cd70326a721c79822b5b271eb4a", transactionIndex: "15", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000317465737420317c4b54593134323831387cd09fd0b0d180d182d0b5d1807c317c327cd09cd183d0b7d0b5d0b87c30525542000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "830052", gasUsed: "143212", confirmations: "3227437"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "13"}, {type: "address", name: "buyer", value: addressList[9]}, {type: "string", name: "infoString", value: `test 1|KTY142818|Партер|1|2|Музеи|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "13", addressList[9], `test 1|KTY142818|Партер|1|2|Музеи|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510059248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "13"}, {name: "_buyer", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "test 1|KTY142818|Партер|1|2|Музеи|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], addressList[10], \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4513741", timeStamp: "1510145107", hash: "0xa8970a2b4b0af2b0569d5bf9be7df1dc8360b8a6d2eaec66e8ae12a53e6eaf87", nonce: "16", blockHash: "0x65dcdad2c3fda54998ada8e47c83ada8d973cec91a193e1ef90864bfc839ee9b", transactionIndex: "10", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc800000000000000000000000052862f49349596e9754de2d9640feaa590342c3d000000000000000000000000025109be24cd6ddb4ab070a875fc4874a0855ba80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "607371", gasUsed: "82917", confirmations: "3221194"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[7]}, {type: "address", name: "receiver", value: addressList[10]}, {type: "uint256", name: "seatID", value: "1"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[7], addressList[10], "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510145107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_receiver", type: "address", value: "0x025109be24cd6ddb4ab070a875fc4874a0855ba8"}, {name: "_seatID", type: "uint256", value: "1"}, {name: "_infoStringt", type: "string", value: "тест большой зал 5|AMY188265||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: redeemTicket( \"2\", addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4513748", timeStamp: "1510145237", hash: "0x275c564119121e524cacada8d603761fc8020b29b856ecdd52457ad8d2f62763", nonce: "17", blockHash: "0x4e80d66a01106b421fdc95840d8f78f361214a9e28b4715215683c770baae7f5", transactionIndex: "9", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xba02021d000000000000000000000000000000000000000000000000000000000000000200000000000000000000000052862f49349596e9754de2d9640feaa590342c3d", contractAddress: "", cumulativeGasUsed: "281935", gasUsed: "49111", confirmations: "3221187"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "2"}, {type: "address", name: "holder", value: addressList[7]}], name: "redeemTicket", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "redeemTicket(uint256,address)" ]( "2", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510145237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogRedeemTicket", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogRedeemTicket", events: [{name: "_seatID", type: "uint256", value: "2"}, {name: "_holder", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188267||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], addressList[11], \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4514225", timeStamp: "1510151831", hash: "0x07cdfee26dbb481b59ca42ffc987ea4d9d48c2e6fbb6c283faa9dd80f281bb15", nonce: "18", blockHash: "0xb93d2406a4a2abdc110a65922a22860bbd9d3c4feebfb187c932ff1d52c5977a", transactionIndex: "6", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc8000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e00000000000000000000000016ea592d189b1448bec5d99d09649eaa372417fc000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "559752", gasUsed: "82408", confirmations: "3220710"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[9]}, {type: "address", name: "receiver", value: addressList[11]}, {type: "uint256", name: "seatID", value: "10"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[9], addressList[11], "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510151831 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_receiver", type: "address", value: "0x16ea592d189b1448bec5d99d09649eaa372417fc"}, {name: "_seatID", type: "uint256", value: "10"}, {name: "_infoStringt", type: "string", value: "test 1|KTY142817|Партер|1|1|Музеи|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: redeemTicket( \"6\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "4514227", timeStamp: "1510151854", hash: "0xa5e46f5b92bd625471c74e6450d0a4753210f75e290cb566f7a16c67ed5f47f7", nonce: "19", blockHash: "0x85ef395873e11241378f4e48f98750acebe9eedc0de32d1ad9ff53f43dac0c68", transactionIndex: "2", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xba02021d0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e", contractAddress: "", cumulativeGasUsed: "162777", gasUsed: "49111", confirmations: "3220708"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "6"}, {type: "address", name: "holder", value: addressList[9]}], name: "redeemTicket", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "redeemTicket(uint256,address)" ]( "6", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510151854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogRedeemTicket", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogRedeemTicket", events: [{name: "_seatID", type: "uint256", value: "6"}, {name: "_holder", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX142066|Амфитеатр, Левая сторона|5|18|Детям|10000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], addressList[9], \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4514233", timeStamp: "1510151898", hash: "0x8e464bc448bf43f04312206aa9116aa82ad521aa24bec766e994ed55524606a8", nonce: "20", blockHash: "0x1fece5beb9376beb9141dd6d1fd16ad12cea690cc4ae19e4ecc271037242d382", transactionIndex: "1", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc800000000000000000000000016ea592d189b1448bec5d99d09649eaa372417fc000000000000000000000000d68cd4339ad6792369b6c7f5df7646cdc6a5296e000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "107648", gasUsed: "55478", confirmations: "3220702"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[11]}, {type: "address", name: "receiver", value: addressList[9]}, {type: "uint256", name: "seatID", value: "10"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[11], addressList[9], "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510151898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0x16ea592d189b1448bec5d99d09649eaa372417fc"}, {name: "_receiver", type: "address", value: "0xd68cd4339ad6792369b6c7f5df7646cdc6a5296e"}, {name: "_seatID", type: "uint256", value: "10"}, {name: "_infoStringt", type: "string", value: "test 1|KTY142817|Партер|1|1|Музеи|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"14\", addressList[8], `тест большой за... )", async function( ) {
		const txOriginal = {blockNumber: "4518997", timeStamp: "1510218647", hash: "0x2f7c5772a2ca666bb9a981cbc719bbc7e33d78f0edf601664be3bf03bd66f8ba", nonce: "21", blockHash: "0xa372ba504d70f37c8a5b7f80300621b576f84e9ca30e4c6514ea9fae6c00b73e", transactionIndex: "7", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000004e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000043d182d0b5d181d18220d0b1d0bed0bbd18cd188d0bed0b920d0b7d0b0d0bb20357c414d593138383236347c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "815490", gasUsed: "161642", confirmations: "3215938"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "14"}, {type: "address", name: "buyer", value: addressList[8]}, {type: "string", name: "infoString", value: `тест большой зал 5|AMY188264||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "14", addressList[8], `тест большой зал 5|AMY188264||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510218647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "14"}, {name: "_buyer", type: "address", value: "0x4e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188264||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"15\", addressList[8], `тест большой за... )", async function( ) {
		const txOriginal = {blockNumber: "4518999", timeStamp: "1510218729", hash: "0x8adaaef966046bafb780254a41aa8c2af79e61574174e87c326238c612e58d24", nonce: "22", blockHash: "0xc033733ab1714b7fd580d74193ca2a71d3990f1b5b2c88ebfac8bc0b3debb997", transactionIndex: "19", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000004e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000043d182d0b5d181d18220d0b1d0bed0bbd18cd188d0bed0b920d0b7d0b0d0bb20357c414d593138383236337c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1078570", gasUsed: "162256", confirmations: "3215936"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "15"}, {type: "address", name: "buyer", value: addressList[8]}, {type: "string", name: "infoString", value: `тест большой зал 5|AMY188263||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "15", addressList[8], `тест большой зал 5|AMY188263||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510218729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "15"}, {name: "_buyer", type: "address", value: "0x4e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188263||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"16\", addressList[8], `тест большой за... )", async function( ) {
		const txOriginal = {blockNumber: "4519001", timeStamp: "1510218739", hash: "0xf50bbe76af4866ffa473d186da81124adcf1ff4b52be5ea054e948da28cef90b", nonce: "23", blockHash: "0x84b75701ea0b24f3b4dc1a83cbd45c7abe327583b4ba6ddebf6691133c83563e", transactionIndex: "2", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x7856684500000000000000000000000000000000000000000000000000000000000000100000000000000000000000004e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000043d182d0b5d181d18220d0b1d0bed0bbd18cd188d0bed0b920d0b7d0b0d0bb20357c4243433134333530327c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "443875", gasUsed: "162870", confirmations: "3215934"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "16"}, {type: "address", name: "buyer", value: addressList[8]}, {type: "string", name: "infoString", value: `тест большой зал 5|BCC143502||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "16", addressList[8], `тест большой зал 5|BCC143502||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510218739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "16"}, {name: "_buyer", type: "address", value: "0x4e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb"}, {name: "_infoString", type: "string", value: "тест большой зал 5|BCC143502||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"17\", addressList[11], `Crypto on stag... )", async function( ) {
		const txOriginal = {blockNumber: "4519003", timeStamp: "1510218787", hash: "0x2f6fdd81ee8fa25709192158da2095cef436453a437f962caaeacd6eaa2278a7", nonce: "24", blockHash: "0xfd9235ac244f1bda921a841961c42beae2186f30b8c39e24fe1ad7858b4d6e2e", transactionIndex: "0", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001100000000000000000000000016ea592d189b1448bec5d99d09649eaa372417fc0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000005d43727970746f206f6e2073746167657c4358583134343330347cd09fd0b0d180d182d0b5d1802c20d09fd180d0b0d0b2d0b0d18f20d181d182d0bed180d0bed0bdd0b07c32307c31337cd094d0b5d182d18fd0bc7c3330303030525542000000", contractAddress: "", cumulativeGasUsed: "177286", gasUsed: "177286", confirmations: "3215932"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "17"}, {type: "address", name: "buyer", value: addressList[11]}, {type: "string", name: "infoString", value: `Crypto on stage|CXX144304|Партер, Правая сторона|20|13|Детям|30000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "17", addressList[11], `Crypto on stage|CXX144304|Партер, Правая сторона|20|13|Детям|30000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510218787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "17"}, {name: "_buyer", type: "address", value: "0x16ea592d189b1448bec5d99d09649eaa372417fc"}, {name: "_infoString", type: "string", value: "Crypto on stage|CXX144304|Партер, Правая сторона|20|13|Детям|30000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"18\", addressList[7], `KRAFTWERK \"3-D... )", async function( ) {
		const txOriginal = {blockNumber: "4519852", timeStamp: "1510230439", hash: "0xfb3482350ef3a5b7200a13a03b6638bd712caa545c6565e6efd19aa86397d06d", nonce: "25", blockHash: "0xa7629641b518a75c0a245f14727569a3348d72da42c0dffe801a172dcf30ec8c", transactionIndex: "58", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001200000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000006d4b524146545745524b2022332d4420d09ad09ed09dd0a6d095d0a0d0a22032303138227c5050503138383633397cd09fd0b0d180d182d0b5d1802c20d0a1d0b5d180d0b5d0b4d0b8d0bdd0b07c34337c33317cd09ad0bed0bdd186d0b5d180d182d18b7c33303030303052554200000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2749466", gasUsed: "183642", confirmations: "3215083"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "18"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `KRAFTWERK "3-D КОНЦЕРТ 2018"|PPP188639|Партер, Середина|43|31|Концерты|300000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "18", addressList[7], `KRAFTWERK "3-D КОНЦЕРТ 2018"|PPP188639|Партер, Середина|43|31|Концерты|300000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510230439 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "18"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "KRAFTWERK \"3-D КОНЦЕРТ 2018\"|PPP188639|Партер, Середина|43|31|Концерты|300000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"19\", addressList[7], `KRAFTWERK \"3-D... )", async function( ) {
		const txOriginal = {blockNumber: "4519854", timeStamp: "1510230472", hash: "0x89c10c63f5cbd5eaf6b3f482a833e9e4da13747ed763371fe2fbc66f2d8dc477", nonce: "26", blockHash: "0x5694a7324663b93a104e9c854feca2c89c814d2ff31787e3ef0c22407f3c3525", transactionIndex: "1", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001300000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000006d4b524146545745524b2022332d4420d09ad09ed09dd0a6d095d0a0d0a22032303138227c5050503138383634307cd09fd0b0d180d182d0b5d1802c20d0a1d0b5d180d0b5d0b4d0b8d0bdd0b07c34337c33327cd09ad0bed0bdd186d0b5d180d182d18b7c33303030303052554200000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "237683", gasUsed: "185484", confirmations: "3215081"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "19"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `KRAFTWERK "3-D КОНЦЕРТ 2018"|PPP188640|Партер, Середина|43|32|Концерты|300000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "19", addressList[7], `KRAFTWERK "3-D КОНЦЕРТ 2018"|PPP188640|Партер, Середина|43|32|Концерты|300000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510230472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "19"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "KRAFTWERK \"3-D КОНЦЕРТ 2018\"|PPP188640|Партер, Середина|43|32|Концерты|300000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"20\", addressList[8], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526515", timeStamp: "1510323434", hash: "0x71c5602f5ab35227153af6e3a5d9288490c3fe2e256da43ab0a511f1c60bea45", nonce: "27", blockHash: "0xd0d4ee8202bedb8a90112957df32e7c5c3b7ceeb7f7f837fc459364736f8a3f0", transactionIndex: "173", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x7856684500000000000000000000000000000000000000000000000000000000000000140000000000000000000000004e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4550583134313631367c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6248980", gasUsed: "164276", confirmations: "3208420"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "20"}, {type: "address", name: "buyer", value: addressList[8]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|EPX141616||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "20", addressList[8], `Demo crypto.tickets powered by Ethereum v1.0|EPX141616||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510323434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "20"}, {name: "_buyer", type: "address", value: "0x4e7fb090b8cf9a09e72ac8d9281e504c5d8d0efb"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|EPX141616||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"21\", addressList[12], `Demo crypto.ti... )", async function( ) {
		const txOriginal = {blockNumber: "4526773", timeStamp: "1510326729", hash: "0x3cc41cc4baf48f47002a79ef8e2c8d69ec61a27befccff59fd3a5645510da1f4", nonce: "28", blockHash: "0x49e64c9122dd5fffd3f367e9cf1d09196fc5918c564dc45fb28bdbaeac7d8194", transactionIndex: "3", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x7856684500000000000000000000000000000000000000000000000000000000000000150000000000000000000000009421190982099698c06eefdcf718dba2c7e591ad0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313938347c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "412266", gasUsed: "176206", confirmations: "3208162"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "21"}, {type: "address", name: "buyer", value: addressList[12]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141984||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "21", addressList[12], `Demo crypto.tickets powered by Ethereum v1.0|KHP141984||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510326729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "21"}, {name: "_buyer", type: "address", value: "0x9421190982099698c06eefdcf718dba2c7e591ad"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141984||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"22\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526806", timeStamp: "1510327147", hash: "0xe37b7b5e3f59d6e41d906af72ad677ad965910279859a217e4bb46dba43e6ecb", nonce: "29", blockHash: "0x9c113f65f65e7c31599f947d4bb1fd95d1a51ac23161c236b8923880e9ffaddb", transactionIndex: "66", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001600000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313938357c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2805715", gasUsed: "163662", confirmations: "3208129"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "22"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141985||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "22", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141985||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510327147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "22"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141985||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], addressList[13], \"19\" )", async function( ) {
		const txOriginal = {blockNumber: "4526842", timeStamp: "1510327569", hash: "0xcc41ebb66f6998716d6994a8e2d40fd74bf7b9f65e1ed934de758d44c4f4e497", nonce: "30", blockHash: "0x44d2a4163426c615a03bf84531e276a0b28cbe2f932e37b00bbc38cc69030884", transactionIndex: "14", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc800000000000000000000000052862f49349596e9754de2d9640feaa590342c3d000000000000000000000000dfe3ab8abc253f1ce1ae54a3d0efb1dd270f692a0000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "497233", gasUsed: "83426", confirmations: "3208093"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[7]}, {type: "address", name: "receiver", value: addressList[13]}, {type: "uint256", name: "seatID", value: "19"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[7], addressList[13], "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510327569 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_receiver", type: "address", value: "0xdfe3ab8abc253f1ce1ae54a3d0efb1dd270f692a"}, {name: "_seatID", type: "uint256", value: "19"}, {name: "_infoStringt", type: "string", value: "KRAFTWERK \"3-D КОНЦЕРТ 2018\"|PPP188640|Партер, Середина|43|32|Концерты|300000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], addressList[7], \"19\" )", async function( ) {
		const txOriginal = {blockNumber: "4526853", timeStamp: "1510327707", hash: "0x98f6f3ffc40d94f880fe3c086c419cd37586fd3a72d0875d378b8c5e8fed4ba9", nonce: "31", blockHash: "0x22cbf00768aa02b15219d3c0c6a44a1280818b6de48e50ac0369621554b18e22", transactionIndex: "4", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc8000000000000000000000000dfe3ab8abc253f1ce1ae54a3d0efb1dd270f692a00000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "221102", gasUsed: "55268", confirmations: "3208082"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[13]}, {type: "address", name: "receiver", value: addressList[7]}, {type: "uint256", name: "seatID", value: "19"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[13], addressList[7], "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510327707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0xdfe3ab8abc253f1ce1ae54a3d0efb1dd270f692a"}, {name: "_receiver", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_seatID", type: "uint256", value: "19"}, {name: "_infoStringt", type: "string", value: "KRAFTWERK \"3-D КОНЦЕРТ 2018\"|PPP188640|Партер, Середина|43|32|Концерты|300000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"23\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526903", timeStamp: "1510328300", hash: "0x1230374311918cdc849beba38055348b556995fb8ef45193c17133a5e90b82e1", nonce: "32", blockHash: "0x823fdd57fdd5d9a8151beabea9248bf70d4b0154a11c609b1ad3ef81bad58914", transactionIndex: "1", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001700000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313938327c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "185935", gasUsed: "164276", confirmations: "3208032"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "23"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141982||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "23", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141982||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510328300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "23"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141982||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"24\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526905", timeStamp: "1510328321", hash: "0xebf024d8f7a3736e2944fd92b49b60fb88d5b85ed91edaced3b19fce8c94d581", nonce: "33", blockHash: "0x2197c97df40c1a02588e323bf96ec7c1ecf99592f746cd2459a09906763eedad", transactionIndex: "4", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001800000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313939307c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "316245", gasUsed: "164890", confirmations: "3208030"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "24"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141990||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "24", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141990||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510328321 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "24"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141990||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"25\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526907", timeStamp: "1510328330", hash: "0xef59ac5cb40a2969ae687904fc1a0fd8e70a57bfb383a090f00703f874b0b110", nonce: "34", blockHash: "0xa1282cd2a58ffa0aed4aeedf4eee06d58d06dc3229460a664633289ae8bc8625", transactionIndex: "29", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001900000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313938307c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1298953", gasUsed: "165504", confirmations: "3208028"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "25"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141980||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "25", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141980||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510328330 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "25"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141980||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"26\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526910", timeStamp: "1510328354", hash: "0x4fe34363f87c276b27cd2ae16a7bebbbd269361a2fcec363406361232c95c158", nonce: "35", blockHash: "0x0746a52f3c838965b44111687c1d07e404dfea288c270e55674d58dddd7e9bef", transactionIndex: "4", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001a00000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313938317c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "329002", gasUsed: "166118", confirmations: "3208025"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "26"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141981||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "26", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141981||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510328354 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "26"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141981||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"27\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526912", timeStamp: "1510328427", hash: "0xcd7759b7f77371b532d58499f4c8e9de9f8045f2d296442302153384ae1a9717", nonce: "36", blockHash: "0xca5391dd59c301dfd3347aecaae12394eff9b8c13b6cbbc26cd78084116b606b", transactionIndex: "13", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313937397c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "604508", gasUsed: "166732", confirmations: "3208023"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "27"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141979||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "27", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141979||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510328427 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "27"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141979||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"28\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526914", timeStamp: "1510328442", hash: "0x7bd651f642a3fc24e55d8a7ad8fa571a2ebeb578fd6194a5a06bfdaec766d0d7", nonce: "37", blockHash: "0xc933a32f8ab3e6402a96f8efe07ba3e2461e4eb83b1d172f9824b90a589092f6", transactionIndex: "3", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313937377c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "262872", gasUsed: "167346", confirmations: "3208021"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "28"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141977||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "28", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141977||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510328442 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "28"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141977||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"29\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526916", timeStamp: "1510328463", hash: "0xc54a67fa3c262c6f08a9941cdeb43bc1957e9f0ad65a410ec3a684bf1cbd983e", nonce: "38", blockHash: "0xc35598a1b96054e033ce96c009dc5ade35e0c3d68a005a1f833b31d74b211403", transactionIndex: "6", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001d00000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313938337c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "386056", gasUsed: "167960", confirmations: "3208019"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "29"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141983||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "29", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141983||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510328463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "29"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141983||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"30\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4526918", timeStamp: "1510328479", hash: "0xa6dd35a81a7363f2c6bac3fceaad96d02da3bd1cf1db4dcbef6d1e5dd424db8c", nonce: "39", blockHash: "0xb9a450ad058c799dedbd42e1de28c387e7d13881bb598635251beb00e7e3fc96", transactionIndex: "60", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004e44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c4b48503134313937387c7c7c7cd091d0b8d0b7d0bdd0b5d1817c31303030525542000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2554256", gasUsed: "168574", confirmations: "3208017"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "30"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|KHP141978||||Бизнес|1000RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "30", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|KHP141978||||Бизнес|1000RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510328479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "30"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141978||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], addressList[13], \"27\" )", async function( ) {
		const txOriginal = {blockNumber: "4526994", timeStamp: "1510329529", hash: "0x646df68f1d8734e10c90f333957ea0c54f8a48e021615c7304e96b681ee3f4bf", nonce: "40", blockHash: "0x3a173677107b9c7908af6837ca7230317d01da1301954cc061d7eb5d5fd1b112", transactionIndex: "165", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc800000000000000000000000052862f49349596e9754de2d9640feaa590342c3d000000000000000000000000dfe3ab8abc253f1ce1ae54a3d0efb1dd270f692a000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "6386564", gasUsed: "82917", confirmations: "3207941"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[7]}, {type: "address", name: "receiver", value: addressList[13]}, {type: "uint256", name: "seatID", value: "27"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[7], addressList[13], "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510329529 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_receiver", type: "address", value: "0xdfe3ab8abc253f1ce1ae54a3d0efb1dd270f692a"}, {name: "_seatID", type: "uint256", value: "27"}, {name: "_infoStringt", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141979||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], addressList[14], \"25\" )", async function( ) {
		const txOriginal = {blockNumber: "4527029", timeStamp: "1510330087", hash: "0x4b5ade093a7a0edf8368cf98265b14b02ae66d2c929f596af2761ee8a3693f67", nonce: "41", blockHash: "0x2d0e768acbf51cf72e29c94838da8a34544e3234381e8767e891ea4c103ea2e1", transactionIndex: "3", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xbeabacc800000000000000000000000052862f49349596e9754de2d9640feaa590342c3d000000000000000000000000da535208eac6101bdf381b4bffe70e38c403e6020000000000000000000000000000000000000000000000000000000000000019", contractAddress: "", cumulativeGasUsed: "299178", gasUsed: "82917", confirmations: "3207906"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "holder", value: addressList[7]}, {type: "address", name: "receiver", value: addressList[14]}, {type: "uint256", name: "seatID", value: "25"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,address,uint256)" ]( addressList[7], addressList[14], "25", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510330087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_receiver", type: "address"}, {indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_infoStringt", type: "string"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_holder", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_receiver", type: "address", value: "0xda535208eac6101bdf381b4bffe70e38c403e602"}, {name: "_seatID", type: "uint256", value: "25"}, {name: "_infoStringt", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|KHP141980||||Бизнес|1000RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: redeemTicket( \"4\", addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4546033", timeStamp: "1510592586", hash: "0xdf0d3f79a431dff413a4ceb8bb9a2fd7ca33ea49594eea398231baaef2cd47a3", nonce: "42", blockHash: "0x28687169ab2fd1be38beca9919e1ca80e282b734fd7adb005201e2ef6458356f", transactionIndex: "3", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0xba02021d000000000000000000000000000000000000000000000000000000000000000400000000000000000000000052862f49349596e9754de2d9640feaa590342c3d", contractAddress: "", cumulativeGasUsed: "137029", gasUsed: "49111", confirmations: "3188902"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "4"}, {type: "address", name: "holder", value: addressList[7]}], name: "redeemTicket", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "redeemTicket(uint256,address)" ]( "4", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510592586 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_holder", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogRedeemTicket", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogRedeemTicket", events: [{name: "_seatID", type: "uint256", value: "4"}, {name: "_holder", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "тест большой зал 5|AMY188266||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"31\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4546054", timeStamp: "1510592828", hash: "0xc28282dc639ca0c4f981e48bd1f9245688a7e6dafa3a164404ab56f20816fde0", nonce: "43", blockHash: "0x4fc83149e72e2680b891849acfa9a650bb5f47357140dcdbee13099bab545d72", transactionIndex: "9", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000001f00000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004f44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c414d593138383236317c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "471889", gasUsed: "165576", confirmations: "3188881"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "31"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|AMY188261||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "31", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|AMY188261||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510592828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "31"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|AMY188261||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"32\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4546056", timeStamp: "1510592876", hash: "0x63b496b215598137d77a71103db52f803575ce1a174ed619da1c9b589dcb613f", nonce: "44", blockHash: "0xb2774626ef288ab9c3cf9a0d2bd72e1ba780b1974a80da87dedbeb626a9dc20c", transactionIndex: "8", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000002000000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004f44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c414d593138383236327c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "549999", gasUsed: "166804", confirmations: "3188879"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "32"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|AMY188262||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "32", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|AMY188262||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510592876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "32"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|AMY188262||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"33\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4546160", timeStamp: "1510594385", hash: "0xbd3373be358d480cb6d5bef57c7075581f0e136d74a2344e9419fe6f680ac446", nonce: "45", blockHash: "0xa122717b9b8e263806961d34a8bddf3ae9eccc3fe741cdf1a827952c10578ffc", transactionIndex: "6", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000002100000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004f44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c414d593138383235347c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "426122", gasUsed: "169260", confirmations: "3188775"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "33"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|AMY188254||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "33", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|AMY188254||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510594385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "33"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|AMY188254||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"34\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4546163", timeStamp: "1510594409", hash: "0x45b768431db5e2f4458daa6ebf184b33c1b7f765978d2d005d5089c38a9bb3ca", nonce: "46", blockHash: "0xa65206b6d9f6068d29815ec7c8c38f3581c399b497ff178ec1d5bdfc8ce579cc", transactionIndex: "9", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000002200000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004f44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c414d593138383235367c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "822761", gasUsed: "169874", confirmations: "3188772"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "34"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|AMY188256||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "34", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|AMY188256||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510594409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "34"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|AMY188256||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"35\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4546165", timeStamp: "1510594439", hash: "0x263ea1639f2602cd07c99917eefa4bcb980d50de18f2863bc208282c54f20804", nonce: "47", blockHash: "0x0a0ae904d96ca8198fbdf585ae862eec06bedf655fe323a83648f69c85b336e1", transactionIndex: "51", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "1", input: "0x78566845000000000000000000000000000000000000000000000000000000000000002300000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004f44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c414d593138383235397c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2512923", gasUsed: "170488", confirmations: "3188770"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "35"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|AMY188259||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "35", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|AMY188259||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510594439 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_seatID", type: "uint256"}, {indexed: false, name: "_buyer", type: "address"}, {indexed: false, name: "_infoString", type: "string"}], name: "LogAllocateTicket", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogAllocateTicket", events: [{name: "_seatID", type: "uint256", value: "35"}, {name: "_buyer", type: "address", value: "0x52862f49349596e9754de2d9640feaa590342c3d"}, {name: "_infoString", type: "string", value: "Demo crypto.tickets powered by Ethereum v1.0|AMY188259||||Выставки|0RUB"}], address: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTicket( \"36\", addressList[7], `Demo crypto.tic... )", async function( ) {
		const txOriginal = {blockNumber: "4546169", timeStamp: "1510594490", hash: "0x93354ff69e03360d700beac0222ba0a232e9b5b8a9632515708b28d988bfced9", nonce: "48", blockHash: "0x93e25b11ee9e6953a848ab21339c8a0988c3fc0bdf264dec2f048509e3d5f471", transactionIndex: "124", from: "0x4c3343bbfa7dac896cd0e3795f46187134ab28bb", to: "0x2b0067e8a59a66a4fbf370b70d21133400b04ac2", value: "0", gas: "300000", gasPrice: "25009599175", isError: "0", txreceipt_status: "0", input: "0x78566845000000000000000000000000000000000000000000000000000000000000002400000000000000000000000052862f49349596e9754de2d9640feaa590342c3d0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004f44656d6f2063727970746f2e7469636b65747320706f776572656420627920457468657265756d2076312e307c414d593138383235377c7c7c7cd092d18bd181d182d0b0d0b2d0bad0b87c305255420000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5691492", gasUsed: "30825", confirmations: "3188766"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "seatID", value: "36"}, {type: "address", name: "buyer", value: addressList[7]}, {type: "string", name: "infoString", value: `Demo crypto.tickets powered by Ethereum v1.0|AMY188257||||Выставки|0RUB`}], name: "allocateTicket", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTicket(uint256,address,string)" ]( "36", addressList[7], `Demo crypto.tickets powered by Ethereum v1.0|AMY188257||||Выставки|0RUB`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510594490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "11839823468835975" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
