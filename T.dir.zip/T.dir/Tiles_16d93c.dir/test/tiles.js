const Tiles = artifacts.require( "./Tiles.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Tiles" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x103992432927f7Ed1a5b3dc0e34186F80b16d93c", "0xB0623C91c65621df716aB8aFE5f66656B21A9108", "0xe438815d1709f7C304C827b96210BAf9dEf09ada", "0xD88e34c9894a69b7302e2B09ac9b9c30Aa2751fC", "0x06c2aB4261F596c3E7e24dDB11F80e7b483748f5", "0x8eA22b3b130556a738142ee848ff2155ed4Ec64b", "0x9FBb3cDfa041fD10D784acb6f66C614D57DC21E1", "0xec8c1050B45789f9ee4D09dCC7D64aAF9e233338", "0x23feB3a8AF901405752A3c50B9358AFAF9cBd095", "0x0Caa889163d479986a57f2cE08F64CCFA2cA533F", "0x0537aC32B0847Eb155D6C3d25f57c7Fb37118d27", "0x00B6D99605C4c33e0e6411af6Be8394015048Ee5", "0x9ddbA02a56864a63048ca4F6395eBf6D1cb3afd2", "0x844E2fD3B16Dc5Edb211CC758b2F88236ce12bA7", "0x924ABBe5dC5D90056B5738C8667B8477272A6db6", "0xa5c3A513645A9a00cB561fED40438E9DFE0D6a69", "0x3eF36A1C18ACb29068D70c595b685DAaa592A5a3", "0x85F5b1AE68Fa58f0BC320AeC3711712e2C012065", "0x0386C37Be02ca51e5aedAE74FeC07DDA6d53f93E", "0x6F606beDa9Cb3Ab704C1c9902578F95BC0B02b1b", "0xdf9c6c6dB6922F78Ab990d0836503587815E5Ebc", "0xDdA8F5A7CD4578c23e4B86BA5A44c62605743467", "0xf2b8B1bA1E2Ab2e85f5108C620663C0F5c0B8285", "0xdD41a4108D31830BD4e8A9B9e453585227A5f295"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "gameStopped", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numTilesClaimed", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentGameBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "NUM_TILES", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "DEFAULT_GAME_COST", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "tiles", outputs: [{name: "gameClaimed", type: "uint256"}, {name: "claimedBy", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "willChangeCost", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentGameNumber", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentGameCost", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "gameEarnings", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "gameToWinner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "nextGameCost", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pendingWithdrawals", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GameWon", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "claimedBy", type: "address"}, {indexed: true, name: "amountClaimed", type: "uint256"}], name: "WinningsClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "claimedBy", type: "address"}, {indexed: true, name: "amountToClaim", type: "uint256"}], name: "FailedToClaim", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "xCoord", type: "uint256"}, {indexed: false, name: "yCoord", type: "uint256"}], name: "PrintWinningInfo", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["GameWon(uint256,address)", "TileClaimed(uint256,uint256,uint256,address)", "WinningsClaimed(address,uint256)", "FailedToClaim(address,uint256)", "PrintWinningInfo(bytes32,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4dc08ce212d967a2959e5901a545b00fd4f86c108a0de62a8d906b7b0793c6d6", "0xa2a6aa11b3e307a3a2d16bed2bb47047a2e5a2301bf7d76bbeab835e9ec1b1cd", "0x1a31e733a172afcf46074b3106c17f0c298e226442682a03c1e99ce256139ec2", "0x7b2c89054c35e58ab5007ab56302305b6cde18f1968b6cd028f77ef6beec7fea", "0x37790454cc96774de45d3b27e3aea1849e97730e54e83a5a7177de0b2840083d"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4511043 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4516624 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Tiles", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "gameStopped", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameStopped()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numTilesClaimed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numTilesClaimed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentGameBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentGameBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "NUM_TILES", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "NUM_TILES()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DEFAULT_GAME_COST", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DEFAULT_GAME_COST()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "tiles", outputs: [{name: "gameClaimed", type: "uint256"}, {name: "claimedBy", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tiles(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "willChangeCost", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "willChangeCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentGameNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentGameNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentGameCost", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentGameCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gameEarnings", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameEarnings()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "gameToWinner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameToWinner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextGameCost", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextGameCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pendingWithdrawals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pendingWithdrawals(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Tiles", function( accounts ) {

	it( "TEST: Tiles(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4511043", timeStamp: "1510107953", hash: "0x04b59c55dcf1fbd066aeac58cb36e414dc237e0f66c9b8e1535c56dd61213980", nonce: "21", blockHash: "0x250137d7c0ff24d3c9561ad0babb9cbfc17b2e6ce84dd66a514655ebecf3e4b9", transactionIndex: "38", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: 0, value: "0", gas: "1460628", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xedd99026", contractAddress: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", cumulativeGasUsed: "3006030", gasUsed: "1460628", confirmations: "3226056"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Tiles", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Tiles.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510107953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Tiles.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512475", timeStamp: "1510127593", hash: "0x3c99781651e070699054591c281fb43c1c684606ec4672a1174192da58702e71", nonce: "1", blockHash: "0xdacf9e0f520b81fbacf287ae68f6247abaedd65127db449588cbf39cc522c0ea", transactionIndex: "35", from: "0xe438815d1709f7c304c827b96210baf9def09ada", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "160809", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1366936", gasUsed: "107206", confirmations: "3224624"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510127593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0xe438815d1709f7c304c827b96210baf9def09ada"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5292463712500000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512643", timeStamp: "1510130100", hash: "0xb5a73c2e498c832e87be503aefc321510338ba8c2c03e267a5b0ef2df87cff83", nonce: "23", blockHash: "0xfba7a34cad561d64908d8fbb2121096fc05b7891cb1dd2aea00fc21408ab31ae", transactionIndex: "77", from: "0xb0623c91c65621df716ab8afe5f66656b21a9108", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "4787500000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3314461", gasUsed: "77334", confirmations: "3224456"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510130100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0xb0623c91c65621df716ab8afe5f66656b21a9108"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "100715374862476978" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"11\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512653", timeStamp: "1510130193", hash: "0x25d2dc29a6950a65ca4415147165c08f055952579d2d452c16a02cc2998fbb24", nonce: "1", blockHash: "0x8a5dd7c201558ab4409447dc08da0d4ae88a4ca6a0bb0a9cde789cf22e50fc12", transactionIndex: "41", from: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "4787500000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1677553", gasUsed: "77334", confirmations: "3224446"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "11"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "11", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510130193 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "11"}, {name: "claimedBy", type: "address", value: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2854361344719998" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"11\", \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512662", timeStamp: "1510130405", hash: "0xb5098d1af9229ebb0ddb6ab2522c52e3771df2e4e64df308ef8ac98d63e601d6", nonce: "2", blockHash: "0xaf7befb8f0dddb6fecd84688a5cd9a9f19d44d5fbb46d4c87cd6cbb3f99a51e1", transactionIndex: "113", from: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "4787500000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4248728", gasUsed: "77334", confirmations: "3224437"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "11"}, {type: "uint256", name: "yCoord", value: "1"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "11", "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510130405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "11"}, {name: "yCoord", type: "uint256", value: "1"}, {name: "claimedBy", type: "address", value: "0xd88e34c9894a69b7302e2b09ac9b9c30aa2751fc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2854361344719998" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"12\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512839", timeStamp: "1510132976", hash: "0x4c467c02f726d80c13a81dd6f1c26ef3d957ff7dc526b2b0d9a9986c588024ce", nonce: "2", blockHash: "0x76f948c12f6e0b43e2974ea027e60a958b602ddffcafc36afc53ae75389ee727", transactionIndex: "123", from: "0xe438815d1709f7c304c827b96210baf9def09ada", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "7181250000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4188505", gasUsed: "77334", confirmations: "3224260"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "12"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "12", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510132976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "12"}, {name: "claimedBy", type: "address", value: "0xe438815d1709f7c304c827b96210baf9def09ada"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "5292463712500000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"12\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512861", timeStamp: "1510133283", hash: "0x56647f7bf1235c776f1e8eca1597140a94d958f8280e2f36e472838e6ee679da", nonce: "0", blockHash: "0xd1b07f7f1a53a3f9bc1cebe7971caa0a6eec0c734190e4554953074b5c8a3ce0", transactionIndex: "74", from: "0x06c2ab4261f596c3e7e24ddb11f80e7b483748f5", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "4787500000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4237379", gasUsed: "77270", confirmations: "3224238"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "12"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "12", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510133283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "12"}, {name: "claimedBy", type: "address", value: "0x06c2ab4261f596c3e7e24ddb11f80e7b483748f5"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "340139750000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"13\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512861", timeStamp: "1510133283", hash: "0x06c7e7f2ef639230e19a880a6d420d373f9bc4772c2b4f5d16513a05ed0298d1", nonce: "1", blockHash: "0xd1b07f7f1a53a3f9bc1cebe7971caa0a6eec0c734190e4554953074b5c8a3ce0", transactionIndex: "75", from: "0x06c2ab4261f596c3e7e24ddb11f80e7b483748f5", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "4787500000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4314649", gasUsed: "77270", confirmations: "3224238"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "13"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "13", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510133283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "13"}, {name: "claimedBy", type: "address", value: "0x06c2ab4261f596c3e7e24ddb11f80e7b483748f5"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "340139750000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512862", timeStamp: "1510133305", hash: "0x7fbaa219c85b202cdf47480dc65897e8471e6e7aad0c9587afdb36493036a01c", nonce: "0", blockHash: "0x167dc6e5e3b663841b7d5a32097258bb972e30c6755af7fcbcdac4beeb0ae778", transactionIndex: "43", from: "0x8ea22b3b130556a738142ee848ff2155ed4ec64b", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "7181250000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1069928", gasUsed: "77334", confirmations: "3224237"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510133305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x8ea22b3b130556a738142ee848ff2155ed4ec64b"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "574408687500000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4512884", timeStamp: "1510133634", hash: "0xe2625e8112316a5e51c51776398fa884ffc44a451d002a8307a0185ebe8fe9a6", nonce: "1", blockHash: "0x556a7e90e65a11d0614f2202d3b487f0fe9354fbe91c4193e5b86cc6e33a0c30", transactionIndex: "38", from: "0x8ea22b3b130556a738142ee848ff2155ed4ec64b", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "4787500000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1721118", gasUsed: "77334", confirmations: "3224215"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510133634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x8ea22b3b130556a738142ee848ff2155ed4ec64b"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "574408687500000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"13\", \"9\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514530", timeStamp: "1510155808", hash: "0x8979f4b927c9b65af73fcd96311c46bffb01a26024cf281e27369972811edc6d", nonce: "0", blockHash: "0x52fe63f40c65302291853d4e1a93c543636b47f61ab45cc607d8300e63c35f57", transactionIndex: "54", from: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3672204", gasUsed: "77334", confirmations: "3222569"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "13"}, {type: "uint256", name: "yCoord", value: "9"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "13", "9", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510155808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "13"}, {name: "yCoord", type: "uint256", value: "9"}, {name: "claimedBy", type: "address", value: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1976425738888888" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"6\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514535", timeStamp: "1510155905", hash: "0x16dd6b72551d9185e931dae921d30f4afba9cbdd1626d0464a0fa060a05490b7", nonce: "1", blockHash: "0x8bc78fecd68bd3c74c76a21310f3cfaf2a70ba1c20d1b539da114d850a0ba586", transactionIndex: "74", from: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2205622", gasUsed: "77334", confirmations: "3222564"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "6"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "6", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510155905 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "6"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0x9fbb3cdfa041fd10d784acb6f66c614d57dc21e1"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1976425738888888" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"10\", \"14\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514789", timeStamp: "1510159239", hash: "0x03aac0833ed318ee7b8b7b288a1262ba59759f98d27feabb2e900d63ba0f8092", nonce: "0", blockHash: "0x8f34249801c79127a941f007e50195e4cd97199da90674ddaa3f4ba3a787cd81", transactionIndex: "10", from: "0xec8c1050b45789f9ee4d09dcc7d64aaf9e233338", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "415419", gasUsed: "77334", confirmations: "3222310"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "10"}, {type: "uint256", name: "yCoord", value: "14"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "10", "14", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510159239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "10"}, {name: "yCoord", type: "uint256", value: "14"}, {name: "claimedBy", type: "address", value: "0xec8c1050b45789f9ee4d09dcc7d64aaf9e233338"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "96503711864761264" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"9\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514825", timeStamp: "1510159893", hash: "0xcf794aea9210f51422fa4e374d9621a1e84f6a5831586678b16ab6ed6723308c", nonce: "0", blockHash: "0xadd3e6627652ef722253e6f060894c1532fa76ccf2dddc927c0010b4c4de3104", transactionIndex: "67", from: "0x23feb3a8af901405752a3c50b9358afaf9cbd095", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4382226", gasUsed: "77334", confirmations: "3222274"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "9"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "9", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510159893 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "9"}, {name: "claimedBy", type: "address", value: "0x23feb3a8af901405752a3c50b9358afaf9cbd095"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1515187200000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"9\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514827", timeStamp: "1510159930", hash: "0xced7b005828667bf308c559b859f51e314685a113a2204e338992e2c1848daa2", nonce: "0", blockHash: "0x9ba6cfcf7c35530bda7ec1086ed1e1e12c7818bb18dba75539eac761bcd3f2c6", transactionIndex: "42", from: "0x0caa889163d479986a57f2ce08f64ccfa2ca533f", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1606027", gasUsed: "77334", confirmations: "3222272"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "9"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "9", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510159930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "9"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0x0caa889163d479986a57f2ce08f64ccfa2ca533f"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1003972000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"5\", \"14\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514878", timeStamp: "1510160574", hash: "0xc25c1f40716d38f73dd204d58fe691cf28186256d83e4c575a4fd859bd674d68", nonce: "0", blockHash: "0x7efcfa49c9cadb225ef1e4b1a7914fb8fdb27f3bdd7ddeb930f39e86a9d04b0e", transactionIndex: "28", from: "0x0537ac32b0847eb155d6c3d25f57c7fb37118d27", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "795733", gasUsed: "77334", confirmations: "3222221"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "5"}, {type: "uint256", name: "yCoord", value: "14"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "5", "14", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510160574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "5"}, {name: "yCoord", type: "uint256", value: "14"}, {name: "claimedBy", type: "address", value: "0x0537ac32b0847eb155d6c3d25f57c7fb37118d27"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "306999200000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514927", timeStamp: "1510161208", hash: "0x4304f4a702618bfc873bf653ddb11147f736a7ecd4a12b97f9d9cec6e2ce1a07", nonce: "621", blockHash: "0xf478f20263a8c7ff4006522355fae2318e44efd13b2e8fce5133c4dcff8b73ac", transactionIndex: "35", from: "0x00b6d99605c4c33e0e6411af6be8394015048ee5", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1116647", gasUsed: "77270", confirmations: "3222172"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510161208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0x00b6d99605c4c33e0e6411af6be8394015048ee5"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "49764523280489928" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514952", timeStamp: "1510161627", hash: "0xe6b5817899b1d2de068f89a3f8cab035ccb9b5d644e9a04ce1f364ad3628273c", nonce: "0", blockHash: "0xf55548c6add967b7557dde50b111978066512622f50d6a14192f7a3064e335ce", transactionIndex: "86", from: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2103132", gasUsed: "77270", confirmations: "3222147"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "1"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510161627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "1"}, {name: "claimedBy", type: "address", value: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "6332589390450000002" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514956", timeStamp: "1510161693", hash: "0x7c666a4a989abe44414a75bcb52a63e8d7cd74742a72bed012012cf1ed3c4187", nonce: "1", blockHash: "0x82db0cf8a49e410d1d7128895ac4f75a9b8130fb0722e073080aeec30416d3a1", transactionIndex: "54", from: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2282518", gasUsed: "77334", confirmations: "3222143"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510161693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "6332589390450000002" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514956", timeStamp: "1510161693", hash: "0x9735df9c0e6d0949654b2122db8580a9e1dd92cbd0ab2f6d73386dbdd021d7e0", nonce: "2", blockHash: "0x82db0cf8a49e410d1d7128895ac4f75a9b8130fb0722e073080aeec30416d3a1", transactionIndex: "110", from: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5320866", gasUsed: "77334", confirmations: "3222143"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510161693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "6332589390450000002" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514957", timeStamp: "1510161705", hash: "0x5947433770e682edc6ddd5a7d8a7ac669c7fb556b1c00c3ed0f1509018094fc1", nonce: "3", blockHash: "0x33b7cca7220bff8a008c1857a4b25ce4117e74fe4aaeb9a590bacc8920394c23", transactionIndex: "36", from: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1768083", gasUsed: "77334", confirmations: "3222142"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510161705 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "6332589390450000002" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"4\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514957", timeStamp: "1510161705", hash: "0xa7db604533575ca7d3b424b0dab384298fcb47fa1e260795ec2b530d084d7cbe", nonce: "4", blockHash: "0x33b7cca7220bff8a008c1857a4b25ce4117e74fe4aaeb9a590bacc8920394c23", transactionIndex: "59", from: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3229843", gasUsed: "77334", confirmations: "3222142"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "4"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "4", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510161705 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "4"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x9ddba02a56864a63048ca4f6395ebf6d1cb3afd2"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "6332589390450000002" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"10\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514973", timeStamp: "1510161964", hash: "0x39558bc17ca3a39e21f0703a71ac39c63a2fd4c3c113ab72de428791cda238fb", nonce: "12", blockHash: "0x7124747ba758a7e0441712dff819575210417b40f63a823772b2a81a615fd155", transactionIndex: "27", from: "0x844e2fd3b16dc5edb211cc758b2f88236ce12ba7", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "852612", gasUsed: "77270", confirmations: "3222126"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "10"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "10", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510161964 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "10"}, {name: "claimedBy", type: "address", value: "0x844e2fd3b16dc5edb211cc758b2f88236ce12ba7"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "999664983319602328" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"14\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514980", timeStamp: "1510162006", hash: "0x861fd0ea32c8330ce2f10c0787c56583c4520f4684b41712ff2b4fbe1dfbaed6", nonce: "0", blockHash: "0x093b0636c980b836e8343e61d534106d9bec36bf3fcea3eb0c70922509d0a7d8", transactionIndex: "11", from: "0x924abbe5dc5d90056b5738c8667b8477272a6db6", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "594283", gasUsed: "77334", confirmations: "3222119"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "14"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "14", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510162006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "14"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0x924abbe5dc5d90056b5738c8667b8477272a6db6"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "202561004200000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"13\", \"4\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514984", timeStamp: "1510162058", hash: "0x1ec5a5a907040e74a32a11fef233b7e8bc48a296baa8ff3f7bbad6b51e285903", nonce: "1", blockHash: "0x38b6ff7c9b002f1119a49fdc6b4c5a6627b5800d5dab283be25534d148e6c948", transactionIndex: "43", from: "0x924abbe5dc5d90056b5738c8667b8477272a6db6", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1824681", gasUsed: "77334", confirmations: "3222115"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "13"}, {type: "uint256", name: "yCoord", value: "4"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "13", "4", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510162058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "13"}, {name: "yCoord", type: "uint256", value: "4"}, {name: "claimedBy", type: "address", value: "0x924abbe5dc5d90056b5738c8667b8477272a6db6"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "202561004200000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"12\", \"5\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4514984", timeStamp: "1510162058", hash: "0x956279cfd2ab14d966634b40e974d7c8296e2b7927c4a6fa8522d3da0fa5dd32", nonce: "2", blockHash: "0x38b6ff7c9b002f1119a49fdc6b4c5a6627b5800d5dab283be25534d148e6c948", transactionIndex: "105", from: "0x924abbe5dc5d90056b5738c8667b8477272a6db6", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5131995", gasUsed: "77334", confirmations: "3222115"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "12"}, {type: "uint256", name: "yCoord", value: "5"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "12", "5", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510162058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "12"}, {name: "yCoord", type: "uint256", value: "5"}, {name: "claimedBy", type: "address", value: "0x924abbe5dc5d90056b5738c8667b8477272a6db6"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "202561004200000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"15\", \"11\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515107", timeStamp: "1510163657", hash: "0xed7c530e606164d87bf580b66f0755ffc2d08f93c23e8f68993c68261f76849d", nonce: "0", blockHash: "0x83733863116dbdb7bb17a2f348dbc96106157d3fcddefbdd6b1099a8127bb7e9", transactionIndex: "32", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1300081", gasUsed: "77334", confirmations: "3221992"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "15"}, {type: "uint256", name: "yCoord", value: "11"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "15", "11", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510163657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "15"}, {name: "yCoord", type: "uint256", value: "11"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"14\", \"11\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515109", timeStamp: "1510163682", hash: "0x81175b07de321641263fc91b76102adf5ff330f6345423ee8146d511e2f439ad", nonce: "1", blockHash: "0xcf3c13895459b0e90286a3cbc6605132da163a5bd05c903c55798e68bba25064", transactionIndex: "116", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3915296", gasUsed: "77334", confirmations: "3221990"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "14"}, {type: "uint256", name: "yCoord", value: "11"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "14", "11", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510163682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "14"}, {name: "yCoord", type: "uint256", value: "11"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"14\", \"12\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515110", timeStamp: "1510163693", hash: "0xbca01a22a3c4e1535da6a7f3135392bd907e2a990c2499d36262348c68b9ff87", nonce: "2", blockHash: "0x12d1ad066a1482fe286fb11d4bc69db2fac82bbb8328c6bb80ef6c719279eb42", transactionIndex: "75", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2329803", gasUsed: "77334", confirmations: "3221989"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "14"}, {type: "uint256", name: "yCoord", value: "12"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "14", "12", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510163693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "14"}, {name: "yCoord", type: "uint256", value: "12"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"14\", \"13\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515111", timeStamp: "1510163718", hash: "0xac8cdff97bfded5b95d1ab23128c72cd62962dc58ec504843b0401c53b1bdbf1", nonce: "3", blockHash: "0xdcf82b4c6d271e0994108890d36e614479be39d44409023dda6bd34cc4e7ec0d", transactionIndex: "159", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4183934", gasUsed: "77334", confirmations: "3221988"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "14"}, {type: "uint256", name: "yCoord", value: "13"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "14", "13", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510163718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "14"}, {name: "yCoord", type: "uint256", value: "13"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"15\", \"13\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515111", timeStamp: "1510163718", hash: "0x8b58ad6ef81f3301c459e56fdf7895121eaecfd40b998058d80e1a3ac683f72b", nonce: "4", blockHash: "0xdcf82b4c6d271e0994108890d36e614479be39d44409023dda6bd34cc4e7ec0d", transactionIndex: "160", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4261268", gasUsed: "77334", confirmations: "3221988"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "15"}, {type: "uint256", name: "yCoord", value: "13"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "15", "13", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510163718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "15"}, {name: "yCoord", type: "uint256", value: "13"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"13\", \"12\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515113", timeStamp: "1510163750", hash: "0x8da023b91b1b9295bcababeb56622097b65ff5474813b016a9075d59c3863cb3", nonce: "5", blockHash: "0x40dfe401f39088bc65c7e6dd8b102fafaf28bc9d7c7c7d98b52e3a6897ad5950", transactionIndex: "16", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3320898", gasUsed: "77334", confirmations: "3221986"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "13"}, {type: "uint256", name: "yCoord", value: "12"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "13", "12", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510163750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "13"}, {name: "yCoord", type: "uint256", value: "12"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"12\", \"12\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515113", timeStamp: "1510163750", hash: "0xfebf8739e5d7c6c2da7e49e479ddfb00d348840737d7b3793ac460557180a38f", nonce: "6", blockHash: "0x40dfe401f39088bc65c7e6dd8b102fafaf28bc9d7c7c7d98b52e3a6897ad5950", transactionIndex: "48", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4749528", gasUsed: "77334", confirmations: "3221986"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "12"}, {type: "uint256", name: "yCoord", value: "12"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "12", "12", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510163750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "12"}, {name: "yCoord", type: "uint256", value: "12"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"11\", \"12\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515113", timeStamp: "1510163750", hash: "0x08dbd273f2725ecdac081ac3c5a40aee1a2e8d7cf0517c583956efc4f6365b5c", nonce: "7", blockHash: "0x40dfe401f39088bc65c7e6dd8b102fafaf28bc9d7c7c7d98b52e3a6897ad5950", transactionIndex: "51", from: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4899646", gasUsed: "77334", confirmations: "3221986"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "11"}, {type: "uint256", name: "yCoord", value: "12"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "11", "12", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510163750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "11"}, {name: "yCoord", type: "uint256", value: "12"}, {name: "claimedBy", type: "address", value: "0xa5c3a513645a9a00cb561fed40438e9dfe0d6a69"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "143751594886360999" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515232", timeStamp: "1510165584", hash: "0x5228f40c141f47cce892a3db9b5cf3761330986ef063d151b2be57aaf393e349", nonce: "358", blockHash: "0xf9cbec529a37080642afa76806a31b4e9d1f73dfa168fa8a97cb6e41a04daf15", transactionIndex: "69", from: "0x3ef36a1c18acb29068d70c595b685daaa592a5a3", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2834597", gasUsed: "77270", confirmations: "3221867"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "2"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510165584 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "2"}, {name: "claimedBy", type: "address", value: "0x3ef36a1c18acb29068d70c595b685daaa592a5a3"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "100000428682432175704" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"8\", \"3\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515367", timeStamp: "1510167582", hash: "0xfb3384bcb6fc75694453dd03c2ea5cb2bd2d7a1730878815a4f86c08e809abc5", nonce: "0", blockHash: "0x8909a628d56a1ca48f7f1004580cdb0ea9ebe4c19050d6f1fb780b27e8858f3c", transactionIndex: "42", from: "0x85f5b1ae68fa58f0bc320aec3711712e2c012065", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1245583", gasUsed: "77334", confirmations: "3221732"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "8"}, {type: "uint256", name: "yCoord", value: "3"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "8", "3", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510167582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "8"}, {name: "yCoord", type: "uint256", value: "3"}, {name: "claimedBy", type: "address", value: "0x85f5b1ae68fa58f0bc320aec3711712e2c012065"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "1453320000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"9\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515393", timeStamp: "1510167915", hash: "0x97ebd679c995021e515f361f0ac48179362692d8f82ebbafe63db8e9fded8e0b", nonce: "148", blockHash: "0x57bfe9ef76dee73e5e4e5ccac40123edfc8bc62e86fe389333ab7bd12d7c2f2a", transactionIndex: "26", from: "0x0386c37be02ca51e5aedae74fec07dda6d53f93e", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1617791", gasUsed: "77334", confirmations: "3221706"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "9"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "9", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510167915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "9"}, {name: "claimedBy", type: "address", value: "0x0386c37be02ca51e5aedae74fec07dda6d53f93e"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1137711628000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"9\", \"11\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515537", timeStamp: "1510169947", hash: "0x24ae7d9793caf524b9e03cc9612522d2a48e54eff2c35d55d308af7ea2c441c2", nonce: "0", blockHash: "0x112f17f666232619a3307a1c161da1dce8cea68e275dedc78eeaa6a06028e5e1", transactionIndex: "74", from: "0x6f606beda9cb3ab704c1c9902578f95bc0b02b1b", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4392610", gasUsed: "77334", confirmations: "3221562"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "9"}, {type: "uint256", name: "yCoord", value: "11"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "9", "11", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510169947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "9"}, {name: "yCoord", type: "uint256", value: "11"}, {name: "claimedBy", type: "address", value: "0x6f606beda9cb3ab704c1c9902578f95bc0b02b1b"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "2690664000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"15\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515877", timeStamp: "1510174822", hash: "0x441acb399815ced5121f83deaf6b7afd457104b2a7e239b6ad8434461982f3b1", nonce: "162", blockHash: "0x4165b66bd55427dd92c68283cb2da6a2f96f5327a44ae36fb78b03d8967fc60f", transactionIndex: "37", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1107959", gasUsed: "77270", confirmations: "3221222"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "15"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "15", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510174822 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "15"}, {name: "claimedBy", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"15\", \"15\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515881", timeStamp: "1510174848", hash: "0x9680275cca1148f01a2843b514934e979184496ab5aabaae29966ff803785f9e", nonce: "163", blockHash: "0x426ce8e7b4bb55202b6fbd5c4841794fb865d13e3dcd072530de53dcbe9bbe77", transactionIndex: "91", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4939725", gasUsed: "77334", confirmations: "3221218"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "15"}, {type: "uint256", name: "yCoord", value: "15"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "15", "15", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510174848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "15"}, {name: "yCoord", type: "uint256", value: "15"}, {name: "claimedBy", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"15\", \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515888", timeStamp: "1510175002", hash: "0x99a73280b0b6a781efc5cc0cfdd9538ad3cafb86f78d5c158d3e471b91ad9e5c", nonce: "164", blockHash: "0x8a3ca579d351e4dbc7b2efd87ef4b4d9c20c65725fc3810c515da778abe3197a", transactionIndex: "63", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3728060", gasUsed: "77270", confirmations: "3221211"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "15"}, {type: "uint256", name: "yCoord", value: "0"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "15", "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510175002 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "15"}, {name: "yCoord", type: "uint256", value: "0"}, {name: "claimedBy", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"0\", \"14\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515889", timeStamp: "1510175007", hash: "0xdf08e8211ffb1d2243857da3cbae4aac929aed3ca4ea71ae89ff55c25b63bc09", nonce: "165", blockHash: "0x703d2db73732047106d1fe2c2656432d3306d0ba12c488217945bbacec0a35ac", transactionIndex: "75", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "115905", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3207480", gasUsed: "77270", confirmations: "3221210"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "0"}, {type: "uint256", name: "yCoord", value: "14"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "0", "14", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510175007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "0"}, {name: "yCoord", type: "uint256", value: "14"}, {name: "claimedBy", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"14\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515889", timeStamp: "1510175007", hash: "0xe81efb51b675949a8aae6294e55b5fae2014348127cf13f38f42fbecef623da6", nonce: "166", blockHash: "0x703d2db73732047106d1fe2c2656432d3306d0ba12c488217945bbacec0a35ac", transactionIndex: "76", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3284814", gasUsed: "77334", confirmations: "3221210"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "14"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "14", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510175007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "14"}, {name: "claimedBy", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"15\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515889", timeStamp: "1510175007", hash: "0xc67a7e30e3b73feb01f3d311c8c581e54f81fb8408f398a8b64e004409d37ea2", nonce: "167", blockHash: "0x703d2db73732047106d1fe2c2656432d3306d0ba12c488217945bbacec0a35ac", transactionIndex: "77", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3362148", gasUsed: "77334", confirmations: "3221210"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "15"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "15", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510175007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "15"}, {name: "claimedBy", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"15\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515889", timeStamp: "1510175007", hash: "0x009df3c31987448210a9a4908ba170be22c07dd31fa631497731514f501e110a", nonce: "168", blockHash: "0x703d2db73732047106d1fe2c2656432d3306d0ba12c488217945bbacec0a35ac", transactionIndex: "78", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3439482", gasUsed: "77334", confirmations: "3221210"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "15"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "15", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510175007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "1"}, {name: "yCoord", type: "uint256", value: "15"}, {name: "claimedBy", type: "address", value: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"1\", \"15\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515899", timeStamp: "1510175160", hash: "0x75996760d9bc32d618e7597fffed2e3c11c1db2c17adfad2abc0a4010c2d142b", nonce: "169", blockHash: "0xf467f50b4878b32344d124c82b024e4f423aeadc30303d53b0035db9a00fc390", transactionIndex: "104", from: "0xdf9c6c6db6922f78ab990d0836503587815e5ebc", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "1000000000", isError: "0", txreceipt_status: "0", input: "0xb8a32c7e0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6519408", gasUsed: "23319", confirmations: "3221200"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "1"}, {type: "uint256", name: "yCoord", value: "15"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "1", "15", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510175160 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "15570446037236574208" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"7\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515951", timeStamp: "1510175741", hash: "0x02e81a795c90dc5578a54bb8315395f013850424baad4f80f035745b535dc88b", nonce: "0", blockHash: "0x18d419529f59e5a9019db62e18f545ae28907a1763658ed85ede2f47d1e570ab", transactionIndex: "50", from: "0xdda8f5a7cd4578c23e4b86ba5a44c62605743467", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2343683", gasUsed: "77334", confirmations: "3221148"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "7"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "7", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510175741 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "7"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0xdda8f5a7cd4578c23e4b86ba5a44c62605743467"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "1453320000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"3\", \"7\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4515989", timeStamp: "1510176197", hash: "0x63baadae29f308afdb7ae8a4087f41627953f116c8f8ecd8f58394d5e1ac1105", nonce: "1", blockHash: "0xd3d9b549ed4ac3d6359630f64dd078ccf79cb0435b7643db2571ca1539e9fcd9", transactionIndex: "31", from: "0xec8c1050b45789f9ee4d09dcc7d64aaf9e233338", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1105157", gasUsed: "77334", confirmations: "3221110"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "3"}, {type: "uint256", name: "yCoord", value: "7"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "3", "7", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510176197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "3"}, {name: "yCoord", type: "uint256", value: "7"}, {name: "claimedBy", type: "address", value: "0xec8c1050b45789f9ee4d09dcc7d64aaf9e233338"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "96503711864761264" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"2\", \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4516517", timeStamp: "1510183821", hash: "0xaf8e48488b45369cf1e93e3aaefb5273d7330f02d91ae776921011798d47a14f", nonce: "23", blockHash: "0x8c0f456facbfa4288793480405021e2dc2e259f456f9d9d91ea188b7702a118c", transactionIndex: "37", from: "0xf2b8b1ba1e2ab2e85f5108c620663c0f5c0b8285", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1676177", gasUsed: "77334", confirmations: "3220582"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "2"}, {type: "uint256", name: "yCoord", value: "6"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "2", "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510183821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "2"}, {name: "yCoord", type: "uint256", value: "6"}, {name: "claimedBy", type: "address", value: "0xf2b8b1ba1e2ab2e85f5108c620663c0f5c0b8285"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: claimTile( \"9\", \"9\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4516624", timeStamp: "1510185377", hash: "0x9e5489b76bf19529b2145f813a7a47621b584bcb82270d57b175174656d108e4", nonce: "82", blockHash: "0xb85978a1c03a58c1767ea7f213f378775687d8d38408165df0afc598a906924c", transactionIndex: "49", from: "0xdd41a4108d31830bd4e8a9b9e453585227a5f295", to: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c", value: "5000000000000000", gas: "116001", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0xb8a32c7e000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1233396", gasUsed: "77334", confirmations: "3220475"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "xCoord", value: "9"}, {type: "uint256", name: "yCoord", value: "9"}, {type: "uint256", name: "gameNumber", value: "1"}], name: "claimTile", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimTile(uint256,uint256,uint256)" ]( "9", "9", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510185377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameNumber", type: "uint256"}, {indexed: true, name: "xCoord", type: "uint256"}, {indexed: true, name: "yCoord", type: "uint256"}, {indexed: false, name: "claimedBy", type: "address"}], name: "TileClaimed", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TileClaimed", events: [{name: "gameNumber", type: "uint256", value: "1"}, {name: "xCoord", type: "uint256", value: "9"}, {name: "yCoord", type: "uint256", value: "9"}, {name: "claimedBy", type: "address", value: "0xdd41a4108d31830bd4e8a9b9e453585227a5f295"}], address: "0x103992432927f7ed1a5b3dc0e34186f80b16d93c"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "586360652137014433" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "18" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
