const Tokensale = artifacts.require( "./Tokensale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Tokensale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8DE429fe7d969C3075Fd72fD87B455B060933cFF", "0x40e4aF98aCA710dDbb86A4f7d2d781906D3d108c", "0x96c645D3D3706f793Ef52C19bBACe441900eD47D", "0x4E19d015b2b4ff6c0AEfc078C9ae1c079bb6A64a", "0x65d30dEcA4F8BcA6aD637Df28042137228590630", "0x09519a92007e055c8a727Df194CD951dA654B616", "0x74e6Acf300e8C8d8ef7C1f85D2589fC1FCc8A500", "0x4C0A0b46B01B4B98619bE54FB020A368e4363795", "0x95Ffb039F33a799038A55A56518441a538cc41f0", "0x4C3A043b86A5952A75b29a91f0f582e239a53044", "0x20bE28b880c7827FacF127bBc5B32309f19A4fCF", "0x46Dd4c296C7216f3313ceC800Bd2CE7606F97116", "0x1fd55891B17d8518c984268e6795a8ff6C708dDE", "0x13eF73437D510C2e4eE625a9783871915A1B39C6", "0xa94e01894F8dd2E8A09C2E447bDB2F0bbaa41909", "0x9dce98d491D5127Df9eB9C7280C2130aECc28A11", "0x80ac3bF017a1745aa59BA673AbE8E2E635E400b7", "0x632210F14D3639cdCE9117E7b86312C14c8a37e6", "0x428f7DA872E034C26c90fE70d8393E5213fefBD5", "0x73240b5B552F3E18fD54dF1EBD739b5E3692DbB3", "0x4b4a27B6e81e1fbB53E8E4F0DD673c43Fd5C916f", "0xC618D5c33aA874d82D9c2571D530A31E939cA3bD", "0x17d47eD222dcc4e8118E19776B45B8A9eEbE95BD", "0x95b4B41725502BB7217E45e8E25B81de1e799c23", "0xeda7D1C20B9403741A52bF898F738139DF4c0004", "0x1cD6Ec23C94828B062a2c420086A806cFd84c0A2", "0xF7eb4f2188B84b2Ff7e00E98Fa1067C04eFB0b59", "0x1e90E7404c8cA3333D86bC81D586449a99a5791A", "0x5Ea9dd2711c61F4b222818AACba703b552D43D06", "0x50F4053C4420C15f8825d409E036c3e751C2966F", "0xCd2b663Bb04C151D2d374f3960377605825b2b6b", "0x7F870F699b61323d360A1C8ba9E729d032F10685", "0xE9B938e5f453065e266Ab0baC83aE39607Dbe03F", "0x7650D859350EbF36DAAC163Af9e76D8687cEE367", "0x9Aa3ed833e187Ee71a853cD458f849E604A833d0", "0xc17e1E7aA42ccee9C43Ad1FAf1811f5a45A6b524", "0xF63db3c1AA825194C18c2Dc1a30b9A86b7410707", "0xc226EF614C1905f15d3a6493FE178e9D33F14a45", "0xA2D6247f16b06ef2d240204f99987B85F400fB44"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "allocatedTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_investorId", type: "uint256"}], name: "investorTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "raisedCHF", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "vaultETH", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "vaultERC20", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "raisedETH", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalRaisedCHF", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "authorityAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_investorId", type: "uint256"}], name: "investorAcceptedSPA", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ratesProvider", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "userRegistry", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_investorId", type: "uint256"}], name: "investorInvestedCHF", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_investorId", type: "uint256"}], name: "investorAllocations", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "availableSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sharePurchaseAgreementHash", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimalAutoWithdraw", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "basePriceCHFCent", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "refundedETH", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimalBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_investorId", type: "uint256"}], name: "investorUnspentETH", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "name", type: "string"}, {indexed: false, name: "_address", type: "address"}], name: "AuthorityDefined", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sharePurchaseAgreement", type: "bytes32"}], name: "SalePurchaseAgreementHash", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Allocation", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "amount", type: "uint256"}], name: "FundETH", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["AuthorityDefined(string,address)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)", "SalePurchaseAgreementHash(bytes32)", "Allocation(uint256,uint256)", "Investment(uint256,uint256)", "ChangeETHCHF(address,uint256,uint256,uint256)", "FundETH(uint256)", "WithdrawETH(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc8c81ac5a1b95ead7b5f71eafa51c9a1436e443c27ba33460885b9debe345abf", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0x17e73384223b513b8527d30845d17eb190bb29269f323c3bac7f57bcb8863595", "0x2ccf21bc8a43b499670fe41c33ca0f7b56c83863aca7c1494f0ede9068d2731a", "0x85369d2981b3997d58407719c231e73f6aa20ff0098b02824bc36d0bf81b0b3b", "0xdeaa92aa373191aee90a177118df53483d5f83ba9f14e5aef4ebb53fef1af76e", "0xfb52132c41e08fba4ca49ec0ecc612f9e9e65735297a70f7105f545d9448cd75", "0x566e45b1c8057e725bf62796a7f1d37ae294393cab069725a09daddd1af98b79"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6567885 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6586291 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_userRegistry", value: 5}, {type: "address", name: "_ratesProvider", value: 6}, {type: "address", name: "_vaultERC20", value: 7}, {type: "address", name: "_vaultETH", value: 8}], name: "Tokensale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "allocatedTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allocatedTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_investorId", value: random.range( maxRandom )}], name: "investorTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorTokens(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "raisedCHF", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "raisedCHF()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "vaultETH", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "vaultETH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "vaultERC20", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "vaultERC20()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "raisedETH", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "raisedETH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalRaisedCHF", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalRaisedCHF()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "authorityAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "authorityAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_investorId", value: random.range( maxRandom )}], name: "investorAcceptedSPA", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorAcceptedSPA(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ratesProvider", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ratesProvider()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "userRegistry", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "userRegistry()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_investorId", value: random.range( maxRandom )}], name: "investorInvestedCHF", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorInvestedCHF(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_investorId", value: random.range( maxRandom )}], name: "investorAllocations", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorAllocations(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "availableSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "availableSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sharePurchaseAgreementHash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sharePurchaseAgreementHash()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimalAutoWithdraw", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimalAutoWithdraw()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "basePriceCHFCent", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "basePriceCHFCent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "refundedETH", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "refundedETH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimalBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimalBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_investorId", value: random.range( maxRandom )}], name: "investorUnspentETH", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorUnspentETH(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Tokensale", function( accounts ) {

	it( "TEST: Tokensale( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6567885", timeStamp: "1540287623", hash: "0x014914729f8cb8e03779e94cb64cc6ade9bfd29f8e0f607c1c6aece8e70b2d9f", nonce: "28", blockHash: "0x45ea3182c859711d5fc6a9b7c19f8d9d2c54d7b18d7bb1053956ca1f6b6fc647", transactionIndex: "22", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: 0, value: "0", gas: "4807795", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4afaaa4b00000000000000000000000096c645d3d3706f793ef52c19bbace441900ed47d0000000000000000000000004e19d015b2b4ff6c0aefc078c9ae1c079bb6a64a00000000000000000000000065d30deca4f8bca6ad637df2804213722859063000000000000000000000000009519a92007e055c8a727df194cd951da654b61600000000000000000000000074e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500", contractAddress: "0x8de429fe7d969c3075fd72fd87b455b060933cff", cumulativeGasUsed: "5216394", gasUsed: "4279937", confirmations: "1140082"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_userRegistry", value: addressList[5]}, {type: "address", name: "_ratesProvider", value: addressList[6]}, {type: "address", name: "_vaultERC20", value: addressList[7]}, {type: "address", name: "_vaultETH", value: addressList[8]}], name: "Tokensale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Tokensale.new( addressList[4], addressList[5], addressList[6], addressList[7], addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540287623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Tokensale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: defineAuthority( `OPERATOR`, addressList[3] )", async function( ) {
		const txOriginal = {blockNumber: "6567919", timeStamp: "1540287936", hash: "0x9413743d3f6b08c8bb786490e7a949afc1d7f91718727a4fbf1ed70ef723da9f", nonce: "29", blockHash: "0xa29b93e7172a9773e3946a53079c747a7c85d2bd26dfd6b76e2ab05d846b9def", transactionIndex: "14", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfc21e167000000000000000000000000000000000000000000000000000000000000004000000000000000000000000040e4af98aca710ddbb86a4f7d2d781906d3d108c00000000000000000000000000000000000000000000000000000000000000084f50455241544f52000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "772050", gasUsed: "47714", confirmations: "1140048"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_name", value: `OPERATOR`}, {type: "address", name: "_address", value: addressList[3]}], name: "defineAuthority", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "defineAuthority(string,address)" ]( `OPERATOR`, addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540287936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "name", type: "string"}, {indexed: false, name: "_address", type: "address"}], name: "AuthorityDefined", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AuthorityDefined", events: [{name: "name", type: "string", value: "OPERATOR"}, {name: "_address", type: "address", value: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: fundETH(  )", async function( ) {
		const txOriginal = {blockNumber: "6567956", timeStamp: "1540288515", hash: "0xba906ce5cc915c47e31177fb6e99c1dc785ef3012a3a4f3752380fb3f85172ef", nonce: "30", blockHash: "0xe124462f5ca4f6329f5cb0e02e2000adaa96d57dff9d6e405bb3dbe0b00b4327", transactionIndex: "123", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "1000000000000000", gas: "4807795", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa9e31ac9", contractAddress: "", cumulativeGasUsed: "3074500", gasUsed: "23273", confirmations: "1140011"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "fundETH", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fundETH()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540288515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amount", type: "uint256"}], name: "FundETH", type: "event"} ;
		console.error( "eventCallOriginal[2,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FundETH", events: [{name: "amount", type: "uint256", value: "1000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[2,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: defineSPA( \"0xa8501f80213b7b075bb39dc674ae8443275b... )", async function( ) {
		const txOriginal = {blockNumber: "6567965", timeStamp: "1540288670", hash: "0x2aa68b1bc7357f07a4072837e8ef5174a4f08a46395a1b6cb05760877b1499b7", nonce: "31", blockHash: "0x9fc5d02ee08a6e292d315e029984c79314b49fcced170af46e1b49a8316fd58c", transactionIndex: "33", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0ab297e3a8501f80213b7b075bb39dc674ae8443275bbb0d163c56bccc8e32b9c04e4779", contractAddress: "", cumulativeGasUsed: "1836074", gasUsed: "45168", confirmations: "1140002"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_sharePurchaseAgreementHash", value: "0xa8501f80213b7b075bb39dc674ae8443275bbb0d163c56bccc8e32b9c04e4779"}], name: "defineSPA", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "defineSPA(bytes32)" ]( "0xa8501f80213b7b075bb39dc674ae8443275bbb0d163c56bccc8e32b9c04e4779", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540288670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sharePurchaseAgreement", type: "bytes32"}], name: "SalePurchaseAgreementHash", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SalePurchaseAgreementHash", events: [{name: "sharePurchaseAgreement", type: "bytes32", value: "0xa8501f80213b7b075bb39dc674ae8443275bbb0d163c56bccc8e32b9c04e4779"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawAllETHFunds(  )", async function( ) {
		const txOriginal = {blockNumber: "6567976", timeStamp: "1540288788", hash: "0x64e35cff77eb8d997fc3eb56e8cd737dcbe82cd22335d68a90d3e6db4060646b", nonce: "32", blockHash: "0x4b6663d61438f181ed4291f1f8ca610fcb55e05944347a4450827b25d3a122dc", transactionIndex: "48", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf0491911", contractAddress: "", cumulativeGasUsed: "1696236", gasUsed: "32176", confirmations: "1139991"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawAllETHFunds", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawAllETHFunds()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540288788 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[4,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "1000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[4,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: updateSchedule( \"1540288800\", \"1540548000\" )", async function( ) {
		const txOriginal = {blockNumber: "6567997", timeStamp: "1540289118", hash: "0x455bf2db8423cbd4c1098685ba4040469436918ffb1aa8d23345bbf37c10b1f6", nonce: "33", blockHash: "0x8f742130404b162240cf907989f638d768391f655f0e44995863e8b08cc91791", transactionIndex: "30", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe6671f90000000000000000000000000000000000000000000000000000000005bcef120000000000000000000000000000000000000000000000000000000005bd2e5a0", contractAddress: "", cumulativeGasUsed: "1416085", gasUsed: "33582", confirmations: "1139970"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_startAt", value: "1540288800"}, {type: "uint256", name: "_endAt", value: "1540548000"}], name: "updateSchedule", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateSchedule(uint256,uint256)" ]( "1540288800", "1540548000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540289118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6568069", timeStamp: "1540290098", hash: "0xa5637f29d950c47a43c95ab05384fc93de134e0e554e5952153497c87c714007", nonce: "0", blockHash: "0x098af7b3f83a39a98289ffcbd30655aaac7da151402a5ee043168c9d72507b3c", transactionIndex: "103", from: "0x4c0a0b46b01b4b98619be54fb020a368e4363795", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "500000000000000000", gas: "327913", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6097876", gasUsed: "327913", confirmations: "1139898"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540290098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "8"}, {name: "spentCHF", type: "uint256", value: "10000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[6,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x4c0a0b46b01b4b98619be54fb020a368e4363795"}, {name: "amount", type: "uint256", value: "489572624467616462"}, {name: "converted", type: "uint256", value: "10000"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[6,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "504414104000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6568202", timeStamp: "1540291917", hash: "0xbd16e6e03220bd2387eef353e490fb8eb7d5d691586635927d31eb36b4a4bb7e", nonce: "1", blockHash: "0x472ba4f5df2dfd0bb52dc32e85aea56aab7b9486ed4f7544276eba9f357d74ad", transactionIndex: "108", from: "0x4c0a0b46b01b4b98619be54fb020a368e4363795", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "1041835336000000000", gas: "183129", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6928025", gasUsed: "182465", confirmations: "1139765"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1041835336000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540291917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "8"}, {name: "spentCHF", type: "uint256", value: "21000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[7,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x4c0a0b46b01b4b98619be54fb020a368e4363795"}, {name: "amount", type: "uint256", value: "1028079033067606694"}, {name: "converted", type: "uint256", value: "21000"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[7,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[7,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "1041835336000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[7,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "504414104000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[10], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "6568452", timeStamp: "1540295169", hash: "0x1e5d3fdd8d679f7fe8dd1021ed6939fa0ff69e8215bf865c3a9dadf38b0b2c1a", nonce: "35", blockHash: "0x82b46cc05b7d7f4d7b60b487b4e49e5a786e6f9474b6e95bc97c4c320cf026b2", transactionIndex: "84", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000095ffb039f33a799038a55a56518441a538cc41f000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2435453", gasUsed: "286220", confirmations: "1139515"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[10]}, {type: "uint256", name: "_amountCHF", value: "1000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[10], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540295169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "6"}, {name: "spentCHF", type: "uint256", value: "1000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[10], \"99000\" )", async function( ) {
		const txOriginal = {blockNumber: "6568482", timeStamp: "1540295645", hash: "0xe0787e71a63bbc1c7393988465769fdc0de56a150eb5b6ca682e4fb692b2fa9c", nonce: "36", blockHash: "0x1371ce39249a03360359f9d1fde095fb3ec2d9844c4fe5861ec81f595acc3b19", transactionIndex: "50", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000095ffb039f33a799038a55a56518441a538cc41f000000000000000000000000000000000000000000000000000000000000182b8", contractAddress: "", cumulativeGasUsed: "2602644", gasUsed: "161210", confirmations: "1139485"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[10]}, {type: "uint256", name: "_amountCHF", value: "99000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[10], "99000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540295645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "6"}, {name: "spentCHF", type: "uint256", value: "99000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6568777", timeStamp: "1540300038", hash: "0xbdbd331bbb07d6f5d5fa92761cbb2eb0093626f07d6a2012bc2f086bfb14e28a", nonce: "0", blockHash: "0x85f184dec880363f3631db811f2709dc61bfd94315734bb441521b09e2cd2272", transactionIndex: "69", from: "0x4c3a043b86a5952a75b29a91f0f582e239a53044", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "100000000000000000000", gas: "21000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3182933", gasUsed: "21000", confirmations: "1139190"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "246440186216000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6570433", timeStamp: "1540323821", hash: "0x11ee4c73f90764d5578bb7e57a17cbdb1b193713f14bebc138d9068df5364ac9", nonce: "1", blockHash: "0x53fe2f607b6f2cbac296eb5aebef25546aaa9b45d971ac61f061e94e9cba03cf", transactionIndex: "2", from: "0x4c3a043b86a5952a75b29a91f0f582e239a53044", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "100000000000000000000", gas: "21000", gasPrice: "32000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "63000", gasUsed: "21000", confirmations: "1137534"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "246440186216000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6570466", timeStamp: "1540324224", hash: "0x6b506e4adc25218a0e595b104e836d3f18c4f67430ebca59ac8a7353cdc8a417", nonce: "2", blockHash: "0x19c00763179bc83e38450b93ab3fa6f4d5cbae1598ca8849cd0c8e8ac90f2115", transactionIndex: "0", from: "0x4c3a043b86a5952a75b29a91f0f582e239a53044", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "100000000000000000000", gas: "991000", gasPrice: "56000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "307539", gasUsed: "307539", confirmations: "1137501"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540324224 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "9"}, {name: "spentCHF", type: "uint256", value: "2042500"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[12,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x4c3a043b86a5952a75b29a91f0f582e239a53044"}, {name: "amount", type: "uint256", value: "99990209037058794800"}, {name: "converted", type: "uint256", value: "2042500"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[12,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[12,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[12,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "246440186216000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[12], \"50000\" )", async function( ) {
		const txOriginal = {blockNumber: "6574852", timeStamp: "1540386059", hash: "0x47e409aedcaeacf03e4fc2958a27e535c448b1e4467b94545e2e036388e9c926", nonce: "42", blockHash: "0xfbc0cc7170a0641e1e77641e2aab10f68552c7104fed7528cb459323e0780746", transactionIndex: "31", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000020be28b880c7827facf127bbc5b32309f19a4fcf000000000000000000000000000000000000000000000000000000000000c350", contractAddress: "", cumulativeGasUsed: "2973674", gasUsed: "271220", confirmations: "1133115"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[12]}, {type: "uint256", name: "_amountCHF", value: "50000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[12], "50000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540386059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "15"}, {name: "spentCHF", type: "uint256", value: "50000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[13], \"120000\" )", async function( ) {
		const txOriginal = {blockNumber: "6574875", timeStamp: "1540386455", hash: "0xb5c46919a56b4aedd5d93ca66240d0295ab5eaba80d8453a9320fa7576b76e95", nonce: "43", blockHash: "0x867ab495c4f30d8ce47610d986b66d2a8bcce6d131e3987fd3d1dd41e7544ae0", transactionIndex: "62", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000046dd4c296c7216f3313cec800bd2ce7606f97116000000000000000000000000000000000000000000000000000000000001d4c0", contractAddress: "", cumulativeGasUsed: "4161562", gasUsed: "271284", confirmations: "1133092"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[13]}, {type: "uint256", name: "_amountCHF", value: "120000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[13], "120000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540386455 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "2"}, {name: "spentCHF", type: "uint256", value: "120000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[14], \"500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6574885", timeStamp: "1540386626", hash: "0x0e135746a7f24272003240034f67b4da2636f81bc216bb32ec3e81395e2666af", nonce: "44", blockHash: "0x46269989621f0465825dc3be9e4bdbd54fcfe47b8faf2eeb0a6e8cf193d30456", transactionIndex: "60", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d53530000000000000000000000001fd55891b17d8518c984268e6795a8ff6c708dde000000000000000000000000000000000000000000000000000000000007a120", contractAddress: "", cumulativeGasUsed: "2714818", gasUsed: "271284", confirmations: "1133082"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[14]}, {type: "uint256", name: "_amountCHF", value: "500000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[14], "500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540386626 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "4"}, {name: "spentCHF", type: "uint256", value: "500000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6575517", timeStamp: "1540395078", hash: "0x11a4af9431e493285094f183fa84dc957a0f2e8fc5a64961cd3ac116274b1cbd", nonce: "83", blockHash: "0x9fc7a5d97dd4e27b1f52312d26f47702a029dca99194e0ef014b4a5ee3f95494", transactionIndex: "1", from: "0x13ef73437d510c2e4ee625a9783871915a1b39c6", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "1470000000000000000000", gas: "308203", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "328539", gasUsed: "307539", confirmations: "1132450"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1470000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540395078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "47"}, {name: "spentCHF", type: "uint256", value: "30027500"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[16,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x13ef73437d510c2e4ee625a9783871915a1b39c6"}, {name: "amount", type: "uint256", value: "1469990698585205855060"}, {name: "converted", type: "uint256", value: "30027500"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[16,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[16,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "1470000000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[16,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "85373769645265641" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6579245", timeStamp: "1540447931", hash: "0x95342ecdad408ef4816e043f87b37cf208564259bc10173637e4194b88c3dc08", nonce: "0", blockHash: "0x974a50555b30e63d45a6932f794c54523af7deb27145d5ae6fca7008755149c7", transactionIndex: "82", from: "0xa94e01894f8dd2e8a09c2e447bdb2f0bbaa41909", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "17954000000000000000", gas: "25200", gasPrice: "11486790510", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3370189", gasUsed: "25200", confirmations: "1128722"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "17954000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "15565172879148000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6579264", timeStamp: "1540448163", hash: "0xc403d9bbde91c5b5bd5f4021689e0fdedd9aecfd3f3f58d1c88ae601b1e16f16", nonce: "1", blockHash: "0x4462cfda65ee9f4b88332ec5ffa76adc0b0921e065836d35f6f0d9dec2f035e9", transactionIndex: "84", from: "0xa94e01894f8dd2e8a09c2e447bdb2f0bbaa41909", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "17940000000000000000", gas: "25200", gasPrice: "60000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7798702", gasUsed: "25200", confirmations: "1128703"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "17940000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "15565172879148000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6579296", timeStamp: "1540448592", hash: "0x4a16225fd3a6568517a9e3685deabe2d949845fd6f52491ef67b1994ddb627c5", nonce: "2", blockHash: "0x36f558c9b5cac507ddfe6567138cfdcaf6788e71f14694b74c2f3f42b773baab", transactionIndex: "2", from: "0xa94e01894f8dd2e8a09c2e447bdb2f0bbaa41909", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "17900000000000000000", gas: "292222", gasPrice: "60000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "334222", gasUsed: "292222", confirmations: "1128671"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "17900000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "15565172879148000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6579384", timeStamp: "1540449647", hash: "0x95103daac6a812f92cc8204802a14a726b710a14c928cef880c417ec44b3de4c", nonce: "3", blockHash: "0xc05c9d48ff4631149f58ec4e83cdee12ad0dbc82b1f4ea58a6d7c2d67c3d1bd3", transactionIndex: "51", from: "0xa94e01894f8dd2e8a09c2e447bdb2f0bbaa41909", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "17920000000000000000", gas: "400000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1821117", gasUsed: "307539", confirmations: "1128583"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "17920000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540449647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "40"}, {name: "spentCHF", type: "uint256", value: "366000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[20,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0xa94e01894f8dd2e8a09c2e447bdb2f0bbaa41909"}, {name: "amount", type: "uint256", value: "17917503304449992674"}, {name: "converted", type: "uint256", value: "366000"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[20,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[20,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "17920000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[20,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "15565172879148000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582210", timeStamp: "1540489023", hash: "0x59f10695478746640be9904aa9637fac3c5cc43646d2d4891d62eb0819cb32ce", nonce: "0", blockHash: "0x97da189886384313e71d045432ad06339670c1ae583013cc9f5887fb49643965", transactionIndex: "26", from: "0x9dce98d491d5127df9eb9c7280c2130aecc28a11", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "12239000000000000000", gas: "21000", gasPrice: "26000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1095790", gasUsed: "21000", confirmations: "1125757"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "12239000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "162620100000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582260", timeStamp: "1540489748", hash: "0x8a7cd5f8b9538f4b087bde9092834f79f9469f0fad3c0de802675d56d06fcca2", nonce: "1", blockHash: "0xb6372b50c5e48e87dfcd666a243a3a51824aa7c6b1fab4e0b5b315ce703a3bc5", transactionIndex: "30", from: "0x9dce98d491d5127df9eb9c7280c2130aecc28a11", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "12239000000000000000", gas: "400000", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1444659", gasUsed: "30369", confirmations: "1125707"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "12239000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540489748 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "162620100000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582355", timeStamp: "1540491174", hash: "0x4fc51252d443f4a29a4c5d02004e0b8db87c275ad3e1e4afa389f644b9971554", nonce: "2", blockHash: "0x36c1f06dce61eb52bbd0824229357d7c665fbfcf9e04830044569694a5efb712", transactionIndex: "77", from: "0x9dce98d491d5127df9eb9c7280c2130aecc28a11", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "12239000000000000000", gas: "400000", gasPrice: "7100000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7568758", gasUsed: "30369", confirmations: "1125612"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "12239000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540491174 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "162620100000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582387", timeStamp: "1540491702", hash: "0xfa547c8f3a9b03b45a21d4714acc3cb68450809ef97830d33cc3454c03264130", nonce: "4", blockHash: "0xc22663613062b296e597522b9915d97bd6fccec1f9ce3638bea471f701e8a47b", transactionIndex: "59", from: "0xa94e01894f8dd2e8a09c2e447bdb2f0bbaa41909", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "11440000000000000000", gas: "400000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2603439", gasUsed: "182465", confirmations: "1125580"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "11440000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540491702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "40"}, {name: "spentCHF", type: "uint256", value: "233500"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[24,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0xa94e01894f8dd2e8a09c2e447bdb2f0bbaa41909"}, {name: "amount", type: "uint256", value: "11430992314094091216"}, {name: "converted", type: "uint256", value: "233500"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[24,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[24,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "11440000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[24,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "15565172879148000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582535", timeStamp: "1540493851", hash: "0x5c340eb0c4f5d4f928ba73e1bd6f2934c78abc966a8f721bfb86530323189312", nonce: "0", blockHash: "0xe5a357286c9fbb3cfb08daebbc980e288febe37a5c597c31c1a473c8e907650b", transactionIndex: "36", from: "0x80ac3bf017a1745aa59ba673abe8e2e635e400b7", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "12239000000000000000", gas: "400000", gasPrice: "5100000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7454420", gasUsed: "307539", confirmations: "1125432"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "12239000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540493851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "29"}, {name: "spentCHF", type: "uint256", value: "250000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[25,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x80ac3bf017a1745aa59ba673abe8e2e635e400b7"}, {name: "amount", type: "uint256", value: "12238706271111763844"}, {name: "converted", type: "uint256", value: "250000"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[25,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[25,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "12239000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[25,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "512000000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6583184", timeStamp: "1540502900", hash: "0x22eeb09c73eaa62c79fc613d7a377786aded3af28c63ffd3027f94a8d14ad82f", nonce: "63", blockHash: "0x6ceaaf059d307e685019aeee2e96e5bc76282f8e922b32d0a1c35851894ed1a3", transactionIndex: "1", from: "0x632210f14d3639cdce9117e7b86312c14c8a37e6", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "2000000000000000000", gas: "315472", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "368563", gasUsed: "314808", confirmations: "1124783"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540502900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "21"}, {name: "spentCHF", type: "uint256", value: "40500"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[26,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x632210f14d3639cdce9117e7b86312c14c8a37e6"}, {name: "amount", type: "uint256", value: "1982669995594066796"}, {name: "converted", type: "uint256", value: "40500"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[26,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[26,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "2000000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[26,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "68939669000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6583333", timeStamp: "1540505079", hash: "0x685386f83cd1d95aa58d06cf8a7787f7d3be5e07b837171758b0a983da8fda86", nonce: "87", blockHash: "0x81dfa7c5a1a94137910b4a11f7901cbfc7b1ca688cc787bbbfc25b61f5f69d2d", transactionIndex: "20", from: "0x13ef73437d510c2e4ee625a9783871915a1b39c6", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "2835000000000000000000", gas: "190418", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "869136", gasUsed: "189754", confirmations: "1124634"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "2835000000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540505079 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "47"}, {name: "spentCHF", type: "uint256", value: "57910500"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[27,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x13ef73437d510c2e4ee625a9783871915a1b39c6"}, {name: "amount", type: "uint256", value: "2834997797033338228830"}, {name: "converted", type: "uint256", value: "57910500"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[27,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[27,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "2835000000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[27,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "85373769645265641" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[20], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583512", timeStamp: "1540507649", hash: "0x84567b4528ca7dfa55ed4ac63775b0150857b12a3a669887037e0a9335447a13", nonce: "52", blockHash: "0x94c1876205918e53f7f93855311a61b0d61e57a04d64b524b49a644165c0b192", transactionIndex: "11", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000428f7da872e034c26c90fe70d8393e5213fefbd500000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "1079521", gasUsed: "278553", confirmations: "1124455"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[20]}, {type: "uint256", name: "_amountCHF", value: "5000000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[20], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540507649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "48"}, {name: "spentCHF", type: "uint256", value: "5000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[21], \"500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583523", timeStamp: "1540507825", hash: "0x1ac80a685a1ad6f1093d0d59fa6e54ebf527514b7011f830e53564e5e1db1396", nonce: "53", blockHash: "0xb9c9a9a37e725f0b9ff77be6e2f24152943a16d4d7597f6baecefbd0276644a7", transactionIndex: "21", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000073240b5b552f3e18fd54df1ebd739b5e3692dbb3000000000000000000000000000000000000000000000000000000000007a120", contractAddress: "", cumulativeGasUsed: "1926804", gasUsed: "278553", confirmations: "1124444"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[21]}, {type: "uint256", name: "_amountCHF", value: "500000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[21], "500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540507825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "25"}, {name: "spentCHF", type: "uint256", value: "500000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[22], \"25000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583532", timeStamp: "1540508043", hash: "0x2cc62946f3e38197b9bdeb73f2200eafe257744acc98ebbfd18c711a9cdc411f", nonce: "54", blockHash: "0x2f8145c9fbd82e81e411a2143c2ce95f7cd874f934b230d3d041a760a14a05d8", transactionIndex: "17", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d53530000000000000000000000004b4a27b6e81e1fbb53e8e4f0dd673c43fd5c916f00000000000000000000000000000000000000000000000000000000000061a8", contractAddress: "", cumulativeGasUsed: "1397306", gasUsed: "278489", confirmations: "1124435"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[22]}, {type: "uint256", name: "_amountCHF", value: "25000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[22], "25000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540508043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "49"}, {name: "spentCHF", type: "uint256", value: "25000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[23], \"200000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583539", timeStamp: "1540508169", hash: "0x5ff3a1d1098c91506d2f1eb99b461a36fa4c4d35e2e301280270eae6ad296546", nonce: "55", blockHash: "0x2f61a7deb74db501dd7a391edfbc183179fbde3e7b9b2160b548379f2b0505f2", transactionIndex: "33", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000c618d5c33aa874d82d9c2571d530a31e939ca3bd0000000000000000000000000000000000000000000000000000000000030d40", contractAddress: "", cumulativeGasUsed: "2992916", gasUsed: "278553", confirmations: "1124428"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[23]}, {type: "uint256", name: "_amountCHF", value: "200000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[23], "200000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540508169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "50"}, {name: "spentCHF", type: "uint256", value: "200000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[24], \"500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583567", timeStamp: "1540508585", hash: "0x23c6c2351ec04552e9b4d9235d2f974687632f2d84c0b8c94a057ac379c492b6", nonce: "56", blockHash: "0xd748827cbb74f3b6f06f49c7048be11e0459be85357967ea13a1a30f6fd6a663", transactionIndex: "65", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000017d47ed222dcc4e8118e19776b45b8a9eebe95bd000000000000000000000000000000000000000000000000000000000007a120", contractAddress: "", cumulativeGasUsed: "3375679", gasUsed: "278553", confirmations: "1124400"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[24]}, {type: "uint256", name: "_amountCHF", value: "500000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[24], "500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540508585 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "51"}, {name: "spentCHF", type: "uint256", value: "500000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[25], \"1500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583580", timeStamp: "1540508774", hash: "0x1f4d286d24825062f3ce224a8f3fa6bef6d1b7bd225a8811d8c70648dbac3208", nonce: "57", blockHash: "0xcdef997f8ee5631aca6b9074693afcfeb81f3dd296eb4d31db5448d42847766d", transactionIndex: "15", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000095b4b41725502bb7217e45e8e25b81de1e799c23000000000000000000000000000000000000000000000000000000000016e360", contractAddress: "", cumulativeGasUsed: "1339455", gasUsed: "278553", confirmations: "1124387"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[25]}, {type: "uint256", name: "_amountCHF", value: "1500000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[25], "1500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540508774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "3"}, {name: "spentCHF", type: "uint256", value: "1500000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[26], \"3000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583586", timeStamp: "1540508939", hash: "0x3d27375efaf1b59164a2fb12fbbd9d833fdc57502acd6cafa50372553b64647c", nonce: "58", blockHash: "0x909f3bb782e054c7c6434ae9aeefca9ef992734502381423feb99071d1c8664a", transactionIndex: "59", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000eda7d1c20b9403741a52bf898f738139df4c000400000000000000000000000000000000000000000000000000000000002dc6c0", contractAddress: "", cumulativeGasUsed: "2526872", gasUsed: "278489", confirmations: "1124381"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[26]}, {type: "uint256", name: "_amountCHF", value: "3000000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[26], "3000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540508939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "52"}, {name: "spentCHF", type: "uint256", value: "3000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[27], \"300000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583597", timeStamp: "1540509178", hash: "0x234a84244936ddcdc3d44ed3a3c7ede6a251393a25e86583501699bdacc2a2a0", nonce: "59", blockHash: "0x037ef52f26737bb6296725b035987d7feea8affcc8ae7d17bb182c0424f8815e", transactionIndex: "50", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d53530000000000000000000000001cd6ec23c94828b062a2c420086a806cfd84c0a200000000000000000000000000000000000000000000000000000000000493e0", contractAddress: "", cumulativeGasUsed: "2661783", gasUsed: "278553", confirmations: "1124370"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[27]}, {type: "uint256", name: "_amountCHF", value: "300000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[27], "300000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540509178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "13"}, {name: "spentCHF", type: "uint256", value: "300000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[28], \"300000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583607", timeStamp: "1540509266", hash: "0xafe390727d41e018cc90a0e585cd124851cb880f65af6151860e5a526584ef79", nonce: "60", blockHash: "0x1d7454c60544749f562156f2ce4b4e02ec2649b4067bcbbfef0395b6b29d0eae", transactionIndex: "22", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000f7eb4f2188b84b2ff7e00e98fa1067c04efb0b5900000000000000000000000000000000000000000000000000000000000493e0", contractAddress: "", cumulativeGasUsed: "1786190", gasUsed: "278553", confirmations: "1124360"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[28]}, {type: "uint256", name: "_amountCHF", value: "300000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[28], "300000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540509266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "39"}, {name: "spentCHF", type: "uint256", value: "300000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[29], \"120000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583616", timeStamp: "1540509415", hash: "0xbd80c808cac5f2bbffc86680613a18620d6efee7cda5ced4bbf4e75d25a7c18d", nonce: "61", blockHash: "0x483f63876b9181c8b0ed898a4887f750b52638d0c174deb351aed8f2955a53a7", transactionIndex: "16", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d53530000000000000000000000001e90e7404c8ca3333d86bc81d586449a99a5791a000000000000000000000000000000000000000000000000000000000001d4c0", contractAddress: "", cumulativeGasUsed: "1654669", gasUsed: "278553", confirmations: "1124351"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[29]}, {type: "uint256", name: "_amountCHF", value: "120000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[29], "120000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540509415 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "14"}, {name: "spentCHF", type: "uint256", value: "120000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[30], \"200000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583634", timeStamp: "1540509750", hash: "0x4228fb5b028e31311f296ae45d9f55d0c38cb0357442535d0e9aeef53e5816ff", nonce: "62", blockHash: "0x6209ef32e508e65c66f1b8f1d4330798067cf65419d26d046149f81889e5d129", transactionIndex: "59", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d53530000000000000000000000005ea9dd2711c61f4b222818aacba703b552d43d060000000000000000000000000000000000000000000000000000000000030d40", contractAddress: "", cumulativeGasUsed: "2843165", gasUsed: "278553", confirmations: "1124333"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[30]}, {type: "uint256", name: "_amountCHF", value: "200000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[30], "200000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540509750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "5"}, {name: "spentCHF", type: "uint256", value: "200000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[31], \"100000\" )", async function( ) {
		const txOriginal = {blockNumber: "6583640", timeStamp: "1540509833", hash: "0x6993ad82dd547b9f4319475f35cd6c196e87d9b6f40c25e6e5da4e1766427764", nonce: "63", blockHash: "0x2d7aac878e3ab67a1a372f50ecb31eeb0fe1cce420bd67deeb2dad38688e4817", transactionIndex: "40", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "4807795", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d535300000000000000000000000050f4053c4420c15f8825d409e036c3e751c2966f00000000000000000000000000000000000000000000000000000000000186a0", contractAddress: "", cumulativeGasUsed: "2211387", gasUsed: "278553", confirmations: "1124327"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[31]}, {type: "uint256", name: "_amountCHF", value: "100000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[31], "100000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540509833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "20"}, {name: "spentCHF", type: "uint256", value: "100000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6585347", timeStamp: "1540533449", hash: "0x3d1af00e74a49c70caf711dce5677a2ed394d971d093d736ac168ff6ea5f5e4a", nonce: "12", blockHash: "0xa0c8e8868e4b927fe35287ce04070d726fbb9e40a8c4bc65a2b463e1f44a63e9", transactionIndex: "24", from: "0xcd2b663bb04c151d2d374f3960377605825b2b6b", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "1350000000000000000", gas: "400000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "955461", gasUsed: "314798", confirmations: "1122620"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "1350000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540533449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "34"}, {name: "spentCHF", type: "uint256", value: "27500"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[40,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0xcd2b663bb04c151d2d374f3960377605825b2b6b"}, {name: "amount", type: "uint256", value: "1346279434082342024"}, {name: "converted", type: "uint256", value: "27500"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[40,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[40,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "1350000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[40,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "25605307000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6585713", timeStamp: "1540538995", hash: "0x61f37cdd08774f4f8886eb8f0f2da615b8fb1027ed623c49a99872f91183690a", nonce: "0", blockHash: "0x27578410c9e35d14bfd3ca36645d31513bf5d51d145538126b272662766959d4", transactionIndex: "11", from: "0x7f870f699b61323d360a1c8ba9e729d032f10685", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "2987066058000000000", gas: "315462", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "698168", gasUsed: "314798", confirmations: "1122254"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "2987066058000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540538995 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "28"}, {name: "spentCHF", type: "uint256", value: "61000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x7f870f699b61323d360a1c8ba9e729d032f10685"}, {name: "amount", type: "uint256", value: "2986282780964703584"}, {name: "converted", type: "uint256", value: "61000"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[41,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "2987066058000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[41,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "27224000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6586147", timeStamp: "1540545130", hash: "0xbf9a201e1225c767a58d5af96f4d1218cac896738dd71517dcfe831a61e04598", nonce: "3", blockHash: "0xb6f55b7270ec993b980c353fbe96d360619a5b017e7d0ffe74ffda62007e7730", transactionIndex: "62", from: "0xe9b938e5f453065e266ab0bac83ae39607dbe03f", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "10000000000000000000", gas: "400000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2621577", gasUsed: "314798", confirmations: "1121820"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540545130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "36"}, {name: "spentCHF", type: "uint256", value: "204000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0xe9b938e5f453065e266ab0bac83ae39607dbe03f"}, {name: "amount", type: "uint256", value: "9986782200029372980"}, {name: "converted", type: "uint256", value: "204000"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[42,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "10000000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[42,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "17542676815000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6586203", timeStamp: "1540545835", hash: "0x5223e7b09e95ff597f9a6eb046648a784957e091ad35c44357120b3765cbedeb", nonce: "64", blockHash: "0x39072989c1c3c731e145de1010f1ad7a740d87a710070a626d6507fcc6bd3b4f", transactionIndex: "15", from: "0x632210f14d3639cdce9117e7b86312c14c8a37e6", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "4000000000000000000", gas: "190416", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "634813", gasUsed: "189752", confirmations: "1121764"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540545835 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "21"}, {name: "spentCHF", type: "uint256", value: "82000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "converted", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "ChangeETHCHF", type: "event"} ;
		console.error( "eventCallOriginal[43,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeETHCHF", events: [{name: "investor", type: "address", value: "0x632210f14d3639cdce9117e7b86312c14c8a37e6"}, {name: "amount", type: "uint256", value: "4014294805894159592"}, {name: "converted", type: "uint256", value: "82000"}, {name: "rate", type: "uint256", value: "48954814706026"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[43,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawETH", type: "event"} ;
		console.error( "eventCallOriginal[43,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawETH", events: [{name: "receiver", type: "address", value: "0x74e6acf300e8c8d8ef7c1f85d2589fc1fcc8a500"}, {name: "amount", type: "uint256", value: "4000000000000000000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[43,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "68939669000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[35], \"25000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586215", timeStamp: "1540546057", hash: "0xffe357aec2082789113e8410148b2b30c5433a0ade3760f89a7b2b590582f220", nonce: "73", blockHash: "0xc42a2622c307936e0398a8441db75e4d80a33b26e95398d3381046b7585bc42e", transactionIndex: "50", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "350000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d53530000000000000000000000007650d859350ebf36daac163af9e76d8687cee36700000000000000000000000000000000000000000000000000000000000061a8", contractAddress: "", cumulativeGasUsed: "3500945", gasUsed: "278479", confirmations: "1121752"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[35]}, {type: "uint256", name: "_amountCHF", value: "25000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[35], "25000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540546057 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[44,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "27"}, {name: "spentCHF", type: "uint256", value: "25000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[44,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[36], \"300000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586256", timeStamp: "1540546529", hash: "0x66de069b7c81283ec524b15aae8e31d32d22e7a4ecb16f992bfb4a5147636b00", nonce: "74", blockHash: "0xc1a954a69fafa395e45437901650f14390e017838100eeefe7ac65b02062e8d1", transactionIndex: "20", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "350000", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d53530000000000000000000000009aa3ed833e187ee71a853cd458f849e604a833d000000000000000000000000000000000000000000000000000000000000493e0", contractAddress: "", cumulativeGasUsed: "3525223", gasUsed: "278543", confirmations: "1121711"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[36]}, {type: "uint256", name: "_amountCHF", value: "300000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[36], "300000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540546529 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "32"}, {name: "spentCHF", type: "uint256", value: "300000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[37], \"50000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586268", timeStamp: "1540546648", hash: "0x540932b2119756f087833b035135f38229c1d3ea2c0626beb38a9824b480b1fe", nonce: "75", blockHash: "0x0a8b7dd7c14a04c10b68d1b8f34099a193d12f5cb6ff977e67fd0dc0a299008e", transactionIndex: "52", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "350000", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000c17e1e7aa42ccee9c43ad1faf1811f5a45a6b524000000000000000000000000000000000000000000000000000000000000c350", contractAddress: "", cumulativeGasUsed: "3294339", gasUsed: "278479", confirmations: "1121699"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[37]}, {type: "uint256", name: "_amountCHF", value: "50000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[37], "50000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540546648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "42"}, {name: "spentCHF", type: "uint256", value: "50000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[38], \"427500\" )", async function( ) {
		const txOriginal = {blockNumber: "6586277", timeStamp: "1540546799", hash: "0xb913e5610616bebf5bf96713c54ec93c5f5a243033630ba59e3f3fcd29482b12", nonce: "76", blockHash: "0xef721d5059e70c8035d38a311329dc1eaf80cc7b98f31c8576df1982ecd518f5", transactionIndex: "31", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "350000", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000f63db3c1aa825194c18c2dc1a30b9a86b741070700000000000000000000000000000000000000000000000000000000000685ec", contractAddress: "", cumulativeGasUsed: "1838708", gasUsed: "278543", confirmations: "1121690"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[38]}, {type: "uint256", name: "_amountCHF", value: "427500"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[38], "427500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540546799 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "38"}, {name: "spentCHF", type: "uint256", value: "427500"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[39], \"888000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586285", timeStamp: "1540546874", hash: "0xc0e20ad442b8a613a1434d96a886ed9371a6b564922df434cb018c1f1b3db889", nonce: "77", blockHash: "0x84d17a20265b65fdf668da231b2fc7fc7d151605e1823837758a08cc07bec4b3", transactionIndex: "37", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "350000", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000c226ef614c1905f15d3a6493fe178e9d33f14a4500000000000000000000000000000000000000000000000000000000000d8cc0", contractAddress: "", cumulativeGasUsed: "1545729", gasUsed: "278543", confirmations: "1121682"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[39]}, {type: "uint256", name: "_amountCHF", value: "888000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[39], "888000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540546874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "43"}, {name: "spentCHF", type: "uint256", value: "888000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addOffChainInvestment( addressList[40], \"750000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586291", timeStamp: "1540546929", hash: "0xeca17d2f78a69034b05f943935d930100a82580753bb1eb15984140fa4da84d6", nonce: "78", blockHash: "0x9c8a3836ad7a152401709ea365ff5220007df152a65b5584bc1ea136d7ca3ab2", transactionIndex: "53", from: "0x40e4af98aca710ddbb86a4f7d2d781906d3d108c", to: "0x8de429fe7d969c3075fd72fd87b455b060933cff", value: "0", gas: "350000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xcd9d5353000000000000000000000000a2d6247f16b06ef2d240204f99987b85f400fb4400000000000000000000000000000000000000000000000000000000000b71b0", contractAddress: "", cumulativeGasUsed: "1728978", gasUsed: "278479", confirmations: "1121676"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[40]}, {type: "uint256", name: "_amountCHF", value: "750000"}], name: "addOffChainInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOffChainInvestment(address,uint256)" ]( addressList[40], "750000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540546929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investorId", type: "uint256"}, {indexed: false, name: "spentCHF", type: "uint256"}], name: "Investment", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Investment", events: [{name: "investorId", type: "uint256", value: "53"}, {name: "spentCHF", type: "uint256", value: "750000"}], address: "0x8de429fe7d969c3075fd72fd87b455b060933cff"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "504804737000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
