const TokenAuction = artifacts.require( "./TokenAuction.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TokenAuction" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xaD4c4ff144e42C73b6333b75Af3Cee5Af901C10e", "0x8B8a571730b631f58E7965d78582Eae1B0417AB6", "0xc16c28D110697b1aD7a0f640Eee2E343febEa43B", "0xEb4245C88C660Ae4eE23c76954e5490ccd7bbd82", "0x9A2F50977426C1226F037B1887Dd7C0205092E0a", "0xb569Db9407a7cA3F0B73090D1DC7FE2F4e5bA26E", "0x79B2B9047f5EE28029033f10e8811816EFf28901", "0x5252013df34cFb6E4Faa0DF41049049304403698", "0x950c77b394c6b2993CcE5158497C32d8C921d748", "0x3794c5e109FF82E9d1EFF80E16011f2633F1510d", "0x4016C7363d466f9Df59AE70FcA88BB82826CACF0", "0x26A46318376E68601A98A9b3E2AFE02c057a071e", "0xF48Ae436E4813c7dcD5cdeB305131D07CA022469", "0x06b9737A7a625478fe5a65Bf4BfF4390fF6ACe96"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "purchasedCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "stateMask", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "auctionEnd", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "developers", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimalMultiplier", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "saleDuration", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "auctionStart", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "proceeds", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "strikePricePctX10", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "developerPctX10K", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isLocked", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "executedCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "saleEnd", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "strikePrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "secretBids", outputs: [{name: "disqualified", type: "bool"}, {name: "deposit", type: "uint256"}, {name: "refund", type: "uint256"}, {name: "tokens", type: "uint256"}, {name: "hash", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "secretBidCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "expiredCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "underwriter", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "developerReserve", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExpireEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "message", type: "string"}, {indexed: false, name: "val", type: "uint256"}], name: "BizarreEvent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "mask", type: "uint256"}], name: "StateChangeEvent", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["SecretBidEvent(uint256,address,uint256,bytes32,bytes)", "ExecuteEvent(uint256,address,uint256,uint256)", "ExpireEvent(uint256,address,uint256,uint256)", "BizarreEvent(address,string,uint256)", "StateChangeEvent(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xe15b694b705acb702334150b898bb2a2646b7bd2748a22f26c36e6ba7cb89f1c", "0xf3f4e84227586e797977952ce09ff57aa48556bbd992e1f611cc2c3f6fb1f745", "0x44cccea75941d95449197a42ac2e10a309a313661b13e669b8bb52c8ccb6f175", "0x0ee13c1ef372bf0aa1349495ea8f00b99ded79c910cfa09fa1d60600cb9ebaa5", "0xc4d1978aca5dbd557298da69c7a31a5dec628dce416e9a721f63665722865502"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4553771 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4574688 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "TokenAuction", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "purchasedCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "purchasedCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stateMask", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stateMask()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "auctionEnd", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "auctionEnd()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "developers", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "developers()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimalMultiplier", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimalMultiplier()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "saleDuration", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "saleDuration()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "auctionStart", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "auctionStart()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "proceeds", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "proceeds()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "strikePricePctX10", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "strikePricePctX10()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "developerPctX10K", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "developerPctX10K()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isLocked", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isLocked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "executedCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "executedCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "saleEnd", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "saleEnd()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "strikePrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "strikePrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "secretBids", outputs: [{name: "disqualified", type: "bool"}, {name: "deposit", type: "uint256"}, {name: "refund", type: "uint256"}, {name: "tokens", type: "uint256"}, {name: "hash", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "secretBids(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "secretBidCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "secretBidCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "expiredCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "expiredCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "underwriter", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "underwriter()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "developerReserve", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "developerReserve()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TokenAuction", function( accounts ) {

	it( "TEST: TokenAuction(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4553771", blockHash: "0x2782b119cc727d40f29f5eb67bcc0e72be9b7131e04669ae3ca8d2e3de9f1a82", timeStamp: "1510700906", hash: "0xcf8f189d033cc4ebc5081ea7a19c09bbdb2373fce004cccb76ed47e0f713dff0", nonce: "2091", transactionIndex: "44", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: 0, value: "0", gas: "2500000", gasPrice: "19000000000", input: "0xc5b05616", contractAddress: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", cumulativeGasUsed: "3264383", txreceipt_status: "1", gasUsed: "1477739", confirmations: "3185459", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "TokenAuction", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TokenAuction.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510700906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TokenAuction.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setToken( addressList[4], \"1000\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4553814", blockHash: "0x6fdb2b71d08c410996db391e13e72f797ee705a5ddaef51c0842050544dd6176", timeStamp: "1510701640", hash: "0x1080e81f04e53738dc486e25f0c88aecb7e459ca6bf39ef25f509e6d92be3641", nonce: "2093", transactionIndex: "167", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "86407", gasPrice: "19000000000", input: "0xe6c52016000000000000000000000000c16c28d110697b1ad7a0f640eee2e343febea43b00000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000eb4245c88c660ae4ee23c76954e5490ccd7bbd82", contractAddress: "", cumulativeGasUsed: "4398882", txreceipt_status: "1", gasUsed: "86407", confirmations: "3185416", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "uint256", name: "_decimalMultiplier", value: "1000"}, {type: "address", name: "_underwriter", value: addressList[5]}], name: "setToken", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setToken(address,uint256,address)" ]( addressList[4], "1000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510701640 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: reserveDeveloperTokens( addressList[6], \"333333\" )", async function( ) {
		const txOriginal = {blockNumber: "4553985", blockHash: "0xaebb531e106056b354d9448e91367f8a972274c2b02fdb81e22729a5adb8bf74", timeStamp: "1510703900", hash: "0x720203dc2222319129215b3952ea122f2b155cced3bbaf18e795529de9af6fe8", nonce: "2094", transactionIndex: "29", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "87355", gasPrice: "19000000000", input: "0x1f6c76f40000000000000000000000009a2f50977426c1226f037b1887dd7c0205092e0a0000000000000000000000000000000000000000000000000000000000051615", contractAddress: "", cumulativeGasUsed: "1175802", txreceipt_status: "1", gasUsed: "87355", confirmations: "3185245", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_developers", value: addressList[6]}, {type: "uint256", name: "_developerPctX10K", value: "333333"}], name: "reserveDeveloperTokens", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reserveDeveloperTokens(address,uint256)" ]( addressList[6], "333333", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510703900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setAuctionParms( \"1510704066\", \"3600\", \"3600\" )", async function( ) {
		const txOriginal = {blockNumber: "4554006", blockHash: "0xb7aedd3d92b1dcd46b5cc0887d1ffe53ad429c824196134a5681e46ca70fd5b2", timeStamp: "1510704178", hash: "0x9eef1be6107e90d3617732ef900b34a6836f0a006636ffb0bc3ce8a5d64ce19e", nonce: "2095", transactionIndex: "44", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "83368", gasPrice: "19000000000", input: "0x2134927e000000000000000000000000000000000000000000000000000000005a0b83c20000000000000000000000000000000000000000000000000000000000000e100000000000000000000000000000000000000000000000000000000000000e10", contractAddress: "", cumulativeGasUsed: "1552797", txreceipt_status: "1", gasUsed: "83368", confirmations: "3185224", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_auctionStart", value: "1510704066"}, {type: "uint256", name: "_auctionDuration", value: "3600"}, {type: "uint256", name: "_saleDuration", value: "3600"}], name: "setAuctionParms", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAuctionParms(uint256,uint256,uint256)" ]( "1510704066", "3600", "3600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510704178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: houseKeep(  )", async function( ) {
		const txOriginal = {blockNumber: "4554031", blockHash: "0x625ff40492649028e2ecbf18ad3a77011a2044896ca11474cb36de158bee64b6", timeStamp: "1510704522", hash: "0x3cf606ca25a78708de0be61d71fc2d92ec1b6451857eaea12ac1621c52c961ed", nonce: "2097", transactionIndex: "48", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "44373", gasPrice: "19000000000", input: "0xda00586b", contractAddress: "", cumulativeGasUsed: "1129335", txreceipt_status: "1", gasUsed: "44373", confirmations: "3185199", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "houseKeep", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "houseKeep()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510704522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "mask", type: "uint256"}], name: "StateChangeEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StateChangeEvent", events: [{name: "mask", type: "uint256", value: "1"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0xd418b264246959b2992e5aa5629cf2bef100... )", async function( ) {
		const txOriginal = {blockNumber: "4554064", blockHash: "0x6554835debfef57e32d5f6c4eba52f742bed8090bf56b2daf262792ae2531ad2", timeStamp: "1510704952", hash: "0xb31e61a2eedb07b9e40b3f2a781a969ef0745fe17d6089416bde6ac6c062c594", nonce: "14", transactionIndex: "52", from: "0xb569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "5000000000000000", gas: "200000", gasPrice: "8000000000", input: "0x25ede147d418b264246959b2992e5aa5629cf2bef10021b2732e3282457b61d2b76c37b5000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001002d8bedff887af91c71d3350a91c6e4849ce6f157363e37e2d33e03081520602e37f3a02b2e856f9534b63fcbf0b1e3f00035a757fbe7648dbd4d400895a6191810022207a53d900601f987562b4e99daefae8025bece237f036ad2cd5a1b14bcd753c0b0b6d3bf0e521996b05a64103c1d72a7cbeb5494aceb746d72880ba2a552068926a03b1db17cc73ee85403ecdcabf2ca2896a750bb53144e9c07a21b4f9d1176899b14040b1cf3fba6a59e2bdedbdf3fda12827fb0325dccb547439b89f748cb99e8235310c2d8c69f7baeb8998c5d2e2f7e536d283126cc5065b37959d7fd873e2339648ce5467036693547324de718907c3a4947646653fb5cf575c6", contractAddress: "", cumulativeGasUsed: "3619313", txreceipt_status: "1", gasUsed: "108755", confirmations: "3185166", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0xd418b264246959b2992e5aa5629cf2bef10021b2732e3282457b61d2b76c37b5"}, {type: "bytes", name: "_message", value: "0x2d8bedff887af91c71d3350a91c6e4849ce6f157363e37e2d33e03081520602e37f3a02b2e856f9534b63fcbf0b1e3f00035a757fbe7648dbd4d400895a6191810022207a53d900601f987562b4e99daefae8025bece237f036ad2cd5a1b14bcd753c0b0b6d3bf0e521996b05a64103c1d72a7cbeb5494aceb746d72880ba2a552068926a03b1db17cc73ee85403ecdcabf2ca2896a750bb53144e9c07a21b4f9d1176899b14040b1cf3fba6a59e2bdedbdf3fda12827fb0325dccb547439b89f748cb99e8235310c2d8c69f7baeb8998c5d2e2f7e536d283126cc5065b37959d7fd873e2339648ce5467036693547324de718907c3a4947646653fb5cf575c6"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0xd418b264246959b2992e5aa5629cf2bef10021b2732e3282457b61d2b76c37b5", "0x2d8bedff887af91c71d3350a91c6e4849ce6f157363e37e2d33e03081520602e37f3a02b2e856f9534b63fcbf0b1e3f00035a757fbe7648dbd4d400895a6191810022207a53d900601f987562b4e99daefae8025bece237f036ad2cd5a1b14bcd753c0b0b6d3bf0e521996b05a64103c1d72a7cbeb5494aceb746d72880ba2a552068926a03b1db17cc73ee85403ecdcabf2ca2896a750bb53144e9c07a21b4f9d1176899b14040b1cf3fba6a59e2bdedbdf3fda12827fb0325dccb547439b89f748cb99e8235310c2d8c69f7baeb8998c5d2e2f7e536d283126cc5065b37959d7fd873e2339648ce5467036693547324de718907c3a4947646653fb5cf575c6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510704952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "0"}, {name: "bidder", type: "address", value: "0xb569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e"}, {name: "deposit", type: "uint256", value: "5000000000000000"}, {name: "hash", type: "bytes32", value: "0xd418b264246959b2992e5aa5629cf2bef10021b2732e3282457b61d2b76c37b5"}, {name: "message", type: "bytes", value: "0x2d8bedff887af91c71d3350a91c6e4849ce6f157363e37e2d33e03081520602e37f3a02b2e856f9534b63fcbf0b1e3f00035a757fbe7648dbd4d400895a6191810022207a53d900601f987562b4e99daefae8025bece237f036ad2cd5a1b14bcd753c0b0b6d3bf0e521996b05a64103c1d72a7cbeb5494aceb746d72880ba2a552068926a03b1db17cc73ee85403ecdcabf2ca2896a750bb53144e9c07a21b4f9d1176899b14040b1cf3fba6a59e2bdedbdf3fda12827fb0325dccb547439b89f748cb99e8235310c2d8c69f7baeb8998c5d2e2f7e536d283126cc5065b37959d7fd873e2339648ce5467036693547324de718907c3a4947646653fb5cf575c6"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0x46833548d298cee5ddbdd613d9215180344d... )", async function( ) {
		const txOriginal = {blockNumber: "4554090", blockHash: "0x08ec1535c38eb079656ced27464295dd15307913478027d6a68606405df8101f", timeStamp: "1510705263", hash: "0xdb7526992d56100364666f3ca9b944c04ff90f56e1e9bdc79d53246142ed717f", nonce: "7", transactionIndex: "61", from: "0x79b2b9047f5ee28029033f10e8811816eff28901", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "10000000000000000", gas: "200000", gasPrice: "6000000000", input: "0x25ede14746833548d298cee5ddbdd613d9215180344d2af86da3ade8e53fe5e5e1e217b90000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000010092ec3f288b3523a7d1189fdc4f17f6717746b273f60a9a5328421ab1505b873d71b8db0e75852cdcfd0e42f6612844f137aa3a6a38961a664893e2e8c85255411f1d50827034a087efa76ae8721788da6b6d4a7219235d18751a76ddbcecdb2c6a79cd7f50e96e6c3c278549883f511f35a4201fbe325e39e5c0ed1e964d119ca25b370db207dce41183c0be08f2bf6af19ef5453848335583729249c9631b6945ab90d0c3d22ecf018fc2e200d1861fbf5c92999f11eabc6505dc189d24466943bcbcb7bedadcd4ffa4265589798813603e2c3383ab9110b9b4eb1661fb4f9fe855995d5fc97f224a3ef8e6fbe26156820f495ad20f222c98bb0d295227bbb3", contractAddress: "", cumulativeGasUsed: "2743281", txreceipt_status: "1", gasUsed: "93819", confirmations: "3185140", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0x46833548d298cee5ddbdd613d9215180344d2af86da3ade8e53fe5e5e1e217b9"}, {type: "bytes", name: "_message", value: "0x92ec3f288b3523a7d1189fdc4f17f6717746b273f60a9a5328421ab1505b873d71b8db0e75852cdcfd0e42f6612844f137aa3a6a38961a664893e2e8c85255411f1d50827034a087efa76ae8721788da6b6d4a7219235d18751a76ddbcecdb2c6a79cd7f50e96e6c3c278549883f511f35a4201fbe325e39e5c0ed1e964d119ca25b370db207dce41183c0be08f2bf6af19ef5453848335583729249c9631b6945ab90d0c3d22ecf018fc2e200d1861fbf5c92999f11eabc6505dc189d24466943bcbcb7bedadcd4ffa4265589798813603e2c3383ab9110b9b4eb1661fb4f9fe855995d5fc97f224a3ef8e6fbe26156820f495ad20f222c98bb0d295227bbb3"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0x46833548d298cee5ddbdd613d9215180344d2af86da3ade8e53fe5e5e1e217b9", "0x92ec3f288b3523a7d1189fdc4f17f6717746b273f60a9a5328421ab1505b873d71b8db0e75852cdcfd0e42f6612844f137aa3a6a38961a664893e2e8c85255411f1d50827034a087efa76ae8721788da6b6d4a7219235d18751a76ddbcecdb2c6a79cd7f50e96e6c3c278549883f511f35a4201fbe325e39e5c0ed1e964d119ca25b370db207dce41183c0be08f2bf6af19ef5453848335583729249c9631b6945ab90d0c3d22ecf018fc2e200d1861fbf5c92999f11eabc6505dc189d24466943bcbcb7bedadcd4ffa4265589798813603e2c3383ab9110b9b4eb1661fb4f9fe855995d5fc97f224a3ef8e6fbe26156820f495ad20f222c98bb0d295227bbb3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510705263 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "0"}, {name: "bidder", type: "address", value: "0x79b2b9047f5ee28029033f10e8811816eff28901"}, {name: "deposit", type: "uint256", value: "10000000000000000"}, {name: "hash", type: "bytes32", value: "0x46833548d298cee5ddbdd613d9215180344d2af86da3ade8e53fe5e5e1e217b9"}, {name: "message", type: "bytes", value: "0x92ec3f288b3523a7d1189fdc4f17f6717746b273f60a9a5328421ab1505b873d71b8db0e75852cdcfd0e42f6612844f137aa3a6a38961a664893e2e8c85255411f1d50827034a087efa76ae8721788da6b6d4a7219235d18751a76ddbcecdb2c6a79cd7f50e96e6c3c278549883f511f35a4201fbe325e39e5c0ed1e964d119ca25b370db207dce41183c0be08f2bf6af19ef5453848335583729249c9631b6945ab90d0c3d22ecf018fc2e200d1861fbf5c92999f11eabc6505dc189d24466943bcbcb7bedadcd4ffa4265589798813603e2c3383ab9110b9b4eb1661fb4f9fe855995d5fc97f224a3ef8e6fbe26156820f495ad20f222c98bb0d295227bbb3"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0x4f62c51c7ae507907aab49a6fff631cccd84... )", async function( ) {
		const txOriginal = {blockNumber: "4554103", blockHash: "0xaa3970a2cadb47078f037d183216e28a9c4bcb8a6e0838b6cf5a7168a616318f", timeStamp: "1510705446", hash: "0xd6c501cb2be4fefab12f4210bd9edcd62c382f8c6cfa1efcc506898570d7e77f", nonce: "8", transactionIndex: "56", from: "0x5252013df34cfb6e4faa0df41049049304403698", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "4000000000000000", gas: "200000", gasPrice: "10000000000", input: "0x25ede1474f62c51c7ae507907aab49a6fff631cccd8454dea6490fed14ecdd8923841d54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001002fbde5bbd9364498607ad3b4b13441af219c24c9499489c2c7a8acec82dcaa0cb5f0f788a5e7c426929ffd2c94dd6fce2b46ec69b6601856347046ceedc7cee26f8c4a364dee97f0768d2787aeb0e439bc40a1895360640283da877f79060bb58c5e005eb7e93932926f7b26e4b1f825ad4bd9c907ad4e171848d0d7837f1a95431dcaed29a7f8bb34ba18785ac11be3ef96845452102b270c104bc8d21e7afead710da447ec19a323b47b15799d61f31b24e14f5487e7c18bd37439416ef2b372c6ce009d7c2e4530457dc5ae89c5d20f5ab84e7aab123defa8d206a2c0f3a323f3a8a4c26ed062ba48bd0a172b5aa1069472383f7d2de0f69c7df70b2b9b49", contractAddress: "", cumulativeGasUsed: "1756830", txreceipt_status: "1", gasUsed: "93755", confirmations: "3185127", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0x4f62c51c7ae507907aab49a6fff631cccd8454dea6490fed14ecdd8923841d54"}, {type: "bytes", name: "_message", value: "0x2fbde5bbd9364498607ad3b4b13441af219c24c9499489c2c7a8acec82dcaa0cb5f0f788a5e7c426929ffd2c94dd6fce2b46ec69b6601856347046ceedc7cee26f8c4a364dee97f0768d2787aeb0e439bc40a1895360640283da877f79060bb58c5e005eb7e93932926f7b26e4b1f825ad4bd9c907ad4e171848d0d7837f1a95431dcaed29a7f8bb34ba18785ac11be3ef96845452102b270c104bc8d21e7afead710da447ec19a323b47b15799d61f31b24e14f5487e7c18bd37439416ef2b372c6ce009d7c2e4530457dc5ae89c5d20f5ab84e7aab123defa8d206a2c0f3a323f3a8a4c26ed062ba48bd0a172b5aa1069472383f7d2de0f69c7df70b2b9b49"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0x4f62c51c7ae507907aab49a6fff631cccd8454dea6490fed14ecdd8923841d54", "0x2fbde5bbd9364498607ad3b4b13441af219c24c9499489c2c7a8acec82dcaa0cb5f0f788a5e7c426929ffd2c94dd6fce2b46ec69b6601856347046ceedc7cee26f8c4a364dee97f0768d2787aeb0e439bc40a1895360640283da877f79060bb58c5e005eb7e93932926f7b26e4b1f825ad4bd9c907ad4e171848d0d7837f1a95431dcaed29a7f8bb34ba18785ac11be3ef96845452102b270c104bc8d21e7afead710da447ec19a323b47b15799d61f31b24e14f5487e7c18bd37439416ef2b372c6ce009d7c2e4530457dc5ae89c5d20f5ab84e7aab123defa8d206a2c0f3a323f3a8a4c26ed062ba48bd0a172b5aa1069472383f7d2de0f69c7df70b2b9b49", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510705446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "0"}, {name: "bidder", type: "address", value: "0x5252013df34cfb6e4faa0df41049049304403698"}, {name: "deposit", type: "uint256", value: "4000000000000000"}, {name: "hash", type: "bytes32", value: "0x4f62c51c7ae507907aab49a6fff631cccd8454dea6490fed14ecdd8923841d54"}, {name: "message", type: "bytes", value: "0x2fbde5bbd9364498607ad3b4b13441af219c24c9499489c2c7a8acec82dcaa0cb5f0f788a5e7c426929ffd2c94dd6fce2b46ec69b6601856347046ceedc7cee26f8c4a364dee97f0768d2787aeb0e439bc40a1895360640283da877f79060bb58c5e005eb7e93932926f7b26e4b1f825ad4bd9c907ad4e171848d0d7837f1a95431dcaed29a7f8bb34ba18785ac11be3ef96845452102b270c104bc8d21e7afead710da447ec19a323b47b15799d61f31b24e14f5487e7c18bd37439416ef2b372c6ce009d7c2e4530457dc5ae89c5d20f5ab84e7aab123defa8d206a2c0f3a323f3a8a4c26ed062ba48bd0a172b5aa1069472383f7d2de0f69c7df70b2b9b49"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0x8b749c5c86be232762d8733ecdbf1c13d1eb... )", async function( ) {
		const txOriginal = {blockNumber: "4554121", blockHash: "0x30c1736622e8f247c497843baa030f72972afe8a3f552ccb131753875d10d948", timeStamp: "1510705674", hash: "0x395dd6a6ecf95585de007169549f7a35aafe16dd1deb59e07cc7a7c5c9b02ad0", nonce: "11", transactionIndex: "52", from: "0x950c77b394c6b2993cce5158497c32d8c921d748", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "8000000000000000", gas: "200000", gasPrice: "10000000000", input: "0x25ede1478b749c5c86be232762d8733ecdbf1c13d1eb02e5a3f6822d62b05df525ec8eda000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001008d3a00ac0d9cd56d78f60fdacdd2256442a1863f430ac64ec05d046631184a32b941c3080ceca95694ddc9ce5b5e192848e37e88c321ecef95edb1e00425ec36c5a0b4ab8f9421f682728aff2110193e0c55af361144229d5555c7e9ae74bda9c8e7a56e5becd99cc1c909f287a7a729b8b829df6357b6a16367bef90b9463a06d7a0db485ec1426f09469758a2a86da34353bed3f10ac2e0d7084ffb15fd7a596198abe166f71572c5b0b08831297e95c9d6ae357c5a519c8844d57a016afb1c4a953ca962e21de71761bfa5888c369361e80a93c3d70c90490dc345399144dc635e6b4eceb9bc09200bb1f805174efd779321741b1b287246e04d260c63529", contractAddress: "", cumulativeGasUsed: "1404913", txreceipt_status: "1", gasUsed: "93755", confirmations: "3185109", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "8000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0x8b749c5c86be232762d8733ecdbf1c13d1eb02e5a3f6822d62b05df525ec8eda"}, {type: "bytes", name: "_message", value: "0x8d3a00ac0d9cd56d78f60fdacdd2256442a1863f430ac64ec05d046631184a32b941c3080ceca95694ddc9ce5b5e192848e37e88c321ecef95edb1e00425ec36c5a0b4ab8f9421f682728aff2110193e0c55af361144229d5555c7e9ae74bda9c8e7a56e5becd99cc1c909f287a7a729b8b829df6357b6a16367bef90b9463a06d7a0db485ec1426f09469758a2a86da34353bed3f10ac2e0d7084ffb15fd7a596198abe166f71572c5b0b08831297e95c9d6ae357c5a519c8844d57a016afb1c4a953ca962e21de71761bfa5888c369361e80a93c3d70c90490dc345399144dc635e6b4eceb9bc09200bb1f805174efd779321741b1b287246e04d260c63529"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0x8b749c5c86be232762d8733ecdbf1c13d1eb02e5a3f6822d62b05df525ec8eda", "0x8d3a00ac0d9cd56d78f60fdacdd2256442a1863f430ac64ec05d046631184a32b941c3080ceca95694ddc9ce5b5e192848e37e88c321ecef95edb1e00425ec36c5a0b4ab8f9421f682728aff2110193e0c55af361144229d5555c7e9ae74bda9c8e7a56e5becd99cc1c909f287a7a729b8b829df6357b6a16367bef90b9463a06d7a0db485ec1426f09469758a2a86da34353bed3f10ac2e0d7084ffb15fd7a596198abe166f71572c5b0b08831297e95c9d6ae357c5a519c8844d57a016afb1c4a953ca962e21de71761bfa5888c369361e80a93c3d70c90490dc345399144dc635e6b4eceb9bc09200bb1f805174efd779321741b1b287246e04d260c63529", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510705674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x950c77b394c6b2993cce5158497c32d8c921d748"}, {name: "deposit", type: "uint256", value: "8000000000000000"}, {name: "hash", type: "bytes32", value: "0x8b749c5c86be232762d8733ecdbf1c13d1eb02e5a3f6822d62b05df525ec8eda"}, {name: "message", type: "bytes", value: "0x8d3a00ac0d9cd56d78f60fdacdd2256442a1863f430ac64ec05d046631184a32b941c3080ceca95694ddc9ce5b5e192848e37e88c321ecef95edb1e00425ec36c5a0b4ab8f9421f682728aff2110193e0c55af361144229d5555c7e9ae74bda9c8e7a56e5becd99cc1c909f287a7a729b8b829df6357b6a16367bef90b9463a06d7a0db485ec1426f09469758a2a86da34353bed3f10ac2e0d7084ffb15fd7a596198abe166f71572c5b0b08831297e95c9d6ae357c5a519c8844d57a016afb1c4a953ca962e21de71761bfa5888c369361e80a93c3d70c90490dc345399144dc635e6b4eceb9bc09200bb1f805174efd779321741b1b287246e04d260c63529"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0xdad3e7fafc4039febb4b8aa76972f071073a... )", async function( ) {
		const txOriginal = {blockNumber: "4554152", blockHash: "0x791d93c0f6fd2b7152536811a41a5b92a62c9025f8a06a542239fe3dd83d3ea3", timeStamp: "1510706017", hash: "0xdf8ce5724743a09bee4b034577d1e88d934b89a8956fe5b02d6e231716ccc920", nonce: "1", transactionIndex: "52", from: "0x3794c5e109ff82e9d1eff80e16011f2633f1510d", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "6000000000000000", gas: "200000", gasPrice: "10000000000", input: "0x25ede147dad3e7fafc4039febb4b8aa76972f071073ab30e32d73315b7d8c199d20ca633000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001008dbd10ac1c380ab38e6eb5c1e6815c2b448674e73d0e14ae066df7bb2e58c6472c53bdb132f30b8b7056ace73ffd6bdfcb315e04860fe0205a52ce1442bcf53446731a2cb465b4b2f6fb6ea9e9d2055913335c76ddc8ba8f50151b54f60ab7bfd4a927d19674e85bf31acba3f0288068a2304c9b0b0b71ef5ea811efa19a8d89909e4696b45762ab2ab2c81c9518c6d56d6cfb14790b0ae62fe3ad404dc5ec147bcbbfa84125806697c08416d8b92ac8f1aa9e4feb5f177f1ecb0596df9560d0e50cbc81e955e60408b74211c79062990798d79a4756a50726b4bdf4b6630e8bfda85502c65b9201a3160fe02cbd36c68e8bcea6f5368b821168a8aceef7800a", contractAddress: "", cumulativeGasUsed: "1868371", txreceipt_status: "1", gasUsed: "93883", confirmations: "3185078", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "6000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0xdad3e7fafc4039febb4b8aa76972f071073ab30e32d73315b7d8c199d20ca633"}, {type: "bytes", name: "_message", value: "0x8dbd10ac1c380ab38e6eb5c1e6815c2b448674e73d0e14ae066df7bb2e58c6472c53bdb132f30b8b7056ace73ffd6bdfcb315e04860fe0205a52ce1442bcf53446731a2cb465b4b2f6fb6ea9e9d2055913335c76ddc8ba8f50151b54f60ab7bfd4a927d19674e85bf31acba3f0288068a2304c9b0b0b71ef5ea811efa19a8d89909e4696b45762ab2ab2c81c9518c6d56d6cfb14790b0ae62fe3ad404dc5ec147bcbbfa84125806697c08416d8b92ac8f1aa9e4feb5f177f1ecb0596df9560d0e50cbc81e955e60408b74211c79062990798d79a4756a50726b4bdf4b6630e8bfda85502c65b9201a3160fe02cbd36c68e8bcea6f5368b821168a8aceef7800a"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0xdad3e7fafc4039febb4b8aa76972f071073ab30e32d73315b7d8c199d20ca633", "0x8dbd10ac1c380ab38e6eb5c1e6815c2b448674e73d0e14ae066df7bb2e58c6472c53bdb132f30b8b7056ace73ffd6bdfcb315e04860fe0205a52ce1442bcf53446731a2cb465b4b2f6fb6ea9e9d2055913335c76ddc8ba8f50151b54f60ab7bfd4a927d19674e85bf31acba3f0288068a2304c9b0b0b71ef5ea811efa19a8d89909e4696b45762ab2ab2c81c9518c6d56d6cfb14790b0ae62fe3ad404dc5ec147bcbbfa84125806697c08416d8b92ac8f1aa9e4feb5f177f1ecb0596df9560d0e50cbc81e955e60408b74211c79062990798d79a4756a50726b4bdf4b6630e8bfda85502c65b9201a3160fe02cbd36c68e8bcea6f5368b821168a8aceef7800a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510706017 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x3794c5e109ff82e9d1eff80e16011f2633f1510d"}, {name: "deposit", type: "uint256", value: "6000000000000000"}, {name: "hash", type: "bytes32", value: "0xdad3e7fafc4039febb4b8aa76972f071073ab30e32d73315b7d8c199d20ca633"}, {name: "message", type: "bytes", value: "0x8dbd10ac1c380ab38e6eb5c1e6815c2b448674e73d0e14ae066df7bb2e58c6472c53bdb132f30b8b7056ace73ffd6bdfcb315e04860fe0205a52ce1442bcf53446731a2cb465b4b2f6fb6ea9e9d2055913335c76ddc8ba8f50151b54f60ab7bfd4a927d19674e85bf31acba3f0288068a2304c9b0b0b71ef5ea811efa19a8d89909e4696b45762ab2ab2c81c9518c6d56d6cfb14790b0ae62fe3ad404dc5ec147bcbbfa84125806697c08416d8b92ac8f1aa9e4feb5f177f1ecb0596df9560d0e50cbc81e955e60408b74211c79062990798d79a4756a50726b4bdf4b6630e8bfda85502c65b9201a3160fe02cbd36c68e8bcea6f5368b821168a8aceef7800a"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0x22591581275d97570b818f399ee0dca3f0fe... )", async function( ) {
		const txOriginal = {blockNumber: "4554176", blockHash: "0x058ed0d87b3bced25fd662856556821b1447d4251211793dd9c4d1fbb2aeb5ce", timeStamp: "1510706314", hash: "0xbbef91c1e09778a34d1b275ecdc1738fa6b0e80913be49a4a43ed23378332118", nonce: "1", transactionIndex: "23", from: "0x4016c7363d466f9df59ae70fca88bb82826cacf0", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "4500000000000000", gas: "200000", gasPrice: "10000000000", input: "0x25ede14722591581275d97570b818f399ee0dca3f0fed96bd6a26bf425fbfbdfd6829927000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001005593feff96942b4d80513c934e08862044f463923b463b419f28e550a392c613c473fe0beaea4ca0f45adab21047b18e652b6c525933520bcc3064e471cafb93e26e50b9917a1bb511c93775e7c8047c8a6a5c39aeffcf905aaf614e6db7c912574be0535b7c832d9d117ec32e171f0e6c0a3977a4789ae3d8e532577986fc447901b3a11c8822e036c85d098fc5dfa7032225ff953ce5c1989ba60adafa2071bf93512892321597a22e04f8582511ffe686d0c26725cb05508041690dc00898dade6a9acc31241a9797164ec0daf229ce9d5480524bdd63f84a6f2218f8e0a8f16d1f3199b19db6e51b64005e828839b9b533b13617c54998b83acd5cf60d16", contractAddress: "", cumulativeGasUsed: "1350429", txreceipt_status: "1", gasUsed: "93819", confirmations: "3185054", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "4500000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0x22591581275d97570b818f399ee0dca3f0fed96bd6a26bf425fbfbdfd6829927"}, {type: "bytes", name: "_message", value: "0x5593feff96942b4d80513c934e08862044f463923b463b419f28e550a392c613c473fe0beaea4ca0f45adab21047b18e652b6c525933520bcc3064e471cafb93e26e50b9917a1bb511c93775e7c8047c8a6a5c39aeffcf905aaf614e6db7c912574be0535b7c832d9d117ec32e171f0e6c0a3977a4789ae3d8e532577986fc447901b3a11c8822e036c85d098fc5dfa7032225ff953ce5c1989ba60adafa2071bf93512892321597a22e04f8582511ffe686d0c26725cb05508041690dc00898dade6a9acc31241a9797164ec0daf229ce9d5480524bdd63f84a6f2218f8e0a8f16d1f3199b19db6e51b64005e828839b9b533b13617c54998b83acd5cf60d16"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0x22591581275d97570b818f399ee0dca3f0fed96bd6a26bf425fbfbdfd6829927", "0x5593feff96942b4d80513c934e08862044f463923b463b419f28e550a392c613c473fe0beaea4ca0f45adab21047b18e652b6c525933520bcc3064e471cafb93e26e50b9917a1bb511c93775e7c8047c8a6a5c39aeffcf905aaf614e6db7c912574be0535b7c832d9d117ec32e171f0e6c0a3977a4789ae3d8e532577986fc447901b3a11c8822e036c85d098fc5dfa7032225ff953ce5c1989ba60adafa2071bf93512892321597a22e04f8582511ffe686d0c26725cb05508041690dc00898dade6a9acc31241a9797164ec0daf229ce9d5480524bdd63f84a6f2218f8e0a8f16d1f3199b19db6e51b64005e828839b9b533b13617c54998b83acd5cf60d16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510706314 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x4016c7363d466f9df59ae70fca88bb82826cacf0"}, {name: "deposit", type: "uint256", value: "4500000000000000"}, {name: "hash", type: "bytes32", value: "0x22591581275d97570b818f399ee0dca3f0fed96bd6a26bf425fbfbdfd6829927"}, {name: "message", type: "bytes", value: "0x5593feff96942b4d80513c934e08862044f463923b463b419f28e550a392c613c473fe0beaea4ca0f45adab21047b18e652b6c525933520bcc3064e471cafb93e26e50b9917a1bb511c93775e7c8047c8a6a5c39aeffcf905aaf614e6db7c912574be0535b7c832d9d117ec32e171f0e6c0a3977a4789ae3d8e532577986fc447901b3a11c8822e036c85d098fc5dfa7032225ff953ce5c1989ba60adafa2071bf93512892321597a22e04f8582511ffe686d0c26725cb05508041690dc00898dade6a9acc31241a9797164ec0daf229ce9d5480524bdd63f84a6f2218f8e0a8f16d1f3199b19db6e51b64005e828839b9b533b13617c54998b83acd5cf60d16"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0x159cf70695ce8e5d571b73288ad7b1da4c0e... )", async function( ) {
		const txOriginal = {blockNumber: "4554242", blockHash: "0xf2a5c1c3c8ca9a2ee75737fdb6697dbdea2aad4c517259226501e411f9ca6334", timeStamp: "1510707185", hash: "0xe8cf6fdfd524ee58f826fa696a09f2c8371d6c0b9d341b9d3fda63a5cc3ab61a", nonce: "0", transactionIndex: "70", from: "0x26a46318376e68601a98a9b3e2afe02c057a071e", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "2500000000000000", gas: "200000", gasPrice: "20000000000", input: "0x25ede147159cf70695ce8e5d571b73288ad7b1da4c0e6d15fb7ed8402696ab006cae910000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000100a37d9c7934c663a8837978df327a44490faf411d2e7bb185ca70e6e29fa7891fa2e23740dcd2cec481b20ab365d0f8a7692daa5dd8ad9fe2c8bed9d4b27a59e0d5998450cf05978afde99972fbe972f5e5e1a3f4a1aae01dc0fdec8e27450cd142dd9665d196a103f860670576dc70e24feb05c490e27ada75bebc75cc0f489086d101dd8ff379ea5994527e5940723a9d897689a66ff80a21f325874e25a0247ca7ad6001765909c0f11768006665908cbc374a0bb06868b9e0e7f3db77999235ecdb566ac65b4ed41308840f023dfeba4b306c54bf20ab2e502af9d7aff6bc330683f9e014f7b2b31ab4047059a6ca543fa3a230e888746a0d39236a0e1741", contractAddress: "", cumulativeGasUsed: "3319222", txreceipt_status: "1", gasUsed: "93691", confirmations: "3184988", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "2500000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0x159cf70695ce8e5d571b73288ad7b1da4c0e6d15fb7ed8402696ab006cae9100"}, {type: "bytes", name: "_message", value: "0xa37d9c7934c663a8837978df327a44490faf411d2e7bb185ca70e6e29fa7891fa2e23740dcd2cec481b20ab365d0f8a7692daa5dd8ad9fe2c8bed9d4b27a59e0d5998450cf05978afde99972fbe972f5e5e1a3f4a1aae01dc0fdec8e27450cd142dd9665d196a103f860670576dc70e24feb05c490e27ada75bebc75cc0f489086d101dd8ff379ea5994527e5940723a9d897689a66ff80a21f325874e25a0247ca7ad6001765909c0f11768006665908cbc374a0bb06868b9e0e7f3db77999235ecdb566ac65b4ed41308840f023dfeba4b306c54bf20ab2e502af9d7aff6bc330683f9e014f7b2b31ab4047059a6ca543fa3a230e888746a0d39236a0e1741"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0x159cf70695ce8e5d571b73288ad7b1da4c0e6d15fb7ed8402696ab006cae9100", "0xa37d9c7934c663a8837978df327a44490faf411d2e7bb185ca70e6e29fa7891fa2e23740dcd2cec481b20ab365d0f8a7692daa5dd8ad9fe2c8bed9d4b27a59e0d5998450cf05978afde99972fbe972f5e5e1a3f4a1aae01dc0fdec8e27450cd142dd9665d196a103f860670576dc70e24feb05c490e27ada75bebc75cc0f489086d101dd8ff379ea5994527e5940723a9d897689a66ff80a21f325874e25a0247ca7ad6001765909c0f11768006665908cbc374a0bb06868b9e0e7f3db77999235ecdb566ac65b4ed41308840f023dfeba4b306c54bf20ab2e502af9d7aff6bc330683f9e014f7b2b31ab4047059a6ca543fa3a230e888746a0d39236a0e1741", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510707185 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x26a46318376e68601a98a9b3e2afe02c057a071e"}, {name: "deposit", type: "uint256", value: "2500000000000000"}, {name: "hash", type: "bytes32", value: "0x159cf70695ce8e5d571b73288ad7b1da4c0e6d15fb7ed8402696ab006cae9100"}, {name: "message", type: "bytes", value: "0xa37d9c7934c663a8837978df327a44490faf411d2e7bb185ca70e6e29fa7891fa2e23740dcd2cec481b20ab365d0f8a7692daa5dd8ad9fe2c8bed9d4b27a59e0d5998450cf05978afde99972fbe972f5e5e1a3f4a1aae01dc0fdec8e27450cd142dd9665d196a103f860670576dc70e24feb05c490e27ada75bebc75cc0f489086d101dd8ff379ea5994527e5940723a9d897689a66ff80a21f325874e25a0247ca7ad6001765909c0f11768006665908cbc374a0bb06868b9e0e7f3db77999235ecdb566ac65b4ed41308840f023dfeba4b306c54bf20ab2e502af9d7aff6bc330683f9e014f7b2b31ab4047059a6ca543fa3a230e888746a0d39236a0e1741"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0x1456ffc81dc5184a3fc0d6c88eaa80112e5d... )", async function( ) {
		const txOriginal = {blockNumber: "4554311", blockHash: "0x85226db2cc234473f858acc18878b430cc80a5677f8764521f7426f3f6326398", timeStamp: "1510707966", hash: "0x89c9db6047e6e5a5c26ea631953ce77a4d70f556f42e06e746217110b560984c", nonce: "0", transactionIndex: "27", from: "0xf48ae436e4813c7dcd5cdeb305131d07ca022469", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "5000000000000000", gas: "93755", gasPrice: "19000000000", input: "0x25ede1471456ffc81dc5184a3fc0d6c88eaa80112e5d455b2347e408126d4a79df67c0c20000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000010075fb66e655d9dab59b570165159b23aec0872ec96afdc5a6dc940b177efb5500cc58a6b16b1fa2f109be292143fb5adc63277dcaa4b56a28021c02c73e32c1663903ad231007679564d0041e616fa79e056688588c98e31bb05cdfa0f2148be6a3057e22b009173899c457d84e39b41a43149eb003d65abb8f200533e894aced46e9191f57a80477c4c9cc075bbbb1d34326f858d69653d568b76f1eed3bc91058926d94521bb2f23f279e81bc23b3f3123bb23d67abb7c3e0465dd442ffba27ffb2bfb90015922570af8cff8174b698280556b976b9db0379d10baafd593e9791be8fec722b87e575b0272322f5e05e2f196a4016aec7d0a81e52d176eeb527", contractAddress: "", cumulativeGasUsed: "1069610", txreceipt_status: "1", gasUsed: "93755", confirmations: "3184919", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0x1456ffc81dc5184a3fc0d6c88eaa80112e5d455b2347e408126d4a79df67c0c2"}, {type: "bytes", name: "_message", value: "0x75fb66e655d9dab59b570165159b23aec0872ec96afdc5a6dc940b177efb5500cc58a6b16b1fa2f109be292143fb5adc63277dcaa4b56a28021c02c73e32c1663903ad231007679564d0041e616fa79e056688588c98e31bb05cdfa0f2148be6a3057e22b009173899c457d84e39b41a43149eb003d65abb8f200533e894aced46e9191f57a80477c4c9cc075bbbb1d34326f858d69653d568b76f1eed3bc91058926d94521bb2f23f279e81bc23b3f3123bb23d67abb7c3e0465dd442ffba27ffb2bfb90015922570af8cff8174b698280556b976b9db0379d10baafd593e9791be8fec722b87e575b0272322f5e05e2f196a4016aec7d0a81e52d176eeb527"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0x1456ffc81dc5184a3fc0d6c88eaa80112e5d455b2347e408126d4a79df67c0c2", "0x75fb66e655d9dab59b570165159b23aec0872ec96afdc5a6dc940b177efb5500cc58a6b16b1fa2f109be292143fb5adc63277dcaa4b56a28021c02c73e32c1663903ad231007679564d0041e616fa79e056688588c98e31bb05cdfa0f2148be6a3057e22b009173899c457d84e39b41a43149eb003d65abb8f200533e894aced46e9191f57a80477c4c9cc075bbbb1d34326f858d69653d568b76f1eed3bc91058926d94521bb2f23f279e81bc23b3f3123bb23d67abb7c3e0465dd442ffba27ffb2bfb90015922570af8cff8174b698280556b976b9db0379d10baafd593e9791be8fec722b87e575b0272322f5e05e2f196a4016aec7d0a81e52d176eeb527", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510707966 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "deposit", type: "uint256"}, {indexed: false, name: "hash", type: "bytes32"}, {indexed: false, name: "message", type: "bytes"}], name: "SecretBidEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SecretBidEvent", events: [{name: "batch", type: "uint256", value: "2"}, {name: "bidder", type: "address", value: "0xf48ae436e4813c7dcd5cdeb305131d07ca022469"}, {name: "deposit", type: "uint256", value: "5000000000000000"}, {name: "hash", type: "bytes32", value: "0x1456ffc81dc5184a3fc0d6c88eaa80112e5d455b2347e408126d4a79df67c0c2"}, {name: "message", type: "bytes", value: "0x75fb66e655d9dab59b570165159b23aec0872ec96afdc5a6dc940b177efb5500cc58a6b16b1fa2f109be292143fb5adc63277dcaa4b56a28021c02c73e32c1663903ad231007679564d0041e616fa79e056688588c98e31bb05cdfa0f2148be6a3057e22b009173899c457d84e39b41a43149eb003d65abb8f200533e894aced46e9191f57a80477c4c9cc075bbbb1d34326f858d69653d568b76f1eed3bc91058926d94521bb2f23f279e81bc23b3f3123bb23d67abb7c3e0465dd442ffba27ffb2bfb90015922570af8cff8174b698280556b976b9db0379d10baafd593e9791be8fec722b87e575b0272322f5e05e2f196a4016aec7d0a81e52d176eeb527"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: houseKeep(  )", async function( ) {
		const txOriginal = {blockNumber: "4554339", blockHash: "0x611f05596d060d10fbb27f105dc7cc193c83f146a4a54aadafc3d778a7d510e9", timeStamp: "1510708391", hash: "0x79f9694036c8e50a5a863a1cc41d7d9e3dcf7107e07994c60824bbe57568fa94", nonce: "2098", transactionIndex: "13", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "34816", gasPrice: "19000000000", input: "0xda00586b", contractAddress: "", cumulativeGasUsed: "307816", txreceipt_status: "1", gasUsed: "34816", confirmations: "3184891", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "houseKeep", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "houseKeep()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510708391 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "mask", type: "uint256"}], name: "StateChangeEvent", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StateChangeEvent", events: [{name: "mask", type: "uint256", value: "3"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setStrikePrice( \"0\", \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "4555402", blockHash: "0xb8bf24939372a00c5d5e44121a9e9c6596500a2579d6a89ce33f30de1674154d", timeStamp: "1510723074", hash: "0xe06e0530457e091a7444db105702c2e378d0d2c89a679a3d0cd3b210dba592f0", nonce: "2099", transactionIndex: "23", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "79895", gasPrice: "19000000000", input: "0x8d52a1fc000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1144475", txreceipt_status: "1", gasUsed: "79895", confirmations: "3183828", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_strikePrice", value: "0"}, {type: "uint256", name: "_strikePricePctX10", value: "1000"}], name: "setStrikePrice", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStrikePrice(uint256,uint256)" ]( "0", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510723074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setStrikePrice( \"1500000000000000\", \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "4555413", blockHash: "0x1cab97ca559467293f6e8077dbc9854d48eac86eb09da2b327d4be544cfd4d58", timeStamp: "1510723218", hash: "0xc14e8bb58a02bda105d2ad96fccc492f548257e300cf98f0f5de70a7d6780672", nonce: "2100", transactionIndex: "68", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "71968", gasPrice: "19000000000", input: "0x8d52a1fc0000000000000000000000000000000000000000000000000005543df729c00000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1961690", txreceipt_status: "1", gasUsed: "71968", confirmations: "3183817", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_strikePrice", value: "1500000000000000"}, {type: "uint256", name: "_strikePricePctX10", value: "1000"}], name: "setStrikePrice", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStrikePrice(uint256,uint256)" ]( "1500000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510723218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "mask", type: "uint256"}], name: "StateChangeEvent", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StateChangeEvent", events: [{name: "mask", type: "uint256", value: "7"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"3472336220512727353\", \"2\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4555421", blockHash: "0x961408748288c296284168a864abff051d29790143614161b0666fe6245046e1", timeStamp: "1510723345", hash: "0x15d16b8b3db1c994360494c2e8780b5c716fb4db6fdd6549c1cdf3ece1f6c77a", nonce: "1", transactionIndex: "8", from: "0xf48ae436e4813c7dcd5cdeb305131d07ca022469", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000303037653462313900000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "249055", txreceipt_status: "1", gasUsed: "57994", confirmations: "3183809", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "3472336220512727353"}, {type: "uint256", name: "_price", value: "2"}, {type: "uint256", name: "_quantity", value: "1"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "3472336220512727353", "2", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510723345 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "0"}, {name: "bidder", type: "address", value: "0xf48ae436e4813c7dcd5cdeb305131d07ca022469"}, {name: "cost", type: "uint256", value: "0"}, {name: "refund", type: "uint256", value: "5000000000000000"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555427", blockHash: "0xf33b25e620f8ed2c12077387e7c4d6d2844eefc14f4992915c1b33674995b21b", timeStamp: "1510723386", hash: "0xd234dc636e859292d2d34fc2c5e89700c557ad2e30d8d6d044f60a45dd3a2826", nonce: "2", transactionIndex: "38", from: "0xf48ae436e4813c7dcd5cdeb305131d07ca022469", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "962063", txreceipt_status: "1", gasUsed: "19410", confirmations: "3183803", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510723386 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"7005125338332553776\", \"2500\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4555441", blockHash: "0xfd8c882a3bfcaa57b07aaac80b7af276f002e2b243f6417c6b626757109b4335", timeStamp: "1510723582", hash: "0x8c09ffe0879deedc7e83d89927f159aac0478cdc3ca618c699a607717df4c5a1", nonce: "1", transactionIndex: "62", from: "0x26a46318376e68601a98a9b3e2afe02c057a071e", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "12000000000", input: "0x02f65096000000000000000000000000000000000000000000000000613734616666623000000000000000000000000000000000000000000000000000000000000009c40000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2464653", txreceipt_status: "1", gasUsed: "145299", confirmations: "3183789", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "7005125338332553776"}, {type: "uint256", name: "_price", value: "2500"}, {type: "uint256", name: "_quantity", value: "1"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "7005125338332553776", "2500", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510723582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "0"}, {name: "bidder", type: "address", value: "0x26a46318376e68601a98a9b3e2afe02c057a071e"}, {name: "cost", type: "uint256", value: "1500000000000000"}, {name: "refund", type: "uint256", value: "1000000000000000"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555443", blockHash: "0xc68630c603f069494ef5c544cd3f1dffa2f5ed2a59d54a6b0b35d02a04f8860d", timeStamp: "1510723600", hash: "0x4578c9edfc606764e511ad516e62994bfef0047c2ab2ef03eaff885b7dfe3276", nonce: "2", transactionIndex: "55", from: "0x26a46318376e68601a98a9b3e2afe02c057a071e", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "12000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "1277079", txreceipt_status: "1", gasUsed: "19410", confirmations: "3183787", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510723600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"7075209097636308272\", \"1500\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4555470", blockHash: "0xee7a4caa2712abad6bd403e2b6a4a224d70e3e71f8df9e4f6495992f5155cd85", timeStamp: "1510724000", hash: "0x7dfd3be23132c902122f9f92a0f0adafdf1660616cb7150841dfc6d699d0a0cc", nonce: "2", transactionIndex: "32", from: "0x4016c7363d466f9df59ae70fca88bb82826cacf0", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "15000000000", input: "0x02f65096000000000000000000000000000000000000000000000000623031303039653000000000000000000000000000000000000000000000000000000000000005dc0000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1056739", txreceipt_status: "1", gasUsed: "90081", confirmations: "3183760", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "7075209097636308272"}, {type: "uint256", name: "_price", value: "1500"}, {type: "uint256", name: "_quantity", value: "3"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "7075209097636308272", "1500", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510724000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "0"}, {name: "bidder", type: "address", value: "0x4016c7363d466f9df59ae70fca88bb82826cacf0"}, {name: "cost", type: "uint256", value: "4500000000000000"}, {name: "refund", type: "uint256", value: "0"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555474", blockHash: "0xb8153087cd21ff21a273f3d066091e6d1561e9c8d8642e33f8196ab7a32bb07c", timeStamp: "1510724038", hash: "0x78c9cd3063f1aaf16c0383977a13680e916d10b76ac41a134a942d59282304f7", nonce: "3", transactionIndex: "35", from: "0x4016c7363d466f9df59ae70fca88bb82826cacf0", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "15000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "988539", txreceipt_status: "1", gasUsed: "27710", confirmations: "3183756", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510724038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"7076901276098913587\", \"1\", \"6000\" )", async function( ) {
		const txOriginal = {blockNumber: "4555503", blockHash: "0x4aa5b840841df66a0cc58b860ee43722c6f718be768129758e2c55fa49e693f2", timeStamp: "1510724446", hash: "0xe3d9af014e6de47b068f5da7aa3a5f4416a7fa78740117a0abcaa6c72cc4c1e1", nonce: "2", transactionIndex: "60", from: "0x3794c5e109ff82e9d1eff80e16011f2633f1510d", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000623634373062653300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000001770", contractAddress: "", cumulativeGasUsed: "1610876", txreceipt_status: "1", gasUsed: "43058", confirmations: "3183727", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "7076901276098913587"}, {type: "uint256", name: "_price", value: "1"}, {type: "uint256", name: "_quantity", value: "6000"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "7076901276098913587", "1", "6000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510724446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x3794c5e109ff82e9d1eff80e16011f2633f1510d"}, {name: "cost", type: "uint256", value: "0"}, {name: "refund", type: "uint256", value: "6000000000000000"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555506", blockHash: "0x3a38be6e616827b92b23e685c4585847fd5eacd76e86c4043bd80cc3a6cd6064", timeStamp: "1510724467", hash: "0xa63067dc17099dc4de64f02b1de029abe0bb70dcd50f0c5f89faef6fecfe1544", nonce: "3", transactionIndex: "30", from: "0x3794c5e109ff82e9d1eff80e16011f2633f1510d", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "1168872", txreceipt_status: "1", gasUsed: "19410", confirmations: "3183724", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510724467 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"3703474455322256994\", \"2000\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4555523", blockHash: "0xcf7f51fffe13a867e09c3097fa38d92e892cf5ee9a4380468f2298a56a136b99", timeStamp: "1510724710", hash: "0xc0cd6055bd4e37e2f6a4df0efae2e02314c2d233bad55ab68816e69f8339825c", nonce: "12", transactionIndex: "106", from: "0x950c77b394c6b2993cce5158497c32d8c921d748", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000336562653037666200000000000000000000000000000000000000000000000000000000000007d00000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "3038807", txreceipt_status: "1", gasUsed: "115299", confirmations: "3183707", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "3703474455322256994"}, {type: "uint256", name: "_price", value: "2000"}, {type: "uint256", name: "_quantity", value: "4"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "3703474455322256994", "2000", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510724710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x950c77b394c6b2993cce5158497c32d8c921d748"}, {name: "cost", type: "uint256", value: "6000000000000000"}, {name: "refund", type: "uint256", value: "2000000000000000"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555529", blockHash: "0xe3e77b26eb69c30d7443e81946de4f9d0b5dd4cd5ff6c89cf85d7f009ff5c9a3", timeStamp: "1510724781", hash: "0x49fe2402e7147d97d6b0e3d9a76e20ed7596215e6eb2605ce7669cebf6b0e4b0", nonce: "13", transactionIndex: "38", from: "0x950c77b394c6b2993cce5158497c32d8c921d748", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "1244693", txreceipt_status: "1", gasUsed: "19410", confirmations: "3183701", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510724781 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"4121186606480712801\", \"2000\", \"400... )", async function( ) {
		const txOriginal = {blockNumber: "4555544", blockHash: "0x96c3c0750916701e59f55a10474251ea623dc706ec19df42ddb8db1de7a940c8", timeStamp: "1510725013", hash: "0x12b48d6696ccd7005540d42cfcfcc304d0d98520b64f1dbb0dd71aefa951ff5e", nonce: "9", transactionIndex: "74", from: "0x5252013df34cfb6e4faa0df41049049304403698", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000393165623461646100000000000000000000000000000000000000000000000000000000000007d00000000000000000000000000000000000000000000000000000000000000190", contractAddress: "", cumulativeGasUsed: "4947302", txreceipt_status: "0", gasUsed: "23704", confirmations: "3183686", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "4121186606480712801"}, {type: "uint256", name: "_price", value: "2000"}, {type: "uint256", name: "_quantity", value: "400"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "4121186606480712801", "2000", "400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510725013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"4121186606480712801\", \"2000\", \"23\... )", async function( ) {
		const txOriginal = {blockNumber: "4555585", blockHash: "0x13aab975c8a5c02d5a1b302ccbbd3cd3c9779665772d34cca3f415cc885323d8", timeStamp: "1510725505", hash: "0xba0d7e122631ffdeedceb83613fa16057c5486ff2bdeafbdd1ab9b071fe622bf", nonce: "10", transactionIndex: "11", from: "0x5252013df34cfb6e4faa0df41049049304403698", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000393165623461646100000000000000000000000000000000000000000000000000000000000007d00000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "461005", txreceipt_status: "0", gasUsed: "23640", confirmations: "3183645", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "4121186606480712801"}, {type: "uint256", name: "_price", value: "2000"}, {type: "uint256", name: "_quantity", value: "23"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "4121186606480712801", "2000", "23", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510725505 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"4121186606480712801\", \"2000\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4555592", blockHash: "0x94ad5a817bc7d46b80a519031eb909479424d666a5e2723ec55e0c0bbd2c36bc", timeStamp: "1510725639", hash: "0x301dd396020cd20f25d907ab1435000a2840c98c4ad2dc4c690aa34ec0b494ff", nonce: "11", transactionIndex: "16", from: "0x5252013df34cfb6e4faa0df41049049304403698", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000393165623461646100000000000000000000000000000000000000000000000000000000000007d00000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1152677", txreceipt_status: "1", gasUsed: "115299", confirmations: "3183638", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "4121186606480712801"}, {type: "uint256", name: "_price", value: "2000"}, {type: "uint256", name: "_quantity", value: "2"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "4121186606480712801", "2000", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510725639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x5252013df34cfb6e4faa0df41049049304403698"}, {name: "cost", type: "uint256", value: "3000000000000000"}, {name: "refund", type: "uint256", value: "1000000000000000"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555596", blockHash: "0xf61feaa5c15ed9585968034eaf5e27cac52e069e243ee0f02900f373d048c76f", timeStamp: "1510725717", hash: "0xa950c81ca11e8537fb5127ea330551856215ac63def96d719309832b67fdd066", nonce: "12", transactionIndex: "171", from: "0x5252013df34cfb6e4faa0df41049049304403698", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "4623180", txreceipt_status: "1", gasUsed: "19410", confirmations: "3183634", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510725717 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"3617571793703811429\", \"1\", \"10000\... )", async function( ) {
		const txOriginal = {blockNumber: "4555618", blockHash: "0xc54e88d75efdad9c6c94d978c507f9c711a73c211bab559cadd12ba7fe8fe837", timeStamp: "1510726004", hash: "0x2db91de87cbe036c3826198b7ba7fbbc0399b0cb0a38136da31221da2d149702", nonce: "8", transactionIndex: "24", from: "0x79b2b9047f5ee28029033f10e8811816eff28901", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000323432613130396500000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "767170", txreceipt_status: "1", gasUsed: "43058", confirmations: "3183612", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "3617571793703811429"}, {type: "uint256", name: "_price", value: "1"}, {type: "uint256", name: "_quantity", value: "10000"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "3617571793703811429", "1", "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510726004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "1"}, {name: "bidder", type: "address", value: "0x79b2b9047f5ee28029033f10e8811816eff28901"}, {name: "cost", type: "uint256", value: "0"}, {name: "refund", type: "uint256", value: "10000000000000000"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555621", blockHash: "0x6b2881e0f3401be78d285a5fb7f6407901506928972ed20b3e27de7b565b45b3", timeStamp: "1510726028", hash: "0xf228eff6b83e307af08a9b7275c56e6c1e0a32071590f4313b6df57ae5afa29f", nonce: "9", transactionIndex: "30", from: "0x79b2b9047f5ee28029033f10e8811816eff28901", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "972851", txreceipt_status: "1", gasUsed: "19410", confirmations: "3183609", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510726028 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: executeBid( \"3832906748846433335\", \"5000\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4555628", blockHash: "0x8852b8dade747f088d6fc26cd2368e76ce0e5b8c7cf632516730dca7d9e3e48a", timeStamp: "1510726126", hash: "0xab74890dca965457bc6cfa977bb9fa4f73f5303f6fb1c3f461f53d41574e6a66", nonce: "15", transactionIndex: "62", from: "0xb569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x02f65096000000000000000000000000000000000000000000000000353138616630643700000000000000000000000000000000000000000000000000000000000013880000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2114970", txreceipt_status: "1", gasUsed: "115299", confirmations: "3183602", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_secret", value: "3832906748846433335"}, {type: "uint256", name: "_price", value: "5000"}, {type: "uint256", name: "_quantity", value: "1"}], name: "executeBid", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeBid(uint256,uint256,uint256)" ]( "3832906748846433335", "5000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510726126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "batch", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: false, name: "cost", type: "uint256"}, {indexed: false, name: "refund", type: "uint256"}], name: "ExecuteEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ExecuteEvent", events: [{name: "batch", type: "uint256", value: "2"}, {name: "bidder", type: "address", value: "0xb569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e"}, {name: "cost", type: "uint256", value: "1500000000000000"}, {name: "refund", type: "uint256", value: "3500000000000000"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawRefund(  )", async function( ) {
		const txOriginal = {blockNumber: "4555633", blockHash: "0x6efc25aa74be256613ce3c549fc94db72aa65cb12afad82838be1694fae4ccf2", timeStamp: "1510726189", hash: "0x26db142329dacc90794cd5580e800f982f9c7e7dad8ff6fc967cb32d1a7ab340", nonce: "16", transactionIndex: "34", from: "0xb569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "200000", gasPrice: "20000000000", input: "0x110f8874", contractAddress: "", cumulativeGasUsed: "4184025", txreceipt_status: "1", gasUsed: "19410", confirmations: "3183597", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawRefund", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawRefund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510726189 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: houseKeep(  )", async function( ) {
		const txOriginal = {blockNumber: "4555669", blockHash: "0xe0031f97d7a9ae33f53db6626548235055852a40f782168da36cdcee45b852f4", timeStamp: "1510726721", hash: "0x357cd2aa87f11641340a3a34160587a8be72a6a21fc2a6edb151f60029fc1a77", nonce: "2101", transactionIndex: "6", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "38999", gasPrice: "19000000000", input: "0xda00586b", contractAddress: "", cumulativeGasUsed: "184961", txreceipt_status: "1", gasUsed: "38999", confirmations: "3183561", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "houseKeep", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "houseKeep()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510726721 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: payUnderwriter(  )", async function( ) {
		const txOriginal = {blockNumber: "4555700", blockHash: "0x52ebfcdb8690449bc41f87b4afafb8911653cc11f38751e228fea0153ad7e77a", timeStamp: "1510727278", hash: "0x556a651c6db2309b776901dea00ade7e13562a8810b08dd58df16259e18f63cf", nonce: "2102", transactionIndex: "44", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "42429", gasPrice: "19000000000", input: "0x4bd9d76c", contractAddress: "", cumulativeGasUsed: "1930564", txreceipt_status: "1", gasUsed: "27394", confirmations: "3183530", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "payUnderwriter", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payUnderwriter()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510727278 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: houseKeep(  )", async function( ) {
		const txOriginal = {blockNumber: "4555730", blockHash: "0xd18f117f3342709327236ebee28d761720c2ce45d0a0bd56a7a25dc011193064", timeStamp: "1510727625", hash: "0x04850c1142cfd1aa0445138eeb31a86ec83691b25bbc01bddc94fc900cd2b2e9", nonce: "2103", transactionIndex: "45", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "45467", gasPrice: "19000000000", input: "0xda00586b", contractAddress: "", cumulativeGasUsed: "1375449", txreceipt_status: "1", gasUsed: "45467", confirmations: "3183500", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "houseKeep", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "houseKeep()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510727625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "mask", type: "uint256"}], name: "StateChangeEvent", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StateChangeEvent", events: [{name: "mask", type: "uint256", value: "15"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: doDeveloperGrant(  )", async function( ) {
		const txOriginal = {blockNumber: "4555738", blockHash: "0x31dc51ed62a283dd39ae77c3203f8c0e748573d1887c5db8a9abeeae8c00c27b", timeStamp: "1510727712", hash: "0x526f7c5d4d103b81e078784579585b5c2dd1bd98b3f403a814ad144d0f2b0088", nonce: "2104", transactionIndex: "40", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "71788", gasPrice: "19000000000", input: "0x4c182a95", contractAddress: "", cumulativeGasUsed: "1514662", txreceipt_status: "1", gasUsed: "56617", confirmations: "3183492", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "doDeveloperGrant", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "doDeveloperGrant()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510727712 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setAuctionParms( \"1510959738\", \"3600\", \"3600\" )", async function( ) {
		const txOriginal = {blockNumber: "4572388", blockHash: "0xcad585a4e28228ab82d6ce4445127f62a55e54ed6fcd5fcdd4a1cbe99d41c32a", timeStamp: "1510959493", hash: "0xcf5f92d31e852cf0e97156313bc33f4cd627afc0296c057d30b824c9ec09b5d1", nonce: "2150", transactionIndex: "31", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "54065", gasPrice: "19000000000", input: "0x2134927e000000000000000000000000000000000000000000000000000000005a0f6a7a0000000000000000000000000000000000000000000000000000000000000e100000000000000000000000000000000000000000000000000000000000000e10", contractAddress: "", cumulativeGasUsed: "988656", txreceipt_status: "1", gasUsed: "27033", confirmations: "3166842", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_auctionStart", value: "1510959738"}, {type: "uint256", name: "_auctionDuration", value: "3600"}, {type: "uint256", name: "_saleDuration", value: "3600"}], name: "setAuctionParms", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAuctionParms(uint256,uint256,uint256)" ]( "1510959738", "3600", "3600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510959493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setToken( addressList[15], \"1000\", addressList[3... )", async function( ) {
		const txOriginal = {blockNumber: "4572401", blockHash: "0x52c2c7fa0f83f8f55c9a03f8fa723db6959e242e2d53ebf4030bcc845123c2a6", timeStamp: "1510959635", hash: "0x26e0c16fa8eebbfd56e1df2cd29fe22a9273440bc54cf94522a35f6bc4cdecb1", nonce: "2151", transactionIndex: "15", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "41407", gasPrice: "19000000000", input: "0xe6c5201600000000000000000000000006b9737a7a625478fe5a65bf4bff4390ff6ace9600000000000000000000000000000000000000000000000000000000000003e80000000000000000000000008b8a571730b631f58e7965d78582eae1b0417ab6", contractAddress: "", cumulativeGasUsed: "368657", txreceipt_status: "1", gasUsed: "41407", confirmations: "3166829", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[15]}, {type: "uint256", name: "_decimalMultiplier", value: "1000"}, {type: "address", name: "_underwriter", value: addressList[3]}], name: "setToken", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setToken(address,uint256,address)" ]( addressList[15], "1000", addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510959635 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setToken( addressList[15], \"1000\", addressList[5... )", async function( ) {
		const txOriginal = {blockNumber: "4572403", blockHash: "0xb6ca86d98a9524f9c45e94694fc5156ba444311f04a1bcd1befd25ea108dfaf7", timeStamp: "1510959706", hash: "0x285e89aefed9400a520dc688276239d6c252997904a35b9d265de830bc244fd7", nonce: "2152", transactionIndex: "78", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "41407", gasPrice: "19000000000", input: "0xe6c5201600000000000000000000000006b9737a7a625478fe5a65bf4bff4390ff6ace9600000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000eb4245c88c660ae4ee23c76954e5490ccd7bbd82", contractAddress: "", cumulativeGasUsed: "2312691", txreceipt_status: "1", gasUsed: "41407", confirmations: "3166827", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[15]}, {type: "uint256", name: "_decimalMultiplier", value: "1000"}, {type: "address", name: "_underwriter", value: addressList[5]}], name: "setToken", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setToken(address,uint256,address)" ]( addressList[15], "1000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510959706 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: reserveDeveloperTokens( addressList[6], \"333333\" )", async function( ) {
		const txOriginal = {blockNumber: "4572418", blockHash: "0xf812e0c41383aab94ba508630224f34be2a1b199a3ff2e6266f7bcc529185e4f", timeStamp: "1510959978", hash: "0x7df11e52742c3c7344a445d42a8f1b8ab671fae35c54b4fbb93adfb3663754fc", nonce: "2153", transactionIndex: "88", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "42355", gasPrice: "19000000000", input: "0x1f6c76f40000000000000000000000009a2f50977426c1226f037b1887dd7c0205092e0a0000000000000000000000000000000000000000000000000000000000051615", contractAddress: "", cumulativeGasUsed: "3078780", txreceipt_status: "1", gasUsed: "42355", confirmations: "3166812", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_developers", value: addressList[6]}, {type: "uint256", name: "_developerPctX10K", value: "333333"}], name: "reserveDeveloperTokens", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reserveDeveloperTokens(address,uint256)" ]( addressList[6], "333333", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510959978 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: houseKeep(  )", async function( ) {
		const txOriginal = {blockNumber: "4572432", blockHash: "0x5be81de10990bbfb2be841257a4f59a10a1a791559d6d86d278244bf7999a4ea", timeStamp: "1510960208", hash: "0xc74ac5218f5ea977bcb454d5f92821c43c64911170c498c672b6ee4ac0807134", nonce: "2154", transactionIndex: "15", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "44373", gasPrice: "19000000000", input: "0xda00586b", contractAddress: "", cumulativeGasUsed: "401826", txreceipt_status: "1", gasUsed: "44373", confirmations: "3166798", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "houseKeep", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "houseKeep()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510960208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "mask", type: "uint256"}], name: "StateChangeEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StateChangeEvent", events: [{name: "mask", type: "uint256", value: "1"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: depositSecretBid( \"0x41c567220ca78d4e8b02f530d1cf262926d0... )", async function( ) {
		const txOriginal = {blockNumber: "4572725", blockHash: "0xb3cc6c8559bed39f3e416d20a90ca1bf7f15595916419d9dcf103436177a1aba", timeStamp: "1510964489", hash: "0xbac5ebbe7ec571970458be64f9a65d973f9d234f78e3a977ea6070e7aeec5aa6", nonce: "17", transactionIndex: "10", from: "0xb569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "1000000000000000000", gas: "200000", gasPrice: "20000000000", input: "0x25ede14741c567220ca78d4e8b02f530d1cf262926d0b4df49382c6a6f55082eabc5d6c60000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000010094b100ba3e70aa38f03f208b7a382e4b7d55a63aebc305bcac9d37c14c4d62ae8528d61f7ba42632f77333fde1f6d24c4626b000c4a28bb37c56762ebc84b96c329da86a033b38e4cb0762b8f2c0f355a56e014787fe55a09098d1abe4c491f08ac514618575af37f5796dd0b7d357de58b272f3c7e84e336340418f32c826df79484eb4fab624a9b250e98f5a31dde26071c33973b932c1eb509e03964bb0c410f29e11b53bcf0f31180a36e3c3e35c36a4768f5180017a73c0fc3d8ee1b32c546d2d4d1285a53e3e50c28082c3be9bfdc3221b4b5a4126a26967a594a7fb1f289a4ee6d646c8806c628047e8d548928b92245d9f22a158e17e726122f93107", contractAddress: "", cumulativeGasUsed: "270953", txreceipt_status: "0", gasUsed: "42638", confirmations: "3166505", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_hash", value: "0x41c567220ca78d4e8b02f530d1cf262926d0b4df49382c6a6f55082eabc5d6c6"}, {type: "bytes", name: "_message", value: "0x94b100ba3e70aa38f03f208b7a382e4b7d55a63aebc305bcac9d37c14c4d62ae8528d61f7ba42632f77333fde1f6d24c4626b000c4a28bb37c56762ebc84b96c329da86a033b38e4cb0762b8f2c0f355a56e014787fe55a09098d1abe4c491f08ac514618575af37f5796dd0b7d357de58b272f3c7e84e336340418f32c826df79484eb4fab624a9b250e98f5a31dde26071c33973b932c1eb509e03964bb0c410f29e11b53bcf0f31180a36e3c3e35c36a4768f5180017a73c0fc3d8ee1b32c546d2d4d1285a53e3e50c28082c3be9bfdc3221b4b5a4126a26967a594a7fb1f289a4ee6d646c8806c628047e8d548928b92245d9f22a158e17e726122f93107"}], name: "depositSecretBid", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositSecretBid(bytes32,bytes)" ]( "0x41c567220ca78d4e8b02f530d1cf262926d0b4df49382c6a6f55082eabc5d6c6", "0x94b100ba3e70aa38f03f208b7a382e4b7d55a63aebc305bcac9d37c14c4d62ae8528d61f7ba42632f77333fde1f6d24c4626b000c4a28bb37c56762ebc84b96c329da86a033b38e4cb0762b8f2c0f355a56e014787fe55a09098d1abe4c491f08ac514618575af37f5796dd0b7d357de58b272f3c7e84e336340418f32c826df79484eb4fab624a9b250e98f5a31dde26071c33973b932c1eb509e03964bb0c410f29e11b53bcf0f31180a36e3c3e35c36a4768f5180017a73c0fc3d8ee1b32c546d2d4d1285a53e3e50c28082c3be9bfdc3221b4b5a4126a26967a594a7fb1f289a4ee6d646c8806c628047e8d548928b92245d9f22a158e17e726122f93107", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510964489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4574646", blockHash: "0xa8db9f444d1f6d1ff15ff443c3d92cc0d20a943569aaf98d3c0062024b98a062", timeStamp: "1510991880", hash: "0xcdbbeb3bd76647f504f7519ae60073961772bd948ea1155b3bd98b183ed8dee6", nonce: "2155", transactionIndex: "98", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "50000", gasPrice: "4000000000", input: "0xbfd272dd000000000000000000000000b569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", contractAddress: "", cumulativeGasUsed: "3347795", txreceipt_status: "1", gasUsed: "31241", confirmations: "3164584", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510991880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "message", type: "string"}, {indexed: false, name: "val", type: "uint256"}], name: "BizarreEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BizarreEvent", events: [{name: "addr", type: "address", value: "0x8b8a571730b631f58e7965d78582eae1b0417ab6"}, {name: "message", type: "string", value: "bizarre payment"}, {name: "val", type: "uint256", value: "0"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4574661", blockHash: "0x4df5a9db45f6b6a565ff0d7d147779550f506eee28bf4678dfd4e038099646d5", timeStamp: "1510992126", hash: "0x38b5b7ae16994ed71410be76ed578043ef23427b24ecfbbf2daf63863cab4026", nonce: "2156", transactionIndex: "15", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "50000", gasPrice: "5568750000", input: "0xbfd272dd000000000000000000000000b569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", contractAddress: "", cumulativeGasUsed: "387595", txreceipt_status: "1", gasUsed: "31241", confirmations: "3164569", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510992126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "message", type: "string"}, {indexed: false, name: "val", type: "uint256"}], name: "BizarreEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BizarreEvent", events: [{name: "addr", type: "address", value: "0x8b8a571730b631f58e7965d78582eae1b0417ab6"}, {name: "message", type: "string", value: "bizarre payment"}, {name: "val", type: "uint256", value: "0"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4574681", blockHash: "0xe568c8a6dc2100a0151c792a86523a5afc72b28bbb1df6e1b41a318f256bca7f", timeStamp: "1510992412", hash: "0x1db5fbdc0242c271d1a79e204e7648356b5d9d0c523ddd5845de89882efffedb", nonce: "2157", transactionIndex: "99", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "50000", gasPrice: "8000000000", input: "0xbfd272dd000000000000000000000000b569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", contractAddress: "", cumulativeGasUsed: "3474779", txreceipt_status: "1", gasUsed: "31241", confirmations: "3164549", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510992412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "message", type: "string"}, {indexed: false, name: "val", type: "uint256"}], name: "BizarreEvent", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BizarreEvent", events: [{name: "addr", type: "address", value: "0x8b8a571730b631f58e7965d78582eae1b0417ab6"}, {name: "message", type: "string", value: "bizarre payment"}, {name: "val", type: "uint256", value: "0"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4574684", blockHash: "0x68734d44312e94a75c5f0cf3d629452b3f8f85ebaf7fef7d7fb20dd587ee2997", timeStamp: "1510992465", hash: "0x1040830a237ab9bd34b364be44a5b2e2ea9ad7511c1116e929986bb06d499308", nonce: "2158", transactionIndex: "88", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "50000", gasPrice: "8000000000", input: "0xbfd272dd000000000000000000000000b569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", contractAddress: "", cumulativeGasUsed: "2642439", txreceipt_status: "1", gasUsed: "31241", confirmations: "3164546", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510992465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "message", type: "string"}, {indexed: false, name: "val", type: "uint256"}], name: "BizarreEvent", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BizarreEvent", events: [{name: "addr", type: "address", value: "0x8b8a571730b631f58e7965d78582eae1b0417ab6"}, {name: "message", type: "string", value: "bizarre payment"}, {name: "val", type: "uint256", value: "0"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4574687", blockHash: "0x72525d0b8c046d74e1b1b2f5dfc9dabfc9bb63824bf755eca8cc5bbf940235ab", timeStamp: "1510992554", hash: "0x8257eb2b780c306f329aa94ba0b2429cb2fc0043ab5fd937e8384c677e94d6b8", nonce: "2159", transactionIndex: "164", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "50000", gasPrice: "8000000000", input: "0xbfd272dd000000000000000000000000b569db9407a7ca3f0b73090d1dc7fe2f4e5ba26e", contractAddress: "", cumulativeGasUsed: "6422513", txreceipt_status: "1", gasUsed: "31241", confirmations: "3164543", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510992554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "message", type: "string"}, {indexed: false, name: "val", type: "uint256"}], name: "BizarreEvent", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BizarreEvent", events: [{name: "addr", type: "address", value: "0x8b8a571730b631f58e7965d78582eae1b0417ab6"}, {name: "message", type: "string", value: "bizarre payment"}, {name: "val", type: "uint256", value: "0"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4574688", blockHash: "0x283bb8719699e2bd587f060d200118a56b8935188b7e8c0d44d02b68f8f1a537", timeStamp: "1510992576", hash: "0x4fe395d5b65782e63468b690c1b6d86d1013f9c6a5ddf1e730106750469902cf", nonce: "2160", transactionIndex: "21", from: "0x8b8a571730b631f58e7965d78582eae1b0417ab6", to: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e", value: "0", gas: "50000", gasPrice: "8000000000", input: "0xbfd272dd00000000000000000000000079b2b9047f5ee28029033f10e8811816eff28901", contractAddress: "", cumulativeGasUsed: "489823", txreceipt_status: "1", gasUsed: "31241", confirmations: "3164542", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510992576 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "message", type: "string"}, {indexed: false, name: "val", type: "uint256"}], name: "BizarreEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BizarreEvent", events: [{name: "addr", type: "address", value: "0x8b8a571730b631f58e7965d78582eae1b0417ab6"}, {name: "message", type: "string", value: "bizarre payment"}, {name: "val", type: "uint256", value: "0"}], address: "0xad4c4ff144e42c73b6333b75af3cee5af901c10e"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
