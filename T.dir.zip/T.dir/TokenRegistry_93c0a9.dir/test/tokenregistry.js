const TokenRegistry = artifacts.require( "./TokenRegistry.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TokenRegistry" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xd79396AB3bFAaa0d9F6d11f95bb641601d93c0a9", "0xD4915e172a195f5F3e343A4196E8bdA3Fc94Aee8", "0xE94327D07Fc17907b4DB788E5aDf2ed424adDff6", "0xE41d2489571d322189246DaFA5ebDe1F4699F498", "0x89d24A6b4CcB1B6fAA2625fE562bDD9a23260359", "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", "0x86Fa049857E0209aa7D9e616F7eb3b3B78ECfdb0", "0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2", "0xB8c77482e45F1F44dE1745F52C74426C631bDD52", "0xb5A5F22694352C15B00323844aD545ABb2B11028", "0xf230b790E05390FC8295F4d3F60332c93BEd42e2", "0xD850942eF8811f2A866692A623011bDE52a462C1", "0xd26114cd6EE289AccF82350c8d8487fedB8A0C07", "0xE0B7927c4aF23765Cb51314A0E0521A9645F0E2A", "0xcB97e65F07DA24D46BcDD078EBebd7C6E6E3d750", "0x05f4a42e251f2d52b8ed15E9FEdAacFcEF1FAD27", "0x168296bb09e24A88805CB9c33356536B980D3fC5", "0x744d70FDBE2Ba4CF95131626614a1763DF805B9E", "0x5CA9a71B1d01849C0a95490Cc00559717fCF0D1d", "0xFA1a856Cfa3409CFa145Fa4e20Eb270dF3EB21ab", "0x4CEdA7906a5Ed2179785Cd3A40A69ee8bc99C466", "0xEF68e7C694F40c8202821eDF525dE3782458639f", "0xb7cB1C96dB6B22b0D3d9536E0108d062BD488F74", "0xa74476443119A942dE498590Fe1f2454d7D4aC0d", "0xbf2179859fc6D5BEE9Bf9158632Dc51678a4100e", "0x0D8775F648430679A709E98d2b0Cb6250d2887EF", "0x8f3470A7388c05eE4e7AF3d01D8C722b0FF52374", "0x1122B6a0E00DCe0563082b6e2953f3A943855c1F", "0x618E75Ac90b12c6049Ba3b27f5d5F8651b0037F6", "0x419c4dB4B9e25d6Db2AD9691ccb832C8D9fDA05E", "0x5d65D971895Edc438f465c17DB6992698a52318D", "0x5Af2Be193a6ABCa9c8817001F45744777Db30756", "0x12480E24eb5bec1a9D4369CaB6a80caD3c0A377A", "0x419D0d8BdD9aF5e606Ae2232ed285Aff190E711b", "0xdd974D5C2e2928deA5F71b9825b8b646686BD200", "0x48f775EFBE4F5EcE6e0DF2f7b5932dF56823B990", "0x4156D3342D5c385a87D264F90653733592000581", "0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C", "0x809826cceAb68c387726af962713b64Cb5Cb3CCA", "0x514910771AF9Ca656af840dff83E8264EcF986CA", "0x595832F8FC6BF59c85C527fEC3740A1b7a361269", "0xD0a4b8946Cb52f0661273bfbC6fD0E0C75Fc6433", "0x8f8221aFbB33998d8584A2B05749bA73c37a938a", "0x39Bb259F66E1C59d5ABEF88375979b4D20D98022", "0xB64ef51C888972c908CFacf59B47C1AfBC0Ab8aC", "0xB97048628DB6B661D4C2aA833e95Dbe1A905B280", "0xf0Ee6b27b759C9893Ce4f094b49ad28fd15A23e4", "0xe25bCec5D3801cE3a794079BF94adF1B8cCD802D", "0x08d32b0da63e2C3bcF8019c9c5d849d7a9d791e6", "0x3597bfD533a99c9aa083587B074434E61Eb0A258", "0xD0352a019e9AB9d757776F532377aAEbd36Fd541"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_index", type: "uint256"}], name: "getTokenAttributesByIndex", outputs: [{name: "", type: "address"}, {name: "", type: "string"}, {name: "", type: "string"}, {name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_symbol", type: "string"}], name: "getTokenIndexBySymbol", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_symbol", type: "string"}], name: "getTokenAddressBySymbol", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "symbolHashToTokenAttributes", outputs: [{name: "tokenAddress", type: "address"}, {name: "tokenIndex", type: "uint256"}, {name: "name", type: "string"}, {name: "numDecimals", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "getTokenAddressByIndex", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "getTokenSymbolByIndex", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_symbol", type: "string"}], name: "getTokenAttributesBySymbol", outputs: [{name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "string"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_symbol", type: "string"}], name: "getNumDecimalsFromSymbol", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "getNumDecimalsByIndex", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tokenSymbolList", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_symbol", type: "string"}], name: "getTokenNameBySymbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenSymbolListLength", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "getTokenNameByIndex", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 5655955 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 5655970 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "TokenRegistry", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "getTokenAttributesByIndex", outputs: [{name: "", type: "address"}, {name: "", type: "string"}, {name: "", type: "string"}, {name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenAttributesByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_symbol", value: random.string( maxRandom )}], name: "getTokenIndexBySymbol", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenIndexBySymbol(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_symbol", value: random.string( maxRandom )}], name: "getTokenAddressBySymbol", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenAddressBySymbol(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "symbolHashToTokenAttributes", outputs: [{name: "tokenAddress", type: "address"}, {name: "tokenIndex", type: "uint256"}, {name: "name", type: "string"}, {name: "numDecimals", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbolHashToTokenAttributes(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "getTokenAddressByIndex", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenAddressByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "getTokenSymbolByIndex", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenSymbolByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_symbol", value: random.string( maxRandom )}], name: "getTokenAttributesBySymbol", outputs: [{name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "string"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenAttributesBySymbol(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_symbol", value: random.string( maxRandom )}], name: "getNumDecimalsFromSymbol", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNumDecimalsFromSymbol(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "getNumDecimalsByIndex", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNumDecimalsByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tokenSymbolList", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenSymbolList(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_symbol", value: random.string( maxRandom )}], name: "getTokenNameBySymbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenNameBySymbol(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenSymbolListLength", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenSymbolListLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "getTokenNameByIndex", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenNameByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TokenRegistry", function( accounts ) {

	it( "TEST: TokenRegistry(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "5655955", timeStamp: "1526968646", hash: "0xd3adc6b90214e471d4f5462462c5080eb62a3a9ada2ae154e83889c8278735c6", nonce: "68", blockHash: "0x95cfc1f0280b1e22828382b7fe460392e7d2486e0b543523442ad273cb393a16", transactionIndex: "7", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: 0, value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x5c043480", contractAddress: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", cumulativeGasUsed: "2202045", gasUsed: "1936720", confirmations: "2026127"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "TokenRegistry", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TokenRegistry.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1526968646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TokenRegistry.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `REP`, addressList[4], `Augur REP`, \"18... )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xc628ebe3d18be9d6189c192b90afb4f0492d8880d09bbe48347cee4428e3cf39", nonce: "69", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "40", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff600000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003524550000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000094175677572205245500000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1291032", gasUsed: "135657", confirmations: "2026124"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `REP`}, {type: "address", name: "_tokenAddress", value: addressList[4]}, {type: "string", name: "_tokenName", value: `Augur REP`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `REP`, addressList[4], `Augur REP`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `ZRX`, addressList[5], `ZRX`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xd21e2b18f30f7902cbdd2cb812061e2654affc82c2405de53bf03ceb51282771", nonce: "70", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "41", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f49800000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000035a5258000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035a52580000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1426305", gasUsed: "135273", confirmations: "2026124"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `ZRX`}, {type: "address", name: "_tokenAddress", value: addressList[5]}, {type: "string", name: "_tokenName", value: `ZRX`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `ZRX`, addressList[5], `ZRX`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `DAI`, addressList[6], `Dai Stablecoin`,... )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xf44b7ba5ed01dd3b0787863ac833796795b794120ad820b8431a9f2309c4c8a1", nonce: "71", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "42", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034441490000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e44616920537461626c65636f696e000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1562282", gasUsed: "135977", confirmations: "2026124"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `DAI`}, {type: "address", name: "_tokenAddress", value: addressList[6]}, {type: "string", name: "_tokenName", value: `Dai Stablecoin`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `DAI`, addressList[6], `Dai Stablecoin`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `WETH`, addressList[7], `Canonical Wrapp... )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xf4c0a1d64f092f38e9427ec8ba8cc3508dadb5085e3603e77bf257087c5fd676", nonce: "72", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "43", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000045745544800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001743616e6f6e6963616c2057726170706564204574686572000000000000000000", contractAddress: "", cumulativeGasUsed: "1698899", gasUsed: "136617", confirmations: "2026124"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `WETH`}, {type: "address", name: "_tokenAddress", value: addressList[7]}, {type: "string", name: "_tokenName", value: `Canonical Wrapped Ether`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `WETH`, addressList[7], `Canonical Wrapped Ether`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `EOS`, addressList[8], `EOS`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xda53795a4dfa230e3e564f3352242d79746a3a577da8a84c204ff45ad6f49a45", nonce: "73", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "44", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000086fa049857e0209aa7d9e616f7eb3b3b78ecfdb000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003454f5300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003454f530000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1834172", gasUsed: "135273", confirmations: "2026124"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `EOS`}, {type: "address", name: "_tokenAddress", value: addressList[8]}, {type: "string", name: "_tokenName", value: `EOS`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `EOS`, addressList[8], `EOS`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `MKR`, addressList[9], `Maker Dao`, \"18... )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0x650ea837e6b39673157aa76e08b65374f64ca2d0a653cb8ab3009f6d7122fd1c", nonce: "74", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "45", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a200000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034d4b52000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000094d616b65722044616f0000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1969829", gasUsed: "135657", confirmations: "2026124"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `MKR`}, {type: "address", name: "_tokenAddress", value: addressList[9]}, {type: "string", name: "_tokenName", value: `Maker Dao`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `MKR`, addressList[9], `Maker Dao`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `BNB`, addressList[10], `BNB`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xaebcfd5ea929090d91727b2cede87434b0911e0ffeed3319a07f1166f9ebdf28", nonce: "75", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "46", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000b8c77482e45f1f44de1745f52c74426c631bdd5200000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003424e4200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003424e420000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2105102", gasUsed: "135273", confirmations: "2026124"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `BNB`}, {type: "address", name: "_tokenAddress", value: addressList[10]}, {type: "string", name: "_tokenName", value: `BNB`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `BNB`, addressList[10], `BNB`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `ICX`, addressList[11], `ICON`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xdea11dd49554f0aab231068a5aac738621fd03112910ec737c96e4a0989c35f3", nonce: "76", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "47", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000b5a5f22694352c15b00323844ad545abb2b1102800000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034943580000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000449434f4e00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2240439", gasUsed: "135337", confirmations: "2026124"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `ICX`}, {type: "address", name: "_tokenAddress", value: addressList[11]}, {type: "string", name: "_tokenName", value: `ICON`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `ICX`, addressList[11], `ICON`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `TRX`, addressList[12], `Tronix`, \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0x2cc782bd1547660feb9bb9c30dc58bf9b53c399208e0dab620f91f69664ded79", nonce: "77", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "48", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000f230b790e05390fc8295f4d3f60332c93bed42e200000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000035452580000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000654726f6e69780000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2375904", gasUsed: "135465", confirmations: "2026124"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `TRX`}, {type: "address", name: "_tokenAddress", value: addressList[12]}, {type: "string", name: "_tokenName", value: `Tronix`}, {type: "uint8", name: "_numDecimals", value: "6"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `TRX`, addressList[12], `Tronix`, "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `VEN`, addressList[13], `VeChain`, \"18\... )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xf1e7804a82b8ee8021db7c8cee5b85eb7c1647f1b533313901ee881e562fbde2", nonce: "78", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "49", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000d850942ef8811f2a866692a623011bde52a462c100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000356454e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000075665436861696e00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2511433", gasUsed: "135529", confirmations: "2026124"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `VEN`}, {type: "address", name: "_tokenAddress", value: addressList[13]}, {type: "string", name: "_tokenName", value: `VeChain`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `VEN`, addressList[13], `VeChain`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `OMG`, addressList[14], `OmiseGO`, \"18\... )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0x021718e2ed4cd9b1af189407ea0bb10c968f712168cfd1e501a873fac4293e86", nonce: "79", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "50", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c0700000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034f4d47000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000074f6d697365474f00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2646962", gasUsed: "135529", confirmations: "2026124"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `OMG`}, {type: "address", name: "_tokenAddress", value: addressList[14]}, {type: "string", name: "_tokenName", value: `OmiseGO`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `OMG`, addressList[14], `OmiseGO`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `DGD`, addressList[15], `DGD`, \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xb05ca617d5274c505214fcf555b621ebc5521604ace03ba428be16f970f4f09e", nonce: "80", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "51", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000e0b7927c4af23765cb51314a0e0521a9645f0e2a00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000003444744000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034447440000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2782235", gasUsed: "135273", confirmations: "2026124"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `DGD`}, {type: "address", name: "_tokenAddress", value: addressList[15]}, {type: "string", name: "_tokenName", value: `DGD`}, {type: "uint8", name: "_numDecimals", value: "9"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `DGD`, addressList[15], `DGD`, "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `BTM`, addressList[16], `Bytom`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0x83625873f50322a2f0c5d5350e0416bfdb17eae54f51a8ab0fb1d18d86b47f0c", nonce: "81", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "52", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000cb97e65f07da24d46bcdd078ebebd7c6e6e3d75000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000342544d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000054279746f6d000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2917636", gasUsed: "135401", confirmations: "2026124"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `BTM`}, {type: "address", name: "_tokenAddress", value: addressList[16]}, {type: "string", name: "_tokenName", value: `Bytom`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `BTM`, addressList[16], `Bytom`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `ZIL`, addressList[17], `Zilliqa`, \"12\... )", async function( ) {
		const txOriginal = {blockNumber: "5655958", timeStamp: "1526968692", hash: "0xd3166f9e6fdf45b2f9dab25af6e876b21b0a36707b4066d967b06b24ff5053d1", nonce: "82", blockHash: "0x3c2136cdee561cc8f68afb23c11fd0a4454aad7c731374fe2eb52addc3f0f2b7", transactionIndex: "53", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000005f4a42e251f2d52b8ed15e9fedaacfcef1fad2700000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000035a494c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000075a696c6c69716100000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3053165", gasUsed: "135529", confirmations: "2026124"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `ZIL`}, {type: "address", name: "_tokenAddress", value: addressList[17]}, {type: "string", name: "_tokenName", value: `Zilliqa`}, {type: "uint8", name: "_numDecimals", value: "12"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `ZIL`, addressList[17], `Zilliqa`, "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1526968692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `RHOC`, addressList[18], `RHOC`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655959", timeStamp: "1526968695", hash: "0xd3e85d784c994ab57dfc99034a36a0a567c1a855cd30dd959e681198fd8d6e14", nonce: "83", blockHash: "0x73748a754e2e1695d6a47c4af2a3c2e539fe7f7f6b1d1773d36b8661d14a885b", transactionIndex: "9", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000168296bb09e24a88805cb9c33356536b980d3fc500000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000452484f4300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000452484f4300000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "439986", gasUsed: "135401", confirmations: "2026123"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `RHOC`}, {type: "address", name: "_tokenAddress", value: addressList[18]}, {type: "string", name: "_tokenName", value: `RHOC`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `RHOC`, addressList[18], `RHOC`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1526968695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `SNT`, addressList[19], `StatusNetwork`,... )", async function( ) {
		const txOriginal = {blockNumber: "5655960", timeStamp: "1526968711", hash: "0x001a93c18a9cd1c5848b25b68309a3d7781f4a23665cd4116ce0890f003637e4", nonce: "84", blockHash: "0x77e0e10ec90f37e337755f12e0709555c0a23fe72a2c6417b2fd247d99d6ff80", transactionIndex: "11", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003534e540000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d5374617475734e6574776f726b00000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "674819", gasUsed: "135913", confirmations: "2026122"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `SNT`}, {type: "address", name: "_tokenAddress", value: addressList[19]}, {type: "string", name: "_tokenName", value: `StatusNetwork`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `SNT`, addressList[19], `StatusNetwork`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1526968711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `AE`, addressList[20], `Aeternity`, \"18... )", async function( ) {
		const txOriginal = {blockNumber: "5655962", timeStamp: "1526968747", hash: "0x3f6a9a4c89a3c2a4e9e7255809dbfa1d4035940e48268a77dfac7611f3b5d3ab", nonce: "85", blockHash: "0xf04a6d337bff2585568b518903c97b4f19791eaec3c79b0c7a5ba3905c28ced9", transactionIndex: "11", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000005ca9a71b1d01849c0a95490cc00559717fcf0d1d00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000024145000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000941657465726e6974790000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "433098", gasUsed: "135593", confirmations: "2026120"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `AE`}, {type: "address", name: "_tokenAddress", value: addressList[20]}, {type: "string", name: "_tokenName", value: `Aeternity`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `AE`, addressList[20], `Aeternity`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1526968747 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `IOST`, addressList[21], `IOSToken`, \"1... )", async function( ) {
		const txOriginal = {blockNumber: "5655963", timeStamp: "1526968770", hash: "0xee012ff4ba4f0d60f2a911dde0b4fbd288f2186599b069bdf4ec03dc56093bce", nonce: "86", blockHash: "0x12b915ace6b68efb1d7c0b891009f6514cc2b8abfd913fad947e38f438b44f0b", transactionIndex: "29", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000fa1a856cfa3409cfa145fa4e20eb270df3eb21ab00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000004494f5354000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008494f53546f6b656e000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "988395", gasUsed: "135657", confirmations: "2026119"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `IOST`}, {type: "address", name: "_tokenAddress", value: addressList[21]}, {type: "string", name: "_tokenName", value: `IOSToken`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `IOST`, addressList[21], `IOSToken`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1526968770 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `AION`, addressList[22], `AION`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655968", timeStamp: "1526968863", hash: "0x5aaa33eb15dcd4c4f12f39f3e7b133f0acad8a8dc98ae1520214d1f5474e1953", nonce: "87", blockHash: "0xbc1b47857a91bb112069a6948f8ddb018c2c71e5ca206e228c8efb69ca1efee4", transactionIndex: "2", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000004ceda7906a5ed2179785cd3a40a69ee8bc99c46600000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000441494f4e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000441494f4e00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "228034", gasUsed: "135401", confirmations: "2026114"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `AION`}, {type: "address", name: "_tokenAddress", value: addressList[22]}, {type: "string", name: "_tokenName", value: `AION`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `AION`, addressList[22], `AION`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1526968863 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `LRC`, addressList[23], `Loopring`, \"18... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x1440cf1928f2f60dce529a0c3acb8516085d98b4e4cdf4193ea11f990ab75230", nonce: "88", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "25", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000ef68e7c694f40c8202821edf525de3782458639f00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034c5243000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000084c6f6f7072696e67000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1049614", gasUsed: "135593", confirmations: "2026113"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `LRC`}, {type: "address", name: "_tokenAddress", value: addressList[23]}, {type: "string", name: "_tokenName", value: `Loopring`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `LRC`, addressList[23], `Loopring`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `WTC`, addressList[24], `Walton`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x4decf07dd7f43182255396cda4638165d85d6d94fc9e59e81e5976125d43f5a2", nonce: "89", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "26", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000b7cb1c96db6b22b0d3d9536e0108d062bd488f7400000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000035754430000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000657616c746f6e0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1185079", gasUsed: "135465", confirmations: "2026113"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `WTC`}, {type: "address", name: "_tokenAddress", value: addressList[24]}, {type: "string", name: "_tokenName", value: `Walton`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `WTC`, addressList[24], `Walton`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `GNT`, addressList[25], `Golem`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xc286aa1bb8a555a0d516096e4cb4e8b448ab2364d048bc22bbb56506ec21271e", nonce: "90", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "27", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000a74476443119a942de498590fe1f2454d7d4ac0d00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003474e5400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005476f6c656d000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1320480", gasUsed: "135401", confirmations: "2026113"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `GNT`}, {type: "address", name: "_tokenAddress", value: addressList[25]}, {type: "string", name: "_tokenName", value: `Golem`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `GNT`, addressList[25], `Golem`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `ELF`, addressList[26], `ELF`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x5fb0f609fbe2f21a851b8709b11fb72cd60aba065de2efbfff2933a6c061d20f", nonce: "91", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "28", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000bf2179859fc6d5bee9bf9158632dc51678a4100e00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003454c4600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003454c460000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1455753", gasUsed: "135273", confirmations: "2026113"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `ELF`}, {type: "address", name: "_tokenAddress", value: addressList[26]}, {type: "string", name: "_tokenName", value: `ELF`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `ELF`, addressList[26], `ELF`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `BAT`, addressList[27], `BAT`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x4b2fd1a8cc9872d328822fe08355e4e8929394f94944abaaeee26f21800381ff", nonce: "92", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "29", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003424154000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034241540000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1591026", gasUsed: "135273", confirmations: "2026113"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `BAT`}, {type: "address", name: "_tokenAddress", value: addressList[27]}, {type: "string", name: "_tokenName", value: `BAT`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `BAT`, addressList[27], `BAT`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `VERI`, addressList[28], `Veritaseum`, \... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xff8b42e626d601f7c2ddf47b357f981996fd119c40f0ce9b43f0f2bb97c0735c", nonce: "93", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "30", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000008f3470a7388c05ee4e7af3d01d8c722b0ff5237400000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000045645524900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a5665726974617365756d00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1726811", gasUsed: "135785", confirmations: "2026113"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `VERI`}, {type: "address", name: "_tokenAddress", value: addressList[28]}, {type: "string", name: "_tokenName", value: `Veritaseum`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `VERI`, addressList[28], `Veritaseum`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `CENNZ`, addressList[29], `Centrality To... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xd5e81ec72b3b9fd648d78532ee3e237764524ae22f4beb85666789dd5ba9e7f3", nonce: "94", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "31", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000001122b6a0e00dce0563082b6e2953f3a943855c1f00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000543454e4e5a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001043656e7472616c69747920546f6b656e00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1863044", gasUsed: "136233", confirmations: "2026113"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `CENNZ`}, {type: "address", name: "_tokenAddress", value: addressList[29]}, {type: "string", name: "_tokenName", value: `Centrality Token`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `CENNZ`, addressList[29], `Centrality Token`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `QASH`, addressList[30], `QASH`, \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x35dbee8da2602fa860ac9b989fcb29af1055bf897cb2bbf792b58918b85960d7", nonce: "95", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "32", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000618e75ac90b12c6049ba3b27f5d5f8651b0037f600000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004514153480000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000045141534800000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1998381", gasUsed: "135337", confirmations: "2026113"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `QASH`}, {type: "address", name: "_tokenAddress", value: addressList[30]}, {type: "string", name: "_tokenName", value: `QASH`}, {type: "uint8", name: "_numDecimals", value: "6"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `QASH`, addressList[30], `QASH`, "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `DRGN`, addressList[31], `Dragon`, \"18\... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x2eea8ab10176f0805670e1f31b9674b37b124a6442f18ea444c2fa0e6c6c2efb", nonce: "96", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "33", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000419c4db4b9e25d6db2ad9691ccb832c8d9fda05e00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000044452474e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006447261676f6e0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2133910", gasUsed: "135529", confirmations: "2026113"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `DRGN`}, {type: "address", name: "_tokenAddress", value: addressList[31]}, {type: "string", name: "_tokenName", value: `Dragon`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `DRGN`, addressList[31], `Dragon`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `NAS`, addressList[32], `Nebulas`, \"18\... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xd96f18c8a6726119a2068ac123484c79d64a7fedecbe28a79fea95bfd4b0e17b", nonce: "97", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "34", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000005d65d971895edc438f465c17db6992698a52318d00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034e4153000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000074e6562756c617300000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2269439", gasUsed: "135529", confirmations: "2026113"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `NAS`}, {type: "address", name: "_tokenAddress", value: addressList[32]}, {type: "string", name: "_tokenName", value: `Nebulas`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `NAS`, addressList[32], `Nebulas`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `ETHOS`, addressList[33], `Ethos`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x032f02392a7bbd03eca7983c33f357dac83cb3f48b3d4fd26964e27efcb83daa", nonce: "98", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "35", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000005af2be193a6abca9c8817001f45744777db3075600000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000054554484f5300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000054574686f73000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2404968", gasUsed: "135529", confirmations: "2026113"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `ETHOS`}, {type: "address", name: "_tokenAddress", value: addressList[33]}, {type: "string", name: "_tokenName", value: `Ethos`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `ETHOS`, addressList[33], `Ethos`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `SUB`, addressList[34], `Substratum`, \"... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xdb41202fe7f7f7fac467815f33ba7e95ba58604b7d99926cf0940491f086564d", nonce: "99", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "36", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000012480e24eb5bec1a9d4369cab6a80cad3c0a377a00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000035355420000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a5375627374726174756d00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2540689", gasUsed: "135721", confirmations: "2026113"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `SUB`}, {type: "address", name: "_tokenAddress", value: addressList[34]}, {type: "string", name: "_tokenName", value: `Substratum`}, {type: "uint8", name: "_numDecimals", value: "2"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `SUB`, addressList[34], `Substratum`, "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `FUN`, addressList[35], `FunFair`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x70580dd8398843f6453033551c71fa4f6ceed5727cbda0c9bf856d5fd97acc84", nonce: "100", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "37", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000419d0d8bdd9af5e606ae2232ed285aff190e711b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000346554e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000746756e4661697200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2676218", gasUsed: "135529", confirmations: "2026113"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `FUN`}, {type: "address", name: "_tokenAddress", value: addressList[35]}, {type: "string", name: "_tokenName", value: `FunFair`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `FUN`, addressList[35], `FunFair`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `KNC`, addressList[36], `KyberNetwork`, ... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x7c3469c7fe9781c7565a3778ef553bc1bb39e3e59115320ba622ff1a16c8504e", nonce: "101", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "38", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd20000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034b4e430000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c4b796265724e6574776f726b0000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2812003", gasUsed: "135785", confirmations: "2026113"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `KNC`}, {type: "address", name: "_tokenAddress", value: addressList[36]}, {type: "string", name: "_tokenName", value: `KyberNetwork`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `KNC`, addressList[36], `KyberNetwork`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `R`, addressList[37], `Revain`, \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x70f2d1c9d208560c0e091f05fe7fc72fb4f9f2a5d5c70b40c7ebe70609bb6d7c", nonce: "102", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "39", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000048f775efbe4f5ece6e0df2f7b5932df56823b99000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000652657661696e0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2932276", gasUsed: "120273", confirmations: "2026113"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `R`}, {type: "address", name: "_tokenAddress", value: addressList[37]}, {type: "string", name: "_tokenName", value: `Revain`}, {type: "uint8", name: "_numDecimals", value: "0"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `R`, addressList[37], `Revain`, "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `SALT`, addressList[38], `Salt`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xabafeee12484b5869b63d64dfc6f9d6d7961fc729311ef67130d1f74eb91e33c", nonce: "103", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "40", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000004156d3342d5c385a87d264f9065373359200058100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000453414c5400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000453616c7400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3067613", gasUsed: "135337", confirmations: "2026113"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `SALT`}, {type: "address", name: "_tokenAddress", value: addressList[38]}, {type: "string", name: "_tokenName", value: `Salt`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `SALT`, addressList[38], `Salt`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `BNT`, addressList[39], `Bancor`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xd233cf034cba44d15a1d93bdfee671e4eef708c3e06caa0834f00cb7254f4444", nonce: "104", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "41", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003424e540000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000642616e636f720000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3203078", gasUsed: "135465", confirmations: "2026113"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `BNT`}, {type: "address", name: "_tokenAddress", value: addressList[39]}, {type: "string", name: "_tokenName", value: `Bancor`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `BNT`, addressList[39], `Bancor`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `nCash`, addressList[40], `NucleusVision... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x42b95f2c0fe3285dfc859abefc14e573f62ac2f677934b1a1d87cac915d0cbaf", nonce: "105", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "42", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000809826cceab68c387726af962713b64cb5cb3cca00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000056e43617368000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d4e75636c657573566973696f6e00000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3339119", gasUsed: "136041", confirmations: "2026113"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `nCash`}, {type: "address", name: "_tokenAddress", value: addressList[40]}, {type: "string", name: "_tokenName", value: `NucleusVision`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `nCash`, addressList[40], `NucleusVision`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `LINK`, addressList[41], `ChainLink Toke... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x5c368955ed4cb9cc03a8f6352133c176940d57411e08da4687b34342fbaa656a", nonce: "106", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "43", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000514910771af9ca656af840dff83e8264ecf986ca00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000044c494e4b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f436861696e4c696e6b20546f6b656e0000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3475224", gasUsed: "136105", confirmations: "2026113"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `LINK`}, {type: "address", name: "_tokenAddress", value: addressList[41]}, {type: "string", name: "_tokenName", value: `ChainLink Token`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `LINK`, addressList[41], `ChainLink Token`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `POWR`, addressList[42], `PowerLedger`, ... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x3c867738140a564a53d454f55fd5b027255ec4b62a6fb84e88e61c4e5244cf92", nonce: "107", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "44", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000595832f8fc6bf59c85c527fec3740a1b7a36126900000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004504f575200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b506f7765724c6564676572000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3611073", gasUsed: "135849", confirmations: "2026113"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `POWR`}, {type: "address", name: "_tokenAddress", value: addressList[42]}, {type: "string", name: "_tokenName", value: `PowerLedger`}, {type: "uint8", name: "_numDecimals", value: "6"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `POWR`, addressList[42], `PowerLedger`, "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `STORM`, addressList[43], `Storm`, \"18\... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x0a432fc9a29151329ccb524bb7714a2057bf0edc76a7a532374e75a952f5e06d", nonce: "108", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "45", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000d0a4b8946cb52f0661273bfbc6fd0e0c75fc643300000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000553544f524d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000553746f726d000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3746602", gasUsed: "135529", confirmations: "2026113"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `STORM`}, {type: "address", name: "_tokenAddress", value: addressList[43]}, {type: "string", name: "_tokenName", value: `Storm`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `STORM`, addressList[43], `Storm`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `REQ`, addressList[44], `Request`, \"18\... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0x5a3cf6669c1146cc360ca66f7f845d95ad9d512ce1e2634e0c2e5ac6a3e34b96", nonce: "109", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "46", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000008f8221afbb33998d8584a2b05749ba73c37a938a00000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000003524551000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000075265717565737400000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3882131", gasUsed: "135529", confirmations: "2026113"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `REQ`}, {type: "address", name: "_tokenAddress", value: addressList[44]}, {type: "string", name: "_tokenName", value: `Request`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `REQ`, addressList[44], `Request`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `WAX`, addressList[45], `WAX Token`, \"8... )", async function( ) {
		const txOriginal = {blockNumber: "5655969", timeStamp: "1526968882", hash: "0xe3d97cf62b9c20a12a8318404b79d661325a1ad9656faa130c249913c51b4f54", nonce: "110", blockHash: "0x161d2c6efb6e16f14e847c2326b201cc0cdb63a567d94f31f021491af044ee89", transactionIndex: "47", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000039bb259f66e1c59d5abef88375979b4d20d9802200000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000035741580000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000957415820546f6b656e0000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4017788", gasUsed: "135657", confirmations: "2026113"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `WAX`}, {type: "address", name: "_tokenAddress", value: addressList[45]}, {type: "string", name: "_tokenName", value: `WAX Token`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `WAX`, addressList[45], `WAX Token`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1526968882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `STORJ`, addressList[46], `Storj`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655970", timeStamp: "1526968889", hash: "0xc9563c3bea97aed394e8efdb9c169a3ba5db4f5ded146e0df1fc7d46818aa156", nonce: "111", blockHash: "0xd2e1d9088b433a8aba3748ee6e1aff66d751efa9cf1c01e607f443913f40d361", transactionIndex: "19", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000b64ef51c888972c908cfacf59b47c1afbc0ab8ac00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000553544f524a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000553746f726a000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1801263", gasUsed: "135529", confirmations: "2026112"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `STORJ`}, {type: "address", name: "_tokenAddress", value: addressList[46]}, {type: "string", name: "_tokenName", value: `Storj`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `STORJ`, addressList[46], `Storj`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1526968889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `PAY`, addressList[47], `TenXPay`, \"18\... )", async function( ) {
		const txOriginal = {blockNumber: "5655970", timeStamp: "1526968889", hash: "0xd8f005c04edeaa88005dd536aaf1e15f2a50bd9d9c17f9f4eba4fa7048b22e77", nonce: "112", blockHash: "0xd2e1d9088b433a8aba3748ee6e1aff66d751efa9cf1c01e607f443913f40d361", transactionIndex: "20", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000b97048628db6b661d4c2aa833e95dbe1a905b28000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000035041590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000754656e5850617900000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1936792", gasUsed: "135529", confirmations: "2026112"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `PAY`}, {type: "address", name: "_tokenAddress", value: addressList[47]}, {type: "string", name: "_tokenName", value: `TenXPay`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `PAY`, addressList[47], `TenXPay`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1526968889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `ENG`, addressList[48], `Enigma`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655970", timeStamp: "1526968889", hash: "0xee4c37be49576995db56df71bf92c0eeeced76776783ccc5ad45ca1b72cd28b0", nonce: "113", blockHash: "0xd2e1d9088b433a8aba3748ee6e1aff66d751efa9cf1c01e607f443913f40d361", transactionIndex: "21", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000f0ee6b27b759c9893ce4f094b49ad28fd15a23e400000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000003454e4700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006456e69676d610000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2072257", gasUsed: "135465", confirmations: "2026112"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `ENG`}, {type: "address", name: "_tokenAddress", value: addressList[48]}, {type: "string", name: "_tokenName", value: `Enigma`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `ENG`, addressList[48], `Enigma`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1526968889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `MAN`, addressList[49], `MATRIX AI Netwo... )", async function( ) {
		const txOriginal = {blockNumber: "5655970", timeStamp: "1526968889", hash: "0x56c424a457409dbf63c621d73e38ed2886a20ce1b14acf8537c3293dca0c5bd3", nonce: "114", blockHash: "0xd2e1d9088b433a8aba3748ee6e1aff66d751efa9cf1c01e607f443913f40d361", transactionIndex: "22", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000e25bcec5d3801ce3a794079bf94adf1b8ccd802d00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000034d414e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000114d4154524958204149204e6574776f726b000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2208426", gasUsed: "136169", confirmations: "2026112"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `MAN`}, {type: "address", name: "_tokenAddress", value: addressList[49]}, {type: "string", name: "_tokenName", value: `MATRIX AI Network`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `MAN`, addressList[49], `MATRIX AI Network`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1526968889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `Dentacoin`, addressList[50], `Dentacoin... )", async function( ) {
		const txOriginal = {blockNumber: "5655970", timeStamp: "1526968889", hash: "0xdfb179cf9ee88b4604f45b0e4e3c5b9f7f2dad6b6d2f1d88af147560d4cc4d9e", nonce: "115", blockHash: "0xd2e1d9088b433a8aba3748ee6e1aff66d751efa9cf1c01e607f443913f40d361", transactionIndex: "23", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000008d32b0da63e2c3bcf8019c9c5d849d7a9d791e600000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000944656e7461636f696e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000944656e7461636f696e0000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2329403", gasUsed: "120977", confirmations: "2026112"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `Dentacoin`}, {type: "address", name: "_tokenAddress", value: addressList[50]}, {type: "string", name: "_tokenName", value: `Dentacoin`}, {type: "uint8", name: "_numDecimals", value: "0"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `Dentacoin`, addressList[50], `Dentacoin`, "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1526968889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `DENT`, addressList[51], `DENT`, \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "5655970", timeStamp: "1526968889", hash: "0x91c33acdf3c57bb627fb203ab91ab6bdbe8fafa93209f299ff8e53d3b7e15eb7", nonce: "116", blockHash: "0xd2e1d9088b433a8aba3748ee6e1aff66d751efa9cf1c01e607f443913f40d361", transactionIndex: "24", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d200000000000000000000000000000000000000000000000000000000000000800000000000000000000000003597bfd533a99c9aa083587b074434e61eb0a25800000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000444454e5400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000444454e5400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2464804", gasUsed: "135401", confirmations: "2026112"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `DENT`}, {type: "address", name: "_tokenAddress", value: addressList[51]}, {type: "string", name: "_tokenName", value: `DENT`}, {type: "uint8", name: "_numDecimals", value: "8"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `DENT`, addressList[51], `DENT`, "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1526968889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAttributes( `FSN`, addressList[52], `Fusion`, \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "5655970", timeStamp: "1526968889", hash: "0x1b2489d8f8493dfae30ca2412605a4f269decda0db1f423848af3a62ec225ac1", nonce: "117", blockHash: "0xd2e1d9088b433a8aba3748ee6e1aff66d751efa9cf1c01e607f443913f40d361", transactionIndex: "25", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0xd79396ab3bfaaa0d9f6d11f95bb641601d93c0a9", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x51d658d20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000d0352a019e9ab9d757776f532377aaebd36fd54100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000346534e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006467573696f6e0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2600269", gasUsed: "135465", confirmations: "2026112"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_symbol", value: `FSN`}, {type: "address", name: "_tokenAddress", value: addressList[52]}, {type: "string", name: "_tokenName", value: `Fusion`}, {type: "uint8", name: "_numDecimals", value: "18"}], name: "setTokenAttributes", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAttributes(string,address,string,uint8)" ]( `FSN`, addressList[52], `Fusion`, "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1526968889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
