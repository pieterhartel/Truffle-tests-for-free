const TrustService = artifacts.require( "./TrustService.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TrustService" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xa35aC2445eB99Ef4E91c696Ea09b448894A76036", "0xFF7766715a9Ea89007a2Fc6d2c2D7b6909490E25", "0x0cfb082e5B7b608853b17c2Ebc6C7f5BF427fF87", "0x653d58eEb3DD1dC8c7E5bF1281C63ffDE3Bd5A2E", "0xb2001817d3a877191D493Aa40A98BcE53DbAD1A6", "0x27e872af8e4f400bcC42cD396C6418BAcf46971B", "0x36B743732508373F056A18CDdD6C89d410c977fa", "0x08d2892E3DcB9aaE2BAb8B2F56461AB080A55122"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "feeSender", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "dealId", type: "uint256"}, {name: "dealHash", type: "bytes32"}], name: "confirmDeal", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "feeRecipient", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "feeToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "dealId", type: "uint256"}], name: "readDeal", outputs: [{name: "dealHash", type: "bytes32"}, {name: "addresses", type: "address[]"}, {name: "signed", type: "bool[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["DealSaved(uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x83f4a9570314ddb3fb6b9c65bebf92a76568949e290eaea5b73e32708ec15b99", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 5623537 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 5707853 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "TrustService", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "feeSender", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeSender()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "dealId", value: random.range( maxRandom )}, {type: "bytes32", name: "dealHash", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "confirmDeal", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "confirmDeal(uint256,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feeRecipient", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeRecipient()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feeToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "dealId", value: random.range( maxRandom )}], name: "readDeal", outputs: [{name: "dealHash", type: "bytes32"}, {name: "addresses", type: "address[]"}, {name: "signed", type: "bool[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "readDeal(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TrustService", function( accounts ) {

	it( "TEST: TrustService(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "5623537", timeStamp: "1526473473", hash: "0xa15e644637b8c94b5599b154e8ba6fa495625c26f3ea44a6bb56a99ac53d3b6e", nonce: "207", blockHash: "0x421514783a25ae514d363c89c5fdecbaec48ecbe49e83c8d3fe6cee028d4e3e5", transactionIndex: "32", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: 0, value: "0", gas: "4700000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x03f7f636", contractAddress: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", cumulativeGasUsed: "3320920", gasUsed: "1637336", confirmations: "2086342"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "TrustService", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TrustService.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1526473473 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TrustService.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setStorage( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "5623638", timeStamp: "1526474844", hash: "0x8b8b26afae2e2d6ed1aa10fcfa8b0c5f2e3e5228e382f126827ff107e02bb58a", nonce: "212", blockHash: "0x36d692309ced61a7eebf28d7e2b994f0b86c46ba928f49fceda4347dea1144e0", transactionIndex: "61", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "4700000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9137c1a70000000000000000000000000cfb082e5b7b608853b17c2ebc6c7f5bf427ff87", contractAddress: "", cumulativeGasUsed: "2474503", gasUsed: "43596", confirmations: "2086241"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_storageAddress", value: addressList[4]}], name: "setStorage", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStorage(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1526474844 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setStorage( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "5623710", timeStamp: "1526475969", hash: "0x186e973a3560b34c57a5265b390a1c0717a2c095d7ff444f1aaeb62b21e44272", nonce: "213", blockHash: "0x247290d25724a71881be2be425c697fb4a3526bcd67ff6f5d627a1c48cf8a255", transactionIndex: "64", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "4700000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9137c1a70000000000000000000000000cfb082e5b7b608853b17c2ebc6c7f5bf427ff87", contractAddress: "", cumulativeGasUsed: "3260938", gasUsed: "28596", confirmations: "2086169"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_storageAddress", value: addressList[4]}], name: "setStorage", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStorage(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1526475969 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setStorage( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "5623766", timeStamp: "1526476916", hash: "0x06d336a25787a24a9563b07b7ac50d6f4bbdfb8855e08504e5d3a6065e75a92b", nonce: "214", blockHash: "0x0d400c5f3d2830a2923b69ab6a33f1c3bde9e1f5dde14072ca7975c12a378750", transactionIndex: "52", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "4700000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x9137c1a70000000000000000000000000cfb082e5b7b608853b17c2ebc6c7f5bf427ff87", contractAddress: "", cumulativeGasUsed: "2665180", gasUsed: "28596", confirmations: "2086113"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_storageAddress", value: addressList[4]}], name: "setStorage", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStorage(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1526476916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setStorage( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "5624075", timeStamp: "1526482002", hash: "0x1584c07e3d226928916baa9750d78b9abac2434a353d8b056d48f5bc570c06c5", nonce: "216", blockHash: "0x8a7530da6cb89c16254fe39fec90fd237f5f7a5c05a6b709481e4f99b69e13e3", transactionIndex: "62", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "4700000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9137c1a70000000000000000000000000cfb082e5b7b608853b17c2ebc6c7f5bf427ff87", contractAddress: "", cumulativeGasUsed: "2418370", gasUsed: "28596", confirmations: "2085804"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_storageAddress", value: addressList[4]}], name: "setStorage", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStorage(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1526482002 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setStorage( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "5624084", timeStamp: "1526482145", hash: "0xa26f6ef0f9969ad71a648d13438d706a78e217c2cd0f3bf6751d697359a74369", nonce: "217", blockHash: "0x0c2c3849db0f2320776c7cb81c9c54968fcc0f494a8a6e7cac2be228b60a7e3c", transactionIndex: "4", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "4700000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9137c1a70000000000000000000000000cfb082e5b7b608853b17c2ebc6c7f5bf427ff87", contractAddress: "", cumulativeGasUsed: "1262450", gasUsed: "28596", confirmations: "2085795"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_storageAddress", value: addressList[4]}], name: "setStorage", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStorage(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1526482145 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setStorage( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "5624107", timeStamp: "1526482645", hash: "0x079c80d35359894119813b6ac6899fd8d18cab3342712656ae13beeb34bc9596", nonce: "218", blockHash: "0xc3c5b82ea590c23859dd8a3e99eed1984452a3eb94f747ecfdedf8c903df5b80", transactionIndex: "47", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "4700000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9137c1a70000000000000000000000000cfb082e5b7b608853b17c2ebc6c7f5bf427ff87", contractAddress: "", cumulativeGasUsed: "1815899", gasUsed: "28596", confirmations: "2085772"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_storageAddress", value: addressList[4]}], name: "setStorage", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStorage(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1526482645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setStorage( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "5624113", timeStamp: "1526482762", hash: "0x32af8aba5ec7d1e550f6399670a42d00bd5d9de8308e6459f8fc781e2131d58f", nonce: "219", blockHash: "0x2669ec1d62c8ffb0eaefab9988b7f822fcf2c941d9b122ba3b6e5372ee788d3b", transactionIndex: "5", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "4700000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x9137c1a70000000000000000000000000cfb082e5b7b608853b17c2ebc6c7f5bf427ff87", contractAddress: "", cumulativeGasUsed: "351225", gasUsed: "28596", confirmations: "2085766"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_storageAddress", value: addressList[4]}], name: "setStorage", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStorage(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1526482762 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xd699efe2a16699952a0316895f37c368a392... )", async function( ) {
		const txOriginal = {blockNumber: "5624266", timeStamp: "1526484924", hash: "0x225a76e82a7b1d63fbe97a5bb2001817d3a877191d493aa40a98bce53dbad1a6", nonce: "220", blockHash: "0x13eb5ed2a85841162ce320cc9998d7c55dddb594d2591764c726638f1ea8dca9", transactionIndex: "143", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bd699efe2a16699952a0316895f37c368a39237da442d7b89b7ee78d84c83c8d200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000653d58eeb3dd1dc8c7e5bf1281c63ffde3bd5a2e", contractAddress: "", cumulativeGasUsed: "5255370", gasUsed: "101565", confirmations: "2085613"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xd699efe2a16699952a0316895f37c368a39237da442d7b89b7ee78d84c83c8d2"}, {type: "address[]", name: "addresses", value: [addressList[5]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xd699efe2a16699952a0316895f37c368a39237da442d7b89b7ee78d84c83c8d2", [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1526484924 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "1"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xe440e6429bd511523c0f59ce07708f15cffe... )", async function( ) {
		const txOriginal = {blockNumber: "5624327", timeStamp: "1526485848", hash: "0x258ef9c40c8febb2dd11e0c0db0333a527ebe388a7d1f77c7d421150389e0439", nonce: "221", blockHash: "0x93e4715dfaaccb954f0b56872ff0fb071bd761f57d822e06901cebd52b27ac23", transactionIndex: "103", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242be440e6429bd511523c0f59ce07708f15cffe138fdd287c82da3ba866c89f7c7c00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000b2001817d3a877191d493aa40a98bce53dbad1a6", contractAddress: "", cumulativeGasUsed: "4409659", gasUsed: "101501", confirmations: "2085552"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xe440e6429bd511523c0f59ce07708f15cffe138fdd287c82da3ba866c89f7c7c"}, {type: "address[]", name: "addresses", value: [addressList[6]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xe440e6429bd511523c0f59ce07708f15cffe138fdd287c82da3ba866c89f7c7c", [addressList[6]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1526485848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "2"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x603799dbe72a410ddc4207fa4b7ac5c045ce... )", async function( ) {
		const txOriginal = {blockNumber: "5624387", timeStamp: "1526486746", hash: "0x096784a21a6dba8993435c20a533430c7294b416c1820ebd88a182476c9f7de1", nonce: "222", blockHash: "0xc7ec45c3928db2384b459599563e5ecaabb88933e30e2db32ffdf111995b76f0", transactionIndex: "124", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b603799dbe72a410ddc4207fa4b7ac5c045ce69575e33df5ebf5a0bc0b95f52e500000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000653d58eeb3dd1dc8c7e5bf1281c63ffde3bd5a2e", contractAddress: "", cumulativeGasUsed: "6290484", gasUsed: "101565", confirmations: "2085492"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x603799dbe72a410ddc4207fa4b7ac5c045ce69575e33df5ebf5a0bc0b95f52e5"}, {type: "address[]", name: "addresses", value: [addressList[5]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x603799dbe72a410ddc4207fa4b7ac5c045ce69575e33df5ebf5a0bc0b95f52e5", [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1526486746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "3"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x1ddf69f9aa2423409445a395405fcb5c1eae... )", async function( ) {
		const txOriginal = {blockNumber: "5624480", timeStamp: "1526488169", hash: "0x1ae9722ea3f8eaf01125123659d1f3224003bcea3bfbb087201ee8ad5f60f6fc", nonce: "223", blockHash: "0x5df8dc1608f6643505195158aae60bb60a45cca4b47fa2f3dcfc76403a2c4147", transactionIndex: "92", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10240000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b1ddf69f9aa2423409445a395405fcb5c1eaeed6618192389aabd7a243493df0c00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "3366518", gasUsed: "101565", confirmations: "2085399"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x1ddf69f9aa2423409445a395405fcb5c1eaeed6618192389aabd7a243493df0c"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x1ddf69f9aa2423409445a395405fcb5c1eaeed6618192389aabd7a243493df0c", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1526488169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "4"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x6fa69bdc6cc6729c852f7b0641a98081f80a... )", async function( ) {
		const txOriginal = {blockNumber: "5624506", timeStamp: "1526488704", hash: "0xcac5d3f64f3a787cc068a2cdef9f8e93a99b4072cab826d3f7fe69dcc02439d3", nonce: "224", blockHash: "0xf1f5089113f237e9272ee467833f00ea177a460a53a8793d1b031f01cf4631c9", transactionIndex: "26", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b6fa69bdc6cc6729c852f7b0641a98081f80aa16e2aebd3d65cf4cea3e0484fa700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "1085348", gasUsed: "101565", confirmations: "2085373"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x6fa69bdc6cc6729c852f7b0641a98081f80aa16e2aebd3d65cf4cea3e0484fa7"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x6fa69bdc6cc6729c852f7b0641a98081f80aa16e2aebd3d65cf4cea3e0484fa7", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1526488704 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "5"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xccc3d2532953b9077a287ab6f8b97f547aab... )", async function( ) {
		const txOriginal = {blockNumber: "5624513", timeStamp: "1526488844", hash: "0x0a715a1ce2e3679e2085be62ffa986ee480a669a6f18315586fdac7191eaa28f", nonce: "225", blockHash: "0x0de9608782290e3b540633eb409993a2c91e42bfab10e268551caa8b59b4fad7", transactionIndex: "166", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bccc3d2532953b9077a287ab6f8b97f547aabc68e879c5a4e21b20c61bd4f721000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "6075780", gasUsed: "101565", confirmations: "2085366"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xccc3d2532953b9077a287ab6f8b97f547aabc68e879c5a4e21b20c61bd4f7210"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xccc3d2532953b9077a287ab6f8b97f547aabc68e879c5a4e21b20c61bd4f7210", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1526488844 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "6"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x9aaca006b5abd15821fd8bec66f483788c40... )", async function( ) {
		const txOriginal = {blockNumber: "5624529", timeStamp: "1526489192", hash: "0xcabffebbd0ad04b1bb10764ac88baa6e960e34214dcb1f5ebbbd0e71c7e4714c", nonce: "226", blockHash: "0x2e0540918c17a4bc62a0a8499240c6f780b69614c4ffb7ae57078c86d7c6b1ed", transactionIndex: "188", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b9aaca006b5abd15821fd8bec66f483788c4031b0f746b6a96d604eda981d2a0c00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "6800228", gasUsed: "101565", confirmations: "2085350"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x9aaca006b5abd15821fd8bec66f483788c4031b0f746b6a96d604eda981d2a0c"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x9aaca006b5abd15821fd8bec66f483788c4031b0f746b6a96d604eda981d2a0c", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1526489192 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "7"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x7facd1c0291998116863bee364dfd625d8cb... )", async function( ) {
		const txOriginal = {blockNumber: "5624543", timeStamp: "1526489454", hash: "0xf1960217ba7047a48671cca5eb00eb09dc52ecf30c91d3e021c19006bb9716ce", nonce: "227", blockHash: "0x7716d343ff4690fc5a47417028e88ad9720a74b51f185066681effa50643ceeb", transactionIndex: "88", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b7facd1c0291998116863bee364dfd625d8cbb33845edbf858ffec3b63b082b8400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "4879997", gasUsed: "101565", confirmations: "2085336"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x7facd1c0291998116863bee364dfd625d8cbb33845edbf858ffec3b63b082b84"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x7facd1c0291998116863bee364dfd625d8cbb33845edbf858ffec3b63b082b84", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1526489454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "8"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x93da56f40831aa5ab5133d3b61556bb4ddee... )", async function( ) {
		const txOriginal = {blockNumber: "5624589", timeStamp: "1526490345", hash: "0x596a5ff94b1879a4ae278f5e8c50f0c79fe06d86d42dcb927a05587beb9ad30a", nonce: "228", blockHash: "0xa85bbae65b367421d42e83f8683f884f8495f33837db106c0d7814ae3533a7ae", transactionIndex: "8", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b93da56f40831aa5ab5133d3b61556bb4ddeeaf3df96986cc25766e2d73b125de00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "756687", gasUsed: "101565", confirmations: "2085290"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x93da56f40831aa5ab5133d3b61556bb4ddeeaf3df96986cc25766e2d73b125de"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x93da56f40831aa5ab5133d3b61556bb4ddeeaf3df96986cc25766e2d73b125de", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1526490345 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "9"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xf6271b211016b839578b9739f5e136d30299... )", async function( ) {
		const txOriginal = {blockNumber: "5624597", timeStamp: "1526490457", hash: "0x014250e6fdcce8d6d2e1f446ac6e160045c841fa5abfa1f2cb64f892616e3b4c", nonce: "229", blockHash: "0x7e8b5eeacc44b2e9e843b9d14ea76263813f4997a05b5f9609630bf5872b582f", transactionIndex: "37", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bf6271b211016b839578b9739f5e136d30299f99919f0f83b8ed11c2321ce0f6900000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "5886329", gasUsed: "101565", confirmations: "2085282"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xf6271b211016b839578b9739f5e136d30299f99919f0f83b8ed11c2321ce0f69"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xf6271b211016b839578b9739f5e136d30299f99919f0f83b8ed11c2321ce0f69", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1526490457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "10"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x4f154e262430e02b319eea575972f76fca6a... )", async function( ) {
		const txOriginal = {blockNumber: "5624604", timeStamp: "1526490539", hash: "0x3cf790f402864011e1529b4a178b27e22784cfefdfbd2bdaa9cc4a6a843af351", nonce: "230", blockHash: "0x6190b9f5040383e4ee16d0c65153e417ebdf42365ed2da608ea32b5a38c44941", transactionIndex: "138", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b4f154e262430e02b319eea575972f76fca6aa1dd1c44f70383a05d387f3b5bdd00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "4461558", gasUsed: "101565", confirmations: "2085275"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x4f154e262430e02b319eea575972f76fca6aa1dd1c44f70383a05d387f3b5bdd"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x4f154e262430e02b319eea575972f76fca6aa1dd1c44f70383a05d387f3b5bdd", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1526490539 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "11"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x8232fb2e0c384d38bd9ba273c92d96f75473... )", async function( ) {
		const txOriginal = {blockNumber: "5624659", timeStamp: "1526491298", hash: "0xc0e05e70062f4b74de58305274d9d64c55a0187a16798734c23390932e565a0d", nonce: "231", blockHash: "0x218b450e395bea666ab6ab7a369d44c74d04f671a4baff2483c0d8dc96e15d36", transactionIndex: "96", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b8232fb2e0c384d38bd9ba273c92d96f754734c188ac784e7aa17a80d832e1e5300000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "7044747", gasUsed: "101565", confirmations: "2085220"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x8232fb2e0c384d38bd9ba273c92d96f754734c188ac784e7aa17a80d832e1e53"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x8232fb2e0c384d38bd9ba273c92d96f754734c188ac784e7aa17a80d832e1e53", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1526491298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "12"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x62d6fa738d9e4b703cf034f093a96501dfc6... )", async function( ) {
		const txOriginal = {blockNumber: "5624667", timeStamp: "1526491396", hash: "0x7bc29601f190bdfc3ede9f321867d0888ef901731e1a90fc338953f45f292e4e", nonce: "232", blockHash: "0x639c4d23d7d4ba41fc588499cb6008330cca05993c9f0030ba56d92d4a7551b7", transactionIndex: "85", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b62d6fa738d9e4b703cf034f093a96501dfc62e26113aa5f54e22b2abaa21a0cf00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ff7766715a9ea89007a2fc6d2c2d7b6909490e25", contractAddress: "", cumulativeGasUsed: "3886849", gasUsed: "101565", confirmations: "2085212"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x62d6fa738d9e4b703cf034f093a96501dfc62e26113aa5f54e22b2abaa21a0cf"}, {type: "address[]", name: "addresses", value: [addressList[3]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x62d6fa738d9e4b703cf034f093a96501dfc62e26113aa5f54e22b2abaa21a0cf", [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1526491396 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "13"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x9ca6a94a2b685a33e56cac8fbc3026899239... )", async function( ) {
		const txOriginal = {blockNumber: "5624686", timeStamp: "1526491669", hash: "0xd55bc9bc246c1ff6aa720663138d365f739e742d2faab46a5bf4aa86a5a0a341", nonce: "233", blockHash: "0x84c7e02121a6b17ac5bf572af0418cdf7e6241a109b60aa39581061611422bed", transactionIndex: "116", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b9ca6a94a2b685a33e56cac8fbc3026899239be5759652686096162b5a476e8a800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000653d58eeb3dd1dc8c7e5bf1281c63ffde3bd5a2e", contractAddress: "", cumulativeGasUsed: "5211145", gasUsed: "101565", confirmations: "2085193"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x9ca6a94a2b685a33e56cac8fbc3026899239be5759652686096162b5a476e8a8"}, {type: "address[]", name: "addresses", value: [addressList[5]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x9ca6a94a2b685a33e56cac8fbc3026899239be5759652686096162b5a476e8a8", [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1526491669 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "14"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x9de72b4df55060a9431a3f8ba8ede85d5e54... )", async function( ) {
		const txOriginal = {blockNumber: "5624739", timeStamp: "1526492425", hash: "0xa31f95161337426a3ba7956c96dc55f6d754b8085902763ce7dde266d677ab55", nonce: "234", blockHash: "0xadf5058fa640a0e9d88f9ff90196120e74d0bea53615ff537113955b816970f2", transactionIndex: "108", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b9de72b4df55060a9431a3f8ba8ede85d5e54c269ac0ec47c9e6a65526e15155200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000653d58eeb3dd1dc8c7e5bf1281c63ffde3bd5a2e", contractAddress: "", cumulativeGasUsed: "4196230", gasUsed: "101565", confirmations: "2085140"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x9de72b4df55060a9431a3f8ba8ede85d5e54c269ac0ec47c9e6a65526e151552"}, {type: "address[]", name: "addresses", value: [addressList[5]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x9de72b4df55060a9431a3f8ba8ede85d5e54c269ac0ec47c9e6a65526e151552", [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1526492425 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "15"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xb16053a5ceb2ca07228705e97fade9d89604... )", async function( ) {
		const txOriginal = {blockNumber: "5624821", timeStamp: "1526493617", hash: "0x0aa0d425f80c98c0b662e9c9b6c2432caf407bbe88bc45625d8008c0e60f3ca0", nonce: "235", blockHash: "0x132bb3a512b99414bf734f5e3f7b7c29ced91db388e9d6a8237435d7516af9fd", transactionIndex: "78", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bb16053a5ceb2ca07228705e97fade9d896041695f81db4e322f1175dca8dbf9e00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2834541", gasUsed: "64628", confirmations: "2085058"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xb16053a5ceb2ca07228705e97fade9d896041695f81db4e322f1175dca8dbf9e"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xb16053a5ceb2ca07228705e97fade9d896041695f81db4e322f1175dca8dbf9e", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1526493617 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "16"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xe4d4928349ff5e8d4c185d3449239ae0e66f... )", async function( ) {
		const txOriginal = {blockNumber: "5625576", timeStamp: "1526504593", hash: "0x6e4ad3fe759cda42a5181cb19ead2762477fe00bb879342041aecc55ce9b96f2", nonce: "236", blockHash: "0xa03454c13126cc704eb3fd7499513c5867bba328cd5d2966194bbd65ba2fa21e", transactionIndex: "112", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "9400000000", isError: "0", txreceipt_status: "1", input: "0xc71b242be4d4928349ff5e8d4c185d3449239ae0e66f6f2c743d30a58a34464ff312711700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6849036", gasUsed: "64628", confirmations: "2084303"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xe4d4928349ff5e8d4c185d3449239ae0e66f6f2c743d30a58a34464ff3127117"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xe4d4928349ff5e8d4c185d3449239ae0e66f6f2c743d30a58a34464ff3127117", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1526504593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "17"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x97d63d32d85bfbfd29ac367146c0ade39992... )", async function( ) {
		const txOriginal = {blockNumber: "5628243", timeStamp: "1526545076", hash: "0x629bd99ed250e8f5396dbc043de6021146ca279b8bed377198cade33c68d044c", nonce: "237", blockHash: "0xfa163060c620b0731d2b09c725168790cdce9230a0511a7a9885730a3ffae19e", transactionIndex: "114", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b97d63d32d85bfbfd29ac367146c0ade399929042eec866d624a67260d002081200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000653d58eeb3dd1dc8c7e5bf1281c63ffde3bd5a2e", contractAddress: "", cumulativeGasUsed: "4891158", gasUsed: "101565", confirmations: "2081636"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x97d63d32d85bfbfd29ac367146c0ade399929042eec866d624a67260d0020812"}, {type: "address[]", name: "addresses", value: [addressList[5]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x97d63d32d85bfbfd29ac367146c0ade399929042eec866d624a67260d0020812", [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1526545076 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "18"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xf06bad77fb5ee094a888980c265a5155acfe... )", async function( ) {
		const txOriginal = {blockNumber: "5629774", timeStamp: "1526568349", hash: "0x7e2786f78d9932ccd3cc4a29eb0ab701be7b4fc512dd3de0a8c5395d9c881acf", nonce: "238", blockHash: "0xd005d3a448d8b1255e8e9e4192b417f9ceaf87b097b3e9728bca8cb2d19ddc1f", transactionIndex: "127", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bf06bad77fb5ee094a888980c265a5155acfec812a571e682e4a28b356a4cad2f00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000653d58eeb3dd1dc8c7e5bf1281c63ffde3bd5a2e", contractAddress: "", cumulativeGasUsed: "7106949", gasUsed: "101565", confirmations: "2080105"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xf06bad77fb5ee094a888980c265a5155acfec812a571e682e4a28b356a4cad2f"}, {type: "address[]", name: "addresses", value: [addressList[5]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xf06bad77fb5ee094a888980c265a5155acfec812a571e682e4a28b356a4cad2f", [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1526568349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "19"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xbc1e1c16750841c2146c0789fdce3a4516f8... )", async function( ) {
		const txOriginal = {blockNumber: "5630185", timeStamp: "1526574683", hash: "0x23c51af7ac9d30017e4fcf3f25184feeadb7966c037468febd4fa7c3d2dea056", nonce: "239", blockHash: "0xfc6ea314e2679ce1e40022c8bf88b5d98e485d24e84448781ba5b24a35aca377", transactionIndex: "117", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bbc1e1c16750841c2146c0789fdce3a4516f8780ea4ecb1d3ea735ffb27e3064000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001000000000000000000000000653d58eeb3dd1dc8c7e5bf1281c63ffde3bd5a2e", contractAddress: "", cumulativeGasUsed: "6650725", gasUsed: "101565", confirmations: "2079694"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xbc1e1c16750841c2146c0789fdce3a4516f8780ea4ecb1d3ea735ffb27e30640"}, {type: "address[]", name: "addresses", value: [addressList[5]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xbc1e1c16750841c2146c0789fdce3a4516f8780ea4ecb1d3ea735ffb27e30640", [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1526574683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "20"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xc458a47ab0c3d6c6447156269d07bde0e670... )", async function( ) {
		const txOriginal = {blockNumber: "5630207", timeStamp: "1526574988", hash: "0xfdb69a46884971f32a45f862885c503e712b4321b52723f06099df967ffe1cec", nonce: "240", blockHash: "0x4101aa5396b9a2a82281bfa65d1b69bab9e7cd6520496e7ef14aa1beae0fe6ca", transactionIndex: "126", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bc458a47ab0c3d6c6447156269d07bde0e670b9c7f7904df831c36cafdfe334e800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5784509", gasUsed: "64628", confirmations: "2079672"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xc458a47ab0c3d6c6447156269d07bde0e670b9c7f7904df831c36cafdfe334e8"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xc458a47ab0c3d6c6447156269d07bde0e670b9c7f7904df831c36cafdfe334e8", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1526574988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "21"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x5ea4a7a26a7798187393d762e8f695881871... )", async function( ) {
		const txOriginal = {blockNumber: "5634183", timeStamp: "1526635597", hash: "0x0f4949d0a792dc4d8493bcd1bb282a034be9a06da58b809f202b6644fc3dbbe1", nonce: "241", blockHash: "0xfb936e1d4fa1ff1d7a9ab1c6fb99c8e0eef707ca62ed8f9605ab7399b27ee700", transactionIndex: "4", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b5ea4a7a26a7798187393d762e8f695881871b895ec222ab84b76f1912f3b69be00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "186810", gasUsed: "64628", confirmations: "2075696"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x5ea4a7a26a7798187393d762e8f695881871b895ec222ab84b76f1912f3b69be"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x5ea4a7a26a7798187393d762e8f695881871b895ec222ab84b76f1912f3b69be", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1526635597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "22"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x4d3f94259290280a3504fcf4601fc4678f8c... )", async function( ) {
		const txOriginal = {blockNumber: "5635267", timeStamp: "1526652464", hash: "0x4dd9db696acbecb78dda6b89e658bc201f52b5282e30e752baeb0c5ad8b4c3d8", nonce: "242", blockHash: "0x45055c6b7ec075fe5201c03354218142a581eadc8692b951a4c16e20420aa457", transactionIndex: "61", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "22887500000", isError: "0", txreceipt_status: "1", input: "0xc71b242b4d3f94259290280a3504fcf4601fc4678f8c73e0b300f9922afe51036746351100000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2122947", gasUsed: "64564", confirmations: "2074612"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x4d3f94259290280a3504fcf4601fc4678f8c73e0b300f9922afe510367463511"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x4d3f94259290280a3504fcf4601fc4678f8c73e0b300f9922afe510367463511", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1526652464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "23"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x89f7a63f016454b921f6713a2f2781c44410... )", async function( ) {
		const txOriginal = {blockNumber: "5653122", timeStamp: "1526925303", hash: "0xb77eeaf296babc3d8ad204e5829d2e37b994f82948744daf9ea554ae44a7dbbe", nonce: "243", blockHash: "0x747b07a14459edff547afb3e56a87c2171d2b8ea846b7d12aca4b1ffe3df91af", transactionIndex: "41", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b89f7a63f016454b921f6713a2f2781c444105e752d4a59f8fbac1a0aaa687e3f0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000027e872af8e4f400bcc42cd396c6418bacf46971b", contractAddress: "", cumulativeGasUsed: "1755064", gasUsed: "101565", confirmations: "2056757"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x89f7a63f016454b921f6713a2f2781c444105e752d4a59f8fbac1a0aaa687e3f"}, {type: "address[]", name: "addresses", value: [addressList[7]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x89f7a63f016454b921f6713a2f2781c444105e752d4a59f8fbac1a0aaa687e3f", [addressList[7]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1526925303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "24"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xa442562abaf935a9b58e4e0ce3fb16c6c465... )", async function( ) {
		const txOriginal = {blockNumber: "5663069", timeStamp: "1527079242", hash: "0xb03df12bc0eab5a9e5ea8742619d713e83d03392cc3631fdf7ff1de739182d83", nonce: "244", blockHash: "0xaa33cebcd23ec79737efa055787846e4165aa91ef00a86b761b66752a7c23d2a", transactionIndex: "67", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242ba442562abaf935a9b58e4e0ce3fb16c6c465350d6106651525555a390dffa44c0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "1779339", gasUsed: "101565", confirmations: "2046810"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xa442562abaf935a9b58e4e0ce3fb16c6c465350d6106651525555a390dffa44c"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xa442562abaf935a9b58e4e0ce3fb16c6c465350d6106651525555a390dffa44c", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1527079242 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "25"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xed029d870ac6a0d15fce46147feede82904d... )", async function( ) {
		const txOriginal = {blockNumber: "5664083", timeStamp: "1527094384", hash: "0x18b3bca57d929f1f25d1f59a76ab50bff44fcd21231e135395dff68457f53a3d", nonce: "245", blockHash: "0x0c99856f1a8ff7cbffa45d8f9e1f4ca4f4eeb809035a9d4dec6069862f0e2877", transactionIndex: "79", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bed029d870ac6a0d15fce46147feede82904d17752bfcb86acb53a5e760a277050000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000008d2892e3dcb9aae2bab8b2f56461ab080a55122", contractAddress: "", cumulativeGasUsed: "3428001", gasUsed: "101565", confirmations: "2045796"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xed029d870ac6a0d15fce46147feede82904d17752bfcb86acb53a5e760a27705"}, {type: "address[]", name: "addresses", value: [addressList[9]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xed029d870ac6a0d15fce46147feede82904d17752bfcb86acb53a5e760a27705", [addressList[9]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1527094384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "26"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x15f222eed5b55c9bbab74ee6f51598298408... )", async function( ) {
		const txOriginal = {blockNumber: "5668014", timeStamp: "1527154517", hash: "0x23b741a949c312881b78467ea3277423135c7a633ae113fb0b15e5761a1cc2dc", nonce: "246", blockHash: "0xb63c5c47554ae3655c873ff09b5193ce389f3d03d70ff5f38754f63cddf71c13", transactionIndex: "264", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "26000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b15f222eed5b55c9bbab74ee6f51598298408c80d2b44404387ba16efb8bff6520000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000008d2892e3dcb9aae2bab8b2f56461ab080a55122", contractAddress: "", cumulativeGasUsed: "6273663", gasUsed: "101565", confirmations: "2041865"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x15f222eed5b55c9bbab74ee6f51598298408c80d2b44404387ba16efb8bff652"}, {type: "address[]", name: "addresses", value: [addressList[9]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x15f222eed5b55c9bbab74ee6f51598298408c80d2b44404387ba16efb8bff652", [addressList[9]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1527154517 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "27"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xb11178970dee8b6af3742ff73f42652c9eaf... )", async function( ) {
		const txOriginal = {blockNumber: "5668267", timeStamp: "1527158661", hash: "0xdca3d529200db912f3f9d121eafffab81d54090b02b59dd3eb47168349e336ff", nonce: "247", blockHash: "0x869d51055a288caf836bcf6882844ae8428d092b912c443431ebff2e66610e1e", transactionIndex: "11", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "26000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bb11178970dee8b6af3742ff73f42652c9eafa81e3b021a7e2425af5853c6d65f0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "542468", gasUsed: "101565", confirmations: "2041612"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xb11178970dee8b6af3742ff73f42652c9eafa81e3b021a7e2425af5853c6d65f"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xb11178970dee8b6af3742ff73f42652c9eafa81e3b021a7e2425af5853c6d65f", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1527158661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "28"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xb7cd725fe091ed593a69981e64c05e559aa9... )", async function( ) {
		const txOriginal = {blockNumber: "5668444", timeStamp: "1527161599", hash: "0x09ee73fbd6d724aa33dac61d27094ed7304fcf3cceb02fe348a0016c2daa1a08", nonce: "248", blockHash: "0xa0b5dae8b7a6f4cc6a9453aa9db19f76ba35ff7c9fa7e51118e173812911a18c", transactionIndex: "40", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bb7cd725fe091ed593a69981e64c05e559aa9e4da6235851d9d5acd5af5608e580000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "1431061", gasUsed: "101565", confirmations: "2041435"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xb7cd725fe091ed593a69981e64c05e559aa9e4da6235851d9d5acd5af5608e58"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xb7cd725fe091ed593a69981e64c05e559aa9e4da6235851d9d5acd5af5608e58", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1527161599 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "29"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x79e5a14d7a11ac6834a1260be2d853376859... )", async function( ) {
		const txOriginal = {blockNumber: "5668928", timeStamp: "1527169174", hash: "0x24567cc53adfff74f407c7feff12f714926e3ae2afc6bbaf0401dff7677e9ff7", nonce: "249", blockHash: "0x2717fbd9a7241dfbc5d1357a686d0428128dd36727c150636d45f263129e5009", transactionIndex: "24", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "22887500000", isError: "0", txreceipt_status: "1", input: "0xc71b242b79e5a14d7a11ac6834a1260be2d8533768597769a68630820cf4427bb8e7b00d0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "795433", gasUsed: "101565", confirmations: "2040951"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x79e5a14d7a11ac6834a1260be2d8533768597769a68630820cf4427bb8e7b00d"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x79e5a14d7a11ac6834a1260be2d8533768597769a68630820cf4427bb8e7b00d", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1527169174 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "30"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xf1ae15c0e4a525bca3d120f970cab90d77e5... )", async function( ) {
		const txOriginal = {blockNumber: "5669248", timeStamp: "1527173916", hash: "0x44a8a2ed126cf8cd2415a4a27a28a31840ad4c68bb16c1b9dfb93d2928274f6b", nonce: "250", blockHash: "0x146d915507af404056aacd20e659fd6755de664de7801909be7ac4cb2a81ae67", transactionIndex: "133", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bf1ae15c0e4a525bca3d120f970cab90d77e51d8f46860ee7522d72c961bbe3f100000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4382691", gasUsed: "64628", confirmations: "2040631"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xf1ae15c0e4a525bca3d120f970cab90d77e51d8f46860ee7522d72c961bbe3f1"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xf1ae15c0e4a525bca3d120f970cab90d77e51d8f46860ee7522d72c961bbe3f1", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1527173916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "31"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x1eae6711f4b63b4324ea601f9d8ab9f282c2... )", async function( ) {
		const txOriginal = {blockNumber: "5669256", timeStamp: "1527174059", hash: "0xa8db077b084b108b30d4356efa394551aee2420ffc1ac31c4da869516b5aab7f", nonce: "251", blockHash: "0x86f918567f32c028619b4edd2e71baf1c416e78f0baa7a2a0fe988b146344a5b", transactionIndex: "85", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b1eae6711f4b63b4324ea601f9d8ab9f282c2c297c896410cae7ef261db3a548a0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000008d2892e3dcb9aae2bab8b2f56461ab080a55122", contractAddress: "", cumulativeGasUsed: "4583334", gasUsed: "101565", confirmations: "2040623"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x1eae6711f4b63b4324ea601f9d8ab9f282c2c297c896410cae7ef261db3a548a"}, {type: "address[]", name: "addresses", value: [addressList[9]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x1eae6711f4b63b4324ea601f9d8ab9f282c2c297c896410cae7ef261db3a548a", [addressList[9]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1527174059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "32"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xb6f106e04fd6c6164c0f0084f5610458f585... )", async function( ) {
		const txOriginal = {blockNumber: "5673830", timeStamp: "1527243728", hash: "0xfd0c1ffe3026d3f925dfa89658ab03ce2b356bc6fc49a063f14ec63097c5e5a7", nonce: "252", blockHash: "0x9194101bf568d449ddf93679c1e98669830b9975cb7e85a1a8f1639fcc0e094c", transactionIndex: "92", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bb6f106e04fd6c6164c0f0084f5610458f58527bd7ab66db67363c5b190d440a600000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2568054", gasUsed: "64564", confirmations: "2036049"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xb6f106e04fd6c6164c0f0084f5610458f58527bd7ab66db67363c5b190d440a6"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xb6f106e04fd6c6164c0f0084f5610458f58527bd7ab66db67363c5b190d440a6", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1527243728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "33"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x087ef191843a449092b68517d721517d666a... )", async function( ) {
		const txOriginal = {blockNumber: "5674311", timeStamp: "1527251138", hash: "0x3ca58eef9cea7557ea9f039fcfaa674cfce827f271942bdfc6ef3595d4dc1684", nonce: "253", blockHash: "0x8a96fb570edcbbf163070aae42d637473cd5bcddf5ef458381564b16dd47d791", transactionIndex: "49", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "18200000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b087ef191843a449092b68517d721517d666a31ee45bf6d4dfa30eac8eb1059780000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "1507058", gasUsed: "101565", confirmations: "2035568"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x087ef191843a449092b68517d721517d666a31ee45bf6d4dfa30eac8eb105978"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x087ef191843a449092b68517d721517d666a31ee45bf6d4dfa30eac8eb105978", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1527251138 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "34"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x584d92208df8a551202ca8ab798c4e82d12c... )", async function( ) {
		const txOriginal = {blockNumber: "5674563", timeStamp: "1527255102", hash: "0xbb21c861254ba050a2fdd6f52902b5f9784305ef39a657a934b77c46a7f74497", nonce: "254", blockHash: "0x8ce17ff8958fa9484ee682d5d3bb4f381cfcace2b3adb9f508aa8545e6fc050d", transactionIndex: "12", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b584d92208df8a551202ca8ab798c4e82d12c505f308d178ca2d6ab9acafc332b0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "510404", gasUsed: "101565", confirmations: "2035316"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x584d92208df8a551202ca8ab798c4e82d12c505f308d178ca2d6ab9acafc332b"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x584d92208df8a551202ca8ab798c4e82d12c505f308d178ca2d6ab9acafc332b", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1527255102 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "35"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xd6d0aec418037e5067aacdcd2320b99adf78... )", async function( ) {
		const txOriginal = {blockNumber: "5674843", timeStamp: "1527259317", hash: "0x0b734316b507c46ba2181b8d2f1e05ebd675a99fcf0e90a5d691e85cd2343840", nonce: "255", blockHash: "0x2bec329e4b14d2a17e0c93d69a59d0d2cb956e6c120a97d0a1abf35d5bf97303", transactionIndex: "49", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bd6d0aec418037e5067aacdcd2320b99adf78e57615f30a5769700fa5f9ff08ab0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "3546784", gasUsed: "101565", confirmations: "2035036"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xd6d0aec418037e5067aacdcd2320b99adf78e57615f30a5769700fa5f9ff08ab"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xd6d0aec418037e5067aacdcd2320b99adf78e57615f30a5769700fa5f9ff08ab", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1527259317 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "36"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x9c7c4eec38ea1b9cc31d7243a5115327831b... )", async function( ) {
		const txOriginal = {blockNumber: "5674996", timeStamp: "1527261946", hash: "0x5cbadbb933ef60587c5bbe01c4da55558b5abb26791da55ad3c6b410ce9b13d6", nonce: "256", blockHash: "0x154e311741c67e7a71a57d355bda9f5605acb315e2fc1307ad6d5731eab08cf7", transactionIndex: "84", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b9c7c4eec38ea1b9cc31d7243a5115327831b40654e8dae229fc37c649eeea9120000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "3295538", gasUsed: "101565", confirmations: "2034883"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x9c7c4eec38ea1b9cc31d7243a5115327831b40654e8dae229fc37c649eeea912"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x9c7c4eec38ea1b9cc31d7243a5115327831b40654e8dae229fc37c649eeea912", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1527261946 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "37"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xd362953952753d7a82a9621896bb9e134689... )", async function( ) {
		const txOriginal = {blockNumber: "5675259", timeStamp: "1527266053", hash: "0x250f35d60323cb9136da7864c5a851a3c135e6b0b566adcae6f9b1d652e89211", nonce: "257", blockHash: "0x2a43a7a3b5a0475d8e863ad05a18f57ad78011e2215104465873ce2f926338b6", transactionIndex: "28", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "22887500000", isError: "0", txreceipt_status: "1", input: "0xc71b242bd362953952753d7a82a9621896bb9e13468914912b03fa11aaa0c9b7ad0faae30000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000100000000000000000000000036b743732508373f056a18cddd6c89d410c977fa", contractAddress: "", cumulativeGasUsed: "1150921", gasUsed: "101565", confirmations: "2034620"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xd362953952753d7a82a9621896bb9e13468914912b03fa11aaa0c9b7ad0faae3"}, {type: "address[]", name: "addresses", value: [addressList[8]]}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xd362953952753d7a82a9621896bb9e13468914912b03fa11aaa0c9b7ad0faae3", [addressList[8]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1527266053 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "38"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x2895630be213d6311de64eeb7c8481242afc... )", async function( ) {
		const txOriginal = {blockNumber: "5692397", timeStamp: "1527526937", hash: "0x2ea36fb55193f016bbb6060da6d5c998ed08bdfeab833ae71ca97adb071da972", nonce: "258", blockHash: "0x10b0ea24d74ca0bac4083fd61928443897060f990c595f053e81a3e2d22cb172", transactionIndex: "68", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b2895630be213d6311de64eeb7c8481242afcc6700c82bd5f9bf09337da59974700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2008283", gasUsed: "64628", confirmations: "2017482"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x2895630be213d6311de64eeb7c8481242afcc6700c82bd5f9bf09337da599747"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x2895630be213d6311de64eeb7c8481242afcc6700c82bd5f9bf09337da599747", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1527526937 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "39"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xaedf9206a6ef421dc0eb7c544f89ab6de0a4... )", async function( ) {
		const txOriginal = {blockNumber: "5697236", timeStamp: "1527600433", hash: "0x576310072521aaf2fd2734358b4bd7dac1bf6f66d96a7ebaf1ea5e17c3aa36da", nonce: "259", blockHash: "0x8efd7799430a370b1cddb3ec0e95df7c1f63880a40455d9fcbf36c94bdda61db", transactionIndex: "85", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "22200000000", isError: "0", txreceipt_status: "1", input: "0xc71b242baedf9206a6ef421dc0eb7c544f89ab6de0a4653a96aed600f18e9e5edb83ca9500000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3608828", gasUsed: "64564", confirmations: "2012643"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xaedf9206a6ef421dc0eb7c544f89ab6de0a4653a96aed600f18e9e5edb83ca95"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xaedf9206a6ef421dc0eb7c544f89ab6de0a4653a96aed600f18e9e5edb83ca95", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1527600433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "40"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0x17402d24a8a03e0f0ad4257e983f9d474497... )", async function( ) {
		const txOriginal = {blockNumber: "5697642", timeStamp: "1527606973", hash: "0x4708837ec97fbccf4f4a79792d45cf82ab265671c586332f842739b6ccf36753", nonce: "260", blockHash: "0x934c9019e7de7549f3077244e922800c89315fb4928e7c4432997dc3e8a6d455", transactionIndex: "117", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "28000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242b17402d24a8a03e0f0ad4257e983f9d474497a6dcf23d778753e61e146b3774ca00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4247693", gasUsed: "64628", confirmations: "2012237"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0x17402d24a8a03e0f0ad4257e983f9d474497a6dcf23d778753e61e146b3774ca"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0x17402d24a8a03e0f0ad4257e983f9d474497a6dcf23d778753e61e146b3774ca", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1527606973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "41"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: createDeal( \"0xc6489c6acfd98b7b783fae26af5f75d4c824... )", async function( ) {
		const txOriginal = {blockNumber: "5707853", timeStamp: "1527763695", hash: "0x1a1055b2555290a51bd22736f0ed356c0a9412bdeedf9be18093860a22ae7bb7", nonce: "261", blockHash: "0xffb934ba134fafa6cee2de4b092482eb2cac7168d65d07377a9af71a26243387", transactionIndex: "52", from: "0xff7766715a9ea89007a2fc6d2c2d7b6909490e25", to: "0xa35ac2445eb99ef4e91c696ea09b448894a76036", value: "0", gas: "800000", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xc71b242bc6489c6acfd98b7b783fae26af5f75d4c824ca8a2964099be4e0f1bd86bd962e00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1593698", gasUsed: "64628", confirmations: "2002026"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "dealHash", value: "0xc6489c6acfd98b7b783fae26af5f75d4c824ca8a2964099be4e0f1bd86bd962e"}, {type: "address[]", name: "addresses", value: []}], name: "createDeal", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createDeal(bytes32,address[])" ]( "0xc6489c6acfd98b7b783fae26af5f75d4c824ca8a2964099be4e0f1bd86bd962e", [], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1527763695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "dealId", type: "uint256"}], name: "DealSaved", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DealSaved", events: [{name: "dealId", type: "uint256", value: "42"}], address: "0xa35ac2445eb99ef4e91c696ea09b448894a76036"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9484761888339810" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
