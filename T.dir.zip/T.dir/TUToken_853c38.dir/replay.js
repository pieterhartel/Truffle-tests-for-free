var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "TUToken"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xfE3A06a947a036EFf9f9E8EC25B385ff4E853c38","0xEd3998AA7F255Ade06236776f9FD429eECc91357","0x1867812567f42e2Da3C572bE597996B1309593A7","0xF7549be7449aA2b7D708d39481fCBB618C9Fb903","0x252c4f77f1cdCCEBaEBbce393804F4c8f3D5703D","0x03a59D08980A5327a958860e346d020ec8bb33dC","0xC138d62b3E34391964852Cf712454492DC7eFF68","0xD1C6FeC0167153994E34715Bb67488b59a2623B4","0x1983B354F47b82975A897B30e958F84B6Deb61c6","0x528dB6C82Ffa8FcCC5e13Bf35571Dd87c11124E3","0x953588c1Ab5726D632Db8712A07B727F1e4041AA","0x6b1Ff08a928353E0FBF432D16a285064d3B0b579","0xED876e03b1Db47afE4d4c0F4e20783578810Ed98","0x7869C58e25D30EC8e90cF9A6705cdEd1A0eD9493","0x3177cd3A0C3bc48066Ab81436b8a855f1c0d2D18","0xA75917A5141513dcD761CCF55624ef201df823F5","0x2b813B974200dBDF9Ff6A01ed01E20C3F008060E","0xB97afe0315472b31B853669a14fDedaba4e2e770","0xFbb122f3235B17107980b7c9c6D283C1D0cB9aB5","0xaa8E8231dDD064fBeee82A9Ce7550fbcA4131c01","0x672028322808BE55cb7Af17E26E8d34c09D9b6Df","0x3089cAAd545Fc57292265674D3C748e8C86211e4","0xab728419a0f2FB4ff2D5eFf47b55697467B0A251","0x4C0C09FA931C9e818b82F17B9351d7D6D3435053","0xa67F72E8782e8A2eB10c027a083D2D11174693F8","0x709bcd6CbC1B8b1d709e2D4933DAacb0e5CF731A","0x0bE3E2e3234423118d571C1d9aE61b364D590A72","0xdF64CaBf819E84D4Bb0DE2bDdE72fC947FD4e886","0x09F50d63241a72C6b3Fc11777e2D3511358F6483","0x0f02A6c0D55D87359f25539D9CD0c311CD01218c","0x2EF9c006162F916fE4589a82227D22aDD5A5BAaa","0xd38eD463D6a66b6798786c681D6a92c8C1227f0d","0x5D4342D6F15F40Ba91067C996A355738aa827021","0x458B647287FFd7640894afD3AD4efa0B154D82d1","0x19CDE35EF2119349ABff30601251cc4487E44dF3","0xd79b11EB6bd24455a59Fc5c2c570e9b37EB670fb","0x03d560ce1a72A8c411FC422A4675844d1f39a277","0x8D337AD819e3CD7a5D2b6c0e7875ce5680389430","0x30DfD9F863fBD252c99c9BF169eF6D3b5deedD38","0xF13D44eb7bdb2E75c4cFfB3dbD10E1E0103a1691","0x08DFf5ED8e49a0cE2FaD0de640d644450113B400","0xD10D09883d4dA6fF7e75F8fDb32b82C24485Ed9b","0xc24a4D55a9006F0A40420188E5A43a6d1D61cA5b","0x0bc9390CE3E6510ae6523e41bfbF290E317D56ec","0x73e424F9bc661286E9A96e5C28A9F88338E169ea"]
addressListOriginal.length = 47
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"paused","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"pendingOwner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOfLocked","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"uint256"}],"name":"balancesLocked","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":true,"name":"locked","type":"address"},{"indexed":false,"name":"amount","type":"uint256"},{"indexed":false,"name":"releaseTime","type":"uint256"}],"name":"TransferWithLock","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"previousOwner","type":"address"},{"indexed":true,"name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]
eventSignatureListOriginal = ["TransferWithLock(address,address,address,uint256,uint256)","Pause()","Unpause()","OwnershipTransferred(address,address)","Approval(address,address,uint256)","Transfer(address,address,uint256)"]
topicListOriginal = ["0xc4a3ea8819a3430d7cef20bd733e41bd486ebfddbc195e6f31ab9eb7f00022ef","0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625","0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33","0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0","0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925","0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"]
nBlocksOriginal = 50
fromBlockOriginal = 6513148
toBlockOriginal = 6865965
constructorPrototypeOriginal = {"inputs":[],"name":"TUToken","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"6513148","timeStamp":"1539515298","hash":"0x14a5af51d011a6095b8f1628ef98f9bc17b949735f0bc1f8da01b46a31b15679","nonce":"27","blockHash":"0xc25f08b138b377f2ae6b16803295714a126461048e330a9f2b0b1e5cab0ba790","transactionIndex":"6","from":"0xd1c6fec0167153994e34715bb67488b59a2623b4","to":0,"value":"0","gas":"7401574","gasPrice":"3200000000","isError":"0","txreceipt_status":"1","input":"0x51a2432a","contractAddress":"0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38","cumulativeGasUsed":"7781518","gasUsed":"7386574","confirmations":"1212967"}
txOptions[0] = {"from":"0x3E5e9111Ae8eB78Fe1CC3bb8915d5D461F3Ef9A9","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"TUToken","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
