const TUToken = artifacts.require( "./TUToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TUToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xfE3A06a947a036EFf9f9E8EC25B385ff4E853c38", "0xEd3998AA7F255Ade06236776f9FD429eECc91357", "0x1867812567f42e2Da3C572bE597996B1309593A7", "0xF7549be7449aA2b7D708d39481fCBB618C9Fb903", "0x252c4f77f1cdCCEBaEBbce393804F4c8f3D5703D", "0x03a59D08980A5327a958860e346d020ec8bb33dC", "0xC138d62b3E34391964852Cf712454492DC7eFF68", "0xD1C6FeC0167153994E34715Bb67488b59a2623B4", "0x1983B354F47b82975A897B30e958F84B6Deb61c6", "0x528dB6C82Ffa8FcCC5e13Bf35571Dd87c11124E3", "0x953588c1Ab5726D632Db8712A07B727F1e4041AA", "0x6b1Ff08a928353E0FBF432D16a285064d3B0b579", "0xED876e03b1Db47afE4d4c0F4e20783578810Ed98", "0x7869C58e25D30EC8e90cF9A6705cdEd1A0eD9493", "0x3177cd3A0C3bc48066Ab81436b8a855f1c0d2D18", "0xA75917A5141513dcD761CCF55624ef201df823F5", "0x2b813B974200dBDF9Ff6A01ed01E20C3F008060E", "0xB97afe0315472b31B853669a14fDedaba4e2e770", "0xFbb122f3235B17107980b7c9c6D283C1D0cB9aB5", "0xaa8E8231dDD064fBeee82A9Ce7550fbcA4131c01", "0x672028322808BE55cb7Af17E26E8d34c09D9b6Df", "0x3089cAAd545Fc57292265674D3C748e8C86211e4", "0xab728419a0f2FB4ff2D5eFf47b55697467B0A251", "0x4C0C09FA931C9e818b82F17B9351d7D6D3435053", "0xa67F72E8782e8A2eB10c027a083D2D11174693F8", "0x709bcd6CbC1B8b1d709e2D4933DAacb0e5CF731A", "0x0bE3E2e3234423118d571C1d9aE61b364D590A72", "0xdF64CaBf819E84D4Bb0DE2bDdE72fC947FD4e886", "0x09F50d63241a72C6b3Fc11777e2D3511358F6483", "0x0f02A6c0D55D87359f25539D9CD0c311CD01218c", "0x2EF9c006162F916fE4589a82227D22aDD5A5BAaa", "0xd38eD463D6a66b6798786c681D6a92c8C1227f0d", "0x5D4342D6F15F40Ba91067C996A355738aa827021", "0x458B647287FFd7640894afD3AD4efa0B154D82d1", "0x19CDE35EF2119349ABff30601251cc4487E44dF3", "0xd79b11EB6bd24455a59Fc5c2c570e9b37EB670fb", "0x03d560ce1a72A8c411FC422A4675844d1f39a277", "0x8D337AD819e3CD7a5D2b6c0e7875ce5680389430", "0x30DfD9F863fBD252c99c9BF169eF6D3b5deedD38", "0xF13D44eb7bdb2E75c4cFfB3dbD10E1E0103a1691", "0x08DFf5ED8e49a0cE2FaD0de640d644450113B400", "0xD10D09883d4dA6fF7e75F8fDb32b82C24485Ed9b", "0xc24a4D55a9006F0A40420188E5A43a6d1D61cA5b", "0x0bc9390CE3E6510ae6523e41bfbF290E317D56ec", "0x73e424F9bc661286E9A96e5C28A9F88338E169ea"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pendingOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOfLocked", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "uint256"}], name: "balancesLocked", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "locked", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "releaseTime", type: "uint256"}], name: "TransferWithLock", type: "event"}, {anonymous: false, inputs: [], name: "Pause", type: "event"}, {anonymous: false, inputs: [], name: "Unpause", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TransferWithLock(address,address,address,uint256,uint256)", "Pause()", "Unpause()", "OwnershipTransferred(address,address)", "Approval(address,address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc4a3ea8819a3430d7cef20bd733e41bd486ebfddbc195e6f31ab9eb7f00022ef", "0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625", "0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6513148 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6865965 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "TUToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pendingOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pendingOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOfLocked", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOfLocked(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "balancesLocked", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balancesLocked(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TUToken", function( accounts ) {

	it( "TEST: TUToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6513148", timeStamp: "1539515298", hash: "0x14a5af51d011a6095b8f1628ef98f9bc17b949735f0bc1f8da01b46a31b15679", nonce: "27", blockHash: "0xc25f08b138b377f2ae6b16803295714a126461048e330a9f2b0b1e5cab0ba790", transactionIndex: "6", from: "0xd1c6fec0167153994e34715bb67488b59a2623b4", to: 0, value: "0", gas: "7401574", gasPrice: "3200000000", isError: "0", txreceipt_status: "1", input: "0x51a2432a", contractAddress: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", cumulativeGasUsed: "7781518", gasUsed: "7386574", confirmations: "1212967"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "TUToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TUToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1539515298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TUToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "locked", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "releaseTime", type: "uint256"}], name: "TransferWithLock", type: "event"} ;
		console.error( "eventCallOriginal[0,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xed3998aa7f255ade06236776f9fd429eecc91357"}, {name: "locked", type: "address", value: "0xbe0676dba429dc65cef0e55b2b4562cae79e8dda"}, {name: "amount", type: "uint256", value: "5000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1540828800"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xed3998aa7f255ade06236776f9fd429eecc91357"}, {name: "locked", type: "address", value: "0x226bd47ff8a0743681d1ee059cd8d08401ff13c8"}, {name: "amount", type: "uint256", value: "10000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1548777600"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xed3998aa7f255ade06236776f9fd429eecc91357"}, {name: "locked", type: "address", value: "0xee10cbc4b5f2721ef73f6b31ea4a84b6e124f05f"}, {name: "amount", type: "uint256", value: "15000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1556553600"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xed3998aa7f255ade06236776f9fd429eecc91357"}, {name: "locked", type: "address", value: "0x861c0b73f9ba77d4074564fc2bbda687cd6b1ec1"}, {name: "amount", type: "uint256", value: "20000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1564416000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x1867812567f42e2da3c572be597996b1309593a7"}, {name: "locked", type: "address", value: "0x1e50a0fe49dee1bfecfc06794d5c0960bc97a134"}, {name: "amount", type: "uint256", value: "50000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1572364800"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x1867812567f42e2da3c572be597996b1309593a7"}, {name: "locked", type: "address", value: "0x797d8e1f3df917a8546ac447d155978bc691e77b"}, {name: "amount", type: "uint256", value: "50000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1588176000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x1867812567f42e2da3c572be597996b1309593a7"}, {name: "locked", type: "address", value: "0x582cbe7491197cfbff989aa4e4e97e17e87ad29f"}, {name: "amount", type: "uint256", value: "50000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1603987200"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x573c23f0ab4cff7ff09c0450e351b6bce4177df1"}, {name: "amount", type: "uint256", value: "45000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1554048000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x46e1886e826f27bbaa4a6645ad10183f52f68d36"}, {name: "amount", type: "uint256", value: "45000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1569859200"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x06ced26a22967ba69f7ec515bfb4467a1514b8c6"}, {name: "amount", type: "uint256", value: "40000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1585670400"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0xf7f162f923fb9b6bee453f83cc1f638701098f03"}, {name: "amount", type: "uint256", value: "40000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1601481600"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x940a9f252ae74df74c50203117e91431b573635d"}, {name: "amount", type: "uint256", value: "35000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1617206400"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x566b5e44b7a9cd379e0516f6e4c9740f03b6b5f5"}, {name: "amount", type: "uint256", value: "35000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1633017600"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0xe065b5b14c72679e1b1fa34b55d3f51313748f0a"}, {name: "amount", type: "uint256", value: "30000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1648742400"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x09c8282b27f3940b1928ad772fd017526fc81f77"}, {name: "amount", type: "uint256", value: "30000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1664553600"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0xa23775f69e9b629da1e25096c91f17634dfe9e0f"}, {name: "amount", type: "uint256", value: "25000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1680278400"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x9777ad4dfa9d644912af1731070f58722bb4fe65"}, {name: "amount", type: "uint256", value: "25000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1696089600"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0x885a1b905591016551d9a61347ffcf5147d9c2fb"}, {name: "amount", type: "uint256", value: "25000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1711900800"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "TransferWithLock", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7549be7449aa2b7d708d39481fcbb618c9fb903"}, {name: "locked", type: "address", value: "0xc70eeb1e5325b8332259ff4c477d75beb7dd8fe7"}, {name: "amount", type: "uint256", value: "25000000000000000000000000"}, {name: "releaseTime", type: "uint256", value: "1727712000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[0,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[0,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "value", type: "uint256", value: "100000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x03a59d08980a5327a958860e346d020ec8bb33dc"}, {name: "value", type: "uint256", value: "100000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xc138d62b3e34391964852cf712454492dc7eff68"}, {name: "value", type: "uint256", value: "200000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xbe0676dba429dc65cef0e55b2b4562cae79e8dda"}, {name: "value", type: "uint256", value: "5000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x226bd47ff8a0743681d1ee059cd8d08401ff13c8"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xee10cbc4b5f2721ef73f6b31ea4a84b6e124f05f"}, {name: "value", type: "uint256", value: "15000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x861c0b73f9ba77d4074564fc2bbda687cd6b1ec1"}, {name: "value", type: "uint256", value: "20000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x1e50a0fe49dee1bfecfc06794d5c0960bc97a134"}, {name: "value", type: "uint256", value: "50000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x797d8e1f3df917a8546ac447d155978bc691e77b"}, {name: "value", type: "uint256", value: "50000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x582cbe7491197cfbff989aa4e4e97e17e87ad29f"}, {name: "value", type: "uint256", value: "50000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x573c23f0ab4cff7ff09c0450e351b6bce4177df1"}, {name: "value", type: "uint256", value: "45000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x46e1886e826f27bbaa4a6645ad10183f52f68d36"}, {name: "value", type: "uint256", value: "45000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x06ced26a22967ba69f7ec515bfb4467a1514b8c6"}, {name: "value", type: "uint256", value: "40000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xf7f162f923fb9b6bee453f83cc1f638701098f03"}, {name: "value", type: "uint256", value: "40000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x940a9f252ae74df74c50203117e91431b573635d"}, {name: "value", type: "uint256", value: "35000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x566b5e44b7a9cd379e0516f6e4c9740f03b6b5f5"}, {name: "value", type: "uint256", value: "35000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xe065b5b14c72679e1b1fa34b55d3f51313748f0a"}, {name: "value", type: "uint256", value: "30000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x09c8282b27f3940b1928ad772fd017526fc81f77"}, {name: "value", type: "uint256", value: "30000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xa23775f69e9b629da1e25096c91f17634dfe9e0f"}, {name: "value", type: "uint256", value: "25000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x9777ad4dfa9d644912af1731070f58722bb4fe65"}, {name: "value", type: "uint256", value: "25000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0x885a1b905591016551d9a61347ffcf5147d9c2fb"}, {name: "value", type: "uint256", value: "25000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xd1c6fec0167153994e34715bb67488b59a2623b4"}, {name: "to", type: "address", value: "0xc70eeb1e5325b8332259ff4c477d75beb7dd8fe7"}, {name: "value", type: "uint256", value: "25000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[0,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3080474955926393620" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6559603", timeStamp: "1540170792", hash: "0x19f30f142cde682886a624cec63a1b992e6a90e14e10076cf1af693ddcb53738", nonce: "0", blockHash: "0xff29b161fff3ccf72069d70decb99ffc05786121b6dd8ce25aef4d7e631609d6", transactionIndex: "15", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52381", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000001983b354f47b82975a897b30e958f84b6deb61c60000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "412236", gasUsed: "52381", confirmations: "1166512"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540170792 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x1983b354f47b82975a897b30e958f84b6deb61c6"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[1,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6573374", timeStamp: "1540365297", hash: "0x89fff225d6f709a38e809ed9d4773532470a9229b6c011f3f8f0eeb38dadc79b", nonce: "10", blockHash: "0xf917f0ded16d0b4e48955bb8527c946dc708af40ab1d7451cff4dbad13917763", transactionIndex: "171", from: "0x1983b354f47b82975a897b30e958f84b6deb61c6", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000528db6c82ffa8fccc5e13bf35571dd87c11124e30000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6505046", gasUsed: "37381", confirmations: "1152741"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540365297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1983b354f47b82975a897b30e958f84b6deb61c6"}, {name: "to", type: "address", value: "0x528db6c82ffa8fccc5e13bf35571dd87c11124e3"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[2,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "8612282156250000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: transferWithLock( addressList[10], \"500000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6573400", timeStamp: "1540365656", hash: "0x67b21160a9c63908998602d07ea6011c1bc2efed7ea147c3e2de1ac513464f93", nonce: "3", blockHash: "0x1992bbde77a2cef3a38d5a6ac031a25a485d4adc86e0157513bc2828f5533f2b", transactionIndex: "41", from: "0x528db6c82ffa8fccc5e13bf35571dd87c11124e3", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "517144", gasPrice: "8950000000", isError: "0", txreceipt_status: "1", input: "0xde6baccb0000000000000000000000001983b354f47b82975a897b30e958f84b6deb61c600000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000005bd02680", contractAddress: "", cumulativeGasUsed: "1640086", gasUsed: "344763", confirmations: "1152715"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "500000000000000000"}, {type: "uint256", name: "_releaseTime", value: "1540368000"}], name: "transferWithLock", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferWithLock(address,uint256,uint256)" ]( addressList[10], "500000000000000000", "1540368000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540365656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "locked", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "releaseTime", type: "uint256"}], name: "TransferWithLock", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferWithLock", events: [{name: "from", type: "address", value: "0x528db6c82ffa8fccc5e13bf35571dd87c11124e3"}, {name: "to", type: "address", value: "0x1983b354f47b82975a897b30e958f84b6deb61c6"}, {name: "locked", type: "address", value: "0xd06259bf4411c9abc1c85e2f9fec03d55de61be5"}, {name: "amount", type: "uint256", value: "500000000000000000"}, {name: "releaseTime", type: "uint256", value: "1540368000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x528db6c82ffa8fccc5e13bf35571dd87c11124e3"}, {name: "to", type: "address", value: "0xd06259bf4411c9abc1c85e2f9fec03d55de61be5"}, {name: "value", type: "uint256", value: "500000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "314296086337048123" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6604900", timeStamp: "1540810701", hash: "0x35cf53e82413a017f0e889c009ca0851e3f71ef8cb61a5a66600664d01f0b31b", nonce: "1", blockHash: "0x95f4d6269e133443c70c7efc5dfafb0025258e1684f1fe031c7e15ec7cb61656", transactionIndex: "14", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000953588c1ab5726d632db8712a07b727f1e4041aa000000000000000000000000000000000000000000027b46536c66c8e3000000", contractAddress: "", cumulativeGasUsed: "444378", gasUsed: "52509", confirmations: "1121215"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "3000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "3000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540810701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "value", type: "uint256", value: "3000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[4,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"825000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6609284", timeStamp: "1540872506", hash: "0x571d0b2939b8776b9c2858bb90098e34f4c540208c0d72d8f09491eb564adbae", nonce: "5", blockHash: "0x07d84baab3b5a6d26e96f8fae85b146aeb1d3002f825e160e24e7d3c2ebf03bd", transactionIndex: "186", from: "0x953588c1ab5726d632db8712a07b727f1e4041aa", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "7100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000006b1ff08a928353e0fbf432d16a285064d3b0b57900000000000000000000000000000000000000000000aeb356f102aa71a00000", contractAddress: "", cumulativeGasUsed: "7684822", gasUsed: "52509", confirmations: "1116831"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "825000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "825000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540872506 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "to", type: "address", value: "0x6b1ff08a928353e0fbf432d16a285064d3b0b579"}, {name: "value", type: "uint256", value: "825000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8622820663211726719" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6610115", timeStamp: "1540884026", hash: "0x3b29a50d6070fbd01bbf78f57f78eeba9011ca6540974cf153bf8403a107b14e", nonce: "6", blockHash: "0x1448ffd36d50cb5870663ad24900d31cbae41de18fd599b8c1ff3f16660454ea", transactionIndex: "132", from: "0x953588c1ab5726d632db8712a07b727f1e4041aa", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "6600000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000ed876e03b1db47afe4d4c0f4e20783578810ed980000000000000000000000000000000000000000000034f086f3b33b68400000", contractAddress: "", cumulativeGasUsed: "6105213", gasUsed: "52509", confirmations: "1116000"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "250000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[14], "250000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540884026 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "to", type: "address", value: "0xed876e03b1db47afe4d4c0f4e20783578810ed98"}, {name: "value", type: "uint256", value: "250000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8622820663211726719" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6610120", timeStamp: "1540884087", hash: "0x9dac01aa14e29decbd4ffe178fdf4fd08147a143e88660c3328b1b2ebbb88161", nonce: "7", blockHash: "0x545104dab71b0313ed5b5e95cc0a7b4a900d527eab2918efe8f4660ddfaf8caf", transactionIndex: "79", from: "0x953588c1ab5726d632db8712a07b727f1e4041aa", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "6600000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000007869c58e25d30ec8e90cf9a6705cded1a0ed9493000000000000000000000000000000000000000000003f870857a3e0e3800000", contractAddress: "", cumulativeGasUsed: "5496326", gasUsed: "52509", confirmations: "1115995"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "300000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "300000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540884087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "to", type: "address", value: "0x7869c58e25d30ec8e90cf9a6705cded1a0ed9493"}, {name: "value", type: "uint256", value: "300000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8622820663211726719" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"275000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612278", timeStamp: "1540914315", hash: "0x51759e7659a941ff8b234d33007552a04c7689e272a8331167b80661f6149064", nonce: "2", blockHash: "0x7f74add43806e697b245d46a6f9cedf0bc0749487fad86f6930cfddeae3cd147", transactionIndex: "35", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003177cd3a0c3bc48066ab81436b8a855f1c0d2d18000000000000000000000000000000000000000000003a3bc7a5ab8e25e00000", contractAddress: "", cumulativeGasUsed: "1041533", gasUsed: "52509", confirmations: "1113837"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "275000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "275000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540914315 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x3177cd3a0c3bc48066ab81436b8a855f1c0d2d18"}, {name: "value", type: "uint256", value: "275000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612289", timeStamp: "1540914455", hash: "0x4233f438d83dd503429564da0628144dfb305f0cbadca8a1022a81849b3df21e", nonce: "3", blockHash: "0x887fa6ee00f3667596ec876aa5db5a9b326ace0e00151a083272d3eeb80e3ac2", transactionIndex: "26", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a75917a5141513dcd761ccf55624ef201df823f500000000000000000000000000000000000000000000010f0cf064dd59200000", contractAddress: "", cumulativeGasUsed: "754649", gasUsed: "52509", confirmations: "1113826"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "5000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "5000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540914455 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0xa75917a5141513dcd761ccf55624ef201df823f5"}, {name: "value", type: "uint256", value: "5000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612297", timeStamp: "1540914518", hash: "0x58ca790f9ea720342449cf2270a8a520447208297bc13c22f8501dad88e305da", nonce: "4", blockHash: "0x3fa3ea3159512699c9bedfcdd6b3330e5cb85a508405fde65b8f4ea971292534", transactionIndex: "15", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52445", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002b813b974200dbdf9ff6a01ed01e20c3f008060e000000000000000000000000000000000000000000000a968163f0a57b400000", contractAddress: "", cumulativeGasUsed: "482378", gasUsed: "52445", confirmations: "1113818"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "50000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "50000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540914518 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x2b813b974200dbdf9ff6a01ed01e20c3f008060e"}, {name: "value", type: "uint256", value: "50000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[19], \"380000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612304", timeStamp: "1540914591", hash: "0xb8a5d7ccebd5f75e4ceb7ab6dcfc14626625b688ea6788759dcc98eb7b0ac301", nonce: "5", blockHash: "0x1af464dac0d555260aa9386a9fbbeb328e44afa32b86240cc0c19b545d465e32", transactionIndex: "41", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b97afe0315472b31b853669a14fdedaba4e2e770000000000000000000000000000000000000000000005077d75df1b675800000", contractAddress: "", cumulativeGasUsed: "1748524", gasUsed: "52509", confirmations: "1113811"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "380000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[19], "380000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540914591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0xb97afe0315472b31b853669a14fdedaba4e2e770"}, {name: "value", type: "uint256", value: "380000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612309", timeStamp: "1540914680", hash: "0x66da099f665291dfbd3665e9332ee11a9428600a12ba381a503e5d3e7a30e4bc", nonce: "6", blockHash: "0x358baf0c7106ab27a6a69986f85452c4e470b1ba372d843698b127e650981a21", transactionIndex: "31", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000fbb122f3235b17107980b7c9c6d283c1d0cb9ab5000000000000000000000000000000000000000000000a968163f0a57b400000", contractAddress: "", cumulativeGasUsed: "1037156", gasUsed: "52509", confirmations: "1113806"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "50000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "50000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540914680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0xfbb122f3235b17107980b7c9c6d283c1d0cb9ab5"}, {name: "value", type: "uint256", value: "50000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[21], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612312", timeStamp: "1540914730", hash: "0xc77772a11ee0150fb947766b596fada70ef86734dc228e2e671c0541f28f6faf", nonce: "7", blockHash: "0xe3e7cca59d6fa94788d68df15cf8aa02e8f4dbdeea7637ab78d6942d339b8df9", transactionIndex: "127", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000aa8e8231ddd064fbeee82a9ce7550fbca4131c01000000000000000000000000000000000000000000001fc3842bd1f071c00000", contractAddress: "", cumulativeGasUsed: "4462435", gasUsed: "52509", confirmations: "1113803"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "150000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[21], "150000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540914730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0xaa8e8231ddd064fbeee82a9ce7550fbca4131c01"}, {name: "value", type: "uint256", value: "150000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"700000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612320", timeStamp: "1540914855", hash: "0x128a451f0ae8a5110b21a0f4121067c1572f92e85a9e8a205f35571d346c094a", nonce: "8", blockHash: "0x05878772d5260ed428f41d24fb436d8e2ea796ac55dd7dc546a462985fb82b64", transactionIndex: "6", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000672028322808be55cb7af17e26e8d34c09d9b6df000000000000000000000000000000000000000000000ed2b525841adfc00000", contractAddress: "", cumulativeGasUsed: "274492", gasUsed: "52509", confirmations: "1113795"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "70000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "70000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540914855 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x672028322808be55cb7af17e26e8d34c09d9b6df"}, {name: "value", type: "uint256", value: "70000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"115000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612324", timeStamp: "1540914923", hash: "0xbc4504001471d2e2fb62a26b3d9f39c5bcc83a8cfb0728750847cf0b37a93af7", nonce: "9", blockHash: "0xf2fccfdad6724a02f18a543f9212a492563e8572ec4657d19ac6eb138df42021", transactionIndex: "17", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003089caad545fc57292265674d3c748e8c86211e400000000000000000000000000000000000000000000185a29990fe301e00000", contractAddress: "", cumulativeGasUsed: "866878", gasUsed: "52509", confirmations: "1113791"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "115000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "115000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540914923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x3089caad545fc57292265674d3c748e8c86211e4"}, {name: "value", type: "uint256", value: "115000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612333", timeStamp: "1540914991", hash: "0xe0bf60678ba4fc3d10a42002ac5e613b34ce8b8d26b87e58d41f907c7992cf3b", nonce: "10", blockHash: "0x8db1a7a1ab374b90266bbd8eee9c525e9d8843db47e34bc89414f828e4c358aa", transactionIndex: "32", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "37509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000672028322808be55cb7af17e26e8d34c09d9b6df00000000000000000000000000000000000000000000043c33c1937564800000", contractAddress: "", cumulativeGasUsed: "1235400", gasUsed: "37509", confirmations: "1113782"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "20000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "20000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540914991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x672028322808be55cb7af17e26e8d34c09d9b6df"}, {name: "value", type: "uint256", value: "20000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612345", timeStamp: "1540915172", hash: "0x8c1d159173c04f123f6513deabc0f31677a7737a774ed67ccc24a78f5850bf2e", nonce: "11", blockHash: "0xc0b4d44b9554928ff4dc4111a00badbe096afffcb3a07f824df7ebbdc1f3b3e3", transactionIndex: "25", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000ab728419a0f2fb4ff2d5eff47b55697467b0a251000000000000000000000000000000000000000000009ed194db19b238c00000", contractAddress: "", cumulativeGasUsed: "874083", gasUsed: "52509", confirmations: "1113770"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "750000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "750000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540915172 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0xab728419a0f2fb4ff2d5eff47b55697467b0a251"}, {name: "value", type: "uint256", value: "750000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"325000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612351", timeStamp: "1540915298", hash: "0x10dfca7b14b45a0bac5efb8f9da4e50ce7b6c3b934f8490da1816e6d384c77ce", nonce: "12", blockHash: "0xe4d57422f55b2fbf80e5d163ed7f66df7b303f63a1050d6bbbba2ac4bd2ecf91", transactionIndex: "35", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000004c0c09fa931c9e818b82f17b9351d7d6d34350530000000000000000000000000000000000000000000044d249099c33a1200000", contractAddress: "", cumulativeGasUsed: "1506947", gasUsed: "52509", confirmations: "1113764"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "325000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "325000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540915298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "value", type: "uint256", value: "325000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612356", timeStamp: "1540915377", hash: "0x49169652823f08fd48115e15aebf8620dae435305a2182b1ad0b33c7a0297249", nonce: "13", blockHash: "0xfbcd02c3422d9240b85aa81a8be58e6011b7bd55e5eebf89e59acec4b8ca86a7", transactionIndex: "81", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52445", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a67f72e8782e8a2eb10c027a083d2d11174693f8000000000000000000000000000000000000000000002a5a058fc295ed000000", contractAddress: "", cumulativeGasUsed: "2400869", gasUsed: "52445", confirmations: "1113759"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "200000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "200000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540915377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0xa67f72e8782e8a2eb10c027a083d2d11174693f8"}, {name: "value", type: "uint256", value: "200000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612361", timeStamp: "1540915472", hash: "0x3ed9826e763880ae3061eb4bc1cb6ffdd9f6f4f95d0130d8064429fa5ab0082b", nonce: "14", blockHash: "0xdbca2cf7cd222c7234b00909137f6ba1d0a89bd9a3438b1be96c60a3e13ace1a", transactionIndex: "4", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000709bcd6cbc1b8b1d709e2d4933daacb0e5cf731a00000000000000000000000000000000000000000000152d02c7e14af6800000", contractAddress: "", cumulativeGasUsed: "168487", gasUsed: "52509", confirmations: "1113754"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "100000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "100000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540915472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x709bcd6cbc1b8b1d709e2d4933daacb0e5cf731a"}, {name: "value", type: "uint256", value: "100000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612364", timeStamp: "1540915536", hash: "0x6e1c70fa9589b1d9f9265a35e8e6f4d8d98cb5c08766b3db6264abde25d5ea10", nonce: "15", blockHash: "0xa1a7eda557b27b8a233a3b18a7388ae5e40b5f080c93768f0afc2b7f0394f429", transactionIndex: "8", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52445", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000be3e2e3234423118d571c1d9ae61b364d590a72000000000000000000000000000000000000000000002a5a058fc295ed000000", contractAddress: "", cumulativeGasUsed: "348485", gasUsed: "52445", confirmations: "1113751"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "200000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "200000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540915536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x0be3e2e3234423118d571c1d9ae61b364d590a72"}, {name: "value", type: "uint256", value: "200000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612371", timeStamp: "1540915606", hash: "0xe20b1c4b8714231bb1a8057849e019c8cd8cbc19d0da838bdf005ba324bb20bb", nonce: "16", blockHash: "0x7922ce65df93be8a9b6258dc28bc03b7c1c13f700d0c1d449f5722411fade518", transactionIndex: "20", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000df64cabf819e84d4bb0de2bdde72fc947fd4e886000000000000000000000000000000000000000000000a968163f0a57b400000", contractAddress: "", cumulativeGasUsed: "759131", gasUsed: "52509", confirmations: "1113744"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "50000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "50000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540915606 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0xdf64cabf819e84d4bb0de2bdde72fc947fd4e886"}, {name: "value", type: "uint256", value: "50000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6615474", timeStamp: "1540959970", hash: "0x9b949f0bbb21c74c307dc0cb4457a53284db63fb9953fd32f5f47e6af4f0e609", nonce: "17", blockHash: "0xa009ba2c1909cd875495d799d41c3b1a4bc286cdd334e1caa7758570f6c3d9cf", transactionIndex: "76", from: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000009f50d63241a72c6b3fc11777e2d3511358f6483000000000000000000000000000000000000000000001fc3842bd1f071c00000", contractAddress: "", cumulativeGasUsed: "1689028", gasUsed: "52509", confirmations: "1110641"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "150000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "150000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540959970 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x252c4f77f1cdccebaebbce393804f4c8f3d5703d"}, {name: "to", type: "address", value: "0x09f50d63241a72c6b3fc11777e2d3511358f6483"}, {name: "value", type: "uint256", value: "150000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "68956877100000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"600000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6616422", timeStamp: "1540972792", hash: "0xa875fcbb9e31aa9865352ba90fabadca9f46585325e13a4f06d760bb101eeaec", nonce: "6", blockHash: "0xfb4cb538ce3470933a4fe2a64cd147081fe7f2793779cbd7837baad50d0cd601", transactionIndex: "73", from: "0x672028322808be55cb7af17e26e8d34c09d9b6df", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a75917a5141513dcd761ccf55624ef201df823f500000000000000000000000000000000000000000000014542ba12a337c00000", contractAddress: "", cumulativeGasUsed: "3429701", gasUsed: "37509", confirmations: "1109693"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "6000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "6000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540972792 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x672028322808be55cb7af17e26e8d34c09d9b6df"}, {name: "to", type: "address", value: "0xa75917a5141513dcd761ccf55624ef201df823f5"}, {name: "value", type: "uint256", value: "6000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "11379908951158047" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6623153", timeStamp: "1541068652", hash: "0x33dbd7bac461ea04cf51712a1c9fbf629b58218aaebd2878a7d78fde833b6f35", nonce: "8", blockHash: "0x3e68f5e9a28b1720f54dd07a10ad22e7c9772c8c18d14c32e559a9e1a6f4947f", transactionIndex: "92", from: "0x953588c1ab5726d632db8712a07b727f1e4041aa", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000f02a6c0d55d87359f25539d9cd0c311cd01218c00000000000000000000000000000000000000000000152d02c7e14af6800000", contractAddress: "", cumulativeGasUsed: "3533235", gasUsed: "52509", confirmations: "1102962"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "100000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[31], "100000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541068652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "to", type: "address", value: "0x0f02a6c0d55d87359f25539d9cd0c311cd01218c"}, {name: "value", type: "uint256", value: "100000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8622820663211726719" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[32], \"450000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725863", timeStamp: "1542522880", hash: "0x6ca00db2d8cf454276aec39daa38a450b2c7661b8bac1adb9fb6715136396d3c", nonce: "3", blockHash: "0xe98a153dc7e07409504e166af8f8a73c98f1da1a0726319f16f8de22cae62c9d", transactionIndex: "120", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002ef9c006162f916fe4589a82227d22add5a5baaa0000000000000000000000000000000000000000000000f3f20b8dfa69d00000", contractAddress: "", cumulativeGasUsed: "5631131", gasUsed: "52445", confirmations: "1000252"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "4500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[32], "4500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542522880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0x2ef9c006162f916fe4589a82227d22add5a5baaa"}, {name: "value", type: "uint256", value: "4500000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[33], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725898", timeStamp: "1542523272", hash: "0x923951a9d35e2e6bb22847ac40773f07bc418c124e1a8b560ec524015534a7f9", nonce: "4", blockHash: "0xcdb29f54b33b076465babea9b71b72954e1dd2e9c28a2552172ecd299ae2f05a", transactionIndex: "155", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "7000000001", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d38ed463d6a66b6798786c681d6a92c8c1227f0d00000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "7574708", gasUsed: "52509", confirmations: "1000217"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_value", value: "10000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[33], "10000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542523272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0xd38ed463d6a66b6798786c681d6a92c8c1227f0d"}, {name: "value", type: "uint256", value: "10000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725910", timeStamp: "1542523449", hash: "0xd3bff4eb38dddd8cb2a344cbc3807d7f2bdfc03845496167e7e20b8643da658e", nonce: "5", blockHash: "0xdd862880d6b98910a3077633a5826dfb9e48c22d63fe3ccfc1191f186b9b2eeb", transactionIndex: "135", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000005d4342d6f15f40ba91067c996a355738aa82702100000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "6942590", gasUsed: "52509", confirmations: "1000205"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "10000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "10000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542523449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0x5d4342d6f15f40ba91067c996a355738aa827021"}, {name: "value", type: "uint256", value: "10000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[35], \"600000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725923", timeStamp: "1542523631", hash: "0xbb6fbd9745bdf5a931faa77ccb791bee20c52ca6c03985d23bebac05921da9cd", nonce: "6", blockHash: "0x45aa08850dd63282fb6e97dd34355c0d05d33fde89823d0a7da788803bd0d283", transactionIndex: "23", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000458b647287ffd7640894afd3ad4efa0b154d82d100000000000000000000000000000000000000000000014542ba12a337c00000", contractAddress: "", cumulativeGasUsed: "1069866", gasUsed: "52509", confirmations: "1000192"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_value", value: "6000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[35], "6000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542523631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0x458b647287ffd7640894afd3ad4efa0b154d82d1"}, {name: "value", type: "uint256", value: "6000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[36], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725941", timeStamp: "1542523803", hash: "0x43d5a9615fa39e15aa933c1ad9d521c31ef3d0d68a6f1639c84c982bdce2943f", nonce: "7", blockHash: "0xb917f60405d17dfcbeb0f52f4b98ef96aaa047ffd720c38eeb1e9c6860823e45", transactionIndex: "9", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000019cde35ef2119349abff30601251cc4487e44df300000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "510475", gasUsed: "52445", confirmations: "1000174"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_value", value: "1000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[36], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542523803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0x19cde35ef2119349abff30601251cc4487e44df3"}, {name: "value", type: "uint256", value: "1000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725946", timeStamp: "1542523857", hash: "0x7a6ea89cdbfe1f1d9565271d7c68d553f2932735486d779754278d7c836281c3", nonce: "8", blockHash: "0x1c5c056f3be3227b120b777a882d33d37ec5907b98f7b8f82cb58f792d54d791", transactionIndex: "38", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d79b11eb6bd24455a59fc5c2c570e9b37eb670fb00000000000000000000000000000000000000000000010f0cf064dd59200000", contractAddress: "", cumulativeGasUsed: "2392246", gasUsed: "52509", confirmations: "1000169"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "5000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "5000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542523857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0xd79b11eb6bd24455a59fc5c2c570e9b37eb670fb"}, {name: "value", type: "uint256", value: "5000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[38], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725951", timeStamp: "1542523929", hash: "0x5fd5132066979a29eae0467ced1fd10c3e2602c1e4649195b3177781078eb619", nonce: "9", blockHash: "0xf8f97a2c692be2483d21ba97dbcd4f9171f451cbf7abf72f5304e7d02be8b61f", transactionIndex: "51", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000003d560ce1a72a8c411fc422a4675844d1f39a27700000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "2107476", gasUsed: "52445", confirmations: "1000164"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[38], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542523929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0x03d560ce1a72a8c411fc422a4675844d1f39a277"}, {name: "value", type: "uint256", value: "500000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6725969", timeStamp: "1542524068", hash: "0x7f7a6c2d3f263d7c59dc08dd536a1aec45f1d575ac1f4f9479be88c219213bf4", nonce: "10", blockHash: "0x03de9c17a673d82598c54f95b0736bf5c3537b3ddb36e7d9e697840adff85f05", transactionIndex: "62", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000008d337ad819e3cd7a5d2b6c0e7875ce568038943000000000000000000000000000000000000000000000032d26d12e980b600000", contractAddress: "", cumulativeGasUsed: "5725936", gasUsed: "52509", confirmations: "1000146"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "15000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[39], "15000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542524068 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0x8d337ad819e3cd7a5d2b6c0e7875ce5680389430"}, {name: "value", type: "uint256", value: "15000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"215200000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6835690", timeStamp: "1544086343", hash: "0x173fa240e0b9367303199cdc02fb695392c4f5075869330f381f12e82716ff16", nonce: "0", blockHash: "0x27a71be3c02077edbdb9ca12ae1dd9249ce20976d565d2a57cc7864f56d29ebb", transactionIndex: "21", from: "0xc138d62b3e34391964852cf712454492dc7eff68", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "52509", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000030dfd9f863fbd252c99c9bf169ef6d3b5deedd3800000000000000000000000000000000000000000001c7b4275cc75771000000", contractAddress: "", cumulativeGasUsed: "798810", gasUsed: "52509", confirmations: "890425"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "2152000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[40], "2152000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544086343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc138d62b3e34391964852cf712454492dc7eff68"}, {name: "to", type: "address", value: "0x30dfd9f863fbd252c99c9bf169ef6d3b5deedd38"}, {name: "value", type: "uint256", value: "2152000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "178798695000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[41], \"730000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6840362", timeStamp: "1544153445", hash: "0x8819c1b88888cb192f0890f19045801e1ff4d09fcf2bf9d955d8b2e4934ab594", nonce: "29", blockHash: "0x33b49b2717ae514db568ad01c10ef5683facd670f2c3c21767a868b327fd0602", transactionIndex: "128", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "12210000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000f13d44eb7bdb2e75c4cffb3dbd10e1e0103a169100000000000000000000000000000000000000000000018bbbd9daf13f900000", contractAddress: "", cumulativeGasUsed: "4139603", gasUsed: "52509", confirmations: "885753"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_value", value: "7300000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[41], "7300000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544153445 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0xf13d44eb7bdb2e75c4cffb3dbd10e1e0103a1691"}, {name: "value", type: "uint256", value: "7300000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[42], \"325000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6840483", timeStamp: "1544155104", hash: "0x63df4531185df52720084672122485baa0bc6aa20834c574c43c392968a1d457", nonce: "30", blockHash: "0xd6082a0579c6781e7609a23ec0e395575d6e2a29013584b8bb118f273f6dcf62", transactionIndex: "147", from: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "11430000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000008dff5ed8e49a0ce2fad0de640d644450113b4000000000000000000000000000000000000000000000000b02ecf74c313880000", contractAddress: "", cumulativeGasUsed: "7388554", gasUsed: "52381", confirmations: "885632"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "3250000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[42], "3250000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544155104 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x4c0c09fa931c9e818b82f17b9351d7d6d3435053"}, {name: "to", type: "address", value: "0x08dff5ed8e49a0ce2fad0de640d644450113b400"}, {name: "value", type: "uint256", value: "3250000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "842008116035072491" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[43], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6847805", timeStamp: "1544260613", hash: "0xb81fdd6096061cfecece7bdc024637871bc384bd52778c86b10aebdfa7b4cbeb", nonce: "9", blockHash: "0x68dcb303ec26393fe0e89c97ff31da5b6c674baed8f1a380b4c776fbbb24376e", transactionIndex: "84", from: "0x953588c1ab5726d632db8712a07b727f1e4041aa", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d10d09883d4da6ff7e75f8fdb32b82c24485ed9b00000000000000000000000000000000000000000000021e19e0c9bab2400000", contractAddress: "", cumulativeGasUsed: "3703242", gasUsed: "52509", confirmations: "878310"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "10000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[43], "10000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544260613 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "to", type: "address", value: "0xd10d09883d4da6ff7e75f8fdb32b82c24485ed9b"}, {name: "value", type: "uint256", value: "10000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8622820663211726719" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6847909", timeStamp: "1544262124", hash: "0xa9c66eb35f6ba8c84adeb8f79bf6f4836d7196ca4f65afd973ad3454d901549d", nonce: "0", blockHash: "0x90e75fe5cc87124f6748e0a1a9c2ba42b31fc3ef8cd04a8726b83061a5aeac81", transactionIndex: "42", from: "0xd10d09883d4da6ff7e75f8fdb32b82c24485ed9b", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000953588c1ab5726d632db8712a07b727f1e4041aa00000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "3544365", gasUsed: "37445", confirmations: "878206"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "1000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544262124 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xd10d09883d4da6ff7e75f8fdb32b82c24485ed9b"}, {name: "to", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "value", type: "uint256", value: "1000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "9662995000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[44], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6859624", timeStamp: "1544427616", hash: "0x3856cd82198734585d9a11ee7f6ccadec33439f537ddee54062ffeef463c7b5b", nonce: "11", blockHash: "0x2e3332fe7477ac40ff327e3a4ce503bffaeecf626a9594c03813ed54012fab9d", transactionIndex: "171", from: "0x953588c1ab5726d632db8712a07b727f1e4041aa", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "6045000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000c24a4d55a9006f0a40420188e5a43a6d1d61ca5b0000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "6051353", gasUsed: "52381", confirmations: "866491"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[44]}, {type: "uint256", name: "_value", value: "100000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[44], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544427616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "to", type: "address", value: "0xc24a4d55a9006f0a40420188e5a43a6d1d61ca5b"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8622820663211726719" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6864216", timeStamp: "1544492747", hash: "0x4dd78a4d6a8305c4e5af2ff0edbda2f8d52c7eb9e3fe6613173a762581210732", nonce: "30", blockHash: "0xd9dd039971be4b9988f2a66243386a82dd20bcad4719c100936fb1f4a55dc70b", transactionIndex: "19", from: "0xc24a4d55a9006f0a40420188e5a43a6d1d61ca5b", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "157335", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000bc9390ce3e6510ae6523e41bfbf290e317d56ec0000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "526431", gasUsed: "37445", confirmations: "861899"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "100000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544492747 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc24a4d55a9006f0a40420188e5a43a6d1d61ca5b"}, {name: "to", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "61493570300000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6864311", timeStamp: "1544493949", hash: "0x89b43ecfef7a7ce916b4018f31872335105d87938fe3a2401409fb07764356b6", nonce: "7278", blockHash: "0x4bb2d8452121726086af2baae7931070bdf2a2d7dc42b44ec1be372eab95f519", transactionIndex: "12", from: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "157143", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000073e424f9bc661286e9a96e5c28a9f88338e169ea0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "489723", gasUsed: "52381", confirmations: "861804"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[46], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544493949 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "to", type: "address", value: "0x73e424f9bc661286e9a96e5c28a9f88338e169ea"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "94966556152371919073" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6864326", timeStamp: "1544494223", hash: "0x0f64c9084e55d9c3c9fc674ae056ae45da1a0e742d923b42aa32f9c9bac1d367", nonce: "29", blockHash: "0xdf22f8847f0202b7f0105ec14900379cc5e7153ec80b2284a8560b0ab1b73663", transactionIndex: "56", from: "0x73e424f9bc661286e9a96e5c28a9f88338e169ea", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "112143", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000bc9390ce3e6510ae6523e41bfbf290e317d56ec0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "4356824", gasUsed: "22381", confirmations: "861789"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544494223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73e424f9bc661286e9a96e5c28a9f88338e169ea"}, {name: "to", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "26326116200000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"98000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6864359", timeStamp: "1544494760", hash: "0x3b82f55ce0ae4f1c4c22303b1d6384fe90a5f0e724be73d3edb27de1cbdd17c9", nonce: "7279", blockHash: "0xc70a89cb685f78d8b5f1670c4efb0121a138947e40e5b745b5004dca615eb866", transactionIndex: "9", from: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "157335", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000073e424f9bc661286e9a96e5c28a9f88338e169ea0000000000000000000000000000000000000000000000055005f0c614480000", contractAddress: "", cumulativeGasUsed: "591072", gasUsed: "52445", confirmations: "861756"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "98000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[46], "98000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544494760 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "to", type: "address", value: "0x73e424f9bc661286e9a96e5c28a9f88338e169ea"}, {name: "value", type: "uint256", value: "98000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "98803858152371919073" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"98000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6864373", timeStamp: "1544494955", hash: "0x46e5703782eae4748016ca5b454391d984edb974877e82b98d946632a2ad568f", nonce: "30", blockHash: "0x4cebdeabc2d6abcb790b45926f2854d4db8dc06ba869b9675c21f5c5c1f51005", transactionIndex: "47", from: "0x73e424f9bc661286e9a96e5c28a9f88338e169ea", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "112335", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000bc9390ce3e6510ae6523e41bfbf290e317d56ec0000000000000000000000000000000000000000000000055005f0c614480000", contractAddress: "", cumulativeGasUsed: "2001205", gasUsed: "22445", confirmations: "861742"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "98000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "98000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544494955 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73e424f9bc661286e9a96e5c28a9f88338e169ea"}, {name: "to", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "value", type: "uint256", value: "98000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[44,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "26326116200000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[44], \"98000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6864409", timeStamp: "1544495428", hash: "0x567512efa600f2ada26007836ac40c481dc942bda347a580e01f88f34f278621", nonce: "7280", blockHash: "0xfeb6c1560b0b96046c5e01fc18c247e8c32086e4327794d8e98dcc253a68f296", transactionIndex: "82", from: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "157143", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000c24a4d55a9006f0a40420188e5a43a6d1d61ca5b0000000000000000000000000000000000000000000000055005f0c614480000", contractAddress: "", cumulativeGasUsed: "1927322", gasUsed: "52381", confirmations: "861706"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[44]}, {type: "uint256", name: "_value", value: "98000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[44], "98000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544495428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "to", type: "address", value: "0xc24a4d55a9006f0a40420188e5a43a6d1d61ca5b"}, {name: "value", type: "uint256", value: "98000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "98803858152371919073" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"98000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6864425", timeStamp: "1544495688", hash: "0xf208dea1d2e4dcb137b0d78a5b95890aeac88362135818eb4f86df0ebfc558a3", nonce: "31", blockHash: "0xfd544adf57596d1c116b0f2559efc4de9c0045f9b65ed6c4950da1a868606e22", transactionIndex: "37", from: "0xc24a4d55a9006f0a40420188e5a43a6d1d61ca5b", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "112335", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000bc9390ce3e6510ae6523e41bfbf290e317d56ec0000000000000000000000000000000000000000000000055005f0c614480000", contractAddress: "", cumulativeGasUsed: "1872764", gasUsed: "22445", confirmations: "861690"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "98000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "98000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544495688 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc24a4d55a9006f0a40420188e5a43a6d1d61ca5b"}, {name: "to", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "value", type: "uint256", value: "98000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "61493570300000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"215200000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6865491", timeStamp: "1544511444", hash: "0xcb56bded465a8d6e3721de51f685510b3ffcec5ec88bf2dcecc65c58fc1f07d9", nonce: "24", blockHash: "0xcfe6712ccf14a2b83edff8733ec2b282e46079136ebef77d6d681ead0ed605b7", transactionIndex: "105", from: "0x30dfd9f863fbd252c99c9bf169ef6d3b5deedd38", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "112527", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000bc9390ce3e6510ae6523e41bfbf290e317d56ec00000000000000000000000000000000000000000001c7b4275cc75771000000", contractAddress: "", cumulativeGasUsed: "3505468", gasUsed: "22509", confirmations: "860624"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "2152000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "2152000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544511444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x30dfd9f863fbd252c99c9bf169ef6d3b5deedd38"}, {name: "to", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "value", type: "uint256", value: "2152000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "65536107128000512" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6865950", timeStamp: "1544517897", hash: "0x55325a996e535a9f90f86afba8af308eaa8f317de5e4feea8b571f23a0cf5bde", nonce: "12", blockHash: "0x640ccb73bac500a0c92c4fb0063049c8d3607b8ef317e8fcee387e498b199ebe", transactionIndex: "76", from: "0x953588c1ab5726d632db8712a07b727f1e4041aa", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "60000", gasPrice: "8000200000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000030dfd9f863fbd252c99c9bf169ef6d3b5deedd3800000000000000000000000000000000000000000000d3c21bcecceda1000000", contractAddress: "", cumulativeGasUsed: "5378859", gasUsed: "52445", confirmations: "860165"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "1000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[40], "1000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544517897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x953588c1ab5726d632db8712a07b727f1e4041aa"}, {name: "to", type: "address", value: "0x30dfd9f863fbd252c99c9bf169ef6d3b5deedd38"}, {name: "value", type: "uint256", value: "1000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "8622820663211726719" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6865965", timeStamp: "1544518128", hash: "0xea9303ff59044eccd7e80f8a4d4e36c0aa96b9f421efdc1b845c095154a5bbac", nonce: "25", blockHash: "0x4ef9e286b7742eaedc78aa6cdd859fbd5e31e18aed743e4e68fd402dc4db6bd9", transactionIndex: "50", from: "0x30dfd9f863fbd252c99c9bf169ef6d3b5deedd38", to: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38", value: "0", gas: "112335", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000bc9390ce3e6510ae6523e41bfbf290e317d56ec00000000000000000000000000000000000000000000d3c21bcecceda1000000", contractAddress: "", cumulativeGasUsed: "1284224", gasUsed: "22445", confirmations: "860150"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "1000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "1000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544518128 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x30dfd9f863fbd252c99c9bf169ef6d3b5deedd38"}, {name: "to", type: "address", value: "0x0bc9390ce3e6510ae6523e41bfbf290e317d56ec"}, {name: "value", type: "uint256", value: "1000000000000000000000000"}], address: "0xfe3a06a947a036eff9f9e8ec25b385ff4e853c38"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "65536107128000512" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
