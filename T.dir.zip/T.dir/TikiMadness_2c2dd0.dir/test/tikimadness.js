const TikiMadness = artifacts.require( "./TikiMadness.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "TikiMadness" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xc094367B4c79564b6C8b4218f84DEa835b2C2dD0", "0x0e21902D93573C18FD0aCBadaC4A5464e9732F54", "0x556F99ff7D5F445f24437ce7c03a909Fc8BB650c", "0x93131eeB067d550f0b38c33EC30Dd28C806C2F43", "0x3C84c7285623e7F7539fF60D6f3Cf1c3CCcd868F", "0x494952f01a30547d269aaF147e6226f940f5B041", "0xBf92E4A68cc341915f571364EC8e261f810D06FE", "0x6Ed450e062C20F929CB7Ee72fCc53e9697980a18", "0xABCDEd3C9BD09729C23ac5d678659cecba6a8A0a", "0x2e6236591bfA37c683CE60d6cfDe40396A114fF1", "0x6629C7199EcC6764383dfB98B229AC8c540Fc76F", "0x190A2409fc6434483D4c2CAb804E75e3Bc5ebFa6", "0x9D9e6c1C81f4A70F9580aaB81e617AfcE66aa559", "0xD25BD6c44D6cF3C0358AB30ed5E89F2090409a79", "0x31228322429E78397fF094ccEBE9655F9e9A247F", "0xe7EcA2a94E9D59848f3c1E1fFaACD881D4C3A4F2", "0xD6EF90F002b659dBA6aae409ab45A94a88aC2dB9", "0x9a934F369d97461705982aF8f7637254198bFf81", "0xfAaECeEcFe58D9Bc2b3061ddC1A227Cf86062e32", "0x992F2864DAa339dDab9ec14003c3cCA1304bD6AA", "0xF897CA9906f10d0a2049321d745AD3b055875924", "0xc951D3463EbBa4e9Ec8dDfe1f42bc5895C46eC8f", "0xC377eD09eD1bBfE9E3E64Fad2fce408A960e864A", "0x262f8c7B80471B26C5f84471772767fa41360D1F", "0x163916bcB80eA6c0D5ea0e6af14aE9069EFc438D", "0x0982a0bf061f3cec2a004b4d2c802F479099C971", "0xE4042aE1C40913bA00619392DE669BdB3becEd50", "0xeb5691310C3977aB4dD93b9830fA69aFBe4940fB", "0xCD75C47B2Ec49E92cC673269B53d1A75D023DfC9", "0x147B7D92C6385B4E4f4c9BD5CAdF5268b64F33C2"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "godTiki", outputs: [{name: "tokenId", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tikiIndexToOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "owner", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "templeContract", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "templeOfEthaddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getTiki", outputs: [{name: "tikiName", type: "string"}, {name: "currentPrice", type: "uint256"}, {name: "basePrice", type: "uint256"}, {name: "currentOwner", type: "address"}, {name: "bagHolderFund", type: "uint256"}, {name: "isBagFundAvailable", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tikiMasks", outputs: [{name: "name", type: "string"}, {name: "basePrice", type: "uint256"}, {name: "highPrice", type: "uint256"}, {name: "fallDuration", type: "uint256"}, {name: "saleTime", type: "uint256"}, {name: "bagHolderFund", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "priceOf", outputs: [{name: "price", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contractOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentDevFee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onTokenSold(uint256,uint256,address,address,string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x136c8670bae1a157608c4b0201053960f4271b43daf46cbf6ac6d729033b4be6"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6808037 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6808172 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "TikiMadness", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "godTiki", outputs: [{name: "tokenId", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "godTiki()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tikiIndexToOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tikiIndexToOwner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "owner", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "templeContract", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "templeContract()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "templeOfEthaddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "templeOfEthaddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getTiki", outputs: [{name: "tikiName", type: "string"}, {name: "currentPrice", type: "uint256"}, {name: "basePrice", type: "uint256"}, {name: "currentOwner", type: "address"}, {name: "bagHolderFund", type: "uint256"}, {name: "isBagFundAvailable", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTiki(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tikiMasks", outputs: [{name: "name", type: "string"}, {name: "basePrice", type: "uint256"}, {name: "highPrice", type: "uint256"}, {name: "fallDuration", type: "uint256"}, {name: "saleTime", type: "uint256"}, {name: "bagHolderFund", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tikiMasks(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "priceOf", outputs: [{name: "price", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "priceOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contractOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contractOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentDevFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentDevFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "TikiMadness", function( accounts ) {

	it( "TEST: TikiMadness(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6808037", timeStamp: "1543690482", hash: "0x07482bbf530e820b68e4d6679c0f85fa8398593aed0534f81d9fb0a51fdd664a", nonce: "90", blockHash: "0x8330239ad3a95e9ddbbcd5518b6d0e5066004446ab8413b3b16877d57e9651dd", transactionIndex: "30", from: "0x556f99ff7d5f445f24437ce7c03a909fc8bb650c", to: 0, value: "0", gas: "2113287", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xf0eb0d7c", contractAddress: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", cumulativeGasUsed: "3340516", gasUsed: "2113287", confirmations: "875950"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "TikiMadness", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = TikiMadness.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543690482 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = TikiMadness.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "10699898391229517909" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6808145", timeStamp: "1543692350", hash: "0xae8a19d6300963bc84c727d713290c4f875ec65f586039fa7f812e8bb5986e4b", nonce: "428", blockHash: "0xb948e8dd305c3a8a3af268bf8a7d0f50860e60af140b913642ecb89ef686431f", transactionIndex: "45", from: "0x93131eeb067d550f0b38c33ec30dd28c806c2f43", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "15000000000000000", gas: "200000", gasPrice: "19000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000000000000000000000000000003c84c7285623e7f7539ff60d6f3cf1c3cccd868f", contractAddress: "", cumulativeGasUsed: "1445145", gasUsed: "23484", confirmations: "875842"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "15000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[6]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543692350 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "534557931542061189" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808154", timeStamp: "1543692432", hash: "0x944d95f898f3cd9708f4d7180eeaf13b3449e0f12580683b51a51113e88f911a", nonce: "3961", blockHash: "0x90091bb49ffab76c64b136aabfa5e27d148244fe3debd6e2ff0cd71eb15ffe06", transactionIndex: "58", from: "0x494952f01a30547d269aaf147e6226f940f5b041", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "18000000000000000", gas: "302329", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4003317", gasUsed: "22268", confirmations: "875833"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "18000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "1", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543692432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "476446551047153084" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0x47e1f870e54725f85f940c791dafc27435ad739aa9bfd7e808e0c0133d400124", nonce: "18", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "0", from: "0xbf92e4a68cc341915f571364ec8e261f810d06fe", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "25000000000000000", gas: "200000", gasPrice: "100000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "22290", gasUsed: "22290", confirmations: "875823"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "18446326779536622" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0xdb1000f7257a25f3b9e1b79c623f472487358499ae998c0229618f30e58a547a", nonce: "2055", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "1", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "15000000000000000", gas: "500000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000abcded3c9bd09729c23ac5d678659cecba6a8a0a", contractAddress: "", cumulativeGasUsed: "261667", gasUsed: "239377", confirmations: "875823"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "15000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[10]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "0"}, {name: "price", type: "uint256", value: "15000000000000000"}, {name: "prevOwner", type: "address", value: "0x556f99ff7d5f445f24437ce7c03a909fc8bb650c"}, {name: "newOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "name", type: "string", value: "Huracan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "10193600696796285015" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0x59655f04b200a376764d3b2d0a80289a94ecb401566052679d62c7db9e1dff96", nonce: "2056", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "2", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "18000000000000000", gas: "500000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000001000000000000000000000000abcded3c9bd09729c23ac5d678659cecba6a8a0a", contractAddress: "", cumulativeGasUsed: "441920", gasUsed: "180253", confirmations: "875823"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "18000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "address", name: "_referredBy", value: addressList[10]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "1", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "18000000000000000"}, {name: "prevOwner", type: "address", value: "0x556f99ff7d5f445f24437ce7c03a909fc8bb650c"}, {name: "newOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "name", type: "string", value: "Itzamna"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "10193600696796285015" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0xd53d38c07a108f36e90472a0717e7c3b9f05e5b43f88b2b1a5ad5dd9d7d9c7f1", nonce: "2057", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "3", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "20000000000000000", gas: "500000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000002000000000000000000000000abcded3c9bd09729c23ac5d678659cecba6a8a0a", contractAddress: "", cumulativeGasUsed: "622848", gasUsed: "180928", confirmations: "875823"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[10]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "2"}, {name: "price", type: "uint256", value: "20000000000000000"}, {name: "prevOwner", type: "address", value: "0x556f99ff7d5f445f24437ce7c03a909fc8bb650c"}, {name: "newOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "name", type: "string", value: "Mitnal"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "10193600696796285015" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0x3ad30984a347b90348a53b3395dabf14c1d5c41c711e23f1f36dc8f55ee35fc4", nonce: "2058", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "4", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "25000000000000000", gas: "500000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000003000000000000000000000000abcded3c9bd09729c23ac5d678659cecba6a8a0a", contractAddress: "", cumulativeGasUsed: "804338", gasUsed: "181490", confirmations: "875823"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[10]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "3"}, {name: "price", type: "uint256", value: "25000000000000000"}, {name: "prevOwner", type: "address", value: "0x556f99ff7d5f445f24437ce7c03a909fc8bb650c"}, {name: "newOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "name", type: "string", value: "Tepeu"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "10193600696796285015" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0x8c7eb0a17c19b7928f5ce8e885230cb81affa76563afb382161860f7e587057a", nonce: "2059", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "5", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "30000000000000000", gas: "500000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000004000000000000000000000000abcded3c9bd09729c23ac5d678659cecba6a8a0a", contractAddress: "", cumulativeGasUsed: "986511", gasUsed: "182173", confirmations: "875823"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "4"}, {type: "address", name: "_referredBy", value: addressList[10]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "4", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "4"}, {name: "price", type: "uint256", value: "30000000000000000"}, {name: "prevOwner", type: "address", value: "0x556f99ff7d5f445f24437ce7c03a909fc8bb650c"}, {name: "newOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "name", type: "string", value: "Usukan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "10193600696796285015" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0xc059b3ac1a6eb728a17889e4c2b1c6b83d551ce02b67d0a2068896e9606ec83e", nonce: "2060", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "6", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "35000000000000000", gas: "500000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000005000000000000000000000000abcded3c9bd09729c23ac5d678659cecba6a8a0a", contractAddress: "", cumulativeGasUsed: "1154367", gasUsed: "167856", confirmations: "875823"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "35000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[10]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "5"}, {name: "price", type: "uint256", value: "35000000000000000"}, {name: "prevOwner", type: "address", value: "0x556f99ff7d5f445f24437ce7c03a909fc8bb650c"}, {name: "newOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "name", type: "string", value: "Voltan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "10193600696796285015" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0x4abe864a00aa2223c33a7492a0143635f7c023590959e676b2c68bd2736a0e6b", nonce: "3963", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "7", from: "0x494952f01a30547d269aaf147e6226f940f5b041", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "35000000000000000", gas: "350027", gasPrice: "99000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1179194", gasUsed: "24827", confirmations: "875823"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "35000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "476446551047153084" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0xe19b6c63240f44d64a3e05f87ac7a97083a08c500002109edf7b169ddd46987e", nonce: "9857", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "49", from: "0x2e6236591bfa37c683ce60d6cfde40396a114ff1", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "35000000000000000", gas: "250000", gasPrice: "30000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4373494", gasUsed: "24827", confirmations: "875823"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "35000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "425523760183587325" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0xf9c04df5f1aba817dc9f284f3b63e1825af5ea7797bb16883620d90ef94ecab9", nonce: "111", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "50", from: "0x6629c7199ecc6764383dfb98b229ac8c540fc76f", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "25000000000000000", gas: "500000", gasPrice: "27000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4398321", gasUsed: "24827", confirmations: "875823"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "5193741120590283291" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0x64f47b12f3a72e8351c097ce4b29433e31ca4624efd58198f2e4075a78f91959", nonce: "1569", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "51", from: "0x190a2409fc6434483d4c2cab804e75e3bc5ebfa6", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "30000000000000000", gas: "500000", gasPrice: "27000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4423148", gasUsed: "24827", confirmations: "875823"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "4"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "4", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "1206263670265771113" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808164", timeStamp: "1543692620", hash: "0x8958a20a996bd4f20f791a88a36fb9ffe244a24847643ecd7909a5035098ba75", nonce: "84", blockHash: "0xa555e075ccc6b1982c0e437f3fa855ed0e8e69d2151c71843e880de32aeb606b", transactionIndex: "63", from: "0x9d9e6c1c81f4a70f9580aab81e617afce66aa559", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "30000000000000000", gas: "200000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5151023", gasUsed: "24827", confirmations: "875823"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "4"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "4", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543692620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "307966692921496640" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808165", timeStamp: "1543692622", hash: "0x067445807acc8e201d07b12d439a965504206b2317770707eec4d4c3d548b358", nonce: "7", blockHash: "0x4e0a62f1a2314ffeafb36b8f651a9e9abca0e89e09b51fe8d9bbbe33391e97d5", transactionIndex: "16", from: "0xd25bd6c44d6cf3c0358ab30ed5e89f2090409a79", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "35000000000000000", gas: "150000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "956134", gasUsed: "24827", confirmations: "875822"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "35000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543692622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6808165", timeStamp: "1543692622", hash: "0x10c3e8f5d8296393a67a89e171aebc3653a9bc42ca917ee1112fa840ed690ab4", nonce: "429", blockHash: "0x4e0a62f1a2314ffeafb36b8f651a9e9abca0e89e09b51fe8d9bbbe33391e97d5", transactionIndex: "64", from: "0x93131eeb067d550f0b38c33ec30dd28c806c2f43", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "35000000000000000", gas: "200000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000003c84c7285623e7f7539ff60d6f3cf1c3cccd868f", contractAddress: "", cumulativeGasUsed: "4108614", gasUsed: "26107", confirmations: "875822"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "35000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[6]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543692622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "534557931542061189" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808166", timeStamp: "1543692631", hash: "0xf9431fe2e6d8e409a55c310b3d4b695b7b7eac696b64bd70e60bf4416820488e", nonce: "3964", blockHash: "0xd9fb2746f979a12b258ae9f784913043de78ba365f6a0c7e91d9964ce1b2fe96", transactionIndex: "0", from: "0x494952f01a30547d269aaf147e6226f940f5b041", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "30000000000000000", gas: "3500027", gasPrice: "99000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "24827", gasUsed: "24827", confirmations: "875821"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "4"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "4", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543692631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "476446551047153084" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0x6dc04472c13c734393526f6f41beae697c4b3c8808c0c12b65d06379af72a89b", nonce: "568", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "7", from: "0x3c84c7285623e7f7539ff60d6f3cf1c3cccd868f", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "46200000000000000", gas: "265134", gasPrice: "200000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "169290", gasUsed: "22290", confirmations: "875820"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "46200000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "13469631249894854" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0xa612fe6064ea7d2e0c1bfe66a29bc2d1c126a3e75981d393fa277a2076e5e864", nonce: "826", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "8", from: "0x31228322429e78397ff094ccebe9655f9e9a247f", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "19800000000000000", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "383588", gasUsed: "214298", confirmations: "875820"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "19800000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "0"}, {name: "price", type: "uint256", value: "19781333333333334"}, {name: "prevOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "newOwner", type: "address", value: "0x31228322429e78397ff094ccebe9655f9e9a247f"}, {name: "name", type: "string", value: "Huracan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7571154597320962748" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0xf9eb2007354461fa738067f95734af839cba5a982e485e86c91ade60ba800dbd", nonce: "251", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "9", from: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "26400000000000000", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000002000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "582958", gasUsed: "199370", confirmations: "875820"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "26400000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "2"}, {name: "price", type: "uint256", value: "26375111111111112"}, {name: "prevOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "newOwner", type: "address", value: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9"}, {name: "name", type: "string", value: "Mitnal"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "6023518121828151077" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0xc7c6426de84af97ed9f9d3dc2a996f1f31920ba0118af19837e4a5fa7e40efc8", nonce: "854", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "10", from: "0x9a934f369d97461705982af8f7637254198bff81", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "23760000000000000", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "782207", gasUsed: "199249", confirmations: "875820"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "23760000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "1", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "23737600000000000"}, {name: "prevOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "newOwner", type: "address", value: "0x9a934f369d97461705982af8f7637254198bff81"}, {name: "name", type: "string", value: "Itzamna"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "6547697695904788045" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0x2e4f275b2eb664a15bb024dfb049b2f70fbbc78db3dfa4f999ae0e8c7b58e477", nonce: "252", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "11", from: "0xfaaeceecfe58d9bc2b3061ddc1a227cf86062e32", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "46200000000000000", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000005000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "981448", gasUsed: "199241", confirmations: "875820"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "46200000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "5"}, {name: "price", type: "uint256", value: "46156444444444445"}, {name: "prevOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "newOwner", type: "address", value: "0xfaaeceecfe58d9bc2b3061ddc1a227cf86062e32"}, {name: "name", type: "string", value: "Voltan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "7060732391015754186" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0x0c4bc2ca9e290defda0217b349eec8b8f2022a58a6062b888f03e2c47b335254", nonce: "920", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "12", from: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "39600000000000000", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000004000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "1180689", gasUsed: "199241", confirmations: "875820"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "39600000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "4"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "4", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "4"}, {name: "price", type: "uint256", value: "39562666666666667"}, {name: "prevOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "newOwner", type: "address", value: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa"}, {name: "name", type: "string", value: "Usukan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "11780670936761692003" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0xbe52cafcd9b3e884e17c76991f7339ccc879368c756950e42a673486ed1c76a1", nonce: "246", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "13", from: "0xf897ca9906f10d0a2049321d745ad3b055875924", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "33000000000000000", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000003000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "1364930", gasUsed: "184241", confirmations: "875820"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "33000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "3"}, {name: "price", type: "uint256", value: "32968888888888889"}, {name: "prevOwner", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "newOwner", type: "address", value: "0xf897ca9906f10d0a2049321d745ad3b055875924"}, {name: "name", type: "string", value: "Tepeu"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "6519714051463995571" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0x65dab3200afbd10c09e5ee46dc9a83c6108854d8da3d288323a18a965866c31f", nonce: "3965", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "14", from: "0x494952f01a30547d269aaf147e6226f940f5b041", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "26400000000000000", gas: "265134", gasPrice: "99000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1389757", gasUsed: "24827", confirmations: "875820"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "26400000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "476446551047153084" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0x6a8d0442a68acbb710c453f2f12edc012263b5937de49cdc9ea0a8804252d604", nonce: "19", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "22", from: "0xbf92e4a68cc341915f571364ec8e261f810d06fe", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "25000000000000000", gas: "200000", gasPrice: "50000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2188320", gasUsed: "24827", confirmations: "875820"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "18446326779536622" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0xb3d6910573507cb94e90b33eba60f1bb7f8dda1d0c329d9282c9dd89ae186b03", nonce: "8012", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "26", from: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "46200000000000000", gas: "265105", gasPrice: "44000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2354594", gasUsed: "24827", confirmations: "875820"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "46200000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "434995510015059910" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0x9a6228327db777205d1e28c02dd9079a48063a43cde7c9a3e43812922a0ecb41", nonce: "44", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "32", from: "0xc377ed09ed1bbfe9e3e64fad2fce408a960e864a", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "46193777777777780", gas: "265134", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2700169", gasUsed: "24827", confirmations: "875820"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "46193777777777780" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "134253813512388" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0x975ac0a12dab1bee072e1dc1205e47c9c5fd2d7990dd378cbee5c25676659c69", nonce: "14", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "88", from: "0x262f8c7b80471b26c5f84471772767fa41360d1f", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "15000000000000000", gas: "150000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5616917", gasUsed: "24763", confirmations: "875820"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "15000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "76095173189938" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808167", timeStamp: "1543692634", hash: "0xf7d6ca6f1a4c637b642ceef2035fddd6c2b5e7d21e0bffa3146f63623583b688", nonce: "95", blockHash: "0xafcf2445c015b9cd106870df4eeb73743578a5c49e8f013658eb8587744c3eb7", transactionIndex: "116", from: "0x163916bcb80ea6c0d5ea0e6af14ae9069efc438d", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "20000000000000000", gas: "780000", gasPrice: "4800000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7179839", gasUsed: "24827", confirmations: "875820"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543692634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0xe621a091e704c9da140a7d35ec7c5254bc979ccf3d0a317445423b9c8dd66746", nonce: "827", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "0", from: "0x31228322429e78397ff094ccebe9655f9e9a247f", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "31333632000000000", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "154241", gasUsed: "154241", confirmations: "875818"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "31333632000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "1", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "31252148693333334"}, {name: "prevOwner", type: "address", value: "0x9a934f369d97461705982af8f7637254198bff81"}, {name: "newOwner", type: "address", value: "0x31228322429e78397ff094ccebe9655f9e9a247f"}, {name: "name", type: "string", value: "Itzamna"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7571154597320962748" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0x1f43562d23fcdec7eead74fa3a454654e6090e7377ae25ca3048462d633bd476", nonce: "855", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "1", from: "0x9a934f369d97461705982af8f7637254198bff81", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "26111359999999956", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "338539", gasUsed: "184298", confirmations: "875818"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "26111359999999956" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "0"}, {name: "price", type: "uint256", value: "26043457244444401"}, {name: "prevOwner", type: "address", value: "0x31228322429e78397ff094ccebe9655f9e9a247f"}, {name: "newOwner", type: "address", value: "0x9a934f369d97461705982af8f7637254198bff81"}, {name: "name", type: "string", value: "Huracan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "6547697695904788045" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0xab257e60ed4abf946a343a8ae6c742da97d34b404948a19d6d0c5ed479eacf88", nonce: "921", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "2", from: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "43518933333333216", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000003000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "492780", gasUsed: "154241", confirmations: "875818"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "43518933333333216" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "3"}, {name: "price", type: "uint256", value: "43405762074073958"}, {name: "prevOwner", type: "address", value: "0xf897ca9906f10d0a2049321d745ad3b055875924"}, {name: "newOwner", type: "address", value: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa"}, {name: "name", type: "string", value: "Tepeu"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "11780670936761692003" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0xe899acb13a9eecb65048467933c3b0926939f82d07fdbc11576bb21ba9c1a9bc", nonce: "247", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "3", from: "0xf897ca9906f10d0a2049321d745ad3b055875924", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "34815146666666652", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000002000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "662021", gasUsed: "169241", confirmations: "875818"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "34815146666666652" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "2"}, {name: "price", type: "uint256", value: "34724609659259245"}, {name: "prevOwner", type: "address", value: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9"}, {name: "newOwner", type: "address", value: "0xf897ca9906f10d0a2049321d745ad3b055875924"}, {name: "name", type: "string", value: "Mitnal"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "6519714051463995571" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0x07123ac378ad289a458c275a242b5c2a34ac591a59f0968d12498b00c32bb383", nonce: "3966", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "4", from: "0x494952f01a30547d269aaf147e6226f940f5b041", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "32975555555555560", gas: "265134", gasPrice: "99000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "686848", gasUsed: "24827", confirmations: "875818"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "32975555555555560" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "476446551047153084" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[28] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0x30d3e895b93ffc4ee7d60fc922ab323608baadacf75d90fdef4de059c9ac55dd", nonce: "1220", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "16", from: "0x0982a0bf061f3cec2a004b4d2c802f479099c971", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "19800000000000000", gas: "298669", gasPrice: "30000000000", isError: "1", txreceipt_status: "0", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e4042ae1c40913ba00619392de669bdb3beced50", contractAddress: "", cumulativeGasUsed: "959460", gasUsed: "25979", confirmations: "875818"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "19800000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[28]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[28], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "56372951369163749" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4\", addressList[30] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0xd1c458a35a649d416bc58dcfe4e28203ebb318f166f2c0f61b1b2e1f889702e4", nonce: "370", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "54", from: "0xeb5691310c3977ab4dd93b9830fa69afbe4940fb", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "39600000000000000", gas: "298861", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000004000000000000000000000000cd75c47b2ec49e92cc673269b53d1a75d023dfc9", contractAddress: "", cumulativeGasUsed: "4387048", gasUsed: "26107", confirmations: "875818"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "39600000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "4"}, {type: "address", name: "_referredBy", value: addressList[30]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "4", addressList[30], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "485169033684804458" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808169", timeStamp: "1543692656", hash: "0x485d45d580e9e1515b1d162714facf0434f840edbc26ca216ff4fc6ec52ff486", nonce: "47", blockHash: "0xb109b52131a9145caf3ee7462e0d4167c64c0138bc5037bd69aa05a9d7dbf927", transactionIndex: "55", from: "0x147b7d92c6385b4e4f4c9bd5cadf5268b64f33c2", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "26400000000000000", gas: "265134", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4411875", gasUsed: "24827", confirmations: "875818"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "26400000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543692656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "13019808187860988" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808170", timeStamp: "1543692660", hash: "0x97bfc0281df30a09492e062cfd49142e2a8aea6ed7fa6c8dfffa4efe1846f9af", nonce: "248", blockHash: "0x3189dbfd064ebc7af7371f81c2a2773bee7c0a7fb9f5cc644678c3484c17faa9", transactionIndex: "20", from: "0xf897ca9906f10d0a2049321d745ad3b055875924", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "41252836275199956", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "949710", gasUsed: "154362", confirmations: "875817"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "41252836275199956" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "1", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543692660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "41226999790449734"}, {name: "prevOwner", type: "address", value: "0x31228322429e78397ff094ccebe9655f9e9a247f"}, {name: "newOwner", type: "address", value: "0xf897ca9906f10d0a2049321d745ad3b055875924"}, {name: "name", type: "string", value: "Itzamna"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "6519714051463995571" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808170", timeStamp: "1543692660", hash: "0xf5820542d2cc39bff701e0d16427539e36d473bb393f0abb52f12e2ff115d40d", nonce: "922", blockHash: "0x3189dbfd064ebc7af7371f81c2a2773bee7c0a7fb9f5cc644678c3484c17faa9", transactionIndex: "21", from: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "45836484750222144", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000002000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "1119072", gasUsed: "169362", confirmations: "875817"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "45836484750222144" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543692660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "2"}, {name: "price", type: "uint256", value: "45807777544944120"}, {name: "prevOwner", type: "address", value: "0xf897ca9906f10d0a2049321d745ad3b055875924"}, {name: "newOwner", type: "address", value: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa"}, {name: "name", type: "string", value: "Mitnal"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "11780670936761692003" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808170", timeStamp: "1543692660", hash: "0x46e94f2d3651785ace0514881cbd344392a588b7ca6ed3b4f4b5712a85d19787", nonce: "252", blockHash: "0x3189dbfd064ebc7af7371f81c2a2773bee7c0a7fb9f5cc644678c3484c17faa9", transactionIndex: "22", from: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "57295605937777548", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000003000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "1303313", gasUsed: "184241", confirmations: "875817"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "57295605937777548" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543692660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "3"}, {name: "price", type: "uint256", value: "57259721931180018"}, {name: "prevOwner", type: "address", value: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa"}, {name: "newOwner", type: "address", value: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9"}, {name: "name", type: "string", value: "Tepeu"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "6023518121828151077" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808170", timeStamp: "1543692660", hash: "0xc8aeddfc2960651b71c0045f97a00f206b182b90de875255dae6e073e96b572e", nonce: "253", blockHash: "0x3189dbfd064ebc7af7371f81c2a2773bee7c0a7fb9f5cc644678c3484c17faa9", transactionIndex: "23", from: "0xfaaeceecfe58d9bc2b3061ddc1a227cf86062e32", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "34377363562666608", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "1457611", gasUsed: "154298", confirmations: "875817"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "34377363562666608" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543692660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "0"}, {name: "price", type: "uint256", value: "34355833158708090"}, {name: "prevOwner", type: "address", value: "0x9a934f369d97461705982af8f7637254198bff81"}, {name: "newOwner", type: "address", value: "0xfaaeceecfe58d9bc2b3061ddc1a227cf86062e32"}, {name: "name", type: "string", value: "Huracan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "7060732391015754186" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808170", timeStamp: "1543692660", hash: "0x38b8f52fa0a21ef3301d2c23c07b17dd53e34166071a0be3d77aa8cbf1ccc49e", nonce: "3967", blockHash: "0x3189dbfd064ebc7af7371f81c2a2773bee7c0a7fb9f5cc644678c3484c17faa9", transactionIndex: "24", from: "0x494952f01a30547d269aaf147e6226f940f5b041", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "23742400000000000", gas: "265105", gasPrice: "99000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1482438", gasUsed: "24827", confirmations: "875817"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "23742400000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "1", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543692660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "476446551047153084" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"1\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808172", timeStamp: "1543692682", hash: "0x254dc44cf9196c41219c446685ee1872463daf5e64d71898a6df0adbe67d26cf", nonce: "856", blockHash: "0x0ab4a159cd09a6f6c7e3627514fe3755e51be58214174db99ca6833f609a36ee", transactionIndex: "14", from: "0x9a934f369d97461705982af8f7637254198bff81", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "54419639723393604", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "489149", gasUsed: "169241", confirmations: "875815"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "54419639723393604" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "1"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "1", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543692682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "1"}, {name: "price", type: "uint256", value: "54197075258417310"}, {name: "prevOwner", type: "address", value: "0xf897ca9906f10d0a2049321d745ad3b055875924"}, {name: "newOwner", type: "address", value: "0x9a934f369d97461705982af8f7637254198bff81"}, {name: "name", type: "string", value: "Itzamna"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "6547697695904788045" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"3\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808172", timeStamp: "1543692682", hash: "0x3e4454b80500f69452cddaa8765ba00b77e40fcdc3c4a7fbe8143a369ecb59ec", nonce: "828", blockHash: "0x0ab4a159cd09a6f6c7e3627514fe3755e51be58214174db99ca6833f609a36ee", transactionIndex: "15", from: "0x31228322429e78397ff094ccebe9655f9e9a247f", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "75582832949157600", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000003000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "658390", gasUsed: "169241", confirmations: "875815"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "75582832949157600" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "3"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "3", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543692682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "3"}, {name: "price", type: "uint256", value: "75273715636690526"}, {name: "prevOwner", type: "address", value: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9"}, {name: "newOwner", type: "address", value: "0x31228322429e78397ff094ccebe9655f9e9a247f"}, {name: "name", type: "string", value: "Tepeu"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7571154597320962748" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"2\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808172", timeStamp: "1543692682", hash: "0x20335d0320672e1c7bcf24bfc38d49f97b86c437b5324ba3c8ebc301e097a0ca", nonce: "253", blockHash: "0x0ab4a159cd09a6f6c7e3627514fe3755e51be58214174db99ca6833f609a36ee", transactionIndex: "16", from: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "60466266359326212", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000002000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "842631", gasUsed: "184241", confirmations: "875815"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "60466266359326212" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "2"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "2", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543692682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "2"}, {name: "price", type: "uint256", value: "60218972509352552"}, {name: "prevOwner", type: "address", value: "0x992f2864daa339ddab9ec14003c3cca1304bd6aa"}, {name: "newOwner", type: "address", value: "0xd6ef90f002b659dba6aae409ab45a94a88ac2db9"}, {name: "name", type: "string", value: "Mitnal"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "6023518121828151077" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6808172", timeStamp: "1543692682", hash: "0xaea2d60ee32e98194fe044cc7944e1451f91f3803837568cb9e0621c976eb2b9", nonce: "249", blockHash: "0x0ab4a159cd09a6f6c7e3627514fe3755e51be58214174db99ca6833f609a36ee", transactionIndex: "17", from: "0xf897ca9906f10d0a2049321d745ad3b055875924", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "45349699769494560", gas: "600000", gasPrice: "99999999998", isError: "0", txreceipt_status: "1", input: "0xae77c2370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e7eca2a94e9d59848f3c1e1ffaacd881d4c3a4f2", contractAddress: "", cumulativeGasUsed: "1026808", gasUsed: "184177", confirmations: "875815"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "45349699769494560" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[17]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543692682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "0"}, {name: "price", type: "uint256", value: "45164229382014316"}, {name: "prevOwner", type: "address", value: "0xfaaeceecfe58d9bc2b3061ddc1a227cf86062e32"}, {name: "newOwner", type: "address", value: "0xf897ca9906f10d0a2049321d745ad3b055875924"}, {name: "name", type: "string", value: "Huracan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "6519714051463995571" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"0\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808172", timeStamp: "1543692682", hash: "0x78ecf4dadf92cb72458a9667e99a7d9a54421faa01074b0665b6c8984418600c", nonce: "3968", blockHash: "0x0ab4a159cd09a6f6c7e3627514fe3755e51be58214174db99ca6833f609a36ee", transactionIndex: "18", from: "0x494952f01a30547d269aaf147e6226f940f5b041", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "0", gas: "350027", gasPrice: "99000000000", isError: "1", txreceipt_status: "0", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1051571", gasUsed: "24763", confirmations: "875815"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "0"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "0", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543692682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "476446551047153084" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6808172", timeStamp: "1543692682", hash: "0x4fa45c24cb46ad7b12c90118a60d7adfd8ddea57f0234bde5ded66c1f61656ba", nonce: "9858", blockHash: "0x0ab4a159cd09a6f6c7e3627514fe3755e51be58214174db99ca6833f609a36ee", transactionIndex: "26", from: "0x2e6236591bfa37c683ce60d6cfde40396a114ff1", to: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0", value: "60768066903703650", gas: "287634", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xae77c23700000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1560897", gasUsed: "176764", confirmations: "875815"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "60768066903703650" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "5"}, {type: "address", name: "_referredBy", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint256,address)" ]( "5", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543692682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "tokenId", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "prevOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}, {indexed: false, name: "name", type: "string"}], name: "onTokenSold", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenSold", events: [{name: "tokenId", type: "uint256", value: "5"}, {name: "price", type: "uint256", value: "60580819911111054"}, {name: "prevOwner", type: "address", value: "0xfaaeceecfe58d9bc2b3061ddc1a227cf86062e32"}, {name: "newOwner", type: "address", value: "0x2e6236591bfa37c683ce60d6cfde40396a114ff1"}, {name: "name", type: "string", value: "Voltan"}], address: "0xc094367b4c79564b6c8b4218f84dea835b2c2dd0"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "425523760183587325" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "2840909090990495" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
