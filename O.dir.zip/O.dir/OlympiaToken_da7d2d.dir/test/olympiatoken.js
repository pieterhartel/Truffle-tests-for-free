const OlympiaToken = artifacts.require( "./OlympiaToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "OlympiaToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xCFC64d8eAEB4E6a68860e415f55DFe9057dA7d2D", "0x629573ad5A234A921628bF6BFD545949CA8b6eEd", "0xAD84D21b6BE3957aa4de1504958Bd264463304Ae", "0xeB257e352269020143E614ED4dB80AC96DDeE8c1", "0x8bb226F3e381b2930b1224C22b31e431E6d2888f", "0xA8230e2C277cfb9D90B7e0cA28Ad9c089650a017", "0xC17D8400F7ee5f65674717B12283bC328312BDD2", "0x733d35a79DCDDA443263FCe3147105C9aac7A55F", "0x484A3588e42fB1541858aA314854eEd26E14816c", "0x219C32A3Add86913fCF259cE938378f07779d702", "0xdcCd48f9412947763aDAA833F51121116b44e281", "0x0D0963f22D2491CA534d2F3aE3549Ec9CdD01571", "0x76CC77f2627e4bfFf1Dc7a88f4c80a632894F0E2", "0x52b045704105231dC943e1fE1Ba45305da2322FE", "0xBd12aa424c207E90B66402c1F0aeC357e8b1Ded7", "0xCF50E2E2a63F133152C9567Cb25c02663E8aa715", "0x685654d53BEF389760135c30f91C404eB000F4C5", "0x13Bc32066c0126A99274182796316FC69dE488b8", "0x03D7326F53715D4a042bd1Fa12669eB420e87b5B", "0xdebBd37ac845b0E6F6bB69070154DE4b68B4D733", "0x2B53f9CB996a3C0b76B4E53104Ed975aAD720c70", "0x6c0F48c03f752175aEF48383A0e4C26Bd8259a24", "0x869eC00FA1DC112917c781942Cc01c68521c415e", "0x2562E435F74b821d32509A03A817C3aB2bA00E5c", "0xa3D1AF4d2534Ed58FD889CB830F28D1DF54C0584", "0x749da07afBD691d0D5932f42F98358A150952c9e", "0x1faaDc02151071eB6A8122959bF8Fcae86EA36c7", "0x12BbD656F895a776BB3A63FF0375D27457dE0b31", "0xA5FA73A6c5C6Ff3fCA0478c75C49A8C1c5dB452F", "0x7D678b9218aC289e0C9F18c82F546c988BfE3022", "0x06542485C9E2dF512C03D81c84C562d18876733F", "0x39A8c8cEf3f3AC7843907145467bE25B9Ee7ae05", "0xBDD6FB8B197eb31be30997af4b9eF124328e3c9b", "0x44F93E529BeB33929E4973959B054f1Fe1145CA9", "0xE71E5Eb13baE69e19D5b04744404903FEC415EC0", "0xb2969D3429e99E4846E5bE4Df47d74bA87069E0D", "0xF037747527B99D9dc705F23a2b914be19f204De1", "0x008d04c54469018Da69a18EcA01898bb443D1E61", "0x97Da7FDbaFe3647656561850F17233a07d6c9C9C", "0xD10D6E8Fca3042edd7387608f99A3009FA3bF14f", "0x9D79bd745d1506D9B8A732a5e1825369ab383938", "0xb3817Ad14517c19c4dbbb410B20510c48Ce72102", "0xC3ed58B8fB45DBf294cCDb9fd59fa2be05c7d0E1", "0x54488AD9f88Cf00397de235d343C421dcb4d5245", "0x484CFfcB47d4775004e242bDb6Fe19dDF3cc67Ed", "0x80fe58A8e4ee88EebF20a362b912A0446C14D690", "0xf05af483Aa06588346b4c2A30d3759ea31Ca900b", "0x9a10Fc45cf5469606c74B915F88dd90D59658DaB", "0x6b344D70D3D72bD214D6d158545a006651c44337", "0xa1f685f4175C7Bc3db055042f06A143De4fD230D", "0x28Cd26d85b4ac655A489Aa3f259F81283BD1A804", "0xCBE5cc860332B6661192dC71c62cCcBe3De650A1", "0x2239806aAe7Fd1A0053144C351d66D74Edd90ec1", "0x99f0C984129978E73c504A09040c1Cdfc1E3FA71", "0xc4A821Ce10D6dA42d63937f0Ea5581ace0E039CC", "0xB277C8C7a48A5D1418cF9a4A38E642F2d7989e56", "0x830E3A6766C753e041aa5B78e94213972a99D400", "0x611B13d54F0423Bc87Abdc113Aa9d2512A472735", "0x29E898a03b58daC7eEcBA400CdA283635025Ec14", "0xcF8e7573894CB97D2589EFdaF04cf65b8ad94cD9", "0xFF326878D13b33591D286372E67B4AF05cD100bd", "0xb8dDdc25E6a133855AD10c5b0221aa7e6fdEf62F", "0x4eE7e9F5F00ccb61d99af67Cbd420ED13df3d2F9", "0xAF919DcbA4889Fe115541157481af08E6cd4ff79", "0xda94148Af0565669Dd419ebc0354113cE0A3583B", "0xD23341b1042b673a10E7A4f56b8550B190648c6f", "0xB2Aa129CEa71BB30F53F47B11B086B5132F15169", "0xA59FC9fddb1e3D803b2c3D3456a4451Ab6349B19", "0xa9C98385dB572a270c790D3A5c503D2ee89D9f1f", "0x5C198B248dFc1C428d29558dF90347115A3f3f65", "0xa338096d43efFc151E7e89519b524CA5a7E5626f", "0x7402016E38c676E11F5B4556082311F8B00B6d94", "0x5fD861Ad220995d1e8d847474c4388f09C53774B", "0x1b83F6E9C6D7f5F3c154BEb834DAF5032ba15a39", "0xDD18C392914c19e0f6688a8C9Ef93a4860834Cdf", "0xdC3464488676175423F6d4C09dD6E43bDf6E7796", "0xa2aB1AC4862E3E04Bb3E6100C41631eAFc011877", "0x37A8cA1312c3b7f1f4e0b7B08C6633F1d747E3fe", "0xa1f958F922B89b3F3Ffcd881895FcEE672944e83", "0x4b13E3B09bC214450946572275D0b316fD918ed5", "0xdfe496F26a428936d0f806b535734448ACF97F8b", "0x9C10096cBac0eC393D89fd4754a3b350A610E08F", "0x2B1D2d290268cb4C4862d4a658f1C2A663C0F79a", "0x551Ff91A3cDA6794680f6df2c93ae70F062cb28C", "0xCE77F7Af5a4fC879226d001723938d614018ce83", "0x7B2e78D4dFaABA045A167a70dA285E30E8FcA196", "0x2daBb24e53B5D14980Cb9Df20d05Bcfd3A9f4b0f", "0xcEC56F1D4Dc439E298D5f8B6ff3Aa6be58Cd6Fdf", "0xE8F08D7dc98be694CDa49430CA01595776909Eac", "0xAC9ba72fb61aA7c31A95df0A8b6ebA6f41EF875e", "0xbC4104BA80cc3734D62cdB4ca612A85E0bFF99ED", "0x843dcF1e6c509ba962E31723202bACc671A7cFb8", "0x1D89d4A14cEcc19E03Dfda7846ecdDEf8e41b7e5", "0xC73Add416E2119d20cE80E0904FC1877e33EF246", "0xA5aBF3Ea06aBBD0b9EC40caEb77f8Fb0Fe42fCb7", "0x73c86E55dC0754210DeB63C306A144Db77F632E8", "0x46c0a081a869F6D9fDe6d5e83dBF24b887FCcD77", "0x3821d641f34b7C9Be01c619d03c84DC7A053D832", "0x7b31A6B8ED486482A87639DbE7b9fBf20efDe50e", "0xf90BE09571296383018fe44eA34DC381E88E574F", "0xcb9eEa0D2C94f5601649601E30f97d21F052960B", "0x3748BaA24b424fB0ee4d197dFdff664D4050b167"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "creator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "admins", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isPlayToken", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}, {name: "spender", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Issuance(address,uint256)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x9cb9c14f7bc76e3a89b796b091850526236115352a198b1e472f00e91376bbcb", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6663016 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6733347 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "OlympiaToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "creator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "creator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "admins", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "admins(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isPlayToken", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPlayToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "OlympiaToken", function( accounts ) {

	it( "TEST: OlympiaToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6663016", timeStamp: "1541633742", hash: "0x4712090dd208e079416829e6a0beb34302c83b668043b12aa0ea639b511bda90", nonce: "4", blockHash: "0x99a7dbc576762fa18b5136bd9a7aff23a224eab100381b66e7b83607de8767bf", transactionIndex: "27", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: 0, value: "0", gas: "6721975", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe92d8c05", contractAddress: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", cumulativeGasUsed: "2407982", gasUsed: "1673362", confirmations: "1058903"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "OlympiaToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = OlympiaToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541633742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = OlympiaToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addAdmin( [addressList[3]] )", async function( ) {
		const txOriginal = {blockNumber: "6663121", timeStamp: "1541635146", hash: "0xfbf163a35edd2eaa4e207e332698a7057f08f413fa5d8502d467dd074883d325", nonce: "8", blockHash: "0xa19f8d8d2d29ae15aebb00e14b5091d9eabd88014b8ced38d166d5b696aa13ed", transactionIndex: "7", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "6721975", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3d0950a800000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000001000000000000000000000000629573ad5a234a921628bf6bfd545949ca8b6eed", contractAddress: "", cumulativeGasUsed: "487448", gasUsed: "44365", confirmations: "1058798"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_admins", value: [addressList[3]]}], name: "addAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAdmin(address[])" ]( [addressList[3]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541635146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[3]], \"10000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6663150", timeStamp: "1541635705", hash: "0x347a9c4637f8cbf36749d6c38a175ea15e4415de85342286e59fe436a3cc9cf3", nonce: "9", blockHash: "0xee742b6b7ba395860445c621ac40742e693ca15f292a0b21196fa6cd742f0230", transactionIndex: "13", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "6721975", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000629573ad5a234a921628bf6bfd545949ca8b6eed", contractAddress: "", cumulativeGasUsed: "1079260", gasUsed: "67232", confirmations: "1058769"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[3]]}, {type: "uint256", name: "amount", value: "1000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[3]], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541635705 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "amount", type: "uint256", value: "1000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[4],addressList[5]] )", async function( ) {
		const txOriginal = {blockNumber: "6666458", timeStamp: "1541682974", hash: "0x5d3d867207afe8e4cba3b0d8c80787c4a10c0e3a217cd75fa0acc834fd5227e8", nonce: "15", blockHash: "0x653cc5395eebfce1d9b5ec0c04e5d120810e95a2b79816d124c727d7e01dbfcf", transactionIndex: "80", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000ad84d21b6be3957aa4de1504958bd264463304ae000000000000000000000000eb257e352269020143e614ed4db80ac96ddee8c1", contractAddress: "", cumulativeGasUsed: "5714663", gasUsed: "66185", confirmations: "1055461"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[4],addressList[5]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[4],addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541682974 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[4],addressList[5]] )", async function( ) {
		const txOriginal = {blockNumber: "6666547", timeStamp: "1541684184", hash: "0x0f5e8e53eb12b5e89f649f45e7c37a8db375f26e825ee22e2006537d65347158", nonce: "17", blockHash: "0x357748af2ed88525a5ccab4c4aa0ed1ae711e91ac7ced0cab5d350236eb04982", transactionIndex: "99", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000ad84d21b6be3957aa4de1504958bd264463304ae000000000000000000000000eb257e352269020143e614ed4db80ac96ddee8c1", contractAddress: "", cumulativeGasUsed: "6383844", gasUsed: "36185", confirmations: "1055372"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[4],addressList[5]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[4],addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541684184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[4], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6666551", timeStamp: "1541684275", hash: "0x3dff0a7dc005f4b4d917366b99467ff631379832ffdb5e12279b1e53a5bc57e4", nonce: "18", blockHash: "0xb033486c5a9128fd5ab66fedd2f051d29d5b62f6c2de90fd16b9317147d7c608", transactionIndex: "99", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000ad84d21b6be3957aa4de1504958bd264463304ae0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6391408", gasUsed: "45567", confirmations: "1055368"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[4]}, {type: "uint256", name: "value", value: "1000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[4], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541684275 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0xad84d21b6be3957aa4de1504958bd264463304ae"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[5],addressList[4]] )", async function( ) {
		const txOriginal = {blockNumber: "6667670", timeStamp: "1541700053", hash: "0xec6bd833a3ac8cd6c9d480de3f3f09c434cc80edc7a1dfcc89fb1ef05d3910a7", nonce: "21", blockHash: "0x3e7c98e8a89fc6621bfdcab0fd9b4327746ec03ab22b82b3b180c96bccb490c5", transactionIndex: "7", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "6721975", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000eb257e352269020143e614ed4db80ac96ddee8c1000000000000000000000000ad84d21b6be3957aa4de1504958bd264463304ae", contractAddress: "", cumulativeGasUsed: "975679", gasUsed: "36185", confirmations: "1054249"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[5],addressList[4]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[5],addressList[4]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541700053 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[6],addressList[7]] )", async function( ) {
		const txOriginal = {blockNumber: "6673279", timeStamp: "1541779808", hash: "0x3e75d15427c8d615d08281f9fc94620367ba74f18af53a47cc37ca5cbed1fe7c", nonce: "25", blockHash: "0xa26f86368813cb52606a53fef592c59c07c98a299d9fd97090ac96faae5c6acd", transactionIndex: "139", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000008bb226f3e381b2930b1224c22b31e431e6d2888f000000000000000000000000a8230e2c277cfb9d90b7e0ca28ad9c089650a017", contractAddress: "", cumulativeGasUsed: "7138470", gasUsed: "66185", confirmations: "1048640"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[6],addressList[7]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[6],addressList[7]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541779808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[6],addressList[7]] )", async function( ) {
		const txOriginal = {blockNumber: "6673306", timeStamp: "1541780088", hash: "0x97e8a7a641fa7144ee9f522e08a61ba57eee0bc1fcd979192a87bb6571fc4f6c", nonce: "26", blockHash: "0x76397130e5b39a7a3d78601633b8264bb6a5413220cc6fb58b51791b248fa6a9", transactionIndex: "190", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000008bb226f3e381b2930b1224c22b31e431e6d2888f000000000000000000000000a8230e2c277cfb9d90b7e0ca28ad9c089650a017", contractAddress: "", cumulativeGasUsed: "7961372", gasUsed: "36185", confirmations: "1048613"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[6],addressList[7]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[6],addressList[7]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541780088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[6],addressList[7]] )", async function( ) {
		const txOriginal = {blockNumber: "6673340", timeStamp: "1541780521", hash: "0x4f531e56e82bdd54b1091b2a1254e27264c506b24c013775c522a79b8ea14bed", nonce: "27", blockHash: "0xa5f44b9e532059d9ead57c7ab550d0d0641272e6be661d876fa8b69dead8e1f7", transactionIndex: "71", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000008bb226f3e381b2930b1224c22b31e431e6d2888f000000000000000000000000a8230e2c277cfb9d90b7e0ca28ad9c089650a017", contractAddress: "", cumulativeGasUsed: "3771363", gasUsed: "36185", confirmations: "1048579"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[6],addressList[7]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[6],addressList[7]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541780521 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[6],addressList[7]] )", async function( ) {
		const txOriginal = {blockNumber: "6673363", timeStamp: "1541780809", hash: "0x1f25053972643d9b3b52a841892266900e3039280c0764b54cb88fa1fbc5456e", nonce: "28", blockHash: "0x3fb5ce527713c757cf768206c52813c338cb24648b2ce46421318c1847f043c4", transactionIndex: "86", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000008bb226f3e381b2930b1224c22b31e431e6d2888f000000000000000000000000a8230e2c277cfb9d90b7e0ca28ad9c089650a017", contractAddress: "", cumulativeGasUsed: "5070041", gasUsed: "36185", confirmations: "1048556"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[6],addressList[7]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[6],addressList[7]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541780809 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[6], \"50000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6673365", timeStamp: "1541780849", hash: "0x2073cbb0e0f2d69411bea63d7c814e39f9fc109b61be2f89a662c7d9d7360960", nonce: "29", blockHash: "0x198df0b324bce551cdb9463dab9c7384be2e5b2982e8f807a2960493ec36072e", transactionIndex: "106", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000008bb226f3e381b2930b1224c22b31e431e6d2888f000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "5457191", gasUsed: "45631", confirmations: "1048554"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[6]}, {type: "uint256", name: "value", value: "50000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[6], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541780849 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0x8bb226f3e381b2930b1224c22b31e431e6d2888f"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[8],addressList[9],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6673446", timeStamp: "1541782031", hash: "0xebc35f3f7173ec5a1f0760542a474ca76ef732e5cdd1abbab44fdd3891943a5d", nonce: "36", blockHash: "0xb842756f4973eaa4ccacdf34797d80f479afaced9588e7f2f564dfbf4af62944", transactionIndex: "2", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "6721975", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x42958b5400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000005000000000000000000000000c17d8400f7ee5f65674717b12283bc328312bdd2000000000000000000000000733d35a79dcdda443263fce3147105c9aac7a55f000000000000000000000000484a3588e42fb1541858aa314854eed26e14816c000000000000000000000000219c32a3add86913fcf259ce938378f07779d702000000000000000000000000dccd48f9412947763adaa833f51121116b44e281", contractAddress: "", cumulativeGasUsed: "189149", gasUsed: "146312", confirmations: "1048473"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12]]}, {type: "uint256", name: "amount", value: "100000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12]], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541782031 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0xc17d8400f7ee5f65674717b12283bc328312bdd2"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x733d35a79dcdda443263fce3147105c9aac7a55f"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x484a3588e42fb1541858aa314854eed26e14816c"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x219c32a3add86913fcf259ce938378f07779d702"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xdccd48f9412947763adaa833f51121116b44e281"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[6], \"1157920892373161954200... )", async function( ) {
		const txOriginal = {blockNumber: "6673514", timeStamp: "1541782930", hash: "0x35d41a5cbd5b6e28036953093ac36b0e743b02816bc1f8c90920a2632773fedd", nonce: "16", blockHash: "0xe1d3ae25dece753d8deb186328c1eb216461341990d3d4a8c3618fa5ed2db47c", transactionIndex: "87", from: "0x219c32a3add86913fcf259ce938378f07779d702", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000008bb226f3e381b2930b1224c22b31e431e6d2888fffffffffffffffff6e5d2d49dbd61e236e98bdcba76f3b769800000000000000", contractAddress: "", cumulativeGasUsed: "5050277", gasUsed: "46783", confirmations: "1048405"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[6]}, {type: "uint256", name: "value", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[6], "115792089237316195420000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541782930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x219c32a3add86913fcf259ce938378f07779d702"}, {name: "spender", type: "address", value: "0x8bb226f3e381b2930b1224c22b31e431e6d2888f"}, {name: "value", type: "uint256", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "22930678678630826" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[13],addressList[14]], \"200... )", async function( ) {
		const txOriginal = {blockNumber: "6708905", timeStamp: "1542283381", hash: "0xc716e03881530e15569482f7cdd3ba02a4d9222c999bff2e77dd49732a483a3e", nonce: "37", blockHash: "0xc24cdf394d4b0098eec247119b264558e7a09204027562ff7a067b018d78ccfb", transactionIndex: "26", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "113652", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000006c6b935b8bbd40000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000d0963f22d2491ca534d2f3ae3549ec9cdd0157100000000000000000000000076cc77f2627e4bfff1dc7a88f4c80a632894f0e2", contractAddress: "", cumulativeGasUsed: "1264643", gasUsed: "75768", confirmations: "1013014"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[13],addressList[14]]}, {type: "uint256", name: "amount", value: "2000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[13],addressList[14]], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542283381 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0x0d0963f22d2491ca534d2f3ae3549ec9cdd01571"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x76cc77f2627e4bfff1dc7a88f4c80a632894f0e2"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[15],addressList[16],address... )", async function( ) {
		const txOriginal = {blockNumber: "6709311", timeStamp: "1542289107", hash: "0x6da96286487fbd0f6560ad3d38dd5eb85ead226e48a260ba4c57a8d2c24c2a5d", nonce: "38", blockHash: "0xd762ece071ebddcd0c236e150b6b3024d093a02079816c60027214c16cccb2aa", transactionIndex: "55", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "819637", gasPrice: "10700000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000006c6b935b8bbd400000000000000000000000000000000000000000000000000000000000000000001600000000000000000000000052b045704105231dc943e1fe1ba45305da2322fe000000000000000000000000bd12aa424c207e90b66402c1f0aec357e8b1ded7000000000000000000000000cf50e2e2a63f133152c9567cb25c02663e8aa715000000000000000000000000685654d53bef389760135c30f91c404eb000f4c500000000000000000000000013bc32066c0126a99274182796316fc69de488b800000000000000000000000003d7326f53715d4a042bd1fa12669eb420e87b5b000000000000000000000000debbd37ac845b0e6f6bb69070154de4b68b4d7330000000000000000000000002b53f9cb996a3c0b76b4e53104ed975aad720c700000000000000000000000006c0f48c03f752175aef48383a0e4c26bd8259a24000000000000000000000000869ec00fa1dc112917c781942cc01c68521c415e0000000000000000000000002562e435f74b821d32509a03a817c3ab2ba00e5c000000000000000000000000a3d1af4d2534ed58fd889cb830f28d1df54c0584000000000000000000000000749da07afbd691d0d5932f42f98358a150952c9e0000000000000000000000001faadc02151071eb6a8122959bf8fcae86ea36c700000000000000000000000012bbd656f895a776bb3a63ff0375d27457de0b31000000000000000000000000a5fa73a6c5c6ff3fca0478c75c49a8c1c5db452f0000000000000000000000007d678b9218ac289e0c9f18c82f546c988bfe302200000000000000000000000006542485c9e2df512c03d81c84c562d18876733f00000000000000000000000039a8c8cef3f3ac7843907145467be25b9ee7ae05000000000000000000000000bdd6fb8b197eb31be30997af4b9ef124328e3c9b00000000000000000000000044f93e529beb33929e4973959b054f1fe1145ca9000000000000000000000000e71e5eb13bae69e19d5b04744404903fec415ec0", contractAddress: "", cumulativeGasUsed: "7668994", gasUsed: "546425", confirmations: "1012608"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36]]}, {type: "uint256", name: "amount", value: "2000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36]], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542289107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0x52b045704105231dc943e1fe1ba45305da2322fe"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xbd12aa424c207e90b66402c1f0aec357e8b1ded7"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xcf50e2e2a63f133152c9567cb25c02663e8aa715"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x685654d53bef389760135c30f91c404eb000f4c5"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x13bc32066c0126a99274182796316fc69de488b8"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x03d7326f53715d4a042bd1fa12669eb420e87b5b"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xdebbd37ac845b0e6f6bb69070154de4b68b4d733"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x2b53f9cb996a3c0b76b4e53104ed975aad720c70"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x6c0f48c03f752175aef48383a0e4c26bd8259a24"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x869ec00fa1dc112917c781942cc01c68521c415e"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x2562e435f74b821d32509a03a817c3ab2ba00e5c"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xa3d1af4d2534ed58fd889cb830f28d1df54c0584"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x749da07afbd691d0d5932f42f98358a150952c9e"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x1faadc02151071eb6a8122959bf8fcae86ea36c7"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x12bbd656f895a776bb3a63ff0375d27457de0b31"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xa5fa73a6c5c6ff3fca0478c75c49a8c1c5db452f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x7d678b9218ac289e0c9f18c82f546c988bfe3022"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x06542485c9e2df512c03d81c84c562d18876733f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x39a8c8cef3f3ac7843907145467be25b9ee7ae05"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xbdd6fb8b197eb31be30997af4b9ef124328e3c9b"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x44f93e529beb33929e4973959b054f1fe1145ca9"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xe71e5eb13bae69e19d5b04744404903fec415ec0"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[12],addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6709427", timeStamp: "1542290574", hash: "0x7c5aaa77f3da2718bebd463fa7e89956751c7eff6eaeea0e467ab43a4b6c0fca", nonce: "39", blockHash: "0x02d3043deb387fe44a434c3fede2322a05ef7a1f3195383ac026e690fa669ec1", transactionIndex: "130", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "1351828", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000006c6b935b8bbd4000000000000000000000000000000000000000000000000000000000000000000027000000000000000000000000dccd48f9412947763adaa833f51121116b44e281000000000000000000000000c17d8400f7ee5f65674717b12283bc328312bdd2000000000000000000000000b2969d3429e99e4846e5be4df47d74ba87069e0d000000000000000000000000733d35a79dcdda443263fce3147105c9aac7a55f000000000000000000000000f037747527b99d9dc705f23a2b914be19f204de1000000000000000000000000008d04c54469018da69a18eca01898bb443d1e6100000000000000000000000097da7fdbafe3647656561850f17233a07d6c9c9c000000000000000000000000d10d6e8fca3042edd7387608f99a3009fa3bf14f0000000000000000000000009d79bd745d1506d9b8a732a5e1825369ab383938000000000000000000000000b3817ad14517c19c4dbbb410b20510c48ce72102000000000000000000000000c3ed58b8fb45dbf294ccdb9fd59fa2be05c7d0e100000000000000000000000054488ad9f88cf00397de235d343c421dcb4d5245000000000000000000000000484cffcb47d4775004e242bdb6fe19ddf3cc67ed00000000000000000000000080fe58a8e4ee88eebf20a362b912a0446c14d690000000000000000000000000f05af483aa06588346b4c2a30d3759ea31ca900b0000000000000000000000009a10fc45cf5469606c74b915f88dd90d59658dab0000000000000000000000006b344d70d3d72bd214d6d158545a006651c44337000000000000000000000000a1f685f4175c7bc3db055042f06a143de4fd230d00000000000000000000000028cd26d85b4ac655a489aa3f259f81283bd1a804000000000000000000000000cbe5cc860332b6661192dc71c62cccbe3de650a10000000000000000000000002239806aae7fd1a0053144c351d66d74edd90ec100000000000000000000000099f0c984129978e73c504a09040c1cdfc1e3fa71000000000000000000000000c4a821ce10d6da42d63937f0ea5581ace0e039cc000000000000000000000000b277c8c7a48a5d1418cf9a4a38e642f2d7989e56000000000000000000000000830e3a6766c753e041aa5b78e94213972a99d400000000000000000000000000611b13d54f0423bc87abdc113aa9d2512a47273500000000000000000000000029e898a03b58dac7eecba400cda283635025ec14000000000000000000000000cf8e7573894cb97d2589efdaf04cf65b8ad94cd9000000000000000000000000ff326878d13b33591d286372e67b4af05cd100bd000000000000000000000000b8dddc25e6a133855ad10c5b0221aa7e6fdef62f0000000000000000000000004ee7e9f5f00ccb61d99af67cbd420ed13df3d2f9000000000000000000000000af919dcba4889fe115541157481af08e6cd4ff79000000000000000000000000da94148af0565669dd419ebc0354113ce0a3583b000000000000000000000000d23341b1042b673a10e7a4f56b8550b190648c6f000000000000000000000000b2aa129cea71bb30f53f47b11b086b5132f15169000000000000000000000000a59fc9fddb1e3d803b2c3d3456a4451ab6349b19000000000000000000000000a9c98385db572a270c790d3a5c503d2ee89d9f1f0000000000000000000000005c198b248dfc1c428d29558df90347115a3f3f65000000000000000000000000a338096d43effc151e7e89519b524ca5a7e5626f", contractAddress: "", cumulativeGasUsed: "7543153", gasUsed: "901219", confirmations: "1012492"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[12],addressList[8],addressList[37],addressList[9],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72]]}, {type: "uint256", name: "amount", value: "2000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[12],addressList[8],addressList[37],addressList[9],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72]], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542290574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0xdccd48f9412947763adaa833f51121116b44e281"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xc17d8400f7ee5f65674717b12283bc328312bdd2"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xb2969d3429e99e4846e5be4df47d74ba87069e0d"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x733d35a79dcdda443263fce3147105c9aac7a55f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xf037747527b99d9dc705f23a2b914be19f204de1"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x008d04c54469018da69a18eca01898bb443d1e61"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x97da7fdbafe3647656561850f17233a07d6c9c9c"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xd10d6e8fca3042edd7387608f99a3009fa3bf14f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x9d79bd745d1506d9b8a732a5e1825369ab383938"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xb3817ad14517c19c4dbbb410b20510c48ce72102"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xc3ed58b8fb45dbf294ccdb9fd59fa2be05c7d0e1"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x54488ad9f88cf00397de235d343c421dcb4d5245"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x484cffcb47d4775004e242bdb6fe19ddf3cc67ed"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x80fe58a8e4ee88eebf20a362b912a0446c14d690"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xf05af483aa06588346b4c2a30d3759ea31ca900b"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x9a10fc45cf5469606c74b915f88dd90d59658dab"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x6b344d70d3d72bd214d6d158545a006651c44337"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xa1f685f4175c7bc3db055042f06a143de4fd230d"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x28cd26d85b4ac655a489aa3f259f81283bd1a804"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xcbe5cc860332b6661192dc71c62cccbe3de650a1"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x2239806aae7fd1a0053144c351d66d74edd90ec1"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x99f0c984129978e73c504a09040c1cdfc1e3fa71"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xc4a821ce10d6da42d63937f0ea5581ace0e039cc"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xb277c8c7a48a5d1418cf9a4a38e642f2d7989e56"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x830e3a6766c753e041aa5b78e94213972a99d400"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x611b13d54f0423bc87abdc113aa9d2512a472735"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x29e898a03b58dac7eecba400cda283635025ec14"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xcf8e7573894cb97d2589efdaf04cf65b8ad94cd9"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xff326878d13b33591d286372e67b4af05cd100bd"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xb8dddc25e6a133855ad10c5b0221aa7e6fdef62f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x4ee7e9f5f00ccb61d99af67cbd420ed13df3d2f9"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xaf919dcba4889fe115541157481af08e6cd4ff79"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xda94148af0565669dd419ebc0354113ce0a3583b"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xd23341b1042b673a10e7a4f56b8550b190648c6f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xb2aa129cea71bb30f53f47b11b086b5132f15169"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xa59fc9fddb1e3d803b2c3d3456a4451ab6349b19"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xa9c98385db572a270c790d3a5c503d2ee89d9f1f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x5c198b248dfc1c428d29558df90347115a3f3f65"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xa338096d43effc151e7e89519b524ca5a7e5626f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[4], \"1157920892373161954200... )", async function( ) {
		const txOriginal = {blockNumber: "6710590", timeStamp: "1542307553", hash: "0xab10ae7db789777a79ec53fb22e985714015420dd621b293e3ae991c78968245", nonce: "20", blockHash: "0x75cb945d8f8d51f4999a6ada95570f051e67e4958be408505f5fe10d1594e060", transactionIndex: "68", from: "0x219c32a3add86913fcf259ce938378f07779d702", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000ad84d21b6be3957aa4de1504958bd264463304aeffffffffffffffff6e5d2d49dbd61e236e98bdcba76f3b769800000000000000", contractAddress: "", cumulativeGasUsed: "4870897", gasUsed: "46783", confirmations: "1011329"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[4]}, {type: "uint256", name: "value", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[4], "115792089237316195420000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542307553 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x219c32a3add86913fcf259ce938378f07779d702"}, {name: "spender", type: "address", value: "0xad84d21b6be3957aa4de1504958bd264463304ae"}, {name: "value", type: "uint256", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "22930678678630826" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[73],addressList[74]] )", async function( ) {
		const txOriginal = {blockNumber: "6715198", timeStamp: "1542371236", hash: "0x8dff055d3ac6cd954f52ef468ab714430f83a7725b7a45c82062730445a36cbf", nonce: "48", blockHash: "0xa2481c98869bb9ddacae31214b282f402e53bcced7061df9a60cd7395289b2bc", transactionIndex: "178", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000007402016e38c676e11f5b4556082311f8b00b6d940000000000000000000000005fd861ad220995d1e8d847474c4388f09c53774b", contractAddress: "", cumulativeGasUsed: "7458531", gasUsed: "66185", confirmations: "1006721"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[73],addressList[74]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[73],addressList[74]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542371236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[73],addressList[74]] )", async function( ) {
		const txOriginal = {blockNumber: "6715220", timeStamp: "1542371618", hash: "0x48020efddeddbad1ead66d7d93eddbb7e71519c8090d2af7149bec8e451e0022", nonce: "49", blockHash: "0xd1dfa4b7738f97a1989710f7d0bfbd637b25ade66c7c13539901d94ccdc80ceb", transactionIndex: "72", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "6100000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000007402016e38c676e11f5b4556082311f8b00b6d940000000000000000000000005fd861ad220995d1e8d847474c4388f09c53774b", contractAddress: "", cumulativeGasUsed: "3702350", gasUsed: "36185", confirmations: "1006699"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[73],addressList[74]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[73],addressList[74]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542371618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[73], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6715230", timeStamp: "1542371797", hash: "0x0d4a1cd8325b4320c49782983d045f5a19406ec91453919efdf02b769eb4807b", nonce: "50", blockHash: "0x0893ef64211d2133880e97978e0d7068cea7cee1f661e409aba3768d3d4854cc", transactionIndex: "140", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000007402016e38c676e11f5b4556082311f8b00b6d94000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "6424388", gasUsed: "45631", confirmations: "1006689"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[73]}, {type: "uint256", name: "value", value: "50000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[73], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542371797 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0x7402016e38c676e11f5b4556082311f8b00b6d94"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[73],addressList[74]] )", async function( ) {
		const txOriginal = {blockNumber: "6715406", timeStamp: "1542374264", hash: "0x90a1baf513e83f91a6e851b23e8a19f6df67a6741812568ee7946f861c23ca88", nonce: "51", blockHash: "0xb80b3a2bf8bf95361a76b57ec31430115161e56bd87306222d5a5bbc9741e0d0", transactionIndex: "34", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "5218750000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000007402016e38c676e11f5b4556082311f8b00b6d940000000000000000000000005fd861ad220995d1e8d847474c4388f09c53774b", contractAddress: "", cumulativeGasUsed: "5923926", gasUsed: "36185", confirmations: "1006513"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[73],addressList[74]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[73],addressList[74]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542374264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[73], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6715410", timeStamp: "1542374289", hash: "0x8634998b5516f771a48b05a26a463617b05d4b3f4e90692938efaacc364650a9", nonce: "52", blockHash: "0xdcfe8a93fa99f6e701743502e12662b68703508e253b74d278965139709a28de", transactionIndex: "26", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000007402016e38c676e11f5b4556082311f8b00b6d94000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "3660183", gasUsed: "30631", confirmations: "1006509"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[73]}, {type: "uint256", name: "value", value: "50000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[73], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542374289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0x7402016e38c676e11f5b4556082311f8b00b6d94"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[73], \"115792089237316195420... )", async function( ) {
		const txOriginal = {blockNumber: "6715458", timeStamp: "1542374925", hash: "0x818139066ef187bdff935d826930635191b90a5dbe61b35a25d41c8f8c1cf9b9", nonce: "24", blockHash: "0xdc6f8bbe40d51c3ba23878aa30c9aa82de8e9b9ee43bd920eecee60a7b7fd937", transactionIndex: "57", from: "0x219c32a3add86913fcf259ce938378f07779d702", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000007402016e38c676e11f5b4556082311f8b00b6d94ffffffffffffffff6e5d2d49dbd61e236e98bdcba76f3b769800000000000000", contractAddress: "", cumulativeGasUsed: "3755042", gasUsed: "46783", confirmations: "1006461"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[73]}, {type: "uint256", name: "value", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[73], "115792089237316195420000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542374925 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x219c32a3add86913fcf259ce938378f07779d702"}, {name: "spender", type: "address", value: "0x7402016e38c676e11f5b4556082311f8b00b6d94"}, {name: "value", type: "uint256", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "22930678678630826" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[75]], \"2000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6721646", timeStamp: "1542463489", hash: "0x1052051bec309bde3f91fa08cf89719858029e61e4cf8702a8cf5f463c6f37b4", nonce: "59", blockHash: "0x47c6730c4c6c42e0a4ee706dfba5c39c2bdac33257b31cb4b736873d55713c2b", transactionIndex: "128", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "78348", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000006c6b935b8bbd40000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000001b83f6e9c6d7f5f3c154beb834daf5032ba15a39", contractAddress: "", cumulativeGasUsed: "5912440", gasUsed: "52232", confirmations: "1000273"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[75]]}, {type: "uint256", name: "amount", value: "2000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[75]], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542463489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0x1b83f6e9c6d7f5f3c154beb834daf5032ba15a39"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[76],addressList[77]] )", async function( ) {
		const txOriginal = {blockNumber: "6721980", timeStamp: "1542468068", hash: "0x3adeeb44641156a448bcaaa3a0d185af1b3c9018d71ae60d0d5eb8f16486483d", nonce: "64", blockHash: "0x18459763967353c6a8e6008888d51371a548e3194200b05b8245cab2560a5d69", transactionIndex: "73", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000dc3464488676175423f6d4c09dd6e43bdf6e7796", contractAddress: "", cumulativeGasUsed: "6727735", gasUsed: "66185", confirmations: "999939"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[76],addressList[77]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[76],addressList[77]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542468068 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[76],addressList[77]] )", async function( ) {
		const txOriginal = {blockNumber: "6721983", timeStamp: "1542468128", hash: "0xac232e5a220f2607f8eab512baa7fb3be02094686f240fd161b73ae9ab81fb52", nonce: "65", blockHash: "0x0cc6f658985b2e5b8b9f4e3bf16e7dbaf1baeba52639084743ab6ee28ad72943", transactionIndex: "36", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000dc3464488676175423f6d4c09dd6e43bdf6e7796", contractAddress: "", cumulativeGasUsed: "2713178", gasUsed: "36185", confirmations: "999936"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[76],addressList[77]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[76],addressList[77]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542468128 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[76],addressList[77]] )", async function( ) {
		const txOriginal = {blockNumber: "6721998", timeStamp: "1542468365", hash: "0xac844e04b9ff7a58facb1fde52fecf6b0d62a6d76c47d03a4f4b0b6c4992695b", nonce: "66", blockHash: "0x5e79a9226dbeecbe7e003fffb9a5298f71b22533e4f0e648bb4acd193e2c83aa", transactionIndex: "96", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000dc3464488676175423f6d4c09dd6e43bdf6e7796", contractAddress: "", cumulativeGasUsed: "6027283", gasUsed: "36185", confirmations: "999921"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[76],addressList[77]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[76],addressList[77]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542468365 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[76],addressList[77]] )", async function( ) {
		const txOriginal = {blockNumber: "6722021", timeStamp: "1542468651", hash: "0xfedac8fbac9db074296c27919d236969b6465cb4539999829efce433767bbd04", nonce: "67", blockHash: "0xd04752049300a46a0de00976a18da7941ef56e66c4b9c14213291d854a89c5ef", transactionIndex: "99", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000dc3464488676175423f6d4c09dd6e43bdf6e7796", contractAddress: "", cumulativeGasUsed: "5508276", gasUsed: "36185", confirmations: "999898"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[76],addressList[77]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[76],addressList[77]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542468651 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[76], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6722023", timeStamp: "1542468682", hash: "0x8d6eae85bd457ae96604aba18ea6b2ae5b10bb22d240082e43c9cf00922e9113", nonce: "68", blockHash: "0xb7d41b1245626569f105115f71c25411908cd95f2a051b89d18a3e34bcf9384f", transactionIndex: "3", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "15320000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "163693", gasUsed: "45631", confirmations: "999896"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[76]}, {type: "uint256", name: "value", value: "50000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[76], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542468682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0xdd18c392914c19e0f6688a8c9ef93a4860834cdf"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[76],addressList[77]] )", async function( ) {
		const txOriginal = {blockNumber: "6722041", timeStamp: "1542468875", hash: "0xeb16fa7a16c60ce8c9fa15b4e4f426a47db71eab3c97a77e5c995bec41ef4714", nonce: "69", blockHash: "0x5805e18eb76f10b29d118b9c21058a31a3572fa06f5722135f851fb1ebe1fe7a", transactionIndex: "156", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000dc3464488676175423f6d4c09dd6e43bdf6e7796", contractAddress: "", cumulativeGasUsed: "7155931", gasUsed: "36185", confirmations: "999878"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[76],addressList[77]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[76],addressList[77]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542468875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[76],addressList[77]] )", async function( ) {
		const txOriginal = {blockNumber: "6722097", timeStamp: "1542469810", hash: "0xcbdaa3ead0cd59a0f9b28c7c0b4a18f7d2f8d500b67a18a50635e0262c41b100", nonce: "70", blockHash: "0x9217e1ef81eea675efe96ed637877f066224478ca5214bea4403f513a63b3769", transactionIndex: "193", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000dc3464488676175423f6d4c09dd6e43bdf6e7796", contractAddress: "", cumulativeGasUsed: "7890364", gasUsed: "36185", confirmations: "999822"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[76],addressList[77]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[76],addressList[77]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542469810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[76],addressList[77]] )", async function( ) {
		const txOriginal = {blockNumber: "6722118", timeStamp: "1542470112", hash: "0xa59c7d6e333876d719d711193bcea112d5e22adde5e8268f70bf522570ffe172", nonce: "71", blockHash: "0x2a5752af3f494463d74601c6abdc45e439cf1254986899eb175ab51ee04f2a4e", transactionIndex: "116", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "3600000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000dc3464488676175423f6d4c09dd6e43bdf6e7796", contractAddress: "", cumulativeGasUsed: "7556264", gasUsed: "36185", confirmations: "999801"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[76],addressList[77]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[76],addressList[77]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542470112 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[76], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6722120", timeStamp: "1542470182", hash: "0xc96289ecfffede6f1fcc281d498253f972f05c4817303d3a0134deaaaff05045", nonce: "72", blockHash: "0xb0032211b48ad74626665a64d5590f98d03719de3c56598efd7dbb4b21577752", transactionIndex: "76", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "15320000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdf000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "1845248", gasUsed: "30631", confirmations: "999799"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[76]}, {type: "uint256", name: "value", value: "50000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[76], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542470182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0xdd18c392914c19e0f6688a8c9ef93a4860834cdf"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[8]], \"20000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6722131", timeStamp: "1542470313", hash: "0x2cf35e4a9be1e819dac1457c3a796aa8f172a48b70c8e3f9dd4f3beb8b856062", nonce: "74", blockHash: "0xebe745973906cca8767cc031fb372c224f373306c55d2e6c8a5a248e8956daf2", transactionIndex: "10", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "2000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000ad78ebc5ac62000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000c17d8400f7ee5f65674717b12283bc328312bdd2", contractAddress: "", cumulativeGasUsed: "403676", gasUsed: "37168", confirmations: "999788"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[8]]}, {type: "uint256", name: "amount", value: "200000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[8]], "200000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542470313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0xc17d8400f7ee5f65674717b12283bc328312bdd2"}, {name: "amount", type: "uint256", value: "200000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[78],addressList[8]], \"2000... )", async function( ) {
		const txOriginal = {blockNumber: "6726651", timeStamp: "1542533695", hash: "0xb17a4e69dbf14a5f583b8cf40cedd25935fff9426bf0915612de114f64ba2235", nonce: "75", blockHash: "0x7396a9b23621e999453fde33c833667e288824f37b5d2db019efb22235b81a5e", transactionIndex: "7", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "2000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000ad78ebc5ac62000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000a2ab1ac4862e3e04bb3e6100c41631eafc011877000000000000000000000000c17d8400f7ee5f65674717b12283bc328312bdd2", contractAddress: "", cumulativeGasUsed: "830611", gasUsed: "60640", confirmations: "995268"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[78],addressList[8]]}, {type: "uint256", name: "amount", value: "200000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[78],addressList[8]], "200000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542533695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0xa2ab1ac4862e3e04bb3e6100c41631eafc011877"}, {name: "amount", type: "uint256", value: "200000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xc17d8400f7ee5f65674717b12283bc328312bdd2"}, {name: "amount", type: "uint256", value: "200000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[79]], \"2000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6726693", timeStamp: "1542534249", hash: "0xabb80562f97badebe3a26c3c510f6d3c26385cd16fd7c0d611ad7dcf1b72040c", nonce: "76", blockHash: "0x2fddc0ebe582c47cef853fe3ddd2456d8820a50342b90cf21040ccb87e59572c", transactionIndex: "45", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "2000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000ad78ebc5ac6200000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000037a8ca1312c3b7f1f4e0b7b08c6633f1d747e3fe", contractAddress: "", cumulativeGasUsed: "4766349", gasUsed: "52232", confirmations: "995226"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[79]]}, {type: "uint256", name: "amount", value: "200000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[79]], "200000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542534249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0x37a8ca1312c3b7f1f4e0b7b08c6633f1d747e3fe"}, {name: "amount", type: "uint256", value: "200000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[76], \"115792089237316195420... )", async function( ) {
		const txOriginal = {blockNumber: "6731128", timeStamp: "1542596775", hash: "0x17ac4a2cc4935fba387845daf27ce22871f78da80bb164f702bcf7be15d07364", nonce: "1", blockHash: "0x42635508788c459bbafb5aa0149d7e287f74aedc4fe326eb8c86c4d5dcd38611", transactionIndex: "169", from: "0x733d35a79dcdda443263fce3147105c9aac7a55f", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000dd18c392914c19e0f6688a8c9ef93a4860834cdfffffffffffffffff6e5d2d49dbd61e236e98bdcba76f3b769800000000000000", contractAddress: "", cumulativeGasUsed: "7705589", gasUsed: "46783", confirmations: "990791"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[76]}, {type: "uint256", name: "value", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[76], "115792089237316195420000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542596775 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x733d35a79dcdda443263fce3147105c9aac7a55f"}, {name: "spender", type: "address", value: "0xdd18c392914c19e0f6688a8c9ef93a4860834cdf"}, {name: "value", type: "uint256", value: "115792089237316195420000000000000000000000000000000000000000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2523034012280404" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[2]], \"10000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732763", timeStamp: "1542620143", hash: "0x1e845707b318495a787b3f33e7087cfa02244b57fdcd5e41a73690eb3c0d5ea7", nonce: "81", blockHash: "0x3f8541bc050b9a5911b0e518ea2d89d5634e88884ada06e66b7b4cedd04b940d", transactionIndex: "216", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "78444", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000152d02c7e14af68000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000cfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", contractAddress: "", cumulativeGasUsed: "6803769", gasUsed: "52296", confirmations: "989156"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[2]]}, {type: "uint256", name: "amount", value: "100000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[2]], "100000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542620143 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "amount", type: "uint256", value: "100000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[3]], \"10000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732787", timeStamp: "1542620446", hash: "0x6e361a8d6c1db2dae646f939cf68b40c253f6b8ee52bb18000276cc1b68c1f22", nonce: "82", blockHash: "0xbd19d4f2c3ac10f2c3fbc9e48b3f02f3ec131888bb571d485f3e6cb660386664", transactionIndex: "118", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "55944", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000152d02c7e14af68000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000629573ad5a234a921628bf6bfd545949ca8b6eed", contractAddress: "", cumulativeGasUsed: "7234106", gasUsed: "37296", confirmations: "989132"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[3]]}, {type: "uint256", name: "amount", value: "100000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[3]], "100000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542620446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "amount", type: "uint256", value: "100000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[80],addressList[81]] )", async function( ) {
		const txOriginal = {blockNumber: "6732805", timeStamp: "1542620713", hash: "0x68c56839c433e6b8f44927949eff8ea6902f3c3c5257ce6f422a1ed682e3131d", nonce: "86", blockHash: "0x2c27ca5928f7675124e4957f122feabd15eb834f90d460f75a938f9dae06d496", transactionIndex: "180", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000a1f958f922b89b3f3ffcd881895fcee672944e830000000000000000000000004b13e3b09bc214450946572275d0b316fd918ed5", contractAddress: "", cumulativeGasUsed: "7519880", gasUsed: "66185", confirmations: "989114"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[80],addressList[81]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[80],addressList[81]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542620713 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[80],addressList[81]] )", async function( ) {
		const txOriginal = {blockNumber: "6732816", timeStamp: "1542620824", hash: "0x5688616a988b130961b7cf9cbe28c341e254ddb5cb97485ecf7f4a8ae4d20c91", nonce: "87", blockHash: "0x799e36e325f286b6b7b39c88d829f2b03d49c0af564ef7dbb18f8095af558852", transactionIndex: "89", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000a1f958f922b89b3f3ffcd881895fcee672944e830000000000000000000000004b13e3b09bc214450946572275d0b316fd918ed5", contractAddress: "", cumulativeGasUsed: "3744411", gasUsed: "36185", confirmations: "989103"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[80],addressList[81]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[80],addressList[81]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542620824 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[80], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732819", timeStamp: "1542620842", hash: "0x166ee2e2c48d53dcb512a8e5f575aa921348bf1662440b23713d6ace2770923e", nonce: "88", blockHash: "0x410d61b95683bc6d8e7a8b2774c4863466b64c6dc4d5e9a4bc4dc860f6e18fef", transactionIndex: "7", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "15320000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000a1f958f922b89b3f3ffcd881895fcee672944e8300000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "196847", gasUsed: "45631", confirmations: "989100"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[80]}, {type: "uint256", name: "value", value: "1000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[80], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542620842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0xa1f958f922b89b3f3ffcd881895fcee672944e83"}, {name: "value", type: "uint256", value: "1000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: issue( [addressList[82],addressList[83],address... )", async function( ) {
		const txOriginal = {blockNumber: "6733018", timeStamp: "1542623515", hash: "0x999dee76cad5cc74f9000d179582d141767fc9e1653dd793174cedba1eb5a815", nonce: "90", blockHash: "0xf58ea2bab3751894d55324a188b1185b178032e947ac8f808098c1a27f374c41", transactionIndex: "159", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "607812", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x42958b54000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000006c6b935b8bbd4000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000dfe496f26a428936d0f806b535734448acf97f8b0000000000000000000000009c10096cbac0ec393d89fd4754a3b350a610e08f0000000000000000000000002b1d2d290268cb4c4862d4a658f1c2a663c0f79a000000000000000000000000551ff91a3cda6794680f6df2c93ae70f062cb28c000000000000000000000000ce77f7af5a4fc879226d001723938d614018ce830000000000000000000000007b2e78d4dfaaba045a167a70da285e30e8fca1960000000000000000000000002dabb24e53b5d14980cb9df20d05bcfd3a9f4b0f000000000000000000000000cec56f1d4dc439e298d5f8b6ff3aa6be58cd6fdf000000000000000000000000e8f08d7dc98be694cda49430ca01595776909eac000000000000000000000000ac9ba72fb61aa7c31a95df0a8b6eba6f41ef875e000000000000000000000000bc4104ba80cc3734d62cdb4ca612a85e0bff99ed000000000000000000000000843dcf1e6c509ba962e31723202bacc671a7cfb80000000000000000000000001d89d4a14cecc19e03dfda7846ecddef8e41b7e5000000000000000000000000c73add416e2119d20ce80e0904fc1877e33ef246000000000000000000000000a5abf3ea06abbd0b9ec40caeb77f8fb0fe42fcb700000000000000000000000073c86e55dc0754210deb63c306a144db77f632e8", contractAddress: "", cumulativeGasUsed: "6037908", gasUsed: "405208", confirmations: "988901"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "recipients", value: [addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97]]}, {type: "uint256", name: "amount", value: "2000000000000000000000"}], name: "issue", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issue(address[],uint256)" ]( [addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97]], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542623515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Issuance", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Issuance", events: [{name: "owner", type: "address", value: "0xdfe496f26a428936d0f806b535734448acf97f8b"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x9c10096cbac0ec393d89fd4754a3b350a610e08f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x2b1d2d290268cb4c4862d4a658f1c2a663c0f79a"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x551ff91a3cda6794680f6df2c93ae70f062cb28c"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xce77f7af5a4fc879226d001723938d614018ce83"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x7b2e78d4dfaaba045a167a70da285e30e8fca196"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x2dabb24e53b5d14980cb9df20d05bcfd3a9f4b0f"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xcec56f1d4dc439e298d5f8b6ff3aa6be58cd6fdf"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xe8f08d7dc98be694cda49430ca01595776909eac"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xac9ba72fb61aa7c31a95df0a8b6eba6f41ef875e"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xbc4104ba80cc3734d62cdb4ca612a85e0bff99ed"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x843dcf1e6c509ba962e31723202bacc671a7cfb8"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x1d89d4a14cecc19e03dfda7846ecddef8e41b7e5"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xc73add416e2119d20ce80e0904fc1877e33ef246"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0xa5abf3ea06abbd0b9ec40caeb77f8fb0fe42fcb7"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}, {name: "Issuance", events: [{name: "owner", type: "address", value: "0x73c86e55dc0754210deb63c306a144db77f632e8"}, {name: "amount", type: "uint256", value: "2000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[98],addressList[99]] )", async function( ) {
		const txOriginal = {blockNumber: "6733173", timeStamp: "1542626162", hash: "0x61da80a93f92d08008bbda5e2d4612c58bf3423786b30e9e205c8accb9191649", nonce: "94", blockHash: "0xc675757dd5d3a0e20379d43a8ca79151f86a78f3cc13db45e69ff3f8a233c181", transactionIndex: "21", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "9720000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000200000000000000000000000046c0a081a869f6d9fde6d5e83dbf24b887fccd770000000000000000000000003821d641f34b7c9be01c619d03c84dc7a053d832", contractAddress: "", cumulativeGasUsed: "4101026", gasUsed: "66185", confirmations: "988746"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[98],addressList[99]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[98],addressList[99]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542626162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[98], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6733175", timeStamp: "1542626213", hash: "0xff1cfee288b1ab244e758d89e4b92d5862cb40d202a8eb3591353cd603aa0e3f", nonce: "95", blockHash: "0x9cc444affd56ea7c4e28f1585b336f631d5166afbeac2520d63a5f1d6e23de2c", transactionIndex: "93", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "15320000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b300000000000000000000000046c0a081a869f6d9fde6d5e83dbf24b887fccd7700000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "5856372", gasUsed: "45631", confirmations: "988744"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[98]}, {type: "uint256", name: "value", value: "1000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[98], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542626213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0x46c0a081a869f6d9fde6d5e83dbf24b887fccd77"}, {name: "value", type: "uint256", value: "1000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[100],addressList[101]] )", async function( ) {
		const txOriginal = {blockNumber: "6733264", timeStamp: "1542627302", hash: "0x1e1f46f90d38240e533289b355be8a901bc59d10470f66671e4a624bece33d83", nonce: "100", blockHash: "0xc3cbbee60198557a9606daf07c6be318da1a4091d6ef2895b7a693c5784b690d", transactionIndex: "117", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000007b31a6b8ed486482a87639dbe7b9fbf20efde50e000000000000000000000000f90be09571296383018fe44ea34dc381e88e574f", contractAddress: "", cumulativeGasUsed: "5270391", gasUsed: "66185", confirmations: "988655"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[100],addressList[101]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[100],addressList[101]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542627302 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[100], \"10000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6733266", timeStamp: "1542627333", hash: "0x0e95fd6d56182f7dbb545ef19a8e801a975e3bad0432a897826e78362220ac8e", nonce: "101", blockHash: "0xef4d3c7220dbbd4d90636dc1e7bfcd6f010034ae7d8a2c7705348f3d3ea58192", transactionIndex: "15", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "136132", gasPrice: "15320000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000007b31a6b8ed486482a87639dbe7b9fbf20efde50e00000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "633635", gasUsed: "45631", confirmations: "988653"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[100]}, {type: "uint256", name: "value", value: "1000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[100], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542627333 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x629573ad5a234a921628bf6bfd545949ca8b6eed"}, {name: "spender", type: "address", value: "0x7b31a6b8ed486482a87639dbe7b9fbf20efde50e"}, {name: "value", type: "uint256", value: "1000000000000000000000"}], address: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[102],addressList[103]] )", async function( ) {
		const txOriginal = {blockNumber: "6733312", timeStamp: "1542628048", hash: "0x422661bc253115acd815b8cfd812071e8cfc38de8d0e1af765686e94f1d914d8", nonce: "106", blockHash: "0x906502c80f40f45c8dbe0437f8bd74c164e1460317ba77133f94a50d547d73fe", transactionIndex: "146", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "66185", gasPrice: "6156250000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000cb9eea0d2c94f5601649601e30f97d21f052960b0000000000000000000000003748baa24b424fb0ee4d197dfdff664d4050b167", contractAddress: "", cumulativeGasUsed: "7522731", gasUsed: "66185", confirmations: "988607"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[102],addressList[103]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[102],addressList[103]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542628048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: allowTransfers( [addressList[102],addressList[103]] )", async function( ) {
		const txOriginal = {blockNumber: "6733347", timeStamp: "1542628606", hash: "0xa7141d113547bc333ad6b3f104125064f5b8c221fab0ad204f7efb38c8e0e827", nonce: "107", blockHash: "0x86b29b50b5a71336c60a14eb79266efa7b82fbcc006441db6f9cf194f5ba163a", transactionIndex: "77", from: "0x629573ad5a234a921628bf6bfd545949ca8b6eed", to: "0xcfc64d8eaeb4e6a68860e415f55dfe9057da7d2d", value: "0", gas: "36185", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x136ef18a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000cb9eea0d2c94f5601649601e30f97d21f052960b0000000000000000000000003748baa24b424fb0ee4d197dfdff664d4050b167", contractAddress: "", cumulativeGasUsed: "4607488", gasUsed: "36185", confirmations: "988572"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "allowed", value: [addressList[102],addressList[103]]}], name: "allowTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allowTransfers(address[])" ]( [addressList[102],addressList[103]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542628606 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
