const Oraclize = artifacts.require( "./Oraclize.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Oraclize" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x3dBDc81a6edc94c720B0B88FB65dBD7e395fDcf6", "0x5B2D063205c643c8f0974a5c36c584e0C17459CC", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0x324FcCB8cA8b746FF179AFd700ea5F9528867FD3", "0xee9147dd0307e4A663D0f756549d47d6F8BD356b", "0x60Aa80fe41B43c180870a137c7A87334e5C3cb5D", "0xaAE10c1223df062E2Df6982A80621977fA8B2D34", "0x78F6A1d4b94d2e6c4cE3c5CC858b9dfB6e98B50f", "0x4B99a8676EA959759a56c5f4fd2EbC6F16A07792", "0x65b4770B096bB882dA4DCefDA0619c4DF15bbcEB", "0xABFE1a1CfFAc17514A17fDDcA9Ec10Cc40e8784e", "0x6777c314B412F0196aCA852632969F63e7971340", "0xC9EDC5b5375505CCA18C45B4A801725696845d5a", "0xd70F3F0038108753Df5Eb4Df242D2969297d2c8D", "0xB2E3AC7EDe9a375A4eeF541fF221f1DfF768CE1d", "0x1843ccB1816ac6E682488AD3424470cd8a54bbEA", "0x8c28Ae8b6f1ed01578EDd85a91a899Eaf6D0F291", "0x09D4b4014Db27DdFbC73393af4F0A8f444E539eA", "0x61e1599D75283927fd470f52866Dcf05F10e841b", "0x699a80E0f7e6e9980c6ab707550b03529393C372", "0xd1fDD663F59DAe08Ff426B64F73C610A332064A7", "0x573DA486711E3CfAfbF4b22cd71C280A33c38222", "0xee0bf603Ab3AAdf3387eD48882Cc0c5ec84f7240", "0x4B92a948Ced9D457b4655aBf62ed930a090f8566", "0xb95Dd00B76c15B11Ae82e875e9719029Cd4d2110", "0x75a931567048EdD4F349Fa1A1cFBC4b4dcA352c9", "0xD3c9836230d43E85C643607cEc509138F2955Da8", "0x2AB9f67A27f606272189b307052694D3a2B158bA", "0x4Ff99C63f181E6C92948757920DfE7E6b5b0b968", "0x5b912B9172A1a6A01d73184782dbcF5e232D7BA5", "0x3fcCb426c33b1ae067115390354B968592348D05", "0x082AB4c52a11D8c086fD9acAEBd8c3e67247260C", "0xA8C03c43659c6B024a54384405EF8fc61d3137dd", "0x83eF2c534F4d842e7730Ec29211c10f7b26F2806", "0xb3bF7996CC178ededeDf2b242121e0E8CfCBE4B5", "0x389d62b6258f2b8261812C61A57A6F8D24cC9d88", "0xcE04A41bd0A254da543269042dB2370c879e95d8", "0x982268f66b5c4eb2A4cD88B8C6d2EA2a2628Df49", "0x7eA6Df636d385a51dD0a3AdB1D46440eC916aDAf", "0x86ec459FF58e6608C4615c4b3404c0E93BBd1836", "0x9Ba91E4963eD5e1BBDFC3C221783A0F8f4eB52C2", "0x4D54bE5a62F5d9fcF4b17C7ab6e68822C142ec6B", "0xE2f0e4986cb2D548bF363eFd4593d786497727Ec", "0x0D00BE66287A989ADb6b8cC434e9E934e6076695", "0x6A846B662ed513C1Bcb66A5072201F9B26cF5ca8", "0x75D9946Bf9584E5381834E5024BbDaD2E3FF7e53", "0xbb78e5b275fcf001501d6708f58D18200D9A83ff", "0xa8Cd51814bddfeFad87B9e69A778A913D9a5e323", "0x12f8c63034AAC487396b70db04aBA5c84dEd1886", "0xf7D02347D055BD3a1FD66a7F187C4453fb6882AA", "0x76BC9E61A1904B82CbF70d1fd9C0f8a120483BbB", "0xC9943f62f39563F700C694d2FCB13A5f574fEb6C", "0xa88146aed78cbA4a98Eb7F6c25158587a9E49544", "0x17eC9A8e3D4085092688B9168269c25A775C4204", "0x85c548a176f86BCAAD45e96a7758538dDAbA3A65", "0x8355048D74888569ad9f9675ae9B6920F54b9985", "0xDF7339BFaD0f4F1837367cdCd965A61084D340b9", "0x1ea9D718b3f8c589f1373f7Be631F4444236bCf5", "0xc5f7349B642AEA160cCE3798508a79f863a8Ac8E", "0x3CED1A903ee79509900E14aEa3d07bC457aE6A2b", "0x6F95398479752b606730c327CcdE2674A1F054a2", "0x92243f25Cf872b08D336742A8db93B6DF11c5F25", "0xc31651AB6DEBB448A73958a548E883B97473b211", "0x6b57b3D9044FADD4a204a8f2587305f05B5D9874", "0x370dB4a8308F5419A0DE1f29A6872Bc96151AaEB", "0x98eC4F93E1a61Ffc8124b06b0962462E560479e0", "0x597d181568467eC7D77Efe40fd6b3f3BFa6A3de3", "0x748a0cE285C40fD7Ee1B71820Ee9CA02Cbb3dFEc", "0xEd099BABd29347de3812D38d0DB6B53C48507aDa", "0x390A6AB0684073ae6caBe6c390A43e87B117Ed0A", "0x5471b11DBA5c2b94442afAf82909De3cb6A9A9C3", "0x1E8396E912Abd599695482ddc13b584A188aCD93", "0x4e87a723a3a75C41e34aD6e6995f724d9abdc745", "0x960E766f126Ff30Efb5688dAbd24ccB4eF67f31D", "0xa341d53E64198cbA938465236d1b3d9a929E0732", "0xccf13891822BF2de0cAcD300d2Ce6f27ABCE8aBE", "0xfDfd8a46146bCc7B12BcEE778c4562937849181f", "0x108284702b23504DE29D3293f2530255C6b3CCeA", "0x6Dd38916b8C3780Fd487980C54c90C175017664c", "0x96843f4763B86FEfd1f56aa7133e24ACf2a88EfD", "0x84BFD848717d60E01805B34D38A0d8B1F2bc4E85", "0xd4160356A4e81f008b86F9867e71D1e1404c5292", "0xC3b643bb85318B6a0e1B46c30365AdAcDF9469C2", "0x29aAFBd3a13A5f02F2D6B78eD1034208b08b44D3", "0x285761a0Fd6aEfbeE84f7377Db9f3b666f04d41d", "0xDB1c54Df945050CEFaC0fab75D3C955F50c1BCba", "0xB2f910366e53Bd60fE245F5db96e8E58224A30ab", "0xcE8D197e13C10D6e81A094f1067138AE29DD95dc", "0x4e646A576917a6A47D5B0896c3E207693870869D", "0xE8A51bE86ad96447D45DDEdDc55013f25157688c", "0xe642B6f79041C60d8447679B3a499F18D8B03b81", "0x1E2Fbe6BE9Eb39Fc894d38be976111F332172d83", "0xdd98b423dc61A756e1070De151b1485425505954", "0x49fDdEae0b521dAb8d0c4b77E7161094F971320D", "0x7DA90089A73edD14c75B0C827cb54f4248D47eCc", "0xc8942C648F6e523B174d0e03A02b8812A8eADA67", "0x5fC37db74Bdb13A771493f598A47d5Edad1A995a", "0xA1a979657a25a7f871C1588464Cbb4a83bb96730", "0x102102460df017670Ba8ca9a03eA8b2Db36097c8", "0x987C442F0d606636bdE7413A5F275A6AB6d43288", "0xdcf59eE4803931A376a0fB6244036E49ebc7dd61", "0x130951893C010916b34773293e05404cEe93D5c5", "0x4634090363CDcF1edBC28464F72bb771177135F7", "0x053936be1D3F030EEf39546285085a82bF717e81", "0x1D7Fe72C49c4D08b5a92883B703D9871A60e8fe3", "0xB919B2903e07293bc84372471A7081eCb69E8d36", "0x1Fa8b177dc1A9AA12f52cc15db4A514e12194e21", "0x807A3EF8A8dBDD7fc9863Df695bbe8691E450e8e", "0x1C95408a4De3E1Ebb5955C65189843271DF20201", "0x5CE309215190159429dB5E2522E6C59C31A8F427", "0x4FeC6Fb7ae16Fab18662db770DaB6F2D5A115739", "0x69F705C4Dc75eBDc88CfCbCe937059E1C2a22111", "0x96C6774622532dd729Db608f84C285fEDFc0CC0B", "0x4280DBb6F11d1d147711D1564B9077C7A847431b", "0x1D979bd0b663040f2Fe8A9854A8569919aE153aC", "0x5C430fA24F782cF8156cA97208C42127b17b0494", "0x847458F925E56a158610B6cab2Ed076Fc5Ba6a75", "0x4ec0E441270db6f6C3c1CF08aF2D9e1e92474883", "0x3A39963f9A98eFD58E3163b345e28E97BEb3D614", "0x64cDd7a96fBC40b98432d94322F935D4D6F9CB53", "0x77de87E8d0503E0170827791e8DAcC527A99bc84", "0x69f86C1994FBBC5896d3808DBd3a7DB89ad2830c", "0x0851185501bA44E84Fd8Af13aDE44846F00890B7", "0x2fdBfff4df9f8D7C8eF2500389bf75fa56c6d777", "0x910d87254972e98B9b1d7d088792e5fCaF4C694D", "0x8a4c5E1362ac227afACcEDF582130282DE76aA95", "0x2f3cad6364caAF8Eba52B0B42c364Cc65EbeD69a", "0x912179f3307461e195942e4807D162897e6Bc213", "0xac5B6Aa65B8A3025DFBD81F355cBfCdabd2f5845", "0x9496F6a6D7Df728998374A733a8Fea0a0CbE4Ea7", "0x5e363Fc01C1dA0604709C3b9B3Af8b805568d462", "0xF501f9E51041C379Ee64d07F8e41E7390beadc23", "0xFAf96A0354A3A71f741A200A93bF79f0394aAC4c", "0xBcc0F7e5C93FE6EA8c1FEA821F8Ca71389128ac5", "0x695838ddFB02A1E36139593371a02e0F9b5c99e7", "0xBd72A2170b92b467665E55DECC4F86452C7cB115", "0x0b78438D1b83D529f192729734979c83f0369E56", "0x443dcADf55A41D7CAF347b4d925041065FeC66F6", "0x863693E4A6e65AB96a1eB0EB65681E8Aecb6182b", "0xfB74048Eb4926De18BaE23c8A7aC336E6636a3b3", "0x53AAaa7bD2592479c399A341e974995B5E359890", "0x94Ab42736484344aD693d732AD1fA3bccd872C80", "0xFfD52115544e9440C5CfBdCb02b083Ce1bc24518", "0xF50EBB00013d8A0eFfe1c093E9012748A83Aa920", "0xE82363e45Cc235d941Ee5A125c714616775B4f8D", "0xC3c6198390daB6837F1BC5A98e2Eb4eE489E44d0", "0xe6517b766E6Ee07f91b517435ed855926bCb1AaE", "0x39B3C8616928c7F9c21cfbF0Ec44E8020f49799D", "0x21610Ca60cD879899c83d2cF026D3C27584Ff38c", "0x1ca0324F275B4C34F7f89Ab2fe6F84e425E3c6B3", "0x65AB2360129575019e437c9A0745DB12EB3DE8B3", "0xD8a5b0D3CB3B00113A0cD96856926Dc555D9e752", "0xb134bBC1e6df09233a8138368b6560C68A960e68", "0x9Eb455B6F1B90EbFF057d56902A2eCB0cB0D2E29", "0xa24688d145e9edA5E92615b4073F0250FE9b4bd5", "0x07B0448Fe6C0C6EcE7FAE3AB4a21dDc78fA87d24", "0x7Ed58877581d07bB4238a8B4D341E54C609b73c2", "0xc5c49c5f57d9F1635dDe956C6858146717879600", "0x74bA2381Cf72778293401aa5EeEa22ADfe0a2f92", "0x9a4B479D68AdEEA16FCd538d4613dfDCDD8EC2F1", "0xbC10f4E0Ee2856a21a9754df93359968464C3969", "0xFCEF311967105531C4234b105a0D1a49b0fC04ff", "0xfaF4a5fbf621B049215C19a73baBd0B94fD9155F", "0xfe5E5D3D64f2e600ABCe4889d75fC88F8AEd30b6", "0xb38bd84C4d8fD969D9A60dA7b7383b73e6efcdDd", "0x1aB033443BE1616F62F2Ce6E23FD1468279692E6", "0xec6DA574185F4ee599C9522A18107f9099f49f43", "0xe39240f2199e2582Ce0F4667f19ac3fA0abf6205", "0x395cF3ecd8794e9b2C58c2FFF0e3D9E58f939319", "0x8316b95945AbDbc15FB7736C1620E9904cd1D9e5", "0xDD5d965b26E1d11f7933797B465fA95c89C368f5", "0x2700B4469Ddb14f435e57ecA538E95f43d9E6c38", "0x9DC69490EC0d558f8F62b6d0aD64611B621A026E", "0x6410504202C3fD106baadB2A1c1782B0aDAd1654", "0x2DD78551C49D739C4A0ae80E4F863E74bE39e1CB", "0x7C07b7b34dA43f240Ed6d4EdaeFE9a986Aa01BfC", "0xb69d539c777E7793Fda30f31633dE321e8feE613", "0x77d7536EB289F61C47C728142Bda4da54cA9C71F", "0xD081de30e74E459f245B5d0d1A74aBd4dA657212", "0xb397DD90E19E4aC4559BECeB388C07bD001E7743", "0xA545dA30f0A7cB1D3eAFa7e4aDd768d66A993be1", "0x612b83dEa4b89AeF724CE4CCdC21a7b9eaDDF902", "0xf0cfB6e33aF9A0bBF70b37662C0f5B3C7483B16D", "0x7e5A67154C566f1fdd8AD5B671d7CF8CbFC97182", "0x0F822AE3FC6E3305B33F95D905C9967bae244d82", "0x2a7E1F7932240A1e0609B4b993933649163D8755", "0xC4DA73d42593485555879B6b1DCB7925aec0e6e3", "0xaF458dF877510b7249aEa6d49dD7d18f435d6939", "0xfcC5A37F3FEac32Dd90B6381262Ef653cccbB449", "0x22CdaA7B4460A046F0Cc9878A4f79fDC2f187316", "0x8F3d6447a647Ecf3c185ecbB165D2e6C41FAd547", "0x11691aD4E9BF379420BD2bB0119fC328aCd5067a", "0x05Ef6Aa798fB4aeB7517Ce53116F6743a99F3Bb6", "0x85278c33aeE0A79E9fB39BA16322d9Ca214ad1Cd", "0xc7E89224bad0DC7308B37C86104d767C12dD5983", "0x84215bf78e828adc764f986003B08bA40aBbB839", "0xA98a60041FBa1b04EA9E9b17D848ccf4f0f0A1B2", "0xAD9662Ac19138599170Efd026436B5851633500A", "0xc8356b1dB0b3951AbAe0ABBfF13d7A5Fa1359A71", "0x2536ec01e4BcBB6a3712F492E96eeE390B07904A", "0xc528EDD1296E0A4B0EBE48507b3787F6861e25Eb", "0xCD749891ab70EA716E8663CBB333F95C5f07461D", "0xd0F379bb8d779000Fd092177f11Ae28129f9004f", "0x5B62Df6cEa296C715070fccB895c4e1408DFca71", "0x94E7eF42A814A7A522985A574caBdF51C72ff0e2", "0x150d11f1eEBbB35Ce5d4946eE81332d2dC79C2ba", "0xa334509B08C834f222ae3dC46b43F1bD61eA535D", "0xFEc7b9A92dc88F934E8a5ff299Bb1ac5e6595677", "0x164875d5FA1CcF6d33eb1f075853d11Fe7e95d89", "0xEce701C76bD00D1C3f96410a0C69eA8Dfcf5f34E", "0xd0615b06EE71C4CC975B8C40D76E6c78f7358C85", "0xab743c3363712BD68D38f642a38608Ace2fE77Ba", "0xa2BA05472c4504ED6cF2D65e0251bC65aA0115B8", "0x05bA948A753769df37491EB70908aF78C5F57779", "0xE15E57fE0D93E2F898d80A1AFa6a33da682358e9", "0xA43653B0088Ce10f6c5446DcEc472388989145B7", "0x542d09f9E38c96FbbfE2812d19f485Ab1bE62C98", "0x132F795705650a46c593a7c3442819D3E3e36Ff7", "0x2d623F30194870EDf32F2d85c80B9E6ffb7Db9F8", "0x02b97CCa6D6A5227E464b2a60EE1A580EA4F7da9", "0x34E95dB6D0ADf44E1EEcB7860daE5833088832c4", "0x6BF2e20B21005dDc16e09f89F3b483D126e7Fbc8", "0x3BEF6f53Cd3066D982BeB61688B41c238a68f8e5", "0x63660B981B022790487d2B6026C18EA038A46Aa5", "0xF2E5A8c518092AD97a14d877E6376837a561e2C9", "0x663a5cA0295231B0d88afB1C557a8D8f4C1B6459", "0x2d3B62a8B756103E417D161c20e97E76eD5Ef0c2", "0xc45695480F688e6DC0cff576efE72219dBd3AAdC", "0x0869d49644Ce3FD53DCbfa824b3794c0b4AE3774", "0x7909f0B4A0c25F126F85E010Aa573C64e5E2EBf9", "0x162D558AC8F3b8ABA5f549066AC81dF4Ddc912A2", "0xd51C109110E7ccB7f6B84DdD2485c2F8E2753415", "0xBeD503A443565d7f0005805EdBC33c0cD8F4a4b3", "0xdCCa8FA09BeC1205Ea2946b5fa466D72123b70F8", "0x8cd2bBc42f030FfFAbF79DE4f176980Eed843fd3", "0x639e250b6Eb084e2B3575EAAc76873221b431Bbb", "0x249a7c08536211393fC3dd5323e70Ae21a18368a", "0xbE87AFf8814d4A465ad04c47ec2570cA9ef15B36", "0x16aA4c5a51042EfeDdc86dEA4B454b085b4A80B2", "0x9c1F59bDDdc90D65d3B47adb1069a1B257818493", "0x131cF0D3b3cc6763417bffb2DfDC119FdeBcA002", "0xE8528c3139b571C8A306C08c4A6861D47622B968", "0x78aEAA0929f933bC0Ea3A2eb5A1d07ac6e21401D", "0x9b26BA3A1D66CcA67Aa413da042a144A39c554B9", "0x221Ea1B119B4Aa2C6b4E2282AB0b621B1f54CF61", "0xc797f7d82962157b4c73d43Dc7723DF0f82c0194", "0xB57b9206d75c1bb02Cb64F97fB5176eAE731a62d", "0x736D9b6A58aB142e9EA171FB9cb5C401deCbE1D0", "0xEdA2B1CC85743AD07d6eB8E5a22cDBE142C10E6d", "0x9a9C62cC05ceb3C189C43B18B070821794DB6944", "0xd768Bca1ca5e5DeFF16274Be27e24552AC08D2F2", "0x5A13CAA82851342E14cd2Ad0257707CDdb8A31b7", "0xDb9822bb9885d844d1986a8949fCe1a4ceb5F8B6", "0xaD227491E11bB69bE013B0d5029D6A3128986FC7", "0x29a90a9236bC4D3Fbf8CA0ae29659815B3460d58", "0x10ff783574C0610b947f6c1Fe019cBa845c88656", "0x3EEDF709634c949A3c3F77C6f588BaFCc695ca44", "0xE8cBA706c07850b322f8fcE1c93bdE83Ef3bF8A1", "0x41fF0796a6c7a201476Bff53C4Cb2C48B084e5e0", "0x5d501E399a4C406a2fDa69A3F67BB0727F40A9c2", "0xc2551126B9Bb8DB7530Bf884A8C1c1Fda80615d4", "0xf0cdC385709f1aD604b6d11965208a8c505D7dFF", "0x5d892A70870637DAeF7284c185Cb8666B549C049", "0xbe1d8403A63B4875f2103EcFa16C9f0cFD29d0f8", "0x5182184f125aAfA0B7e22A0FE5A573071A4Df39a", "0x2E28A7EA669F01C3625a3c691E06251c92671289", "0xdE027676C2c22CC1F2cC7676083b04520E3CA891", "0x5936d34a49aAa7bbAEffBA2cF7f7c191bD96477d", "0x735049b443724377157f9d07E5A05bdbA4A5C234", "0xb83CbEb1E3b188D0a71a2929472143b34a28780A", "0x712E6ABDc6F70A8b6D1f300E2b82606F31475002", "0xAe57CbF3152fA894D4A6c61F496f663Da46aF4b2", "0xC619211800679c0c2f01E404CF866f0dFB5B89Bd", "0xd39ed6143D5A69a25D7FCB06b1bB554f2debAAAe", "0xD72eaD482B15197B99f74d846E8180D7F33670df", "0x6BA8e05E0F36afc72ea18f89A0c1693d7832c52C", "0xffC08dD84A66775e6236e0A80ee2f340e0042f8C", "0x2549f29844BAA2fd283B949E7C35C45829FF3edc", "0xA9244061223eedFa34FFa05f3EBdC8083276aCeA", "0x0AaF8865a6Cbf417e7AD51Fe71Fe60F1a0C192F8", "0x366374a2EC8A244B7da7e51d6df460ec8a3B8b14", "0xa1A465548fe36dCAB13cd3150e45037460d425E8", "0xdaff1F98299b12d475b4725a2635e5bA291aA651", "0x600a115702a44A7372fe9A7fD93fc2fC67F9eEB4", "0x1c923bC27998465f0b197EF73C7AeeC9359169D3", "0x2D5426edBa78238D71ccBdBb6947959037FdA532", "0x3023D5Ee05EBeE74b61F940433b7783EAc1F221E", "0x4220698BE33a9738898f430018f28aECeeCAA6FF", "0xE5a04D98538231b0fAb9ABa60cd73cE4fF3039DF", "0x102011Cb0f7109E98a4E98DFbaCd792bFB343e14", "0x5dC80a9056685eCfc07Bd3bbF080484962c8Ba81", "0x376E355F94d930808b6b8F46Ebfe8Cd1C114C64f", "0xa35FE1BCfDe297a328Dd4Ef0bC902FB1CA7661cB", "0x358bd9446e79eE20c0FBAa4f3BFf31d794bFe8B9", "0x912f5be7f4Ef37C6f8B443cA1D83F3b7a5f88787", "0xa456D1E4DcE1Cec1CdE58faE10D1b6385bc86Ed9", "0x2b12390D999DADA036A7C8909b753b0d13c552D5", "0x60991c469dF42A9dc1292A40978f59197895a330", "0xD91E45416bfbBEc6e2D1ae4aC83b788A21Acf583"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "baseprice", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "offchainPayment", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "randomDS_getSessionPubKeyHash", outputs: [{name: "", type: "bytes32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "cbAddress", outputs: [{name: "_cbAddress", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "cbAddresses", outputs: [{name: "", type: "bytes1"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "randomDS_sessionPubKeysHash", outputs: [{name: "", type: "bytes32"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "cid", type: "bytes32"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "datasource", type: "string"}, {indexed: false, name: "arg", type: "string"}, {indexed: false, name: "gaslimit", type: "uint256"}, {indexed: false, name: "proofType", type: "bytes1"}, {indexed: false, name: "gasPrice", type: "uint256"}], name: "Log1", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "cid", type: "bytes32"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "datasource", type: "string"}, {indexed: false, name: "arg1", type: "string"}, {indexed: false, name: "arg2", type: "string"}, {indexed: false, name: "gaslimit", type: "uint256"}, {indexed: false, name: "proofType", type: "bytes1"}, {indexed: false, name: "gasPrice", type: "uint256"}], name: "Log2", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "cid", type: "bytes32"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "datasource", type: "string"}, {indexed: false, name: "args", type: "bytes"}, {indexed: false, name: "gaslimit", type: "uint256"}, {indexed: false, name: "proofType", type: "bytes1"}, {indexed: false, name: "gasPrice", type: "uint256"}], name: "LogN", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "cid", type: "bytes32"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "datasource", type: "string"}, {indexed: false, name: "arg", type: "string"}, {indexed: false, name: "callback", type: "function"}, {indexed: false, name: "gaslimit", type: "uint256"}, {indexed: false, name: "proofType", type: "bytes1"}, {indexed: false, name: "gasPrice", type: "uint256"}], name: "Log1_fnc", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "cid", type: "bytes32"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "datasource", type: "string"}, {indexed: false, name: "arg1", type: "string"}, {indexed: false, name: "arg2", type: "string"}, {indexed: false, name: "callback", type: "function"}, {indexed: false, name: "gaslimit", type: "uint256"}, {indexed: false, name: "proofType", type: "bytes1"}, {indexed: false, name: "gasPrice", type: "uint256"}], name: "Log2_fnc", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "cid", type: "bytes32"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "datasource", type: "string"}, {indexed: false, name: "args", type: "bytes"}, {indexed: false, name: "callback", type: "function"}, {indexed: false, name: "gaslimit", type: "uint256"}, {indexed: false, name: "proofType", type: "bytes1"}, {indexed: false, name: "gasPrice", type: "uint256"}], name: "LogN_fnc", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Log1(address,bytes32,uint256,string,string,uint256,bytes1,uint256)", "Log2(address,bytes32,uint256,string,string,string,uint256,bytes1,uint256)", "LogN(address,bytes32,uint256,string,bytes,uint256,bytes1,uint256)", "Log1_fnc(address,bytes32,uint256,string,string,function,uint256,bytes1,uint256)", "Log2_fnc(address,bytes32,uint256,string,string,string,function,uint256,bytes1,uint256)", "LogN_fnc(address,bytes32,uint256,string,bytes,function,uint256,bytes1,uint256)", "Emit_OffchainPaymentFlag(address,address,bool,bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xb76d0edd90c6a07aa3ff7a222d7f5933e29c6acc660c059c97837f05c4ca1a84", "0xaf30e4d66b2f1f23e63ef4591058a897f67e6867233e33ca3508b982dcc4129b", "0x3af7d71c651d8670228b02a0b636ffa73a7f759ef99ff9c024bc3b044a724438", "0x5051eab4e301cef16e893db3c7a192f8cbf7bb44e1a92b928665c66170930a39", "0xcc57f89a6a20799d672e6569d224340220a0891ad6efa3039e7728f0c88854b3", "0x90552fb8e54d9a2aa4212413b16aa948c66cab32c9fe727ff74be1850bb0a8be", "0x84feab93d65c19f28e91b26f8245938bf3a97dab7b8dafe3c8b028954e9ac934"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4360011 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4836970 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Oraclize", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "baseprice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "baseprice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "offchainPayment", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "offchainPayment(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "randomDS_getSessionPubKeyHash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "randomDS_getSessionPubKeyHash()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cbAddress", outputs: [{name: "_cbAddress", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cbAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "cbAddresses", outputs: [{name: "", type: "bytes1"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cbAddresses(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "randomDS_sessionPubKeysHash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "randomDS_sessionPubKeysHash(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Oraclize", function( accounts ) {

	it( "TEST: Oraclize(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4360011", timeStamp: "1507834639", hash: "0x962940b08cf2cb39502fa43f0a86550f9fdf5079f145cc9936b53eb587544751", nonce: "55", blockHash: "0x1b39e4356fe4413b3ecab184b288617d753057a46138f0760a7fdabdb2540a9d", transactionIndex: "44", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: 0, value: "0", gas: "3408687", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x0e1ca8a5", contractAddress: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", cumulativeGasUsed: "5503108", gasUsed: "3186737", confirmations: "3357471"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Oraclize", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Oraclize.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1507834639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Oraclize.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addCbAddress( addressList[4], \"0x10\" )", async function( ) {
		const txOriginal = {blockNumber: "4360032", timeStamp: "1507835330", hash: "0x8fcb47e4dcb18cc6586d0d1bc55f0a1e0b474dbd57ef144e0d33e95227354e46", nonce: "56", blockHash: "0x1091e8d29abbb678b92679bedf338a53c8d9373cf31c63c3757cbb3d9f93fc70", transactionIndex: "60", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "44520", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x627fd3bb00000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d511000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3348816", gasUsed: "44520", confirmations: "3357450"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newCbAddress", value: addressList[4]}, {type: "bytes1", name: "addressType", value: "0x10"}], name: "addCbAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCbAddress(address,bytes1)" ]( addressList[4], "0x10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1507835330 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51402437707986901630" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setBasePrice( \"3327142086313\" )", async function( ) {
		const txOriginal = {blockNumber: "4360034", timeStamp: "1507835374", hash: "0x561744c0f5ecc08a2c04f167fe0748a3ae311dc5cb5d42d3b2400d320c041131", nonce: "57", blockHash: "0xd98670ceb74190415fd7e0fbf9d1087f2fe80e0405619bf7dc0d6ac55a20cf56", transactionIndex: "108", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "43353", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xde4b326200000000000000000000000000000000000000000000000000000306a91f46a9", contractAddress: "", cumulativeGasUsed: "4921278", gasUsed: "43353", confirmations: "3357448"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "new_baseprice", value: "3327142086313"}], name: "setBasePrice", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setBasePrice(uint256)" ]( "3327142086313", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1507835374 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51402437707986901630" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: randomDS_updateSessionPubKeysHash( [\"0x3026b44b0b8ac5e1a5443dd54e2ff107479... )", async function( ) {
		const txOriginal = {blockNumber: "4360065", timeStamp: "1507836407", hash: "0x016591a6f48bbeb02af1a91daec6692121ab251ee1fc0b44364ea28b49727f83", nonce: "58", blockHash: "0xa125cf06b8c53e3f752918662a6c49145bc3f86b904540297d4c988067138624", transactionIndex: "25", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "70555", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x512c0b9c000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000013026b44b0b8ac5e1a5443dd54e2ff1074790b4ae736a67d35cfc1464f7747f2d", contractAddress: "", cumulativeGasUsed: "1270889", gasUsed: "70555", confirmations: "3357417"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_newSessionPubKeysHash", value: ["0x3026b44b0b8ac5e1a5443dd54e2ff1074790b4ae736a67d35cfc1464f7747f2d"]}], name: "randomDS_updateSessionPubKeysHash", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "randomDS_updateSessionPubKeysHash(bytes32[])" ]( ["0x3026b44b0b8ac5e1a5443dd54e2ff1074790b4ae736a67d35cfc1464f7747f2d"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1507836407 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51402437707986901630" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: changePaymentFlagger( addressList[3] )", async function( ) {
		const txOriginal = {blockNumber: "4360066", timeStamp: "1507836478", hash: "0x77a78f3e9124e15d70d1505839738f83b4a92867b26d5b8883519f3637f25569", nonce: "59", blockHash: "0xd8011a9849be70fffb4302f3a8ac01ca85215ea53507bbf35658732601661d99", transactionIndex: "28", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "43915", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x801298fa0000000000000000000000005b2d063205c643c8f0974a5c36c584e0c17459cc", contractAddress: "", cumulativeGasUsed: "1718413", gasUsed: "43915", confirmations: "3357416"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newFlagger", value: addressList[3]}], name: "changePaymentFlagger", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changePaymentFlagger(address)" ]( addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1507836478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51402437707986901630" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: multisetProofType( [\"17\",\"17\",\"17\",\"17\",\"17\",\"17... )", async function( ) {
		const txOriginal = {blockNumber: "4360079", timeStamp: "1507837005", hash: "0xb640b159ba4d8ddfbeb1ce433465e7cffe4a4b82af0a3b294f1ca80a6ca66c98", nonce: "60", blockHash: "0x9266e6fa8d39a2cc3695a5d70a1eef9d75ed918113d26ac1a55eac01643488c8", transactionIndex: "46", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "4000000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xdb37e42f00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000001ac000000000000000000000000000000000000000000000000000000000000000d300000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d3000000000000000000000000324fccb8ca8b746ff179afd700ea5f9528867fd3000000000000000000000000ee9147dd0307e4a663d0f756549d47d6f8bd356b00000000000000000000000060aa80fe41b43c180870a137c7a87334e5c3cb5d000000000000000000000000aae10c1223df062e2df6982a80621977fa8b2d3400000000000000000000000078f6a1d4b94d2e6c4ce3c5cc858b9dfb6e98b50f0000000000000000000000004b99a8676ea959759a56c5f4fd2ebc6f16a0779200000000000000000000000065b4770b096bb882da4dcefda0619c4df15bbceb000000000000000000000000abfe1a1cffac17514a17fddca9ec10cc40e8784e0000000000000000000000006777c314b412f0196aca852632969f63e7971340000000000000000000000000c9edc5b5375505cca18c45b4a801725696845d5a000000000000000000000000d70f3f0038108753df5eb4df242d2969297d2c8d000000000000000000000000b2e3ac7ede9a375a4eef541ff221f1dff768ce1d0000000000000000000000001843ccb1816ac6e682488ad3424470cd8a54bbea0000000000000000000000008c28ae8b6f1ed01578edd85a91a899eaf6d0f29100000000000000000000000009d4b4014db27ddfbc73393af4f0a8f444e539ea00000000000000000000000061e1599d75283927fd470f52866dcf05f10e841b000000000000000000000000699a80e0f7e6e9980c6ab707550b03529393c372000000000000000000000000d1fdd663f59dae08ff426b64f73c610a332064a7000000000000000000000000573da486711e3cfafbf4b22cd71c280a33c38222000000000000000000000000ee0bf603ab3aadf3387ed48882cc0c5ec84f72400000000000000000000000004b92a948ced9d457b4655abf62ed930a090f8566000000000000000000000000b95dd00b76c15b11ae82e875e9719029cd4d211000000000000000000000000075a931567048edd4f349fa1a1cfbc4b4dca352c9000000000000000000000000d3c9836230d43e85c643607cec509138f2955da80000000000000000000000002ab9f67a27f606272189b307052694d3a2b158ba0000000000000000000000004ff99c63f181e6c92948757920dfe7e6b5b0b9680000000000000000000000005b912b9172a1a6a01d73184782dbcf5e232d7ba50000000000000000000000003fccb426c33b1ae067115390354b968592348d05000000000000000000000000082ab4c52a11d8c086fd9acaebd8c3e67247260c000000000000000000000000a8c03c43659c6b024a54384405ef8fc61d3137dd00000000000000000000000083ef2c534f4d842e7730ec29211c10f7b26f2806000000000000000000000000b3bf7996cc178edededf2b242121e0e8cfcbe4b5000000000000000000000000389d62b6258f2b8261812c61a57a6f8d24cc9d88000000000000000000000000ce04a41bd0a254da543269042db2370c879e95d8000000000000000000000000982268f66b5c4eb2a4cd88b8c6d2ea2a2628df490000000000000000000000007ea6df636d385a51dd0a3adb1d46440ec916adaf00000000000000000000000086ec459ff58e6608c4615c4b3404c0e93bbd18360000000000000000000000009ba91e4963ed5e1bbdfc3c221783a0f8f4eb52c20000000000000000000000004d54be5a62f5d9fcf4b17c7ab6e68822c142ec6b000000000000000000000000e2f0e4986cb2d548bf363efd4593d786497727ec0000000000000000000000000d00be66287a989adb6b8cc434e9e934e60766950000000000000000000000006a846b662ed513c1bcb66a5072201f9b26cf5ca800000000000000000000000075d9946bf9584e5381834e5024bbdad2e3ff7e53000000000000000000000000bb78e5b275fcf001501d6708f58d18200d9a83ff000000000000000000000000a8cd51814bddfefad87b9e69a778a913d9a5e32300000000000000000000000012f8c63034aac487396b70db04aba5c84ded1886000000000000000000000000f7d02347d055bd3a1fd66a7f187c4453fb6882aa00000000000000000000000076bc9e61a1904b82cbf70d1fd9c0f8a120483bbb000000000000000000000000c9943f62f39563f700c694d2fcb13a5f574feb6c000000000000000000000000a88146aed78cba4a98eb7f6c25158587a9e4954400000000000000000000000017ec9a8e3d4085092688b9168269c25a775c420400000000000000000000000085c548a176f86bcaad45e96a7758538ddaba3a650000000000000000000000008355048d74888569ad9f9675ae9b6920f54b9985000000000000000000000000df7339bfad0f4f1837367cdcd965a61084d340b90000000000000000000000001ea9d718b3f8c589f1373f7be631f4444236bcf5000000000000000000000000c5f7349b642aea160cce3798508a79f863a8ac8e0000000000000000000000003ced1a903ee79509900e14aea3d07bc457ae6a2b0000000000000000000000006f95398479752b606730c327ccde2674a1f054a200000000000000000000000092243f25cf872b08d336742a8db93b6df11c5f25000000000000000000000000c31651ab6debb448a73958a548e883b97473b2110000000000000000000000006b57b3d9044fadd4a204a8f2587305f05b5d9874000000000000000000000000370db4a8308f5419a0de1f29a6872bc96151aaeb00000000000000000000000098ec4f93e1a61ffc8124b06b0962462e560479e0000000000000000000000000597d181568467ec7d77efe40fd6b3f3bfa6a3de3000000000000000000000000748a0ce285c40fd7ee1b71820ee9ca02cbb3dfec000000000000000000000000ed099babd29347de3812d38d0db6b53c48507ada000000000000000000000000390a6ab0684073ae6cabe6c390a43e87b117ed0a0000000000000000000000005471b11dba5c2b94442afaf82909de3cb6a9a9c30000000000000000000000001e8396e912abd599695482ddc13b584a188acd930000000000000000000000004e87a723a3a75c41e34ad6e6995f724d9abdc745000000000000000000000000960e766f126ff30efb5688dabd24ccb4ef67f31d000000000000000000000000a341d53e64198cba938465236d1b3d9a929e0732000000000000000000000000ccf13891822bf2de0cacd300d2ce6f27abce8abe000000000000000000000000fdfd8a46146bcc7b12bcee778c4562937849181f000000000000000000000000108284702b23504de29d3293f2530255c6b3ccea0000000000000000000000006dd38916b8c3780fd487980c54c90c175017664c00000000000000000000000096843f4763b86fefd1f56aa7133e24acf2a88efd00000000000000000000000084bfd848717d60e01805b34d38a0d8b1f2bc4e85000000000000000000000000d4160356a4e81f008b86f9867e71d1e1404c5292000000000000000000000000c3b643bb85318b6a0e1b46c30365adacdf9469c200000000000000000000000029aafbd3a13a5f02f2d6b78ed1034208b08b44d3000000000000000000000000285761a0fd6aefbee84f7377db9f3b666f04d41d000000000000000000000000db1c54df945050cefac0fab75d3c955f50c1bcba000000000000000000000000b2f910366e53bd60fe245f5db96e8e58224a30ab000000000000000000000000ce8d197e13c10d6e81a094f1067138ae29dd95dc0000000000000000000000004e646a576917a6a47d5b0896c3e207693870869d000000000000000000000000e8a51be86ad96447d45ddeddc55013f25157688c000000000000000000000000e642b6f79041c60d8447679b3a499f18d8b03b810000000000000000000000001e2fbe6be9eb39fc894d38be976111f332172d83000000000000000000000000dd98b423dc61a756e1070de151b148542550595400000000000000000000000049fddeae0b521dab8d0c4b77e7161094f971320d0000000000000000000000007da90089a73edd14c75b0c827cb54f4248d47ecc000000000000000000000000c8942c648f6e523b174d0e03a02b8812a8eada670000000000000000000000005fc37db74bdb13a771493f598a47d5edad1a995a000000000000000000000000a1a979657a25a7f871c1588464cbb4a83bb96730000000000000000000000000102102460df017670ba8ca9a03ea8b2db36097c8000000000000000000000000987c442f0d606636bde7413a5f275a6ab6d43288000000000000000000000000dcf59ee4803931a376a0fb6244036e49ebc7dd61000000000000000000000000130951893c010916b34773293e05404cee93d5c50000000000000000000000004634090363cdcf1edbc28464f72bb771177135f7000000000000000000000000053936be1d3f030eef39546285085a82bf717e810000000000000000000000001d7fe72c49c4d08b5a92883b703d9871a60e8fe3000000000000000000000000b919b2903e07293bc84372471a7081ecb69e8d360000000000000000000000001fa8b177dc1a9aa12f52cc15db4a514e12194e21000000000000000000000000807a3ef8a8dbdd7fc9863df695bbe8691e450e8e0000000000000000000000001c95408a4de3e1ebb5955c65189843271df202010000000000000000000000005ce309215190159429db5e2522e6c59c31a8f4270000000000000000000000004fec6fb7ae16fab18662db770dab6f2d5a11573900000000000000000000000069f705c4dc75ebdc88cfcbce937059e1c2a2211100000000000000000000000096c6774622532dd729db608f84c285fedfc0cc0b0000000000000000000000004280dbb6f11d1d147711d1564b9077c7a847431b0000000000000000000000001d979bd0b663040f2fe8a9854a8569919ae153ac0000000000000000000000005c430fa24f782cf8156ca97208c42127b17b0494000000000000000000000000847458f925e56a158610b6cab2ed076fc5ba6a750000000000000000000000004ec0e441270db6f6c3c1cf08af2d9e1e924748830000000000000000000000003a39963f9a98efd58e3163b345e28e97beb3d61400000000000000000000000064cdd7a96fbc40b98432d94322f935d4d6f9cb5300000000000000000000000077de87e8d0503e0170827791e8dacc527a99bc8400000000000000000000000069f86c1994fbbc5896d3808dbd3a7db89ad2830c0000000000000000000000000851185501ba44e84fd8af13ade44846f00890b70000000000000000000000002fdbfff4df9f8d7c8ef2500389bf75fa56c6d777000000000000000000000000910d87254972e98b9b1d7d088792e5fcaf4c694d0000000000000000000000008a4c5e1362ac227afaccedf582130282de76aa950000000000000000000000002f3cad6364caaf8eba52b0b42c364cc65ebed69a000000000000000000000000912179f3307461e195942e4807d162897e6bc213000000000000000000000000ac5b6aa65b8a3025dfbd81f355cbfcdabd2f58450000000000000000000000009496f6a6d7df728998374a733a8fea0a0cbe4ea70000000000000000000000005e363fc01c1da0604709c3b9b3af8b805568d462000000000000000000000000f501f9e51041c379ee64d07f8e41e7390beadc23000000000000000000000000faf96a0354a3a71f741a200a93bf79f0394aac4c000000000000000000000000bcc0f7e5c93fe6ea8c1fea821f8ca71389128ac5000000000000000000000000695838ddfb02a1e36139593371a02e0f9b5c99e7000000000000000000000000bd72a2170b92b467665e55decc4f86452c7cb1150000000000000000000000000b78438d1b83d529f192729734979c83f0369e56000000000000000000000000443dcadf55a41d7caf347b4d925041065fec66f6000000000000000000000000863693e4a6e65ab96a1eb0eb65681e8aecb6182b000000000000000000000000fb74048eb4926de18bae23c8a7ac336e6636a3b300000000000000000000000053aaaa7bd2592479c399a341e974995b5e35989000000000000000000000000094ab42736484344ad693d732ad1fa3bccd872c80000000000000000000000000ffd52115544e9440c5cfbdcb02b083ce1bc24518000000000000000000000000f50ebb00013d8a0effe1c093e9012748a83aa920000000000000000000000000e82363e45cc235d941ee5a125c714616775b4f8d000000000000000000000000c3c6198390dab6837f1bc5a98e2eb4ee489e44d0000000000000000000000000e6517b766e6ee07f91b517435ed855926bcb1aae00000000000000000000000039b3c8616928c7f9c21cfbf0ec44e8020f49799d00000000000000000000000021610ca60cd879899c83d2cf026d3c27584ff38c0000000000000000000000001ca0324f275b4c34f7f89ab2fe6f84e425e3c6b300000000000000000000000065ab2360129575019e437c9a0745db12eb3de8b3000000000000000000000000d8a5b0d3cb3b00113a0cd96856926dc555d9e752000000000000000000000000b134bbc1e6df09233a8138368b6560c68a960e680000000000000000000000009eb455b6f1b90ebff057d56902a2ecb0cb0d2e29000000000000000000000000a24688d145e9eda5e92615b4073f0250fe9b4bd500000000000000000000000007b0448fe6c0c6ece7fae3ab4a21ddc78fa87d240000000000000000000000007ed58877581d07bb4238a8b4d341e54c609b73c2000000000000000000000000c5c49c5f57d9f1635dde956c685814671787960000000000000000000000000074ba2381cf72778293401aa5eeea22adfe0a2f920000000000000000000000009a4b479d68adeea16fcd538d4613dfdcdd8ec2f1000000000000000000000000bc10f4e0ee2856a21a9754df93359968464c3969000000000000000000000000fcef311967105531c4234b105a0d1a49b0fc04ff000000000000000000000000faf4a5fbf621b049215c19a73babd0b94fd9155f000000000000000000000000fe5e5d3d64f2e600abce4889d75fc88f8aed30b6000000000000000000000000b38bd84c4d8fd969d9a60da7b7383b73e6efcddd0000000000000000000000001ab033443be1616f62f2ce6e23fd1468279692e6000000000000000000000000ec6da574185f4ee599c9522a18107f9099f49f43000000000000000000000000e39240f2199e2582ce0f4667f19ac3fa0abf6205000000000000000000000000395cf3ecd8794e9b2c58c2fff0e3d9e58f9393190000000000000000000000008316b95945abdbc15fb7736c1620e9904cd1d9e5000000000000000000000000dd5d965b26e1d11f7933797b465fa95c89c368f50000000000000000000000002700b4469ddb14f435e57eca538e95f43d9e6c380000000000000000000000009dc69490ec0d558f8f62b6d0ad64611b621a026e0000000000000000000000006410504202c3fd106baadb2a1c1782b0adad16540000000000000000000000002dd78551c49d739c4a0ae80e4f863e74be39e1cb0000000000000000000000007c07b7b34da43f240ed6d4edaefe9a986aa01bfc000000000000000000000000b69d539c777e7793fda30f31633de321e8fee61300000000000000000000000077d7536eb289f61c47c728142bda4da54ca9c71f000000000000000000000000d081de30e74e459f245b5d0d1a74abd4da657212000000000000000000000000b397dd90e19e4ac4559beceb388c07bd001e7743000000000000000000000000a545da30f0a7cb1d3eafa7e4add768d66a993be1000000000000000000000000612b83dea4b89aef724ce4ccdc21a7b9eaddf902000000000000000000000000f0cfb6e33af9a0bbf70b37662c0f5b3c7483b16d0000000000000000000000007e5a67154c566f1fdd8ad5b671d7cf8cbfc971820000000000000000000000000f822ae3fc6e3305b33f95d905c9967bae244d820000000000000000000000002a7e1f7932240a1e0609b4b993933649163d8755000000000000000000000000c4da73d42593485555879b6b1dcb7925aec0e6e3000000000000000000000000af458df877510b7249aea6d49dd7d18f435d6939000000000000000000000000fcc5a37f3feac32dd90b6381262ef653cccbb44900000000000000000000000022cdaa7b4460a046f0cc9878a4f79fdc2f1873160000000000000000000000008f3d6447a647ecf3c185ecbb165d2e6c41fad54700000000000000000000000011691ad4e9bf379420bd2bb0119fc328acd5067a00000000000000000000000005ef6aa798fb4aeb7517ce53116f6743a99f3bb600000000000000000000000085278c33aee0a79e9fb39ba16322d9ca214ad1cd000000000000000000000000c7e89224bad0dc7308b37c86104d767c12dd598300000000000000000000000084215bf78e828adc764f986003b08ba40abbb839000000000000000000000000a98a60041fba1b04ea9e9b17d848ccf4f0f0a1b2000000000000000000000000ad9662ac19138599170efd026436b5851633500a000000000000000000000000c8356b1db0b3951abae0abbff13d7a5fa1359a710000000000000000000000002536ec01e4bcbb6a3712f492e96eee390b07904a000000000000000000000000c528edd1296e0a4b0ebe48507b3787f6861e25eb000000000000000000000000cd749891ab70ea716e8663cbb333f95c5f07461d000000000000000000000000d0f379bb8d779000fd092177f11ae28129f9004f0000000000000000000000005b62df6cea296c715070fccb895c4e1408dfca7100000000000000000000000094e7ef42a814a7a522985a574cabdf51c72ff0e2000000000000000000000000150d11f1eebbb35ce5d4946ee81332d2dc79c2ba000000000000000000000000a334509b08c834f222ae3dc46b43f1bd61ea535d000000000000000000000000fec7b9a92dc88f934e8a5ff299bb1ac5e6595677000000000000000000000000164875d5fa1ccf6d33eb1f075853d11fe7e95d89000000000000000000000000ece701c76bd00d1c3f96410a0c69ea8dfcf5f34e000000000000000000000000d0615b06ee71c4cc975b8c40d76e6c78f7358c85000000000000000000000000ab743c3363712bd68d38f642a38608ace2fe77ba000000000000000000000000a2ba05472c4504ed6cf2d65e0251bc65aa0115b800000000000000000000000005ba948a753769df37491eb70908af78c5f57779", contractAddress: "", cumulativeGasUsed: "5778911", gasUsed: "3525280", confirmations: "3357403"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_proofType", value: ["17","17","17","17","17","17","17","17","0","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","0","0","0","0","0","0","17","0","0","0","17","17","17","17","0","0","0","0","0","17","17","17","0","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","0","0","0","0","0","17","17","0","17","17","17","17","17","17","17","17","17","0","0","0","0","17","17","17","17","17","17","17","17","0","0","17","0","0","0","0","0","17","0","0","0","0","0","0","0","0","0","17","0","0","0","240","17","17","0","0","0","0","0","0","17","17","17","17","17","17","0","17","0","17","0","0","17","17","17","0","0","0","0","0","17","0","0","0","0","0","17","0","0","17","0","0","17","17","0","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","0","17","17","17","17","17","17","0","0","0","0","17","17","0","0","0","0","17","0","17","0","0"]}, {type: "address[]", name: "_addr", value: [addressList[5],addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215]]}], name: "multisetProofType", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multisetProofType(uint256[],address[])" ]( ["17","17","17","17","17","17","17","17","0","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","0","0","0","0","0","0","17","0","0","0","17","17","17","17","0","0","0","0","0","17","17","17","0","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","0","0","0","0","0","17","17","0","17","17","17","17","17","17","17","17","17","0","0","0","0","17","17","17","17","17","17","17","17","0","0","17","0","0","0","0","0","17","0","0","0","0","0","0","0","0","0","17","0","0","0","240","17","17","0","0","0","0","0","0","17","17","17","17","17","17","0","17","0","17","0","0","17","17","17","0","0","0","0","0","17","0","0","0","0","0","17","0","0","17","0","0","17","17","0","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","0","17","17","17","17","17","17","0","0","0","0","17","17","0","0","0","0","17","0","17","0","0"], [addressList[5],addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1507837005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51402437707986901630" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: multisetCustomGasPrice( [\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0... )", async function( ) {
		const txOriginal = {blockNumber: "4360083", timeStamp: "1507837134", hash: "0x5cb227d7c9bc5d9dd975b7df3728b0cdd3ce4bb7054ec755c4ba7f2738851e51", nonce: "61", blockHash: "0x2f1868ad3c897c07c020406a02cae59023d0c23024826d8bef69ca5da73e595a", transactionIndex: "43", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "3000000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xd959701600000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000001ac000000000000000000000000000000000000000000000000000000000000000d3000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006fc23ac0000000000000000000000000000000000000000000000000000000006fc23ac0000000000000000000000000000000000000000000000000000000006fc23ac0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d3000000000000000000000000324fccb8ca8b746ff179afd700ea5f9528867fd3000000000000000000000000ee9147dd0307e4a663d0f756549d47d6f8bd356b00000000000000000000000060aa80fe41b43c180870a137c7a87334e5c3cb5d000000000000000000000000aae10c1223df062e2df6982a80621977fa8b2d3400000000000000000000000078f6a1d4b94d2e6c4ce3c5cc858b9dfb6e98b50f0000000000000000000000004b99a8676ea959759a56c5f4fd2ebc6f16a0779200000000000000000000000065b4770b096bb882da4dcefda0619c4df15bbceb000000000000000000000000abfe1a1cffac17514a17fddca9ec10cc40e8784e0000000000000000000000006777c314b412f0196aca852632969f63e7971340000000000000000000000000c9edc5b5375505cca18c45b4a801725696845d5a000000000000000000000000d70f3f0038108753df5eb4df242d2969297d2c8d000000000000000000000000b2e3ac7ede9a375a4eef541ff221f1dff768ce1d0000000000000000000000001843ccb1816ac6e682488ad3424470cd8a54bbea0000000000000000000000008c28ae8b6f1ed01578edd85a91a899eaf6d0f29100000000000000000000000009d4b4014db27ddfbc73393af4f0a8f444e539ea00000000000000000000000061e1599d75283927fd470f52866dcf05f10e841b000000000000000000000000699a80e0f7e6e9980c6ab707550b03529393c372000000000000000000000000d1fdd663f59dae08ff426b64f73c610a332064a7000000000000000000000000573da486711e3cfafbf4b22cd71c280a33c38222000000000000000000000000ee0bf603ab3aadf3387ed48882cc0c5ec84f72400000000000000000000000004b92a948ced9d457b4655abf62ed930a090f8566000000000000000000000000b95dd00b76c15b11ae82e875e9719029cd4d211000000000000000000000000075a931567048edd4f349fa1a1cfbc4b4dca352c9000000000000000000000000d3c9836230d43e85c643607cec509138f2955da80000000000000000000000002ab9f67a27f606272189b307052694d3a2b158ba0000000000000000000000004ff99c63f181e6c92948757920dfe7e6b5b0b9680000000000000000000000005b912b9172a1a6a01d73184782dbcf5e232d7ba50000000000000000000000003fccb426c33b1ae067115390354b968592348d05000000000000000000000000082ab4c52a11d8c086fd9acaebd8c3e67247260c000000000000000000000000a8c03c43659c6b024a54384405ef8fc61d3137dd00000000000000000000000083ef2c534f4d842e7730ec29211c10f7b26f2806000000000000000000000000b3bf7996cc178edededf2b242121e0e8cfcbe4b5000000000000000000000000389d62b6258f2b8261812c61a57a6f8d24cc9d88000000000000000000000000ce04a41bd0a254da543269042db2370c879e95d8000000000000000000000000982268f66b5c4eb2a4cd88b8c6d2ea2a2628df490000000000000000000000007ea6df636d385a51dd0a3adb1d46440ec916adaf00000000000000000000000086ec459ff58e6608c4615c4b3404c0e93bbd18360000000000000000000000009ba91e4963ed5e1bbdfc3c221783a0f8f4eb52c20000000000000000000000004d54be5a62f5d9fcf4b17c7ab6e68822c142ec6b000000000000000000000000e2f0e4986cb2d548bf363efd4593d786497727ec0000000000000000000000000d00be66287a989adb6b8cc434e9e934e60766950000000000000000000000006a846b662ed513c1bcb66a5072201f9b26cf5ca800000000000000000000000075d9946bf9584e5381834e5024bbdad2e3ff7e53000000000000000000000000bb78e5b275fcf001501d6708f58d18200d9a83ff000000000000000000000000a8cd51814bddfefad87b9e69a778a913d9a5e32300000000000000000000000012f8c63034aac487396b70db04aba5c84ded1886000000000000000000000000f7d02347d055bd3a1fd66a7f187c4453fb6882aa00000000000000000000000076bc9e61a1904b82cbf70d1fd9c0f8a120483bbb000000000000000000000000c9943f62f39563f700c694d2fcb13a5f574feb6c000000000000000000000000a88146aed78cba4a98eb7f6c25158587a9e4954400000000000000000000000017ec9a8e3d4085092688b9168269c25a775c420400000000000000000000000085c548a176f86bcaad45e96a7758538ddaba3a650000000000000000000000008355048d74888569ad9f9675ae9b6920f54b9985000000000000000000000000df7339bfad0f4f1837367cdcd965a61084d340b90000000000000000000000001ea9d718b3f8c589f1373f7be631f4444236bcf5000000000000000000000000c5f7349b642aea160cce3798508a79f863a8ac8e0000000000000000000000003ced1a903ee79509900e14aea3d07bc457ae6a2b0000000000000000000000006f95398479752b606730c327ccde2674a1f054a200000000000000000000000092243f25cf872b08d336742a8db93b6df11c5f25000000000000000000000000c31651ab6debb448a73958a548e883b97473b2110000000000000000000000006b57b3d9044fadd4a204a8f2587305f05b5d9874000000000000000000000000370db4a8308f5419a0de1f29a6872bc96151aaeb00000000000000000000000098ec4f93e1a61ffc8124b06b0962462e560479e0000000000000000000000000597d181568467ec7d77efe40fd6b3f3bfa6a3de3000000000000000000000000748a0ce285c40fd7ee1b71820ee9ca02cbb3dfec000000000000000000000000ed099babd29347de3812d38d0db6b53c48507ada000000000000000000000000390a6ab0684073ae6cabe6c390a43e87b117ed0a0000000000000000000000005471b11dba5c2b94442afaf82909de3cb6a9a9c30000000000000000000000001e8396e912abd599695482ddc13b584a188acd930000000000000000000000004e87a723a3a75c41e34ad6e6995f724d9abdc745000000000000000000000000960e766f126ff30efb5688dabd24ccb4ef67f31d000000000000000000000000a341d53e64198cba938465236d1b3d9a929e0732000000000000000000000000ccf13891822bf2de0cacd300d2ce6f27abce8abe000000000000000000000000fdfd8a46146bcc7b12bcee778c4562937849181f000000000000000000000000108284702b23504de29d3293f2530255c6b3ccea0000000000000000000000006dd38916b8c3780fd487980c54c90c175017664c00000000000000000000000096843f4763b86fefd1f56aa7133e24acf2a88efd00000000000000000000000084bfd848717d60e01805b34d38a0d8b1f2bc4e85000000000000000000000000d4160356a4e81f008b86f9867e71d1e1404c5292000000000000000000000000c3b643bb85318b6a0e1b46c30365adacdf9469c200000000000000000000000029aafbd3a13a5f02f2d6b78ed1034208b08b44d3000000000000000000000000285761a0fd6aefbee84f7377db9f3b666f04d41d000000000000000000000000db1c54df945050cefac0fab75d3c955f50c1bcba000000000000000000000000b2f910366e53bd60fe245f5db96e8e58224a30ab000000000000000000000000ce8d197e13c10d6e81a094f1067138ae29dd95dc0000000000000000000000004e646a576917a6a47d5b0896c3e207693870869d000000000000000000000000e8a51be86ad96447d45ddeddc55013f25157688c000000000000000000000000e642b6f79041c60d8447679b3a499f18d8b03b810000000000000000000000001e2fbe6be9eb39fc894d38be976111f332172d83000000000000000000000000dd98b423dc61a756e1070de151b148542550595400000000000000000000000049fddeae0b521dab8d0c4b77e7161094f971320d0000000000000000000000007da90089a73edd14c75b0c827cb54f4248d47ecc000000000000000000000000c8942c648f6e523b174d0e03a02b8812a8eada670000000000000000000000005fc37db74bdb13a771493f598a47d5edad1a995a000000000000000000000000a1a979657a25a7f871c1588464cbb4a83bb96730000000000000000000000000102102460df017670ba8ca9a03ea8b2db36097c8000000000000000000000000987c442f0d606636bde7413a5f275a6ab6d43288000000000000000000000000dcf59ee4803931a376a0fb6244036e49ebc7dd61000000000000000000000000130951893c010916b34773293e05404cee93d5c50000000000000000000000004634090363cdcf1edbc28464f72bb771177135f7000000000000000000000000053936be1d3f030eef39546285085a82bf717e810000000000000000000000001d7fe72c49c4d08b5a92883b703d9871a60e8fe3000000000000000000000000b919b2903e07293bc84372471a7081ecb69e8d360000000000000000000000001fa8b177dc1a9aa12f52cc15db4a514e12194e21000000000000000000000000807a3ef8a8dbdd7fc9863df695bbe8691e450e8e0000000000000000000000001c95408a4de3e1ebb5955c65189843271df202010000000000000000000000005ce309215190159429db5e2522e6c59c31a8f4270000000000000000000000004fec6fb7ae16fab18662db770dab6f2d5a11573900000000000000000000000069f705c4dc75ebdc88cfcbce937059e1c2a2211100000000000000000000000096c6774622532dd729db608f84c285fedfc0cc0b0000000000000000000000004280dbb6f11d1d147711d1564b9077c7a847431b0000000000000000000000001d979bd0b663040f2fe8a9854a8569919ae153ac0000000000000000000000005c430fa24f782cf8156ca97208c42127b17b0494000000000000000000000000847458f925e56a158610b6cab2ed076fc5ba6a750000000000000000000000004ec0e441270db6f6c3c1cf08af2d9e1e924748830000000000000000000000003a39963f9a98efd58e3163b345e28e97beb3d61400000000000000000000000064cdd7a96fbc40b98432d94322f935d4d6f9cb5300000000000000000000000077de87e8d0503e0170827791e8dacc527a99bc8400000000000000000000000069f86c1994fbbc5896d3808dbd3a7db89ad2830c0000000000000000000000000851185501ba44e84fd8af13ade44846f00890b70000000000000000000000002fdbfff4df9f8d7c8ef2500389bf75fa56c6d777000000000000000000000000910d87254972e98b9b1d7d088792e5fcaf4c694d0000000000000000000000008a4c5e1362ac227afaccedf582130282de76aa950000000000000000000000002f3cad6364caaf8eba52b0b42c364cc65ebed69a000000000000000000000000912179f3307461e195942e4807d162897e6bc213000000000000000000000000ac5b6aa65b8a3025dfbd81f355cbfcdabd2f58450000000000000000000000009496f6a6d7df728998374a733a8fea0a0cbe4ea70000000000000000000000005e363fc01c1da0604709c3b9b3af8b805568d462000000000000000000000000f501f9e51041c379ee64d07f8e41e7390beadc23000000000000000000000000faf96a0354a3a71f741a200a93bf79f0394aac4c000000000000000000000000bcc0f7e5c93fe6ea8c1fea821f8ca71389128ac5000000000000000000000000695838ddfb02a1e36139593371a02e0f9b5c99e7000000000000000000000000bd72a2170b92b467665e55decc4f86452c7cb1150000000000000000000000000b78438d1b83d529f192729734979c83f0369e56000000000000000000000000443dcadf55a41d7caf347b4d925041065fec66f6000000000000000000000000863693e4a6e65ab96a1eb0eb65681e8aecb6182b000000000000000000000000fb74048eb4926de18bae23c8a7ac336e6636a3b300000000000000000000000053aaaa7bd2592479c399a341e974995b5e35989000000000000000000000000094ab42736484344ad693d732ad1fa3bccd872c80000000000000000000000000ffd52115544e9440c5cfbdcb02b083ce1bc24518000000000000000000000000f50ebb00013d8a0effe1c093e9012748a83aa920000000000000000000000000e82363e45cc235d941ee5a125c714616775b4f8d000000000000000000000000c3c6198390dab6837f1bc5a98e2eb4ee489e44d0000000000000000000000000e6517b766e6ee07f91b517435ed855926bcb1aae00000000000000000000000039b3c8616928c7f9c21cfbf0ec44e8020f49799d00000000000000000000000021610ca60cd879899c83d2cf026d3c27584ff38c0000000000000000000000001ca0324f275b4c34f7f89ab2fe6f84e425e3c6b300000000000000000000000065ab2360129575019e437c9a0745db12eb3de8b3000000000000000000000000d8a5b0d3cb3b00113a0cd96856926dc555d9e752000000000000000000000000b134bbc1e6df09233a8138368b6560c68a960e680000000000000000000000009eb455b6f1b90ebff057d56902a2ecb0cb0d2e29000000000000000000000000a24688d145e9eda5e92615b4073f0250fe9b4bd500000000000000000000000007b0448fe6c0c6ece7fae3ab4a21ddc78fa87d240000000000000000000000007ed58877581d07bb4238a8b4d341e54c609b73c2000000000000000000000000c5c49c5f57d9f1635dde956c685814671787960000000000000000000000000074ba2381cf72778293401aa5eeea22adfe0a2f920000000000000000000000009a4b479d68adeea16fcd538d4613dfdcdd8ec2f1000000000000000000000000bc10f4e0ee2856a21a9754df93359968464c3969000000000000000000000000fcef311967105531c4234b105a0d1a49b0fc04ff000000000000000000000000faf4a5fbf621b049215c19a73babd0b94fd9155f000000000000000000000000fe5e5d3d64f2e600abce4889d75fc88f8aed30b6000000000000000000000000b38bd84c4d8fd969d9a60da7b7383b73e6efcddd0000000000000000000000001ab033443be1616f62f2ce6e23fd1468279692e6000000000000000000000000ec6da574185f4ee599c9522a18107f9099f49f43000000000000000000000000e39240f2199e2582ce0f4667f19ac3fa0abf6205000000000000000000000000395cf3ecd8794e9b2c58c2fff0e3d9e58f9393190000000000000000000000008316b95945abdbc15fb7736c1620e9904cd1d9e5000000000000000000000000dd5d965b26e1d11f7933797b465fa95c89c368f50000000000000000000000002700b4469ddb14f435e57eca538e95f43d9e6c380000000000000000000000009dc69490ec0d558f8f62b6d0ad64611b621a026e0000000000000000000000006410504202c3fd106baadb2a1c1782b0adad16540000000000000000000000002dd78551c49d739c4a0ae80e4f863e74be39e1cb0000000000000000000000007c07b7b34da43f240ed6d4edaefe9a986aa01bfc000000000000000000000000b69d539c777e7793fda30f31633de321e8fee61300000000000000000000000077d7536eb289f61c47c728142bda4da54ca9c71f000000000000000000000000d081de30e74e459f245b5d0d1a74abd4da657212000000000000000000000000b397dd90e19e4ac4559beceb388c07bd001e7743000000000000000000000000a545da30f0a7cb1d3eafa7e4add768d66a993be1000000000000000000000000612b83dea4b89aef724ce4ccdc21a7b9eaddf902000000000000000000000000f0cfb6e33af9a0bbf70b37662c0f5b3c7483b16d0000000000000000000000007e5a67154c566f1fdd8ad5b671d7cf8cbfc971820000000000000000000000000f822ae3fc6e3305b33f95d905c9967bae244d820000000000000000000000002a7e1f7932240a1e0609b4b993933649163d8755000000000000000000000000c4da73d42593485555879b6b1dcb7925aec0e6e3000000000000000000000000af458df877510b7249aea6d49dd7d18f435d6939000000000000000000000000fcc5a37f3feac32dd90b6381262ef653cccbb44900000000000000000000000022cdaa7b4460a046f0cc9878a4f79fdc2f1873160000000000000000000000008f3d6447a647ecf3c185ecbb165d2e6c41fad54700000000000000000000000011691ad4e9bf379420bd2bb0119fc328acd5067a00000000000000000000000005ef6aa798fb4aeb7517ce53116f6743a99f3bb600000000000000000000000085278c33aee0a79e9fb39ba16322d9ca214ad1cd000000000000000000000000c7e89224bad0dc7308b37c86104d767c12dd598300000000000000000000000084215bf78e828adc764f986003b08ba40abbb839000000000000000000000000a98a60041fba1b04ea9e9b17d848ccf4f0f0a1b2000000000000000000000000ad9662ac19138599170efd026436b5851633500a000000000000000000000000c8356b1db0b3951abae0abbff13d7a5fa1359a710000000000000000000000002536ec01e4bcbb6a3712f492e96eee390b07904a000000000000000000000000c528edd1296e0a4b0ebe48507b3787f6861e25eb000000000000000000000000cd749891ab70ea716e8663cbb333f95c5f07461d000000000000000000000000d0f379bb8d779000fd092177f11ae28129f9004f0000000000000000000000005b62df6cea296c715070fccb895c4e1408dfca7100000000000000000000000094e7ef42a814a7a522985a574cabdf51c72ff0e2000000000000000000000000150d11f1eebbb35ce5d4946ee81332d2dc79c2ba000000000000000000000000a334509b08c834f222ae3dc46b43f1bd61ea535d000000000000000000000000fec7b9a92dc88f934e8a5ff299bb1ac5e6595677000000000000000000000000164875d5fa1ccf6d33eb1f075853d11fe7e95d89000000000000000000000000ece701c76bd00d1c3f96410a0c69ea8dfcf5f34e000000000000000000000000d0615b06ee71c4cc975b8c40d76e6c78f7358c85000000000000000000000000ab743c3363712bd68d38f642a38608ace2fe77ba000000000000000000000000a2ba05472c4504ed6cf2d65e0251bc65aa0115b800000000000000000000000005ba948a753769df37491eb70908af78c5f57779", contractAddress: "", cumulativeGasUsed: "3786620", gasUsed: "1545036", confirmations: "3357399"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_gasPrice", value: ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","30000000000","30000000000","30000000000","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"]}, {type: "address[]", name: "_addr", value: [addressList[5],addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215]]}], name: "multisetCustomGasPrice", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multisetCustomGasPrice(uint256[],address[])" ]( ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","30000000000","30000000000","30000000000","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"], [addressList[5],addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1507837134 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51402437707986901630" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: multiAddDSource( [\"0xf1f308360c686bd8b9770385a1c7f66c028... )", async function( ) {
		const txOriginal = {blockNumber: "4360094", timeStamp: "1507837453", hash: "0x715915159af7fdc11d9db87023da3d5b527bc5f19e8f82ddddd9ddcbcf7eb20c", nonce: "62", blockHash: "0x4ec79ad23919da1688c0dff72353e26e26886eddaf0938d0f5c69347d8b38b01", transactionIndex: "38", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "2000000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x6c0f7ee700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001ef1f308360c686bd8b9770385a1c7f66c02883436fbcc8e21986d37938ba5b193d1382a4492cb4b746491bca43ea0b1b140ff7cfa06375a5a2f1189f24986fa2b6f1f10f7717bb477c22c8b8d8377c5ed1edb862fbaa802cd56c9c1226ee30c32fe35147d521ae6068cec247e79ab3e8c55a54c9858c74f3e08d853a99dd81b69a574996f1fb846d2cfdf52083590fba9021982de2db688223d29eea55761466c25c4d8e8135484ea39f063e3022552ce939fcad4dfc0f65c337e045105b7d539e647255fbf9c18642e5a2d842b19c8c211096dc08ad441dea5a02612e60bb9b6b052050c6ed400a931c7e68cb2c3fd217e53c8cfa638ee94c32b17947c0f6ea44c1a071db9bb38c32503d60879c3bec508ee0ff69f5abef5f7396f6827d5e688ed05f27908baf7cf964d34a0353e4756980b7615e5b67a275eede1fc2665784ae557f607141355c5fb666aaedf1d7f6cc78114391d9d539233b772dc3aea2a637c50b7b2ec0be1a24415280fb02e465b25b18537f4529c1b69c994dbd2903aa62aa7d316e238fce7388e8abf3a5b0738bac62397d7f7fcf8b7c2a174d20b65021446780a2eaba4ded140ba8038b5725d6aac3769138ca26eb4375f04d6ca933a82270a89c6f311e9bdaf40d6977cc136cd72acf7e86890c7052df2050ec87fad3d30063a2528aafc1d5b45d8c13bcd17a66320b7f21fa948ce44513636c76fe746ca39880eb8ff045512901be989b533f38e357036abce240c3b2c8166f52d0a95f758656da67a1bea1ac065acd9e770404aa3dfb31aabea36c3ca2cd0dcf17c5b1025619050a5b5c021f9975ed8b018245179d77c1f757e3977233d75a481e525f02893fd2ba0c558818ec09c1c0312b085bccecf759b76c35564afb5695eca5b6379eb33dd6cace0a362cf8f9fc5d6813775e40dfa14d734813c332ec939b36851924ba44a5b28cacbf6b0d1cfde16220c5b4a1b1312d923537d3664b0ca8b3d2e0c09c9a2c21ba086d0c656ba28507123d3bc15f41709feca66d1b660e81add4a1304292c5d228c25dd2e0f58c36b9f987829e213ec30791e28841a60787c1014c9c46d9e4b70a60c690a82aff0e8f831f71f77770f37c0b1e29986a4ab3455c147f860ad35fd2acd6126c96834b1bbd9c4a66bc323bdfeb7081645b6046c8d7c9f7d1ad8b4be0a94c7b4ed4660ba28deb69dfd80da61f5f1f50c3f0a859c82a610b2a76931c80b3893b40bf141744cf59b888db4fc9763beebd0c59c47d69a57694f741dacc7afdc71e342bd3becb4d65cce4cd547e3e6a7e89d0e98d56dbaf1d85af7abc8d0e95eff03c29072ea4942909f91ef2a00b5fd5c594978ad5d000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000001f400000000000000000000000000000000000000000000000000000000000001f4000000000000000000000000000000000000000000000000000000000000021c000000000000000000000000000000000000000000000000000000000000021c000000000000000000000000000000000000000000000000000000000000021c000000000000000000000000000000000000000000000000000000000000021c0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3455334", gasUsed: "1496197", confirmations: "3357388"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "dsHash", value: ["0xf1f308360c686bd8b9770385a1c7f66c02883436fbcc8e21986d37938ba5b193","0xd1382a4492cb4b746491bca43ea0b1b140ff7cfa06375a5a2f1189f24986fa2b","0x6f1f10f7717bb477c22c8b8d8377c5ed1edb862fbaa802cd56c9c1226ee30c32","0xfe35147d521ae6068cec247e79ab3e8c55a54c9858c74f3e08d853a99dd81b69","0xa574996f1fb846d2cfdf52083590fba9021982de2db688223d29eea55761466c","0x25c4d8e8135484ea39f063e3022552ce939fcad4dfc0f65c337e045105b7d539","0xe647255fbf9c18642e5a2d842b19c8c211096dc08ad441dea5a02612e60bb9b6","0xb052050c6ed400a931c7e68cb2c3fd217e53c8cfa638ee94c32b17947c0f6ea4","0x4c1a071db9bb38c32503d60879c3bec508ee0ff69f5abef5f7396f6827d5e688","0xed05f27908baf7cf964d34a0353e4756980b7615e5b67a275eede1fc2665784a","0xe557f607141355c5fb666aaedf1d7f6cc78114391d9d539233b772dc3aea2a63","0x7c50b7b2ec0be1a24415280fb02e465b25b18537f4529c1b69c994dbd2903aa6","0x2aa7d316e238fce7388e8abf3a5b0738bac62397d7f7fcf8b7c2a174d20b6502","0x1446780a2eaba4ded140ba8038b5725d6aac3769138ca26eb4375f04d6ca933a","0x82270a89c6f311e9bdaf40d6977cc136cd72acf7e86890c7052df2050ec87fad","0x3d30063a2528aafc1d5b45d8c13bcd17a66320b7f21fa948ce44513636c76fe7","0x46ca39880eb8ff045512901be989b533f38e357036abce240c3b2c8166f52d0a","0x95f758656da67a1bea1ac065acd9e770404aa3dfb31aabea36c3ca2cd0dcf17c","0x5b1025619050a5b5c021f9975ed8b018245179d77c1f757e3977233d75a481e5","0x25f02893fd2ba0c558818ec09c1c0312b085bccecf759b76c35564afb5695eca","0x5b6379eb33dd6cace0a362cf8f9fc5d6813775e40dfa14d734813c332ec939b3","0x6851924ba44a5b28cacbf6b0d1cfde16220c5b4a1b1312d923537d3664b0ca8b","0x3d2e0c09c9a2c21ba086d0c656ba28507123d3bc15f41709feca66d1b660e81a","0xdd4a1304292c5d228c25dd2e0f58c36b9f987829e213ec30791e28841a60787c","0x1014c9c46d9e4b70a60c690a82aff0e8f831f71f77770f37c0b1e29986a4ab34","0x55c147f860ad35fd2acd6126c96834b1bbd9c4a66bc323bdfeb7081645b6046c","0x8d7c9f7d1ad8b4be0a94c7b4ed4660ba28deb69dfd80da61f5f1f50c3f0a859c","0x82a610b2a76931c80b3893b40bf141744cf59b888db4fc9763beebd0c59c47d6","0x9a57694f741dacc7afdc71e342bd3becb4d65cce4cd547e3e6a7e89d0e98d56d","0xbaf1d85af7abc8d0e95eff03c29072ea4942909f91ef2a00b5fd5c594978ad5d"]}, {type: "uint256[]", name: "multiplier", value: ["10","10","10","10","10","10","50","50","50","50","10","10","10","10","50","50","50","50","30","30","500","500","540","540","540","540","50","50","50","50"]}], name: "multiAddDSource", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multiAddDSource(bytes32[],uint256[])" ]( ["0xf1f308360c686bd8b9770385a1c7f66c02883436fbcc8e21986d37938ba5b193","0xd1382a4492cb4b746491bca43ea0b1b140ff7cfa06375a5a2f1189f24986fa2b","0x6f1f10f7717bb477c22c8b8d8377c5ed1edb862fbaa802cd56c9c1226ee30c32","0xfe35147d521ae6068cec247e79ab3e8c55a54c9858c74f3e08d853a99dd81b69","0xa574996f1fb846d2cfdf52083590fba9021982de2db688223d29eea55761466c","0x25c4d8e8135484ea39f063e3022552ce939fcad4dfc0f65c337e045105b7d539","0xe647255fbf9c18642e5a2d842b19c8c211096dc08ad441dea5a02612e60bb9b6","0xb052050c6ed400a931c7e68cb2c3fd217e53c8cfa638ee94c32b17947c0f6ea4","0x4c1a071db9bb38c32503d60879c3bec508ee0ff69f5abef5f7396f6827d5e688","0xed05f27908baf7cf964d34a0353e4756980b7615e5b67a275eede1fc2665784a","0xe557f607141355c5fb666aaedf1d7f6cc78114391d9d539233b772dc3aea2a63","0x7c50b7b2ec0be1a24415280fb02e465b25b18537f4529c1b69c994dbd2903aa6","0x2aa7d316e238fce7388e8abf3a5b0738bac62397d7f7fcf8b7c2a174d20b6502","0x1446780a2eaba4ded140ba8038b5725d6aac3769138ca26eb4375f04d6ca933a","0x82270a89c6f311e9bdaf40d6977cc136cd72acf7e86890c7052df2050ec87fad","0x3d30063a2528aafc1d5b45d8c13bcd17a66320b7f21fa948ce44513636c76fe7","0x46ca39880eb8ff045512901be989b533f38e357036abce240c3b2c8166f52d0a","0x95f758656da67a1bea1ac065acd9e770404aa3dfb31aabea36c3ca2cd0dcf17c","0x5b1025619050a5b5c021f9975ed8b018245179d77c1f757e3977233d75a481e5","0x25f02893fd2ba0c558818ec09c1c0312b085bccecf759b76c35564afb5695eca","0x5b6379eb33dd6cace0a362cf8f9fc5d6813775e40dfa14d734813c332ec939b3","0x6851924ba44a5b28cacbf6b0d1cfde16220c5b4a1b1312d923537d3664b0ca8b","0x3d2e0c09c9a2c21ba086d0c656ba28507123d3bc15f41709feca66d1b660e81a","0xdd4a1304292c5d228c25dd2e0f58c36b9f987829e213ec30791e28841a60787c","0x1014c9c46d9e4b70a60c690a82aff0e8f831f71f77770f37c0b1e29986a4ab34","0x55c147f860ad35fd2acd6126c96834b1bbd9c4a66bc323bdfeb7081645b6046c","0x8d7c9f7d1ad8b4be0a94c7b4ed4660ba28deb69dfd80da61f5f1f50c3f0a859c","0x82a610b2a76931c80b3893b40bf141744cf59b888db4fc9763beebd0c59c47d6","0x9a57694f741dacc7afdc71e342bd3becb4d65cce4cd547e3e6a7e89d0e98d56d","0xbaf1d85af7abc8d0e95eff03c29072ea4942909f91ef2a00b5fd5c594978ad5d"], ["10","10","10","10","10","10","50","50","50","50","10","10","10","10","50","50","50","50","30","30","500","500","540","540","540","540","50","50","50","50"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1507837453 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51402437707986901630" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: multisetCustomGasPrice( [\"4000000000\",\"4000000000\",\"4000000... )", async function( ) {
		const txOriginal = {blockNumber: "4360109", timeStamp: "1507837738", hash: "0x977678f1269dc152a77b55cee2a69c1b51f4c298ab4c67ab58d2094fbca003e0", nonce: "63", blockHash: "0xfbedb0587ada8bd44c21220d92ce04338abdbd8510db09c4a7314aff52b35b15", transactionIndex: "20", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "467899", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xd9597016000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000002e0000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000ee6b280000000000000000000000000000000000000000000000000000000000ee6b280000000000000000000000000000000000000000000000000000000000ee6b280000000000000000000000000000000000000000000000000000000000ee6b2800000000000000000000000000000000000000000000000000000000012a05f20000000000000000000000000000000000000000000000000000000006fc23ac0000000000000000000000000000000000000000000000000000000009502f900000000000000000000000000000000000000000000000000000000000ee6b280000000000000000000000000000000000000000000000000000000000ee6b280000000000000000000000000000000000000000000000000000000000ee6b280000000000000000000000000000000000000000000000000000000000ee6b280000000000000000000000000000000000000000000000000000000004a817c8000000000000000000000000000000000000000000000000000000000a7a35820000000000000000000000000000000000000000000000000000000004a817c80000000000000000000000000000000000000000000000000000000004a817c80000000000000000000000000000000000000000000000000000000004a817c80000000000000000000000000000000000000000000000000000000004a817c80000000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000165a0bc000000000000000000000000000000000000000000000000000000000165a0bc000000000000000000000000000000000000000000000000000000000000000014000000000000000000000000e15e57fe0d93e2f898d80a1afa6a33da682358e9000000000000000000000000a43653b0088ce10f6c5446dcec472388989145b7000000000000000000000000542d09f9e38c96fbbfe2812d19f485ab1be62c98000000000000000000000000132f795705650a46c593a7c3442819d3e3e36ff70000000000000000000000002d623f30194870edf32f2d85c80b9e6ffb7db9f800000000000000000000000002b97cca6d6a5227e464b2a60ee1a580ea4f7da900000000000000000000000034e95db6d0adf44e1eecb7860dae5833088832c40000000000000000000000006bf2e20b21005ddc16e09f89f3b483d126e7fbc80000000000000000000000003bef6f53cd3066d982beb61688b41c238a68f8e500000000000000000000000063660b981b022790487d2b6026c18ea038a46aa5000000000000000000000000f2e5a8c518092ad97a14d877e6376837a561e2c9000000000000000000000000663a5ca0295231b0d88afb1c557a8d8f4c1b64590000000000000000000000002d3b62a8b756103e417d161c20e97e76ed5ef0c2000000000000000000000000c45695480f688e6dc0cff576efe72219dbd3aadc0000000000000000000000000869d49644ce3fd53dcbfa824b3794c0b4ae37740000000000000000000000007909f0b4a0c25f126f85e010aa573c64e5e2ebf9000000000000000000000000162d558ac8f3b8aba5f549066ac81df4ddc912a2000000000000000000000000d51c109110e7ccb7f6b84ddd2485c2f8e2753415000000000000000000000000bed503a443565d7f0005805edbc33c0cd8f4a4b3000000000000000000000000dcca8fa09bec1205ea2946b5fa466d72123b70f8", contractAddress: "", cumulativeGasUsed: "1399984", gasUsed: "467899", confirmations: "3357373"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_gasPrice", value: ["4000000000","4000000000","4000000000","4000000000","5000000000","30000000000","40000000000","4000000000","4000000000","4000000000","4000000000","20000000000","45000000000","20000000000","20000000000","20000000000","20000000000","30000000000","6000000000","6000000000"]}, {type: "address[]", name: "_addr", value: [addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235]]}], name: "multisetCustomGasPrice", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multisetCustomGasPrice(uint256[],address[])" ]( ["4000000000","4000000000","4000000000","4000000000","5000000000","30000000000","40000000000","4000000000","4000000000","4000000000","4000000000","20000000000","45000000000","20000000000","20000000000","20000000000","20000000000","30000000000","6000000000","6000000000"], [addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1507837738 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51403936108559830730" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: multisetProofType( [\"48\",\"48\",\"48\",\"48\",\"48\",\"48... )", async function( ) {
		const txOriginal = {blockNumber: "4360126", timeStamp: "1507838124", hash: "0x372eebd4bc1e6ac9f35f3c03e61c9eb1ce68242ff7f76ab1ee048517e8ba0bed", nonce: "64", blockHash: "0x144974cf65adb87e73e84223ba1a85808ba2b561c686304f1de102f743f2f9dc", transactionIndex: "31", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "1751774", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xdb37e42f00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000055000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000550000000000000000000000008cd2bbc42f030fffabf79de4f176980eed843fd3000000000000000000000000639e250b6eb084e2b3575eaac76873221b431bbb000000000000000000000000249a7c08536211393fc3dd5323e70ae21a18368a000000000000000000000000be87aff8814d4a465ad04c47ec2570ca9ef15b3600000000000000000000000016aa4c5a51042efeddc86dea4b454b085b4a80b20000000000000000000000009c1f59bdddc90d65d3b47adb1069a1b257818493000000000000000000000000131cf0d3b3cc6763417bffb2dfdc119fdebca002000000000000000000000000e8528c3139b571c8a306c08c4a6861d47622b96800000000000000000000000049fddeae0b521dab8d0c4b77e7161094f971320d000000000000000000000000ece701c76bd00d1c3f96410a0c69ea8dfcf5f34e00000000000000000000000078aeaa0929f933bc0ea3a2eb5a1d07ac6e21401d0000000000000000000000001e2fbe6be9eb39fc894d38be976111f332172d830000000000000000000000007da90089a73edd14c75b0c827cb54f4248d47ecc0000000000000000000000004e646a576917a6a47d5b0896c3e207693870869d0000000000000000000000009b26ba3a1d66cca67aa413da042a144a39c554b9000000000000000000000000e642b6f79041c60d8447679b3a499f18d8b03b81000000000000000000000000e8a51be86ad96447d45ddeddc55013f25157688c000000000000000000000000dd98b423dc61a756e1070de151b148542550595400000000000000000000000011691ad4e9bf379420bd2bb0119fc328acd5067a000000000000000000000000e6517b766e6ee07f91b517435ed855926bcb1aae000000000000000000000000221ea1b119b4aa2c6b4e2282ab0b621b1f54cf61000000000000000000000000c797f7d82962157b4c73d43dc7723df0f82c0194000000000000000000000000b57b9206d75c1bb02cb64f97fb5176eae731a62d000000000000000000000000736d9b6a58ab142e9ea171fb9cb5c401decbe1d0000000000000000000000000eda2b1cc85743ad07d6eb8e5a22cdbe142c10e6d0000000000000000000000009a9c62cc05ceb3c189c43b18b070821794db6944000000000000000000000000d768bca1ca5e5deff16274be27e24552ac08d2f20000000000000000000000005a13caa82851342e14cd2ad0257707cddb8a31b700000000000000000000000053aaaa7bd2592479c399a341e974995b5e35989000000000000000000000000085278c33aee0a79e9fb39ba16322d9ca214ad1cd000000000000000000000000db9822bb9885d844d1986a8949fce1a4ceb5f8b6000000000000000000000000ad227491e11bb69be013b0d5029d6a3128986fc700000000000000000000000029a90a9236bc4d3fbf8ca0ae29659815b3460d5800000000000000000000000010ff783574c0610b947f6c1fe019cba845c886560000000000000000000000003eedf709634c949a3c3f77c6f588bafcc695ca44000000000000000000000000e8cba706c07850b322f8fce1c93bde83ef3bf8a100000000000000000000000041ff0796a6c7a201476bff53c4cb2c48b084e5e00000000000000000000000005d501e399a4c406a2fda69a3f67bb0727f40a9c2000000000000000000000000c2551126b9bb8db7530bf884a8c1c1fda80615d4000000000000000000000000e15e57fe0d93e2f898d80a1afa6a33da682358e9000000000000000000000000f0cdc385709f1ad604b6d11965208a8c505d7dff000000000000000000000000a43653b0088ce10f6c5446dcec472388989145b7000000000000000000000000542d09f9e38c96fbbfe2812d19f485ab1be62c98000000000000000000000000132f795705650a46c593a7c3442819d3e3e36ff70000000000000000000000005d892a70870637daef7284c185cb8666b549c049000000000000000000000000be1d8403a63b4875f2103ecfa16c9f0cfd29d0f80000000000000000000000005182184f125aafa0b7e22a0fe5a573071a4df39a0000000000000000000000002e28a7ea669f01c3625a3c691e06251c92671289000000000000000000000000de027676c2c22cc1f2cc7676083b04520e3ca8910000000000000000000000005936d34a49aaa7bbaeffba2cf7f7c191bd96477d000000000000000000000000735049b443724377157f9d07e5a05bdba4a5c234000000000000000000000000b83cbeb1e3b188d0a71a2929472143b34a28780a000000000000000000000000712e6abdc6f70a8b6d1f300e2b82606f31475002000000000000000000000000ae57cbf3152fa894d4a6c61f496f663da46af4b2000000000000000000000000c619211800679c0c2f01e404cf866f0dfb5b89bd000000000000000000000000d39ed6143d5a69a25d7fcb06b1bb554f2debaaae000000000000000000000000d72ead482b15197b99f74d846e8180d7f33670df0000000000000000000000006ba8e05e0f36afc72ea18f89a0c1693d7832c52c000000000000000000000000ffc08dd84a66775e6236e0a80ee2f340e0042f8c0000000000000000000000002549f29844baa2fd283b949e7c35c45829ff3edc000000000000000000000000a9244061223eedfa34ffa05f3ebdc8083276acea0000000000000000000000000aaf8865a6cbf417e7ad51fe71fe60f1a0c192f8000000000000000000000000366374a2ec8a244b7da7e51d6df460ec8a3b8b14000000000000000000000000a1a465548fe36dcab13cd3150e45037460d425e8000000000000000000000000daff1f98299b12d475b4725a2635e5ba291aa65100000000000000000000000002b97cca6d6a5227e464b2a60ee1a580ea4f7da9000000000000000000000000600a115702a44a7372fe9a7fd93fc2fc67f9eeb40000000000000000000000006bf2e20b21005ddc16e09f89f3b483d126e7fbc80000000000000000000000003bef6f53cd3066d982beb61688b41c238a68f8e500000000000000000000000063660b981b022790487d2b6026c18ea038a46aa5000000000000000000000000f2e5a8c518092ad97a14d877e6376837a561e2c9000000000000000000000000663a5ca0295231b0d88afb1c557a8d8f4c1b64590000000000000000000000001c923bc27998465f0b197ef73c7aeec9359169d3000000000000000000000000c45695480f688e6dc0cff576efe72219dbd3aadc0000000000000000000000002d5426edba78238d71ccbdbb6947959037fda5320000000000000000000000003023d5ee05ebee74b61f940433b7783eac1f221e0000000000000000000000000869d49644ce3fd53dcbfa824b3794c0b4ae37740000000000000000000000007909f0b4a0c25f126f85e010aa573c64e5e2ebf9000000000000000000000000162d558ac8f3b8aba5f549066ac81df4ddc912a2000000000000000000000000bed503a443565d7f0005805edbc33c0cd8f4a4b3000000000000000000000000dcca8fa09bec1205ea2946b5fa466d72123b70f80000000000000000000000004220698be33a9738898f430018f28aeceecaa6ff000000000000000000000000e5a04d98538231b0fab9aba60cd73ce4ff3039df000000000000000000000000102011cb0f7109e98a4e98dfbacd792bfb343e140000000000000000000000005dc80a9056685ecfc07bd3bbf080484962c8ba81", contractAddress: "", cumulativeGasUsed: "3115402", gasUsed: "1751774", confirmations: "3357356"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_proofType", value: ["48","48","48","48","48","48","17","48","17","17","17","17","17","17","48","17","17","17","17","17","48","48","48","48","48","48","48","48","17","17","48","17","17","17","17","17","48","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","48","17","17","17","17","48","48","48","17","17","17","17","17","48","48","17","48","48","48","48","48","17","17","48","48","17","17"]}, {type: "address[]", name: "_addr", value: [addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[95],addressList[211],addressList[244],addressList[93],addressList[96],addressList[90],addressList[245],addressList[92],addressList[91],addressList[94],addressList[193],addressList[148],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[142],addressList[195],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[216],addressList[263],addressList[217],addressList[218],addressList[219],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[221],addressList[285],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[286],addressList[229],addressList[287],addressList[288],addressList[230],addressList[231],addressList[232],addressList[234],addressList[235],addressList[289],addressList[290],addressList[291],addressList[292]]}], name: "multisetProofType", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multisetProofType(uint256[],address[])" ]( ["48","48","48","48","48","48","17","48","17","17","17","17","17","17","48","17","17","17","17","17","48","48","48","48","48","48","48","48","17","17","48","17","17","17","17","17","48","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","17","48","17","17","17","17","48","48","48","17","17","17","17","17","48","48","17","48","48","48","48","48","17","17","48","48","17","17"], [addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[95],addressList[211],addressList[244],addressList[93],addressList[96],addressList[90],addressList[245],addressList[92],addressList[91],addressList[94],addressList[193],addressList[148],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[142],addressList[195],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[216],addressList[263],addressList[217],addressList[218],addressList[219],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[221],addressList[285],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[286],addressList[229],addressList[287],addressList[288],addressList[230],addressList[231],addressList[232],addressList[234],addressList[235],addressList[289],addressList[290],addressList[291],addressList[292]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1507838124 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51403936108559830730" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addDSource( `IPFS`, \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4360250", timeStamp: "1507841898", hash: "0x190878d599f6307f1d52a7e5168659d49da2dd55ca51e07ff7d584f8a4c7cc27", nonce: "72", blockHash: "0xead7a8b29a532542b1365e08bfed113639afe3feb978231b30b3daa77262b98a", transactionIndex: "34", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "150000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xa2ec191a0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000044950465300000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2428975", gasUsed: "54851", confirmations: "3357232"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "dsname", value: `IPFS`}, {type: "uint256", name: "multiplier", value: "10"}], name: "addDSource", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addDSource(string,uint256)" ]( `IPFS`, "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1507841898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addDSource( `URL`, \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4360252", timeStamp: "1507842020", hash: "0xcb6fc4221f221563ed39de94ff69835c577b369533e2790e7690cee6cec7490f", nonce: "73", blockHash: "0x3f81ab9d722c1a8ef67e9f5192614dfdc01d3c379378882e279c3053b5b368f1", transactionIndex: "57", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "150000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xa2ec191a0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000355524c0000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3029795", gasUsed: "54787", confirmations: "3357230"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "dsname", value: `URL`}, {type: "uint256", name: "multiplier", value: "10"}], name: "addDSource", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addDSource(string,uint256)" ]( `URL`, "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1507842020 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addDSource( `swarm`, \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4360255", timeStamp: "1507842109", hash: "0xf7087afcc8b9ca2d2677232757acc0849434a16a57d4221a8c822eda773d5dc7", nonce: "74", blockHash: "0x01ac4be177d536c102af19da3faad2c4995659d59cbe5203ca370e9704db117d", transactionIndex: "87", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "150000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xa2ec191a0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000005737761726d000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5786159", gasUsed: "54915", confirmations: "3357227"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "dsname", value: `swarm`}, {type: "uint256", name: "multiplier", value: "10"}], name: "addDSource", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addDSource(string,uint256)" ]( `swarm`, "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1507842109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setOffchainPayment( addressList[293], true )", async function( ) {
		const txOriginal = {blockNumber: "4360300", timeStamp: "1507843292", hash: "0xa07c379fb74fdec9bf407acf32987dace1276c1d5bec1849201202acce4e4f4a", nonce: "76", blockHash: "0xb39749376c51150738a3c73e7271aef0f90cd3f46ee4f84e6a9f58c1b857fe30", transactionIndex: "108", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "46894", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xe8be3853000000000000000000000000376e355f94d930808b6b8f46ebfe8cd1c114c64f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5294248", gasUsed: "46894", confirmations: "3357182"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[293]}, {type: "bool", name: "_flag", value: true}], name: "setOffchainPayment", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOffchainPayment(address,bool)" ]( addressList[293], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1507843292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"} ;
		console.error( "eventCallOriginal[13,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Emit_OffchainPaymentFlag", events: [{name: "idx_sender", type: "address", value: "0x376e355f94d930808b6b8f46ebfe8cd1c114c64f"}, {name: "sender", type: "address", value: "0x376e355f94d930808b6b8f46ebfe8cd1c114c64f"}, {name: "idx_flag", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "flag", type: "bool", value: true}], address: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6"}] ;
		console.error( "eventResultOriginal[13,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setOffchainPayment( addressList[293], false )", async function( ) {
		const txOriginal = {blockNumber: "4360392", timeStamp: "1507845917", hash: "0x836170e88cba1b4a597a0921db5033b367ccf6bf8bdd1023cf98e0147d2a7535", nonce: "78", blockHash: "0x7f56a67800c5609eef0dcfa704b02ea600a06b2e366c3096c14539ce07ba8acc", transactionIndex: "19", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "31830", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xe8be3853000000000000000000000000376e355f94d930808b6b8f46ebfe8cd1c114c64f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1202480", gasUsed: "16830", confirmations: "3357090"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[293]}, {type: "bool", name: "_flag", value: false}], name: "setOffchainPayment", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOffchainPayment(address,bool)" ]( addressList[293], false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1507845917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"} ;
		console.error( "eventCallOriginal[14,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Emit_OffchainPaymentFlag", events: [{name: "idx_sender", type: "address", value: "0x376e355f94d930808b6b8f46ebfe8cd1c114c64f"}, {name: "sender", type: "address", value: "0x376e355f94d930808b6b8f46ebfe8cd1c114c64f"}, {name: "idx_flag", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "flag", type: "bool", value: false}], address: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6"}] ;
		console.error( "eventResultOriginal[14,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setBasePrice( \"3327142086313\" )", async function( ) {
		const txOriginal = {blockNumber: "4362345", timeStamp: "1507903314", hash: "0x8cb8bda9e6aafcccb3121ca52517289d168f4ec53ed27fef1e07114178f7b3fe", nonce: "79", blockHash: "0x7354b9f7c1e958131fe6d57880cbc48e60b78f3b139903fa5f213cef9af914ec", transactionIndex: "22", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "700000", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xde4b326200000000000000000000000000000000000000000000000000000306a91f46a9", contractAddress: "", cumulativeGasUsed: "1645819", gasUsed: "697077", confirmations: "3355137"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "new_baseprice", value: "3327142086313"}], name: "setBasePrice", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setBasePrice(uint256)" ]( "3327142086313", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1507903314 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: multisetProofType( [\"17\",\"17\",\"17\",\"17\",\"17\",\"17... )", async function( ) {
		const txOriginal = {blockNumber: "4362450", timeStamp: "1507907006", hash: "0xdfe9d0a7f7dfabe7efd17b0a4c86dd1dbd1309c0a06b43d7726d4a30096293f5", nonce: "81", blockHash: "0xd86aaeb4364f0a553b49e4b2f6d2cc43f6dd0187aceac037143b5d8ebda7a97c", transactionIndex: "76", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "179782", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xdb37e42f00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001500000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000150000000000000000000000004e646a576917a6a47d5b0896c3e207693870869d000000000000000000000000e642b6f79041c60d8447679b3a499f18d8b03b810000000000000000000000007da90089a73edd14c75b0c827cb54f4248d47ecc000000000000000000000000e8a51be86ad96447d45ddeddc55013f25157688c000000000000000000000000dd98b423dc61a756e1070de151b14854255059540000000000000000000000001e2fbe6be9eb39fc894d38be976111f332172d8300000000000000000000000049fddeae0b521dab8d0c4b77e7161094f971320d000000000000000000000000e6517b766e6ee07f91b517435ed855926bcb1aae0000000000000000000000005d892a70870637daef7284c185cb8666b549c0490000000000000000000000003023d5ee05ebee74b61f940433b7783eac1f221e000000000000000000000000ffc08dd84a66775e6236e0a80ee2f340e0042f8c000000000000000000000000162d558ac8f3b8aba5f549066ac81df4ddc912a2000000000000000000000000c45695480f688e6dc0cff576efe72219dbd3aadc000000000000000000000000bed503a443565d7f0005805edbc33c0cd8f4a4b300000000000000000000000041ff0796a6c7a201476bff53c4cb2c48b084e5e0000000000000000000000000dcca8fa09bec1205ea2946b5fa466d72123b70f80000000000000000000000004220698be33a9738898f430018f28aeceecaa6ff000000000000000000000000e5a04d98538231b0fab9aba60cd73ce4ff3039df000000000000000000000000102011cb0f7109e98a4e98dfbacd792bfb343e140000000000000000000000005dc80a9056685ecfc07bd3bbf080484962c8ba81000000000000000000000000366374a2ec8a244b7da7e51d6df460ec8a3b8b14", contractAddress: "", cumulativeGasUsed: "3671111", gasUsed: "179782", confirmations: "3355032"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_proofType", value: ["17","17","17","17","17","17","17","17","17","48","48","48","17","17","48","17","48","48","17","17","17"]}, {type: "address[]", name: "_addr", value: [addressList[90],addressList[92],addressList[96],addressList[91],addressList[94],addressList[93],addressList[95],addressList[148],addressList[264],addressList[288],addressList[278],addressList[232],addressList[229],addressList[234],addressList[260],addressList[235],addressList[289],addressList[290],addressList[291],addressList[292],addressList[282]]}], name: "multisetProofType", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multisetProofType(uint256[],address[])" ]( ["17","17","17","17","17","17","17","17","17","48","48","48","17","17","48","17","48","48","17","17","17"], [addressList[90],addressList[92],addressList[96],addressList[91],addressList[94],addressList[93],addressList[95],addressList[148],addressList[264],addressList[288],addressList[278],addressList[232],addressList[229],addressList[234],addressList[260],addressList[235],addressList[289],addressList[290],addressList[291],addressList[292],addressList[282]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1507907006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: multisetCustomGasPrice( [\"20000000000\",\"20000000000\",\"30000... )", async function( ) {
		const txOriginal = {blockNumber: "4362451", timeStamp: "1507907071", hash: "0x440965bdf663a63c1d4197fae4d5cee95d5f4ce1657c6f8ffc34b709d3bf2ccf", nonce: "82", blockHash: "0x12ea8a8441fe79c6af8bd0858b57239d5fac03cdb962a07715fa3adc498d324a", transactionIndex: "81", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "66905", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xd959701600000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000004a817c80000000000000000000000000000000000000000000000000000000004a817c80000000000000000000000000000000000000000000000000000000006fc23ac000000000000000000000000000000000000000000000000000000000165a0bc000000000000000000000000000000000000000000000000000000000165a0bc00000000000000000000000000000000000000000000000000000000012a05f2000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000162d558ac8f3b8aba5f549066ac81df4ddc912a2000000000000000000000000c45695480f688e6dc0cff576efe72219dbd3aadc000000000000000000000000d51c109110e7ccb7f6b84ddd2485c2f8e2753415000000000000000000000000bed503a443565d7f0005805edbc33c0cd8f4a4b3000000000000000000000000dcca8fa09bec1205ea2946b5fa466d72123b70f80000000000000000000000002d623f30194870edf32f2d85c80b9e6ffb7db9f8", contractAddress: "", cumulativeGasUsed: "3242719", gasUsed: "66905", confirmations: "3355031"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_gasPrice", value: ["20000000000","20000000000","30000000000","6000000000","6000000000","5000000000"]}, {type: "address[]", name: "_addr", value: [addressList[232],addressList[229],addressList[233],addressList[234],addressList[235],addressList[220]]}], name: "multisetCustomGasPrice", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multisetCustomGasPrice(uint256[],address[])" ]( ["20000000000","20000000000","30000000000","6000000000","6000000000","5000000000"], [addressList[232],addressList[229],addressList[233],addressList[234],addressList[235],addressList[220]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1507907071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: changeAdmin( addressList[294] )", async function( ) {
		const txOriginal = {blockNumber: "4362473", timeStamp: "1507907677", hash: "0xdcc459cac4b99d8f4723b3e7d58b2386655f3481269b76bde5897c563a6f39ee", nonce: "83", blockHash: "0x8ac3ac77d73f5425c889f4ca6cfc2f479e4512c520817e09780be7b607c1c6a2", transactionIndex: "137", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "29025", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x8f283970000000000000000000000000a35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", contractAddress: "", cumulativeGasUsed: "5778301", gasUsed: "29025", confirmations: "3355009"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newAdmin", value: addressList[294]}], name: "changeAdmin", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeAdmin(address)" ]( addressList[294], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1507907677 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setOffchainPayment( addressList[295], true )", async function( ) {
		const txOriginal = {blockNumber: "4365970", timeStamp: "1508012218", hash: "0x32e5851c229146a2bb02d6fed5f3ec0e492866171108d68fb96822733d58ba25", nonce: "90", blockHash: "0x6364a54ff2919324166403e71f81255cd87dd58ec8f5b701c7af0e18c7f7059b", transactionIndex: "55", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "46894", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xe8be3853000000000000000000000000358bd9446e79ee20c0fbaa4f3bff31d794bfe8b90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1268208", gasUsed: "46894", confirmations: "3351512"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[295]}, {type: "bool", name: "_flag", value: true}], name: "setOffchainPayment", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOffchainPayment(address,bool)" ]( addressList[295], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508012218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"} ;
		console.error( "eventCallOriginal[19,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Emit_OffchainPaymentFlag", events: [{name: "idx_sender", type: "address", value: "0x358bd9446e79ee20c0fbaa4f3bff31d794bfe8b9"}, {name: "sender", type: "address", value: "0x358bd9446e79ee20c0fbaa4f3bff31d794bfe8b9"}, {name: "idx_flag", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "flag", type: "bool", value: true}], address: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6"}] ;
		console.error( "eventResultOriginal[19,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4367072", timeStamp: "1508044297", hash: "0x8b9e42bfc3da6839a01e0aba00fcdbe458da22cfdc4380fc895cebbfe159412e", nonce: "93", blockHash: "0xd06ba3e323052214f582984921fbaa4f20c85d979bbd431648ea34f46a525599", transactionIndex: "160", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "6000000000", isError: "0", txreceipt_status: "", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "3567567", gasUsed: "31439", confirmations: "3350410"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508044297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4376827", timeStamp: "1508240574", hash: "0xaddcae6bb3327d86792822796597ce7b7b2886650c35faf8eefaa929f30d72f5", nonce: "94", blockHash: "0x8e3f268b0b9ad521b57070deeb915371c7f94fbf3d4859b79f75fb7ec96d3f0d", transactionIndex: "113", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "5062913", gasUsed: "31439", confirmations: "3340655"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508240574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[296] )", async function( ) {
		const txOriginal = {blockNumber: "4389918", timeStamp: "1508423096", hash: "0xf586369298c9b34adbd59c5b4da6fc290ee78728decbe2b7627d5cd38f5df64d", nonce: "95", blockHash: "0xe8f776bf555387dc345bd22b117f36b4e23596c2102f3b423e5dd9bb27751c09", transactionIndex: "155", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x68742da6000000000000000000000000912f5be7f4ef37c6f8b443ca1d83f3b7a5f88787", contractAddress: "", cumulativeGasUsed: "6630698", gasUsed: "31439", confirmations: "3327564"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[296]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[296], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1508423096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51405915148903588190" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setOffchainPayment( addressList[297], true )", async function( ) {
		const txOriginal = {blockNumber: "4394349", timeStamp: "1508484837", hash: "0x02f5c78c8fad37bfeac181e04feb2a6759c3b618f3080afcb4f39edc713fd0a9", nonce: "91", blockHash: "0xd9c805340b90fca7fe0afae9d491c9349d98d8da9cf01f8c0d7ca4d1dfd5b73b", transactionIndex: "110", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "46894", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe8be3853000000000000000000000000a456d1e4dce1cec1cde58fae10d1b6385bc86ed90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2596730", gasUsed: "46894", confirmations: "3323133"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[297]}, {type: "bool", name: "_flag", value: true}], name: "setOffchainPayment", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOffchainPayment(address,bool)" ]( addressList[297], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1508484837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"} ;
		console.error( "eventCallOriginal[23,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Emit_OffchainPaymentFlag", events: [{name: "idx_sender", type: "address", value: "0xa456d1e4dce1cec1cde58fae10d1b6385bc86ed9"}, {name: "sender", type: "address", value: "0xa456d1e4dce1cec1cde58fae10d1b6385bc86ed9"}, {name: "idx_flag", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "flag", type: "bool", value: true}], address: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6"}] ;
		console.error( "eventResultOriginal[23,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51408274829018174010" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setOffchainPayment( addressList[298], true )", async function( ) {
		const txOriginal = {blockNumber: "4394352", timeStamp: "1508484941", hash: "0xccfbffb39bb7b9dbc02a0caec096fc446a499e95bcc77d597e1ee184124932c3", nonce: "92", blockHash: "0xd6ecee33c3b98d48b047c536632343c39d2d382dc6d32aa2e02e72d6431e33c8", transactionIndex: "98", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "46894", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe8be38530000000000000000000000002b12390d999dada036a7c8909b753b0d13c552d50000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2268053", gasUsed: "46894", confirmations: "3323130"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[298]}, {type: "bool", name: "_flag", value: true}], name: "setOffchainPayment", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOffchainPayment(address,bool)" ]( addressList[298], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1508484941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"} ;
		console.error( "eventCallOriginal[24,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Emit_OffchainPaymentFlag", events: [{name: "idx_sender", type: "address", value: "0x2b12390d999dada036a7c8909b753b0d13c552d5"}, {name: "sender", type: "address", value: "0x2b12390d999dada036a7c8909b753b0d13c552d5"}, {name: "idx_flag", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "flag", type: "bool", value: true}], address: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6"}] ;
		console.error( "eventResultOriginal[24,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51408274829018174010" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setOffchainPayment( addressList[299], true )", async function( ) {
		const txOriginal = {blockNumber: "4394356", timeStamp: "1508484981", hash: "0x70bf22d8d63a595ef36acde9e3bffc397a3c516239d92d483f8879fe67dd9783", nonce: "93", blockHash: "0x7528feef18706304e8ca5fb3454ce0f6ff9bc0d39a3ea5547ca39ef48cb12a9f", transactionIndex: "24", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "46894", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe8be385300000000000000000000000060991c469df42a9dc1292a40978f59197895a3300000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "597990", gasUsed: "46894", confirmations: "3323126"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[299]}, {type: "bool", name: "_flag", value: true}], name: "setOffchainPayment", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOffchainPayment(address,bool)" ]( addressList[299], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1508484981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"} ;
		console.error( "eventCallOriginal[25,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Emit_OffchainPaymentFlag", events: [{name: "idx_sender", type: "address", value: "0x60991c469df42a9dc1292a40978f59197895a330"}, {name: "sender", type: "address", value: "0x60991c469df42a9dc1292a40978f59197895a330"}, {name: "idx_flag", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "flag", type: "bool", value: true}], address: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6"}] ;
		console.error( "eventResultOriginal[25,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51408274829018174010" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[296] )", async function( ) {
		const txOriginal = {blockNumber: "4406834", timeStamp: "1508656475", hash: "0x5d75e27b899e06a3bf5938ebf0ab1ca95825b4fdd91c1cfcf14d1a06f99a88a4", nonce: "96", blockHash: "0xcdd976f187a334b5f565424073be1576b614efa988153d95aa6aa292cc8c7695", transactionIndex: "95", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x68742da6000000000000000000000000912f5be7f4ef37c6f8b443ca1d83f3b7a5f88787", contractAddress: "", cumulativeGasUsed: "3244037", gasUsed: "31439", confirmations: "3310648"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[296]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[296], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1508656475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51408274829018174010" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[296] )", async function( ) {
		const txOriginal = {blockNumber: "4426280", timeStamp: "1508926788", hash: "0x137bd860919f98968d7cce6c96bf069f549233ef12a05d61e31e4cd7fe72c63d", nonce: "97", blockHash: "0xc83135a632672972fcc8b8013b32e20f662253b2eb23652c8df67ad7cc10265c", transactionIndex: "97", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0x68742da6000000000000000000000000912f5be7f4ef37c6f8b443ca1d83f3b7a5f88787", contractAddress: "", cumulativeGasUsed: "6676722", gasUsed: "31439", confirmations: "3291202"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[296]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[296], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1508926788 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51408274829018174010" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setOffchainPayment( addressList[300], true )", async function( ) {
		const txOriginal = {blockNumber: "4427046", timeStamp: "1508937509", hash: "0x518ed146b730e02636047dea50fdbc914ac50ebad6aaaa18c69ad28c294951dc", nonce: "94", blockHash: "0x2a15c2ff95c4eabb92c82a6f9921cb3531007d35355b218286e12e184143aada", transactionIndex: "41", from: "0x5b2d063205c643c8f0974a5c36c584e0c17459cc", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "46894", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe8be3853000000000000000000000000d91e45416bfbbec6e2d1ae4ac83b788a21acf5830000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2111900", gasUsed: "46894", confirmations: "3290436"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[300]}, {type: "bool", name: "_flag", value: true}], name: "setOffchainPayment", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOffchainPayment(address,bool)" ]( addressList[300], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1508937509 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "idx_sender", type: "address"}, {indexed: false, name: "sender", type: "address"}, {indexed: true, name: "idx_flag", type: "bool"}, {indexed: false, name: "flag", type: "bool"}], name: "Emit_OffchainPaymentFlag", type: "event"} ;
		console.error( "eventCallOriginal[28,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Emit_OffchainPaymentFlag", events: [{name: "idx_sender", type: "address", value: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}, {name: "sender", type: "address", value: "0xd91e45416bfbbec6e2d1ae4ac83b788a21acf583"}, {name: "idx_flag", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "flag", type: "bool", value: true}], address: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6"}] ;
		console.error( "eventResultOriginal[28,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "679132910778270880" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51408274829018174010" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4434381", timeStamp: "1509040318", hash: "0x547d24e9212ecf8d2d8770dd727b5e7916d37ebee548e029ce54672eb621aa45", nonce: "98", blockHash: "0x92c697db1452f8112f3b09f537693213cdca8bf06cecf27cec9d7b9ff96b2b9d", transactionIndex: "85", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "6689422", gasUsed: "31439", confirmations: "3283101"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509040318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51408274829018174010" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4451266", timeStamp: "1509274571", hash: "0x19ac05889ac28cd4f1e24e5b97134e8fb36873fa6ed8c947f626e2dbe53670ff", nonce: "99", blockHash: "0xfbb4e5972acd7a12660d995b7b9f00bcd121de609ec0f1f240030fa9d6835280", transactionIndex: "88", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "6467858", gasUsed: "31439", confirmations: "3266216"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509274571 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51410253869361931470" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4544388", timeStamp: "1510569177", hash: "0x84d5da36c9d1ace664d272b410305836c9483b767085e3721c7f5a794b433bc4", nonce: "100", blockHash: "0x09b6864546e9d095a88467d25ade96e89c6396950ab95e3b0601fa7a146fbbd0", transactionIndex: "44", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "2226923", gasUsed: "31439", confirmations: "3173094"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510569177 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51410253869361931470" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4581567", timeStamp: "1511087614", hash: "0x776187fccc0d6021d2ba320269a71ad633cd78aca30ae5a7b53d1b909dcc59fe", nonce: "101", blockHash: "0x21ec35d2de9811cf62112c6c06564b0e08572e0fb6514a46326f2b76b99254e0", transactionIndex: "10", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "6688301", gasUsed: "31439", confirmations: "3135915"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511087614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51412183549476517290" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4589881", timeStamp: "1511202073", hash: "0x02d9215bfdf2cdd20b126c2a38006626495dcd919ee047393a246a27bb21a856", nonce: "102", blockHash: "0x7e43e04a40fc03b0723a0b50d76d749e906a9ce6a36ed671851c3b9881650784", transactionIndex: "36", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "805951", gasUsed: "31439", confirmations: "3127601"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511202073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51412183549476517290" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4606270", timeStamp: "1511430819", hash: "0x02e078f608448adeb31c2d1a225dfcc60a43776e56bf0dab4607b2b40d030c94", nonce: "103", blockHash: "0x74c1db4de7be18dfbb81317c1970cca35302d8207a988488cca6329d9a43b6e2", transactionIndex: "79", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "3516781", gasUsed: "31439", confirmations: "3111212"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511430819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51412183549476517290" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4624964", timeStamp: "1511691417", hash: "0x4cdf1684ab90d972a1fba6d8fce832e4c33f65f0096277ee3f7fc95c07f3d864", nonce: "104", blockHash: "0x042c17f5ca06ccc0b8b35b12b08d84d4592582e6f17f2afc831d7827c7cb6d9d", transactionIndex: "143", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "6734299", gasUsed: "31439", confirmations: "3092518"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511691417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4702062", timeStamp: "1512816359", hash: "0x43fc987cb15a538637af279437cafc26740d8d2abbd78815e7851aeb2626d11c", nonce: "105", blockHash: "0x388b36ae5ea8a1b21a2982b37e36ed15863a25688a932d7bda7a77a39e8faf8b", transactionIndex: "50", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "2481646", gasUsed: "31439", confirmations: "3015420"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1512816359 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setGasPrice( \"60000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4702085", timeStamp: "1512816728", hash: "0xc7bf96c6288ac8d7b6d56062acf1ce2e13f7924b89ca8985b5609a57081a907e", nonce: "106", blockHash: "0xb6a2a42ffebc11a2159b3f6bb0da32ae3b75a37ba81b1b8a5bd935f5075ec1e1", transactionIndex: "62", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "27790", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0xbf1fe4200000000000000000000000000000000000000000000000000000000df8475800", contractAddress: "", cumulativeGasUsed: "2174282", gasUsed: "27790", confirmations: "3015397"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "newgasprice", value: "60000000000"}], name: "setGasPrice", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setGasPrice(uint256)" ]( "60000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1512816728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setBasePrice( \"2100000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4702110", timeStamp: "1512817065", hash: "0x1ebee77eda4a04ced606972f0194ddde058e42049cf93c42c8cd7cfd3bceb498", nonce: "107", blockHash: "0xfd67e5d3ec49d086d8a583e6b57246f21aeaf5febc275293e8c8d8085a417d9d", transactionIndex: "15", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "247013", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0xde4b3262000000000000000000000000000000000000000000000000000001e8f1c10800", contractAddress: "", cumulativeGasUsed: "803990", gasUsed: "247013", confirmations: "3015372"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "new_baseprice", value: "2100000000000"}], name: "setBasePrice", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setBasePrice(uint256)" ]( "2100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1512817065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4709485", timeStamp: "1512927204", hash: "0x314b3d315a4cde74ce75744f6876dfc3caac92141536d1dc6d095acf3650dde7", nonce: "108", blockHash: "0x6308f32073057f27a468db7870203d15a8ceff8e754fcb02bb539906f62ce94a", transactionIndex: "99", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "6258975", gasUsed: "31439", confirmations: "3007997"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1512927204 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setGasPrice( \"40000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4709492", timeStamp: "1512927302", hash: "0x05201b3d1ba8e625e060c531a9c8b04e97b3f2695be7dc646a43a7a0479cc7b3", nonce: "109", blockHash: "0x693da9b8f05b475d12db5c409c780836f3d642857c0b802397fdbf5076574184", transactionIndex: "90", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "27790", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xbf1fe42000000000000000000000000000000000000000000000000000000009502f9000", contractAddress: "", cumulativeGasUsed: "5178572", gasUsed: "27790", confirmations: "3007990"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "newgasprice", value: "40000000000"}], name: "setGasPrice", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setGasPrice(uint256)" ]( "40000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1512927302 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4718937", timeStamp: "1513068791", hash: "0x05361b0636216445dbc58b1522b6ed4bd5e7d20f91076a6d901505cfc4260a17", nonce: "110", blockHash: "0x87388862e327178e8d36bcbbfb50b4906a75b6c48d9bf72d199fb0aaf2b9fb7b", transactionIndex: "19", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "875177", gasUsed: "31439", confirmations: "2998545"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1513068791 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4725498", timeStamp: "1513167887", hash: "0x1fcbe880c311388e37db5417d2c456392ccc8cf113a69eba5053febe8c7dc482", nonce: "111", blockHash: "0xa4468c0920455f36ed32970c7d5a9e9a40b73589c392f728b9e454a40193c26a", transactionIndex: "84", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "6311197", gasUsed: "31439", confirmations: "2991984"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1513167887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4738623", timeStamp: "1513367134", hash: "0x83a11457f728c6b7c690ef9f0eeaf77f747989435b9127b34941095f55f8c4e4", nonce: "112", blockHash: "0x2aa0d3c274199f8253a8e11633bacbbf34ba63b26635df9f6a3d38eaf27142f6", transactionIndex: "103", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "7598552", gasUsed: "31439", confirmations: "2978859"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1513367134 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51422078751195304590" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4759397", timeStamp: "1513678342", hash: "0x5793c5135fb099ff2eab8c599dcff1b0080c25039c8f98411b308f69cf8d0f4c", nonce: "113", blockHash: "0x71a1861cfa989a9075caad42a5d8e0431298f3143c0b0b1ec30e014d06002b3d", transactionIndex: "161", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "7968822", gasUsed: "31439", confirmations: "2958085"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1513678342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51426036831882819510" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4767648", timeStamp: "1513806249", hash: "0x561e14a74d319f0a71ca88aad49167e9b10f0ec4f33a20f360db8f16c319b657", nonce: "114", blockHash: "0x21d059c19fde23b085480c14f51afbbe7b772a456993b95723c7c7a1c9122678", transactionIndex: "100", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "4816516", gasUsed: "31439", confirmations: "2949834"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1513806249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51426036831882819510" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4770961", timeStamp: "1513857156", hash: "0xad8f945bcf50e085e35a2a100e78521d8a7b1a35f9dc06a86efd01a0295e4dca", nonce: "115", blockHash: "0x6d110816fb60d0a8952f1a245c41d3c3fa44037bf2b2c284d6730d01e34ab49e", transactionIndex: "29", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "1678000", gasUsed: "31439", confirmations: "2946521"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1513857156 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51426036831882819510" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4788831", timeStamp: "1514124751", hash: "0x00fd9e03f86326919c40368007de889b9ce526177d4c657de95c46af89bb411d", nonce: "116", blockHash: "0x8329a3cf7fea3ae6a56f6e7a263dbb0e1a7f96da629e3ef65b750bd00871bf3a", transactionIndex: "155", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "5452186", gasUsed: "31439", confirmations: "2928651"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1514124751 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51426036831882819510" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4806007", timeStamp: "1514371159", hash: "0x443d389d4106c160b23e03b84acf13442ee0fb6f5330956d3af6aaaea7a6cf6d", nonce: "117", blockHash: "0x6040908278cf766b34fb0c01bbeb52b1666a0c7c07c5b10826c7154f7fe2a13c", transactionIndex: "68", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "2169021", gasUsed: "31439", confirmations: "2911475"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1514371159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51426036831882819510" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawFunds( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4836970", timeStamp: "1514826898", hash: "0x7fec9b0632b886dea1264043e91216fb3d9ac4704f227674f66b4fef12f98a23", nonce: "118", blockHash: "0xce54705c920fac5f731ab69086cf6e3c019dc235a2b47fda1013c62d954e9086", transactionIndex: "131", from: "0xa35fe1bcfde297a328dd4ef0bc902fb1ca7661cb", to: "0x3dbdc81a6edc94c720b0b88fb65dbd7e395fdcf6", value: "0", gas: "33717", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x68742da600000000000000000000000026588a9301b0428d95e6fc3a5024fce8bec12d51", contractAddress: "", cumulativeGasUsed: "4028911", gasUsed: "31439", confirmations: "2880512"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addr", value: addressList[4]}], name: "withdrawFunds", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawFunds(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1514826898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "128044933779734776" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "51426036831882819510" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
