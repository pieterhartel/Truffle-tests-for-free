const OwnersExchange = artifacts.require( "./OwnersExchange.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "OwnersExchange" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x468Fc64277655687c358c2f016F2d772D4148626", "0x7b1660682078fe0eFD9310e8EFe32Cb93a0417bc", "0x3Ab2ab661311501F4B3c9B17d40e3D95F9Bc577f", "0x514910771AF9Ca656af840dff83E8264EcF986CA", "0xBf37bdA8937E7DD3A0CF5fb4d51Daf82f81737eB", "0xb3D3e3af50d5c3f715c024fBFB054882bE199A08", "0x324C7a82024e498152F71151dc7E364fE014024a", "0xEC9B6aA1f9Fb2BE9efF77D271E2b6a37a386a662", "0xa8CCc0A6961CfE3994423ac67C4Bbd3BcE0aCB04", "0x81F7cA1BdcD75fAe30Da14F95BF5965D6f814f3b", "0xE2F36140D66f0d51374a2c49419b3B1b6369D984", "0x02b0e3CCF41270FB5294Ec229667c56c0BB14a95", "0x27Fbdf7dA94ad91DE76E4d51f1A416B570Cd2969", "0xCe7457D5012eC65c000220E80e00C1BFDAA287e7", "0x2b62dd90d422b0CfC32CaA7FF62445c530f6E848", "0x489Ed404be1BeB391F4E1e748221bCe0857cBF23", "0xdE7d9d56D64895d9Dc862476f7a98f8d921cD160", "0x41221F2C0c521d2086A4e95D4996fe22B904aFFa"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_start", type: "uint256"}], name: "getOrders", outputs: [{name: "keys", type: "uint256[10]"}, {name: "addresses", type: "address[10]"}, {name: "orderTypes", type: "uint8[10]"}, {name: "prices", type: "uint256[10]"}, {name: "amounts", type: "uint256[10]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalFees", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_price", type: "uint256"}, {name: "_amount", type: "uint256"}], name: "feeForOrder", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getOrderBookSize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_i", type: "uint256"}], name: "getOrderBookKey", outputs: [{name: "key", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "orderCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_price", type: "uint256"}, {name: "_amount", type: "uint256"}], name: "costOfOrder", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "lockedFees", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "feeToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "addressIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "feeBalances", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "poolOwners", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_key", type: "uint256"}], name: "getOrder", outputs: [{name: "", type: "uint8"}, {name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "addressRegistry", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_start", type: "uint256"}], name: "getOrderBookKeys", outputs: [{name: "keys", type: "uint256[10]"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderFilled", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["NewOrder(uint8,address,uint256,uint256)", "OrderRemoved(uint8,address,uint256,uint256)", "OrderFilled(uint8,address,address,uint256,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xbcbf7b263490465b953d70010fc8e536abfdfbcae985c547ef7e2ada714af4ff", "0xe2f99b27ce844edd7e242a1056afe8f0a4f5c28c45b300a13fec9aff87d82bff", "0x37561a23711d8277a49bc8fdac68dafcf982b917f213a7691984a6dcea1edcd2", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6625646 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6629734 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_poolOwners", value: 4}, {type: "address", name: "_feeToken", value: 5}], name: "OwnersExchange", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_start", value: random.range( maxRandom )}], name: "getOrders", outputs: [{name: "keys", type: "uint256[10]"}, {name: "addresses", type: "address[10]"}, {name: "orderTypes", type: "uint8[10]"}, {name: "prices", type: "uint256[10]"}, {name: "amounts", type: "uint256[10]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrders(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalFees", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalFees()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_price", value: random.range( maxRandom )}, {type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "feeForOrder", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeForOrder(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getOrderBookSize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrderBookSize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_i", value: random.range( maxRandom )}], name: "getOrderBookKey", outputs: [{name: "key", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrderBookKey(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "orderCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "orderCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_price", value: random.range( maxRandom )}, {type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "costOfOrder", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "costOfOrder(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lockedFees", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockedFees()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "feeToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "addressIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addressIndex(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "feeBalances", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "feeBalances(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "poolOwners", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "poolOwners()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_key", value: random.range( maxRandom )}], name: "getOrder", outputs: [{name: "", type: "uint8"}, {name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrder(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "addressRegistry", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addressRegistry(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_start", value: random.range( maxRandom )}], name: "getOrderBookKeys", outputs: [{name: "keys", type: "uint256[10]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrderBookKeys(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "OwnersExchange", function( accounts ) {

	it( "TEST: OwnersExchange( addressList[4], addressList[5] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6625646", timeStamp: "1541104172", hash: "0xeaf26637b8a7e489af7d3a7c8a7b3fc7dcbc009fbd0c4cae0882598eecc1e8c7", nonce: "1897", blockHash: "0x597586d239665872c26d335e70fc498f59e89286e061efbe55bec7830b823b01", transactionIndex: "1", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: 0, value: "0", gas: "6721975", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb0b02f790000000000000000000000003ab2ab661311501f4b3c9b17d40e3d95f9bc577f000000000000000000000000514910771af9ca656af840dff83e8264ecf986ca", contractAddress: "0x468fc64277655687c358c2f016f2d772d4148626", cumulativeGasUsed: "2836358", gasUsed: "2815358", confirmations: "1099158"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_poolOwners", value: addressList[4]}, {type: "address", name: "_feeToken", value: addressList[5]}], name: "OwnersExchange", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = OwnersExchange.new( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541104172 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = OwnersExchange.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setFee( \"500000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6625650", timeStamp: "1541104234", hash: "0x69f83b8736ddb9fffaa70ffd93f0db76973e7c2b09810cf14d38334ea875216e", nonce: "1898", blockHash: "0x8c0269f67de8315473fef2518c7f81671051bfd31f39e63a402ef8c095f48fb5", transactionIndex: "42", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "6721975", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x69fe0e2d00000000000000000000000000000000000000000000000006f05b59d3b20000", contractAddress: "", cumulativeGasUsed: "1192485", gasUsed: "42573", confirmations: "1099154"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_fee", value: "500000000000000000"}], name: "setFee", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFee(uint256)" ]( "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541104234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"18650000000000000000\", \"840000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6625885", timeStamp: "1541107485", hash: "0x79414c8f4412151695bacce09d8dfcc179519fede835df7affaaa384ba761bb3", nonce: "97", blockHash: "0x0c1cb5306b988c9222c1193a138b859d244489cca9cea90795a455fd788946d3", transactionIndex: "107", from: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "307129", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3acde41900000000000000000000000000000000000000000000000102d21c30250900000000000000000000000000000000000000000000000000000ba8478cab540000", contractAddress: "", cumulativeGasUsed: "6759858", gasUsed: "204753", confirmations: "1098919"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "18650000000000000000"}, {type: "uint256", name: "_amount", value: "840000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "18650000000000000000", "840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541107485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb"}, {name: "price", type: "uint256", value: "18650000000000000000"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "31773580730770656" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"8000000000000000000\", \"5200000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626046", timeStamp: "1541109633", hash: "0x74149793fb7347b416f93a7f09563e74f359dbe2fb809c971950a091a745fa61", nonce: "94", blockHash: "0x75c9853adb0a59f656d00bf568226d8ea1ffb9c66808b08eb9c1c39a038ba4d9", transactionIndex: "44", from: "0xb3d3e3af50d5c3f715c024fbfb054882be199a08", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "4160000000000000000", gas: "157167", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000000737693eb3340000", contractAddress: "", cumulativeGasUsed: "1880947", gasUsed: "104778", confirmations: "1098758"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "4160000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "8000000000000000000"}, {type: "uint256", name: "_amount", value: "520000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "8000000000000000000", "520000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541109633 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0xb3d3e3af50d5c3f715c024fbfb054882be199a08"}, {name: "price", type: "uint256", value: "8000000000000000000"}, {name: "amount", type: "uint256", value: "520000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "2072302276909590035" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6626181", timeStamp: "1541111675", hash: "0xc19292629b807596608e4229f165015e4fda576f46124ad9bf7c6f303ef03741", nonce: "98", blockHash: "0x2723b20081797eea7043526f14ef1559355be3c535a3109ce765dd95fbcb2e6b", transactionIndex: "58", from: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "148681", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0559c1140000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3759996", gasUsed: "49561", confirmations: "1098623"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "1"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541111675 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb"}, {name: "price", type: "uint256", value: "18650000000000000000"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "31773580730770656" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"18650000000000000000\", \"800000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626191", timeStamp: "1541111784", hash: "0x8f0afc57c8ff1171c631c3c295a7f06f0d883639b60bc155247129198f1939e5", nonce: "100", blockHash: "0xb4bc4cd74358fac6e1987e6805d119b1d2fdbdc81a92ee3aa24d6fc2f3e6a9a4", transactionIndex: "29", from: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "284629", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3acde41900000000000000000000000000000000000000000000000102d21c3025090000000000000000000000000000000000000000000000000000011c37937e080000", contractAddress: "", cumulativeGasUsed: "3280980", gasUsed: "189753", confirmations: "1098613"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "18650000000000000000"}, {type: "uint256", name: "_amount", value: "80000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "18650000000000000000", "80000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541111784 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb"}, {name: "price", type: "uint256", value: "18650000000000000000"}, {name: "amount", type: "uint256", value: "80000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "31773580730770656" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"16390000000000000000\", \"800000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626208", timeStamp: "1541112082", hash: "0x70b25c466ac2ec01d286a59ecdca50bb72f717e79e922d8d0f023091f0c13dd7", nonce: "102", blockHash: "0x458c1f4811ee4c097b31aa3f7801cf5655be123732d48cd7e9c520043aecff5b", transactionIndex: "41", from: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000e374fa297ca70000000000000000000000000000000000000000000000000000011c37937e080000", contractAddress: "", cumulativeGasUsed: "6764616", gasUsed: "128878", confirmations: "1098596"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "16390000000000000000"}, {type: "uint256", name: "_amount", value: "80000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "16390000000000000000", "80000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541112082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb"}, {name: "price", type: "uint256", value: "16390000000000000000"}, {name: "amount", type: "uint256", value: "80000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "31773580730770656" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"17420000000000000000\", \"160000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626222", timeStamp: "1541112262", hash: "0xbef913ba020183d254cb0fe2f2ef2f35e447ded8c1d429da8b0dba41f53efafa", nonce: "104", blockHash: "0xb29f2c312a12c8bdb2ce7208bf9a2e70ac9c931dab95d923f9111f77bf569b55", transactionIndex: "55", from: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000f1c045b4734e000000000000000000000000000000000000000000000000000002386f26fc100000", contractAddress: "", cumulativeGasUsed: "2766155", gasUsed: "128878", confirmations: "1098582"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "17420000000000000000"}, {type: "uint256", name: "_amount", value: "160000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "17420000000000000000", "160000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541112262 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xbf37bda8937e7dd3a0cf5fb4d51daf82f81737eb"}, {name: "price", type: "uint256", value: "17420000000000000000"}, {name: "amount", type: "uint256", value: "160000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "31773580730770656" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"12988000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626643", timeStamp: "1541118229", hash: "0x0ad14b3ec628d9dd9e3beacb6c20542711112a1b26f806afb61b823b2999b01f", nonce: "30", blockHash: "0xf86c90601eb83fc0cce909a70316edf882f4b39dc357e901a3dfcf710bc38c30", transactionIndex: "46", from: "0x324c7a82024e498152f71151dc7e364fe014024a", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "201048", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000b43ea52fc6c60000000000000000000000000000000000000000000000000000008e1bc9bf040000", contractAddress: "", cumulativeGasUsed: "2750279", gasUsed: "119032", confirmations: "1098161"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "12988000000000000000"}, {type: "uint256", name: "_amount", value: "40000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "12988000000000000000", "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541118229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x324c7a82024e498152f71151dc7e364fe014024a"}, {name: "price", type: "uint256", value: "12988000000000000000"}, {name: "amount", type: "uint256", value: "40000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "7739359228777777777" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: fillSellOrder( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6626648", timeStamp: "1541118290", hash: "0xd68d69cc7dd5e5b30b8fd36bdf78cb681da9a4fe44e4fd83fd817c99d7f61cb0", nonce: "95", blockHash: "0x275a0976046dcff8043e70fec9777096078197b9552d75b701bb3cd35bacdced", transactionIndex: "66", from: "0xb3d3e3af50d5c3f715c024fbfb054882be199a08", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "519520000000000000", gas: "268752", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc3aea22e0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "2780817", gasUsed: "134168", confirmations: "1098156"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "519520000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "6"}], name: "fillSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillSellOrder(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541118290 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderFilled", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x324c7a82024e498152f71151dc7e364fe014024a"}, {name: "receiver", type: "address", value: "0xb3d3e3af50d5c3f715c024fbfb054882be199a08"}, {name: "price", type: "uint256", value: "12988000000000000000"}, {name: "amount", type: "uint256", value: "40000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "2072302276909590035" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"47680000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626753", timeStamp: "1541119892", hash: "0xb95887ad25b14d623ba45d19457e7a7c8fb649f4d914cb0050c862a92598cb8b", nonce: "32", blockHash: "0xe83ff503039707262d44fda44ba22f60d4b93ee224088e356d3767e6ffc88c9f", transactionIndex: "32", from: "0x324c7a82024e498152f71151dc7e364fe014024a", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "201144", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3acde41900000000000000000000000000000000000000000000000295b163616aa00000000000000000000000000000000000000000000000000000008e1bc9bf040000", contractAddress: "", cumulativeGasUsed: "1402121", gasUsed: "119096", confirmations: "1098051"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "47680000000000000000"}, {type: "uint256", name: "_amount", value: "40000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "47680000000000000000", "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541119892 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x324c7a82024e498152f71151dc7e364fe014024a"}, {name: "price", type: "uint256", value: "47680000000000000000"}, {name: "amount", type: "uint256", value: "40000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "7739359228777777777" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"14600000000000000000\", \"240000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626822", timeStamp: "1541120971", hash: "0x7645794e1694e8e28df1bfeb6f4465653864037016b9f9ec68d59eee619b797e", nonce: "38", blockHash: "0x03c6eea9a47d171a560e05ff11a832228b561361fe3b529a0069e404a584b20f", transactionIndex: "74", from: "0xec9b6aa1f9fb2be9eff77d271e2b6a37a386a662", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "201144", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000ca9d9ea558b400000000000000000000000000000000000000000000000000000354a6ba7a180000", contractAddress: "", cumulativeGasUsed: "2750646", gasUsed: "119096", confirmations: "1097982"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "14600000000000000000"}, {type: "uint256", name: "_amount", value: "240000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "14600000000000000000", "240000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541120971 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xec9b6aa1f9fb2be9eff77d271e2b6a37a386a662"}, {name: "price", type: "uint256", value: "14600000000000000000"}, {name: "amount", type: "uint256", value: "240000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "317769118458104528" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: fillBuyOrder( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6626848", timeStamp: "1541121297", hash: "0x5cd9e4259e68c73c3cefb41958e5b182a65fa96a2a8ddd7a38c30489cf3915aa", nonce: "23", blockHash: "0x6a1aae2e69d770efc6babcbc8a928478040c3e2fc3eba6f60fb0e61cc4fe8571", transactionIndex: "49", from: "0xa8ccc0a6961cfe3994423ac67c4bbd3bce0acb04", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "189252", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x8cbcca070000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2229311", gasUsed: "66168", confirmations: "1097956"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "2"}], name: "fillBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillBuyOrder(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541121297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderFilled", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0xb3d3e3af50d5c3f715c024fbfb054882be199a08"}, {name: "receiver", type: "address", value: "0xa8ccc0a6961cfe3994423ac67c4bbd3bce0acb04"}, {name: "price", type: "uint256", value: "8000000000000000000"}, {name: "amount", type: "uint256", value: "520000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "6518197635918565" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"1000000000000000000\", \"4000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627237", timeStamp: "1541127125", hash: "0x27562ef7b6b82479acc03d9c7750f5fe4bde87b97285748ec2896528eca15a5f", nonce: "1", blockHash: "0x5fe7c2aa45db33e1fce87c3d83c26f028a750b856e25b9c780a82a8bd2b219e3", transactionIndex: "72", from: "0x81f7ca1bdcd75fae30da14f95bf5965d6f814f3b", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "400000000000000000", gas: "157167", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "7471116", gasUsed: "104778", confirmations: "1097567"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "1000000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541127125 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x81f7ca1bdcd75fae30da14f95bf5965d6f814f3b"}, {name: "price", type: "uint256", value: "1000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"13800000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627695", timeStamp: "1541133604", hash: "0x96f08f5e3cc5ac6e4b8dd6f6b89c6cb368294f7de0c5871a1938d1b35d0536db", nonce: "92", blockHash: "0x0d18ceb39d6ddde4986f8b7fad5edc0678826d7a9bc5f5ba5a4e52c633f132cb", transactionIndex: "105", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000bf8372e26c640000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "6218087", gasUsed: "128878", confirmations: "1097109"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "13800000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "13800000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541133604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13800000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"18000000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627719", timeStamp: "1541133929", hash: "0xe0d07849e6addcfceb4afd69643b774421be0971c59ecf45a8700a0628ab4d38", nonce: "94", blockHash: "0x93604e91b1b1e01a4c3580adf750c884d0c2fc2652a137eb815a2feb15c0eb23", transactionIndex: "88", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000f9ccd8a1c5080000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "6154080", gasUsed: "128878", confirmations: "1097085"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "18000000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "18000000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541133929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "18000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"14200000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627742", timeStamp: "1541134329", hash: "0xb0e654446348f6078ed7aab7c4ae23caef62a03bcae316812cfe415c29b974b1", nonce: "96", blockHash: "0xd9f8abb9753acf2c113137622a5cd631da6641f290fa593f6e5dbde772b227a6", transactionIndex: "17", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000c51088c3e28c0000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "2350872", gasUsed: "128878", confirmations: "1097062"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "14200000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "14200000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541134329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "14200000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"14400000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627771", timeStamp: "1541134818", hash: "0x9689d72f570a1bed0ccf79d256fadaa1630fc562c95999c24ca16f688f177f99", nonce: "98", blockHash: "0x58c9934712059e3ba67a4b001f5838501523f911b8fda52f47c86fbd6790b96c", transactionIndex: "106", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000c7d713b49da00000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "6158100", gasUsed: "128878", confirmations: "1097033"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "14400000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "14400000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541134818 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "14400000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"14000000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627784", timeStamp: "1541135025", hash: "0xc0bc8479aa95ff2df090ffd01cbc0409d2ca62d11e9adb93d1647436f308b141", nonce: "100", blockHash: "0x8ab9e3cbbe18a2c1fa080f2391b60459632fcc7c9d6f89ee1ba800245018dc54", transactionIndex: "28", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000c249fdd327780000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "6400955", gasUsed: "128878", confirmations: "1097020"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "14000000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "14000000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541135025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "14000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"13900000000000000000\", \"200000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627821", timeStamp: "1541135603", hash: "0x2711e70c464211d9d3373fbe2c10820b535b6a499400ccdd63b81cb537223523", nonce: "102", blockHash: "0x12ee5590352a127a28f04c09dbaeea81a66e55ca88e964fe39b0cccde48b2195", transactionIndex: "71", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000c0e6b85ac9ee000000000000000000000000000000000000000000000000000002c68af0bb140000", contractAddress: "", cumulativeGasUsed: "7424134", gasUsed: "128878", confirmations: "1096983"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "13900000000000000000"}, {type: "uint256", name: "_amount", value: "200000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "13900000000000000000", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541135603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13900000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"13850000000000000000\", \"200000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627972", timeStamp: "1541137890", hash: "0x4990c032f37a074d39704da09bd84c36a13341e795fe9c6d37b84cb216bcd889", nonce: "106", blockHash: "0x06a77abe52c486f58696665eaebd707f17fbe97eb54480c6533db725769ce3b7", transactionIndex: "179", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000c035159e9b29000000000000000000000000000000000000000000000000000002c68af0bb140000", contractAddress: "", cumulativeGasUsed: "7769128", gasUsed: "128878", confirmations: "1096832"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "13850000000000000000"}, {type: "uint256", name: "_amount", value: "200000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "13850000000000000000", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541137890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13850000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"13950000000000000000\", \"200000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628013", timeStamp: "1541138429", hash: "0xf84cda0fc35939e2bf808d561b8b53f50e28443a04a403d862a7665932f4cc30", nonce: "108", blockHash: "0x1e4552535af5b0becb19ce3874b2df5e6033dcb00354c084221a7933fe7144f5", transactionIndex: "179", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000c1985b16f8b3000000000000000000000000000000000000000000000000000002c68af0bb140000", contractAddress: "", cumulativeGasUsed: "7562897", gasUsed: "128878", confirmations: "1096791"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "13950000000000000000"}, {type: "uint256", name: "_amount", value: "200000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "13950000000000000000", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541138429 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13950000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "6628027", timeStamp: "1541138744", hash: "0x08804bc2b1f747e77a76cbd865a1069378bcf94df865de843ee35a593c4610c6", nonce: "109", blockHash: "0xfe7d5e5150fc7ac2a60db10609e5ff8882b9e98667c62615741473a222c370c8", transactionIndex: "85", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c114000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "6415271", gasUsed: "41720", confirmations: "1096777"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "11"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541138744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "18000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"5000000000000000000\", \"4000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628066", timeStamp: "1541139266", hash: "0x5603f19ba408bcfd55cdb2baeb008165be2e76ab8e66e6e2ec54e0c8bb21c3af", nonce: "74", blockHash: "0x71dbe66421f81e96412034b01869bd2afb36ba7bf2cef0d0f54008cefc6122d3", transactionIndex: "69", from: "0x02b0e3ccf41270fb5294ec229667c56c0bb14a95", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "2000000000000000000", gas: "157167", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "4779681", gasUsed: "89778", confirmations: "1096738"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "5000000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "5000000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541139266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x02b0e3ccf41270fb5294ec229667c56c0bb14a95"}, {name: "price", type: "uint256", value: "5000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "2714612966575600375" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"12500000000000000000\", \"840000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628345", timeStamp: "1541143171", hash: "0x3108423f4a3727cba143f1905fa10132a0fd20903facfd1063697031998e172f", nonce: "13", blockHash: "0x8ed5f29c53553ae1d81bb892c7feb6f65fc2778f54b25190fff1a22114a5d80b", transactionIndex: "105", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "201144", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000ad78ebc5ac6200000000000000000000000000000000000000000000000000000ba8478cab540000", contractAddress: "", cumulativeGasUsed: "7091365", gasUsed: "119096", confirmations: "1096459"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "12500000000000000000"}, {type: "uint256", name: "_amount", value: "840000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "12500000000000000000", "840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541143171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "12500000000000000000"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"6600000000000000000\", \"6000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628452", timeStamp: "1541144910", hash: "0x408e22fa47c575abb823729c2e039000a07d8fa07daacdc9ac0a1395a0e1efea", nonce: "25", blockHash: "0xa763af94465600f21a1d40e1515e8c90b44538c0de15e9bc234c98d1cba9ba0a", transactionIndex: "20", from: "0xce7457d5012ec65c000220e80e00c1bfdaa287e7", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "3960000000000000000", gas: "157167", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000005b97e9081d9400000000000000000000000000000000000000000000000000000853a0d2313c0000", contractAddress: "", cumulativeGasUsed: "4219818", gasUsed: "104778", confirmations: "1096352"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "3960000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "6600000000000000000"}, {type: "uint256", name: "_amount", value: "600000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "6600000000000000000", "600000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541144910 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0xce7457d5012ec65c000220e80e00c1bfdaa287e7"}, {name: "price", type: "uint256", value: "6600000000000000000"}, {name: "amount", type: "uint256", value: "600000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "521792674041248" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: fillBuyOrder( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6628484", timeStamp: "1541145395", hash: "0x6b2ee1529ee12196e4652bf9c7c1bf1864f36720e5c55e644d1b1a1e7b4fbccb", nonce: "18", blockHash: "0x5e4fe97a83592daafbf4a286217b7d42e90a19f8ba5655ae30e5c0896f40a7b2", transactionIndex: "41", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "254916", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8cbcca070000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "4934974", gasUsed: "124944", confirmations: "1096320"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "20"}], name: "fillBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillBuyOrder(uint256)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541145395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderFilled", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0xce7457d5012ec65c000220e80e00c1bfdaa287e7"}, {name: "receiver", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "6600000000000000000"}, {name: "amount", type: "uint256", value: "600000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"10000000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628497", timeStamp: "1541145539", hash: "0x5990bb8098b10ee3af45d3640d9a03e86b06a2c0413980d6fb18fd5a2ee86375", nonce: "20", blockHash: "0xb46da2416cd6b019290f3fe3682ce69fadd7e0caf3618727fa32cd55b7b9d414", transactionIndex: "94", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde4190000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "6298510", gasUsed: "128878", confirmations: "1096307"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "10000000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "10000000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541145539 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "10000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"2000000000000000000\", \"1000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628716", timeStamp: "1541148782", hash: "0xf535a8c158a3eb534fb081a838cfa1039f89b7557cafe42dd6eaf76612739e93", nonce: "1118", blockHash: "0xe9082524a13882d59bf86871ee0ccb8c4ae7b9c94bc8c38d264d964c992c80db", transactionIndex: "44", from: "0x2b62dd90d422b0cfc32caa7ff62445c530f6e848", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "2000000000000000000", gas: "157167", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000001bc16d674ec800000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6658887", gasUsed: "104778", confirmations: "1096088"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "2000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "2000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541148782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x2b62dd90d422b0cfc32caa7ff62445c530f6e848"}, {name: "price", type: "uint256", value: "2000000000000000000"}, {name: "amount", type: "uint256", value: "1000000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1264336097989557282" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"19\" )", async function( ) {
		const txOriginal = {blockNumber: "6628716", timeStamp: "1541148782", hash: "0x938b0b669dc05538397676ffb1b992eb8585a00f75ffa532204e61a879a80b93", nonce: "21", blockHash: "0xe9082524a13882d59bf86871ee0ccb8c4ae7b9c94bc8c38d264d964c992c80db", transactionIndex: "58", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8800000000", isError: "0", txreceipt_status: "1", input: "0x0559c1140000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "7835039", gasUsed: "41720", confirmations: "1096088"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "19"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541148782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "12500000000000000000"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"12500000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628918", timeStamp: "1541151601", hash: "0xdc36bc05f0b0f287ea40bb082f5503a3b051c083756e5c6e13a8691ab64d5acc", nonce: "25", blockHash: "0xe06b75236c9f26bc580f81cf6ee7f5dfefe867bd593ef71359d88a15aea33cc9", transactionIndex: "76", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193221", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000ad78ebc5ac620000000000000000000000000000000000000000000000000000008e1bc9bf040000", contractAddress: "", cumulativeGasUsed: "6312366", gasUsed: "128814", confirmations: "1095886"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "12500000000000000000"}, {type: "uint256", name: "_amount", value: "40000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "12500000000000000000", "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541151601 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "12500000000000000000"}, {name: "amount", type: "uint256", value: "40000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: fillBuyOrder( \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "6628930", timeStamp: "1541151809", hash: "0x7287f848862d85e5781b4ffbaf37097a951da347de8771ee499d92267e92b00d", nonce: "27", blockHash: "0xcdff1ae49c5862a7bfd96ffcf5cd412e6dcd42481f92907e68dbb9aee6c28f4f", transactionIndex: "69", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "181425", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x8cbcca070000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "6252566", gasUsed: "75950", confirmations: "1095874"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "18"}], name: "fillBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillBuyOrder(uint256)" ]( "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541151809 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderFilled", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x02b0e3ccf41270fb5294ec229667c56c0bb14a95"}, {name: "receiver", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "5000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"3000000000000000000\", \"4000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628932", timeStamp: "1541151814", hash: "0x4ce83945ff0893443da240707301cddeacf21b29bde6ce6d72f8313b0dc06dbe", nonce: "28", blockHash: "0x83d47b965c07f14b35dd775da64bf326aaa2765371bf8947c94d7110f2638045", transactionIndex: "17", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "1200000000000000000", gas: "157167", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c00000000000000000000000000000000000000000000000029a2241af62c0000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "565218", gasUsed: "104778", confirmations: "1095872"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "3000000000000000000"}, {type: "uint256", name: "_amount", value: "400000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "3000000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541151814 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "3000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"12500000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628942", timeStamp: "1541151895", hash: "0x5807973fa491ae3c1f25c96fce992e555e77854fdece7a7e34e8b3c818e125e6", nonce: "30", blockHash: "0xf3cfc01235a089110591db2b6c3270dcf84da178578501decdb1c5989aa008bc", transactionIndex: "94", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193221", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde419000000000000000000000000000000000000000000000000ad78ebc5ac620000000000000000000000000000000000000000000000000000008e1bc9bf040000", contractAddress: "", cumulativeGasUsed: "6068428", gasUsed: "128814", confirmations: "1095862"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "12500000000000000000"}, {type: "uint256", name: "_amount", value: "40000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "12500000000000000000", "40000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541151895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "12500000000000000000"}, {name: "amount", type: "uint256", value: "40000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"10000000000000000000\", \"200000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628976", timeStamp: "1541152417", hash: "0x6d8af913e06ebcdf482e80ac0fa9bfef21ae98d336f1d8af68beee557272d651", nonce: "32", blockHash: "0xa6f6d4f9a973e4a48936d7b04704635e8e5e127a8c56f0893455339730279b0b", transactionIndex: "67", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193317", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde4190000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000002c68af0bb140000", contractAddress: "", cumulativeGasUsed: "5329045", gasUsed: "128878", confirmations: "1095828"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "10000000000000000000"}, {type: "uint256", name: "_amount", value: "200000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "10000000000000000000", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541152417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "10000000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addSellOrder( \"25000000000000000000\", \"160000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628985", timeStamp: "1541152548", hash: "0xaa6f10d38ce5cd5858fa13fef487371204378539fde1e49164eb8beab0146805", nonce: "34", blockHash: "0xa832580f9bbc59449ed12273b986f819a953d42420129e4cd7ca01517ef83df1", transactionIndex: "97", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "193413", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3acde4190000000000000000000000000000000000000000000000015af1d78b58c4000000000000000000000000000000000000000000000000000002386f26fc100000", contractAddress: "", cumulativeGasUsed: "7842647", gasUsed: "128942", confirmations: "1095819"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "25000000000000000000"}, {type: "uint256", name: "_amount", value: "160000000000000000"}], name: "addSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSellOrder(uint256,uint256)" ]( "25000000000000000000", "160000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541152548 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "25000000000000000000"}, {name: "amount", type: "uint256", value: "160000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"4000000000000000000\", \"1000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6629064", timeStamp: "1541153477", hash: "0x95b949d92a5bb35682dc74e258307d30e6046b9d144683bf4e7b6aecfe45a8e0", nonce: "36", blockHash: "0x2c4551c3583133c4f1a798277ee30bcd52486ede4245080861bbf50f24ad1cb2", transactionIndex: "55", from: "0x489ed404be1beb391f4e1e748221bce0857cbf23", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "4000000000000000000", gas: "157167", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6979507", gasUsed: "89778", confirmations: "1095740"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "4000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "4000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541153477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x489ed404be1beb391f4e1e748221bce0857cbf23"}, {name: "price", type: "uint256", value: "4000000000000000000"}, {name: "amount", type: "uint256", value: "1000000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "101739427130794192" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6629100", timeStamp: "1541153929", hash: "0xd0c40aad106e656d43728d83a66ce414df733ee2e994f93414cfe95cc57b457c", nonce: "110", blockHash: "0x44aab9b2c1f8a8d302fff6239ca67d24df295cfa4b1a564bb2e65c1c20a026e0", transactionIndex: "114", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c114000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "7692741", gasUsed: "41720", confirmations: "1095704"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "10"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541153929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13800000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"16\" )", async function( ) {
		const txOriginal = {blockNumber: "6629102", timeStamp: "1541153949", hash: "0xc0018328d4a02a9ffc6bb7dcff2431522bae93ea7c169e4a1b3ce7fdcac69c24", nonce: "111", blockHash: "0x08722b34aa39f96e04cd0f9428ced47eec5aa5c7e53bd072843011ae1aab0e69", transactionIndex: "106", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c1140000000000000000000000000000000000000000000000000000000000000010", contractAddress: "", cumulativeGasUsed: "6274555", gasUsed: "41720", confirmations: "1095702"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "16"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541153949 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13850000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"5000000000000000000\", \"2000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6629102", timeStamp: "1541153949", hash: "0x5bca0c2c55e05455ea00c5151f9847e1845c28d623d7a38ccc3a1a7905e61a4f", nonce: "38", blockHash: "0x08722b34aa39f96e04cd0f9428ced47eec5aa5c7e53bd072843011ae1aab0e69", transactionIndex: "112", from: "0x489ed404be1beb391f4e1e748221bce0857cbf23", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "1000000000000000000", gas: "157167", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000002c68af0bb140000", contractAddress: "", cumulativeGasUsed: "6792939", gasUsed: "89778", confirmations: "1095702"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "5000000000000000000"}, {type: "uint256", name: "_amount", value: "200000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "5000000000000000000", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541153949 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x489ed404be1beb391f4e1e748221bce0857cbf23"}, {name: "price", type: "uint256", value: "5000000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "101739427130794192" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"15\" )", async function( ) {
		const txOriginal = {blockNumber: "6629104", timeStamp: "1541153968", hash: "0xd8e53444b9b5a91fc1acd0642f533763f861f75371d17e27b154bc6c3c1b1ad3", nonce: "112", blockHash: "0xafcac5524706e984bfe585298248565fa393de9c236dd7b0c72925ae355cb0b3", transactionIndex: "70", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c114000000000000000000000000000000000000000000000000000000000000000f", contractAddress: "", cumulativeGasUsed: "7471564", gasUsed: "41720", confirmations: "1095700"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "15"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "15", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541153968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13900000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "6629104", timeStamp: "1541153968", hash: "0x0d53f51c4e4eedc8467603a385161f459fd884ba3ab1457a3a4d4ae0df395bb6", nonce: "113", blockHash: "0xafcac5524706e984bfe585298248565fa393de9c236dd7b0c72925ae355cb0b3", transactionIndex: "71", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c1140000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "7513284", gasUsed: "41720", confirmations: "1095700"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "17"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541153968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "13950000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"14\" )", async function( ) {
		const txOriginal = {blockNumber: "6629104", timeStamp: "1541153968", hash: "0xf0086be96252f8e80db5ba9456095409dde39878fd34fea3cb03c0eac217b123", nonce: "114", blockHash: "0xafcac5524706e984bfe585298248565fa393de9c236dd7b0c72925ae355cb0b3", transactionIndex: "72", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c114000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "7555004", gasUsed: "41720", confirmations: "1095700"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "14"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541153968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "14000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "6629130", timeStamp: "1541154312", hash: "0xeb0854676f6725ad1487ec304643cc9445c9cdbeda06f9ad46dc2813596c2d51", nonce: "115", blockHash: "0x7b2aa1210effb5481ae4755cf435252e890b788fbcab11047cea1fa7766ffd96", transactionIndex: "187", from: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x0559c114000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "5882853", gasUsed: "41720", confirmations: "1095674"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "12"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541154312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0xe2f36140d66f0d51374a2c49419b3b1b6369d984"}, {name: "price", type: "uint256", value: "14200000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "369161032995100879" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"26\" )", async function( ) {
		const txOriginal = {blockNumber: "6629346", timeStamp: "1541157287", hash: "0x0679932f78f8e630476f8563565d24189dfb6eda6cdae6f2b4d3115660eff1d1", nonce: "35", blockHash: "0x93fb406ca6ce2d859104addefbf8d46fc5984234c17ed6706a235f3604a9f607", transactionIndex: "132", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c114000000000000000000000000000000000000000000000000000000000000001a", contractAddress: "", cumulativeGasUsed: "7551399", gasUsed: "41720", confirmations: "1095458"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "26"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "26", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541157287 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "10000000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: fillBuyOrder( \"29\" )", async function( ) {
		const txOriginal = {blockNumber: "6629366", timeStamp: "1541157530", hash: "0x7e11b4c0148e073cbd872e8c15ce82adecabcd7d5e9a98556404e9ac68b1bd94", nonce: "37", blockHash: "0xa51497e53c3dc3730f6c6026aac12b4aa17a5c1ebf8ba9f47ba6f35bf068ef7a", transactionIndex: "149", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "272641", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8cbcca07000000000000000000000000000000000000000000000000000000000000001d", contractAddress: "", cumulativeGasUsed: "7399558", gasUsed: "136761", confirmations: "1095438"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "29"}], name: "fillBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillBuyOrder(uint256)" ]( "29", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541157530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderFilled", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x489ed404be1beb391f4e1e748221bce0857cbf23"}, {name: "receiver", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "5000000000000000000"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"21\" )", async function( ) {
		const txOriginal = {blockNumber: "6629384", timeStamp: "1541157767", hash: "0xd7f7a286c5e1f515fd6b4f00ad00517e9f514909c8de0f7e7e675c593e2fd949", nonce: "38", blockHash: "0x9d48e63a73fd7169caae612a4d6ef58fbe9fc06df16d52b60b4fca6d5e2606ff", transactionIndex: "28", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "125158", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c1140000000000000000000000000000000000000000000000000000000000000015", contractAddress: "", cumulativeGasUsed: "5771787", gasUsed: "41720", confirmations: "1095420"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "21"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "21", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541157767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "10000000000000000000"}, {name: "amount", type: "uint256", value: "400000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: removeSellOrder( \"27\" )", async function( ) {
		const txOriginal = {blockNumber: "6629396", timeStamp: "1541157876", hash: "0x4a8bad31cea58644c1905e0af920c0e234f43f941c73d0a1b1002ee87912265e", nonce: "39", blockHash: "0xc9576f5f5902d6296cc3a4f55e2d946e69a77baa44942a60a7f7bcfc1d8f2aef", transactionIndex: "145", from: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "107433", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0559c114000000000000000000000000000000000000000000000000000000000000001b", contractAddress: "", cumulativeGasUsed: "7714701", gasUsed: "35811", confirmations: "1095408"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "27"}], name: "removeSellOrder", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "removeSellOrder(uint256)" ]( "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541157876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderRemoved", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderRemoved", events: [{name: "orderType", type: "uint8", value: "2"}, {name: "sender", type: "address", value: "0x27fbdf7da94ad91de76e4d51f1a416b570cd2969"}, {name: "price", type: "uint256", value: "25000000000000000000"}, {name: "amount", type: "uint256", value: "160000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "188128512278179902" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: fillBuyOrder( \"28\" )", async function( ) {
		const txOriginal = {blockNumber: "6629462", timeStamp: "1541158891", hash: "0x3c6d6075eb7389252c5049ea401b36c3ef663eb6f35f3f228ae3efca49593c10", nonce: "11", blockHash: "0xe85e3107534f9ce15c9a0ed54c52a245dcd5d731130baa29f5730a4a68ef7486", transactionIndex: "80", from: "0xde7d9d56d64895d9dc862476f7a98f8d921cd160", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "0", gas: "181425", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x8cbcca07000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "5462600", gasUsed: "75950", confirmations: "1095342"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_key", value: "28"}], name: "fillBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillBuyOrder(uint256)" ]( "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541158891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "OrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OrderFilled", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x489ed404be1beb391f4e1e748221bce0857cbf23"}, {name: "receiver", type: "address", value: "0xde7d9d56d64895d9dc862476f7a98f8d921cd160"}, {name: "price", type: "uint256", value: "4000000000000000000"}, {name: "amount", type: "uint256", value: "1000000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addBuyOrder( \"2000000000000000000\", \"6000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6629734", timeStamp: "1541162500", hash: "0xd2446bfe99aa60c699cb6c4b248797b359717d0efe974522e408ae311a33436b", nonce: "7", blockHash: "0xae15ae0d5513d5994892d067f181427f6443f482b8b3789a9f7aa781f9b214bd", transactionIndex: "63", from: "0x41221f2c0c521d2086a4e95d4996fe22b904affa", to: "0x468fc64277655687c358c2f016f2d772d4148626", value: "1200000000000000000", gas: "157167", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x9049681c0000000000000000000000000000000000000000000000001bc16d674ec800000000000000000000000000000000000000000000000000000853a0d2313c0000", contractAddress: "", cumulativeGasUsed: "7476256", gasUsed: "104778", confirmations: "1095070"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "2000000000000000000"}, {type: "uint256", name: "_amount", value: "600000000000000000"}], name: "addBuyOrder", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addBuyOrder(uint256,uint256)" ]( "2000000000000000000", "600000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541162500 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "orderType", type: "uint8"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "NewOrder", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewOrder", events: [{name: "orderType", type: "uint8", value: "1"}, {name: "sender", type: "address", value: "0x41221f2c0c521d2086a4e95d4996fe22b904affa"}, {name: "price", type: "uint256", value: "2000000000000000000"}, {name: "amount", type: "uint256", value: "600000000000000000"}], address: "0x468fc64277655687c358c2f016f2d772d4148626"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "79090721000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
