const PonyCore = artifacts.require( "./PonyCore.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PonyCore" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xAeC5cf7Fa497c2B27A6F37ee0c817c619b42c03A", "0x6DB88c938599C1a461e975F06Cf457E0B68aFF9b", "0xb5E7B466D35F1780448868FB9d47A6872CB4c40b", "0x618a9b59F5Df9B410a3f1f926a4C2B2B2e9dCe24", "0x7c77Ed12C05069981840d5277801199aA0D12b78", "0x4d10CcE87A8AB67E9c70637c7B468522AA5EE82B", "0x223060aC431Fb5Bc7657C945ae0299b27C6d7bC3", "0x0b4C48c4F99421416F5d50c9FBC3995925DaC011", "0x725A490bc514e96f4c60BB71012a8d36Cd443794", "0xfaB24EA18482eEA943DE46d90DA0496AccED5436", "0xb61a7e1eaa78F3Ace657Fb3d7bEB450Fa68afef6"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_interfaceID", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cfoAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "promoCreatedCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "getDerbyWinningCount", outputs: [{name: "grandPrix1st", type: "uint256"}, {name: "grandPrix2st", type: "uint256"}, {name: "grandPrix3st", type: "uint256"}, {name: "grandLucky", type: "uint256"}, {name: "league1st", type: "uint256"}, {name: "league2st", type: "uint256"}, {name: "league3st", type: "uint256"}, {name: "leagueLucky", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "siringAuction", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "GEN0_MINIMUM_STARTING_PRICE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "getPony", outputs: [{name: "isReady", type: "bool"}, {name: "cooldownEndBlock", type: "uint256"}, {name: "birthTime", type: "uint256"}, {name: "matronId", type: "uint256"}, {name: "sireId", type: "uint256"}, {name: "genes", type: "bytes22"}, {name: "age", type: "uint256"}, {name: "month", type: "uint256"}, {name: "retiredAge", type: "uint256"}, {name: "rankingScore", type: "uint256"}, {name: "derbyAttendCount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_matronId", type: "uint256"}, {name: "_sireId", type: "uint256"}], name: "canBreedWith", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "ponyIndexToApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "owner", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newContractAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "count", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "secondsPerBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "tokensOfOwner", outputs: [{name: "ownerTokens", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "isPonyRetired", outputs: [{name: "isRetired", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "isAttendDerby", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rewardAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "ponyIndexToOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "cooldowns", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "derbyAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cooAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "autoBirthFee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "GEN0_MAXIMUM_STARTING_PRICE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gen0Stat", outputs: [{name: "retiredAge", type: "uint8"}, {name: "maxSpeed", type: "uint8"}, {name: "maxStamina", type: "uint8"}, {name: "maxStart", type: "uint8"}, {name: "maxBurst", type: "uint8"}, {name: "maxTemperament", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "nextGen0PriceRate", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_ponyId", type: "uint256"}], name: "isReadyToBreed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "getAbility", outputs: [{name: "speed", type: "uint8"}, {name: "stamina", type: "uint8"}, {name: "start", type: "uint8"}, {name: "burst", type: "uint8"}, {name: "temperament", type: "uint8"}, {name: "maxSpeed", type: "uint8"}, {name: "maxStamina", type: "uint8"}, {name: "maxBurst", type: "uint8"}, {name: "maxStart", type: "uint8"}, {name: "maxTemperament", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "saleAuction", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ponyAbility", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gen0AuctionDuration", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gen0CreatedCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "geneScience", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "RewardSendSuccessful", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "matronCooldownEndBlock", type: "uint256"}, {indexed: false, name: "sireCooldownEndBlock", type: "uint256"}], name: "Pregnant", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "approved", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "receivedValue", type: "uint256"}, {indexed: false, name: "carrotCount", type: "uint256"}], name: "carrotPurchased", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newContract", type: "address"}], name: "ContractUpgrade", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["RewardSendSuccessful(address,address,uint256)", "Pregnant(address,uint256,uint256,uint256,uint256)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "Birth(address,uint256,uint256,uint256,bytes22)", "carrotPurchased(address,uint256,uint256)", "ContractUpgrade(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x02f82126d826d0ffee87341ba824e5c1281882204b82e44c61d7321c9d342dba", "0x92f88a5b0e68184d6eaf466894625052095288be7d39de2429081c769956be1e", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xe465c79ded075209bc7587e787932aa3812ed7fa715c2e2aaf9916e9f97bfe5f", "0x3b1f33cd7a9283ad87739f0ef4d9be13b03698b0e8a61587a4d9ad0dd352f7a3", "0x450db8da6efbe9c22f2347f7c2021231df1fc58d3ae9a2fa75d39fa446199305"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6664489 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6664901 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "PonyCore", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes4", name: "_interfaceID", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cfoAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cfoAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "promoCreatedCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "promoCreatedCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "getDerbyWinningCount", outputs: [{name: "grandPrix1st", type: "uint256"}, {name: "grandPrix2st", type: "uint256"}, {name: "grandPrix3st", type: "uint256"}, {name: "grandLucky", type: "uint256"}, {name: "league1st", type: "uint256"}, {name: "league2st", type: "uint256"}, {name: "league3st", type: "uint256"}, {name: "leagueLucky", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDerbyWinningCount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "siringAuction", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "siringAuction()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "GEN0_MINIMUM_STARTING_PRICE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GEN0_MINIMUM_STARTING_PRICE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "getPony", outputs: [{name: "isReady", type: "bool"}, {name: "cooldownEndBlock", type: "uint256"}, {name: "birthTime", type: "uint256"}, {name: "matronId", type: "uint256"}, {name: "sireId", type: "uint256"}, {name: "genes", type: "bytes22"}, {name: "age", type: "uint256"}, {name: "month", type: "uint256"}, {name: "retiredAge", type: "uint256"}, {name: "rankingScore", type: "uint256"}, {name: "derbyAttendCount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPony(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_matronId", value: random.range( maxRandom )}, {type: "uint256", name: "_sireId", value: random.range( maxRandom )}], name: "canBreedWith", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canBreedWith(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "ponyIndexToApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ponyIndexToApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "owner", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newContractAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newContractAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "count", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "secondsPerBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "secondsPerBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokensOfOwner", outputs: [{name: "ownerTokens", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensOfOwner(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "isPonyRetired", outputs: [{name: "isRetired", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPonyRetired(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "isAttendDerby", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isAttendDerby(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rewardAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rewardAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "ponyIndexToOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ponyIndexToOwner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "cooldowns", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cooldowns(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "derbyAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "derbyAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cooAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cooAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "autoBirthFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "autoBirthFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "GEN0_MAXIMUM_STARTING_PRICE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GEN0_MAXIMUM_STARTING_PRICE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gen0Stat", outputs: [{name: "retiredAge", type: "uint8"}, {name: "maxSpeed", type: "uint8"}, {name: "maxStamina", type: "uint8"}, {name: "maxStart", type: "uint8"}, {name: "maxBurst", type: "uint8"}, {name: "maxTemperament", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gen0Stat()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextGen0PriceRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextGen0PriceRate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_ponyId", value: random.range( maxRandom )}], name: "isReadyToBreed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isReadyToBreed(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "getAbility", outputs: [{name: "speed", type: "uint8"}, {name: "stamina", type: "uint8"}, {name: "start", type: "uint8"}, {name: "burst", type: "uint8"}, {name: "temperament", type: "uint8"}, {name: "maxSpeed", type: "uint8"}, {name: "maxStamina", type: "uint8"}, {name: "maxBurst", type: "uint8"}, {name: "maxStart", type: "uint8"}, {name: "maxTemperament", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAbility(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "saleAuction", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "saleAuction()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ponyAbility", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ponyAbility()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gen0AuctionDuration", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gen0AuctionDuration()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gen0CreatedCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gen0CreatedCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "geneScience", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",35] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "geneScience()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",35] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PonyCore", function( accounts ) {

	it( "TEST: PonyCore(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6664489", timeStamp: "1541654867", hash: "0x55eb5735577ac8f3b2a2a400e6710bb024219ecb0169ff5c566d78c42f59d335", nonce: "58", blockHash: "0xea2093ca37662e7617ae96a578cd7dcd73ed9301ec0da4a01bad0f67d793c210", transactionIndex: "12", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: 0, value: "0", gas: "5979626", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x88d115af", contractAddress: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", cumulativeGasUsed: "6311864", gasUsed: "5979626", confirmations: "1053669"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "PonyCore", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PonyCore.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541654867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PonyCore.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: genesisPonyInit( \"0x737373737373737373737373737373733030... )", async function( ) {
		const txOriginal = {blockNumber: "6664565", timeStamp: "1541655982", hash: "0xb85247c01012e0be3c03375a2c81b7e441ecb6ac1719177b076092f71ccccc02", nonce: "63", blockHash: "0xf678a8b3e0f9d15d564d59e2e27854d3da152ab9d6c0dc50c705ec322e38221a", transactionIndex: "67", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "356868", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xd34401bb73737373737373737373737373737373303030303030000000000000000000000000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000230000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000d200000000000000000000000000000000000000000000000000000000000000dc00000000000000000000000000000000000000000000000000000000000000dc00000000000000000000000000000000000000000000000000000000000000e600000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000aa00000000000000000000000000000000000000000000000000000000000000aa00000000000000000000000000000000000000000000000000000000000000aa00000000000000000000000000000000000000000000000000000000000000aa00000000000000000000000000000000000000000000000000000000000000aa", contractAddress: "", cumulativeGasUsed: "2904147", gasUsed: "356868", confirmations: "1053593"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_gensis", value: "0x73737373737373737373737373737373303030303030"}, {type: "uint256[5]", name: "_ability", value: ["35","25","35","40","30"]}, {type: "uint256[5]", name: "_maxAbility", value: ["210","220","220","230","240"]}, {type: "uint256[6]", name: "_gen0Stat", value: ["10","170","170","170","170","170"]}], name: "genesisPonyInit", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "genesisPonyInit(bytes22,uint256[5],uint256[5],uint256[6])" ]( "0x73737373737373737373737373737373303030303030", ["35","25","35","40","30"], ["210","220","220","230","240"], ["10","170","170","170","170","170"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541655982 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "tokenId", type: "uint256", value: "0"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[1,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "ponyId", type: "uint256", value: "0"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x73737373737373737373737373737373303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[1,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setDerbyAdress( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6664579", timeStamp: "1541656155", hash: "0x714874f81ba425532c92e7a52188a1405e1c6ce13ec45a3622ac92ca4c2358c1", nonce: "64", blockHash: "0x52568a7cdc70b3e0edba12368618ea32f06de63dd57c882e0e228cc498731e4a", transactionIndex: "15", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "43864", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x11453da7000000000000000000000000b5e7b466d35f1780448868fb9d47a6872cb4c40b", contractAddress: "", cumulativeGasUsed: "547100", gasUsed: "43864", confirmations: "1053579"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newDerby", value: addressList[4]}], name: "setDerbyAdress", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDerbyAdress(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541656155 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setRewardAdress( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6664581", timeStamp: "1541656209", hash: "0xe60761162e304bf09ebf3654e4f20b95518c8c5a880e82455a4bc7c1ed0e0ed6", nonce: "65", blockHash: "0xf34597dc7b454acbb8c8c7dce90b73820ac372660261c523eb7214a46132b41d", transactionIndex: "120", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "29216", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x52ff0391000000000000000000000000618a9b59f5df9b410a3f1f926a4c2b2b2e9dce24", contractAddress: "", cumulativeGasUsed: "3501976", gasUsed: "29216", confirmations: "1053577"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newReward", value: addressList[5]}], name: "setRewardAdress", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRewardAdress(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541656209 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setSaleAuctionAddress( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6664587", timeStamp: "1541656271", hash: "0x51b17aa4294782def01b707fb1b7bde659816cb789457b5e2c528194e59af492", nonce: "66", blockHash: "0x4f37d0186afc139cded6d1a9a34490323e8f6079ad9edffe834346c7471f4fdc", transactionIndex: "35", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "46680", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x6fbde40d0000000000000000000000007c77ed12c05069981840d5277801199aa0d12b78", contractAddress: "", cumulativeGasUsed: "1684848", gasUsed: "46680", confirmations: "1053571"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[6]}], name: "setSaleAuctionAddress", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setSaleAuctionAddress(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541656271 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setSiringAuctionAddress( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6664589", timeStamp: "1541656298", hash: "0x2f4411d4029cf3e77f9796ebabe6e1ea3b909e2f5a242af13072a8e9113d1de0", nonce: "67", blockHash: "0xea06b7e2e9d2d489cb0b18971733edf9919ccc76c13dfdf5cb653f52029b597a", transactionIndex: "33", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "45956", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x14001f4c0000000000000000000000004d10cce87a8ab67e9c70637c7b468522aa5ee82b", contractAddress: "", cumulativeGasUsed: "1286072", gasUsed: "45956", confirmations: "1053569"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[7]}], name: "setSiringAuctionAddress", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setSiringAuctionAddress(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541656298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setGeneScienceAddress( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6664591", timeStamp: "1541656329", hash: "0x7819bb2174b6a448b614a0479bde018560223c6a9e0e7a3c0daa6320c719b51e", nonce: "68", blockHash: "0xa53da2383a4b4424915a35675287c75d5220e4bf5bc0be4e922d4d5d7ecdd73b", transactionIndex: "10", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "45836", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x24e7a38a000000000000000000000000223060ac431fb5bc7657c945ae0299b27c6d7bc3", contractAddress: "", cumulativeGasUsed: "323249", gasUsed: "45836", confirmations: "1053567"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[8]}], name: "setGeneScienceAddress", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setGeneScienceAddress(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541656329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setPonyAbilityAddress( addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6664592", timeStamp: "1541656371", hash: "0x5d3f4ab40af6a6360da18585535c369f399e4a085910bce682f53fc067cb6bca", nonce: "69", blockHash: "0xb0fab495bba097b7eb16f4ebb31d2d20b62976b041b172f55fccea2163604708", transactionIndex: "69", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "45968", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x3fcbb9310000000000000000000000000b4c48c4f99421416f5d50c9fbc3995925dac011", contractAddress: "", cumulativeGasUsed: "2325426", gasUsed: "45968", confirmations: "1053566"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[9]}], name: "setPonyAbilityAddress", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPonyAbilityAddress(address)" ]( addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541656371 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: unPause(  )", async function( ) {
		const txOriginal = {blockNumber: "6664595", timeStamp: "1541656415", hash: "0x7fcefdc8ce18935808a5b2a641abe3250ebfb974e2df5e42838554b3f46968ff", nonce: "70", blockHash: "0x26c1ec56d5a823e144db940ac4b6c866e495caf7d81fb487d532c2076526adf2", transactionIndex: "42", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "30912", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xf7b188a5", contractAddress: "", cumulativeGasUsed: "1354024", gasUsed: "30912", confirmations: "1053563"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "unPause", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unPause()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541656415 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyCarrot( \"1541658814318\" )", async function( ) {
		const txOriginal = {blockNumber: "6664763", timeStamp: "1541658862", hash: "0x4f2330ceb36cbc6b492e41ee7c6bceffe4c4004495b783abf6d5bde0215dad58", nonce: "6", blockHash: "0x86d54b14347259673aa5d8857e079d2954d013841ccf04319fdf1a646027891c", transactionIndex: "81", from: "0x725a490bc514e96f4c60bb71012a8d36cd443794", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "34000000000000000", gas: "29384", gasPrice: "7810000000", isError: "0", txreceipt_status: "1", input: "0x5d79193800000000000000000000000000000000000000000000000000000166f206a76e", contractAddress: "", cumulativeGasUsed: "7833623", gasUsed: "24486", confirmations: "1053395"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "34000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "carrotCount", value: "1541658814318"}], name: "buyCarrot", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyCarrot(uint256)" ]( "1541658814318", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541658862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "receivedValue", type: "uint256"}, {indexed: false, name: "carrotCount", type: "uint256"}], name: "carrotPurchased", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "carrotPurchased", events: [{name: "buyer", type: "address", value: "0x725a490bc514e96f4c60bb71012a8d36cd443794"}, {name: "receivedValue", type: "uint256", value: "34000000000000000"}, {name: "carrotCount", type: "uint256", value: "1541658814318"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyCarrot( \"1541658806799\" )", async function( ) {
		const txOriginal = {blockNumber: "6664763", timeStamp: "1541658862", hash: "0xeecde1e422b173c912e288e2b0211942fea1e0ceeca5938c3104b3db6c76c9d2", nonce: "6", blockHash: "0x86d54b14347259673aa5d8857e079d2954d013841ccf04319fdf1a646027891c", transactionIndex: "82", from: "0xfab24ea18482eea943de46d90da0496acced5436", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "34000000000000000", gas: "29384", gasPrice: "7810000000", isError: "0", txreceipt_status: "1", input: "0x5d79193800000000000000000000000000000000000000000000000000000166f2068a0f", contractAddress: "", cumulativeGasUsed: "7858109", gasUsed: "24486", confirmations: "1053395"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "34000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "carrotCount", value: "1541658806799"}], name: "buyCarrot", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyCarrot(uint256)" ]( "1541658806799", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541658862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "receivedValue", type: "uint256"}, {indexed: false, name: "carrotCount", type: "uint256"}], name: "carrotPurchased", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "carrotPurchased", events: [{name: "buyer", type: "address", value: "0xfab24ea18482eea943de46d90da0496acced5436"}, {name: "receivedValue", type: "uint256", value: "34000000000000000"}, {name: "carrotCount", type: "uint256", value: "1541658806799"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x65373369316a33356a66726a736c69363030... )", async function( ) {
		const txOriginal = {blockNumber: "6664795", timeStamp: "1541659311", hash: "0xae731a880948c0cbb56da51810fcd78482ad331709de0b9e6fc0bf0aee18b85d", nonce: "78", blockHash: "0xdafb5046c4a888a8b9ab2d94f5fd89b8f11d8d7a557097a3f30b213023624532", transactionIndex: "28", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d65373369316a33356a66726a736c693630303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3789627", gasUsed: "420552", confirmations: "1053363"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x65373369316a33356a66726a736c6936303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x65373369316a33356a66726a736c6936303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541659311 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "1"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "1"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "1"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x65373369316a33356a66726a736c6936303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x646931326f6634376968716e726633683030... )", async function( ) {
		const txOriginal = {blockNumber: "6664804", timeStamp: "1541659404", hash: "0xde10b62e57f15dfde41b25708a7144107d0c3ba3f113d0b2c5a36de9f90c7d88", nonce: "79", blockHash: "0x8edd82adfa2efbc851ed03ab4e4cd85157e776fa3ff41ea59fb9c12713101565", transactionIndex: "23", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d646931326f6634376968716e7266336830303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "1406267", gasUsed: "390552", confirmations: "1053354"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x646931326f6634376968716e72663368303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x646931326f6634376968716e72663368303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541659404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "2"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "2"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "2"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x646931326f6634376968716e72663368303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x7369693768336f36343366337168336b3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664845", timeStamp: "1541660071", hash: "0xe024376e262605cc2fce710d03913414622ee443cbc2d14bda116dbd95076b89", nonce: "80", blockHash: "0x95f6d40d4a55741cc22d0cefe1c05492b4a47c1b85031663b0e9deb8b4a1d977", transactionIndex: "9", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d7369693768336f36343366337168336b30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "766493", gasUsed: "405910", confirmations: "1053313"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x7369693768336f36343366337168336b303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x7369693768336f36343366337168336b303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541660071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "3"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "3"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "3"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x7369693768336f36343366337168336b303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: createSaleAuction( \"2\", \"10000000000000000\", \"20000000... )", async function( ) {
		const txOriginal = {blockNumber: "6664854", timeStamp: "1541660214", hash: "0xf9cfb03d97106a9c5068208ff4ab9a452d49d783d216d4f1e3f6f245e8b8b834", nonce: "12", blockHash: "0xfa1e9241a563c34f0a523ce1508d018dcc34b6cd2310a8475edf7fa7bfc01f96", transactionIndex: "31", from: "0x725a490bc514e96f4c60bb71012a8d36cd443794", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "187066", gasPrice: "8000200000", isError: "0", txreceipt_status: "1", input: "0x3d7d3f5a0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000470de4df82000000000000000000000000000000000000000000000000000000000000000d2f00", contractAddress: "", cumulativeGasUsed: "6560305", gasUsed: "124254", confirmations: "1053304"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ponyId", value: "2"}, {type: "uint256", name: "_startingPrice", value: "10000000000000000"}, {type: "uint256", name: "_endingPrice", value: "20000000000000000"}, {type: "uint256", name: "_duration", value: "864000"}], name: "createSaleAuction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createSaleAuction(uint256,uint256,uint256,uint256)" ]( "2", "10000000000000000", "20000000000000000", "864000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541660214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x725a490bc514e96f4c60bb71012a8d36cd443794"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "2"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: createSaleAuction( \"2\", \"10000000000000000\", \"20000000... )", async function( ) {
		const txOriginal = {blockNumber: "6664860", timeStamp: "1541660327", hash: "0xc98a67277188e489ffc743eca87cd27b9b971fc64bd5ee87f4ce3666bdd06147", nonce: "13", blockHash: "0x470605d406bf77c47089cf203d2b07756803df510f03c869541b39ada9494f26", transactionIndex: "52", from: "0x725a490bc514e96f4c60bb71012a8d36cd443794", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "187066", gasPrice: "8000200000", isError: "1", txreceipt_status: "0", input: "0x3d7d3f5a0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000470de4df82000000000000000000000000000000000000000000000000000000000000000d2f00", contractAddress: "", cumulativeGasUsed: "4641808", gasUsed: "23892", confirmations: "1053298"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ponyId", value: "2"}, {type: "uint256", name: "_startingPrice", value: "10000000000000000"}, {type: "uint256", name: "_endingPrice", value: "20000000000000000"}, {type: "uint256", name: "_duration", value: "864000"}], name: "createSaleAuction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createSaleAuction(uint256,uint256,uint256,uint256)" ]( "2", "10000000000000000", "20000000000000000", "864000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541660327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6664870", timeStamp: "1541660507", hash: "0xf79a86bb2d84a60ee123ef674a2077a82936dc6a59186f19769c27de83905a7b", nonce: "81", blockHash: "0x540f02630b6d023b294fc106e0a1230e4c57fc71f87781fad91112c277f91dfa", transactionIndex: "43", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "40000000000000000000", gas: "31560", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1447828", gasUsed: "21040", confirmations: "1053288"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "40000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541660507 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x706d3769316235316c323761736369393030... )", async function( ) {
		const txOriginal = {blockNumber: "6664879", timeStamp: "1541660608", hash: "0x43f92f43e5d9244f0602d018d1687bddb750a3aef4820f84ac9e6becdf427056", nonce: "82", blockHash: "0x2e5abf526170944b821734ed8015e364a0d2207fa31a5f5861c120e86f17bd0f", transactionIndex: "23", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d706d3769316235316c3237617363693930303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3764404", gasUsed: "390552", confirmations: "1053279"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x706d3769316235316c32376173636939303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x706d3769316235316c32376173636939303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541660608 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "4"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "4"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "4"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x706d3769316235316c32376173636939303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x733837356961326d31346767736b62333030... )", async function( ) {
		const txOriginal = {blockNumber: "6664882", timeStamp: "1541660657", hash: "0x4aac30fa8976025bc33e55042ec9e69db82853ac2985fc8b46a749e76b58f239", nonce: "83", blockHash: "0xd97dbb1031fe14f6dd89dfa8576984cb53fdc12707bfb35812b47eb01bba2a58", transactionIndex: "40", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d733837356961326d31346767736b623330303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3365952", gasUsed: "390194", confirmations: "1053276"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x733837356961326d31346767736b6233303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x733837356961326d31346767736b6233303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541660657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "5"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "5"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "5"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x733837356961326d31346767736b6233303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x636d6937346a726a673172373532656f3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664884", timeStamp: "1541660673", hash: "0xabd7d68871c1b8cec7ed8c321eccbcefb17a7728ea54354d9b181967b1b3ee29", nonce: "84", blockHash: "0x283ba7a778e7b86543e51bcb975e26419274eb05700bc42878e66bb3e3e56690", transactionIndex: "47", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d636d6937346a726a673172373532656f30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "1884022", gasUsed: "390194", confirmations: "1053274"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x636d6937346a726a673172373532656f303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x636d6937346a726a673172373532656f303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541660673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "6"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "6"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "6"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x636d6937346a726a673172373532656f303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x69386d386566396c6a337133706b32683030... )", async function( ) {
		const txOriginal = {blockNumber: "6664884", timeStamp: "1541660673", hash: "0x9647c0b5947f90fac734671d4f1f525711f9d713a0a4e3e2fc8bfc043ea80194", nonce: "85", blockHash: "0x283ba7a778e7b86543e51bcb975e26419274eb05700bc42878e66bb3e3e56690", transactionIndex: "48", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d69386d386566396c6a337133706b326830303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2274932", gasUsed: "390910", confirmations: "1053274"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x69386d386566396c6a337133706b3268303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x69386d386566396c6a337133706b3268303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541660673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "7"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "7"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "7"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x69386d386566396c6a337133706b3268303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x363566626231723435693636723669353030... )", async function( ) {
		const txOriginal = {blockNumber: "6664884", timeStamp: "1541660673", hash: "0x7df23783ca7921dde861b014ae4be7ac6c026e6e1ea55dadc6b36ffa6c2ce47a", nonce: "86", blockHash: "0x283ba7a778e7b86543e51bcb975e26419274eb05700bc42878e66bb3e3e56690", transactionIndex: "49", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d3635666262317234356936367236693530303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2665126", gasUsed: "390194", confirmations: "1053274"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x36356662623172343569363672366935303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x36356662623172343569363672366935303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541660673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "8"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "8"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "8"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x36356662623172343569363672366935303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x3738736c39643336686c716434336f6c3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664884", timeStamp: "1541660673", hash: "0xa34bf4b85a22c0c834254db1d136f710c45e4fd6cb0a6bf79327bf0c136b0fb9", nonce: "87", blockHash: "0x283ba7a778e7b86543e51bcb975e26419274eb05700bc42878e66bb3e3e56690", transactionIndex: "50", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d3738736c39643336686c716434336f6c30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3055678", gasUsed: "390552", confirmations: "1053274"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x3738736c39643336686c716434336f6c303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x3738736c39643336686c716434336f6c303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541660673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "9"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "9"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "9"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x3738736c39643336686c716434336f6c303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x733536696e6d6b33396373383131366a3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664884", timeStamp: "1541660673", hash: "0xb2f63e35eb48ed7a9d789cdeeb1f3eb9034979079de01b2d152d95a822713ada", nonce: "88", blockHash: "0x283ba7a778e7b86543e51bcb975e26419274eb05700bc42878e66bb3e3e56690", transactionIndex: "51", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d733536696e6d6b33396373383131366a30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3446230", gasUsed: "390552", confirmations: "1053274"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x733536696e6d6b33396373383131366a303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x733536696e6d6b33396373383131366a303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541660673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "10"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "10"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "10"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x733536696e6d6b33396373383131366a303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x7135346a6938686e34623238736536373030... )", async function( ) {
		const txOriginal = {blockNumber: "6664884", timeStamp: "1541660673", hash: "0xda4e0354752b4bf1ffdb725356361e1f38565422efb852d95794f7fb96557320", nonce: "89", blockHash: "0x283ba7a778e7b86543e51bcb975e26419274eb05700bc42878e66bb3e3e56690", transactionIndex: "52", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d7135346a6938686e346232387365363730303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3836782", gasUsed: "390552", confirmations: "1053274"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x7135346a6938686e3462323873653637303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x7135346a6938686e3462323873653637303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541660673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "11"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "11"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "11"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x7135346a6938686e3462323873653637303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x3134716c643332676f6a726c34656f393030... )", async function( ) {
		const txOriginal = {blockNumber: "6664886", timeStamp: "1541660697", hash: "0x5cbb952750063156666b7d272a444591a5a75a66ff17a2a77806e67a04d65230", nonce: "90", blockHash: "0x8d7cd26342745fed9964e58d5b48cbf2080cbde0d8bf4f7eddafd0ae5e2a4404", transactionIndex: "34", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d3134716c643332676f6a726c34656f3930303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "1984890", gasUsed: "390552", confirmations: "1053272"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x3134716c643332676f6a726c34656f39303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x3134716c643332676f6a726c34656f39303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541660697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "12"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "12"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "12"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x3134716c643332676f6a726c34656f39303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x70316566336d3363643271386435336b3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664886", timeStamp: "1541660697", hash: "0xb59ae419c036163cb226e7c39f2894af0501ba92469d66a08dbe62459218f7d6", nonce: "91", blockHash: "0x8d7cd26342745fed9964e58d5b48cbf2080cbde0d8bf4f7eddafd0ae5e2a4404", transactionIndex: "35", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d70316566336d3363643271386435336b30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2374726", gasUsed: "389836", confirmations: "1053272"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x70316566336d3363643271386435336b303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x70316566336d3363643271386435336b303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541660697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "13"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "13"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "13"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x70316566336d3363643271386435336b303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x736473386b636c376c3568656e62356e3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664886", timeStamp: "1541660697", hash: "0x225804215010ee445af3151d6340c4a6c7bdeb250be9f0594d02df1db5bb088f", nonce: "92", blockHash: "0x8d7cd26342745fed9964e58d5b48cbf2080cbde0d8bf4f7eddafd0ae5e2a4404", transactionIndex: "36", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d736473386b636c376c3568656e62356e30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2766352", gasUsed: "391626", confirmations: "1053272"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x736473386b636c376c3568656e62356e303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x736473386b636c376c3568656e62356e303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541660697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "14"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "14"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "14"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x736473386b636c376c3568656e62356e303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x6a6b38366d6e626169667269723265363030... )", async function( ) {
		const txOriginal = {blockNumber: "6664886", timeStamp: "1541660697", hash: "0x0f15c3950d609637926dd36851904d1f7c99ae2ae3e92fefd9ecba5b54d1946a", nonce: "93", blockHash: "0x8d7cd26342745fed9964e58d5b48cbf2080cbde0d8bf4f7eddafd0ae5e2a4404", transactionIndex: "37", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d6a6b38366d6e6261696672697232653630303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3157262", gasUsed: "390910", confirmations: "1053272"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x6a6b38366d6e62616966726972326536303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x6a6b38366d6e62616966726972326536303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541660697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "15"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "15"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "15"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x6a6b38366d6e62616966726972326536303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x70396e6e666a706c366d386563666b333030... )", async function( ) {
		const txOriginal = {blockNumber: "6664886", timeStamp: "1541660697", hash: "0xc8d1b33f51a46a53a10f178e02d097bb20e28de696766315caffd87e0bef8af2", nonce: "94", blockHash: "0x8d7cd26342745fed9964e58d5b48cbf2080cbde0d8bf4f7eddafd0ae5e2a4404", transactionIndex: "38", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d70396e6e666a706c366d386563666b3330303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3547814", gasUsed: "390552", confirmations: "1053272"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x70396e6e666a706c366d386563666b33303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x70396e6e666a706c366d386563666b33303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541660697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "16"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "16"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "16"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x70396e6e666a706c366d386563666b33303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x336f336e6931723268676661733168363030... )", async function( ) {
		const txOriginal = {blockNumber: "6664886", timeStamp: "1541660697", hash: "0xcd3cd8390a36abe3aa3023f01bc15ac5f13b3933bb46c1ee86eab3f1058ab5d2", nonce: "95", blockHash: "0x8d7cd26342745fed9964e58d5b48cbf2080cbde0d8bf4f7eddafd0ae5e2a4404", transactionIndex: "39", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d336f336e69317232686766617331683630303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3938724", gasUsed: "390910", confirmations: "1053272"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x336f336e693172326867666173316836303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x336f336e693172326867666173316836303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541660697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "17"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "17"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "17"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x336f336e693172326867666173316836303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x716d666e696a636b6d686131706365343030... )", async function( ) {
		const txOriginal = {blockNumber: "6664888", timeStamp: "1541660722", hash: "0xd64283b8817509bdfa0298c83328094a29443b94e84329a6d70174bd6673f94d", nonce: "96", blockHash: "0xe2e02ea7a1245ea961d8479da734b094049f3b83cedcb00f362e8b8e9bb325ea", transactionIndex: "80", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d716d666e696a636b6d6861317063653430303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3201775", gasUsed: "390552", confirmations: "1053270"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x716d666e696a636b6d68613170636534303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x716d666e696a636b6d68613170636534303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541660722 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "18"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "18"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "18"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x716d666e696a636b6d68613170636534303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x70657033636b6d656234626468696b6f3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664890", timeStamp: "1541660750", hash: "0x6e9ebe958d7add53aaf0fbcf2157a4959b14bb88eaad712cabc818d5f41e1bf9", nonce: "97", blockHash: "0x087a219f3a283e1f61d05f86a741a54867c85e5a04f9c01826d502e2f4d0e524", transactionIndex: "85", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d70657033636b6d656234626468696b6f30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3765638", gasUsed: "390910", confirmations: "1053268"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x70657033636b6d656234626468696b6f303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x70657033636b6d656234626468696b6f303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541660750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "19"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "19"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "19"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x70657033636b6d656234626468696b6f303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x7264336f69357036666f6c3667336c6a3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664891", timeStamp: "1541660769", hash: "0x24cc7b0ed003ae98e828bf9a8906caaf876dee800ade326394ba4e69d9e906d8", nonce: "98", blockHash: "0xc2b8ffbb662c33c12eb3f3f3cce621e1044d12379bb84eaeee287b9e5090fbc8", transactionIndex: "69", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d7264336f69357036666f6c3667336c6a30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3834708", gasUsed: "390910", confirmations: "1053267"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x7264336f69357036666f6c3667336c6a303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x7264336f69357036666f6c3667336c6a303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541660769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "20"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "20"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "20"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x7264336f69357036666f6c3667336c6a303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x386e676c6d6538316a6d7365726963673030... )", async function( ) {
		const txOriginal = {blockNumber: "6664894", timeStamp: "1541660800", hash: "0x7ef6b2c656f2250c90b82426d12cc7ad2baa44843bfb88c560ff8f8797af4945", nonce: "99", blockHash: "0x5f88dc03d7d6dd696642796dcec666cd1bacde2f73350fb31153d2d6a48cd6a6", transactionIndex: "77", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d386e676c6d6538316a6d73657269636730303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2306847", gasUsed: "390552", confirmations: "1053264"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x386e676c6d6538316a6d736572696367303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x386e676c6d6538316a6d736572696367303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541660800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "21"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "21"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "21"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x386e676c6d6538316a6d736572696367303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyCarrot( \"1541660771309\" )", async function( ) {
		const txOriginal = {blockNumber: "6664894", timeStamp: "1541660800", hash: "0xf6e0c43654c66310b26e4104a9aa1c4c9919b37aa8587013e1bc41474a8c7dfc", nonce: "9", blockHash: "0x5f88dc03d7d6dd696642796dcec666cd1bacde2f73350fb31153d2d6a48cd6a6", transactionIndex: "79", from: "0xb61a7e1eaa78f3ace657fb3d7beb450fa68afef6", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "102000000000000000", gas: "29384", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x5d79193800000000000000000000000000000000000000000000000000000166f22483ed", contractAddress: "", cumulativeGasUsed: "2369234", gasUsed: "24486", confirmations: "1053264"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "102000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "carrotCount", value: "1541660771309"}], name: "buyCarrot", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyCarrot(uint256)" ]( "1541660771309", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541660800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "receivedValue", type: "uint256"}, {indexed: false, name: "carrotCount", type: "uint256"}], name: "carrotPurchased", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "carrotPurchased", events: [{name: "buyer", type: "address", value: "0xb61a7e1eaa78f3ace657fb3d7beb450fa68afef6"}, {name: "receivedValue", type: "uint256", value: "102000000000000000"}, {name: "carrotCount", type: "uint256", value: "1541660771309"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x733539646f32636938373466706738383030... )", async function( ) {
		const txOriginal = {blockNumber: "6664894", timeStamp: "1541660800", hash: "0x88db83674e02eed2a49eb1accd96fd33e1e00e5aa38d41656facfc83d3d30e9c", nonce: "100", blockHash: "0x5f88dc03d7d6dd696642796dcec666cd1bacde2f73350fb31153d2d6a48cd6a6", transactionIndex: "81", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d733539646f326369383734667067383830303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2841470", gasUsed: "390194", confirmations: "1053264"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x733539646f3263693837346670673838303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x733539646f3263693837346670673838303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541660800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "22"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "22"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "22"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x733539646f3263693837346670673838303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x6c6272373262716f64356f62336966343030... )", async function( ) {
		const txOriginal = {blockNumber: "6664894", timeStamp: "1541660800", hash: "0x1eb470c950d143be4d3b4b2ec931c62e63f447bb9fadc0ed5cba7d50f79a1730", nonce: "101", blockHash: "0x5f88dc03d7d6dd696642796dcec666cd1bacde2f73350fb31153d2d6a48cd6a6", transactionIndex: "82", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d6c6272373262716f64356f623369663430303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3232022", gasUsed: "390552", confirmations: "1053264"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x6c6272373262716f64356f6233696634303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x6c6272373262716f64356f6233696634303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541660800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "23"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "23"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "23"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x6c6272373262716f64356f6233696634303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x6e69706b6d63626469366964703233353030... )", async function( ) {
		const txOriginal = {blockNumber: "6664894", timeStamp: "1541660800", hash: "0x0dd0b0ba74790643d92f9059431b3121dd8cf401477e444d5d002ab87a00fdf8", nonce: "102", blockHash: "0x5f88dc03d7d6dd696642796dcec666cd1bacde2f73350fb31153d2d6a48cd6a6", transactionIndex: "83", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d6e69706b6d636264693669647032333530303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3623290", gasUsed: "391268", confirmations: "1053264"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x6e69706b6d6362646936696470323335303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x6e69706b6d6362646936696470323335303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541660800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "24"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "24"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "24"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x6e69706b6d6362646936696470323335303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x3663636a396e736f3239733531396e343030... )", async function( ) {
		const txOriginal = {blockNumber: "6664894", timeStamp: "1541660800", hash: "0xf4f03439d65c9c295c9fb921317ab0ea891803a6662de5ca34aebe132442b35a", nonce: "103", blockHash: "0x5f88dc03d7d6dd696642796dcec666cd1bacde2f73350fb31153d2d6a48cd6a6", transactionIndex: "84", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d3663636a396e736f3239733531396e3430303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "4013484", gasUsed: "390194", confirmations: "1053264"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x3663636a396e736f3239733531396e34303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x3663636a396e736f3239733531396e34303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541660800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "25"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "25"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "25"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x3663636a396e736f3239733531396e34303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x376e716f6a6f72366539636e6d666f653030... )", async function( ) {
		const txOriginal = {blockNumber: "6664895", timeStamp: "1541660806", hash: "0x241358c96d0938705d6bfd6fa4ba95b73f91933afaa83dc4395a52f7790ff870", nonce: "104", blockHash: "0x4fc80fee5633cd9696efaa91490a4ce0fe1dd5f3552bfe6e1be295ee25ff43df", transactionIndex: "5", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d376e716f6a6f72366539636e6d666f6530303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "560378", gasUsed: "390910", confirmations: "1053263"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x376e716f6a6f72366539636e6d666f65303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x376e716f6a6f72366539636e6d666f65303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541660806 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "26"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "26"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "26"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x376e716f6a6f72366539636e6d666f65303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x6861716e353767626267726b6265376a3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0xc1e91396e5a74ec68f2c93c75681b86663a415de87d3fe2679186ef9648fd3e6", nonce: "105", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "37", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d6861716e353767626267726b6265376a30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "1185859", gasUsed: "390194", confirmations: "1053261"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x6861716e353767626267726b6265376a303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x6861716e353767626267726b6265376a303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "27"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "27"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "27"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x6861716e353767626267726b6265376a303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x376f6b366a61643266677037716f356d3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0x95e96602d5b5d5f9003dea0d316f4477e058d52b664677f36b637ac7c133b52f", nonce: "106", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "38", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d376f6b366a61643266677037716f356d30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "1576411", gasUsed: "390552", confirmations: "1053261"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x376f6b366a61643266677037716f356d303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x376f6b366a61643266677037716f356d303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "28"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "28"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "28"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x376f6b366a61643266677037716f356d303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x7267373162327039376e3963666235383030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0x0e0c57a366eed9e2bde3f378ac15b8a9edd00f05042259a1a46c78fc35600d76", nonce: "107", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "39", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d7267373162327039376e39636662353830303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "1966247", gasUsed: "389836", confirmations: "1053261"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x7267373162327039376e396366623538303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x7267373162327039376e396366623538303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "29"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "29"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "29"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x7267373162327039376e396366623538303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x31377361626e71616f6c3539653869363030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0x5d77a174c600c2241f48e5d0fdcd8706ae5c6efd9855f3774789dc18301f2ea1", nonce: "108", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "40", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d31377361626e71616f6c35396538693630303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2356799", gasUsed: "390552", confirmations: "1053261"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x31377361626e71616f6c353965386936303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x31377361626e71616f6c353965386936303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "30"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "30"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "30"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x31377361626e71616f6c353965386936303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x7162396f676e366f3937716b676367363030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0xf301b342dcdb334ba2da1b06d4b3b810899daff45c7a0ea036be099bd59eb4ab", nonce: "109", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "41", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d7162396f676e366f3937716b6763673630303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "2746635", gasUsed: "389836", confirmations: "1053261"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x7162396f676e366f3937716b67636736303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x7162396f676e366f3937716b67636736303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "31"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "31"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "31"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x7162396f676e366f3937716b67636736303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x7369633734627166686d6b38643161363030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0x6568c160b8a76208fa52464bd4f1f9c8714de305ca6340ed4b750776ba46b72f", nonce: "110", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "42", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d7369633734627166686d6b386431613630303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3137187", gasUsed: "390552", confirmations: "1053261"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x7369633734627166686d6b3864316136303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x7369633734627166686d6b3864316136303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "32"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "32"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "32"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x7369633734627166686d6b3864316136303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x323562633566736b6e656e6d716268653030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0x239872ab014fb606c1cb0e374738177d38559ad15e66693a932dbaefb0d8f37c", nonce: "111", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "43", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d323562633566736b6e656e6d7162686530303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3528097", gasUsed: "390910", confirmations: "1053261"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x323562633566736b6e656e6d71626865303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x323562633566736b6e656e6d71626865303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "33"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "33"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "33"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x323562633566736b6e656e6d71626865303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x7234313864687063663966676a6a36613030... )", async function( ) {
		const txOriginal = {blockNumber: "6664897", timeStamp: "1541660827", hash: "0x9884be49f2e590a85c06f5771ab1672d19a0883db300770fe873592328d412c6", nonce: "112", blockHash: "0x0938c5577000ebd2727ec587ffbd85232cae2a61e845cdf5822d95a41a59c83e", transactionIndex: "44", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d7234313864687063663966676a6a366130303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3918291", gasUsed: "390194", confirmations: "1053261"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x7234313864687063663966676a6a3661303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x7234313864687063663966676a6a3661303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541660827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "34"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "34"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "34"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x7234313864687063663966676a6a3661303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: createGen0Auction( \"0x3867726d636468673569736837696c6f3030... )", async function( ) {
		const txOriginal = {blockNumber: "6664901", timeStamp: "1541660962", hash: "0x67e96ec84f827896151f72a4625b3d26357f34f4fa005c6eee25f2c1e0462551", nonce: "113", blockHash: "0xed80a4056c845497c967c745d3aa42060fb8bcc3360c0beaa947d5710b0ffd5a", transactionIndex: "52", from: "0x6db88c938599c1a461e975f06cf457e0b68aff9b", to: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a", value: "0", gas: "4300000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xa62e3c9d3867726d636468673569736837696c6f30303030303000000000000000000000", contractAddress: "", cumulativeGasUsed: "3237914", gasUsed: "390552", confirmations: "1053257"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes22", name: "_genes", value: "0x3867726d636468673569736837696c6f303030303030"}], name: "createGen0Auction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createGen0Auction(bytes22)" ]( "0x3867726d636468673569736837696c6f303030303030", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541660962 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "tokenId", type: "uint256", value: "35"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "to", type: "address", value: "0x7c77ed12c05069981840d5277801199aa0d12b78"}, {name: "tokenId", type: "uint256", value: "35"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ponyId", type: "uint256"}, {indexed: false, name: "matronId", type: "uint256"}, {indexed: false, name: "sireId", type: "uint256"}, {indexed: false, name: "genes", type: "bytes22"}], name: "Birth", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Birth", events: [{name: "owner", type: "address", value: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}, {name: "ponyId", type: "uint256", value: "35"}, {name: "matronId", type: "uint256", value: "0"}, {name: "sireId", type: "uint256", value: "0"}, {name: "genes", type: "bytes22", value: "0x3867726d636468673569736837696c6f303030303030"}], address: "0xaec5cf7fa497c2b27a6f37ee0c817c619b42c03a"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1748204582856442550" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
