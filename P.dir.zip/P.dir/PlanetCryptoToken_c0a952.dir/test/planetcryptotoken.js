const PlanetCryptoToken = artifacts.require( "./PlanetCryptoToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PlanetCryptoToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8C55B18e6bb7083b29102e57c34d0C3124c0a952", "0xA1c8031EF18272d8BfeD22E1b61319D6d9d2881B", "0x19BfDF25542F1380790B6880ad85D6D5B02fee32", "0x65a64D2bCe8f731D51f2Ae0d58B592e7413530f5", "0xbB146f7191AC6bA2710B973C080B07bC0B835A83", "0x0b1B00DF926eD6317A5604c4dF0134507D0324E5", "0xA4e7918fb5F4a8c12f9513b193bE1d764d5757Dc", "0xefc538603b0A2727A9f372db039781c538944ab9", "0x0D4a5Cb5e775c1c81f4111BF19080dD70F987b14", "0x1a8c8ed1BA3057E874bEfd3612Aa10c7CD55c048", "0xa150DDEd73e8B27450e3162EE20392FCD8E8D2D2", "0x377E0eA89D83f3a726e149c25dAb34b2CAA75A83", "0xC6EcfA8b3BB5DEBDa7B88E40B2258AEF21d806ED", "0x7bC54Cc2FE6E26eb8Fa309965e1Be8D840b74cC6", "0xC7250265574F2D9f9BabE946d8205a288537Fb5B", "0x9A7F3277FAE3c10Cb1eEDEC0bC2d6606610C3f12", "0xe9aa7C522de5dBe1b784b285C38F282BD247Ee30", "0x32Db8AfFE842c970BaE811646821c35113F9f0f6", "0xe77164cD465E196fF5067C242B4472AD709eF1D7", "0x6502aCF292EC0b8bdF60D2F56D70CC4BbE8d7fF6", "0x69594e133979F1B991617EE032C186fF7932F581", "0x50F79c59D69F48a8a14E23Ee6506d1cBa94cABff", "0x1f8389D4Cb85A546B1777b90BB16B5b7047F18bA", "0x21676E2Ea4C07FCD4E09Ae599995a7694Edaab21", "0x36726eF314B5E583AbD9Cb8F3Df762c417095A62", "0x52C6a548D4561d98ad299ABA1229E5cd38cB2b34", "0x447eC0dC651FB5B1EE9DBa8782b11F3C36dA9Eb8", "0x20ce3d4fb8796133D0CaBa388f6187589CACb302", "0xc403986C0a45d9eC1c2Ef4379f4947a75B41F593", "0xF805e3A356AEfF4E89D0E0f47B9aa1E168227c08", "0x00e65F38e96D12b543B07D37e1B61122669033d8", "0xDf4b89549d8757D7f8731A4A20F2A62b927D8E30", "0x3156eD3D443Ac912Ca4cB0b6B2d59ce594A72F21", "0x68b924184A97D81E786971056926689a4666aA19"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "min_plots_purchase_for_token_reward", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokens_rewards_available", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "interfaceId", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "zoom", type: "uint8"}, {name: "lat_rows", type: "int256[]"}, {name: "lng_columns", type: "int256[]"}], name: "queryPlotExists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "getApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getAllPlayerObjectLen", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "price_update_amount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "all_playerObjects", outputs: [{name: "playerAddress", type: "address"}, {name: "lastAccess", type: "uint256"}, {name: "totalEmpireScore", type: "uint256"}, {name: "totalLand", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}, {name: "index", type: "uint256"}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "current_plot_price", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokens_rewards_allocated", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "taxEarningsAvailable", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "zoom", type: "uint8"}, {name: "lat_rows", type: "int256[]"}, {name: "lng_columns", type: "int256[]"}], name: "queryMap", outputs: [{name: "_outStr", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "total_empire_score", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "total_land_sold", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "total_trades", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "tokenURI", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "current_plot_empire_score", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}, {name: "isBasic", type: "bool"}], name: "getToken", outputs: [{name: "token_owner", type: "address"}, {name: "name", type: "bytes32"}, {name: "orig_value", type: "uint256"}, {name: "current_value", type: "uint256"}, {name: "empire_score", type: "uint256"}, {name: "plots_lat", type: "int256[]"}, {name: "plots_lng", type: "int256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tax_distributed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "devHoldings", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tax_fund", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}, {name: "operator", type: "address"}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "plots_token_reward_divisor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "search_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "referralPaid", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "searched_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "issueCoinTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_from", type: "address"}, {indexed: true, name: "search_to", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "from", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "orig_value", type: "uint256"}, {indexed: false, name: "new_value", type: "uint256"}, {indexed: false, name: "empireScore", type: "uint256"}, {indexed: false, name: "newEmpireScore", type: "uint256"}, {indexed: false, name: "now", type: "uint256"}], name: "cardBought", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "approved", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "operator", type: "address"}, {indexed: false, name: "approved", type: "bool"}], name: "ApprovalForAll", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["referralPaid(address,address,uint256,uint256)", "issueCoinTokens(address,address,uint256,uint256)", "landPurchased(uint256,address,uint256,address,bytes32,int256,int256,uint256,uint256,uint256,uint256)", "taxDistributed(uint256,uint256,uint256)", "cardBought(uint256,address,address,uint256,address,address,bytes32,uint256,uint256,uint256,uint256,uint256)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "ApprovalForAll(address,address,bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x500a1821a82e1e9951feb0c4eb0043d6f9d97be1a522ffa083f6a91b7b5c013d", "0x4b4baca05c77f3008ba9b998920e58005aeb17a94101186b0a80f564075c043e", "0x807689f8da61b73f683c57d12d78610d2e69edfaa2feac878373d92ba25e2730", "0x5fe10e72bed621bd9aa98489cd68e8ee3f0446c3472cea71de9c6c105c089f8f", "0xca6cef801d696b99880261abca3984a0cf932a69993676ef85130e9ce94e94da", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6714797 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6746063 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "PlanetCryptoToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "min_plots_purchase_for_token_reward", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "min_plots_purchase_for_token_reward()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokens_rewards_available", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokens_rewards_available()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes4", name: "interfaceId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint8", name: "zoom", value: random.range( maxRandom )}, {type: "int256[]", name: "lat_rows", value: [random.intBetween( -maxRandom, maxRandom )]}, {type: "int256[]", name: "lng_columns", value: [random.intBetween( -maxRandom, maxRandom )]}], name: "queryPlotExists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "queryPlotExists(uint8,int256[],int256[])" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "getApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getAllPlayerObjectLen", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAllPlayerObjectLen()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "price_update_amount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "price_update_amount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "all_playerObjects", outputs: [{name: "playerAddress", type: "address"}, {name: "lastAccess", type: "uint256"}, {name: "totalEmpireScore", type: "uint256"}, {name: "totalLand", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "all_playerObjects(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "index", value: random.range( maxRandom )}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenOfOwnerByIndex(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "current_plot_price", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "current_plot_price()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokens_rewards_allocated", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokens_rewards_allocated()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "taxEarningsAvailable", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "taxEarningsAvailable()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint8", name: "zoom", value: random.range( maxRandom )}, {type: "int256[]", name: "lat_rows", value: [random.intBetween( -maxRandom, maxRandom )]}, {type: "int256[]", name: "lng_columns", value: [random.intBetween( -maxRandom, maxRandom )]}], name: "queryMap", outputs: [{name: "_outStr", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "queryMap(uint8,int256[],int256[])" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "total_empire_score", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "total_empire_score()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "total_land_sold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "total_land_sold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "total_trades", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "total_trades()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "tokenURI", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenURI(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "current_plot_empire_score", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "current_plot_empire_score()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}, {type: "bool", name: "isBasic", value: ( random.range( 2 ) === 0 )}], name: "getToken", outputs: [{name: "token_owner", type: "address"}, {name: "name", type: "bytes32"}, {name: "orig_value", type: "uint256"}, {name: "current_value", type: "uint256"}, {name: "empire_score", type: "uint256"}, {name: "plots_lat", type: "int256[]"}, {name: "plots_lng", type: "int256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getToken(uint256,bool)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tax_distributed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tax_distributed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "devHoldings", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "devHoldings()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tax_fund", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tax_fund()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApprovedForAll(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "plots_token_reward_divisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plots_token_reward_divisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PlanetCryptoToken", function( accounts ) {

	it( "TEST: PlanetCryptoToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6714797", timeStamp: "1542365947", hash: "0x62743969cef1364d948337a8b4b5c9b577fa0d9d986467c8f6c11537ea01fc84", nonce: "13", blockHash: "0xba044a0915dc10f946f576363f6bec07ab8c462b34a88ca8c363585eb9054331", transactionIndex: "11", from: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5", to: 0, value: "0", gas: "7335635", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x3137a357", contractAddress: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", cumulativeGasUsed: "7681421", gasUsed: "7335635", confirmations: "995042"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "PlanetCryptoToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PlanetCryptoToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542365947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PlanetCryptoToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "86040000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: p_update_tokensRewardsAvailable( \"100000\" )", async function( ) {
		const txOriginal = {blockNumber: "6714811", timeStamp: "1542366190", hash: "0xf14d73f28a0e689415d18a867a152e78caf4dcdf5834f280d5d9a5f6a6358bd8", nonce: "16", blockHash: "0xac283a87836cc70aaa7e874a1a0533a42e7507a1b0ebf16defa3160f0d8964e4", transactionIndex: "149", from: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "42399", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x28ab737500000000000000000000000000000000000000000000000000000000000186a0", contractAddress: "", cumulativeGasUsed: "7767846", gasUsed: "42399", confirmations: "995028"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokens_rewards_available", value: "100000"}], name: "p_update_tokensRewardsAvailable", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "p_update_tokensRewardsAvailable(uint256)" ]( "100000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542366190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "86040000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buyLandWithTokens( \"0x537461747565206f66204c69626572747900... )", async function( ) {
		const txOriginal = {blockNumber: "6714869", timeStamp: "1542366970", hash: "0x61f8c4dda12bb217c6a5591f2646e2b7058e21974fa65347d54aa793a40e884c", nonce: "18", blockHash: "0xfb60058165d2e2dc011a38370e31cebd970d3bf9ddf593d6c0c4586f7cca3059", transactionIndex: "62", from: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "3485518", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x0d4ea316537461747565206f66204c69626572747900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000026cde6200000000000000000000000000000000000000000000000000000000026cde6200000000000000000000000000000000000000000000000000000000026cddae00000000000000000000000000000000000000000000000000000000026cddae00000000000000000000000000000000000000000000000000000000026cdf1600000000000000000000000000000000000000000000000000000000026cdf1600000000000000000000000000000000000000000000000000000000026cde6200000000000000000000000000000000000000000000000000000000026cddae00000000000000000000000000000000000000000000000000000000026cdf1600000000000000000000000000000000000000000000000000000000026cdf1600000000000000000000000000000000000000000000000000000000026cde6200000000000000000000000000000000000000000000000000000000026cddae00000000000000000000000000000000000000000000000000000000026cdcfa00000000000000000000000000000000000000000000000000000000026cdcfa00000000000000000000000000000000000000000000000000000000026cdcfa00000000000000000000000000000000000000000000000000000000026cdcfa00000000000000000000000000000000000000000000000000000000026cdfca00000000000000000000000000000000000000000000000000000000026cdfca00000000000000000000000000000000000000000000000000000000026cdfca00000000000000000000000000000000000000000000000000000000026cdfca0000000000000000000000000000000000000000000000000000000000000014fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962af8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962be8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962be8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962af8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962af8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962be8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962cd8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962cd8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962cd8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962a12fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962a12fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962a12fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962a12fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962af8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962be8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962cd8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962a12fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962af8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962be8fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb962cd8", contractAddress: "", cumulativeGasUsed: "6813579", gasUsed: "3485518", confirmations: "994970"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x537461747565206f66204c696265727479000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["40689250","40689250","40689070","40689070","40689430","40689430","40689250","40689070","40689430","40689430","40689250","40689070","40688890","40688890","40688890","40688890","40689610","40689610","40689610","40689610"]}, {type: "int256[]", name: "_plots_lng", value: ["-74044680","-74044440","-74044440","-74044680","-74044680","-74044440","-74044200","-74044200","-74044200","-74044910","-74044910","-74044910","-74044910","-74044680","-74044440","-74044200","-74044910","-74044680","-74044440","-74044200"]}], name: "buyLandWithTokens", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLandWithTokens(bytes32,int256[],int256[])" ]( "0x537461747565206f66204c696265727479000000000000000000000000000000", ["40689250","40689250","40689070","40689070","40689430","40689430","40689250","40689070","40689430","40689430","40689250","40689070","40688890","40688890","40688890","40688890","40689610","40689610","40689610","40689610"], ["-74044680","-74044440","-74044440","-74044680","-74044680","-74044440","-74044200","-74044200","-74044200","-74044910","-74044910","-74044910","-74044910","-74044680","-74044440","-74044200","-74044910","-74044680","-74044440","-74044200"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542366970 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "1"}, {name: "search_buyer", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "token_id", type: "uint256", value: "1"}, {name: "buyer", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "name", type: "bytes32", value: "0x537461747565206f66204c696265727479000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [40689250]}}, {name: "center_lng", type: "int256", value: {s: -1, e: 7, c: [74044680]}}, {name: "size", type: "uint256", value: "20"}, {name: "bought_at", type: "uint256", value: "20000000000000000"}, {name: "empire_score", type: "uint256", value: "2000"}, {name: "timestamp", type: "uint256", value: "1542366970"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "tokenId", type: "uint256", value: "1"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[2,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "86040000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buyLandWithTokens( \"0x53696e67656c203534320000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6715311", timeStamp: "1542372920", hash: "0xf1811ed5d505ff19b4c21aca46bc57ca641b8d71e8e28d1bcc19311ac9b06861", nonce: "20", blockHash: "0x9be3553225daebd1dd68972a08697464c21f49667887bedde25d6a1c70a1f1fc", transactionIndex: "45", from: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "1924403", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0d4ea31653696e67656c2035343200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000001a0000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000031f0cf400000000000000000000000000000000000000000000000000000000031f0da800000000000000000000000000000000000000000000000000000000031f0da800000000000000000000000000000000000000000000000000000000031f0cf400000000000000000000000000000000000000000000000000000000031f0cf400000000000000000000000000000000000000000000000000000000031f0da800000000000000000000000000000000000000000000000000000000031f0c4000000000000000000000000000000000000000000000000000000000031f0c4000000000000000000000000000000000000000000000000000000000031f0c40000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000004aa6b400000000000000000000000000000000000000000000000000000000004aa6b400000000000000000000000000000000000000000000000000000000004aa58800000000000000000000000000000000000000000000000000000000004aa58800000000000000000000000000000000000000000000000000000000004aa7d600000000000000000000000000000000000000000000000000000000004aa7d600000000000000000000000000000000000000000000000000000000004aa7d600000000000000000000000000000000000000000000000000000000004aa6b400000000000000000000000000000000000000000000000000000000004aa588", contractAddress: "", cumulativeGasUsed: "4631418", gasUsed: "1924403", confirmations: "994528"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x53696e67656c2035343200000000000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["52366580","52366760","52366760","52366580","52366580","52366760","52366400","52366400","52366400"]}, {type: "int256[]", name: "_plots_lng", value: ["4892340","4892340","4892040","4892040","4892630","4892630","4892630","4892340","4892040"]}], name: "buyLandWithTokens", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLandWithTokens(bytes32,int256[],int256[])" ]( "0x53696e67656c2035343200000000000000000000000000000000000000000000", ["52366580","52366760","52366760","52366580","52366580","52366760","52366400","52366400","52366400"], ["4892340","4892340","4892040","4892040","4892630","4892630","4892630","4892340","4892040"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542372920 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "2"}, {name: "search_buyer", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "token_id", type: "uint256", value: "2"}, {name: "buyer", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "name", type: "bytes32", value: "0x53696e67656c2035343200000000000000000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [52366580]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 6, c: [4892340]}}, {name: "size", type: "uint256", value: "9"}, {name: "bought_at", type: "uint256", value: "20040000000000000"}, {name: "empire_score", type: "uint256", value: "900"}, {name: "timestamp", type: "uint256", value: "1542372920"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "tokenId", type: "uint256", value: "2"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "86040000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyLandWithTokens( \"0x353438204d61726b65742053742c2053616e... )", async function( ) {
		const txOriginal = {blockNumber: "6715319", timeStamp: "1542373016", hash: "0x0e9b7ae10fc0bbbf3f8a832bce71f49461a38a58ccaaa73dd8249f00904fa47c", nonce: "21", blockHash: "0x1f162edf5afd02f1a236d8b3e9a3b57a536e095c7b59940f044ea7deba940f16", transactionIndex: "57", from: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "2955823", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0d4ea316353438204d61726b65742053742c2053616e204672616e000000000000000000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000002a00000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000240915e000000000000000000000000000000000000000000000000000000000240915e000000000000000000000000000000000000000000000000000000000240921200000000000000000000000000000000000000000000000000000000024092c6000000000000000000000000000000000000000000000000000000000240937a000000000000000000000000000000000000000000000000000000000240937a000000000000000000000000000000000000000000000000000000000240921200000000000000000000000000000000000000000000000000000000024092c6000000000000000000000000000000000000000000000000000000000240921200000000000000000000000000000000000000000000000000000000024092c6000000000000000000000000000000000000000000000000000000000240937a000000000000000000000000000000000000000000000000000000000240937a000000000000000000000000000000000000000000000000000000000240942e000000000000000000000000000000000000000000000000000000000240942e000000000000000000000000000000000000000000000000000000000240942e000000000000000000000000000000000000000000000000000000000240942e000000000000000000000000000000000000000000000000000000000240942e0000000000000000000000000000000000000000000000000000000000000011fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43bd6fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43af0fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43af0fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43af0fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43af0fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43bd6fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43bd6fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43bd6fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43cb2fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43cb2fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43cb2fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43d98fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43e7efffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43d98fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43bd6fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43af0fffffffffffffffffffffffffffffffffffffffffffffffffffffffff8b43cb2", contractAddress: "", cumulativeGasUsed: "7988897", gasUsed: "2955823", confirmations: "994520"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x353438204d61726b65742053742c2053616e204672616e000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["37785950","37785950","37786130","37786310","37786490","37786490","37786130","37786310","37786130","37786310","37786490","37786490","37786670","37786670","37786670","37786670","37786670"]}, {type: "int256[]", name: "_plots_lng", value: ["-122405930","-122406160","-122406160","-122406160","-122406160","-122405930","-122405930","-122405930","-122405710","-122405710","-122405710","-122405480","-122405250","-122405480","-122405930","-122406160","-122405710"]}], name: "buyLandWithTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLandWithTokens(bytes32,int256[],int256[])" ]( "0x353438204d61726b65742053742c2053616e204672616e000000000000000000", ["37785950","37785950","37786130","37786310","37786490","37786490","37786130","37786310","37786130","37786310","37786490","37786490","37786670","37786670","37786670","37786670","37786670"], ["-122405930","-122406160","-122406160","-122406160","-122406160","-122405930","-122405930","-122405930","-122405710","-122405710","-122405710","-122405480","-122405250","-122405480","-122405930","-122406160","-122405710"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542373016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "3"}, {name: "search_buyer", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "token_id", type: "uint256", value: "3"}, {name: "buyer", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "name", type: "bytes32", value: "0x353438204d61726b65742053742c2053616e204672616e000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [37785950]}}, {name: "center_lng", type: "int256", value: {s: -1, e: 8, c: [122405930]}}, {name: "size", type: "uint256", value: "17"}, {name: "bought_at", type: "uint256", value: "20058000000000000"}, {name: "empire_score", type: "uint256", value: "1700"}, {name: "timestamp", type: "uint256", value: "1542373016"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x65a64d2bce8f731d51f2ae0d58b592e7413530f5"}, {name: "tokenId", type: "uint256", value: "3"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[4,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "86040000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x57616c74204469736e657920537461747565... )", async function( ) {
		const txOriginal = {blockNumber: "6715929", timeStamp: "1542381906", hash: "0x52e2eeecc9cb6564e3eba0171aa2b96d0aca479ea83b5d9cc6fd07e0763dc330", nonce: "498", blockHash: "0xc90cdff9b35962ce7432a40ca45243824c7ef91c762144a2e9cd98efb0f97f93", transactionIndex: "124", from: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "20092000000000000", gas: "1233588", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef57616c74204469736e6579205374617475650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000001b1a26e0000000000000000000000000000000000000000000000000000000000000001fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb232ba2", contractAddress: "", cumulativeGasUsed: "7879063", gasUsed: "1233588", confirmations: "993910"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "20092000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x57616c74204469736e6579205374617475650000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["28418670"]}, {type: "int256[]", name: "_plots_lng", value: ["-81581150"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x57616c74204469736e6579205374617475650000000000000000000000000000", ["28418670"], ["-81581150"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542381906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "4"}, {name: "search_buyer", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "token_id", type: "uint256", value: "4"}, {name: "buyer", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "name", type: "bytes32", value: "0x57616c74204469736e6579205374617475650000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [28418670]}}, {name: "center_lng", type: "int256", value: {s: -1, e: 7, c: [81581150]}}, {name: "size", type: "uint256", value: "1"}, {name: "bought_at", type: "uint256", value: "20092000000000000"}, {name: "empire_score", type: "uint256", value: "100"}, {name: "timestamp", type: "uint256", value: "1542381906"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "5022999497700000"}, {name: "total_players", type: "uint256", value: "2"}, {name: "timestamp", type: "uint256", value: "1542381906"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "tokenId", type: "uint256", value: "4"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1272151275427472632" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x536f75746865726e6d6f737420506f696e74... )", async function( ) {
		const txOriginal = {blockNumber: "6716074", timeStamp: "1542383922", hash: "0x0be241fc031373bdd4215fba220554e5dafefc505311399b03f9e6474492dc0d", nonce: "499", blockHash: "0x3b374b5b8d89827548a93358d9a07f40a4cef0253be5a07dffe900d83a3a329f", transactionIndex: "111", from: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "20094000000000000", gas: "1058443", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef536f75746865726e6d6f737420506f696e74206f662074686520555300000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000001768cba0000000000000000000000000000000000000000000000000000000000000001fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb1fdeac", contractAddress: "", cumulativeGasUsed: "7795702", gasUsed: "1058443", confirmations: "993765"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "20094000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x536f75746865726e6d6f737420506f696e74206f662074686520555300000000"}, {type: "int256[]", name: "_plots_lat", value: ["24546490"]}, {type: "int256[]", name: "_plots_lng", value: ["-81797460"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x536f75746865726e6d6f737420506f696e74206f662074686520555300000000", ["24546490"], ["-81797460"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1542383922 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "5"}, {name: "search_buyer", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "token_id", type: "uint256", value: "5"}, {name: "buyer", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "name", type: "bytes32", value: "0x536f75746865726e6d6f737420506f696e74206f662074686520555300000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [24546490]}}, {name: "center_lng", type: "int256", value: {s: -1, e: 7, c: [81797460]}}, {name: "size", type: "uint256", value: "1"}, {name: "bought_at", type: "uint256", value: "20094000000000000"}, {name: "empire_score", type: "uint256", value: "100"}, {name: "timestamp", type: "uint256", value: "1542383922"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "5023499497650000"}, {name: "total_players", type: "uint256", value: "2"}, {name: "timestamp", type: "uint256", value: "1542383922"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "tokenId", type: "uint256", value: "5"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1272151275427472632" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x4d616b6520416d6572696361204772656174... )", async function( ) {
		const txOriginal = {blockNumber: "6716889", timeStamp: "1542395808", hash: "0x4451fbebc9054d7915b051cc6afd473119afb53af68981444d26e1b960c258ed", nonce: "104", blockHash: "0x9bbba0e2583fe79dea71a04b9f5637571868e23c55e6095fe2a771530a4c1e4c", transactionIndex: "39", from: "0x0b1b00df926ed6317a5604c4df0134507d0324e5", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "20096000000000000", gas: "1213142", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef4d616b6520416d657269636120477265617420416761696e2100000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000bb146f7191ac6ba2710b973c080b07bc0b835a83000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000025186d00000000000000000000000000000000000000000000000000000000000000001fffffffffffffffffffffffffffffffffffffffffffffffffffffffffb6880d0", contractAddress: "", cumulativeGasUsed: "2891307", gasUsed: "1213142", confirmations: "992950"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "20096000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x4d616b6520416d657269636120477265617420416761696e2100000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["38897360"]}, {type: "int256[]", name: "_plots_lng", value: ["-77037360"]}, {type: "address", name: "_referrer", value: addressList[6]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x4d616b6520416d657269636120477265617420416761696e2100000000000000", ["38897360"], ["-77037360"], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542395808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "referralPaid", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "referralPaid", events: [{name: "search_to", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "to", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "amnt", type: "uint256", value: "1004800000000000"}, {name: "timestamp", type: "uint256", value: "1542395808"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "6"}, {name: "search_buyer", type: "address", value: "0x0b1b00df926ed6317a5604c4df0134507d0324e5"}, {name: "token_id", type: "uint256", value: "6"}, {name: "buyer", type: "address", value: "0x0b1b00df926ed6317a5604c4df0134507d0324e5"}, {name: "name", type: "bytes32", value: "0x4d616b6520416d657269636120477265617420416761696e2100000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [38897360]}}, {name: "center_lng", type: "int256", value: {s: -1, e: 7, c: [77037360]}}, {name: "size", type: "uint256", value: "1"}, {name: "bought_at", type: "uint256", value: "20096000000000000"}, {name: "empire_score", type: "uint256", value: "100"}, {name: "timestamp", type: "uint256", value: "1542395808"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "4772799522720000"}, {name: "total_players", type: "uint256", value: "3"}, {name: "timestamp", type: "uint256", value: "1542395808"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0b1b00df926ed6317a5604c4df0134507d0324e5"}, {name: "tokenId", type: "uint256", value: "6"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "861717558394970924" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x53616e6472696e6768616d20486f75736500... )", async function( ) {
		const txOriginal = {blockNumber: "6718016", timeStamp: "1542411644", hash: "0xffc7e224dc317c6e32c2ed120e962a2cfb63c318ed9e2a0cd989b158ce7b1fe6", nonce: "655", blockHash: "0xd390840d1957dd5dfd1df3a48946c557e42b47c868fd6ad4826de0cef05400d8", transactionIndex: "48", from: "0xa4e7918fb5f4a8c12f9513b193be1d764d5757dc", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "20098000000000000", gas: "1205719", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef53616e6472696e6768616d20486f757365000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000bb146f7191ac6ba2710b973c080b07bc0b835a8300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000003261cd80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000007ddca", contractAddress: "", cumulativeGasUsed: "3980141", gasUsed: "1205719", confirmations: "991823"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "20098000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x53616e6472696e6768616d20486f757365000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["52829400"]}, {type: "int256[]", name: "_plots_lng", value: ["515530"]}, {type: "address", name: "_referrer", value: addressList[6]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x53616e6472696e6768616d20486f757365000000000000000000000000000000", ["52829400"], ["515530"], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542411644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "referralPaid", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "referralPaid", events: [{name: "search_to", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "to", type: "address", value: "0xbb146f7191ac6ba2710b973c080b07bc0b835a83"}, {name: "amnt", type: "uint256", value: "1004900000000000"}, {name: "timestamp", type: "uint256", value: "1542411644"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "7"}, {name: "search_buyer", type: "address", value: "0xa4e7918fb5f4a8c12f9513b193be1d764d5757dc"}, {name: "token_id", type: "uint256", value: "7"}, {name: "buyer", type: "address", value: "0xa4e7918fb5f4a8c12f9513b193be1d764d5757dc"}, {name: "name", type: "bytes32", value: "0x53616e6472696e6768616d20486f757365000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [52829400]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 5, c: [515530]}}, {name: "size", type: "uint256", value: "1"}, {name: "bought_at", type: "uint256", value: "20098000000000000"}, {name: "empire_score", type: "uint256", value: "100"}, {name: "timestamp", type: "uint256", value: "1542411644"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "4773275000000000"}, {name: "total_players", type: "uint256", value: "4"}, {name: "timestamp", type: "uint256", value: "1542411644"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa4e7918fb5f4a8c12f9513b193be1d764d5757dc"}, {name: "tokenId", type: "uint256", value: "7"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "586414383653971865" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x4272616e64656e62757267657220546f7200... )", async function( ) {
		const txOriginal = {blockNumber: "6732552", timeStamp: "1542617217", hash: "0x9d54b1a6f9165a54a6e02936997f1c0cf6817e0de739c49cd4c0739a888a0146", nonce: "55", blockHash: "0x82a9b78ff9ce0d1cc2ddf8d814a00cdd51aa7b5f6c60b8c92694a725bd4c73af", transactionIndex: "86", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "361800000000000000", gas: "3298129", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef4272616e64656e62757267657220546f72000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000002e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000003215680000000000000000000000000000000000000000000000000000000000321568000000000000000000000000000000000000000000000000000000000032155cc000000000000000000000000000000000000000000000000000000000321551800000000000000000000000000000000000000000000000000000000032154640000000000000000000000000000000000000000000000000000000003215464000000000000000000000000000000000000000000000000000000000321551800000000000000000000000000000000000000000000000000000000032155cc000000000000000000000000000000000000000000000000000000000321573400000000000000000000000000000000000000000000000000000000032157340000000000000000000000000000000000000000000000000000000003215734000000000000000000000000000000000000000000000000000000000321568000000000000000000000000000000000000000000000000000000000032155cc0000000000000000000000000000000000000000000000000000000003215518000000000000000000000000000000000000000000000000000000000321546400000000000000000000000000000000000000000000000000000000032153b000000000000000000000000000000000000000000000000000000000032153b000000000000000000000000000000000000000000000000000000000032153b000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc1fdc", contractAddress: "", cumulativeGasUsed: "6985257", gasUsed: "3298129", confirmations: "977287"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "361800000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x4272616e64656e62757267657220546f72000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["52516480","52516480","52516300","52516120","52515940","52515940","52516120","52516300","52516660","52516660","52516660","52516480","52516300","52516120","52515940","52515760","52515760","52515760"]}, {type: "int256[]", name: "_plots_lng", value: ["13377500","13377800","13377800","13377800","13377800","13377500","13377500","13377500","13377500","13377800","13378090","13378090","13378090","13378090","13378090","13378090","13377800","13377500"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x4272616e64656e62757267657220546f72000000000000000000000000000000", ["52516480","52516480","52516300","52516120","52515940","52515940","52516120","52516300","52516660","52516660","52516660","52516480","52516300","52516120","52515940","52515760","52515760","52515760"], ["13377500","13377800","13377800","13377800","13377800","13377500","13377500","13377500","13377500","13377800","13378090","13378090","13378090","13378090","13378090","13378090","13377800","13377500"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542617217 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "searched_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "issueCoinTokens", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "issueCoinTokens", events: [{name: "searched_to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "amnt", type: "uint256", value: "1"}, {name: "timestamp", type: "uint256", value: "1542617217"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "8"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "8"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x4272616e64656e62757267657220546f72000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [52516480]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 7, c: [13377500]}}, {name: "size", type: "uint256", value: "18"}, {name: "bought_at", type: "uint256", value: "20100000000000000"}, {name: "empire_score", type: "uint256", value: "1800"}, {name: "timestamp", type: "uint256", value: "1542617217"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "90449963820000000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542617217"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "8"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x4272616e64656e62757267657220546f7200... )", async function( ) {
		const txOriginal = {blockNumber: "6732599", timeStamp: "1542617823", hash: "0xb9f75fc54cce63d6bd44da5f90fba9e5037dbe11673fdadfec5d62bfdbc07de4", nonce: "56", blockHash: "0x29859316515062fe550cff2e4aa8118fb9b68ec6e901d527f03c1ce9ebb9e2a2", transactionIndex: "84", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "361800000000000000", gas: "3298129", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xdc00adef4272616e64656e62757267657220546f72000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000002e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000003215680000000000000000000000000000000000000000000000000000000000321568000000000000000000000000000000000000000000000000000000000032155cc000000000000000000000000000000000000000000000000000000000321551800000000000000000000000000000000000000000000000000000000032154640000000000000000000000000000000000000000000000000000000003215464000000000000000000000000000000000000000000000000000000000321551800000000000000000000000000000000000000000000000000000000032155cc000000000000000000000000000000000000000000000000000000000321573400000000000000000000000000000000000000000000000000000000032157340000000000000000000000000000000000000000000000000000000003215734000000000000000000000000000000000000000000000000000000000321568000000000000000000000000000000000000000000000000000000000032155cc0000000000000000000000000000000000000000000000000000000003215518000000000000000000000000000000000000000000000000000000000321546400000000000000000000000000000000000000000000000000000000032153b000000000000000000000000000000000000000000000000000000000032153b000000000000000000000000000000000000000000000000000000000032153b000000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc1fdc0000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc222a0000000000000000000000000000000000000000000000000000000000cc21080000000000000000000000000000000000000000000000000000000000cc1fdc", contractAddress: "", cumulativeGasUsed: "2972160", gasUsed: "47044", confirmations: "977240"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "361800000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x4272616e64656e62757267657220546f72000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["52516480","52516480","52516300","52516120","52515940","52515940","52516120","52516300","52516660","52516660","52516660","52516480","52516300","52516120","52515940","52515760","52515760","52515760"]}, {type: "int256[]", name: "_plots_lng", value: ["13377500","13377800","13377800","13377800","13377800","13377500","13377500","13377500","13377500","13377800","13378090","13378090","13378090","13378090","13378090","13378090","13377800","13377500"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x4272616e64656e62757267657220546f72000000000000000000000000000000", ["52516480","52516480","52516300","52516120","52515940","52515940","52516120","52516300","52516660","52516660","52516660","52516480","52516300","52516120","52515940","52515760","52515760","52515760"], ["13377500","13377800","13377800","13377800","13377800","13377500","13377500","13377500","13377500","13377800","13378090","13378090","13378090","13378090","13378090","13378090","13377800","13377500"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1542617823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x53696567657373e4756c6500000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732607", timeStamp: "1542617876", hash: "0xb3b444c279c88a0d94e49af1efa3e3baee54ba6c55384064cdd6528ce09b2466", nonce: "57", blockHash: "0xa97f45d18492648ec91eadd225dd009581e7f6cc56dd6f0ba3d53819633cd2ef", transactionIndex: "67", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "80400000000000000", gas: "1554721", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xdc00adef53696567657373e4756c6500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000003214f140000000000000000000000000000000000000000000000000000000003214f140000000000000000000000000000000000000000000000000000000003214e6a0000000000000000000000000000000000000000000000000000000003214e6a00000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000cbb4480000000000000000000000000000000000000000000000000000000000cbb56a0000000000000000000000000000000000000000000000000000000000cbb56a0000000000000000000000000000000000000000000000000000000000cbb448", contractAddress: "", cumulativeGasUsed: "3467237", gasUsed: "34492", confirmations: "977232"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "80400000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x53696567657373e4756c65000000000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["52514580","52514580","52514410","52514410"]}, {type: "int256[]", name: "_plots_lng", value: ["13349960","13350250","13350250","13349960"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x53696567657373e4756c65000000000000000000000000000000000000000000", ["52514580","52514580","52514410","52514410"], ["13349960","13350250","13350250","13349960"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1542617876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x4665726e7365687475726d00000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732611", timeStamp: "1542617907", hash: "0xa9bea415d34bd4a443fece334f5884e8a1614afbcd15c7c28b7c14c1e46b0b19", nonce: "58", blockHash: "0x9794aaeb02b84cbf03e3d772348a365d71c1116be50e1ae864e09d4b33bcf3d4", transactionIndex: "25", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "40200000000000000", gas: "1324223", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xdc00adef4665726e7365687475726d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000002e7f4080000000000000000000000000000000000000000000000000000000002e7f408000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000008c3a9800000000000000000000000000000000000000000000000000000000008c3ba6", contractAddress: "", cumulativeGasUsed: "6341166", gasUsed: "32691", confirmations: "977228"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "40200000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x4665726e7365687475726d000000000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["48755720","48755720"]}, {type: "int256[]", name: "_plots_lng", value: ["9190040","9190310"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x4665726e7365687475726d000000000000000000000000000000000000000000", ["48755720","48755720"], ["9190040","9190310"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542617907 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x546f75722045696666656c00000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732622", timeStamp: "1542618078", hash: "0x8b6827ad2a6986b92cc5caef2101ec44dba89e192e117d849a45a8535c33e87f", nonce: "59", blockHash: "0xc08c04c997646130a2f0a4cdd5f465e8eba360990f436bf65c38e31106cd9cb9", transactionIndex: "108", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "422856000000000000", gas: "3519166", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef546f75722045696666656c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000002e984760000000000000000000000000000000000000000000000000000000002e9830e0000000000000000000000000000000000000000000000000000000002e9830e0000000000000000000000000000000000000000000000000000000002e9830e0000000000000000000000000000000000000000000000000000000002e983c20000000000000000000000000000000000000000000000000000000002e984760000000000000000000000000000000000000000000000000000000002e9852a0000000000000000000000000000000000000000000000000000000002e985de0000000000000000000000000000000000000000000000000000000002e985de0000000000000000000000000000000000000000000000000000000002e985de0000000000000000000000000000000000000000000000000000000002e9852a0000000000000000000000000000000000000000000000000000000002e9852a0000000000000000000000000000000000000000000000000000000002e9852a0000000000000000000000000000000000000000000000000000000002e9852a0000000000000000000000000000000000000000000000000000000002e984760000000000000000000000000000000000000000000000000000000002e983c20000000000000000000000000000000000000000000000000000000002e983c20000000000000000000000000000000000000000000000000000000002e983c20000000000000000000000000000000000000000000000000000000002e984760000000000000000000000000000000000000000000000000000000002e984760000000000000000000000000000000000000000000000000000000002e984760000000000000000000000000000000000000000000000000000000000000015000000000000000000000000000000000000000000000000000000000023006400000000000000000000000000000000000000000000000000000000002301720000000000000000000000000000000000000000000000000000000000230280000000000000000000000000000000000000000000000000000000000023039800000000000000000000000000000000000000000000000000000000002304a600000000000000000000000000000000000000000000000000000000002304a600000000000000000000000000000000000000000000000000000000002304a6000000000000000000000000000000000000000000000000000000000023039800000000000000000000000000000000000000000000000000000000002302800000000000000000000000000000000000000000000000000000000000230172000000000000000000000000000000000000000000000000000000000023006400000000000000000000000000000000000000000000000000000000002301720000000000000000000000000000000000000000000000000000000000230280000000000000000000000000000000000000000000000000000000000023039800000000000000000000000000000000000000000000000000000000002303980000000000000000000000000000000000000000000000000000000000230398000000000000000000000000000000000000000000000000000000000023028000000000000000000000000000000000000000000000000000000000002301720000000000000000000000000000000000000000000000000000000000230172000000000000000000000000000000000000000000000000000000000023028000000000000000000000000000000000000000000000000000000000002305b4", contractAddress: "", cumulativeGasUsed: "7019919", gasUsed: "3519166", confirmations: "977217"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "422856000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x546f75722045696666656c000000000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["48858230","48857870","48857870","48857870","48858050","48858230","48858410","48858590","48858590","48858590","48858410","48858410","48858410","48858410","48858230","48858050","48858050","48858050","48858230","48858230","48858230"]}, {type: "int256[]", name: "_plots_lng", value: ["2293860","2294130","2294400","2294680","2294950","2294950","2294950","2294680","2294400","2294130","2293860","2294130","2294400","2294680","2294680","2294680","2294400","2294130","2294130","2294400","2295220"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x546f75722045696666656c000000000000000000000000000000000000000000", ["48858230","48857870","48857870","48857870","48858050","48858230","48858410","48858590","48858590","48858590","48858410","48858410","48858410","48858410","48858230","48858050","48858050","48858050","48858230","48858230","48858230"], ["2293860","2294130","2294400","2294680","2294950","2294950","2294950","2294680","2294400","2294130","2293860","2294130","2294400","2294680","2294680","2294680","2294400","2294130","2294130","2294400","2295220"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542618078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "searched_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "issueCoinTokens", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "issueCoinTokens", events: [{name: "searched_to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "amnt", type: "uint256", value: "2"}, {name: "timestamp", type: "uint256", value: "1542618078"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "9"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "9"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x546f75722045696666656c000000000000000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [48858230]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 6, c: [2293860]}}, {name: "size", type: "uint256", value: "21"}, {name: "bought_at", type: "uint256", value: "20136000000000000"}, {name: "empire_score", type: "uint256", value: "2100"}, {name: "timestamp", type: "uint256", value: "1542618078"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "105713978857200000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542618078"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "9"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x53696567657373e4756c6500000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732642", timeStamp: "1542618305", hash: "0xb67b1c26b854cce483541a3894f1dbc2b196632b1a771a46d83d69026ae3c855", nonce: "61", blockHash: "0xdad0ca111860074de236f2185e5c2f8e84b160d1c6a03653e73b07ea5a7aad90", transactionIndex: "110", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "80712000000000000", gas: "1408936", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef53696567657373e4756c6500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000003214f140000000000000000000000000000000000000000000000000000000003214e6a0000000000000000000000000000000000000000000000000000000003214e6a0000000000000000000000000000000000000000000000000000000003214f1400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000cbb4480000000000000000000000000000000000000000000000000000000000cbb4480000000000000000000000000000000000000000000000000000000000cbb56a0000000000000000000000000000000000000000000000000000000000cbb56a", contractAddress: "", cumulativeGasUsed: "7989164", gasUsed: "1408936", confirmations: "977197"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "80712000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x53696567657373e4756c65000000000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["52514580","52514410","52514410","52514580"]}, {type: "int256[]", name: "_plots_lng", value: ["13349960","13349960","13350250","13350250"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x53696567657373e4756c65000000000000000000000000000000000000000000", ["52514580","52514410","52514410","52514580"], ["13349960","13349960","13350250","13350250"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542618305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "10"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "10"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x53696567657373e4756c65000000000000000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [52514580]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 7, c: [13349960]}}, {name: "size", type: "uint256", value: "4"}, {name: "bought_at", type: "uint256", value: "20178000000000000"}, {name: "empire_score", type: "uint256", value: "400"}, {name: "timestamp", type: "uint256", value: "1542618305"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "20177991928800000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542618305"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "10"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x43726973746f20526564656e746f72000000... )", async function( ) {
		const txOriginal = {blockNumber: "6732693", timeStamp: "1542619147", hash: "0x5ef1a1b8f3b5a9b7d46bc042d18c01d0f2e6050de077cb81f34655ac449e041d", nonce: "62", blockHash: "0x32d4653d5f57b1be0fd77030a40673a10a7f4debaa851cdf6c289b107884490a", transactionIndex: "135", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "40372000000000000", gas: "1210209", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef43726973746f20526564656e746f720000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002fffffffffffffffffffffffffffffffffffffffffffffffffffffffffea1c7defffffffffffffffffffffffffffffffffffffffffffffffffffffffffea1c8920000000000000000000000000000000000000000000000000000000000000002fffffffffffffffffffffffffffffffffffffffffffffffffffffffffd6ca97efffffffffffffffffffffffffffffffffffffffffffffffffffffffffd6ca97e", contractAddress: "", cumulativeGasUsed: "7734767", gasUsed: "1210209", confirmations: "977146"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "40372000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x43726973746f20526564656e746f720000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["-22951970","-22951790"]}, {type: "int256[]", name: "_plots_lng", value: ["-43210370","-43210370"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x43726973746f20526564656e746f720000000000000000000000000000000000", ["-22951970","-22951790"], ["-43210370","-43210370"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542619147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "11"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "11"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x43726973746f20526564656e746f720000000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: -1, e: 7, c: [22951970]}}, {name: "center_lng", type: "int256", value: {s: -1, e: 7, c: [43210370]}}, {name: "size", type: "uint256", value: "2"}, {name: "bought_at", type: "uint256", value: "20186000000000000"}, {name: "empire_score", type: "uint256", value: "200"}, {name: "timestamp", type: "uint256", value: "1542619147"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "10092998990700000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542619147"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "11"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x436f6c6f737365756d000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6741957", timeStamp: "1542751807", hash: "0xb517f7034f6e9a41cc46d22b943ef1d071273b7f6ad625a8abd15231094b3dc8", nonce: "64", blockHash: "0x84080a48a7aef7c60d3d5ab1d5ba506d5162b17b1b98d7d9c997017c5aa27430", transactionIndex: "0", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "1009500000000000000", gas: "7855386", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef436f6c6f737365756d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000006e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f300800000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f300800000000000000000000000000000000000000000000000000000000027f300800000000000000000000000000000000000000000000000000000000027f300800000000000000000000000000000000000000000000000000000000027f300800000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f338c00000000000000000000000000000000000000000000000000000000027f338c00000000000000000000000000000000000000000000000000000000027f338c00000000000000000000000000000000000000000000000000000000027f338c00000000000000000000000000000000000000000000000000000000027f338c00000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f317000000000000000000000000000000000000000000000000000000000027f322400000000000000000000000000000000000000000000000000000000027f32d800000000000000000000000000000000000000000000000000000000027f30bc00000000000000000000000000000000000000000000000000000000027f300800000000000000000000000000000000000000000000000000000000027f338c00000000000000000000000000000000000000000000000000000000027f344000000000000000000000000000000000000000000000000000000000027f344000000000000000000000000000000000000000000000000000000000027f2f5400000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000be9e020000000000000000000000000000000000000000000000000000000000be9e020000000000000000000000000000000000000000000000000000000000be9d120000000000000000000000000000000000000000000000000000000000be9c220000000000000000000000000000000000000000000000000000000000be9c220000000000000000000000000000000000000000000000000000000000be9d120000000000000000000000000000000000000000000000000000000000be9d120000000000000000000000000000000000000000000000000000000000be9c220000000000000000000000000000000000000000000000000000000000be9e160000000000000000000000000000000000000000000000000000000000be9ff60000000000000000000000000000000000000000000000000000000000be9f060000000000000000000000000000000000000000000000000000000000be9f060000000000000000000000000000000000000000000000000000000000be9ff60000000000000000000000000000000000000000000000000000000000be9f060000000000000000000000000000000000000000000000000000000000be9ff60000000000000000000000000000000000000000000000000000000000be9ff60000000000000000000000000000000000000000000000000000000000be9f060000000000000000000000000000000000000000000000000000000000be9e160000000000000000000000000000000000000000000000000000000000be9c360000000000000000000000000000000000000000000000000000000000be9d260000000000000000000000000000000000000000000000000000000000be9d260000000000000000000000000000000000000000000000000000000000be9e160000000000000000000000000000000000000000000000000000000000be9ff60000000000000000000000000000000000000000000000000000000000be9f060000000000000000000000000000000000000000000000000000000000bea0f00000000000000000000000000000000000000000000000000000000000bea0f00000000000000000000000000000000000000000000000000000000000bea0f00000000000000000000000000000000000000000000000000000000000bea0f00000000000000000000000000000000000000000000000000000000000bea0f00000000000000000000000000000000000000000000000000000000000bea1e00000000000000000000000000000000000000000000000000000000000bea1e00000000000000000000000000000000000000000000000000000000000bea1e00000000000000000000000000000000000000000000000000000000000bea1e00000000000000000000000000000000000000000000000000000000000be9fec0000000000000000000000000000000000000000000000000000000000be9efc0000000000000000000000000000000000000000000000000000000000be9e020000000000000000000000000000000000000000000000000000000000be9d120000000000000000000000000000000000000000000000000000000000be9c220000000000000000000000000000000000000000000000000000000000be9b320000000000000000000000000000000000000000000000000000000000be9b320000000000000000000000000000000000000000000000000000000000be9b320000000000000000000000000000000000000000000000000000000000be9a4c0000000000000000000000000000000000000000000000000000000000be9a4c0000000000000000000000000000000000000000000000000000000000be9a4c0000000000000000000000000000000000000000000000000000000000be9b460000000000000000000000000000000000000000000000000000000000be9c360000000000000000000000000000000000000000000000000000000000be9b320000000000000000000000000000000000000000000000000000000000be9d120000000000000000000000000000000000000000000000000000000000be9e020000000000000000000000000000000000000000000000000000000000be9e16", contractAddress: "", cumulativeGasUsed: "7855386", gasUsed: "7855386", confirmations: "967882"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1009500000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x436f6c6f737365756d0000000000000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["41890160","41890340","41890340","41890160","41890520","41890520","41890160","41890340","41890520","41890520","41890340","41890520","41890340","41890160","41889980","41890160","41889980","41889980","41889980","41889800","41889980","41889800","41889800","41889800","41889800","41890160","41890340","41890520","41889980","41889980","41890160","41890340","41890520","41890700","41890700","41890700","41890700","41890700","41890520","41890340","41890160","41890160","41890340","41890520","41889980","41889800","41890700","41890880","41890880","41889620"]}, {type: "int256[]", name: "_plots_lng", value: ["12492290","12492290","12492050","12491810","12491810","12492050","12492050","12491810","12492310","12492790","12492550","12492550","12492790","12492550","12492790","12492790","12492550","12492310","12491830","12492070","12492070","12492310","12492790","12492550","12493040","12493040","12493040","12493040","12493040","12493280","12493280","12493280","12493280","12492780","12492540","12492290","12492050","12491810","12491570","12491570","12491570","12491340","12491340","12491340","12491590","12491830","12491570","12492050","12492290","12492310"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x436f6c6f737365756d0000000000000000000000000000000000000000000000", ["41890160","41890340","41890340","41890160","41890520","41890520","41890160","41890340","41890520","41890520","41890340","41890520","41890340","41890160","41889980","41890160","41889980","41889980","41889980","41889800","41889980","41889800","41889800","41889800","41889800","41890160","41890340","41890520","41889980","41889980","41890160","41890340","41890520","41890700","41890700","41890700","41890700","41890700","41890520","41890340","41890160","41890160","41890340","41890520","41889980","41889800","41890700","41890880","41890880","41889620"], ["12492290","12492290","12492050","12491810","12491810","12492050","12492050","12491810","12492310","12492790","12492550","12492550","12492790","12492550","12492790","12492790","12492550","12492310","12491830","12492070","12492070","12492310","12492790","12492550","12493040","12493040","12493040","12493040","12493040","12493280","12493280","12493280","12493280","12492780","12492540","12492290","12492050","12491810","12491570","12491570","12491570","12491340","12491340","12491340","12491590","12491830","12491570","12492050","12492290","12492310"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542751807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "searched_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "issueCoinTokens", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "issueCoinTokens", events: [{name: "searched_to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "amnt", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542751807"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "12"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "12"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x436f6c6f737365756d0000000000000000000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [41890160]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 7, c: [12492290]}}, {name: "size", type: "uint256", value: "50"}, {name: "bought_at", type: "uint256", value: "20190000000000000"}, {name: "empire_score", type: "uint256", value: "5000"}, {name: "timestamp", type: "uint256", value: "1542751807"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "252374949525000000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542751807"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "12"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x546f72726520646920506973610000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6741959", timeStamp: "1542751854", hash: "0x01233165199bd44b979de296920588deb481e567cab0fb36ae05204be4f92fb9", nonce: "65", blockHash: "0xfbc7cac95e71f154bf59b452ee1e4cadc25c9b786cee634e29d5dd8c9211af47", transactionIndex: "69", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "20190000000000000", gas: "1093161", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xdc00adef546f727265206469205069736100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000029b290c000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000009ea3c2", contractAddress: "", cumulativeGasUsed: "3237019", gasUsed: "31951", confirmations: "967880"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20190000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x546f727265206469205069736100000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["43723020"]}, {type: "int256[]", name: "_plots_lng", value: ["10396610"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x546f727265206469205069736100000000000000000000000000000000000000", ["43723020"], ["10396610"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542751854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x4665726e7365687475726d20537475747467... )", async function( ) {
		const txOriginal = {blockNumber: "6741959", timeStamp: "1542751854", hash: "0x1465c1f95bd40e69506026e4b0c9fd86933f9e019ac1159ae9b3607d21e1cfdb", nonce: "66", blockHash: "0xfbc7cac95e71f154bf59b452ee1e4cadc25c9b786cee634e29d5dd8c9211af47", transactionIndex: "70", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "423990000000000000", gas: "3519934", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xdc00adef4665726e7365687475726d20537475747467617274000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000340000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000002e7f30e0000000000000000000000000000000000000000000000000000000002e7f4760000000000000000000000000000000000000000000000000000000002e7f3c20000000000000000000000000000000000000000000000000000000002e7f4760000000000000000000000000000000000000000000000000000000002e7f3c20000000000000000000000000000000000000000000000000000000002e7f30e0000000000000000000000000000000000000000000000000000000002e7f4760000000000000000000000000000000000000000000000000000000002e7f3c20000000000000000000000000000000000000000000000000000000002e7f52a0000000000000000000000000000000000000000000000000000000002e7f4760000000000000000000000000000000000000000000000000000000002e7f52a0000000000000000000000000000000000000000000000000000000002e7f52a0000000000000000000000000000000000000000000000000000000002e7f4760000000000000000000000000000000000000000000000000000000002e7f3c20000000000000000000000000000000000000000000000000000000002e7f52a0000000000000000000000000000000000000000000000000000000002e7f52a0000000000000000000000000000000000000000000000000000000002e7f52a0000000000000000000000000000000000000000000000000000000002e7f5de0000000000000000000000000000000000000000000000000000000002e7f5de0000000000000000000000000000000000000000000000000000000002e7f5de0000000000000000000000000000000000000000000000000000000002e7f5de000000000000000000000000000000000000000000000000000000000000001500000000000000000000000000000000000000000000000000000000008c38ea00000000000000000000000000000000000000000000000000000000008c38ea00000000000000000000000000000000000000000000000000000000008c38ea00000000000000000000000000000000000000000000000000000000008c39f800000000000000000000000000000000000000000000000000000000008c39f800000000000000000000000000000000000000000000000000000000008c39f800000000000000000000000000000000000000000000000000000000008c3b1000000000000000000000000000000000000000000000000000000000008c3b1000000000000000000000000000000000000000000000000000000000008c3b1000000000000000000000000000000000000000000000000000000000008c3c1e00000000000000000000000000000000000000000000000000000000008c3d2c00000000000000000000000000000000000000000000000000000000008c3c1e00000000000000000000000000000000000000000000000000000000008c3d2c00000000000000000000000000000000000000000000000000000000008c3c1e00000000000000000000000000000000000000000000000000000000008c39f800000000000000000000000000000000000000000000000000000000008c3e3a00000000000000000000000000000000000000000000000000000000008c3f5200000000000000000000000000000000000000000000000000000000008c3e3a00000000000000000000000000000000000000000000000000000000008c3f5200000000000000000000000000000000000000000000000000000000008c3d2c00000000000000000000000000000000000000000000000000000000008c3c1e", contractAddress: "", cumulativeGasUsed: "3286928", gasUsed: "49909", confirmations: "967880"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "423990000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x4665726e7365687475726d205374757474676172740000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["48755470","48755830","48755650","48755830","48755650","48755470","48755830","48755650","48756010","48755830","48756010","48756010","48755830","48755650","48756010","48756010","48756010","48756190","48756190","48756190","48756190"]}, {type: "int256[]", name: "_plots_lng", value: ["9189610","9189610","9189610","9189880","9189880","9189880","9190160","9190160","9190160","9190430","9190700","9190430","9190700","9190430","9189880","9190970","9191250","9190970","9191250","9190700","9190430"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x4665726e7365687475726d205374757474676172740000000000000000000000", ["48755470","48755830","48755650","48755830","48755650","48755470","48755830","48755650","48756010","48755830","48756010","48756010","48755830","48755650","48756010","48756010","48756010","48756190","48756190","48756190","48756190"], ["9189610","9189610","9189610","9189880","9189880","9189880","9190160","9190160","9190160","9190430","9190700","9190430","9190700","9190430","9189880","9190970","9191250","9190970","9191250","9190700","9190430"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542751854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x5363686c6f7373204e657573636877616e73... )", async function( ) {
		const txOriginal = {blockNumber: "6741978", timeStamp: "1542752191", hash: "0x90b64a67816bb0b769bd67b117cbbf0a6e0392f490a98a74be341d2fa1f3dd8e", nonce: "67", blockHash: "0x6a8e1e1e25a9c77f05f6b4e4f91bdd2925893a867a245bf8663098f1ca298d46", transactionIndex: "48", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "405800000000000000", gas: "3397170", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef5363686c6f7373204e657573636877616e737465696e0000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000002d5aa960000000000000000000000000000000000000000000000000000000002d5aa960000000000000000000000000000000000000000000000000000000002d5ab4a0000000000000000000000000000000000000000000000000000000002d5ab4a0000000000000000000000000000000000000000000000000000000002d5ab4a0000000000000000000000000000000000000000000000000000000002d5aa960000000000000000000000000000000000000000000000000000000002d5abfe0000000000000000000000000000000000000000000000000000000002d5aa960000000000000000000000000000000000000000000000000000000002d5abfe0000000000000000000000000000000000000000000000000000000002d5ab4a0000000000000000000000000000000000000000000000000000000002d5abfe0000000000000000000000000000000000000000000000000000000002d5acb20000000000000000000000000000000000000000000000000000000002d5ab4a0000000000000000000000000000000000000000000000000000000002d5aa960000000000000000000000000000000000000000000000000000000002d5ab4a0000000000000000000000000000000000000000000000000000000002d5acb20000000000000000000000000000000000000000000000000000000002d5acb20000000000000000000000000000000000000000000000000000000002d5ab4a0000000000000000000000000000000000000000000000000000000002d5abfe0000000000000000000000000000000000000000000000000000000002d5abfe00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000a4042a0000000000000000000000000000000000000000000000000000000000a403260000000000000000000000000000000000000000000000000000000000a403260000000000000000000000000000000000000000000000000000000000a405380000000000000000000000000000000000000000000000000000000000a4042a0000000000000000000000000000000000000000000000000000000000a405380000000000000000000000000000000000000000000000000000000000a406460000000000000000000000000000000000000000000000000000000000a406460000000000000000000000000000000000000000000000000000000000a405380000000000000000000000000000000000000000000000000000000000a406460000000000000000000000000000000000000000000000000000000000a4074a0000000000000000000000000000000000000000000000000000000000a4074a0000000000000000000000000000000000000000000000000000000000a4074a0000000000000000000000000000000000000000000000000000000000a4074a0000000000000000000000000000000000000000000000000000000000a408580000000000000000000000000000000000000000000000000000000000a408580000000000000000000000000000000000000000000000000000000000a409660000000000000000000000000000000000000000000000000000000000a409660000000000000000000000000000000000000000000000000000000000a409660000000000000000000000000000000000000000000000000000000000a40858", contractAddress: "", cumulativeGasUsed: "6216257", gasUsed: "3397170", confirmations: "967861"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "405800000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x5363686c6f7373204e657573636877616e737465696e00000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["47557270","47557270","47557450","47557450","47557450","47557270","47557630","47557270","47557630","47557450","47557630","47557810","47557450","47557270","47557450","47557810","47557810","47557450","47557630","47557630"]}, {type: "int256[]", name: "_plots_lng", value: ["10748970","10748710","10748710","10749240","10748970","10749240","10749510","10749510","10749240","10749510","10749770","10749770","10749770","10749770","10750040","10750040","10750310","10750310","10750310","10750040"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x5363686c6f7373204e657573636877616e737465696e00000000000000000000", ["47557270","47557270","47557450","47557450","47557450","47557270","47557630","47557270","47557630","47557450","47557630","47557810","47557450","47557270","47557450","47557810","47557810","47557450","47557630","47557630"], ["10748970","10748710","10748710","10749240","10748970","10749240","10749510","10749510","10749240","10749510","10749770","10749770","10749770","10749770","10750040","10750040","10750310","10750310","10750310","10750040"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542752191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "searched_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "issueCoinTokens", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "issueCoinTokens", events: [{name: "searched_to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "amnt", type: "uint256", value: "2"}, {name: "timestamp", type: "uint256", value: "1542752191"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "13"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "13"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x5363686c6f7373204e657573636877616e737465696e00000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [47557270]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 7, c: [10748970]}}, {name: "size", type: "uint256", value: "20"}, {name: "bought_at", type: "uint256", value: "20290000000000000"}, {name: "empire_score", type: "uint256", value: "2000"}, {name: "timestamp", type: "uint256", value: "1542752191"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "101449979710000000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542752191"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "13"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x546f72726520646920706973610000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6741995", timeStamp: "1542752490", hash: "0x94306a64951072b72e5793ac9c9f1a8db65cec44ff87b392ea3ee478794fe2cf", nonce: "68", blockHash: "0x6451d448396c2a04a0fd167d3cbe2c46f834e7eeaf5fd6fab1a2afee2856914d", transactionIndex: "85", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "20330000000000000", gas: "1093161", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef546f727265206469207069736100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000029b290c000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000009ea3c2", contractAddress: "", cumulativeGasUsed: "6857635", gasUsed: "1093161", confirmations: "967844"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20330000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x546f727265206469207069736100000000000000000000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["43723020"]}, {type: "int256[]", name: "_plots_lng", value: ["10396610"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x546f727265206469207069736100000000000000000000000000000000000000", ["43723020"], ["10396610"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542752490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "14"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "14"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x546f727265206469207069736100000000000000000000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [43723020]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 7, c: [10396610]}}, {name: "size", type: "uint256", value: "1"}, {name: "bought_at", type: "uint256", value: "20330000000000000"}, {name: "empire_score", type: "uint256", value: "100"}, {name: "timestamp", type: "uint256", value: "1542752490"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "5082497967000000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542752490"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "14"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x4665726e7365687475726d20537475747467... )", async function( ) {
		const txOriginal = {blockNumber: "6742003", timeStamp: "1542752654", hash: "0xeb777190390832837e4c90fa2cebdd41f08d208bbdaed2a602f6b633a0f1130f", nonce: "69", blockHash: "0x312908aec1dfd77605cbb888656837e53804d15025b3c6ab7f328e1a17627bc1", transactionIndex: "34", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "345644000000000000", gas: "3000925", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef4665726e7365687475726d205374757474676172740000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000002e7f3540000000000000000000000000000000000000000000000000000000002e7f4080000000000000000000000000000000000000000000000000000000002e7f4bc0000000000000000000000000000000000000000000000000000000002e7f4080000000000000000000000000000000000000000000000000000000002e7f3540000000000000000000000000000000000000000000000000000000002e7f3540000000000000000000000000000000000000000000000000000000002e7f4bc0000000000000000000000000000000000000000000000000000000002e7f4bc0000000000000000000000000000000000000000000000000000000002e7f4080000000000000000000000000000000000000000000000000000000002e7f4080000000000000000000000000000000000000000000000000000000002e7f4080000000000000000000000000000000000000000000000000000000002e7f4bc0000000000000000000000000000000000000000000000000000000002e7f5700000000000000000000000000000000000000000000000000000000002e7f5700000000000000000000000000000000000000000000000000000000002e7f5700000000000000000000000000000000000000000000000000000000002e7f4bc0000000000000000000000000000000000000000000000000000000002e7f4bc000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000008c387c00000000000000000000000000000000000000000000000000000000008c387c00000000000000000000000000000000000000000000000000000000008c387c00000000000000000000000000000000000000000000000000000000008c398a00000000000000000000000000000000000000000000000000000000008c398a00000000000000000000000000000000000000000000000000000000008c3a9800000000000000000000000000000000000000000000000000000000008c398a00000000000000000000000000000000000000000000000000000000008c3a9800000000000000000000000000000000000000000000000000000000008c3a9800000000000000000000000000000000000000000000000000000000008c3cbe00000000000000000000000000000000000000000000000000000000008c3ba600000000000000000000000000000000000000000000000000000000008c3cbe00000000000000000000000000000000000000000000000000000000008c3cbe00000000000000000000000000000000000000000000000000000000008c3ba600000000000000000000000000000000000000000000000000000000008c3a9800000000000000000000000000000000000000000000000000000000008c3dcc00000000000000000000000000000000000000000000000000000000008c3ba6", contractAddress: "", cumulativeGasUsed: "5449239", gasUsed: "3000925", confirmations: "967836"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "345644000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x4665726e7365687475726d205374757474676172740000000000000000000000"}, {type: "int256[]", name: "_plots_lat", value: ["48755540","48755720","48755900","48755720","48755540","48755540","48755900","48755900","48755720","48755720","48755720","48755900","48756080","48756080","48756080","48755900","48755900"]}, {type: "int256[]", name: "_plots_lng", value: ["9189500","9189500","9189500","9189770","9189770","9190040","9189770","9190040","9190040","9190590","9190310","9190590","9190590","9190310","9190040","9190860","9190310"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x4665726e7365687475726d205374757474676172740000000000000000000000", ["48755540","48755720","48755900","48755720","48755540","48755540","48755900","48755900","48755720","48755720","48755720","48755900","48756080","48756080","48756080","48755900","48755900"], ["9189500","9189500","9189500","9189770","9189770","9190040","9189770","9190040","9190040","9190590","9190310","9190590","9190590","9190310","9190040","9190860","9190310"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542752654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "searched_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "issueCoinTokens", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "issueCoinTokens", events: [{name: "searched_to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "amnt", type: "uint256", value: "1"}, {name: "timestamp", type: "uint256", value: "1542752654"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "15"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "15"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x4665726e7365687475726d205374757474676172740000000000000000000000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [48755540]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 6, c: [9189500]}}, {name: "size", type: "uint256", value: "17"}, {name: "bought_at", type: "uint256", value: "20332000000000000"}, {name: "empire_score", type: "uint256", value: "1700"}, {name: "timestamp", type: "uint256", value: "1542752654"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "86410974076700000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542752654"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "15"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyLand( \"0x4d742e20527573686d6f7265204e6174696f... )", async function( ) {
		const txOriginal = {blockNumber: "6742044", timeStamp: "1542753263", hash: "0x41d512718cd68c120ea2c66e26518fa3edfb60d358646a9fb0f08d3e93a1c047", nonce: "70", blockHash: "0xec393d923975ad37e23bca5c7d5b78dce6905d0b1176e002d62afe317d201791", transactionIndex: "40", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "427686000000000000", gas: "3577149", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc00adef4d742e20527573686d6f7265204e6174696f6e616c204d656d6f7269616c0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001500000000000000000000000000000000000000000000000000000000029d8b7a00000000000000000000000000000000000000000000000000000000029d8b7a00000000000000000000000000000000000000000000000000000000029d8b7a00000000000000000000000000000000000000000000000000000000029d8a1200000000000000000000000000000000000000000000000000000000029d8ac600000000000000000000000000000000000000000000000000000000029d8a1200000000000000000000000000000000000000000000000000000000029d8ac600000000000000000000000000000000000000000000000000000000029d895e00000000000000000000000000000000000000000000000000000000029d895e00000000000000000000000000000000000000000000000000000000029d88aa00000000000000000000000000000000000000000000000000000000029d895e00000000000000000000000000000000000000000000000000000000029d88aa00000000000000000000000000000000000000000000000000000000029d87f600000000000000000000000000000000000000000000000000000000029d8a1200000000000000000000000000000000000000000000000000000000029d88aa00000000000000000000000000000000000000000000000000000000029d87f600000000000000000000000000000000000000000000000000000000029d8ac600000000000000000000000000000000000000000000000000000000029d87f600000000000000000000000000000000000000000000000000000000029d88aa00000000000000000000000000000000000000000000000000000000029d895e00000000000000000000000000000000000000000000000000000000029d8a120000000000000000000000000000000000000000000000000000000000000015fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55914fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5581afffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55720fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55720fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55720fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55626fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55626fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55720fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55626fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5552cfffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5552cfffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55626fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5552cfffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5552cfffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55720fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55626fffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5581afffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5543cfffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5543cfffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d5543cfffffffffffffffffffffffffffffffffffffffffffffffffffffffff9d55824", contractAddress: "", cumulativeGasUsed: "7408831", gasUsed: "3577149", confirmations: "967795"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "427686000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x4d742e20527573686d6f7265204e6174696f6e616c204d656d6f7269616c0000"}, {type: "int256[]", name: "_plots_lat", value: ["43879290","43879290","43879290","43878930","43879110","43878930","43879110","43878750","43878750","43878570","43878750","43878570","43878390","43878930","43878570","43878390","43879110","43878390","43878570","43878750","43878930"]}, {type: "int256[]", name: "_plots_lng", value: ["-103458540","-103458790","-103459040","-103459040","-103459040","-103459290","-103459290","-103459040","-103459290","-103459540","-103459540","-103459290","-103459540","-103459540","-103459040","-103459290","-103458790","-103459780","-103459780","-103459780","-103458780"]}, {type: "address", name: "_referrer", value: addressList[0]}], name: "buyLand", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLand(bytes32,int256[],int256[],address)" ]( "0x4d742e20527573686d6f7265204e6174696f6e616c204d656d6f7269616c0000", ["43879290","43879290","43879290","43878930","43879110","43878930","43879110","43878750","43878750","43878570","43878750","43878570","43878390","43878930","43878570","43878390","43879110","43878390","43878570","43878750","43878930"], ["-103458540","-103458790","-103459040","-103459040","-103459040","-103459290","-103459290","-103459040","-103459290","-103459540","-103459540","-103459290","-103459540","-103459540","-103459040","-103459290","-103458790","-103459780","-103459780","-103459780","-103458780"], addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542753263 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "searched_to", type: "address"}, {indexed: false, name: "to", type: "address"}, {indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "issueCoinTokens", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "issueCoinTokens", events: [{name: "searched_to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "amnt", type: "uint256", value: "2"}, {name: "timestamp", type: "uint256", value: "1542753263"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "16"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "16"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x4d742e20527573686d6f7265204e6174696f6e616c204d656d6f7269616c0000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [43879290]}}, {name: "center_lng", type: "int256", value: {s: -1, e: 8, c: [103458540]}}, {name: "size", type: "uint256", value: "21"}, {name: "bought_at", type: "uint256", value: "20366000000000000"}, {name: "empire_score", type: "uint256", value: "2100"}, {name: "timestamp", type: "uint256", value: "1542753263"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amnt", type: "uint256"}, {indexed: false, name: "total_players", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "taxDistributed", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "taxDistributed", events: [{name: "amnt", type: "uint256", value: "106921467923550000"}, {name: "total_players", type: "uint256", value: "5"}, {name: "timestamp", type: "uint256", value: "1542753263"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "16"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyLandWithTokens( \"0x42743544043d43e43144b43b44c44143a438... )", async function( ) {
		const txOriginal = {blockNumber: "6744460", timeStamp: "1542787207", hash: "0x5e8d1620600f61042cf4bba24a35ae20e5cde49721a7dd0cb5024e2dcf1a5329", nonce: "72", blockHash: "0x671a7ab2e7a1b42c59787cf43e9283004acc3ff3066d4cf3e44cd9537bb03a3c", transactionIndex: "81", from: "0xefc538603b0a2727a9f372db039781c538944ab9", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "1817593", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0d4ea31642743544043d43e43144b43b44c44143a4384392042043543043a44243e440000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000003102b6c0000000000000000000000000000000000000000000000000000000003102b6c0000000000000000000000000000000000000000000000000000000003102c200000000000000000000000000000000000000000000000000000000003102c200000000000000000000000000000000000000000000000000000000003102cd40000000000000000000000000000000000000000000000000000000003102cd40000000000000000000000000000000000000000000000000000000003102d880000000000000000000000000000000000000000000000000000000003102d8800000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000001cb37880000000000000000000000000000000000000000000000000000000001cb38aa0000000000000000000000000000000000000000000000000000000001cb38aa0000000000000000000000000000000000000000000000000000000001cb37880000000000000000000000000000000000000000000000000000000001cb37880000000000000000000000000000000000000000000000000000000001cb38aa0000000000000000000000000000000000000000000000000000000001cb38aa0000000000000000000000000000000000000000000000000000000001cb3788", contractAddress: "", cumulativeGasUsed: "6084594", gasUsed: "1817593", confirmations: "965379"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_name", value: "0x42743544043d43e43144b43b44c44143a4384392042043543043a44243e44000"}, {type: "int256[]", name: "_plots_lat", value: ["51391340","51391340","51391520","51391520","51391700","51391700","51391880","51391880"]}, {type: "int256[]", name: "_plots_lng", value: ["30095240","30095530","30095530","30095240","30095240","30095530","30095530","30095240"]}], name: "buyLandWithTokens", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyLandWithTokens(bytes32,int256[],int256[])" ]( "0x42743544043d43e43144b43b44c44143a4384392042043543043a44243e44000", ["51391340","51391340","51391520","51391520","51391700","51391700","51391880","51391880"], ["30095240","30095530","30095530","30095240","30095240","30095530","30095530","30095240"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542787207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "search_token_id", type: "uint256"}, {indexed: true, name: "search_buyer", type: "address"}, {indexed: false, name: "token_id", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "name", type: "bytes32"}, {indexed: false, name: "center_lat", type: "int256"}, {indexed: false, name: "center_lng", type: "int256"}, {indexed: false, name: "size", type: "uint256"}, {indexed: false, name: "bought_at", type: "uint256"}, {indexed: false, name: "empire_score", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "landPurchased", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "landPurchased", events: [{name: "search_token_id", type: "uint256", value: "17"}, {name: "search_buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "token_id", type: "uint256", value: "17"}, {name: "buyer", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "name", type: "bytes32", value: "0x42743544043d43e43144b43b44c44143a4384392042043543043a44243e44000"}, {name: "center_lat", type: "int256", value: {s: 1, e: 7, c: [51391340]}}, {name: "center_lng", type: "int256", value: {s: 1, e: 7, c: [30095240]}}, {name: "size", type: "uint256", value: "8"}, {name: "bought_at", type: "uint256", value: "20408000000000000"}, {name: "empire_score", type: "uint256", value: "800"}, {name: "timestamp", type: "uint256", value: "1542787207"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xefc538603b0a2727a9f372db039781c538944ab9"}, {name: "tokenId", type: "uint256", value: "17"}], address: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "124149979785230000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6745497", timeStamp: "1542802305", hash: "0xea94254653db1fc9c5e19c45d3327353e3cacf32b4d2fdf096a2958fbd72f2b4", nonce: "0", blockHash: "0x150d258dfe3972212cbc04ac0a23219bcd55a99ade0178d8f81c6ee1efd23b70", transactionIndex: "107", from: "0x0d4a5cb5e775c1c81f4111bf19080dd70f987b14", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "3900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7740830", gasUsed: "22059", confirmations: "964342"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542802305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3908900000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6745503", timeStamp: "1542802386", hash: "0x51d607681b25839396861fe12fac33911adb65956dbf8c651807c9533409c44b", nonce: "0", blockHash: "0x3fee52367996e4153587f5b42f7d46bd6f790f70a6874a567ec241ba90343dd2", transactionIndex: "86", from: "0x1a8c8ed1ba3057e874befd3612aa10c7cd55c048", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "3900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7462539", gasUsed: "22059", confirmations: "964336"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542802386 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "3908900000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6745527", timeStamp: "1542802619", hash: "0x7c7b7a24d5978a4591f2093ae38d52c3c9e8a79e394200f5831c2fc378d51539", nonce: "0", blockHash: "0xd97e2ce4987b08348d90193b502c0dcc699408ef47645f6adab08523f43c14dc", transactionIndex: "63", from: "0xa150dded73e8b27450e3162ee20392fcd8e8d2d2", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "4781317", gasUsed: "22059", confirmations: "964312"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542802619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6745532", timeStamp: "1542802721", hash: "0x9ba5aaf7bf71dabb1e29b39af808953901d234f93ce0482dfb0dcf829802c1d9", nonce: "0", blockHash: "0x81a98b0d76434a8be2893183bb57a0021e34cfbecfb0b18a241363ecf3e4f831", transactionIndex: "100", from: "0x377e0ea89d83f3a726e149c25dab34b2caa75a83", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7997279", gasUsed: "22059", confirmations: "964307"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542802721 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746008", timeStamp: "1542809541", hash: "0x2a8b3ab17e910761a58a6d08c3082872e965d825fca9de37d2e1f219e156dc42", nonce: "0", blockHash: "0x2288889be4071a2a4450878e8b9882ef2a5e0a112dc66e08aef3ff505fad9ebb", transactionIndex: "57", from: "0xc6ecfa8b3bb5debda7b88e40b2258aef21d806ed", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7135178", gasUsed: "22059", confirmations: "963831"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542809541 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746012", timeStamp: "1542809582", hash: "0x396c4ab578dfb2ba373a0fc2150678eaa5180a41341854e0a567dcbd7b3af4e6", nonce: "0", blockHash: "0x68bebfcf0cf2ca79967b1693dea9449576ed3b9cfcc0e97c2e3edc3cf3548c8e", transactionIndex: "91", from: "0x7bc54cc2fe6e26eb8fa309965e1be8d840b74cc6", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "3970064", gasUsed: "22059", confirmations: "963827"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542809582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746015", timeStamp: "1542809598", hash: "0x9455bcc32740b9ec8be5828d2422dbd0fb05aa55ab3e5f820b14fb0c6240a1e2", nonce: "0", blockHash: "0x1cce7d5d5d7872f77a1006f4c6bf4960175426e9008c9c4401bd05d203f9f08f", transactionIndex: "49", from: "0xc7250265574f2d9f9babe946d8205a288537fb5b", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "2072400", gasUsed: "22059", confirmations: "963824"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542809598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746020", timeStamp: "1542809685", hash: "0xf1038be250d45be52e577f73de95209127ec8098501c156b60eb0c51617ae0cf", nonce: "0", blockHash: "0xc7f4e12722575ddf6b149481ccbe548cabe2bc3dc9e9ce4ef63038a12d95a915", transactionIndex: "71", from: "0x9a7f3277fae3c10cb1eedec0bc2d6606610c3f12", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "3735302", gasUsed: "22059", confirmations: "963819"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542809685 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746025", timeStamp: "1542809770", hash: "0xe4bb84d4d59748060bbf2c2e3c5e898b97b2be98040fd5dadd678856e0670823", nonce: "0", blockHash: "0x41b0abbae92a99e49cddc36ea21ca0cee2b2733acb1ec2f11facdef1f87e7590", transactionIndex: "134", from: "0xe9aa7c522de5dbe1b784b285c38f282bd247ee30", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7893635", gasUsed: "22059", confirmations: "963814"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542809770 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746027", timeStamp: "1542809805", hash: "0x5272b9c7fe3333c3163035009fb95a860a745420923fd91d2bfa8b5d152cc4a6", nonce: "0", blockHash: "0x9c631143a9d335183935ad32ccc9bc780fc8fd05da6266f7ba94942f5f25d705", transactionIndex: "89", from: "0x32db8affe842c970bae811646821c35113f9f0f6", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "3690906", gasUsed: "22059", confirmations: "963812"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542809805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746030", timeStamp: "1542809836", hash: "0x30bf5cccd15ef734ffba5a6bf348c1d69bec8f901614333d24b3a35c607fe6a9", nonce: "0", blockHash: "0x38bfc80815da7a9bbd5572330b6d485a1ce5d670b19b1b3cd4bbf10e40221810", transactionIndex: "94", from: "0xe77164cd465e196ff5067c242b4472ad709ef1d7", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "4638214", gasUsed: "22059", confirmations: "963809"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542809836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746033", timeStamp: "1542809857", hash: "0xe64cc002d65499f55e792f3ff34eda7739db6813ce167457b8ec99b32f91107a", nonce: "0", blockHash: "0x5f44f6ffac59ed9ae934cc7196fde35b0fa9e8635e99d98bcdce58ac46550e2d", transactionIndex: "33", from: "0x6502acf292ec0b8bdf60d2f56d70cc4bbe8d7ff6", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "1285614", gasUsed: "22059", confirmations: "963806"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542809857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746035", timeStamp: "1542809879", hash: "0x0c9f86c0635f0ba3222704ffc081abe051617a06fd878d7fa8f58ad06cfb020f", nonce: "0", blockHash: "0x7db25dcd1f8d1a1c8be709d61239b03924e359945b367e24ccb11379d13ac5ad", transactionIndex: "78", from: "0x69594e133979f1b991617ee032c186ff7932f581", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "3205135", gasUsed: "22059", confirmations: "963804"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542809879 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746036", timeStamp: "1542809881", hash: "0x7242b87a206b0849b28bd34864306cc9ca48843c363f5fd87f34e0d4aacf6848", nonce: "0", blockHash: "0x60a512efc40d7c03a2183b07a5091890a8c8c3966cb958fb1c0f28b317e98abf", transactionIndex: "117", from: "0x50f79c59d69f48a8a14e23ee6506d1cba94cabff", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7287108", gasUsed: "22059", confirmations: "963803"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542809881 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746038", timeStamp: "1542809917", hash: "0x2dfac5b0929cc5f37416d8995411b8cc6bbd7cf1b616340166d780313de04753", nonce: "0", blockHash: "0xd6836027b06ac4c4affb05d663e141ec32cd85200d6f9e31f5e55accd1ccef34", transactionIndex: "38", from: "0x1f8389d4cb85a546b1777b90bb16b5b7047f18ba", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "2308903", gasUsed: "22059", confirmations: "963801"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542809917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746040", timeStamp: "1542809938", hash: "0x4ff571373952bd5d5ed5a6bc89ba0bda632dbca80e2bc2e5249a1c1395cc133e", nonce: "0", blockHash: "0x4c1b9a65b34d5142b9d1da945f0f6c3f6ece06b5ea0f8babc390a41aac7577be", transactionIndex: "61", from: "0x21676e2ea4c07fcd4e09ae599995a7694edaab21", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "2584431", gasUsed: "22059", confirmations: "963799"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542809938 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746043", timeStamp: "1542809973", hash: "0x475ff62ec624dba3514d83175956144ba9b4a76a19733af8afe0268ba23f293b", nonce: "0", blockHash: "0xfe4ae15f65eda149bba3a267179b154a55ecc77e61cc4c0dc9f34427fa678a43", transactionIndex: "129", from: "0x36726ef314b5e583abd9cb8f3df762c417095a62", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7030652", gasUsed: "22059", confirmations: "963796"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542809973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746045", timeStamp: "1542810010", hash: "0x65cd69650342ffa87735a808e86efd470fb3456b48e4732694031eb29c389f56", nonce: "0", blockHash: "0x292a354f5c4355eeff42968ad4980cc128fa6edfc84713fe2e337699b72714e1", transactionIndex: "94", from: "0x52c6a548d4561d98ad299aba1229e5cd38cb2b34", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "4353097", gasUsed: "22059", confirmations: "963794"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542810010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746047", timeStamp: "1542810025", hash: "0x383bf5e939fad1db8935d6da907f7554b8797cbaccdb87f1d458e4439266c9fa", nonce: "0", blockHash: "0xc457e22c8b1291786ddee91de7f0793dd031fe85aeab6a8f367bbd058fffa40a", transactionIndex: "94", from: "0x447ec0dc651fb5b1ee9dba8782b11f3c36da9eb8", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "5712426", gasUsed: "22059", confirmations: "963792"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542810025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746048", timeStamp: "1542810050", hash: "0xd7b3914e1319f99b80056c478b84893853fe63eebfd2b2025a298cdfbdec9f0f", nonce: "0", blockHash: "0x25c0d02adcb089339037c30e5da33d65d8fed10673e4830ac0703ab53967d792", transactionIndex: "115", from: "0x20ce3d4fb8796133d0caba388f6187589cacb302", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7219703", gasUsed: "22059", confirmations: "963791"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542810050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746051", timeStamp: "1542810089", hash: "0x8dbd67fef7890098d61ac78b9d9b9078b5b502cc7373cdaab00dc5ecf1545256", nonce: "0", blockHash: "0x3d874e72da90c01d0deeeac726b8c35e8d07b81598c3e477164200d6cafee11c", transactionIndex: "73", from: "0xc403986c0a45d9ec1c2ef4379f4947a75b41f593", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "4382416", gasUsed: "22059", confirmations: "963788"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542810089 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746055", timeStamp: "1542810125", hash: "0x86d7625f8793f5c14aefd784257dacf353b13c85b2bcb72a83e89e75322ad2da", nonce: "0", blockHash: "0xf85d8a6d897041b8f072544376e46a29ab387c56bfbb58849ad3e64b48f7b9f0", transactionIndex: "42", from: "0xf805e3a356aeff4e89d0e0f47b9aa1e168227c08", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "2650659", gasUsed: "22059", confirmations: "963784"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542810125 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746057", timeStamp: "1542810215", hash: "0xf53f328f7ac41042c6d825af5c60aa123fc3ad6b7b771779fdc3d24f3a50bc4b", nonce: "0", blockHash: "0xbef1a761217e25366ead9ae8aadcb38eec799bb4e61717b1d7aab84eb7af451f", transactionIndex: "140", from: "0x00e65f38e96d12b543b07d37e1b61122669033d8", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "7073910", gasUsed: "22059", confirmations: "963782"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542810215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746059", timeStamp: "1542810236", hash: "0x9c72193f2511c099672cb7b17dc16dd201eba62c0ed1aa94dc0948f0414aaf4c", nonce: "0", blockHash: "0xad8aceeeaeeebc0235d13349a96d6462d4bcf170401708571ee2ec5cf788d158", transactionIndex: "45", from: "0xdf4b89549d8757d7f8731a4a20f2a62b927d8e30", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "1964467", gasUsed: "22059", confirmations: "963780"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542810236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746063", timeStamp: "1542810339", hash: "0x5ef0a534f0d8d7bb8b49eb03b02071711faecf7c763b211364a1a70614df293f", nonce: "0", blockHash: "0x52495be4c763516e565f04382c803fad7ff8a875b5baa2df413f3a1d494813b0", transactionIndex: "157", from: "0x3156ed3d443ac912ca4cb0b6b2d59ce594a72f21", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "6653510", gasUsed: "22059", confirmations: "963776"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542810339 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: m(  )", async function( ) {
		const txOriginal = {blockNumber: "6746063", timeStamp: "1542810339", hash: "0x5cdd98d10887ef2815e053de7baf8652a113e6eca629995cca33d4d2bc4337bc", nonce: "0", blockHash: "0x52495be4c763516e565f04382c803fad7ff8a875b5baa2df413f3a1d494813b0", transactionIndex: "158", from: "0x68b924184a97d81e786971056926689a4666aa19", to: "0x8c55b18e6bb7083b29102e57c34d0c3124c0a952", value: "0", gas: "22059", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x5a2ee019", contractAddress: "", cumulativeGasUsed: "6675569", gasUsed: "22059", confirmations: "963776"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "m", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "m()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542810339 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "3205900000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "706807225096308000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
