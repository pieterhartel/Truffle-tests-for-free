var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "ProfitExchange"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xD72eaD482B15197B99f74d846E8180D7F33670df","0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed","0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1","0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e","0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48","0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475","0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF","0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA","0x4E202e841A07e4c7474bF791CF39386285c52FBB","0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51","0x0000002BFA4DAC0fdcf5cd9D47259241Ce92459B","0x94d0dE1a5A16F90ba91915148b0F5894CA79a22e"]
addressListOriginal.length = 14
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"ACCEPT_EXCHANGE","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"bytes32"}],"name":"addresses","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"bytes32"}],"name":"balances","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = []
eventSignatureListOriginal = []
topicListOriginal = []
nBlocksOriginal = 50
fromBlockOriginal = 4076460
toBlockOriginal = 4076749
constructorPrototypeOriginal = {"inputs":[],"name":"ProfitExchange","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"4076460","timeStamp":"1501076157","hash":"0x65c5ea4b08f5f3ab1a4e225825735614ad3d302a3218321bc52db0ee81dd78cd","nonce":"3","blockHash":"0x85be7a8dba9001ba9c81799f83a32b2b945a9a65c60491bc7e2f5c7d0ba9c057","transactionIndex":"25","from":"0x4e202e841a07e4c7474bf791cf39386285c52fbb","to":0,"value":"0","gas":"2500000","gasPrice":"21000000000","isError":"0","txreceipt_status":"","input":"0xc17b5a93","contractAddress":"0xd72ead482b15197b99f74d846e8180d7f33670df","cumulativeGasUsed":"2601861","gasUsed":"1798711","confirmations":"3605196"}
txOptions[0] = {"from":"0x28a8746e75304c0780E011BEd21C72cD78cd535E","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"ProfitExchange","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
