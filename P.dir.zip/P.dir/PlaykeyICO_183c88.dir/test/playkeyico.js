const PlaykeyICO = artifacts.require( "./PlaykeyICO.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PlaykeyICO" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x26D08B9d227933A85e855656DC46aB889E183C88", "0x8Abdf2AB2F5D76C3cAC045EB25EE54FfF721787c", "0x9e02445768dD6fBe9341f9491B03517EF890cBc3", "0xE8d5B64163BA28CBA2B23eb6cE3b12D91B7537bC", "0x92D99Fa62911fE843772C40148bFeC99cD59919f", "0xE4541cc49d4AF3F231B0Ef5A77763A3886712D9E", "0xF43e2F4f93a70BA37c8e8c35C3d1E6a7Ecfe8464", "0x2B49f6a9B2bC1BC55F333720CfF3adEB91D01913", "0xb6bAaC2A81a90a61d94b03EBf9B40a5d733fCb05", "0x5917208B1Af9f964277E434edeEA1d254A52Ba75", "0xCa8b656313E16c6AAe29b7aB629700186A52aB54", "0x0b67b09D7faAD12D974b7C57a6Eaa92118CBc9Bb", "0x11818eb8Dba082f6E28Fa0Fb398a9E81e6C73099", "0x5769F573f727491bE5DEeB0B5214FceC2A12439e", "0xf34147Dfe8C97B65dA5E3402665E3Bb3561fa90A", "0x0b5eF55fa1539Ab69b195483aF5d98aE8892ffeF", "0x7c49665f601FC9d13532B4e57e557EE7679b868A", "0xb54C3DCf6922479b01535ec9578c545308270464", "0xc85306DB94659182BEc5B735Cd70824ee079E290", "0xdff0c6C16183ACf27349D20277EFd75069C7F779", "0x10D1b6046c98b406529fa2b82b873025A03780E4", "0x002152d1b790DeBf0456B0086294F44ae87B7F63", "0xC17433649458Ba80f418fd48E615E9d257794968", "0x196f093f2ea13814a5a4ED409fB70e464a94Fd16", "0xb7B30B7f85938FbB38Ee7BF67003a7EC3De4bF6f", "0x2bF2D7368afFAab776d81f3caD285dd8d1709d6d", "0x047A56Bb52836dBf10D0f7E776B534a7b18B5F43", "0xAc11De2fd895A9142fC2442404f77A546De7f951", "0xCF4FB8C1A1466eD59beA61Fc228a5e3253A87cd1", "0x7a37B1A88857CA07748f93B699890deE413848Cd", "0x673D75EE790F1F1A3444d6701f3D9c86883FAB9f", "0xdC57f9D8faB3AB72232B5f0a22485BA803c39Db9", "0x4000fc17405BA4EFfd35ef96a6638B53400cb7Dd", "0x19c039acbA6bdc41FbD133176253E8117924C7D1", "0xb8e8dAb9Fe22AE80BB85581bC177861bB42f1Cb7", "0x1442Aae751C95650B63c54F634a657aC5F35C739", "0x796d066BAe23e8c6Aa43Ab205c98584737504997", "0x3f11FC9B45bD36222012b0e08108255F3D6095FF", "0xEb667b11C2Dc86329b95b785E583304a83782b3F", "0x180F50CfE192CE8B5BDcFBb6eE2D0c0eEf3f5102", "0xDdcC8ebfc3b2d711A96dA87377716FB23FdD6E03", "0xFEc4A0Da542E582F827916B1e252eec9d7383376", "0x5191f12B9487c30ECB6EBd6A8Cfa744d78d707EB", "0xEe3327D0Ccc1f04026816D75E098405675E51F6E", "0x7675A9F900597AB0BEc3b4806b5BEeC7A296a964", "0x87B3F377D754BC8927905F0084DFb46Eeb1A969B", "0x763C7e608357d4efF41BDa0899401d92082cdef6", "0xB4C552c7944242704573BE6438E23930e901e8ad", "0xe80A478f6384D06D622B694d24faeAfAf6feDFd0", "0xe080AC6be764E80555e4cB1af4005Bab5E8D5Eb0", "0x120dA28553a05454F2390A6CE94a0060663CFF6c", "0xe7458bd09313cdABf651C8FB8F33038A5d724f73", "0x7194210fbD35B97b861aFb593c7832C201e1d149", "0x56DC4Eee59ADed33C4842a76aE9c4111fD335A08", "0x86B63193D4e39757fD53B55C6f93984d61391f61", "0x3b9F5b65Ee3Df58971E13C55EcA57d471709Df50", "0x7Eefbf2c95A570A00a17c3bf850594c17bFC6C8d", "0xD519c5FB617824Db833EF0f06dA9E78fb7B9a12f", "0x14aF54A533ac534f2Cf2482430C8515843Ea1C65", "0x0613941CE79a9161E4873Ffa5C119c9246aA4A39", "0x5675430C291fb9414AD54a4d2E490249679c8F2E", "0x176eB9A22D79eE0F54C5F9036f96290190eAC94a", "0xac0e553A39159dD14fbB55EF7b3A0850C805DDB8", "0x5064c52F5C13D7100aE028Ed1B720F541b3cFaac", "0x951a72CBdD98548fCB3FCD40EdC4356Ca24546F5", "0x6924CdB6DEfa533004fa8B6CCCDd116468505a90", "0x532FB8d8f4dc28F6D633E4B8d158703e74A00781", "0xa89a22472c4C30D05561ec23d1214bF6F3ca5EB5", "0xb092a5aBAfEA74F2d2a91aD1e8AaD0086013D79A", "0xa9CB2db763f9E2822dD7F51777d88f77a9Bb6149", "0x987A0301BDC83fdC2801E203A259B9bbBAcE345E", "0x3968755435dE43E94174E8D123987EF3B3b267f9", "0xc939bCd98788eAD658e13c2c6271c19f87c72621", "0x9cb5eD2A397ce286a5C2144d594Cdb46F6019BDB", "0x11130E6ED3E419c2cEDEbd0D0105C1240e98d8a8", "0x9d2B01841Ed486f48E8ebC0057223B0D9dDE2c68", "0x0d4b8C542d51b66b697C408c38224aCE81d35B69", "0x1c992DE6F0C8a589e08347c4DA0cd036Ea9C820B", "0x8c4A7Af20d4826305120280524b527Ff7778c67C", "0x886705Bdb7e0D70Af09Cb06aC365b68203580690", "0x96C4fa0Db2457Aa26374ac16bAEcdd2b98cCa655", "0xCBd501d5072374EB5ff4bD29b56D8845Cd8c7801", "0x61CE5F7f6CcC5EA2E2685A0Ae582DB2D0485C66B", "0x65e7c4491aE72559521375416F7de669Cff6d185", "0xD7EB64573B323F8EafcC9d140A4B83651A0Bc524", "0x96484F2550dcba2456C63b4e6000cA9d97e3ace4", "0x694cf45aC0C9e093eD6c4eC1C3093703800F7C74", "0x5a9A90De0ee638A7eEeFa86AcFeB3992947Fc842", "0x6A7FBaa1E250d4CDB661c12CB2d5F55D5091CA37", "0xd7c5c9028A29Ca63aCC65Aee9162f578FcFe037C", "0xf64C86749686aBFE9640F9E949807793FC96cd73", "0x7328c306058C7368613EcD1485425819573127B6", "0x653062b85b7Cc24165FC4a8aC9ae9c6DBa6dA7B2", "0x2C694e9206d0E8A56F4ec7c5B77a4f68CE3FA9E3", "0xd945413dAE04028b01746Dc204477B5f3762F05A", "0xab58B32bCB02520bf1d63b82e62B97E485Dd49e2", "0xD2f99D66791128e8653Be5bb90f2cDd4Ac701a59", "0xcee9f23da377494747D73f671031Df99E993977D", "0x99dB8f34393C3EDDe4B26E087eD0D495AE1cbAd7", "0xEf58321032cF693Fa7e39F31e45CBc32f2092cb3", "0xEd7c208CD2994CF6d579345E86DEF5c819A1497C", "0xf53C2d61A8b51DFC57dC55F2FA24412c66d989a6", "0x03743C12444D7A9F30D942Eb5aD103B4Cb13EEFA", "0xe1e77E68da2d8aa344F7c7F0b55d1969b3E3b2BB", "0xaf5C040b2fd2185e6aAa1a6B712ba92bbFbCa65B", "0x9d34C3Ecee1B70239e94fdDA28bB9f1ec96344dD", "0xd93212C338e10D5C251b1aC9b717093119eb6CD0", "0x94E2ad87c898900F87c0636213b6822260C601D6", "0x1a868691f207ACed20dC488942e3FA83ADd8FBB8", "0x6732D40000EF5850c97Cb11ab7FecFa20094B385", "0xeeFC1227112447cC9471a2C74Ef37c8E18c160c6", "0x0713A2F9E0ddFa7Ea9728974870D47efb706FAf1", "0x746C92F3CA41fa8c53a31eF8A4DbAa268BB1144b", "0xB43780D0B6dD4538cAF16F6A9D3fF5695568cDF2", "0xeD7d7ad6e309E833160Ee7E88B934dD6A995b6B8", "0x9066375979A93455cA609bE7C15457ADDC846E4e", "0x200c0C4D4c4AF29DBB29CDc78A408AEb23dAeAD7", "0x01dEc1be2156054d3f6C77235D032e35425ef0ce", "0x9B5202eB6128F4c5240b87ae34676a85Ce6A2ACa", "0x9136E32ed0b5cbBd25A69AA08D5B9BA7FDd32587", "0xd0bA2bf7C14e6c06Cb05d39216F78e56707BC711", "0x8386D2b9aA2F77029D6618E79028FF3A3554a808", "0xC32D1E09b68953355BA1faD88B247399e3F77d98", "0x267F6dA0B2da89e365157eCDA8102095CFD9580B", "0xb6B629976253698319067737dFe1f464f7Cc79cE", "0xC2A9Abc05987Ab28d6Ae1dA347a19553a530A2D1", "0xa0feb13b95F692F314e014b932A312CB43Ee62DF", "0x9a1069E24961b696d107413C76346eeE02EF296d", "0xFC35032Ca12a4Eec84f40630a53D73dBb6aD9c84", "0xb94a677371FA8d25C452e613dE3505CDA1D6cf1F", "0x541e350501dD562d2e6d61ef0B60050Eb11C09E7", "0x16a5171223ACc848De45A87733026198cc64Eddb", "0x3833F8DBDbd6bdcb6A883FF209B869148965b364", "0x5aAf4b30F92e9625092DD221621D0caB55077a95", "0x5Baa44DfeAeD6354C394D8AE448B9D367e237254", "0x292B760F76A02e30281477976aa905858C40fe6E", "0x40E72e652420D360DC2595AB145C7a308F85eAF2", "0xb6c3e6a645f105EFaE04d3332D3Af259868E8e83", "0x1520912C45F3a6AdBA46f3ed14A2586F032465D8", "0x5bb3B225B4A24A95C34A90f6029c6e3D4E065a90", "0x8ecD1010D39C842c61d9E94B0eAC3d9D0377D65d", "0x1Eaa5661d3A46bf33cE3e95b41B5F85A7fD320D5", "0x14605D27Fc0F0F30021D317E8b819eCbDd2e45CF", "0x173448386903DDB117C1da2d3aD193bbBa73E4Be", "0xb4a6D7029F419AE628509195b834065D723859EB", "0xBe4176dbcC14fFF3AbD40F85e77108dAD67F28F8", "0x40B1b265Bf4D2202C3345232d6Bb24265a83eb1A", "0x9fdce9399EF34702A9D70E6816ceE3d7Ef75e473", "0x4d2008aDe516862E0a7Ba69B0ab0537ac130f898", "0x9EA3C7a23e958415597DA11497CEE5eb0409838a", "0xeF6274BB851C1f56f699D4a4B167a4764599095D", "0xb36d801a84cAD61A06A777cFb53Cb8F57fca4674", "0xA2c58BAB8C7405a282559a68C7086c915217ada4", "0x5De5B13121eD7f5a32793Dc6b97bE201B8f6D732", "0xf742AFC5561e857D895eE22198bb198686af14b2", "0x42eE47F542aDD4C349465BE8f045b79e731d371b", "0x199b31E245Cc9d22a8209Ea867A5b747B0174144", "0xF2C94748C523F5A5Be87C4237E139Fe1816c7eF1", "0x9042b0a3E55D8438D098e7877A444f6f9Aeb72f5", "0x488Be1890C054674837554750bE29d0D6B88D695", "0xa5b1C9Cd0f6318931F00b8c51449aC06E94DAa44", "0x107AaB77da84Beb1dB4d1cBa2686c66c63F19628", "0x7aad6e2c3885BfB22a19f0FA0E19B05ffC68e8a9", "0x1cb002Ad89E5f3fD06a5E1BA67597a6ab432E137", "0xD178bDA9571B0Df49399724F6050B12BbBAe1B92", "0x36fF4903D66C5Fed5d6b8bd1ab985cDdc3ADCBc5", "0x73e75Fa2ec638393b6512474412b88A4bCC1051B", "0x89d80da44F29d8e53055171A60D5027f6debCf43", "0x34dEbc2b82dA90E2eB9D60152C537df0Af55EEB9", "0x79c9fE695a5F34634BEc31D9111B9aef5F9ee5b2", "0x92753c89707435954bDf567aC8cf99C7E69CfA5A", "0x1DcFd2C1B97E92F7277107bfb6cF82E2DCf62Fc1", "0xdDd8582D3AafA16eD62DC394F37Cba3C2Bb92311", "0xEbf5c85Fe4B24601F5851a898f78C53ea57b6351", "0x397dBD9eB04B7af74831567322Ed4E1c8232E41D", "0x6a762579E6300B195D8ce1C7DFcc9E18a70a7cBb", "0x44B4EedaA08c61507c798FFef8E669b1b64b4Fd6", "0xA79d5277B3E02D593F9B90D52f0fc76658468F8B", "0xDA724AB5Ba9De3853Fa8C95eF63e1139F287f713", "0xEd5467A43b41525EC92ea33043b6Efd677EF90dA", "0xD35184b3fb9B3376e4Af80F41C6AB012A9f81f79", "0x580a408dc5D06032Bbd0b938eabDa14d845451C3", "0xa8175BD7cEeF06FFE631e284bEfA7dEA8e0CDb16", "0x60902F909E6428c63935991Ae6B101C75Fc7Eca8", "0x1deCF5Aa54faFF410d5047930c7C138312d82760", "0x4eeB026FD859D51c6aeb0CC9E5068365EB575051", "0x151936E6BD7000174AB38af53134d81e46652dFC", "0xF30319ea1817F48724e8bFcD04a4817A4A78f93a", "0x5D4C6a07eB1d3474Bd44aCF8B9e15c673ff59B4A", "0xE422244b54A5c6ab91146bc409dE5b65522b9e3B", "0x2fd0458bD985aa01031c3615769d2827AE18024B", "0x4c76fE34087e43f4070d29735B02FB06ae667788", "0x208e6feaa925324C48DBC002CA1Abf6895D12450", "0x90683276d0182069708abF14EfEE39439bE8BC71", "0x63bD01c310c2c645d929Cc59c20acbe4AA71F872", "0xf54E3D79A8e236c2851578Dd26b8F3c52F2bA92D", "0xad4Ca3FB1C39Bc3FC7904D80AE09ED8399E63898", "0xDD6ec9f00A15A151E8B0F582930CF850a1D075EC", "0xD5D234655D1E8E2899aA8F6427de7E912654be7e", "0x80bee60B7d7696079426B0cb03E3094a642E99D3", "0x9E8A75fD5847e4606Ea23F56CaecE213b3278E13", "0x249e7C9B5223c773aa5960e217e8d49da40c1037", "0xd662F5D05588AF7c38D7a1A2606898Cda86402C0", "0x757881c315e4f6DDB4dD91017e7C0bb7568CF646", "0x8D31Cc0231B20a573130A48FF2a2044E616A62BC", "0x08efBAfec9e03C0048E7A96df9b799a9F7747c71", "0x2d10eDaa7B9B683A4a8f8284BadB14E91E9A3272", "0x7D3f1D2deBf26F82Cf4e91769Dd74de508A7eBA5", "0x0D30f3e3292812aBD69EFc6af4f9DC3718fBE4Cc", "0xC5EE0E69B61a47a0DeE546704c55F10947238137", "0x976ef662ac98e5C96Cc95202A241f706673Ae305", "0xA8A8c9f403ba31f2270024A4FDA69fAc9d5A047A", "0xc75d9F381Ab0005E5c2385Be7aA52734bBcCbe45", "0x462C19cD5498EA9613F7B97dFEB7C2Ab5aB7da3d", "0xA285472849a80Fed60CC52055Bac492E082917e5", "0xb51Ce12FD1dA6Bff064dF2D5ec7f454Aaf942c82", "0xd94aDB8B31135b64C53Dcf4f91D595057751ccf0", "0x8E555443198317AC0A455a8A17Fed3d8E9A46b66", "0x1e814202ab10cfad800C43200D3daFcdcc921a1d", "0xfE01c61aADd4Fba7052484097E312f59FaD21691", "0xCD42C3E6937C92c1D5252159768801757AeBF73b", "0xfBe9B34C64F4dc000F9Bc132fCcDA552FA6581Eb", "0x78e3a387bD4cFaBcc466ba941185D0F690ddfA06", "0x9Ea33991242a7963df62232f2d6454c2787c5E83", "0xC85202837AFa3F29bB97e43DD59Aaad5B22dD565", "0x693150539D1B8811AE36dea588313EBe33BA24B1", "0x31222eB6c38FF5a1b8e98E15452B1c1F5Ae0cad7", "0xecd6A1D180baF455f1856C9f29916B923Ba89c86", "0xCa33241802904dF85E909c8F2Aa1FA9d49a2e5E3", "0x53eEF2fcd83F8E7A44C364252009782a6148A31d", "0x5Ed78A19e5C1b8BDAfC3D1e82cCDF23ea6C30406", "0x55FE9D8a70992963aF812A9b8C900700EFf17B7D", "0x070DA016f68A99985F48cFD0d2d5370466827a1c", "0x41C95B35ea7A665A7A0b91b44BC15a5a83fd7e8b", "0xB210473aB7333470f3Ff51FCf4466924985F6514", "0x34345A49d9Cf673fDC221501E8ee175d36EB1Adc", "0xaD67c9e9b643e1403B1C70A3816cBc0038c59Fe8", "0x09fbD56bFEFAD15e0c6Ee73Eb3C25676027e01F8", "0xC721da9A2D903558d1b008F36ad71a83045cACDC", "0xC86302e35af3a8cf48aFE8d25026ae239077792a", "0xf5cD89d72bFE947723cEF94d876bC44f400D9B2b", "0x006cFd76c553f5cf91d1F457862f627eB1A3F0Ff", "0x389AE20115182758B9aC08aa4ebb36BB7d6b9843", "0x37D114AbA7094134Be9Cd89DcCDB1eE705e28D51", "0x838eAa81C69deA9D1Da556d285501C5F7676D1e9", "0xbAb8321EE1568d94B50CD21682Cf9011057abf68", "0x63F311C2E5E4aa5f14D7d0a8cEfc657b640BE60C", "0x619B636a64EA02087E54b2DAeA77E1EfE4C8Cf79", "0x09De14e8f898df97977C365b379C7b62dE32DBB2", "0xB7050615fDc741075f5ec5B4474f535f9a2269Ec", "0x25A3904C5Eb5aA5c29F5d0C6d54daae8c74Eb59f", "0x64bcC61A3733beA091a407776103637379Cc4b42", "0x7B73FE5B4BCCcA8E778b9ee7fC4D04bfa6f8Bf13", "0x619b958E5a0D38776263e92C9F38b339A293dAc2", "0x1e4f75708dFe9A70B8fBb01ae85C3bE8737F7E28", "0xd9De3883D66edDcCf2aa459F155a0219c3837536", "0x6Cbbd990c24c1a16b48540a7733Ff270A9f6b85b", "0x2E97C909Bc9aacADe819E8c9484B8815903B0A22", "0x4ce56aEc927F18e91a4400B3195C51806487658d", "0x412e942BE5eC1aA28ec52989eE20A595d0c77B57", "0x64bE227c3EF62EfaE69008d16c8d8eb3012f5834", "0x40aF76054e0Bdc875772b4e03DDaB1176BB7962f", "0xF75f4946704236A29f1B28F6e24Fd9f55D5AFE14", "0x9678e6B4e66ef464F44824017B314dCBBD5f39E2", "0x3d8BE603d1374C1aD4FC776883370F215EaaCcF5", "0x297E856623F6f8164c399e530516C63c15B3436c", "0x43Ee5950ba2340AEc78DaDe90be894C92CB437D9", "0x83A77d44218fc06755e696AdF1486dFfa1922174", "0x907dAE11026946385Ea5a906CC988eAa097A767B", "0x213Cd4339b958aA62933f5651da380D3b3923720", "0x17687c090a15Ef27Cd4592cF05044CC69bAf5c20", "0xEB66af50e9209067d0919894EccbbdB426Ab6EDc", "0x466953Cc0ef335Bfd5Afc24ff989d215a1d36951", "0xf08B9d4b54E145d99f8739aF0A594253eB60b749", "0x76b790BB8c60906e664A314a8eF0687EA189e56E", "0xDeA6f7C29Eebe56Ba61E6A8Fac9201DB798E1a46", "0xEa6dB815322E32E84b5c3f8b93CE9d35c0faE3d9", "0x930f092E7192F58D96f41b8FE417621c1b4EF472", "0xCF14DF97D67bc9D5Cd5dFE89198fCC6e5BC4C4Fb", "0x2F81363Ed4c2Aff368eA80A08DC935e39BD7D4BD", "0x3707D0B7EB1A3e70E2a892aAD4938be493b053Ef", "0x0C725194A56638c67367FeEF86aEda4cd6A1dC73", "0xfB83ec491522553F6CB1c0b37BCAa1bE64EBB65B", "0x35F806a9513E6D37Aff8957Eb951FD65a0F4b774", "0xAE71a717175B920b597Bb905E88165a2eB9327Cd", "0xf5faC5a5e9d5eEDad09EdDD8B04d0e2B642E82fC", "0x8dBDD9e25f15a0012F31eAA3F50Be6775AbA786d", "0x8895195dC8a9e61F6c10f29799910D454ca8Ca69", "0x141CF68Ad37F924Cfe7501caB5469440b96AB6e3", "0xb96523e36aC8A71eFc33e096338ba75dFFac17B6", "0x989a706cD6D4C7d20770aBFe9f1C94597037FD87", "0xc2c153E05C9671bb7C9C4ca7c4bbABeb4Cf1Ae87", "0xDd76E696DB3DEe9d5e9cF24233036010e60DEEff", "0xe1827e4842966643e59c802212bb60598Ae29C63", "0x6a72FEF73DBcB6287a3b98769a2ce26D41a35af2", "0x95ABCa1A49134dDd9bE33b45005D285b292f66f7"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_value", type: "uint256"}], name: "getPresaleTotal", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tokensForSale", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_value", type: "uint256"}], name: "getTotal", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "icoState", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "presaleSold", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tokenLimit", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "team", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_pktValue", type: "uint256"}, {name: "_sold", type: "uint256"}], name: "getBonus", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "pkt", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tokensPerEth", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [], name: "RunIco", type: "event"}, {anonymous: false, inputs: [], name: "PauseIco", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "team", type: "address"}, {indexed: false, name: "foundation", type: "address"}, {indexed: false, name: "advisors", type: "address"}, {indexed: false, name: "bounty", type: "address"}], name: "FinishIco", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["RunIco()", "PauseIco()", "FinishIco(address,address,address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1f96d9685921236d8b8fc404794445857b6b79b853b606d547ab3cb4878d0d72", "0x8bb4b9f09f7571abfa7c9f11ae39a25d6b4c6f0798a3fe2c7c7d708f4edefebb", "0x071b7e732f3f893bbba6721ad45e689f7d87ebecb171b124c1219a924a5b528c"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4457684 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4468318 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_team", value: 4}], name: "PlaykeyICO", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_value", value: random.range( maxRandom )}], name: "getPresaleTotal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPresaleTotal(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensForSale", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensForSale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_value", value: random.range( maxRandom )}], name: "getTotal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotal(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "icoState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "icoState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presaleSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presaleSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "team", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "team()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pktValue", value: random.range( maxRandom )}, {type: "uint256", name: "_sold", value: random.range( maxRandom )}], name: "getBonus", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBonus(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pkt", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pkt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensPerEth", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensPerEth()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PlaykeyICO", function( accounts ) {

	it( "TEST: PlaykeyICO( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4457684", timeStamp: "1509364528", hash: "0x2c0d62c5051d2fd9a49e8eff868bac3451e0677c52e571c535a12a49cf6c27af", nonce: "0", blockHash: "0x98c1fc66f0205f83bfe553c0ae4904d56deb11e45cda6a70a3fb64788416a5e4", transactionIndex: "50", from: "0x8abdf2ab2f5d76c3cac045eb25ee54fff721787c", to: 0, value: "0", gas: "4000000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe8fa9c3f0000000000000000000000009e02445768dd6fbe9341f9491b03517ef890cbc3", contractAddress: "0x26d08b9d227933a85e855656dc46ab889e183c88", cumulativeGasUsed: "6139484", gasUsed: "3675131", confirmations: "3274191"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_team", value: addressList[4]}], name: "PlaykeyICO", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PlaykeyICO.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509364528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PlaykeyICO.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[5],addressList[5]], [\"3750... )", async function( ) {
		const txOriginal = {blockNumber: "4462829", timeStamp: "1509436903", hash: "0x0125491b70c354a74797b8e8c5377f1c0b8066938a16201048e6a3977428fe35", nonce: "0", blockHash: "0x67764247ed170132b1d75dfa0d20797c297cffa22a3347e2eb865bf10a8ae70d", transactionIndex: "77", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000002000000000000000000000000e8d5b64163ba28cba2b23eb6ce3b12d91b7537bc000000000000000000000000e8d5b64163ba28cba2b23eb6ce3b12d91b7537bc0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000002086ac35105260000000000000000000000000000000000000000000000000002086ac35105260000", contractAddress: "", cumulativeGasUsed: "6124993", gasUsed: "119083", confirmations: "3269046"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "_values", value: ["37500000000000000000","37500000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[5],addressList[5]], ["37500000000000000000","37500000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509436903 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[6],addressList[7]], [\"7200... )", async function( ) {
		const txOriginal = {blockNumber: "4462881", timeStamp: "1509437603", hash: "0x81e873ec9c0b6189ba32a289267dfa13e35a6714855b88488911b1d15ec18a8e", nonce: "1", blockHash: "0x9d2249bd35e2b06ebe32117a3b0503254e27d03bfd936905b1402ba2450bbecf", transactionIndex: "67", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "105000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000200000000000000000000000092d99fa62911fe843772c40148bfec99cd59919f000000000000000000000000e4541cc49d4af3f231b0ef5a77763a3886712d9e000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000063eb89da4ed0000000000000000000000000000000000000000000000000000063eb89da4ed00000", contractAddress: "", cumulativeGasUsed: "5790790", gasUsed: "103955", confirmations: "3268994"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[6],addressList[7]]}, {type: "uint256[]", name: "_values", value: ["7200000000000000000","7200000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[6],addressList[7]], ["7200000000000000000","7200000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509437603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[8],addressList[9],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4462913", timeStamp: "1509437984", hash: "0x72f3fcdc34ac789b178538c11177938ff5b7def982f86fbee1545a2b93037443", nonce: "2", blockHash: "0x0718433ed00d8d0038cc701d89d51e54edac92c797bbaec112dd8afebc0efce4", transactionIndex: "55", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "1441999", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000004c00000000000000000000000000000000000000000000000000000000000000023000000000000000000000000f43e2f4f93a70ba37c8e8c35c3d1e6a7ecfe84640000000000000000000000002b49f6a9b2bc1bc55f333720cff3adeb91d01913000000000000000000000000b6baac2a81a90a61d94b03ebf9b40a5d733fcb050000000000000000000000005917208b1af9f964277e434edeea1d254a52ba75000000000000000000000000ca8b656313e16c6aae29b7ab629700186a52ab540000000000000000000000000b67b09d7faad12d974b7c57a6eaa92118cbc9bb00000000000000000000000011818eb8dba082f6e28fa0fb398a9e81e6c730990000000000000000000000005769f573f727491be5deeb0b5214fcec2a12439e000000000000000000000000f34147dfe8c97b65da5e3402665e3bb3561fa90a0000000000000000000000000b5ef55fa1539ab69b195483af5d98ae8892ffef0000000000000000000000007c49665f601fc9d13532b4e57e557ee7679b868a000000000000000000000000b54c3dcf6922479b01535ec9578c545308270464000000000000000000000000c85306db94659182bec5b735cd70824ee079e290000000000000000000000000dff0c6c16183acf27349d20277efd75069c7f77900000000000000000000000010d1b6046c98b406529fa2b82b873025a03780e4000000000000000000000000002152d1b790debf0456b0086294f44ae87b7f63000000000000000000000000c17433649458ba80f418fd48e615e9d257794968000000000000000000000000196f093f2ea13814a5a4ed409fb70e464a94fd16000000000000000000000000b7b30b7f85938fbb38ee7bf67003a7ec3de4bf6f0000000000000000000000002bf2d7368affaab776d81f3cad285dd8d1709d6d000000000000000000000000047a56bb52836dbf10d0f7e776b534a7b18b5f43000000000000000000000000ac11de2fd895a9142fc2442404f77a546de7f951000000000000000000000000cf4fb8c1a1466ed59bea61fc228a5e3253a87cd10000000000000000000000007a37b1a88857ca07748f93b699890dee413848cd000000000000000000000000673d75ee790f1f1a3444d6701f3d9c86883fab9f000000000000000000000000dc57f9d8fab3ab72232b5f0a22485ba803c39db90000000000000000000000004000fc17405ba4effd35ef96a6638b53400cb7dd00000000000000000000000019c039acba6bdc41fbd133176253e8117924c7d1000000000000000000000000b8e8dab9fe22ae80bb85581bc177861bb42f1cb70000000000000000000000001442aae751c95650b63c54f634a657ac5f35c739000000000000000000000000796d066bae23e8c6aa43ab205c985847375049970000000000000000000000003f11fc9b45bd36222012b0e08108255f3d6095ff000000000000000000000000eb667b11c2dc86329b95b785e583304a83782b3f000000000000000000000000180f50cfe192ce8b5bdcfbb6ee2d0c0eef3f5102000000000000000000000000ddcc8ebfc3b2d711a96da87377716fb23fdd6e03000000000000000000000000000000000000000000000000000000000000002300000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000082f8bc3f7bbfc00000000000000000000000000000000000000000000000000000031bced02db000000000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000003a6ab442a168f00000000000000000000000000000000000000000000000000000314b3d2e4230000000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000257853b1dd8e000000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000001442f643bc120000000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000000b011a5de6c70000000000000000000000000000000000000000000000000049b9ca9a69434000000000000000000000000000000000000000000000000000000ee08251ff380000000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000340aad21b3b70000000000000000000000000000000000000000000000000000002c7b7fb354a1c000000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000000853a0d2313c000000000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000033dc4ac4d18700000000000000000000000000000000000000000000000000000b564b2d3808400000000000000000000000000000000000000000000000000017eac0c50e15400000000000000000000000000000000000000000000000000000e35fa931a000000000000000000000000000000000000000000000000000000c3663566a580000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000415659389416e000000000000000000000000000000000000000000000000000494654067e100000000000000000000000000000000000000000000000000000101cf81b475fa0000000000000000000000000000000000000000000000000002231e2f1f69000000000000000000000000000000000000000000000000000002d8c9de616fd800000000000000000000000000000000000000000000000000bc9960ff418f000000000000000000000000000000000000000000000000000340aad21b3b700000", contractAddress: "", cumulativeGasUsed: "3404606", gasUsed: "1441999", confirmations: "3268962"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42]]}, {type: "uint256[]", name: "_values", value: ["200000000000000000","151000000000000000000","14000000000000000","500000000000000000","67350000000000000000","222000000000000000","100000000000000000","2700000000000000000","500000000000000000","1460000000000000000","100000000000000000","49559000000000000","85000000000000000000","67000000000000000","10000000000000000000","60000000000000000000","200330998000000000","5000000000000000000","600000000000000000","250000000000000000","10000000000000000","1000000000000000000","233559000000000000","51057690000000000","107712610000000000","4000000000000000","55000000000000000","1000000000000000000","294253035000000000","330000000000000000","72567225000000000","154000000000000000","205135740000000000","13590000000000000000","60000000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42]], ["200000000000000000","151000000000000000000","14000000000000000","500000000000000000","67350000000000000000","222000000000000000","100000000000000000","2700000000000000000","500000000000000000","1460000000000000000","100000000000000000","49559000000000000","85000000000000000000","67000000000000000","10000000000000000000","60000000000000000000","200330998000000000","5000000000000000000","600000000000000000","250000000000000000","10000000000000000","1000000000000000000","233559000000000000","51057690000000000","107712610000000000","4000000000000000","55000000000000000","1000000000000000000","294253035000000000","330000000000000000","72567225000000000","154000000000000000","205135740000000000","13590000000000000000","60000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509437984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[43],addressList[44],address... )", async function( ) {
		const txOriginal = {blockNumber: "4462922", timeStamp: "1509438154", hash: "0x4c1bbe69a0933e98e99899ffb6fc6c28a4e243d674e0a15419b1a935e7603bee", nonce: "3", blockHash: "0xa0ae97cec697732f2a7fa562737456a785f244fe73e6adcdd5137dfa1da71d4c", transactionIndex: "41", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "1442686", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000004c00000000000000000000000000000000000000000000000000000000000000023000000000000000000000000fec4a0da542e582f827916b1e252eec9d73833760000000000000000000000005191f12b9487c30ecb6ebd6a8cfa744d78d707eb000000000000000000000000ee3327d0ccc1f04026816d75e098405675e51f6e0000000000000000000000007675a9f900597ab0bec3b4806b5beec7a296a96400000000000000000000000087b3f377d754bc8927905f0084dfb46eeb1a969b000000000000000000000000763c7e608357d4eff41bda0899401d92082cdef6000000000000000000000000b4c552c7944242704573be6438e23930e901e8ad000000000000000000000000e80a478f6384d06d622b694d24faeafaf6fedfd0000000000000000000000000e080ac6be764e80555e4cb1af4005bab5e8d5eb0000000000000000000000000120da28553a05454f2390a6ce94a0060663cff6c000000000000000000000000e7458bd09313cdabf651c8fb8f33038a5d724f730000000000000000000000007194210fbd35b97b861afb593c7832c201e1d14900000000000000000000000056dc4eee59aded33c4842a76ae9c4111fd335a0800000000000000000000000086b63193d4e39757fd53b55c6f93984d61391f610000000000000000000000003b9f5b65ee3df58971e13c55eca57d471709df500000000000000000000000007eefbf2c95a570a00a17c3bf850594c17bfc6c8d000000000000000000000000d519c5fb617824db833ef0f06da9e78fb7b9a12f00000000000000000000000014af54a533ac534f2cf2482430c8515843ea1c650000000000000000000000000613941ce79a9161e4873ffa5c119c9246aa4a390000000000000000000000005675430c291fb9414ad54a4d2e490249679c8f2e000000000000000000000000176eb9a22d79ee0f54c5f9036f96290190eac94a000000000000000000000000ac0e553a39159dd14fbb55ef7b3a0850c805ddb80000000000000000000000005064c52f5c13d7100ae028ed1b720f541b3cfaac000000000000000000000000951a72cbdd98548fcb3fcd40edc4356ca24546f50000000000000000000000006924cdb6defa533004fa8b6cccdd116468505a90000000000000000000000000532fb8d8f4dc28f6d633e4b8d158703e74a00781000000000000000000000000a89a22472c4c30d05561ec23d1214bf6f3ca5eb5000000000000000000000000b092a5abafea74f2d2a91ad1e8aad0086013d79a000000000000000000000000a9cb2db763f9e2822dd7f51777d88f77a9bb6149000000000000000000000000987a0301bdc83fdc2801e203a259b9bbbace345e0000000000000000000000003968755435de43e94174e8d123987ef3b3b267f9000000000000000000000000c939bcd98788ead658e13c2c6271c19f87c726210000000000000000000000009cb5ed2a397ce286a5c2144d594cdb46f6019bdb00000000000000000000000011130e6ed3e419c2cedebd0d0105c1240e98d8a80000000000000000000000009d2b01841ed486f48e8ebc0057223b0d9dde2c680000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000a688906bd8b0000000000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000087536d3bbf94ef07300000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000011344a184a99e84000000000000000000000000000000000000000000000000000340aad21b3b7000000000000000000000000000000000000000000000000000000192baeb3495d8000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000009082da0432bd5000000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000001d3c7ce58992be0000000000000000000000000000000000000000000000000029a2241af62c00000000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000004e1ae50666326800000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000494654067e10000000000000000000000000000000000000000000000000000001c6bf5263400000000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000005543df729c00000000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000008940ab702de0c000000000000000000000000000000000000000000000000001f399b1438a100000000000000000000000000000000000000000000000000000d7ae6a39aa008000000000000000000000000000000000000000000000000036afb0b73bb9a8000000000000000000000000000000000000000000000000000015b1cfd7ee7780000000000000000000000000000000000000000000000000000f8b0a10e4700000000000000000000000000000000000000000000000000000de03a8e4560f8000000000000000000000000000000000000000000000000002ec4a5251d110000000000000000000000000000000000000000000000000000027f7d0bdb92000000000000000000000000000000000000000000000000000001ddbecca281bc000000000000000000000000000000000000000000000000000186cc6acd4b0000000000000000000000000000000000000000000000000000058d15e17628000000000000000000000000000000000000000000000000000002df359ddc0848000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000006f05b59d3b20000", contractAddress: "", cumulativeGasUsed: "6247181", gasUsed: "1442686", confirmations: "3268953"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77]]}, {type: "uint256[]", name: "_values", value: ["12000000000000000000","250000000000000000","156020123545151402099","500000000000000000","5077800000000000000000","60000000000000000000","113358460000000000","8000000000000000000","166610000000000000000","500000000000000000","2106696051000000000","3000000000000000000","10000000000000000000","90049000000000000000","160000000000000000","330000000000000000","8000000000000000","4000000000000000000","24000000000000000","5000000000000000000","618130830000000000","2250000000000000000","971342260000000000","63049000000000000000","97703692000000000","70000000000000000","999863500000000000","3370000000000000000","180000000000000000","134473350000000000","110000000000000000","400000000000000000","206943060000000000","1000000000000000000","500000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77]], ["12000000000000000000","250000000000000000","156020123545151402099","500000000000000000","5077800000000000000000","60000000000000000000","113358460000000000","8000000000000000000","166610000000000000000","500000000000000000","2106696051000000000","3000000000000000000","10000000000000000000","90049000000000000000","160000000000000000","330000000000000000","8000000000000000","4000000000000000000","24000000000000000","5000000000000000000","618130830000000000","2250000000000000000","971342260000000000","63049000000000000000","97703692000000000","70000000000000000","999863500000000000","3370000000000000000","180000000000000000","134473350000000000","110000000000000000","400000000000000000","206943060000000000","1000000000000000000","500000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509438154 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[78],addressList[79],address... )", async function( ) {
		const txOriginal = {blockNumber: "4462938", timeStamp: "1509438435", hash: "0x564347db2a4d06bca9504b52d9c2c75feccd7ab16a02679d92763ce39bc7240d", nonce: "4", blockHash: "0xce8b6767b0128f80c17c87204e7040a8a1493a0001ead6cc8fbda6a8eb4fe6fa", transactionIndex: "73", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "1443047", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000004c000000000000000000000000000000000000000000000000000000000000000230000000000000000000000000d4b8c542d51b66b697c408c38224ace81d35b690000000000000000000000001c992de6f0c8a589e08347c4da0cd036ea9c820b0000000000000000000000008c4a7af20d4826305120280524b527ff7778c67c000000000000000000000000886705bdb7e0d70af09cb06ac365b6820358069000000000000000000000000096c4fa0db2457aa26374ac16baecdd2b98cca655000000000000000000000000cbd501d5072374eb5ff4bd29b56d8845cd8c780100000000000000000000000061ce5f7f6ccc5ea2e2685a0ae582db2d0485c66b00000000000000000000000065e7c4491ae72559521375416f7de669cff6d185000000000000000000000000d7eb64573b323f8eafcc9d140a4b83651a0bc52400000000000000000000000096484f2550dcba2456c63b4e6000ca9d97e3ace4000000000000000000000000694cf45ac0c9e093ed6c4ec1c3093703800f7c740000000000000000000000005a9a90de0ee638a7eeefa86acfeb3992947fc8420000000000000000000000006a7fbaa1e250d4cdb661c12cb2d5f55d5091ca37000000000000000000000000d7c5c9028a29ca63acc65aee9162f578fcfe037c000000000000000000000000f64c86749686abfe9640f9e949807793fc96cd730000000000000000000000007328c306058c7368613ecd1485425819573127b6000000000000000000000000653062b85b7cc24165fc4a8ac9ae9c6dba6da7b20000000000000000000000002c694e9206d0e8a56f4ec7c5b77a4f68ce3fa9e3000000000000000000000000d945413dae04028b01746dc204477b5f3762f05a000000000000000000000000ab58b32bcb02520bf1d63b82e62b97e485dd49e2000000000000000000000000d2f99d66791128e8653be5bb90f2cdd4ac701a59000000000000000000000000cee9f23da377494747d73f671031df99e993977d00000000000000000000000099db8f34393c3edde4b26e087ed0d495ae1cbad7000000000000000000000000ef58321032cf693fa7e39f31e45cbc32f2092cb3000000000000000000000000ed7c208cd2994cf6d579345e86def5c819a1497c000000000000000000000000f53c2d61a8b51dfc57dc55f2fa24412c66d989a600000000000000000000000003743c12444d7a9f30d942eb5ad103b4cb13eefa000000000000000000000000e1e77e68da2d8aa344f7c7f0b55d1969b3e3b2bb000000000000000000000000af5c040b2fd2185e6aaa1a6b712ba92bbfbca65b0000000000000000000000009d34c3ecee1b70239e94fdda28bb9f1ec96344dd000000000000000000000000d93212c338e10d5c251b1ac9b717093119eb6cd000000000000000000000000094e2ad87c898900f87c0636213b6822260c601d60000000000000000000000001a868691f207aced20dc488942e3fa83add8fbb80000000000000000000000006732d40000ef5850c97cb11ab7fecfa20094b385000000000000000000000000eefc1227112447cc9471a2c74ef37c8e18c160c60000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000058d15e1762800000000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000000083d00de25d1800000000000000000000000000000000000000000000000000001c6bf52634000000000000000000000000000000000000000000000000000001b88957d0260000000000000000000000000000000000000000000000000000011c37937e0800000000000000000000000000000000000000000000000000001f689fb913956c000000000000000000000000000000000000000000000000199546c5b8bd467381000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000ab252046153ba5e300000000000000000000000000000000000000000000000b8bf8037a4634000000000000000000000000000000000000000000000000000340aad21b3b7000000000000000000000000000000000000000000000000000000429d069189e00000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000e3aa060264b9000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000002d33381a0994000000000000000000000000000000000000000000000000000f195a3c4ba0000000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000002faf1fcb983e0000000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000e35fa931a000000000000000000000000000000000000000000000000000340aad21b3b7000000000000000000000000000000000000000000000000000083d6c7aab636000000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000d87e55590018000000000000000000000000000000000000000000000000000029a2241af62c0000000000000000000000000000000000000000000000000008230e52bc722200000000000000000000000000000000000000000000000000000177d09893d03c00000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000340aad21b3b7000000000000000000000000000000000000000000000000000005dacd13ca9e3000000000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000268e396a913a2c0000000000000000000000000000000000000000000000000402f4cfee62e80000", contractAddress: "", cumulativeGasUsed: "4816817", gasUsed: "1443047", confirmations: "3268937"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112]]}, {type: "uint256[]", name: "_values", value: ["400000000000000000","5000000000000000000","37101980000000000","8000000000000000","124000000000000000","80000000000000000","2263234430000000000","471925103999999964033","40000000000000000","12332298640000001507","213000000000000000000","60000000000000000000","300000000000000000","1000000000000000000","1025308200000000000","160000000000000000000","12722690000000000","1088000000000000000","160000000000000000","3436000000000000000","100000000000000000","4000000000000000","60000000000000000000","152000000000000000000","8000000000000000000","15600000000000000000","3000000000000000000","150100000000000000000","105782470000000000","100000000000000000","60000000000000000000","6750000000000000000","50000000000000000","2778221150000000000","74000000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112]], ["400000000000000000","5000000000000000000","37101980000000000","8000000000000000","124000000000000000","80000000000000000","2263234430000000000","471925103999999964033","40000000000000000","12332298640000001507","213000000000000000000","60000000000000000000","300000000000000000","1000000000000000000","1025308200000000000","160000000000000000000","12722690000000000","1088000000000000000","160000000000000000","3436000000000000000","100000000000000000","4000000000000000","60000000000000000000","152000000000000000000","8000000000000000000","15600000000000000000","3000000000000000000","150100000000000000000","105782470000000000","100000000000000000","60000000000000000000","6750000000000000000","50000000000000000","2778221150000000000","74000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509438435 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[113],addressList[114],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4462947", timeStamp: "1509438490", hash: "0x43132d766407a4bc6e321b8562f1b10aa388f8cd1ba0abf64b5104f7d6cc6594", nonce: "5", blockHash: "0x64ab1888ff21fdac0caf8accdb83338fe774f14212fba4d4f2e9e4b2b9577b2b", transactionIndex: "43", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "1442938", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000004c000000000000000000000000000000000000000000000000000000000000000230000000000000000000000000713a2f9e0ddfa7ea9728974870d47efb706faf1000000000000000000000000746c92f3ca41fa8c53a31ef8a4dbaa268bb1144b000000000000000000000000b43780d0b6dd4538caf16f6a9d3ff5695568cdf2000000000000000000000000ed7d7ad6e309e833160ee7e88b934dd6a995b6b80000000000000000000000009066375979a93455ca609be7c15457addc846e4e000000000000000000000000200c0c4d4c4af29dbb29cdc78a408aeb23daead700000000000000000000000001dec1be2156054d3f6c77235d032e35425ef0ce0000000000000000000000009b5202eb6128f4c5240b87ae34676a85ce6a2aca0000000000000000000000009136e32ed0b5cbbd25a69aa08d5b9ba7fdd32587000000000000000000000000d0ba2bf7c14e6c06cb05d39216f78e56707bc7110000000000000000000000008386d2b9aa2f77029d6618e79028ff3a3554a808000000000000000000000000c32d1e09b68953355ba1fad88b247399e3f77d98000000000000000000000000267f6da0b2da89e365157ecda8102095cfd9580b000000000000000000000000b6b629976253698319067737dfe1f464f7cc79ce000000000000000000000000c2a9abc05987ab28d6ae1da347a19553a530a2d1000000000000000000000000a0feb13b95f692f314e014b932a312cb43ee62df0000000000000000000000009a1069e24961b696d107413c76346eee02ef296d000000000000000000000000fc35032ca12a4eec84f40630a53d73dbb6ad9c84000000000000000000000000b94a677371fa8d25c452e613de3505cda1d6cf1f000000000000000000000000541e350501dd562d2e6d61ef0b60050eb11c09e700000000000000000000000016a5171223acc848de45a87733026198cc64eddb0000000000000000000000003833f8dbdbd6bdcb6a883ff209b869148965b3640000000000000000000000005aaf4b30f92e9625092dd221621d0cab55077a950000000000000000000000005baa44dfeaed6354c394d8ae448b9d367e237254000000000000000000000000292b760f76a02e30281477976aa905858c40fe6e00000000000000000000000040e72e652420d360dc2595ab145c7a308f85eaf2000000000000000000000000b6c3e6a645f105efae04d3332d3af259868e8e830000000000000000000000001520912c45f3a6adba46f3ed14a2586f032465d80000000000000000000000005bb3b225b4a24a95c34a90f6029c6e3d4e065a900000000000000000000000008ecd1010d39c842c61d9e94b0eac3d9d0377d65d0000000000000000000000001eaa5661d3a46bf33ce3e95b41b5f85a7fd320d500000000000000000000000014605d27fc0f0f30021d317e8b819ecbdd2e45cf000000000000000000000000173448386903ddb117c1da2d3ad193bbba73e4be000000000000000000000000b4a6d7029f419ae628509195b834065d723859eb000000000000000000000000be4176dbcc14fff3abd40f85e77108dad67f28f8000000000000000000000000000000000000000000000000000000000000002300000000000000000000000000000000000000000000000000f9271a75cdae0000000000000000000000000000000000000000000000000000ea7aa67b2d0000000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000001e2586e68a7a40000000000000000000000000000000000000000000000000000b1a2bc2ec5000000000000000000000000000000000000000000000000000029a2241af62c00000000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000a375d9ea1da000000000000000000000000000000000000000000000000000adbff9aa8be4000000000000000000000000000000000000000000000000000368e9b0bdd41200000000000000000000000000000000000000000000000000001feb3dd0676600000000000000000000000000000000000000000000000000000093fe078f5e140000000000000000000000000000000000000000000000000340aad21b3b7000000000000000000000000000000000000000000000000000001dd6559bdb1700000000000000000000000000000000000000000000000000000f43fc2c04ee0000000000000000000000000000000000000000000000000004e1003b28d92800000000000000000000000000000000000000000000000000018493fba64ef0000000000000000000000000000000000000000000000000000340aad21b3b7000000000000000000000000000000000000000000000000000000edfb58d9313500000000000000000000000000000000000000000000000000340aad21b3b7000000000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000e501829392fc000000000000000000000000000000000000000000000000003fc321d7a9e3c60000000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000058d15e17628000000000000000000000000000000000000000000000000001d4dc3b26bcb6a64c200000000000000000000000000000000000000000000000000670758aa7c80000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000340aad21b3b700000000000000000000000000000000000000000000000000000006a94d74f43000000000000000000000000000000000000000000000000000000fb8e33bbd2b8000000000000000000000000000000000000000000000000046419ced7f6a4000000000000000000000000000000000000000000000000000014ce1613bd79800000000000000000000000000000000000000000000000000003464b0abe6b7800", contractAddress: "", cumulativeGasUsed: "3404439", gasUsed: "1442938", confirmations: "3268928"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147]]}, {type: "uint256[]", name: "_values", value: ["70130263800000000","66000000000000000","100000000000000000","500000000000000000","135768170000000000","50000000000000000","3000000000000000000","800000000000000000","46010000000000000","12520000000000000000","62900000000000000000","2300000000000000000","41656130000000000","60000000000000000000","2150000000000000000","1100000000000000000","90000000000000000000","28000000000000000000","60000000000000000000","1071774856000000000","60000000000000000000","5000000000000000000","64459430000000000","4594553255000000000","200000000000000000","400000000000000000","540559096675000018114","29000000000000000","1000000000000000000","60000000000000000000","30000000000000000","70806572000000000","81000000000000000000","1499160000000000000","235958540000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147]], ["70130263800000000","66000000000000000","100000000000000000","500000000000000000","135768170000000000","50000000000000000","3000000000000000000","800000000000000000","46010000000000000","12520000000000000000","62900000000000000000","2300000000000000000","41656130000000000","60000000000000000000","2150000000000000000","1100000000000000000","90000000000000000000","28000000000000000000","60000000000000000000","1071774856000000000","60000000000000000000","5000000000000000000","64459430000000000","4594553255000000000","200000000000000000","400000000000000000","540559096675000018114","29000000000000000","1000000000000000000","60000000000000000000","30000000000000000","70806572000000000","81000000000000000000","1499160000000000000","235958540000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509438490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[148],addressList[149],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4462949", timeStamp: "1509438524", hash: "0xc76b78f8393cd5f746d4da9c4a4ed41b6f77ae3d6bcf5f563a366e4db37aefdd", nonce: "6", blockHash: "0xf62b07f9b693e35f4aa7f636aef7866d24a33ac38f2d82f625eba88c6db62649", transactionIndex: "95", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "1444506", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000004c0000000000000000000000000000000000000000000000000000000000000002300000000000000000000000040b1b265bf4d2202c3345232d6bb24265a83eb1a0000000000000000000000009fdce9399ef34702a9d70e6816cee3d7ef75e4730000000000000000000000004d2008ade516862e0a7ba69b0ab0537ac130f8980000000000000000000000009ea3c7a23e958415597da11497cee5eb0409838a000000000000000000000000ef6274bb851c1f56f699d4a4b167a4764599095d000000000000000000000000b36d801a84cad61a06a777cfb53cb8f57fca4674000000000000000000000000a2c58bab8c7405a282559a68c7086c915217ada40000000000000000000000005de5b13121ed7f5a32793dc6b97be201b8f6d732000000000000000000000000f742afc5561e857d895ee22198bb198686af14b200000000000000000000000042ee47f542add4c349465be8f045b79e731d371b000000000000000000000000199b31e245cc9d22a8209ea867a5b747b0174144000000000000000000000000f2c94748c523f5a5be87c4237e139fe1816c7ef10000000000000000000000009042b0a3e55d8438d098e7877a444f6f9aeb72f5000000000000000000000000488be1890c054674837554750be29d0d6b88d695000000000000000000000000a5b1c9cd0f6318931f00b8c51449ac06e94daa44000000000000000000000000107aab77da84beb1db4d1cba2686c66c63f196280000000000000000000000007aad6e2c3885bfb22a19f0fa0e19b05ffc68e8a90000000000000000000000001cb002ad89e5f3fd06a5e1ba67597a6ab432e137000000000000000000000000d178bda9571b0df49399724f6050b12bbbae1b9200000000000000000000000036ff4903d66c5fed5d6b8bd1ab985cddc3adcbc500000000000000000000000073e75fa2ec638393b6512474412b88a4bcc1051b00000000000000000000000089d80da44f29d8e53055171a60d5027f6debcf4300000000000000000000000034debc2b82da90e2eb9d60152c537df0af55eeb900000000000000000000000079c9fe695a5f34634bec31d9111b9aef5f9ee5b200000000000000000000000092753c89707435954bdf567ac8cf99c7e69cfa5a0000000000000000000000001dcfd2c1b97e92f7277107bfb6cf82e2dcf62fc1000000000000000000000000ddd8582d3aafa16ed62dc394f37cba3c2bb92311000000000000000000000000ebf5c85fe4b24601f5851a898f78c53ea57b6351000000000000000000000000397dbd9eb04b7af74831567322ed4e1c8232e41d0000000000000000000000006a762579e6300b195d8ce1c7dfcc9e18a70a7cbb00000000000000000000000044b4eedaa08c61507c798ffef8e669b1b64b4fd6000000000000000000000000a79d5277b3e02d593f9b90d52f0fc76658468f8b000000000000000000000000da724ab5ba9de3853fa8c95ef63e1139f287f713000000000000000000000000ed5467a43b41525ec92ea33043b6efd677ef90da000000000000000000000000d35184b3fb9b3376e4af80f41c6ab012a9f81f790000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000340aad21b3b700000000000000000000000000000000000000000000000000006c26850de8eae800000000000000000000000000000000000000000000000000000df95ee3ae0683600000000000000000000000000000000000000000000000001531d4f68a2480000000000000000000000000000000000000000000000000684a9faab4f0560410000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000000340ce590dab31000000000000000000000000000000000000000000000000000340ce590dab31000000000000000000000000000000000000000000000000000001f33660285470020000000000000000000000000000000000000000000000036762e45306c700000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000005d423c655aa000000000000000000000000000000000000000000000000000ea5c73c6b468c00000000000000000000000000000000000000000000000000000853a0d2313c00000000000000000000000000000000000000000000000000000354a6ba7a1800000000000000000000000000000000000000000000000000022b1c8c1227a000000000000000000000000000000000000000000000000000000959b63ec650a00000000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000004aa392fe161000000000000000000000000000000000000000000000000000003c23dab8ca635900000000000000000000000000000000000000000000000aa2dedbb8245ac00000000000000000000000000000000000000000000000000002e239b91b2b00000000000000000000000000000000000000000000000000000291408513728000000000000000000000000000000000000000000000000003e733628714200000000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000340aad21b3b70000000000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000000030df88d3f40e1b000000000000000000000000000000000000000000000000058d15e176280000000000000000000000000000000000000000000000000000136c3b7ecd3370000000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000011e31015311dfba00000000000000000000000000000000000000000000000000000429d069189e000000000000000000000000000000000000000000000000000410d586a20a4c0000", contractAddress: "", cumulativeGasUsed: "6389673", gasUsed: "1444506", confirmations: "3268926"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182]]}, {type: "uint256[]", name: "_values", value: ["100000000000000000","60000000000000000000","124689000000000000000","62933770229016630","95452244000000000","120239911740000002113","2000000000000000000","60010000000000000000","60010000000000000000","140515800000000002","62790000000000000000","1000000000000000000","420000000000000000","270200000000000000000","600000000000000000","240000000000000000","40000000000000000000","673770000000000000","500000000000000000","21009000000000000","16927920912753497","196203500000000000000","207792000000000000","185000000000000000","72000000000000000000","100000000000000000","60000000000000000000","20000000000000000","13756577646644763","400000000000000000","1399559000000000000","2000000000000000000","5279300000000000000000","300000000000000000","75000000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182]], ["100000000000000000","60000000000000000000","124689000000000000000","62933770229016630","95452244000000000","120239911740000002113","2000000000000000000","60010000000000000000","60010000000000000000","140515800000000002","62790000000000000000","1000000000000000000","420000000000000000","270200000000000000000","600000000000000000","240000000000000000","40000000000000000000","673770000000000000","500000000000000000","21009000000000000","16927920912753497","196203500000000000000","207792000000000000","185000000000000000","72000000000000000000","100000000000000000","60000000000000000000","20000000000000000","13756577646644763","400000000000000000","1399559000000000000","2000000000000000000","5279300000000000000000","300000000000000000","75000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509438524 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[183],addressList[184],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4462954", timeStamp: "1509438573", hash: "0xaf65763afcee4edaf28cb58c49929a5fc9aba3cffc03caefe6527745a9044003", nonce: "7", blockHash: "0xfabbbe70bb8901fb6744ddb74b54c1bb6cb2cd0f5f07d5fe1207084663033167", transactionIndex: "93", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "1158297", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000003e0000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000580a408dc5d06032bbd0b938eabda14d845451c3000000000000000000000000a8175bd7ceef06ffe631e284befa7dea8e0cdb1600000000000000000000000060902f909e6428c63935991ae6b101c75fc7eca80000000000000000000000001decf5aa54faff410d5047930c7c138312d827600000000000000000000000004eeb026fd859d51c6aeb0cc9e5068365eb575051000000000000000000000000151936e6bd7000174ab38af53134d81e46652dfc000000000000000000000000f30319ea1817f48724e8bfcd04a4817a4a78f93a0000000000000000000000005d4c6a07eb1d3474bd44acf8b9e15c673ff59b4a000000000000000000000000e422244b54a5c6ab91146bc409de5b65522b9e3b0000000000000000000000002fd0458bd985aa01031c3615769d2827ae18024b0000000000000000000000004c76fe34087e43f4070d29735b02fb06ae667788000000000000000000000000208e6feaa925324c48dbc002ca1abf6895d1245000000000000000000000000090683276d0182069708abf14efee39439be8bc7100000000000000000000000063bd01c310c2c645d929cc59c20acbe4aa71f872000000000000000000000000f54e3d79a8e236c2851578dd26b8f3c52f2ba92d000000000000000000000000ad4ca3fb1c39bc3fc7904d80ae09ed8399e63898000000000000000000000000dd6ec9f00a15a151e8b0f582930cf850a1d075ec000000000000000000000000d5d234655d1e8e2899aa8f6427de7e912654be7e00000000000000000000000080bee60b7d7696079426b0cb03e3094a642e99d30000000000000000000000009e8a75fd5847e4606ea23f56caece213b3278e13000000000000000000000000249e7c9b5223c773aa5960e217e8d49da40c1037000000000000000000000000d662f5d05588af7c38d7a1a2606898cda86402c0000000000000000000000000757881c315e4f6ddb4dd91017e7c0bb7568cf6460000000000000000000000008d31cc0231b20a573130a48ff2a2044e616a62bc00000000000000000000000008efbafec9e03c0048e7a96df9b799a9f7747c710000000000000000000000002d10edaa7b9b683a4a8f8284badb14e91e9a32720000000000000000000000007d3f1d2debf26f82cf4e91769dd74de508a7eba50000000000000000000000000d30f3e3292812abd69efc6af4f9dc3718fbe4cc000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000a83ce4ec2d6c00000000000000000000000000000000000000000000000000008700cc757700000000000000000000000000000000000000000000000000000429d069189e0000000000000000000000000000000000000000000000000008670e9ec6598c00000000000000000000000000000000000000000000000000000f9d8c888bb7a00000000000000000000000000000000000000000000000000002b6c4c8ac467fe000000000000000000000000000000000000000000000000000b8bdb9785200000000000000000000000000000000000000000000000000000186cc6acd4b00000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000066b214cb09e400000000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000012c5e0bf3955c600000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000003cde083cdd02de0000000000000000000000000000000000000000000000000000b5dac29270b80000000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000003b659d52d6ac00000000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000031094cf5832800000000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000000009f234e2f00d80000000000000000000000000000000000000000000000000000178d9d05246c0000000000000000000000000000000000000000000000000340aad21b3b70000000000000000000000000000000000000000000000000000015c9c2ae895d0000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "5301870", gasUsed: "1158297", confirmations: "3268921"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210]]}, {type: "uint256[]", name: "_values", value: ["47354750000000000","38000000000000000","300000000000000000","155000000000000000000","1125210000000000000","195559999999999968","52000000000000000","110000000000000000","1000000000000000000","7400000000000000000","4000000000000000000","200000000000000000","40000000000000000","346300000000000000000","150000000000000000","70175234313671270400","819000000000000000","4000000000000000000","68480000000000000000","100000000000000000","3533440000000000000","5000000000000000000","44793340000000000","6629630000000000","60000000000000000000","1570000000000000000","10000000000000000","10000000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210]], ["47354750000000000","38000000000000000","300000000000000000","155000000000000000000","1125210000000000000","195559999999999968","52000000000000000","110000000000000000","1000000000000000000","7400000000000000000","4000000000000000000","200000000000000000","40000000000000000","346300000000000000000","150000000000000000","70175234313671270400","819000000000000000","4000000000000000000","68480000000000000000","100000000000000000","3533440000000000000","5000000000000000000","44793340000000000","6629630000000000","60000000000000000000","1570000000000000000","10000000000000000","10000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509438573 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[211],addressList[212],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4462957", timeStamp: "1509438619", hash: "0x4dbd2998d101199455b2deffc4b141c265c19ba9397e8bad4706233183d86775", nonce: "8", blockHash: "0xfadb9d6504a449f62229fefdc02bab52ee6cf373c129709f30ae510ccf13b474", transactionIndex: "83", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "816983", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000002e00000000000000000000000000000000000000000000000000000000000000014000000000000000000000000c5ee0e69b61a47a0dee546704c55f10947238137000000000000000000000000976ef662ac98e5c96cc95202a241f706673ae305000000000000000000000000a8a8c9f403ba31f2270024a4fda69fac9d5a047a000000000000000000000000c75d9f381ab0005e5c2385be7aa52734bbccbe45000000000000000000000000462c19cd5498ea9613f7b97dfeb7c2ab5ab7da3d000000000000000000000000a285472849a80fed60cc52055bac492e082917e5000000000000000000000000b51ce12fd1da6bff064df2d5ec7f454aaf942c82000000000000000000000000d94adb8b31135b64c53dcf4f91d595057751ccf00000000000000000000000008e555443198317ac0a455a8a17fed3d8e9a46b660000000000000000000000001e814202ab10cfad800c43200d3dafcdcc921a1d000000000000000000000000173448386903ddb117c1da2d3ad193bbba73e4be000000000000000000000000fe01c61aadd4fba7052484097e312f59fad21691000000000000000000000000cd42c3e6937c92c1d5252159768801757aebf73b000000000000000000000000fbe9b34c64f4dc000f9bc132fccda552fa6581eb00000000000000000000000078e3a387bd4cfabcc466ba941185d0f690ddfa060000000000000000000000009ea33991242a7963df62232f2d6454c2787c5e83000000000000000000000000c85202837afa3f29bb97e43dd59aaad5b22dd565000000000000000000000000693150539d1b8811ae36dea588313ebe33ba24b100000000000000000000000031222eb6c38ff5a1b8e98e15452b1c1f5ae0cad7000000000000000000000000ecd6a1d180baf455f1856c9f29916b923ba89c860000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000000000000000000000000000008e1bc9bf0400000000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "4111964", gasUsed: "816983", confirmations: "3268918"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[145],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229]]}, {type: "uint256[]", name: "_values", value: ["40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","5000000000000000000","5000000000000000000","5000000000000000000","5000000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[145],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229]], ["40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","40000000000000000","5000000000000000000","5000000000000000000","5000000000000000000","5000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509438619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[230],addressList[231],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4463635", timeStamp: "1509447923", hash: "0x3ec069072e3981631a471ea25305b5cb7d798a6976f58b04521c1368c99c1979", nonce: "9", blockHash: "0xb5050dbb7c27f4ee8d7fdd05450be60a8b98dad0e94f842549fac66f223ac787", transactionIndex: "112", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "511685", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001e0000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000ca33241802904df85e909c8f2aa1fa9d49a2e5e300000000000000000000000053eef2fcd83f8e7a44c364252009782a6148a31d0000000000000000000000005ed78a19e5c1b8bdafc3d1e82ccdf23ea6c3040600000000000000000000000055fe9d8a70992963af812a9b8c900700eff17b7d000000000000000000000000070da016f68a99985f48cfd0d2d5370466827a1c00000000000000000000000041c95b35ea7a665a7a0b91b44bc15a5a83fd7e8b000000000000000000000000b210473ab7333470f3ff51fcf4466924985f651400000000000000000000000034345a49d9cf673fdc221501e8ee175d36eb1adc000000000000000000000000ad67c9e9b643e1403b1c70a3816cbc0038c59fe800000000000000000000000009fbd56bfefad15e0c6ee73eb3c25676027e01f8000000000000000000000000c721da9a2d903558d1b008f36ad71a83045cacdc000000000000000000000000c86302e35af3a8cf48afe8d25026ae239077792a000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000014d1120d7b160000000000000000000000000000000000000000000000000000aa00be18c2890000000000000000000000000000000000000000000000000000aa00be18c2890000000000000000000000000000000000000000000000000000aa00be18c2890000000000000000000000000000000000000000000000000000aa00be18c2890000000000000000000000000000000000000000000000000000832524ee87710000000000000000000000000000000000000000000000000000832524ee87710000000000000000000000000000000000000000000000000000832524ee87710000000000000000000000000000000000000000000000000000832524ee87710000000000000000000000000000000000000000000000000000832524ee8771000000000000000000000000000000000000000000000000000003be53c65feadfaaa0000000000000000000000000000000000000000000000000429d069189e0000", contractAddress: "", cumulativeGasUsed: "6100210", gasUsed: "511685", confirmations: "3268240"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241]]}, {type: "uint256[]", name: "_values", value: ["24000000000000000000","196000000000000000000","196000000000000000000","196000000000000000000","196000000000000000000","151200000000000000000","151200000000000000000","151200000000000000000","151200000000000000000","151200000000000000000","4315922226666666666","300000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241]], ["24000000000000000000","196000000000000000000","196000000000000000000","196000000000000000000","196000000000000000000","151200000000000000000","151200000000000000000","151200000000000000000","151200000000000000000","151200000000000000000","4315922226666666666","300000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509447923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[242],addressList[242],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4464592", timeStamp: "1509461443", hash: "0xa794fbe092b37f31e1c7cfe4e844a050c90fa8107a3c3c342aabe49907c1aba8", nonce: "10", blockHash: "0x0f2ad6ad1ec3704486622064706ef178bb33a975850cb618b5940af98b403873", transactionIndex: "31", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "719955", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000013000000000000000000000000f5cd89d72bfe947723cef94d876bc44f400d9b2b000000000000000000000000f5cd89d72bfe947723cef94d876bc44f400d9b2b000000000000000000000000006cfd76c553f5cf91d1f457862f627eb1a3f0ff000000000000000000000000389ae20115182758b9ac08aa4ebb36bb7d6b984300000000000000000000000037d114aba7094134be9cd89dccdb1ee705e28d51000000000000000000000000838eaa81c69dea9d1da556d285501c5f7676d1e900000000000000000000000092d99fa62911fe843772c40148bfec99cd59919f000000000000000000000000bab8321ee1568d94b50cd21682cf9011057abf6800000000000000000000000063f311c2e5e4aa5f14d7d0a8cefc657b640be60c000000000000000000000000619b636a64ea02087e54b2daea77e1efe4c8cf7900000000000000000000000009de14e8f898df97977c365b379c7b62de32dbb2000000000000000000000000b7050615fdc741075f5ec5b4474f535f9a2269ec000000000000000000000000fec4a0da542e582f827916b1e252eec9d738337600000000000000000000000025a3904c5eb5aa5c29f5d0c6d54daae8c74eb59f00000000000000000000000025a3904c5eb5aa5c29f5d0c6d54daae8c74eb59f00000000000000000000000064bcc61a3733bea091a407776103637379cc4b42000000000000000000000000e80a478f6384d06d622b694d24faeafaf6fedfd00000000000000000000000007b73fe5b4bccca8e778b9ee7fc4d04bfa6f8bf13000000000000000000000000619b958e5a0d38776263e92c9f38b339a293dac20000000000000000000000000000000000000000000000000000000000000013000000000000000000000000000000000000000000000001ae361fc1451c0000000000000000000000000000000000000000000000000001ae361fc1451c00000000000000000000000000000000000000000000000000020440f2e7ec880000000000000000000000000000000000000000000000000000ac15a64d4ed80000000000000000000000000000000000000000000000000000ac15a64d4ed800000000000000000000000000000000000000000000000000012b171aea6f7e147a00000000000000000000000000000000000000000000000031d92f271a87851e00000000000000000000000000000000000000000000000013f07942dc2e1cac0000000000000000000000000000000000000000000000004fc1e502df45020c000000000000000000000000000000000000000000000000c764bc99ce8ba5e300000000000000000000000000000000000000000000000063b25e4ce745d2f100000000000000000000000000000000000000000000000027e0f285294f20c400000000000000000000000000000000000000000000000077a2d78d9f17126e0000000000000000000000000000000000000000000000022b1c8c1227a00000000000000000000000000000000000000000000000000001b9db22f83149ba5e000000000000000000000000000000000000000000000000ef45af22b187645a0000000000000000000000000000000000000000000000018ec97939339a2d0e000000000000000000000000000000000000000000000000e74bf127f91b851e0000000000000000000000000000000000000000000000043d70f675c8e8db6d", contractAddress: "", cumulativeGasUsed: "1937243", gasUsed: "719955", confirmations: "3267283"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[242],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[6],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[43],addressList[252],addressList[252],addressList[253],addressList[50],addressList[254],addressList[255]]}, {type: "uint256[]", name: "_values", value: ["31000000000000000000","31000000000000000000","37200000000000000000","12400000000000000000","12400000000000000000","21551724136000001146","3591954022800000286","1436781609200000172","5747126400000000524","14367816080000001507","7183908040000000753","2873563216000000196","8620689640000000622","40000000000000000000","31839080440000002654","17241379312000001114","28735632183999999246","16666680000000001310","78214285714285714285"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[242],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[6],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[43],addressList[252],addressList[252],addressList[253],addressList[50],addressList[254],addressList[255]], ["31000000000000000000","31000000000000000000","37200000000000000000","12400000000000000000","12400000000000000000","21551724136000001146","3591954022800000286","1436781609200000172","5747126400000000524","14367816080000001507","7183908040000000753","2873563216000000196","8620689640000000622","40000000000000000000","31839080440000002654","17241379312000001114","28735632183999999246","16666680000000001310","78214285714285714285"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509461443 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[256]], [\"57471264000000005... )", async function( ) {
		const txOriginal = {blockNumber: "4464701", timeStamp: "1509462897", hash: "0x163be2c6d914ff3325dfdc90cc62c393228e1835d0fefe27e0fad1502916711e", nonce: "11", blockHash: "0x27cdb9848e84d2f342c595fdbc5fefb6179c76a17ea4dfccf22a9a13f1fdd3d6", transactionIndex: "18", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "63573", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e800000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000001e4f75708dfe9a70b8fbb01ae85c3be8737f7e2800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000004fc1e502df45020c", contractAddress: "", cumulativeGasUsed: "672260", gasUsed: "63573", confirmations: "3267174"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[256]]}, {type: "uint256[]", name: "_values", value: ["5747126400000000524"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[256]], ["5747126400000000524"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509462897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[257]], [\"14367816092000001... )", async function( ) {
		const txOriginal = {blockNumber: "4464773", timeStamp: "1509463870", hash: "0x26fba2c05b69d59f3301bcebbc6ba79338aab1fe953956ebbdfde5730e35321f", nonce: "12", blockHash: "0x5beff1be1399ea94c7b8662b751f4d4077aab851a8c39ca14394a45d2408d30d", transactionIndex: "106", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "63573", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000d9de3883d66eddccf2aa459f155a0219c3837536000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000013f07942dc2e1cac", contractAddress: "", cumulativeGasUsed: "4696603", gasUsed: "63573", confirmations: "3267102"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[257]]}, {type: "uint256[]", name: "_values", value: ["1436781609200000172"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[257]], ["1436781609200000172"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509463870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyFor( addressList[259] )", async function( ) {
		const txOriginal = {blockNumber: "4467614", timeStamp: "1509502989", hash: "0x75a8c1b62416dec7387bef09d1aef19088f84740ba6e72f693a83caeab0c7435", nonce: "247", blockHash: "0x71116ae4a4f55b7ca362b33f4e99fdf8a076b1c8a5b349262c9dc3e09ef768dd", transactionIndex: "8", from: "0x6cbbd990c24c1a16b48540a7733ff270a9f6b85b", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "90364840000000000", gas: "300000", gasPrice: "30000000000", isError: "0", txreceipt_status: "0", input: "0x6f0b51800000000000000000000000002e97c909bc9aacade819e8c9484b8815903b0a22", contractAddress: "", cumulativeGasUsed: "513142", gasUsed: "23343", confirmations: "3264261"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[258], to: addressList[2], value: "90364840000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[259]}], name: "buyFor", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFor(address)" ]( addressList[259], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509502989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[258], balance: "6551028549511864" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[258], balance: ( await web3.eth.getBalance( addressList[258], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[260],addressList[261],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4468200", timeStamp: "1509510831", hash: "0x6ff7038346048070abeed34b487a72d828bcadff9b7fa80ba518c42077544ab6", nonce: "13", blockHash: "0x77358a227299029afd671b7d523930e3c890ff1bf18d89072c04856da5f5a1dd", transactionIndex: "157", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "520551", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e8000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000004ce56aec927f18e91a4400b3195c51806487658d000000000000000000000000412e942be5ec1aa28ec52989ee20a595d0c77b57000000000000000000000000ac0e553a39159dd14fbb55ef7b3a0850c805ddb800000000000000000000000064be227c3ef62efae69008d16c8d8eb3012f583400000000000000000000000040af76054e0bdc875772b4e03ddab1176bb7962f000000000000000000000000f75f4946704236a29f1b28f6e24fd9f55d5afe140000000000000000000000009678e6b4e66ef464f44824017b314dcbbd5f39e2000000000000000000000000d2f99d66791128e8653be5bb90f2cdd4ac701a590000000000000000000000003d8be603d1374c1ad4fc776883370f215eaaccf5000000000000000000000000297e856623f6f8164c399e530516c63c15b3436c00000000000000000000000043ee5950ba2340aec78dade90be894c92cb437d900000000000000000000000083a77d44218fc06755e696adf1486dffa1922174000000000000000000000000907dae11026946385ea5a906cc988eaa097a767b000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000002cdd10d645ae978d4000000000000000000000000000000000000000000000000e74bf127f91b851e000000000000000000000000000000000000000000000000063eb89da4ed0000000000000000000000000000000000000000000000000002423dc8b351df7ced0000000000000000000000000000000000000000000000034e8b88cee2d4000000000000000000000000000000000000000000000000000063b25e4dd5b0f5c2000000000000000000000000000000000000000000000000c764bc9c99cd16870000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000000075af03122f500000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000b1a2bc2ec5000000000000000000000000000000000000000000000000000000234e1a857498000", contractAddress: "", cumulativeGasUsed: "6734466", gasUsed: "520551", confirmations: "3263675"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[260],addressList[261],addressList[64],addressList[262],addressList[263],addressList[264],addressList[265],addressList[98],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270]]}, {type: "uint256[]", name: "_values", value: ["51724137919999998164","16666680000000001310","450000000000000000","41666679999999999213","61000000000000000000","7183908043999999426","14367816091999999623","5000000000000000000","530000000000000000","150000000000000000","100000000000000000","800000000000000000","159000000000000000"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[260],addressList[261],addressList[64],addressList[262],addressList[263],addressList[264],addressList[265],addressList[98],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270]], ["51724137919999998164","16666680000000001310","450000000000000000","41666679999999999213","61000000000000000000","7183908043999999426","14367816091999999623","5000000000000000000","530000000000000000","150000000000000000","100000000000000000","800000000000000000","159000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509510831 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: mintForEarlyInvestors( [addressList[271]], [\"21551724136000001... )", async function( ) {
		const txOriginal = {blockNumber: "4468273", timeStamp: "1509511951", hash: "0x9763d416a28fb349369ed52867bbbee9dd7a2afa9434672d39d2ed52f042e5bb", nonce: "14", blockHash: "0x3d68cdc71c52236dbded3ef03b46ec275be0b68e0a11361464ce4d3671ce0c0a", transactionIndex: "87", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "63637", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbf439e80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000213cd4339b958aa62933f5651da380d3b392372000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000012b171aea6f7e147a", contractAddress: "", cumulativeGasUsed: "4260494", gasUsed: "63637", confirmations: "3263602"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[271]]}, {type: "uint256[]", name: "_values", value: ["21551724136000001146"]}], name: "mintForEarlyInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintForEarlyInvestors(address[],uint256[])" ]( [addressList[271]], ["21551724136000001146"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509511951 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: startIco(  )", async function( ) {
		const txOriginal = {blockNumber: "4468306", timeStamp: "1509512399", hash: "0xa1b4d767d0e2fd09e2519c66f84e7fa918652c819b63feb76afb2a6e1f92ca52", nonce: "15", blockHash: "0x972fb6ec875f2083445aa80a5910a6bc75a005a2aa9b48a0a4be2c88901b8f5a", transactionIndex: "50", from: "0x9e02445768dd6fbe9341f9491b03517ef890cbc3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "0", gas: "28371", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x89311e6f", contractAddress: "", cumulativeGasUsed: "1083206", gasUsed: "28371", confirmations: "3263569"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "startIco", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startIco()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509512399 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [], name: "RunIco", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RunIco", events: [], address: "0x26d08b9d227933a85e855656dc46ab889e183c88"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "944690142100001001" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468307", timeStamp: "1509512417", hash: "0x5c3234027bac056eddadab7850ae5354ed841bdf4782787373608c8c777422e4", nonce: "0", blockHash: "0x31dd8a656f6e1e740ba86bb6f80a3bb0648415b23870f5045893f45a80ecf2c3", transactionIndex: "44", from: "0x17687c090a15ef27cd4592cf05044cc69baf5c20", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "180000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2128879", gasUsed: "59248", confirmations: "3263568"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[272], to: addressList[2], value: "180000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509512417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[272], balance: "45722632000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[272], balance: ( await web3.eth.getBalance( addressList[272], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468307", timeStamp: "1509512417", hash: "0xb132db1bdcbaced875cd088ba8c05183c0e7f17de45d2d4f2900f2eca497708f", nonce: "0", blockHash: "0x31dd8a656f6e1e740ba86bb6f80a3bb0648415b23870f5045893f45a80ecf2c3", transactionIndex: "60", from: "0xeb66af50e9209067d0919894eccbbdb426ab6edc", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "48240000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3360127", gasUsed: "59248", confirmations: "3263568"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[273], to: addressList[2], value: "48240000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509512417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[273], balance: "3339000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[273], balance: ( await web3.eth.getBalance( addressList[273], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468309", timeStamp: "1509512431", hash: "0xce18dcc0c88f0e5b30ea6091b1d0740753bb6dbc3348fd9e296bc824be58b8c1", nonce: "30", blockHash: "0xa1c9f4d3a1d8c7502d3500177c61f7b1613603f6b65815f139649fd3925720a6", transactionIndex: "23", from: "0x466953cc0ef335bfd5afc24ff989d215a1d36951", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "10000000000000000000", gas: "200000", gasPrice: "40300000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1430186", gasUsed: "59248", confirmations: "3263566"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[274], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509512431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[274], balance: "20299192438069311665" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[274], balance: ( await web3.eth.getBalance( addressList[274], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468309", timeStamp: "1509512431", hash: "0xa3b34a6432b790e5d85ce74d32f68b4645b5860dd58b30d49316b3c83f1dc567", nonce: "5", blockHash: "0xa1c9f4d3a1d8c7502d3500177c61f7b1613603f6b65815f139649fd3925720a6", transactionIndex: "31", from: "0xf08b9d4b54e145d99f8739af0a594253eb60b749", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "1000000000000000000", gas: "59645", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2152887", gasUsed: "59248", confirmations: "3263566"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[275], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509512431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[275], balance: "2057454000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[275], balance: ( await web3.eth.getBalance( addressList[275], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyFor( addressList[139] )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0xd7946e535c1c6c3a8fdd4e1a973679603e4a0141c8b0ef5118029daed6790939", nonce: "834", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "12", from: "0xb6c3e6a645f105efae04d3332d3af259868e8e83", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "2500000000000000000", gas: "100000", gasPrice: "65000000000", isError: "0", txreceipt_status: "1", input: "0x6f0b5180000000000000000000000000b6c3e6a645f105efae04d3332d3af259868e8e83", contractAddress: "", cumulativeGasUsed: "502354", gasUsed: "46163", confirmations: "3263564"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[139], to: addressList[2], value: "2500000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[139]}], name: "buyFor", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFor(address)" ]( addressList[139], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[139], balance: "163751951737533770620" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[139], balance: ( await web3.eth.getBalance( addressList[139], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0xe4550b255cca1db1deeb511b32644c83f16e8007c9e3cd13589ee27db5439b39", nonce: "2", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "34", from: "0x5bb3b225b4a24a95c34a90f6029c6e3d4e065a90", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "2000000000000000000", gas: "210000", gasPrice: "45000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2737809", gasUsed: "44248", confirmations: "3263564"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[141], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[141], balance: "309929160000003000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[141], balance: ( await web3.eth.getBalance( addressList[141], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0xf0f68647ad8af70e75a80e1f13c1cff751fdb63849708076896207bd26511896", nonce: "1", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "62", from: "0x76b790bb8c60906e664a314a8ef0687ea189e56e", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "200000000000000000", gas: "40000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "4626383", gasUsed: "39880", confirmations: "3263564"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[276], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[276], balance: "22873297000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[276], balance: ( await web3.eth.getBalance( addressList[276], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0x25a8fe1566ef78ffc586accc1b7a8f1d0147a49e30a15cdb6eddee45160e82c3", nonce: "28", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "63", from: "0xdea6f7c29eebe56ba61e6a8fac9201db798e1a46", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "10000000000000000000", gas: "117000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4685631", gasUsed: "59248", confirmations: "3263564"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "57497920000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0xd73dabd4160271fadcb7512eb759da14184a2f4a353fccadfd3afa37be680cac", nonce: "0", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "69", from: "0xea6db815322e32e84b5c3f8b93ce9d35c0fae3d9", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "1800000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5217964", gasUsed: "59248", confirmations: "3263564"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[278], to: addressList[2], value: "1800000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[278], balance: "355666222000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[278], balance: ( await web3.eth.getBalance( addressList[278], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0x4c4b9f036d308b2baac6cff82fc7dc9b9ef9370982a17208edc26e041e741171", nonce: "0", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "75", from: "0x930f092e7192f58d96f41b8fe417621c1b4ef472", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "240000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5491679", gasUsed: "59248", confirmations: "3263564"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[279], to: addressList[2], value: "240000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[279], balance: "89426742000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[279], balance: ( await web3.eth.getBalance( addressList[279], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0x68f96b281ba4adfaca2165e49e718ab52e31a8befeb459cd50abda52553a6c54", nonce: "1", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "76", from: "0xcf14df97d67bc9d5cd5dfe89198fcc6e5bc4c4fb", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "4815467511000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5550927", gasUsed: "59248", confirmations: "3263564"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[280], to: addressList[2], value: "4815467511000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[280], balance: "29208022900000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[280], balance: ( await web3.eth.getBalance( addressList[280], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0x7641ce59cbdcfd1ad0aac3061da5d85554d1c869a2c09a9b674885ca16c3f001", nonce: "8", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "78", from: "0x2f81363ed4c2aff368ea80a08dc935e39bd7d4bd", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "4000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5631175", gasUsed: "59248", confirmations: "3263564"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[281], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[281], balance: "3789738401221410510" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[281], balance: ( await web3.eth.getBalance( addressList[281], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0x231c6ab78ad403f803bfb82a2b09b9d32cc8e74cbabc2cdaa25718bc852cc516", nonce: "3", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "81", from: "0x3707d0b7eb1a3e70e2a892aad4938be493b053ef", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "3500000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5792676", gasUsed: "59248", confirmations: "3263564"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "3500000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0xd1819a44090412a34e6db47257a3eec2956591439c9c527ffc624dda42adabe2", nonce: "3", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "82", from: "0x90683276d0182069708abf14efee39439be8bc71", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "150000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5836924", gasUsed: "44248", confirmations: "3263564"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[195], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[195], balance: "1150282331782230944" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[195], balance: ( await web3.eth.getBalance( addressList[195], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468311", timeStamp: "1509512494", hash: "0xaef839acd8689ac12768402db37031cee0addb9ffd04961e905e86e49049af62", nonce: "0", blockHash: "0xbacc03fc073c4ab0148e1a4c874f62366b1af0f5c8174fd40ef4550785103fe7", transactionIndex: "86", from: "0x0c725194a56638c67367feef86aeda4cd6a1dc73", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "1000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5975059", gasUsed: "59248", confirmations: "3263564"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[283], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509512494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[283], balance: "17169959999999968" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[283], balance: ( await web3.eth.getBalance( addressList[283], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468313", timeStamp: "1509512532", hash: "0x376c5a45b55f1519c3280491405d16326879a04362d86a3ae90367cc807757e5", nonce: "16", blockHash: "0x2bace2bb35b92c1efbc923c18d6a80477a34f5a749fa852b49f93215938e0919", transactionIndex: "3", from: "0x79c9fe695a5f34634bec31d9111b9aef5f9ee5b2", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "395982194000000000", gas: "44407", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "109312", gasUsed: "44248", confirmations: "3263562"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[171], to: addressList[2], value: "395982194000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509512532 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[171], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[171], balance: ( await web3.eth.getBalance( addressList[171], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468314", timeStamp: "1509512544", hash: "0xd827637d6d59907f16d19c6de9e49e9a08d1f77bbab10d9a4e1f55a345b02648", nonce: "1", blockHash: "0x14a973e3e6c090c6e1cb8c83e87b11c6d5dd89f0184bfe97291933f44dad6310", transactionIndex: "17", from: "0xfb83ec491522553f6cb1c0b37bcaa1be64ebb65b", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "347000000000000000", gas: "59645", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "577902", gasUsed: "59248", confirmations: "3263561"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[284], to: addressList[2], value: "347000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509512544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[284], balance: "299838660070852073" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[284], balance: ( await web3.eth.getBalance( addressList[284], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468314", timeStamp: "1509512544", hash: "0xb99dbe912527a2fc60df1fb381ca06ac33fc13d1ba9888923f269d4377b43255", nonce: "1", blockHash: "0x14a973e3e6c090c6e1cb8c83e87b11c6d5dd89f0184bfe97291933f44dad6310", transactionIndex: "18", from: "0x35f806a9513e6d37aff8957eb951fd65a0f4b774", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "355000000000000000", gas: "59645", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "637150", gasUsed: "59248", confirmations: "3263561"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[285], to: addressList[2], value: "355000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509512544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[285], balance: "616704000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[285], balance: ( await web3.eth.getBalance( addressList[285], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468314", timeStamp: "1509512544", hash: "0xc6f8d9799a6e68716f469ac7f6c1e9d47ea2c78623c08782573177991e0e39a3", nonce: "0", blockHash: "0x14a973e3e6c090c6e1cb8c83e87b11c6d5dd89f0184bfe97291933f44dad6310", transactionIndex: "19", from: "0xae71a717175b920b597bb905e88165a2eb9327cd", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "2750000000000000000", gas: "59645", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "696398", gasUsed: "59248", confirmations: "3263561"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[286], to: addressList[2], value: "2750000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509512544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[286], balance: "27424890000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[286], balance: ( await web3.eth.getBalance( addressList[286], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyFor( addressList[139] )", async function( ) {
		const txOriginal = {blockNumber: "4468314", timeStamp: "1509512544", hash: "0xbb5d41c91f5525c8226cc680a4b581291fbad577d3a02180617dfe779c4cf607", nonce: "835", blockHash: "0x14a973e3e6c090c6e1cb8c83e87b11c6d5dd89f0184bfe97291933f44dad6310", transactionIndex: "85", from: "0xb6c3e6a645f105efae04d3332d3af259868e8e83", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "988000000000000000", gas: "100000", gasPrice: "35000000000", isError: "0", txreceipt_status: "1", input: "0x6f0b5180000000000000000000000000b6c3e6a645f105efae04d3332d3af259868e8e83", contractAddress: "", cumulativeGasUsed: "3716410", gasUsed: "46163", confirmations: "3263561"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[139], to: addressList[2], value: "988000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[139]}], name: "buyFor", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFor(address)" ]( addressList[139], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509512544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[139], balance: "163751951737533770620" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[139], balance: ( await web3.eth.getBalance( addressList[139], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468314", timeStamp: "1509512544", hash: "0x2eea554be0b283bf547ed02d7f656655fb828ed9a6d452e5261837b012cd4adf", nonce: "0", blockHash: "0x14a973e3e6c090c6e1cb8c83e87b11c6d5dd89f0184bfe97291933f44dad6310", transactionIndex: "98", from: "0xf5fac5a5e9d5eedad09eddd8b04d0e2b642e82fc", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "699000000000000000", gas: "121000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4443393", gasUsed: "59248", confirmations: "3263561"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[287], to: addressList[2], value: "699000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509512544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[287], balance: "1034792000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[287], balance: ( await web3.eth.getBalance( addressList[287], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468314", timeStamp: "1509512544", hash: "0x688f7ca27c098ce94156594b4cabff26b3e5022dc655fa33ba9be61455a4fd54", nonce: "1", blockHash: "0x14a973e3e6c090c6e1cb8c83e87b11c6d5dd89f0184bfe97291933f44dad6310", transactionIndex: "107", from: "0x8dbdd9e25f15a0012f31eaa3f50be6775aba786d", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "800000000000000000", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4874292", gasUsed: "59248", confirmations: "3263561"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[288], to: addressList[2], value: "800000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509512544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[288], balance: "114832560000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[288], balance: ( await web3.eth.getBalance( addressList[288], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468314", timeStamp: "1509512544", hash: "0xdf128d45bf38b1701f06e905b3f3e8b22cc338104c775bb4e085a0d9a312737a", nonce: "0", blockHash: "0x14a973e3e6c090c6e1cb8c83e87b11c6d5dd89f0184bfe97291933f44dad6310", transactionIndex: "111", from: "0x8895195dc8a9e61f6c10f29799910d454ca8ca69", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "12000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5148944", gasUsed: "59248", confirmations: "3263561"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[289], to: addressList[2], value: "12000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509512544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[289], balance: "230430000000001" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[289], balance: ( await web3.eth.getBalance( addressList[289], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468315", timeStamp: "1509512560", hash: "0xdd93b49269281ce73ab023ec78c9bb57d8d8bf1f54d2e313ba047a6b0022e52b", nonce: "21", blockHash: "0x7a6be5c1efa661f6e43863f1af6d2ce880ea5b83b59ffe075674d76ed9c71134", transactionIndex: "5", from: "0x141cf68ad37f924cfe7501cab5469440b96ab6e3", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "1000000000000000000", gas: "300000", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "212482", gasUsed: "59248", confirmations: "3263560"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[290], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509512560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[290], balance: "19590525038067" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[290], balance: ( await web3.eth.getBalance( addressList[290], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468315", timeStamp: "1509512560", hash: "0xa3a8e366f232a04fcc1a6fd4aaf7582c0b1de4c180e1e870f0a8c6f7dc8305ac", nonce: "73", blockHash: "0x7a6be5c1efa661f6e43863f1af6d2ce880ea5b83b59ffe075674d76ed9c71134", transactionIndex: "39", from: "0xb96523e36ac8a71efc33e096338ba75dffac17b6", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "6800000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5959526", gasUsed: "59248", confirmations: "3263560"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[291], to: addressList[2], value: "6800000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509512560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[291], balance: "10541000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[291], balance: ( await web3.eth.getBalance( addressList[291], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468316", timeStamp: "1509512562", hash: "0xd3ed44258e275158a2f93ca30ea72379e552f8d09b693e3adffddcf5284c6434", nonce: "0", blockHash: "0xcab5fece2d7323b53ea2028e3d4b2b5dfa4fe30dde78a32372f2e3d547c4b5d2", transactionIndex: "47", from: "0x989a706cd6d4c7d20770abfe9f1c94597037fd87", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "580000000000000000", gas: "200000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4036927", gasUsed: "59248", confirmations: "3263559"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[292], to: addressList[2], value: "580000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1509512562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[292], balance: "65745055000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[292], balance: ( await web3.eth.getBalance( addressList[292], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468317", timeStamp: "1509512568", hash: "0x7e90c48ce8cc6038c62ae9426ae6ddb5af20837adaa3598966bdcfc9a0609816", nonce: "7", blockHash: "0xa0d3236882b5abd4d4ab4eefd12160f4e5442cfc89f455f10dec16a905722532", transactionIndex: "31", from: "0xc2c153e05c9671bb7c9c4ca7c4bbabeb4cf1ae87", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "1000000000000000000", gas: "59645", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1367094", gasUsed: "59248", confirmations: "3263558"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[293], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1509512568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[293], balance: "41982188000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[293], balance: ( await web3.eth.getBalance( addressList[293], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468318", timeStamp: "1509512593", hash: "0xb971859e8a716299f9267c7d0278891b69d11189ff9d7f79c8c0f2425ec746c9", nonce: "1", blockHash: "0x820288011c1b6e7de4477d06f14c2beb05e958d542a2004782759e3a91267ff4", transactionIndex: "29", from: "0xdd76e696db3dee9d5e9cf24233036010e60deeff", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "560000000000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2482031", gasUsed: "59248", confirmations: "3263557"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[294], to: addressList[2], value: "560000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1509512593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[294], balance: "6695091000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[294], balance: ( await web3.eth.getBalance( addressList[294], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468318", timeStamp: "1509512593", hash: "0xea70045c8132d4fbfd4185eee463fdd983724725ede202252dce0b5bbb7d9d03", nonce: "0", blockHash: "0x820288011c1b6e7de4477d06f14c2beb05e958d542a2004782759e3a91267ff4", transactionIndex: "33", from: "0xe1827e4842966643e59c802212bb60598ae29c63", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "4700000000000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2635311", gasUsed: "59248", confirmations: "3263557"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[295], to: addressList[2], value: "4700000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1509512593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[295], balance: "6555792000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[295], balance: ( await web3.eth.getBalance( addressList[295], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468318", timeStamp: "1509512593", hash: "0x5ce345f24c065b4cf8c566a12cf6d52704f2d261fa7a4b2bbc932f0ecc0b9cc9", nonce: "0", blockHash: "0x820288011c1b6e7de4477d06f14c2beb05e958d542a2004782759e3a91267ff4", transactionIndex: "35", from: "0x6a72fef73dbcb6287a3b98769a2ce26d41a35af2", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "439815610000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2719754", gasUsed: "59248", confirmations: "3263557"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[296], to: addressList[2], value: "439815610000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1509512593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[296], balance: "2900939981091000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[296], balance: ( await web3.eth.getBalance( addressList[296], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4468318", timeStamp: "1509512593", hash: "0x218ee0c8fa2233800e1d170595ce265f66ea111b601e7069b646392029ed30bb", nonce: "6", blockHash: "0x820288011c1b6e7de4477d06f14c2beb05e958d542a2004782759e3a91267ff4", transactionIndex: "38", from: "0x95abca1a49134ddd9be33b45005d285b292f66f7", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "4000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2880702", gasUsed: "59248", confirmations: "3263557"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[297], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1509512593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[297], balance: "321594667231325440" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[297], balance: ( await web3.eth.getBalance( addressList[297], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyFor( addressList[139] )", async function( ) {
		const txOriginal = {blockNumber: "4468318", timeStamp: "1509512593", hash: "0x48312844ef3edf0991963910eae1be0c3839db6005bf37d8ece321c3d0a00ab5", nonce: "836", blockHash: "0x820288011c1b6e7de4477d06f14c2beb05e958d542a2004782759e3a91267ff4", transactionIndex: "53", from: "0xb6c3e6a645f105efae04d3332d3af259868e8e83", to: "0x26d08b9d227933a85e855656dc46ab889e183c88", value: "2704000000000000000", gas: "100000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x6f0b5180000000000000000000000000b6c3e6a645f105efae04d3332d3af259868e8e83", contractAddress: "", cumulativeGasUsed: "3396288", gasUsed: "46163", confirmations: "3263557"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[139], to: addressList[2], value: "2704000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investor", value: addressList[139]}], name: "buyFor", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFor(address)" ]( addressList[139], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1509512593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[139], balance: "163751951737533770620" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "944192281252373" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[139], balance: ( await web3.eth.getBalance( addressList[139], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
