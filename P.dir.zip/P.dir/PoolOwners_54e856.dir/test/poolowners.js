const PoolOwners = artifacts.require( "./PoolOwners.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PoolOwners" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xa038B9B36f22485Ff0d4E48842d4a1905054e856", "0x7b1660682078fe0eFD9310e8EFe32Cb93a0417bc", "0xE2D06414b011D6DFff2D7181FEB37e68e8322D61", "0xAB31AE46f4D4Dd01a475d41832dE9b863B712E13", "0xdE7d9d56D64895d9Dc862476f7a98f8d921cD160", "0x12243A169c448d0bb039023039210D9A1084c9a9", "0x20fE562d797A42Dcb3399062AE9546cd06f63280", "0x3BBF5B5e873543dc90bCaEe9BC98bd8CcD06e60f", "0xD66e8D9D968fE9A3E104cA5a4eeb3ee9aE4459c5", "0x7F6EC4479627aD1eE18e971f70a74842432253dE", "0xf685EddD53914cC3EB1D5745e3a16CD65a20fc3B", "0x1F2DC097491214AE0b466997e7f72621B0DB62B6", "0xbcDBf2e48e10FdBD9925c9781a0C1E9c48C9a606", "0xbeFfd97845CBc374ed41913086721aD9e163d3CD", "0x6b2809391D6eea98b387E9264f9Ec455Be2C9370", "0xD9B39cF5157240C12081e3a310ACb3a079F9cEc0", "0x14Ae6607c0cFa7d96D9a2C13dA8C9C9A01dAF6BB", "0x1E1D1D6648778D1983D65075E6B5Bb62D4d31ef8", "0xf7411A3F727b36f56ff3A871163c21E56D672656", "0x2CD0e3F2EDD24286AD41CeEdFCb24Fe3869D5A2b", "0x997B9F57451bD6695B1370B1f911E25b58A6d116", "0xD1dFb948a426d7fDe1935550E686096986b656Ad", "0xCf27558Eb423F14698Ea31Bbe5e19A4961668B85", "0xbD900AA6d26E2CB6B7b0e4Ce92d4246EA3918480", "0xF230Bb4B42486941847B0DE365D33c1E867206f2", "0x66e07a14b65ABa7f94BdBDcf1EEB8EfD5Fd8Ac9b", "0xdAceD166A3E114CF9A987c3DFEc6333401a096f5", "0x0A53E28f2f7b27971E18a6305C2C74A449BADd2e", "0x0945d36498743A49c93f971735eD88F97c3f4fa6", "0xA59C1a5E1B86ef1c182534ED4dB6907B50a59349", "0x60e7CB73B6Bb7506Cffd803e60FcEC5f7275aF0C", "0xf328149952194185c7d962D0Bdd23c32562b6646", "0xAA7eeC6b62D55Db20381AF6d8E83210DAF59Ca77", "0x42EAd2b245aC5951AFCfFe6Ed5552DFB729Eb21e", "0x3EB68723Ca4780577bdfcca81FaC03B0a43eAF87", "0xD5a8c5C368b4330e72B87E58D8ED8ED2B10Df729", "0xa8737C2FfC0774f96c1DcAef5A5f82a53DC9e90d", "0x87A7DbA23ec3cff1a30c76c487B9B8327A153B36", "0xcE2Bfa2Fc4197f36897f5AE6B0B5F780fa2E50cd", "0xfD069863E3613193CE443F5E0243Ad7dEeFd930D", "0xf6770169D4E100d13C8EeC6ee10817bf9d45BA05", "0x25fF1CcfA7205387B1874BB435588E60fF2d3f99", "0xC7F0a3268aabb0e6F56d901C68486eA3a11B1663", "0x381B278bbD1a39623ce45b28dd0bC9BB977172A8", "0xABFe188786978eA38Af8c3bA924326e9b16Be57E", "0x9aC5B1dc4F911f5B3823f716E96a6E71e8CA6BEb", "0xc3AB75122030cB4500a4222C0aEB25391c77a131", "0x7ACea4fd5a4668500d77fEEAc862b1a502387005", "0xda5b64038Cc813E9c12aCA9000674ACAf85702E0", "0x0Ad2945D05064ce9f8EFD2d9C36D634412F9b85e", "0xceA077172675bf31e879Bba71fb46C3188591070", "0x59666bC2aB8a7e1E457e7D642f0693d238627b37"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "totalContributed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_sender", type: "address"}], name: "getAllowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "getOwnerPercentage", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentOwners", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokenWhitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "distributionActive", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "precisionMinimum", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "getOwnerTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_i", type: "uint256"}], name: "getOwnerAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "distributionMinimum", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getClaimedOwners", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "amountOfOwners", type: "uint256"}], name: "TokenDistributionActive", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "token", type: "address"}, {indexed: true, name: "owner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenWithdrawal", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "amountOfOwners", type: "uint256"}], name: "TokenDistributionComplete", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Contribution(address,uint256,uint256)", "TokenDistributionActive(address,uint256,uint256)", "TokenWithdrawal(address,address,uint256)", "OwnershipTransferred(address,address,uint256)", "TokenDistributionComplete(address,uint256,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x5f7675b09617d2c9fa4fd13058ee5877a9538f626b0308816736e83748a45040", "0xeede959c6858c7a658800c9574366c74769c18e3e3095c31d9516c31b894f743", "0x42856d0378dde02337bb59ae41747abc77ded8ebdbbc5cbdd1e53693b7554938", "0xc13a1166d81cd3b0b352a367aebab95f3a6f6bc695fdab8e9a9d335239c3861b", "0x3f1b49349800340b97132392d0b7f9be99025a47d4b5025999cd26da96681250", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6607104 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6607205 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_wallet", value: 4}], name: "PoolOwners", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "totalContributed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalContributed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getAllowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAllowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getOwnerPercentage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOwnerPercentage(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentOwners", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentOwners()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokenWhitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenWhitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "distributionActive", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "distributionActive()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "locked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "precisionMinimum", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "precisionMinimum()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getOwnerTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOwnerTokens(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_i", value: random.range( maxRandom )}], name: "getOwnerAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOwnerAddress(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "distributionMinimum", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "distributionMinimum(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getClaimedOwners", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getClaimedOwners()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PoolOwners", function( accounts ) {

	it( "TEST: PoolOwners( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6607104", timeStamp: "1540841069", hash: "0x7611b98eac479ca4f2be2b2e3ee1822820f4dab02aa4dc146f9e2cb35f63904b", nonce: "1489", blockHash: "0x38198251593dd755c6c299fa3a5519fde067bf9a376bee4be6494dd8fc63c9a9", transactionIndex: "1", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: 0, value: "0", gas: "6721975", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4a89dbc4000000000000000000000000e2d06414b011d6dfff2d7181feb37e68e8322d61", contractAddress: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", cumulativeGasUsed: "3243646", gasUsed: "3190609", confirmations: "1125901"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_wallet", value: addressList[4]}], name: "PoolOwners", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PoolOwners.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540841069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PoolOwners.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setOwnerShare( addressList[5], \"1480000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6607111", timeStamp: "1540841157", hash: "0x05ae3a09e0e7d02527db4ebaea2cbf4c2a54b2dbf92bb75a5b6675896c282079", nonce: "1490", blockHash: "0x3d4e720c8deffcb547fb2e3a20a9faab0ad35231674dec227cb31d260cba2f96", transactionIndex: "4", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "6721975", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xdcac652e000000000000000000000000ab31ae46f4d4dd01a475d41832de9b863b712e130000000000000000000000000000000000000000000000503b203e9fba200000", contractAddress: "", cumulativeGasUsed: "348773", gasUsed: "107084", confirmations: "1125894"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[5]}, {type: "uint256", name: "_value", value: "1480000000000000000000"}], name: "setOwnerShare", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOwnerShare(address,uint256)" ]( addressList[5], "1480000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540841157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setOwnerShare( addressList[6], \"1480000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6607111", timeStamp: "1540841157", hash: "0x69eda579bdfb19005f13cf78f7f120d362096f1fa4f2e84f2b2c2d85b754cce2", nonce: "1491", blockHash: "0x3d4e720c8deffcb547fb2e3a20a9faab0ad35231674dec227cb31d260cba2f96", transactionIndex: "5", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "6721975", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xdcac652e000000000000000000000000de7d9d56d64895d9dc862476f7a98f8d921cd1600000000000000000000000000000000000000000000000503b203e9fba200000", contractAddress: "", cumulativeGasUsed: "440857", gasUsed: "92084", confirmations: "1125894"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[6]}, {type: "uint256", name: "_value", value: "1480000000000000000000"}], name: "setOwnerShare", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOwnerShare(address,uint256)" ]( addressList[6], "1480000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540841157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setOwnerShare( addressList[7], \"43040000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607111", timeStamp: "1540841157", hash: "0xbd6e9dc0bd726a00aa0e457a0b7262853266ccd9a4dd8250ee8f1cf91ed7b33b", nonce: "1492", blockHash: "0x3d4e720c8deffcb547fb2e3a20a9faab0ad35231674dec227cb31d260cba2f96", transactionIndex: "6", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "6721975", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xdcac652e00000000000000000000000012243a169c448d0bb039023039210d9a1084c9a9000000000000000000000000000000000000000000000002554ccbf6dcd00000", contractAddress: "", cumulativeGasUsed: "532941", gasUsed: "92084", confirmations: "1125894"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[7]}, {type: "uint256", name: "_value", value: "43040000000000000000"}], name: "setOwnerShare", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOwnerShare(address,uint256)" ]( addressList[7], "43040000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540841157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistToken( addressList[8], \"500000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607111", timeStamp: "1540841157", hash: "0x958898719d45ed331c38c921fa4856eab7212fa9473b4326fa7678cc4949b93f", nonce: "1493", blockHash: "0x3d4e720c8deffcb547fb2e3a20a9faab0ad35231674dec227cb31d260cba2f96", transactionIndex: "7", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "6721975", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xc4e16b7d00000000000000000000000020fe562d797a42dcb3399062ae9546cd06f6328000000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "597936", gasUsed: "64995", confirmations: "1125894"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[8]}, {type: "uint256", name: "_minimum", value: "500000000000000000000"}], name: "whitelistToken", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistToken(address,uint256)" ]( addressList[8], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540841157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[9], \"840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607111", timeStamp: "1540841157", hash: "0xa156b09f4fe9fae28ec679481a1985d3b9cf1eea342d911b26bf9114fc95edfd", nonce: "1494", blockHash: "0x3d4e720c8deffcb547fb2e3a20a9faab0ad35231674dec227cb31d260cba2f96", transactionIndex: "8", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000003bbf5b5e873543dc90bcaee9bc98bd8ccd06e60f0000000000000000000000000000000000000000000000000ba8478cab540000", contractAddress: "", cumulativeGasUsed: "712895", gasUsed: "114959", confirmations: "1125894"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[9]}, {type: "uint256", name: "_amount", value: "840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[9], "840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540841157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x3bbf5b5e873543dc90bcaee9bc98bd8ccd06e60f"}, {name: "share", type: "uint256", value: "21"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[10], \"1400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607111", timeStamp: "1540841157", hash: "0xfca3ffe6dab5e35221c3469286e242c618fb504e7c16dff553e7e9397580092e", nonce: "1495", blockHash: "0x3d4e720c8deffcb547fb2e3a20a9faab0ad35231674dec227cb31d260cba2f96", transactionIndex: "9", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000d66e8d9d968fe9a3e104ca5a4eeb3ee9ae4459c5000000000000000000000000000000000000000000000000136dcc951d8c0000", contractAddress: "", cumulativeGasUsed: "812854", gasUsed: "99959", confirmations: "1125894"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[10]}, {type: "uint256", name: "_amount", value: "1400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[10], "1400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540841157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xd66e8d9d968fe9a3e104ca5a4eeb3ee9ae4459c5"}, {name: "share", type: "uint256", value: "35"}, {name: "amount", type: "uint256", value: "1400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[11], \"1400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607115", timeStamp: "1540841200", hash: "0x5a7c2c355661c3950b53d8509498c8ced0c7c3c2a271523bce8a231af8e67758", nonce: "1496", blockHash: "0x17eb6edf432677f929070a6837078294a1e9525aded44fb46769fe12f0542420", transactionIndex: "50", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000007f6ec4479627ad1ee18e971f70a74842432253de000000000000000000000000000000000000000000000000136dcc951d8c0000", contractAddress: "", cumulativeGasUsed: "3405425", gasUsed: "99959", confirmations: "1125890"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[11]}, {type: "uint256", name: "_amount", value: "1400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[11], "1400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540841200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x7f6ec4479627ad1ee18e971f70a74842432253de"}, {name: "share", type: "uint256", value: "35"}, {name: "amount", type: "uint256", value: "1400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[12], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607115", timeStamp: "1540841200", hash: "0xaac7f1f2841dbfec10a90ce295da872c0cb0ce1fcebb108537be955d729a4f02", nonce: "1497", blockHash: "0x17eb6edf432677f929070a6837078294a1e9525aded44fb46769fe12f0542420", transactionIndex: "51", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000f685eddd53914cc3eb1d5745e3a16cd65a20fc3b00000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "3505384", gasUsed: "99959", confirmations: "1125890"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[12]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[12], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540841200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xf685eddd53914cc3eb1d5745e3a16cd65a20fc3b"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[13], \"1400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607115", timeStamp: "1540841200", hash: "0xacd98d8f9b17d2dd766f4aeb7c462fb40c823e7cb0726c6720acdce52bec7685", nonce: "1498", blockHash: "0x17eb6edf432677f929070a6837078294a1e9525aded44fb46769fe12f0542420", transactionIndex: "52", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000001f2dc097491214ae0b466997e7f72621b0db62b6000000000000000000000000000000000000000000000000136dcc951d8c0000", contractAddress: "", cumulativeGasUsed: "3605343", gasUsed: "99959", confirmations: "1125890"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[13]}, {type: "uint256", name: "_amount", value: "1400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[13], "1400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540841200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x1f2dc097491214ae0b466997e7f72621b0db62b6"}, {name: "share", type: "uint256", value: "35"}, {name: "amount", type: "uint256", value: "1400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[14], \"840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607116", timeStamp: "1540841205", hash: "0xbb40ada0c0c9515597d3f093f97ce4a2ec532ab9cd858cf577005e6a156c3117", nonce: "1499", blockHash: "0xd12375eb6d65f38e5674f248b47ffabd344ae8871200af121c8265bb96c9dedb", transactionIndex: "21", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000bcdbf2e48e10fdbd9925c9781a0c1e9c48c9a6060000000000000000000000000000000000000000000000000ba8478cab540000", contractAddress: "", cumulativeGasUsed: "1731937", gasUsed: "99959", confirmations: "1125889"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[14]}, {type: "uint256", name: "_amount", value: "840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[14], "840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540841205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xbcdbf2e48e10fdbd9925c9781a0c1e9c48c9a606"}, {name: "share", type: "uint256", value: "21"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[15], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607119", timeStamp: "1540841219", hash: "0xfb471ae2ec933d46c99e81713730c4a35eb1b770d53bee2e050185a95ecd3e16", nonce: "1500", blockHash: "0xe9d13688a51acd6fcb697bbadd9506d5adbd24a60657f2dafc78d18f0b5df981", transactionIndex: "12", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000beffd97845cbc374ed41913086721ad9e163d3cd00000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "604821", gasUsed: "99959", confirmations: "1125886"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[15]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[15], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540841219 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xbeffd97845cbc374ed41913086721ad9e163d3cd"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[16], \"3120000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607121", timeStamp: "1540841231", hash: "0xfcd0e1d34126e3875a17cd2e6295e82b4b268da5ce10379c90c737627f5ec345", nonce: "1501", blockHash: "0x849cc4cb001d9f4ad556cbd331d9302fb870f803bd0a62ac21641a99c08f4f86", transactionIndex: "55", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000006b2809391d6eea98b387e9264f9ec455be2c93700000000000000000000000000000000000000000000000002b4c777833380000", contractAddress: "", cumulativeGasUsed: "2548919", gasUsed: "99959", confirmations: "1125884"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[16]}, {type: "uint256", name: "_amount", value: "3120000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[16], "3120000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540841231 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x6b2809391d6eea98b387e9264f9ec455be2c9370"}, {name: "share", type: "uint256", value: "78"}, {name: "amount", type: "uint256", value: "3120000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[17], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607124", timeStamp: "1540841305", hash: "0x4fe410cf22131948dee441bca45a45c16077dda7f66ba3acfc7f2589f86a592a", nonce: "1502", blockHash: "0xc9f12543226502daed16921cc4a70a5c610590a19926b8575070ce3882f8f783", transactionIndex: "7", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000d9b39cf5157240c12081e3a310acb3a079f9cec000000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "407846", gasUsed: "99959", confirmations: "1125881"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[17]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[17], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540841305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xd9b39cf5157240c12081e3a310acb3a079f9cec0"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[18], \"560000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607126", timeStamp: "1540841338", hash: "0x607d527557f372f23bc9d2ecec62b4f13923693b6ffbd5990ba9a79ef2c1441a", nonce: "1503", blockHash: "0x8984ab655ab4acd21b9c60e9da656ae807c04b9894fdf57af2f7edfd032a00d0", transactionIndex: "53", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac00000000000000000000000014ae6607c0cfa7d96d9a2c13da8c9c9a01daf6bb00000000000000000000000000000000000000000000000007c5850872380000", contractAddress: "", cumulativeGasUsed: "2321492", gasUsed: "99959", confirmations: "1125879"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[18]}, {type: "uint256", name: "_amount", value: "560000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[18], "560000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540841338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x14ae6607c0cfa7d96d9a2c13da8c9c9a01daf6bb"}, {name: "share", type: "uint256", value: "14"}, {name: "amount", type: "uint256", value: "560000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[19], \"2840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607126", timeStamp: "1540841338", hash: "0xdbbaf51fbf985852e3da051d3e6ee38044bc31fc88c2339f7950948d0721a20f", nonce: "1504", blockHash: "0x8984ab655ab4acd21b9c60e9da656ae807c04b9894fdf57af2f7edfd032a00d0", transactionIndex: "54", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000001e1d1d6648778d1983d65075e6b5bb62d4d31ef80000000000000000000000000000000000000000000000002769b4f3fa1c0000", contractAddress: "", cumulativeGasUsed: "2421451", gasUsed: "99959", confirmations: "1125879"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[19]}, {type: "uint256", name: "_amount", value: "2840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[19], "2840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540841338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x1e1d1d6648778d1983d65075e6b5bb62d4d31ef8"}, {name: "share", type: "uint256", value: "71"}, {name: "amount", type: "uint256", value: "2840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[20], \"106920000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6607128", timeStamp: "1540841363", hash: "0xaec03b645d443edb6f97151b7e6833a34b783af3a733bdb5176ea7731560d3b1", nonce: "1505", blockHash: "0xc2c0231aef41bc2c8a5bbd441f8639254bacff97bcb4212309f618217fb509b4", transactionIndex: "316", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000f7411a3f727b36f56ff3a871163c21e56d672656000000000000000000000000000000000000000000000005cbd0258378c40000", contractAddress: "", cumulativeGasUsed: "7779295", gasUsed: "100023", confirmations: "1125877"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[20]}, {type: "uint256", name: "_amount", value: "106920000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[20], "106920000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540841363 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xf7411a3f727b36f56ff3a871163c21e56d672656"}, {name: "share", type: "uint256", value: "2673"}, {name: "amount", type: "uint256", value: "106920000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[21], \"560000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607131", timeStamp: "1540841400", hash: "0xc4ab558a0118879902d3f36c2cc510994afb333dc11f716148b5dd8e00339d8b", nonce: "1506", blockHash: "0x33c2e35dfee0523f67cbb119ad70d3d9abfed155ef3b712aa9724757af43d080", transactionIndex: "5", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000002cd0e3f2edd24286ad41ceedfcb24fe3869d5a2b00000000000000000000000000000000000000000000000007c5850872380000", contractAddress: "", cumulativeGasUsed: "387208", gasUsed: "99959", confirmations: "1125874"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[21]}, {type: "uint256", name: "_amount", value: "560000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[21], "560000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540841400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x2cd0e3f2edd24286ad41ceedfcb24fe3869d5a2b"}, {name: "share", type: "uint256", value: "14"}, {name: "amount", type: "uint256", value: "560000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[22], \"3120000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607131", timeStamp: "1540841400", hash: "0x7ee46797483df9c07f02cc38e71a69eef50711c786de512c865515d853c08e76", nonce: "1507", blockHash: "0x33c2e35dfee0523f67cbb119ad70d3d9abfed155ef3b712aa9724757af43d080", transactionIndex: "16", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000997b9f57451bd6695b1370b1f911e25b58a6d1160000000000000000000000000000000000000000000000002b4c777833380000", contractAddress: "", cumulativeGasUsed: "6711132", gasUsed: "99959", confirmations: "1125874"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[22]}, {type: "uint256", name: "_amount", value: "3120000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[22], "3120000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540841400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x997b9f57451bd6695b1370b1f911e25b58a6d116"}, {name: "share", type: "uint256", value: "78"}, {name: "amount", type: "uint256", value: "3120000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[23], \"1400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607134", timeStamp: "1540841415", hash: "0xe9cc6efb55d18b9be3fe49f1534917ddd99ef5c02a7bf7b416b9e2c4a0bf03af", nonce: "1508", blockHash: "0x7c8a4aad54792c9fcadc4dccccd850cf4f6ccd8f514a1bcf6e80233625d840ff", transactionIndex: "11", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000d1dfb948a426d7fde1935550e686096986b656ad000000000000000000000000000000000000000000000000136dcc951d8c0000", contractAddress: "", cumulativeGasUsed: "396116", gasUsed: "99959", confirmations: "1125871"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[23]}, {type: "uint256", name: "_amount", value: "1400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[23], "1400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540841415 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xd1dfb948a426d7fde1935550e686096986b656ad"}, {name: "share", type: "uint256", value: "35"}, {name: "amount", type: "uint256", value: "1400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[24], \"840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607135", timeStamp: "1540841417", hash: "0xa76fb110e7493a1719494e13d620783c462c47eab2b998b94c992b3b811fa83e", nonce: "1509", blockHash: "0x77b364a8e9a8ee07a4d213d4bdd13131b976f1a3eac242ce4623e466e92f2b6b", transactionIndex: "12", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000cf27558eb423f14698ea31bbe5e19a4961668b850000000000000000000000000000000000000000000000000ba8478cab540000", contractAddress: "", cumulativeGasUsed: "6160637", gasUsed: "99959", confirmations: "1125870"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[24]}, {type: "uint256", name: "_amount", value: "840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[24], "840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540841417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xcf27558eb423f14698ea31bbe5e19a4961668b85"}, {name: "share", type: "uint256", value: "21"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[25], \"3120000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607139", timeStamp: "1540841480", hash: "0x8e6cb7f74da59a21695ca0822c0eca8c0399848635a62f642dec24aebeb18e2a", nonce: "1510", blockHash: "0xfd7486e22c97a5c935aafa866a68b6fbb3ca1396d685d391da74dfd39d714e23", transactionIndex: "114", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000bd900aa6d26e2cb6b7b0e4ce92d4246ea39184800000000000000000000000000000000000000000000000002b4c777833380000", contractAddress: "", cumulativeGasUsed: "4532573", gasUsed: "99959", confirmations: "1125866"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[25]}, {type: "uint256", name: "_amount", value: "3120000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[25], "3120000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540841480 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xbd900aa6d26e2cb6b7b0e4ce92d4246ea3918480"}, {name: "share", type: "uint256", value: "78"}, {name: "amount", type: "uint256", value: "3120000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[26], \"840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607140", timeStamp: "1540841490", hash: "0x959f28c7f6ab5161098c2ca155a4ae751bb39c2b272138a40ce7b7d435b631ca", nonce: "1511", blockHash: "0xc87166d887f4cfc8fb4639256ddf52618441a1217c0f33becb891310333f13bf", transactionIndex: "58", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000f230bb4b42486941847b0de365d33c1e867206f20000000000000000000000000000000000000000000000000ba8478cab540000", contractAddress: "", cumulativeGasUsed: "3943975", gasUsed: "99959", confirmations: "1125865"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[26]}, {type: "uint256", name: "_amount", value: "840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[26], "840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540841490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xf230bb4b42486941847b0de365d33c1e867206f2"}, {name: "share", type: "uint256", value: "21"}, {name: "amount", type: "uint256", value: "840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[27], \"4560000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607140", timeStamp: "1540841490", hash: "0xdacf61105184d9c45918cc4b8e7ae4bd6854dadfbc4eb9a3361d048485edf99f", nonce: "1512", blockHash: "0xc87166d887f4cfc8fb4639256ddf52618441a1217c0f33becb891310333f13bf", transactionIndex: "59", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac00000000000000000000000066e07a14b65aba7f94bdbdcf1eeb8efd5fd8ac9b0000000000000000000000000000000000000000000000003f485fd70fc80000", contractAddress: "", cumulativeGasUsed: "4043934", gasUsed: "99959", confirmations: "1125865"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[27]}, {type: "uint256", name: "_amount", value: "4560000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[27], "4560000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540841490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x66e07a14b65aba7f94bdbdcf1eeb8efd5fd8ac9b"}, {name: "share", type: "uint256", value: "114"}, {name: "amount", type: "uint256", value: "4560000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[28], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607140", timeStamp: "1540841490", hash: "0x0b5ba2918464f2ad3475a7f4d612a0e5df4385c3807f46075f6deb7204b0908c", nonce: "1513", blockHash: "0xc87166d887f4cfc8fb4639256ddf52618441a1217c0f33becb891310333f13bf", transactionIndex: "60", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000daced166a3e114cf9a987c3dfec6333401a096f500000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "4143893", gasUsed: "99959", confirmations: "1125865"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[28]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[28], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540841490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xdaced166a3e114cf9a987c3dfec6333401a096f5"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[29], \"1400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607142", timeStamp: "1540841530", hash: "0x7dfd1f702ed409b968e4c86c8b017f72bcf7b2a1357bedeb31d4df67ff0ec96c", nonce: "1514", blockHash: "0x14a2402ed42261768a0bfa8f210b71bb1e74a3ee54f6e33cfd30dc6c0824d366", transactionIndex: "97", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000000a53e28f2f7b27971e18a6305c2c74a449badd2e000000000000000000000000000000000000000000000000136dcc951d8c0000", contractAddress: "", cumulativeGasUsed: "6010979", gasUsed: "99959", confirmations: "1125863"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[29]}, {type: "uint256", name: "_amount", value: "1400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[29], "1400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540841530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x0a53e28f2f7b27971e18a6305c2c74a449badd2e"}, {name: "share", type: "uint256", value: "35"}, {name: "amount", type: "uint256", value: "1400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[30], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607143", timeStamp: "1540841541", hash: "0x828815f538a0c2e89823e786dcf73edd4c9fec0a74ca94aa46be92d45cef35b6", nonce: "1515", blockHash: "0xa88ca07872e9fbbab02c2db114827fc0589640cead79e04a097e45148022fe9e", transactionIndex: "22", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000000945d36498743a49c93f971735ed88f97c3f4fa600000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "744000", gasUsed: "99959", confirmations: "1125862"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[30]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[30], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540841541 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x0945d36498743a49c93f971735ed88f97c3f4fa6"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[31], \"12240000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607146", timeStamp: "1540841571", hash: "0x751e5a29bdc82aed858a6e27b51f25fb711bf5b4c79783e225e691d35cda8df5", nonce: "1516", blockHash: "0xf479a4d61a91fb458cb1e986c4a0bb8c9df084e12c4b5b7ceb027f6eb022cc06", transactionIndex: "7", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000a59c1a5e1b86ef1c182534ed4db6907b50a59349000000000000000000000000000000000000000000000000a9dd372652c80000", contractAddress: "", cumulativeGasUsed: "464953", gasUsed: "99959", confirmations: "1125859"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[31]}, {type: "uint256", name: "_amount", value: "12240000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[31], "12240000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540841571 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xa59c1a5e1b86ef1c182534ed4db6907b50a59349"}, {name: "share", type: "uint256", value: "306"}, {name: "amount", type: "uint256", value: "12240000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[32], \"22800000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607146", timeStamp: "1540841571", hash: "0x683eb34045895f1a725d8f36bb4b6133baa777d7598b2be0c31a49aaf3ae0384", nonce: "1517", blockHash: "0xf479a4d61a91fb458cb1e986c4a0bb8c9df084e12c4b5b7ceb027f6eb022cc06", transactionIndex: "46", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac00000000000000000000000060e7cb73b6bb7506cffd803e60fcec5f7275af0c0000000000000000000000000000000000000000000000013c69df334ee80000", contractAddress: "", cumulativeGasUsed: "7947345", gasUsed: "100023", confirmations: "1125859"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[32]}, {type: "uint256", name: "_amount", value: "22800000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[32], "22800000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540841571 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x60e7cb73b6bb7506cffd803e60fcec5f7275af0c"}, {name: "share", type: "uint256", value: "570"}, {name: "amount", type: "uint256", value: "22800000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[33], \"4240000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607148", timeStamp: "1540841630", hash: "0x269c821e3983d6d2e80d4d179ead31cdda11ac23273d6fbe8c21a4d3a01ba0a5", nonce: "1518", blockHash: "0x21e839d3fb05006c0f303dc037a34e7c61aa057a330b9b446fd95219c112fd6f", transactionIndex: "115", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000f328149952194185c7d962d0bdd23c32562b66460000000000000000000000000000000000000000000000003ad7818917a80000", contractAddress: "", cumulativeGasUsed: "6452185", gasUsed: "99959", confirmations: "1125857"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[33]}, {type: "uint256", name: "_amount", value: "4240000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[33], "4240000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540841630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xf328149952194185c7d962d0bdd23c32562b6646"}, {name: "share", type: "uint256", value: "106"}, {name: "amount", type: "uint256", value: "4240000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[34], \"14240000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607149", timeStamp: "1540841636", hash: "0xe1b11c4e6886d0e5e8287ed561b0278a2918285deb91684bec43887e75543ed6", nonce: "1519", blockHash: "0xa81c09f752371a0a671176a3591e8e56172b39f9040e5065b43cd0a7ded7c4c9", transactionIndex: "16", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000aa7eec6b62d55db20381af6d8e83210daf59ca77000000000000000000000000000000000000000000000000c59ea48da1900000", contractAddress: "", cumulativeGasUsed: "2714986", gasUsed: "99959", confirmations: "1125856"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[34]}, {type: "uint256", name: "_amount", value: "14240000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[34], "14240000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540841636 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xaa7eec6b62d55db20381af6d8e83210daf59ca77"}, {name: "share", type: "uint256", value: "356"}, {name: "amount", type: "uint256", value: "14240000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[35], \"1400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607153", timeStamp: "1540841699", hash: "0x404f35c7df0de811a40d43226623f93bed1fd638461cf5ef3b5556c32166e859", nonce: "1520", blockHash: "0xdeeee13e94364ec2dd54fc42f0dc2b575bc90306cb50854d1a9041b398edfddf", transactionIndex: "53", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac00000000000000000000000042ead2b245ac5951afcffe6ed5552dfb729eb21e000000000000000000000000000000000000000000000000136dcc951d8c0000", contractAddress: "", cumulativeGasUsed: "3591890", gasUsed: "99959", confirmations: "1125852"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[35]}, {type: "uint256", name: "_amount", value: "1400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[35], "1400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540841699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x42ead2b245ac5951afcffe6ed5552dfb729eb21e"}, {name: "share", type: "uint256", value: "35"}, {name: "amount", type: "uint256", value: "1400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[36], \"1680000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607159", timeStamp: "1540841736", hash: "0x3da9b5698992763ccdacbbaa92a35fdabe6701f417ef45932f78f2fc0b66d0a1", nonce: "1521", blockHash: "0x0e969276d8e9cfc3088bcca5dc51ea27eb37859c4510fdae06a3a525c6bddb07", transactionIndex: "55", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000003eb68723ca4780577bdfcca81fac03b0a43eaf8700000000000000000000000000000000000000000000000017508f1956a80000", contractAddress: "", cumulativeGasUsed: "3584728", gasUsed: "99959", confirmations: "1125846"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[36]}, {type: "uint256", name: "_amount", value: "1680000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[36], "1680000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540841736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x3eb68723ca4780577bdfcca81fac03b0a43eaf87"}, {name: "share", type: "uint256", value: "42"}, {name: "amount", type: "uint256", value: "1680000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[37], \"14240000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607159", timeStamp: "1540841736", hash: "0x291a86c78d0ebafe4445004cd5e79789ee998da71481c1c54a684c538f328896", nonce: "1522", blockHash: "0x0e969276d8e9cfc3088bcca5dc51ea27eb37859c4510fdae06a3a525c6bddb07", transactionIndex: "56", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000d5a8c5c368b4330e72b87e58d8ed8ed2b10df729000000000000000000000000000000000000000000000000c59ea48da1900000", contractAddress: "", cumulativeGasUsed: "3684687", gasUsed: "99959", confirmations: "1125846"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[37]}, {type: "uint256", name: "_amount", value: "14240000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[37], "14240000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540841736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xd5a8c5c368b4330e72b87e58d8ed8ed2b10df729"}, {name: "share", type: "uint256", value: "356"}, {name: "amount", type: "uint256", value: "14240000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[38], \"28520000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607159", timeStamp: "1540841736", hash: "0x0249ac2b578614f6b5b688d568ef97a734c78b53374496465407d7dd36f8e449", nonce: "1523", blockHash: "0x0e969276d8e9cfc3088bcca5dc51ea27eb37859c4510fdae06a3a525c6bddb07", transactionIndex: "57", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000a8737c2ffc0774f96c1dcaef5a5f82a53dc9e90d0000000000000000000000000000000000000000000000018bcb64e502240000", contractAddress: "", cumulativeGasUsed: "3784710", gasUsed: "100023", confirmations: "1125846"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[38]}, {type: "uint256", name: "_amount", value: "28520000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[38], "28520000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540841736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xa8737c2ffc0774f96c1dcaef5a5f82a53dc9e90d"}, {name: "share", type: "uint256", value: "713"}, {name: "amount", type: "uint256", value: "28520000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[39], \"5680000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607160", timeStamp: "1540841743", hash: "0x68f2b4c3e093f6042a653a78bd9361b30260896b667553003b95b3e919745cf0", nonce: "1524", blockHash: "0xefeb5d2b42c229b2701a15dce5246e064062ddb46f86783a1f911d092d913e30", transactionIndex: "29", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac00000000000000000000000087a7dba23ec3cff1a30c76c487b9b8327a153b360000000000000000000000000000000000000000000000004ed369e7f4380000", contractAddress: "", cumulativeGasUsed: "1406178", gasUsed: "99959", confirmations: "1125845"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[39]}, {type: "uint256", name: "_amount", value: "5680000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[39], "5680000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540841743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x87a7dba23ec3cff1a30c76c487b9b8327a153b36"}, {name: "share", type: "uint256", value: "142"}, {name: "amount", type: "uint256", value: "5680000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[40], \"71280000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607162", timeStamp: "1540841765", hash: "0x7db26dd9a6e5f52c78e38d94cbeca6d03f9bb0d3d0ec1b49342ccafae35f131e", nonce: "1525", blockHash: "0xc9a2a2d9d4680491c5fe466797878c810bb55ec00fe9a8aaf4eafcc1cd9436bd", transactionIndex: "33", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000ce2bfa2fc4197f36897f5ae6b0b5f780fa2e50cd000000000000000000000000000000000000000000000003dd356e57a5d80000", contractAddress: "", cumulativeGasUsed: "5406910", gasUsed: "100023", confirmations: "1125843"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[40]}, {type: "uint256", name: "_amount", value: "71280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[40], "71280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540841765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xce2bfa2fc4197f36897f5ae6b0b5f780fa2e50cd"}, {name: "share", type: "uint256", value: "1782"}, {name: "amount", type: "uint256", value: "71280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[41], \"8520000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607166", timeStamp: "1540841833", hash: "0xa8c1ca7850cce2ccc721d84abbb99780e7ba1d962b3cc0ba1fb72194a3d39bcb", nonce: "1526", blockHash: "0x064512e1f0012bb0307f8db285671a5c9a029d73433bdce6b7e1268a9f7fb0c3", transactionIndex: "191", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000fd069863e3613193ce443f5e0243ad7deefd930d000000000000000000000000000000000000000000000000763d1edbee540000", contractAddress: "", cumulativeGasUsed: "6213886", gasUsed: "99959", confirmations: "1125839"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[41]}, {type: "uint256", name: "_amount", value: "8520000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[41], "8520000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540841833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xfd069863e3613193ce443f5e0243ad7deefd930d"}, {name: "share", type: "uint256", value: "213"}, {name: "amount", type: "uint256", value: "8520000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[42], \"2840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607166", timeStamp: "1540841833", hash: "0xaeed58255fbbaaece9bc57ccb487487c3fedc85d7e67df751cbcfbb8f2a3e20b", nonce: "1527", blockHash: "0x064512e1f0012bb0307f8db285671a5c9a029d73433bdce6b7e1268a9f7fb0c3", transactionIndex: "192", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000f6770169d4e100d13c8eec6ee10817bf9d45ba050000000000000000000000000000000000000000000000002769b4f3fa1c0000", contractAddress: "", cumulativeGasUsed: "6313781", gasUsed: "99895", confirmations: "1125839"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[42]}, {type: "uint256", name: "_amount", value: "2840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[42], "2840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540841833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xf6770169d4e100d13c8eec6ee10817bf9d45ba05"}, {name: "share", type: "uint256", value: "71"}, {name: "amount", type: "uint256", value: "2840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[43], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607168", timeStamp: "1540841843", hash: "0xa7345757eba783ebc1488c412ea0c57b4d9dfcef01a6d4e276171304a070fd52", nonce: "1528", blockHash: "0x63fd592c11c975663ea8bfc3d1d44d859a578302cd22897bab131b5733c048dd", transactionIndex: "45", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac00000000000000000000000025ff1ccfa7205387b1874bb435588e60ff2d3f9900000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "3150765", gasUsed: "99959", confirmations: "1125837"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[43]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[43], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540841843 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x25ff1ccfa7205387b1874bb435588e60ff2d3f99"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[44], \"142600000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6607170", timeStamp: "1540841857", hash: "0x1af8614b624a14f194a4891e41b5241b203d44228e67345e1e04928b54c63ff6", nonce: "1529", blockHash: "0x1b0285112559046dcb1683ea598d888613d0ba17f92abf82ae6c7de93a45abc1", transactionIndex: "42", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000c7f0a3268aabb0e6f56d901c68486ea3a11b1663000000000000000000000000000000000000000000000007baf8f8790ab40000", contractAddress: "", cumulativeGasUsed: "2586430", gasUsed: "100023", confirmations: "1125835"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[44]}, {type: "uint256", name: "_amount", value: "142600000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[44], "142600000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540841857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xc7f0a3268aabb0e6f56d901c68486ea3a11b1663"}, {name: "share", type: "uint256", value: "3565"}, {name: "amount", type: "uint256", value: "142600000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[45], \"49880000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6607175", timeStamp: "1540841902", hash: "0xc1e535404f890b62b98b5eb81ff14e625336dd80256226ef3c9c2026499aee7e", nonce: "1530", blockHash: "0x87d2abd83f6c7ff308ad910cd39855ceda8ea01c500bb69418a53491e128ad8b", transactionIndex: "34", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000381b278bbd1a39623ce45b28dd0bc9bb977172a8000000000000000000000000000000000000000000000002b4395bb9747c0000", contractAddress: "", cumulativeGasUsed: "1591573", gasUsed: "100023", confirmations: "1125830"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[45]}, {type: "uint256", name: "_amount", value: "49880000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[45], "49880000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540841902 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x381b278bbd1a39623ce45b28dd0bc9bb977172a8"}, {name: "share", type: "uint256", value: "1247"}, {name: "amount", type: "uint256", value: "49880000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[46], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607175", timeStamp: "1540841902", hash: "0xacb5de3fbafeb5d2d229fbbf5f54dc194a653531fff430e3ecd7f5b8432f0ca3", nonce: "1531", blockHash: "0x87d2abd83f6c7ff308ad910cd39855ceda8ea01c500bb69418a53491e128ad8b", transactionIndex: "46", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000abfe188786978ea38af8c3ba924326e9b16be57e00000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "2082477", gasUsed: "99959", confirmations: "1125830"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[46]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[46], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540841902 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xabfe188786978ea38af8c3ba924326e9b16be57e"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[47], \"7120000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607175", timeStamp: "1540841902", hash: "0x4d8558f716c7e028420ad63a07b01964261e181a2a484bfb33aa99cba6280c4e", nonce: "1532", blockHash: "0x87d2abd83f6c7ff308ad910cd39855ceda8ea01c500bb69418a53491e128ad8b", transactionIndex: "80", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000009ac5b1dc4f911f5b3823f716e96a6e71e8ca6beb00000000000000000000000000000000000000000000000062cf5246d0c80000", contractAddress: "", cumulativeGasUsed: "3374720", gasUsed: "99959", confirmations: "1125830"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[47]}, {type: "uint256", name: "_amount", value: "7120000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[47], "7120000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540841902 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x9ac5b1dc4f911f5b3823f716e96a6e71e8ca6beb"}, {name: "share", type: "uint256", value: "178"}, {name: "amount", type: "uint256", value: "7120000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[48], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607178", timeStamp: "1540841949", hash: "0x35da406bd6fcc8bf09eb53d9e0b2bb47c433289c59a24440cc17d20b96a1eff4", nonce: "1533", blockHash: "0x08b658722d378cb7565c2850f5db30272761fc987f5bff43645673dc5c0ffa44", transactionIndex: "131", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000c3ab75122030cb4500a4222c0aeb25391c77a13100000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "5465152", gasUsed: "99895", confirmations: "1125827"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[48]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[48], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540841949 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xc3ab75122030cb4500a4222c0aeb25391c77a131"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[49], \"280000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607185", timeStamp: "1540842098", hash: "0xbad91bdc954ef255aa9bf15052b869390a32e96055aaecb6dda2e038bd4b2dbe", nonce: "1534", blockHash: "0x44bf04cd97723a8c24666672c3e6a9f2796932deba98ac999b0b7cd7f50d65fd", transactionIndex: "43", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000007acea4fd5a4668500d77feeac862b1a50238700500000000000000000000000000000000000000000000000003e2c284391c0000", contractAddress: "", cumulativeGasUsed: "4451283", gasUsed: "99959", confirmations: "1125820"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[49]}, {type: "uint256", name: "_amount", value: "280000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[49], "280000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540842098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x7acea4fd5a4668500d77feeac862b1a502387005"}, {name: "share", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "280000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[50], \"3400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607185", timeStamp: "1540842098", hash: "0xc1998e639e16f163e01df1dfedd1166e01b176154ff5d69a1d5abcbe79581636", nonce: "1535", blockHash: "0x44bf04cd97723a8c24666672c3e6a9f2796932deba98ac999b0b7cd7f50d65fd", transactionIndex: "44", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000da5b64038cc813e9c12aca9000674acaf85702e00000000000000000000000000000000000000000000000002f2f39fc6c540000", contractAddress: "", cumulativeGasUsed: "4551178", gasUsed: "99895", confirmations: "1125820"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[50]}, {type: "uint256", name: "_amount", value: "3400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[50], "3400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540842098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xda5b64038cc813e9c12aca9000674acaf85702e0"}, {name: "share", type: "uint256", value: "85"}, {name: "amount", type: "uint256", value: "3400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[51], \"2840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607185", timeStamp: "1540842098", hash: "0x54f154361f657172ae65479ca29ae870fe992148d35619ad05a649fafe1b8e7f", nonce: "1536", blockHash: "0x44bf04cd97723a8c24666672c3e6a9f2796932deba98ac999b0b7cd7f50d65fd", transactionIndex: "45", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac0000000000000000000000000ad2945d05064ce9f8efd2d9c36d634412f9b85e0000000000000000000000000000000000000000000000002769b4f3fa1c0000", contractAddress: "", cumulativeGasUsed: "4651137", gasUsed: "99959", confirmations: "1125820"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[51]}, {type: "uint256", name: "_amount", value: "2840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[51], "2840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540842098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x0ad2945d05064ce9f8efd2d9c36d634412f9b85e"}, {name: "share", type: "uint256", value: "71"}, {name: "amount", type: "uint256", value: "2840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[52], \"1400000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607185", timeStamp: "1540842098", hash: "0x6d8006b4a3e2783d1eddcaf736158cec04afe43315ac4f22cd7e3df008ec771c", nonce: "1537", blockHash: "0x44bf04cd97723a8c24666672c3e6a9f2796932deba98ac999b0b7cd7f50d65fd", transactionIndex: "46", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac000000000000000000000000cea077172675bf31e879bba71fb46c3188591070000000000000000000000000000000000000000000000000136dcc951d8c0000", contractAddress: "", cumulativeGasUsed: "4751096", gasUsed: "99959", confirmations: "1125820"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[52]}, {type: "uint256", name: "_amount", value: "1400000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[52], "1400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540842098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0xcea077172675bf31e879bba71fb46c3188591070"}, {name: "share", type: "uint256", value: "35"}, {name: "amount", type: "uint256", value: "1400000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addContribution( addressList[53], \"2840000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6607205", timeStamp: "1540842476", hash: "0xfe37d235432882d33f961668559f23af8d61d119fe2e5a610963d74b9b9b3299", nonce: "1539", blockHash: "0xb694357f9e598e33a201070a939fadad3ed2626a3d39332355ff77e9a868845f", transactionIndex: "7", from: "0x7b1660682078fe0efd9310e8efe32cb93a0417bc", to: "0xa038b9b36f22485ff0d4e48842d4a1905054e856", value: "0", gas: "140000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x39ecacac00000000000000000000000059666bc2ab8a7e1e457e7d642f0693d238627b370000000000000000000000000000000000000000000000002769b4f3fa1c0000", contractAddress: "", cumulativeGasUsed: "4185094", gasUsed: "99959", confirmations: "1125800"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[53]}, {type: "uint256", name: "_amount", value: "2840000000000000000"}], name: "addContribution", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addContribution(address,uint256)" ]( addressList[53], "2840000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540842476 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "share", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Contribution", events: [{name: "sender", type: "address", value: "0x59666bc2ab8a7e1e457e7d642f0693d238627b37"}, {name: "share", type: "uint256", value: "71"}, {name: "amount", type: "uint256", value: "2840000000000000000"}], address: "0xa038b9b36f22485ff0d4e48842d4a1905054e856"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1232769813000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
