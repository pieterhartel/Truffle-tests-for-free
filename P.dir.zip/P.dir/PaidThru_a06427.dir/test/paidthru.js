const PaidThru = artifacts.require( "./PaidThru.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PaidThru" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x79ab658eAF45a19D2961e0E4d09C9C4566A06427", "0x745b70072A65A3D4bF96eBFCa5Aec4FE0b932dB1", "0xA0fF56099E7Dec74aa4Ee47BE2f18bc194E8518a", "0xd3F18C70a2cfeb61010F54760e72aC88E6Df53f5", "0x001d909dc10b401392d1f4128CFb95466603B6c3", "0x983d961cEF5d6FDa1089cBD23FB4fc274e73Aa2E", "0x8fb186b94756f5658D16dF90ABCE4B84bceeA31e", "0xf3cA2B8c4191948837EeFC25f559f987F47228b1", "0x39C269A41B67fe727752FAfc26432c1738fDC1bc", "0xDD6f48aC87d136479B37F8c7A77d54b7d9340443", "0x7E4e65f2764000846f4F1234F7fD70f76FE3fa9b", "0xd383ddbAE47106FF8038977AC1fD48d75aF72486", "0x393A70BC0cDbB6D7bF6b06bFB635ac5f2cCc2d12", "0x4C5E674121379595351191cd52A6CdcA4a1AE2a7", "0x0Af86051172d0681d6Efaef54aE15448Afc8a27b", "0x70c722c6bCb398f85eCe53146965C365791C1979", "0xbEcAeFA3566024AD0629138D3f14A6014e04E60F", "0x52CB962Ff74376d3D58DE7Ef51aB0EAc8f4D06a0", "0x33a545dBD475E210C6E5D0Bc967f7A274C8c6494", "0xbE2aC9ac6A02e0293382AbE94D68592e7acc3cD5", "0xCA918d0aB86bab37c2CB691D69b0dCCa6e8aBB17", "0xA7C6109cCAfb37ab0a3025e75Aa932B2145297E4", "0x28745C81bb2E2567219d9ae9D31F1ef47e201391", "0xB83EbbfdC7c1efd73BAaD726107Bfd487BAa1474", "0x248fDa68c522330e3c7DEfe56c10d5f299Df75a5", "0x0bE01945EeCa5C85f7aeeAed48326cC60aF72750", "0x56C4cAbda999b63a0aCb017f14e2882AB969783A", "0x88FB6c6871525ECB1c4128f654AD64DFe508A399", "0x20E55DF571e41Cab1F7fdCBda7cc7bA3AF32f44E", "0xF6FB8cb0483B2A2f9D42bB39e2057a18326BDe5d", "0xEe172400aCB0C1b83cb733C8B453cb802f3dEC66", "0x55fcE2d3Fe2aD2334048A35fCD71c0E40C3b65b9", "0x6f51B4727e5783603C5A21c2278a87f2FC039d29", "0x71ec06982dc33161f8B2a95400908D5Ef9581bB2", "0x152Ca49Ec9bc026f79Fd1a90A0fA96398B7E0cCa", "0x2aEca22F9E3eF645Fac57510f065eCcA6823f986", "0xEF43Df51A1cAd63ce6C522d7e095c89A261600ea", "0xeFafF3c81a10e700fB992CbeD55E83E242477f45", "0x5A8De4781bcCa6067DBcB05e560e418f98d61198", "0x3E80aE493A4f036642bDBAa5F7476Ce5509F0b56", "0x6E2A5608034Da328687B423e326ecbB09430d45C", "0x126787B8Df2865718190E516f1FE32aA9519e82D", "0xeb356cC5cDe824173B4e9c1D218042bBF8B94c83", "0x10ad92751f7dF8c1Aa653Ba4cd6b085ddBeF584E", "0xf9A42075E087581bC9dc6C352A452B4252b39F3e", "0xA4Bb67f1e0203A9EB5Dc83244457112c80DD02ef", "0x129BBfeBb515ACdE57F3b88f30da5d173fA464d2"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "supply", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [], name: "Freeze", type: "event"}, {anonymous: false, inputs: [], name: "Unfreeze", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "target", type: "address"}, {indexed: false, name: "frozen", type: "bool"}], name: "FrozenFunds", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_token", type: "address"}, {indexed: false, name: "_refund", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "RefundTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Freeze()", "Unfreeze()", "FrozenFunds(address,bool)", "RefundTokens(address,address,uint256)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x615acbaede366d76a8b8cb2a9ada6a71495f0786513d71aa97aaf0c3910b78de", "0x2f05ba71d0df11bf5fa562a6569d70c4f80da84284badbe015ce1456063d0ded", "0x48335238b4855f35377ed80f164e8c6f3c366e54ac00b96a6402d4a9814a03a5", "0xfab5e7a27e02736e52f60776d307340051d8bc15aee0ef211c7a4aa2a8cdc154", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6683085 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6802381 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "PaidThru", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "supply", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PaidThru", function( accounts ) {

	it( "TEST: PaidThru(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6683085", timeStamp: "1541917803", hash: "0x287610a983b93b38a2ac57a5e030b766e1e44af3ba09495f73e221e1400dc3b6", nonce: "0", blockHash: "0x3d3999774269a2f74ce29e80951b6833c4462c6be158ce7259df71ca41dce78b", transactionIndex: "20", from: "0x745b70072a65a3d4bf96ebfca5aec4fe0b932db1", to: 0, value: "0", gas: "868925", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x026364ff", contractAddress: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", cumulativeGasUsed: "1765610", gasUsed: "868925", confirmations: "1034544"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "PaidThru", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PaidThru.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541917803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PaidThru.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17778272000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: createTokens( \"30000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6683096", timeStamp: "1541917980", hash: "0x6bb14d1fd6a6adcffc2008dafcc379df06479289a3e1f2ec46ba90884ba0c3a1", nonce: "1", blockHash: "0x34e30a7b9ccf65f753f0245bb60f212d30055b77d2b823fdbb9f7f38a06e6acc", transactionIndex: "44", from: "0x745b70072a65a3d4bf96ebfca5aec4fe0b932db1", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "65283", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x7e1f2bb800000000000000000000000000000000000000000000000000001b48eb57e000", contractAddress: "", cumulativeGasUsed: "2779580", gasUsed: "65283", confirmations: "1034533"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "30000000000000"}], name: "createTokens", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createTokens(uint256)" ]( "30000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541917980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x745b70072a65a3d4bf96ebfca5aec4fe0b932db1"}, {name: "_value", type: "uint256", value: "30000000000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[1,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17778272000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"100000\" )", async function( ) {
		const txOriginal = {blockNumber: "6689456", timeStamp: "1542008319", hash: "0x8222a51ca995d21f5504768bc2341c6c9b5eb7b31cf2e23cd3a5462ff4b49a59", nonce: "2", blockHash: "0x43df95bc7934e7d2b75e803741acf289a0d62a05a08273d2a7100972d40c3530", transactionIndex: "38", from: "0x745b70072a65a3d4bf96ebfca5aec4fe0b932db1", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a0ff56099e7dec74aa4ee47be2f18bc194e8518a00000000000000000000000000000000000000000000000000000000000186a0", contractAddress: "", cumulativeGasUsed: "3872734", gasUsed: "52535", confirmations: "1028173"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "100000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "100000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542008319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x745b70072a65a3d4bf96ebfca5aec4fe0b932db1"}, {name: "_to", type: "address", value: "0xa0ff56099e7dec74aa4ee47be2f18bc194e8518a"}, {name: "_value", type: "uint256", value: "100000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[2,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17778272000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"29999999900000\" )", async function( ) {
		const txOriginal = {blockNumber: "6689466", timeStamp: "1542008572", hash: "0x083575268dd0a93b59f18eeefb277e940525e42fae7b2dd79c9e61a32e586667", nonce: "3", blockHash: "0x99fb22ebae1a0998621ca657d888d80bb9a4898ae66dbd777580216066320fa7", transactionIndex: "76", from: "0x745b70072a65a3d4bf96ebfca5aec4fe0b932db1", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "39727", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a0ff56099e7dec74aa4ee47be2f18bc194e8518a00000000000000000000000000000000000000000000000000001b48eb565960", contractAddress: "", cumulativeGasUsed: "3685631", gasUsed: "22727", confirmations: "1028163"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "29999999900000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "29999999900000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542008572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x745b70072a65a3d4bf96ebfca5aec4fe0b932db1"}, {name: "_to", type: "address", value: "0xa0ff56099e7dec74aa4ee47be2f18bc194e8518a"}, {name: "_value", type: "uint256", value: "29999999900000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "17778272000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"1000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6787703", timeStamp: "1543401415", hash: "0xad0a559674ef244806187d5c6fa8967c6febce3bbe151626bcc9cf94fb925f32", nonce: "2", blockHash: "0x424b9ecc06e72d1a3949b29e0a840894bd4be586f59a3ac397ba5d6ee30ca0c1", transactionIndex: "1", from: "0xa0ff56099e7dec74aa4ee47be2f18bc194e8518a", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d3f18c70a2cfeb61010f54760e72ac88e6df53f500000000000000000000000000000000000000000000000000000000000f4240", contractAddress: "", cumulativeGasUsed: "73535", gasUsed: "52535", confirmations: "929926"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "1000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "1000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543401415 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xa0ff56099e7dec74aa4ee47be2f18bc194e8518a"}, {name: "_to", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_value", type: "uint256", value: "1000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "4547666000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"999000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6787711", timeStamp: "1543401575", hash: "0x7e6c815f7ede40a9ffe2568d91709fe95f3a19b264f2df0aa0dadef7179f4a58", nonce: "3", blockHash: "0x354020343431071a7b230074d91ec49678c5f84e4600e7e27d6f7ac1a861571c", transactionIndex: "33", from: "0xa0ff56099e7dec74aa4ee47be2f18bc194e8518a", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "37599", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d3f18c70a2cfeb61010f54760e72ac88e6df53f5000000000000000000000000000000000000000000000000000000003b8b87c0", contractAddress: "", cumulativeGasUsed: "997496", gasUsed: "37599", confirmations: "929918"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "999000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "999000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543401575 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xa0ff56099e7dec74aa4ee47be2f18bc194e8518a"}, {name: "_to", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_value", type: "uint256", value: "999000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "4547666000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789784", timeStamp: "1543431062", hash: "0xd468260bcb208501dee74a1993335e7d2d7ea692fa82a3f113bc1e9d5c16ae6c", nonce: "3", blockHash: "0x571d545bf5e72b20b3328c43b872aa81027fe8a4abaad08621039c12be583ff9", transactionIndex: "47", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52471", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000001d909dc10b401392d1f4128cfb95466603b6c30000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "2279521", gasUsed: "52471", confirmations: "927845"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543431062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x001d909dc10b401392d1f4128cfb95466603b6c3"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789805", timeStamp: "1543431356", hash: "0x5b56fd16da7147b382a37ab8ee0a6d6f7c93180025fad99ad49bc955bebafda7", nonce: "4", blockHash: "0x26c78d6576856ba08d8e4636d70ed06d638992deb8b80de4346106cee02bdc70", transactionIndex: "2", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000983d961cef5d6fda1089cbd23fb4fc274e73aa2e0000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "230616", gasUsed: "52535", confirmations: "927824"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543431356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x983d961cef5d6fda1089cbd23fb4fc274e73aa2e"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789842", timeStamp: "1543431961", hash: "0x8495bb32e3986c6023fe285f767ce271a6927fbd8235f4ca0843a0711ddd725f", nonce: "5", blockHash: "0xc83437cbeaa762f45759953f481112a7070479e9fa60d793d6e17c9742e1ad58", transactionIndex: "6", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000008fb186b94756f5658d16df90abce4b84bceea31e0000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "244406", gasUsed: "52535", confirmations: "927787"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543431961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x8fb186b94756f5658d16df90abce4b84bceea31e"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789883", timeStamp: "1543432401", hash: "0x955da5e9a4c724049a1b9621edfe1acd0f0f472b1398d1f8db1d79f781c6413e", nonce: "6", blockHash: "0x95b55e8b57c053ac8c6091cab9d9f14cc70c8edb697a09d35d576d7a44af9cc3", transactionIndex: "5", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000f3ca2b8c4191948837eefc25f559f987f47228b100000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "646919", gasUsed: "52535", confirmations: "927746"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543432401 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xf3ca2b8c4191948837eefc25f559f987f47228b1"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789916", timeStamp: "1543432997", hash: "0xdcf8d491a9e30c323956497f54baca88f0f9c50d80b6b367b162362d4b48aed6", nonce: "7", blockHash: "0x7bff8902588f5c295704986b1476567646d80f79aa778bcf9ddbe34b1f7d086b", transactionIndex: "17", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000039c269a41b67fe727752fafc26432c1738fdc1bc00000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "1305487", gasUsed: "52535", confirmations: "927713"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543432997 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x39c269a41b67fe727752fafc26432c1738fdc1bc"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789934", timeStamp: "1543433186", hash: "0xb6c56a240bc5e35b955c08fedafc92ea8517aea2c9efbada24b5e2eade10e06f", nonce: "8", blockHash: "0xf6fb110730a69a683753c0c616dae277abe811a01cda39b67d130a82cb63445d", transactionIndex: "16", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000dd6f48ac87d136479b37f8c7a77d54b7d93404430000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "1355090", gasUsed: "52535", confirmations: "927695"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543433186 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xdd6f48ac87d136479b37f8c7a77d54b7d9340443"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789950", timeStamp: "1543433450", hash: "0x1f048b35681d70c4c289090390c7efb9d5148470da12a531f4fb658847e6c64a", nonce: "9", blockHash: "0x1ed0c50de43fabaef06e1d55de2ed0c463c32db9b5737c4d5ba23223b8786039", transactionIndex: "51", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52471", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000007e4e65f2764000846f4f1234f7fd70f76fe3fa9b00000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "3543896", gasUsed: "52471", confirmations: "927679"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543433450 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x7e4e65f2764000846f4f1234f7fd70f76fe3fa9b"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789955", timeStamp: "1543433539", hash: "0x63d4dc378507562e7c4e3aa99b379c1f03f9456472895b20ec285305c0b35d3b", nonce: "10", blockHash: "0x208e1d17fabd9977a50c474b34aec18c9acc97ffba0a1b42900ac094df308cf8", transactionIndex: "171", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d383ddbae47106ff8038977ac1fd48d75af724860000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "3924320", gasUsed: "52535", confirmations: "927674"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543433539 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xd383ddbae47106ff8038977ac1fd48d75af72486"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6789960", timeStamp: "1543433585", hash: "0xeed021d4371735af3edbac21631b33e87d3d36deea04ed089120f48ad6e7f470", nonce: "11", blockHash: "0xbc81409407a3662dee8aaf720a701df1c8854d2a2fc9b53aad09ccab53ce7cc8", transactionIndex: "104", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000393a70bc0cdbb6d7bf6b06bfb635ac5f2ccc2d1200000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "4376152", gasUsed: "52535", confirmations: "927669"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[14], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543433585 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x393a70bc0cdbb6d7bf6b06bfb635ac5f2ccc2d12"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790003", timeStamp: "1543434222", hash: "0xfbb36b9c34f3a95b64ab2df197a1fbc05abfa88bacebeace1bef73e74c004c07", nonce: "12", blockHash: "0xcc0aa769fd34b3b6aecac03be1352e7bd7ea1786ab850e477adc39e0265cb67e", transactionIndex: "30", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000004c5e674121379595351191cd52a6cdca4a1ae2a700000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "4165340", gasUsed: "52535", confirmations: "927626"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543434222 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x4c5e674121379595351191cd52a6cdca4a1ae2a7"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790062", timeStamp: "1543434965", hash: "0xfd98748d73dac6ee5d428398ed8300bde0fc011d712e8acf03104650ba54c9f6", nonce: "13", blockHash: "0x437b62fe386d8b109262a376a1678d8846c1ab03341ab43d2950347a047c7de3", transactionIndex: "7", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000af86051172d0681d6efaef54ae15448afc8a27b0000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "387601", gasUsed: "52535", confirmations: "927567"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543434965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x0af86051172d0681d6efaef54ae15448afc8a27b"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790072", timeStamp: "1543435045", hash: "0x7d4b6fc841f5e62075902b5ad6507477b9b9e2d87f073a185ec0a048b2764a90", nonce: "14", blockHash: "0x2aed15d62cf490f4b9b63c52bae481257fef1a54703e3cb03cbf735d847ccc97", transactionIndex: "27", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000070c722c6bcb398f85ece53146965c365791c197900000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "1261567", gasUsed: "52535", confirmations: "927557"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543435045 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x70c722c6bcb398f85ece53146965c365791c1979"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790086", timeStamp: "1543435239", hash: "0xabbf4a1cbe9f7efb0e09d49dee9bbecf9c7f2864a579846741771b26d177d23b", nonce: "15", blockHash: "0x9b80137222ffdd9185374410e6718724f3f33d0263c96791892f5b2a690ccab6", transactionIndex: "5", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000becaefa3566024ad0629138d3f14a6014e04e60f00000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "279616", gasUsed: "52535", confirmations: "927543"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543435239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xbecaefa3566024ad0629138d3f14a6014e04e60f"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[19], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790113", timeStamp: "1543435651", hash: "0xb1daf7a2508f4518e325c519eae97780440a7cc70f8ea18faca53d74546267ec", nonce: "16", blockHash: "0x7fac9b03e108c87edfb11f83cb7a02a90876a09f79b371e2454a9dbb077da484", transactionIndex: "19", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000052cb962ff74376d3d58de7ef51ab0eac8f4d06a000000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "1521514", gasUsed: "52535", confirmations: "927516"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[19], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543435651 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x52cb962ff74376d3d58de7ef51ab0eac8f4d06a0"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790134", timeStamp: "1543435985", hash: "0x3873f8ccb7a6ab9f4b5a474d5f342ddaca66e37767a54c0e97cdb1c2dfab3a9c", nonce: "17", blockHash: "0xa0677d5c5f6c8377c45bcb81feef6d325cfb83411dd8f4b6fa405476cf91a584", transactionIndex: "21", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000033a545dbd475e210c6e5d0bc967f7a274c8c649400000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "1800366", gasUsed: "52535", confirmations: "927495"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543435985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x33a545dbd475e210c6e5d0bc967f7a274c8c6494"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[21], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790142", timeStamp: "1543436178", hash: "0xe802fc3f827218b92eaf885da2146f84fe4df3d4bbd607a1de12beba2aebf15e", nonce: "18", blockHash: "0x2ea7159bfc49ece4785e58247ec55c7e3ef152fa23470da8eff0c10499fe57bc", transactionIndex: "24", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000be2ac9ac6a02e0293382abe94d68592e7acc3cd500000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "2301174", gasUsed: "52535", confirmations: "927487"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[21], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543436178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xbe2ac9ac6a02e0293382abe94d68592e7acc3cd5"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"25000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790341", timeStamp: "1543439203", hash: "0x3000607454942b3c085a49f8a7a77dd7529d0c9fd9e4c4d1543d009f9fe1178a", nonce: "19", blockHash: "0xbae271f4fcda3c93977fc757093ef7afd6070bce35f44f8280227e1f5a9bf290", transactionIndex: "7", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52599", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000ca918d0ab86bab37c2cb691d69b0dcca6e8abb1700000000000000000000000000000000000000000000000000000000017d7840", contractAddress: "", cumulativeGasUsed: "755520", gasUsed: "52599", confirmations: "927288"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "25000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "25000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543439203 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xca918d0ab86bab37c2cb691d69b0dcca6e8abb17"}, {name: "_value", type: "uint256", value: "25000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790378", timeStamp: "1543439769", hash: "0xb16cf82d04342be1373fd80c32d018fc244020a796e9d720bb30b5e613596e2a", nonce: "20", blockHash: "0x5ba5467759f7ff6bea6936fd5850eb899ae52d98408b7682ca8a934675351384", transactionIndex: "21", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a7c6109ccafb37ab0a3025e75aa932b2145297e40000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "620847", gasUsed: "52535", confirmations: "927251"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543439769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xa7c6109ccafb37ab0a3025e75aa932b2145297e4"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790387", timeStamp: "1543439895", hash: "0x21556002f848b8c34ba9d2822acee5b59f74f3eaae92869033ecf197707657f3", nonce: "21", blockHash: "0xc8ad67ab3ca7ac62b6e1838fc52cf058087ad3253d09fa988056425ff6dedcf1", transactionIndex: "4", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000028745c81bb2e2567219d9ae9d31f1ef47e20139100000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "328532", gasUsed: "52535", confirmations: "927242"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543439895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x28745c81bb2e2567219d9ae9d31f1ef47e201391"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790399", timeStamp: "1543440075", hash: "0x260dbd2801e8995b84e2e168e5b379dc4ab15dc57a0ab6538b8b30cb2633972a", nonce: "22", blockHash: "0xf09b758775cc12f2c55294a6d7f27dd81618466646f84b75c827160d91d62d8b", transactionIndex: "9", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b83ebbfdc7c1efd73baad726107bfd487baa147400000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "461283", gasUsed: "52535", confirmations: "927230"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543440075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xb83ebbfdc7c1efd73baad726107bfd487baa1474"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"25000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790426", timeStamp: "1543440403", hash: "0xc1b0192641a5eeba45af9f1af475f69768639dc7b0c0a25bcf335d783a0f9bfe", nonce: "23", blockHash: "0x1089e2a77283464e5cf112836fae2f32a418a4dcc12b1fbb72309dfef921c035", transactionIndex: "39", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52599", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000248fda68c522330e3c7defe56c10d5f299df75a500000000000000000000000000000000000000000000000000000000017d7840", contractAddress: "", cumulativeGasUsed: "1129657", gasUsed: "52599", confirmations: "927203"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "25000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "25000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543440403 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x248fda68c522330e3c7defe56c10d5f299df75a5"}, {name: "_value", type: "uint256", value: "25000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790906", timeStamp: "1543446914", hash: "0x7cff95a9b1711712f2f823155d6b8d80795abd83d8e2d9c1976a0cfcbef30513", nonce: "24", blockHash: "0x78d882fed03521427888e643630af93ee063e3675dff22c32766d9173e6a3115", transactionIndex: "60", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000be01945eeca5c85f7aeeaed48326cc60af727500000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "6461408", gasUsed: "52535", confirmations: "926723"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543446914 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x0be01945eeca5c85f7aeeaed48326cc60af72750"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6790921", timeStamp: "1543447088", hash: "0x2ebb725f11b59d15be79ea5c8009c1a296249d4efad1dccfc170f8495e1c245f", nonce: "25", blockHash: "0x5b2058e95ace46b35a6e92cf6317bf848960de28d5a70c2525cd01d460289e55", transactionIndex: "12", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000056c4cabda999b63a0acb017f14e2882ab969783a0000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "580113", gasUsed: "52535", confirmations: "926708"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543447088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x56c4cabda999b63a0acb017f14e2882ab969783a"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6793713", timeStamp: "1543486624", hash: "0x645887e6476c59e3ac3bfd53632dd015ff814812ecba5627e955442e79bbf4b7", nonce: "26", blockHash: "0xef54666a0f6d50a16cd3807f793ab93a83926bb89b4bd092429c382f5509a87d", transactionIndex: "32", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000088fb6c6871525ecb1c4128f654ad64dfe508a3990000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "6284655", gasUsed: "52535", confirmations: "923916"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "10000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543486624 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x88fb6c6871525ecb1c4128f654ad64dfe508a399"}, {name: "_value", type: "uint256", value: "10000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"10000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6793724", timeStamp: "1543486821", hash: "0x3cdf41a7ce8b4d29ee802758a29c0b33c85f9e23b1596fb98ee2088c7239b2ba", nonce: "27", blockHash: "0x3b666cfecf0686f248900e38535e7ed40ebb249fadd42ffbaab9de7387cfbfca", transactionIndex: "20", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25000", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb00000000000000000000000020e55df571e41cab1f7fdcbda7cc7ba3af32f44e0000000000000000000000000000000000000000000000000000000000989680", contractAddress: "", cumulativeGasUsed: "611617", gasUsed: "25000", confirmations: "923905"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "10000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"40000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6794009", timeStamp: "1543490520", hash: "0xfe050e51c2ed0e0d21d7ee80ce94092ee2a5b74e6b8308acb0218aa7adac85f1", nonce: "28", blockHash: "0x7e812124bb6d49cdb94b0702dd0150a6d71529820ac5e30828c0aff078094858", transactionIndex: "13", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25000", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000f6fb8cb0483b2a2f9d42bb39e2057a18326bde5d0000000000000000000000000000000000000000000000000000000002625a00", contractAddress: "", cumulativeGasUsed: "737316", gasUsed: "25000", confirmations: "923620"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "40000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[32], \"100000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6794109", timeStamp: "1543491743", hash: "0x7348533f40a5b64feea927b60637d8c0909ea3525556973bd01ad42206042d94", nonce: "29", blockHash: "0x59ed07f9c7484402b9886d15d69a7b3f927241bb3624d586292930473acf0b4d", transactionIndex: "62", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52471", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000ee172400acb0c1b83cb733c8b453cb802f3dec660000000000000000000000000000000000000000000000000000000005f5e100", contractAddress: "", cumulativeGasUsed: "7535080", gasUsed: "52471", confirmations: "923520"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "100000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[32], "100000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543491743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xee172400acb0c1b83cb733c8b453cb802f3dec66"}, {name: "_value", type: "uint256", value: "100000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[33], \"2500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6794674", timeStamp: "1543499981", hash: "0x63fdffeeb1e7dc096b35b41f88a41fb4f6a51c14d67059e0def04f777d7a4bc0", nonce: "30", blockHash: "0x4a79071dfe19cf05de0a37daf0bdd92e0ae544a65b71b24b47abfe9caf35eab6", transactionIndex: "4", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000055fce2d3fe2ad2334048a35fcd71c0e40c3b65b900000000000000000000000000000000000000000000000000000000002625a0", contractAddress: "", cumulativeGasUsed: "462984", gasUsed: "52535", confirmations: "922955"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_value", value: "2500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[33], "2500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543499981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x55fce2d3fe2ad2334048a35fcd71c0e40c3b65b9"}, {name: "_value", type: "uint256", value: "2500000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"5000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6794725", timeStamp: "1543500574", hash: "0x3ee4ee9583e7d83e52bc297ed2c99ddbbd4dee8b0fed8107ffaec86e7e89364c", nonce: "31", blockHash: "0x07054b6337468343e6426aec5fce08906ba4d5f4d242bc1249aedca48ffdcdae", transactionIndex: "9", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000006f51b4727e5783603c5a21c2278a87f2fc039d2900000000000000000000000000000000000000000000000000000000004c4b40", contractAddress: "", cumulativeGasUsed: "364076", gasUsed: "52535", confirmations: "922904"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "5000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "5000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543500574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x6f51b4727e5783603c5a21c2278a87f2fc039d29"}, {name: "_value", type: "uint256", value: "5000000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[35], \"2500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6794759", timeStamp: "1543501147", hash: "0xf471f063af78fb2dcaa0683cf8605c0002c280e8d3e21543545f784ac8d94c54", nonce: "32", blockHash: "0x51001be9d81991c0b2690a1e78d18a16e21892aa6ceb8c2c18ecf216205997b7", transactionIndex: "83", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52471", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000071ec06982dc33161f8b2a95400908d5ef9581bb200000000000000000000000000000000000000000000000000000000002625a0", contractAddress: "", cumulativeGasUsed: "2674219", gasUsed: "52471", confirmations: "922870"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_value", value: "2500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[35], "2500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543501147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x71ec06982dc33161f8b2a95400908d5ef9581bb2"}, {name: "_value", type: "uint256", value: "2500000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[36], \"2500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6794897", timeStamp: "1543503162", hash: "0x08ff4001aa78ec5b90e491196fc3aac461099859e70bee93a3621c5ef5c766b5", nonce: "33", blockHash: "0xfee81c441110d86c0288def4b7be8f5114a3bf65651a627bf929c0573f6bab9b", transactionIndex: "40", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000152ca49ec9bc026f79fd1a90a0fa96398b7e0cca00000000000000000000000000000000000000000000000000000000002625a0", contractAddress: "", cumulativeGasUsed: "2125998", gasUsed: "52535", confirmations: "922732"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_value", value: "2500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[36], "2500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543503162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x152ca49ec9bc026f79fd1a90a0fa96398b7e0cca"}, {name: "_value", type: "uint256", value: "2500000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"2500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6795155", timeStamp: "1543507204", hash: "0xbd0a4000b5e249b3291a6770061e24a5de139e222653292ba8fbf56a2037460a", nonce: "34", blockHash: "0xc5e825e85f4adcb5a3e9703431390ca25328f293c7545468c00a74fa7b5dd12b", transactionIndex: "41", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002aeca22f9e3ef645fac57510f065ecca6823f98600000000000000000000000000000000000000000000000000000000002625a0", contractAddress: "", cumulativeGasUsed: "2193717", gasUsed: "52535", confirmations: "922474"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "2500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "2500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543507204 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0x2aeca22f9e3ef645fac57510f065ecca6823f986"}, {name: "_value", type: "uint256", value: "2500000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[38], \"2500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6796783", timeStamp: "1543530057", hash: "0x86fb6da8719583b37998202c32655195c82c5d0da9db78457c57c3c97a53fa43", nonce: "35", blockHash: "0x01a8f0c22a6d7cca22a4d7d9ebf1e0470c0dee6255e360cbcba1d0eb294f5b1d", transactionIndex: "7", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "52535", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000ef43df51a1cad63ce6c522d7e095c89a261600ea00000000000000000000000000000000000000000000000000000000002625a0", contractAddress: "", cumulativeGasUsed: "218823", gasUsed: "52471", confirmations: "920846"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "2500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[38], "2500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543530057 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5"}, {name: "_to", type: "address", value: "0xef43df51a1cad63ce6c522d7e095c89a261600ea"}, {name: "_value", type: "uint256", value: "2500000"}], address: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6799762", timeStamp: "1543572871", hash: "0xd53c3b2331fa4eddd6d280c79a9247d1c22ba92e80df5102fc1d546070d9edc0", nonce: "36", blockHash: "0x6ff5b853ee33d947720846d6c258880be5403473df289c204c83b7877eb000ba", transactionIndex: "83", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb0000000000000000000000008fb186b94756f5658d16df90abce4b84bceea31e00000000000000000000000000000000000000000000000000000000000f4240", contractAddress: "", cumulativeGasUsed: "3660776", gasUsed: "25535", confirmations: "917867"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "1000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"1000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6799769", timeStamp: "1543573032", hash: "0xaffd6440ceccbefd1d562953c4803d447cb8272f3b51c9dcd2de48f31db0504e", nonce: "37", blockHash: "0x92fdd8b66e3e35f2f9a395ee371bcb399fcd8256977c2d0e22272f93f6acafdd", transactionIndex: "39", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000efaff3c81a10e700fb992cbed55e83e242477f4500000000000000000000000000000000000000000000000000000000000f4240", contractAddress: "", cumulativeGasUsed: "2411875", gasUsed: "25535", confirmations: "917860"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "1000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801435", timeStamp: "1543596473", hash: "0xe7d70b96c590b6d54ec1877f900f55d86de5c42619d0401ab90dc84f4b1cb76e", nonce: "38", blockHash: "0x3a25f0c3fab71b80ae729ea33faa498ff639bc046ea4a49069fc69fd257bda4a", transactionIndex: "24", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb0000000000000000000000005a8de4781bcca6067dbcb05e560e418f98d6119800000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "921941", gasUsed: "25535", confirmations: "916194"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[41], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801465", timeStamp: "1543597042", hash: "0x1069a9755279121b90bf04f4e80068ee2270e89324a78f2eec2bdbb98c68664f", nonce: "39", blockHash: "0x96f06d2aac3ee7183080ce72999a92305497117405f452833fd669ee02758ca7", transactionIndex: "31", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb0000000000000000000000003e80ae493a4f036642bdbaa5f7476ce5509f0b5600000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "2405149", gasUsed: "25535", confirmations: "916164"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[42], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801474", timeStamp: "1543597141", hash: "0x00dc86efec89a121e4457d5f11207a14a8d23708d270e10e522fed868e35a2a3", nonce: "40", blockHash: "0x7c09174005b6b3e61820c63b0fdb499507e0c7814561812bd685acfeff5d294c", transactionIndex: "43", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb0000000000000000000000006e2a5608034da328687b423e326ecbb09430d45c00000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "2428668", gasUsed: "25535", confirmations: "916155"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[43], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801479", timeStamp: "1543597220", hash: "0x6b3dd46b2e3dc0d838eda1543db6132bd70fdb6b787539b2a0f1e72b7da793a6", nonce: "41", blockHash: "0x20baa42e841b0e0547638010a2ef702072f53584109456065311638ff366e444", transactionIndex: "38", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000126787b8df2865718190e516f1fe32aa9519e82d00000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "1225321", gasUsed: "25535", confirmations: "916150"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[44], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801482", timeStamp: "1543597307", hash: "0x0b26a9761b20faa5c689a56fad68fbffb4d6b7e697f967a616da3988ffd051c5", nonce: "42", blockHash: "0x1be5b4e8c8c5495e7e3f6db6b0685d12627ede57bd11a10696f0390300aed1e9", transactionIndex: "6", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000eb356cc5cde824173b4e9c1d218042bbf8b94c8300000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "296240", gasUsed: "25535", confirmations: "916147"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[44]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801507", timeStamp: "1543597579", hash: "0x87076497595e824fb5d04ca93ba26e39d26f59854ed0fcd2b805b93390bfc460", nonce: "43", blockHash: "0x4f1c342b3aaa68dd92dbe2345de17e7545a43364c2b4a3b723eead809e1d5d83", transactionIndex: "13", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb00000000000000000000000010ad92751f7df8c1aa653ba4cd6b085ddbef584e00000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "977596", gasUsed: "25535", confirmations: "916122"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801514", timeStamp: "1543597678", hash: "0xa71dd2053c19290e754bef48d34cb81f0d08aa24e6208b72fae8308c8a28507b", nonce: "44", blockHash: "0x5498334559414bdbe13bf8d1f599c09b020281ac8b031fbccbac69491591b575", transactionIndex: "24", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000f9a42075e087581bc9dc6c352a452b4252b39f3e00000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "1544451", gasUsed: "25535", confirmations: "916115"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[47], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6801546", timeStamp: "1543598264", hash: "0x4f0a37417d3d3ed15e454c9acdaf8f6f6fa49d0d3176ca1bb923962a47cd2d23", nonce: "45", blockHash: "0xdef9fd23e77d9f1bac5bf3f93b8fdef2cd8fb9682dc58002efe2637d3392b14d", transactionIndex: "36", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000a4bb67f1e0203a9eb5dc83244457112c80dd02ef00000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "1708296", gasUsed: "25535", confirmations: "916083"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[47]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"7500000\" )", async function( ) {
		const txOriginal = {blockNumber: "6802381", timeStamp: "1543609310", hash: "0x2587f8a3c81803bf5f439e9c8d3cd13035ddebe42ed53d9546110728c8577bc4", nonce: "46", blockHash: "0x1bc6e317d98bdba5497629da746557415ba844c7eb49079a47ab956afbd1d6e9", transactionIndex: "115", from: "0xd3f18c70a2cfeb61010f54760e72ac88e6df53f5", to: "0x79ab658eaf45a19d2961e0e4d09c9c4566a06427", value: "0", gas: "25535", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000129bbfebb515acde57f3b88f30da5d173fa464d200000000000000000000000000000000000000000000000000000000007270e0", contractAddress: "", cumulativeGasUsed: "7975747", gasUsed: "25535", confirmations: "915248"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[48]}, {type: "uint256", name: "_value", value: "7500000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "51859040000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
