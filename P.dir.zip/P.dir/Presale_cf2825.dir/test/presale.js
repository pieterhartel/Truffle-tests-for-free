const Presale = artifacts.require( "./Presale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Presale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xe0fc5d52576E05DD7403782bA1d9a7fC82Cf2825", "0x9C38C7e22Cb20b055E008775617224d0eC25C91F", "0x3669ad54675E94e14196528786645c858b8391F1", "0x0000003937C42D613c9eb87e233f7ce3Bf99e261", "0xc27A2F05fa577a83BA0fDb4c38443c0718356501", "0xbEb530452eF406E5B758118111BE662eA5Cb7788", "0xf13fBdF602A42F3C56898a3e578f44FCC62a2Aa0", "0xa531cb52E3363960D9D108B4e8728d8BaDe22630", "0xE913c0f42fB60F85Bd43bDdDAf4e004135eF318c", "0x41a3cBb13B40B331674690569394F0D7ab27a7FE", "0xB71B9C618Dd41c153305410073D30117E56F1bCC", "0x408072DB61848c120DDd191398261352EA5412e6", "0x7F581a792DcC91e890702c07A29938198DD1ae80", "0xE650d3d4A3557A8da1Ec6193a111401C3ffe8e6f", "0x47B7AA597F7163F0a5A77e8BCf302a66F581a898", "0x00F0A25Fea06f8E42Bbd4dB2096CBD592d01C531", "0x4113a1C0Ad5bDdDc35B31A3dC9008A082590969d", "0xB290e60A9526c22B353EA842E70bB73E985E660b", "0x318f0B3477DB30Cb1DdefB25D68a46F137ae6813", "0x9B40f8b9A9b03Fb95029293C9BfC1927EDcC33cA", "0x289575352de316C945C5792F1BBC5bAC4C3Cf016", "0x1A6417dCd02a28067B080A1FDa6afBf7781d3f27", "0xe4Ff5466E5F0fc851FC73D73d55aA0aEAa340D4d", "0x0026D497D3087D369899655e44ECe790a92D5B30", "0xdBc35A4b1388D6d82B26fa5D2eD9Eed735D73148", "0x8cAa0AAb6efCacFEB6d9F49Dfc6585d0767b3bF2", "0x87c6357b07BcA7A1fF15083b5ccE7032a34c7f13", "0x1511a017eAFaccbD2EAFFa2905d2f0b5843e0c57", "0xcbf047257A81BEd861d19110705e237B7514115D", "0x8386f87262fc99c32E02cd982C403F4d998A499e", "0xE23D91d9D6C1B08f7F3477f902123411901Bb30B", "0x4461C9e445EfB0162c3B75FC9D1445DFCA350Ce9", "0xb8Fb5d047516840B7Efd17c56aB6CAD3Cac1CEF3", "0xd36FBDF060ca4E733444e106905fadc0D253E787", "0xA8d85ceC1e9e9E6c3904b4d873Cda459A0490243", "0x3361d77F3d5C79a67bed19c9D9Ab25950061D2bE", "0xAd725038b47251Ae7CA0aaA5Ac42Eb251C65957d", "0xb0fa6b1f68971b6f0b00290bF7b797a9c4f3df34", "0x00d43d052fCC727cb262971Ea068D3F94f774935", "0xe47BBeAc8F268d7126082D5574B6f027f95AF5FB", "0x00a0e722f279445108b60A836b10fc34bf2aA9A7", "0x7f9a49dEF2B81358148D663614f46B53D932c766", "0x82021D851bEADccCc1881BaC8723a3bfAdBaea7e", "0x7058Ec5f04d03dB4290FF387B0794774d0cCF491", "0x6a599aEf3a4927D886a369D9C1b6566942e1a3af", "0x00a613f448D4f59FB4C1059CE0657577809267c7", "0x2b74bE5Ea5026333F11Fe80436222BC8A16a3e67", "0xCdcbe578c15AC8597Df43520e3188A9b8AC55714", "0x693841E9720F1f36C30371aB30A04b7ede872ae9", "0xF4421CDaf6dF0A0eFa85F596369c6F1115E63659", "0x869DAaa8257aBBBa3471A909CFa9c728be4D82f4", "0xcB1e36eD431619636ffB357F35F348AF9088D096", "0x6420Df9ec5D925AB456948E7A50454e619A7d04E", "0x7Ad6e05F8961AE99863F9c371d4f4F88F1D5bC08", "0xB3Fe6e04Fc418310A0097d1F0F4Ab26c983Eef44", "0x6D0f401Af1dF5510B423267df47C0Fe13AD3b58d", "0x3E9E4e16506a304099B00Fd5580d0FC44E71BeAd", "0xA08A2FF1680a5206260cf58c923D37396596b710", "0xba5BeC3f165f1Aea16B8a456d941CA404E84DFEe", "0x0a3258C323D3eA35BC1287589649Af24C3E70069", "0xF69B630C48F109D108a6305d1c350e59cd853138", "0xfe99D4E1fe7E163ed3358A4CBF51488B1DAA3ca6", "0x2D2cf5059A47B7ADD6D845722f2f7FC9ed939dcA", "0x40D2Fa6Ea02dFDD81eA621A1853069fbE39acc18", "0xB22dE1834486C75e1d22A53655193C94429f64c3", "0x30585e6D739800547f71865773d7E29fd802b94A", "0xe28C5E4C6891afb0DF739910C733766305cde69a", "0x7Cf209a05D1565CC63fD2364149bEb5b3db62ff8", "0x36acebaf7e19c1B2D8725Fee911e5788935777b8", "0xF09750a5a6Fc68f08d5e7ECb5b27155c8F2e45AB", "0x44901A91ec046Cc37c40B06D8193e8a61Ba9D271", "0xD822844EDb8caC4123A36679550E5Ab6754DCD8e", "0x4d0a53EF352BA6eC2b123f3a69D50A22728C7f69", "0x2AAF975D4ED2f7d5516537e509a91A40B69e32E1", "0x5f8EB5b726b45757Cee0A5BDBEEACd1f1aA3eE68", "0x7e60A1B7dA1e59A1DC46A4F29bB35453446717bf", "0xCDf0C14B5917d57A486DFAF7F6D1Ed84A22C3210", "0x4A140BdcFdfD8fF8E78bc19042348bA1F4940c52", "0x169C5a87e9eEdfF4FEbcef0e5B23b05374F19c90", "0x00D37fbE01BE6066E26c83E061C0293251b39660", "0x549BE23BB455bf8b1540b551DF14D0666f33C3fc", "0x19e4D41b7171E052a3f52e42F61C80E19092E4a4", "0x5Ff4b28a0A24Dbf1f44B63F6b269296Cdd9F8F5a", "0x236F67b0ae10eDD0C4BCb2AE71290750A1eCD39c", "0xcBfe29ee9E82b7197682728Ea282855785eC6db0", "0x19fA5172C6CAbd7cB68cb32Cc0e21A1fbEa08b45", "0xa5Eb2d16C960F3C9d9eDb810A615F0E6e491DE0C", "0x7CEc10e8551adE40304b14EA92015C4A9E23eA22", "0x28532C928bb7275eA1312463A318E633918A2e1c", "0x787530fD41e0D99F48638A96D138071348d9212A", "0x89e973EE900B27D38f2CB6437589853b798c21C3", "0x260838357463b8bf466F9B1Ef1458a11aA8CFEa8", "0x9555Ffb0a6C3395457ee996C187315a00D29347c", "0xb491e7B4B8be4E247E258D9DF7A257B21C4204b2", "0xE3bB32d1e0e60c6FbBa4A53f9F90450B3b794c4e", "0x00138bDFf88FeD0076829769d5b4E2f445aB3D68", "0x2d9016f7c05c598180b411e69E1dc43A25074E32", "0x343bAc92Ee594bF5B7D7D5A28E73586d1AC83AAb", "0xaF53f3693DF783132EA87aC4E282BC7b50641556", "0xeC999C58915cF9c694763be9f673B9B9927f857C", "0x00Cd9Fad11d5B2118a3dd32d5d43FDb33BDe9e85", "0xa3008916C08A2D7012cF7a38F45926268B3CFD58", "0x48f60FB0B71fa87f3988A8F7A60fE6bD0F86c216", "0x8C85700202d7d67E1106474DeA9Ef491976C0E03", "0xc0CCCDe11859186549cBB089834212D649C61c59", "0x310fB3B44211Bd8a18Ea347C108e697668a4Bd1b", "0xC6dDF90790b433743bd050c1D1d45f673A3413F4", "0x5a84aFB58F4aE43D2311F0C6665f0f7a4a58010d", "0xA20b110043445e0906F9fca259488E528850F37B", "0x95528863b0aEd349933a2Ad80AbcEB10E2ECADf6", "0xa5Bbf24c93cd80b974b3B97e7f1C31c280Abe2ac", "0x004C3f12b43C6Dc0ABc779bE6C89F63D16dd8Ce4", "0xa2fBbCACE9d4ebE0D207Ca34B5e02D7a6Fb92c4D", "0xa67D755df1BA283243cd1Fb40cf4D52e355c3B86", "0xbd0e2f3f8862f6302F74937C5942f2812CeC7bCB", "0x418582A4b6Ce17a16aA4Ce77e1be14f4D8f316d1", "0xB9cbFDb2dB400fE1EB9685B963Af775BEC00C8FD", "0x0595042dC477C246BEC9a582088296dEc7416eAe", "0x8edF52221605cf2d6cfc1F12d141cc85103EBdC5", "0x96a11f12e4b2904Ef8F26d6Dc39179A56C495d4b", "0xEC3B29f2f544F06E6a1C17801D060B6d6b3e2293", "0x00582f083582f59A0dA86a0688332c77C7044a3A", "0x19D0c3c28A5e243a8364A0B4114DaF2D76bEF31e", "0x88696C4985f64Ea1EBfb9E46c1B47197F7a244AB", "0x01E7ba1dBC4B75FA04F0E61E4E261c171fD61Df8", "0x001Af96a32A5993396Bb40e8eBa987ea4d7cf52a", "0xC48CbaaecC224B3ee71e4fd7DA4f63D3963d87A8", "0x3Fd51473217cF4a556620523d9Cc5E23E85E7C5F", "0x003cb170077B8502C6D85B90AD7A505e3eD09A71", "0xc2789ddFdDF6bA47CE795fFe9A15AFc488FbD6c8", "0x725AF7641c6F4718d54CC4e3C1D1fab37A7DFb93", "0xA80E7163aAF5c829cdd5b49c49306F01CcA43C46", "0x954811F54b44E3C957159eF7990663F775B5825d", "0x849cB83281d88975649368B840953B0cAAF32c4b", "0x949b82Dfc04558bC4D3CA033A1B194915a3A3bEE", "0x2e4DA7c0de1e3dac66C5709C6D4e93eaCfb3A7A2", "0xB12E36667364A00068520b77FD0d71539CD35D63", "0xA35B3883db39D2B86CdE589CE8Bda092f814D18A", "0x9C4fcA4C220eFaf55c7531aAaeBF0936B7c54227", "0x75531B664c6DCa5D489d82d99A2A2EE9565e802C", "0xb6FAd4b15657429fbFf0bD5BC874B47c1dc452EC", "0x0C148703b23652a498137B3C1802EB433b86E791", "0x9ce943D92b20Cc81b8B11fa8b27a9182f59aCf41", "0x9D9388E7f7170e8a7bdD8E5ac4e1e02e64Fca0eb", "0x7b2710b1750F7D3862ba62AA335F2f14E1Cf3477", "0x636eB42c4f8fC8b9D37316aC586943C29F9BDf62", "0x8427ebA4340fbaEBbAa923fFD028faB9c28BA4bA", "0x652e53fA9AF39E15fC4F19B2EB8223c2DC23545e", "0xa0e4949eDa31898cE6863047Bd9649e8f8a57e30", "0xf86Fd121Bd825fFabb7709116Ae0eebDC8dC6365", "0xDCc261BFFF8ffC509803c26fd0aAd2c70238a044", "0x65CAf645185e2361c70B099ff579e0D54E5765BE", "0x77e10731F17444570C19320B6a63912f89611B71", "0xCC09Bdc2EDF656B5ca45858D3d710d451da5a305", "0x0c78ED0eDC389aa466e6519a7E111ff6d474A23A", "0xB4644415a639bf48418f50717Ea59E7299682173", "0xB1De0dC512415356F68155Bd8Ba65120564E3343", "0x036992D2fE2d7AEeFAB894fF173113C37Cde4EC9", "0x49390272D570F1957836272102f95e29DF1BceC5"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "rate", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cap", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "hasAllocated", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "mediator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seed", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "team", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isFinalized", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seedShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "teamShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "hasEnded", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [], name: "Finalized", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Finalized()", "TokenPurchase(address,address,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x6823b073d48d6e3a7d385eeb601452d680e74bb46afe3255a7d778f3a9b17681", "0x623b3804fa71d67900d064613da8f94b9617215ee90799290593e1745087ad18"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4545517 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4614698 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "_startTime", value: "1510543800"}, {type: "uint256", name: "_endTime", value: "1514764799"}, {type: "uint256", name: "_rate", value: "11834"}, {type: "uint256", name: "_cap", value: "8504000000000000000000"}, {type: "address", name: "_wallet", value: 3}, {type: "address", name: "_tokenAddress", value: 6}], name: "Presale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "rate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hasAllocated", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasAllocated()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "mediator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "mediator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seed", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "team", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "team()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isFinalized", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isFinalized()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seedShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seedShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "teamShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "teamShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hasEnded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasEnded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Presale", function( accounts ) {

	it( "TEST: Presale( \"1510543800\", \"1514764799\", \"11834\... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4545517", timeStamp: "1510585277", hash: "0xa84a874cb03fb2c788eeb5f35f6944ba6a295bad169fa2ec105e9a345d4b3293", nonce: "1", blockHash: "0x82ecb8759dc2abf5825471dd327f602adc77f4152556c8778d7f896e7c45943c", transactionIndex: "27", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: 0, value: "0", gas: "2290428", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbdf58a19000000000000000000000000000000000000000000000000000000005a0911b8000000000000000000000000000000000000000000000000000000005a4979ff0000000000000000000000000000000000000000000000000000000000002e3a0000000000000000000000000000000000000000000001cd00b51fe081e000000000000000000000000000009c38c7e22cb20b055e008775617224d0ec25c91f000000000000000000000000c27a2f05fa577a83ba0fdb4c38443c0718356501", contractAddress: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", cumulativeGasUsed: "3894968", gasUsed: "2290428", confirmations: "3193234"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_startTime", value: "1510543800"}, {type: "uint256", name: "_endTime", value: "1514764799"}, {type: "uint256", name: "_rate", value: "11834"}, {type: "uint256", name: "_cap", value: "8504000000000000000000"}, {type: "address", name: "_wallet", value: addressList[3]}, {type: "address", name: "_tokenAddress", value: addressList[6]}], name: "Presale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Presale.new( "1510543800", "1514764799", "11834", "8504000000000000000000", addressList[3], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510585277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Presale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: acceptToken(  )", async function( ) {
		const txOriginal = {blockNumber: "4545535", timeStamp: "1510585560", hash: "0xff5516fb28a6e14aa3ac1b29b21439efcbbf767ff652b8d161e4fcb4342e1454", nonce: "3", blockHash: "0x059542a3437aab79cba6c4c0d0988a5dcfd53f6b04022751f44e6e078f155b01", transactionIndex: "36", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "29859", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x5510f804", contractAddress: "", cumulativeGasUsed: "3133516", gasUsed: "29859", confirmations: "3193216"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "acceptToken", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptToken()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510585560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: allocateTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4545551", timeStamp: "1510585750", hash: "0x02e2779944893ecbbc5bf2c4bf6bc77f7101aed4803408e25b47825e894028cf", nonce: "4", blockHash: "0xd695b6975bbb9b765e45b17a829f6476a277867f74ad9f42fc41bffd976cca44", transactionIndex: "73", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "122383", gasPrice: "6100000000", isError: "0", txreceipt_status: "1", input: "0x03894922", contractAddress: "", cumulativeGasUsed: "2943940", gasUsed: "122383", confirmations: "3193200"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "allocateTokens", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "allocateTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510585750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: mintTokens( \"7500000000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4545713", timeStamp: "1510588210", hash: "0x4db3d4942d54080f9fa41c033232e7b88808318a04286b285594b00de4314583", nonce: "5", blockHash: "0xd23a7522b1bc22f8fa389c48a0b683117e6018a1498356ebabd6fd2d49716af1", transactionIndex: "39", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "40441", gasPrice: "6100000000", isError: "0", txreceipt_status: "1", input: "0x97304ced00000000000000000000000000000000000000000006342fd08f00f637800000", contractAddress: "", cumulativeGasUsed: "1368881", gasUsed: "40258", confirmations: "3193038"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenAmount", value: "7500000000000000000000000"}], name: "mintTokens", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTokens(uint256)" ]( "7500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510588210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: mintTokens( \"10000000000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4545738", timeStamp: "1510588612", hash: "0x9d3464c23633a30c219774962cfeddf73b2e7d8e37a2201e049c3335cea24c29", nonce: "6", blockHash: "0x3c6b8c7ecc80365b4d76bfc25deeb2e21713bf2e0d5b0c7ebdef44901211963b", transactionIndex: "201", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "40441", gasPrice: "6100000000", isError: "0", txreceipt_status: "1", input: "0x97304ced000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "6479472", gasUsed: "40258", confirmations: "3193013"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenAmount", value: "10000000000000000000000000"}], name: "mintTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTokens(uint256)" ]( "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510588612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: mintTokens( \"191730272055000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4555280", timeStamp: "1510721447", hash: "0x4e0b841c8a04a03e36a132a0f578d5c11f1dd66e1bba90739834607b060bee07", nonce: "7", blockHash: "0x6c9315dddf6d9a44ed095cd64b14d0c77236d525cff693dcb7c25c739f1520bd", transactionIndex: "33", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "40505", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x97304ced000000000000000000000000000000000000000000002899b8082b812ee67000", contractAddress: "", cumulativeGasUsed: "1281211", gasUsed: "40322", confirmations: "3183471"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenAmount", value: "191730272055000000000000"}], name: "mintTokens", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTokens(uint256)" ]( "191730272055000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510721447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[7],addressList[7],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4558563", timeStamp: "1510767764", hash: "0xab737d44706b2ceca2ea1ee03a2e6a0b0f70a3a2f8beccfaa71602f241f89353", nonce: "8", blockHash: "0x61f646f40a90c4ac2a17b5b41d8c2d8b638f5c13b30126b48b35faa5deafd79a", transactionIndex: "95", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "320868", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000beb530452ef406e5b758118111be662ea5cb7788000000000000000000000000beb530452ef406e5b758118111be662ea5cb7788000000000000000000000000f13fbdf602a42f3c56898a3e578f44fcc62a2aa0000000000000000000000000a531cb52e3363960d9d108b4e8728d8bade22630000000000000000000000000e913c0f42fb60f85bd43bdddaf4e004135ef318c00000000000000000000000041a3cbb13b40b331674690569394f0d7ab27a7fe000000000000000000000000b71b9c618dd41c153305410073d30117e56f1bcc000000000000000000000000408072db61848c120ddd191398261352ea5412e60000000000000000000000007f581a792dcc91e890702c07a29938198dd1ae80000000000000000000000000408072db61848c120ddd191398261352ea5412e6000000000000000000000000e650d3d4a3557a8da1ec6193a111401c3ffe8e6f00000000000000000000000047b7aa597f7163f0a5a77e8bcf302a66f581a89800000000000000000000000000f0a25fea06f8e42bbd4db2096cbd592d01c5310000000000000000000000004113a1c0ad5bdddc35b31a3dc9008a082590969d000000000000000000000000b290e60a9526c22b353ea842e70bb73e985e660b", contractAddress: "", cumulativeGasUsed: "3803936", gasUsed: "320868", confirmations: "3180188"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[7],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[13],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[7],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[13],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510767764 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[20],addressList[21],address... )", async function( ) {
		const txOriginal = {blockNumber: "4560734", timeStamp: "1510797422", hash: "0xcf340bd303e3e68797bb2cc0baee3d939e0428c184e10bf26cfba898391126a9", nonce: "9", blockHash: "0x8ecaf68a9305aed90b3c48e636e6a832d3a8573d2290f3ec868a0c7168237bb5", transactionIndex: "62", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "95345", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f2700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004000000000000000000000000318f0b3477db30cb1ddefb25d68a46f137ae68130000000000000000000000009b40f8b9a9b03fb95029293c9bfc1927edcc33ca00000000000000000000000041a3cbb13b40b331674690569394f0d7ab27a7fe000000000000000000000000289575352de316c945c5792f1bbc5bac4c3cf016", contractAddress: "", cumulativeGasUsed: "2183760", gasUsed: "95345", confirmations: "3178017"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[20],addressList[21],addressList[11],addressList[22]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[20],addressList[21],addressList[11],addressList[22]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510797422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[23],addressList[24],address... )", async function( ) {
		const txOriginal = {blockNumber: "4566783", timeStamp: "1510882162", hash: "0xf5cabb62002b6fb5e545bab8185af9229e965798e135ba38225cac241f6b1476", nonce: "10", blockHash: "0x9ba912ea69e2032b10cb18ec56e5a1f37bf5ffd5fe507cdaad08de64a94d7555", transactionIndex: "94", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "211551", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000001a6417dcd02a28067b080a1fda6afbf7781d3f27000000000000000000000000e4ff5466e5f0fc851fc73d73d55aa0aeaa340d4d0000000000000000000000000026d497d3087d369899655e44ece790a92d5b30000000000000000000000000dbc35a4b1388d6d82b26fa5d2ed9eed735d731480000000000000000000000008caa0aab6efcacfeb6d9f49dfc6585d0767b3bf200000000000000000000000087c6357b07bca7a1ff15083b5cce7032a34c7f130000000000000000000000001511a017eafaccbd2eaffa2905d2f0b5843e0c57000000000000000000000000cbf047257a81bed861d19110705e237b7514115d000000000000000000000000e913c0f42fb60f85bd43bdddaf4e004135ef318c0000000000000000000000008caa0aab6efcacfeb6d9f49dfc6585d0767b3bf2", contractAddress: "", cumulativeGasUsed: "3904938", gasUsed: "211551", confirmations: "3171968"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[10],addressList[27]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[10],addressList[27]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510882162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4567366", timeStamp: "1510890073", hash: "0xec295b8c5ca1e0763dd0a2070c6e4da440bd1908ee0132491447a0b1e462b085", nonce: "0", blockHash: "0x8af4a93410c4d4606897233dfe0e195d10e80e6a4ac2f160a2d14f811e242f37", transactionIndex: "12", from: "0x289575352de316c945c5792f1bbc5bac4c3cf016", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "9174000000000000000", gas: "250000", gasPrice: "8800000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "417113", gasUsed: "85772", confirmations: "3171385"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "9174000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510890073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x289575352de316c945c5792f1bbc5bac4c3cf016"}, {name: "beneficiary", type: "address", value: "0x289575352de316c945c5792f1bbc5bac4c3cf016"}, {name: "value", type: "uint256", value: "9174000000000000000"}, {name: "amount", type: "uint256", value: "108565116000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "20448400000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4570960", timeStamp: "1510940121", hash: "0xeadc097fc505955c3a6cbfc58b81d50b0b81e52765191f708f63e877a552cdcd", nonce: "4", blockHash: "0x571d6a5e191c4f76dcf2980fda8280b896ab13d238512fe70e0f5351600036b6", transactionIndex: "47", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "2000000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1835581", gasUsed: "23214", confirmations: "3167791"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510940121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4570972", timeStamp: "1510940258", hash: "0x33162d287e66723752638a15a662287308868d9ad5ff866730ad898743140236", nonce: "5", blockHash: "0xf8ddac84a1cc6af66d18dfc01266e8af21ff813ee6b28f612d7d7eee7fdfa596", transactionIndex: "43", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "2000000000000000000", gas: "250000", gasPrice: "47000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1141996", gasUsed: "23214", confirmations: "3167779"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510940258 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4570988", timeStamp: "1510940451", hash: "0x9d39fece351ad47c8f7fc2dfc35fed19d9f1f3b476d1a4af957e1be9f712a558", nonce: "6", blockHash: "0x2152a3970f1452906f98df4cd1a2bc5d62f921c85764714fa70671c0a871022c", transactionIndex: "18", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "2000000000000000000", gas: "250000", gasPrice: "17000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "680674", gasUsed: "23214", confirmations: "3167763"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510940451 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4570999", timeStamp: "1510940591", hash: "0xecb2c20331a8bc09796dddf92e006c4b4f6628fd1658506cee7528225f28b010", nonce: "7", blockHash: "0x78d272a3ae81665cf7c3ea1531b7d5d1d66a6df047dc799da4a2d2c779394bad", transactionIndex: "48", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "2000000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1963561", gasUsed: "23214", confirmations: "3167752"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510940591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[11],addressList[21],address... )", async function( ) {
		const txOriginal = {blockNumber: "4571046", timeStamp: "1510941105", hash: "0x67a503bc651487ae1095fdd9797a5341129f29e66fbd405fb244aaf0c2b56efb", nonce: "11", blockHash: "0x47dbb89bd757901d4be6e489f7e01d91dddf3cfc7260bdd4c986b0617611236a", transactionIndex: "47", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "1748109", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000006000000000000000000000000041a3cbb13b40b331674690569394f0d7ab27a7fe0000000000000000000000009b40f8b9a9b03fb95029293c9bfc1927edcc33ca000000000000000000000000318f0b3477db30cb1ddefb25d68a46f137ae6813000000000000000000000000beb530452ef406e5b758118111be662ea5cb7788000000000000000000000000beb530452ef406e5b758118111be662ea5cb7788000000000000000000000000f13fbdf602a42f3c56898a3e578f44fcc62a2aa0000000000000000000000000a531cb52e3363960d9d108b4e8728d8bade22630000000000000000000000000e913c0f42fb60f85bd43bdddaf4e004135ef318c00000000000000000000000041a3cbb13b40b331674690569394f0d7ab27a7fe000000000000000000000000b71b9c618dd41c153305410073d30117e56f1bcc000000000000000000000000408072db61848c120ddd191398261352ea5412e60000000000000000000000007f581a792dcc91e890702c07a29938198dd1ae80000000000000000000000000408072db61848c120ddd191398261352ea5412e6000000000000000000000000e650d3d4a3557a8da1ec6193a111401c3ffe8e6f00000000000000000000000047b7aa597f7163f0a5a77e8bcf302a66f581a89800000000000000000000000000f0a25fea06f8e42bbd4db2096cbd592d01c5310000000000000000000000004113a1c0ad5bdddc35b31a3dc9008a082590969d000000000000000000000000b290e60a9526c22b353ea842e70bb73e985e660b000000000000000000000000e23d91d9d6c1b08f7f3477f902123411901bb30b0000000000000000000000004461c9e445efb0162c3b75fc9d1445dfca350ce9000000000000000000000000b8fb5d047516840b7efd17c56ab6cad3cac1cef3000000000000000000000000d36fbdf060ca4e733444e106905fadc0d253e787000000000000000000000000a8d85cec1e9e9e6c3904b4d873cda459a04902430000000000000000000000003361d77f3d5c79a67bed19c9d9ab25950061d2be000000000000000000000000ad725038b47251ae7ca0aaa5ac42eb251c65957d000000000000000000000000b0fa6b1f68971b6f0b00290bf7b797a9c4f3df3400000000000000000000000000d43d052fcc727cb262971ea068d3f94f774935000000000000000000000000e47bbeac8f268d7126082d5574b6f027f95af5fb000000000000000000000000b71b9c618dd41c153305410073d30117e56f1bcc00000000000000000000000000d43d052fcc727cb262971ea068d3f94f77493500000000000000000000000000a0e722f279445108b60a836b10fc34bf2aa9a70000000000000000000000007f9a49def2b81358148d663614f46b53d932c76600000000000000000000000082021d851beadcccc1881bac8723a3bfadbaea7e0000000000000000000000007058ec5f04d03db4290ff387b0794774d0ccf4910000000000000000000000006a599aef3a4927d886a369d9c1b6566942e1a3af00000000000000000000000000a613f448d4f59fb4c1059ce0657577809267c70000000000000000000000002b74be5ea5026333f11fe80436222bc8a16a3e67000000000000000000000000cdcbe578c15ac8597df43520e3188a9b8ac55714000000000000000000000000693841e9720f1f36c30371ab30a04b7ede872ae9000000000000000000000000f4421cdaf6df0a0efa85f596369c6f1115e63659000000000000000000000000869daaa8257abbba3471a909cfa9c728be4d82f4000000000000000000000000cb1e36ed431619636ffb357f35f348af9088d0960000000000000000000000006420df9ec5d925ab456948e7a50454e619a7d04e0000000000000000000000007ad6e05f8961ae99863f9c371d4f4f88f1d5bc08000000000000000000000000b3fe6e04fc418310a0097d1f0f4ab26c983eef440000000000000000000000006d0f401af1df5510b423267df47c0fe13ad3b58d0000000000000000000000003e9e4e16506a304099b00fd5580d0fc44e71bead000000000000000000000000a08a2ff1680a5206260cf58c923d37396596b710000000000000000000000000ba5bec3f165f1aea16b8a456d941ca404e84dfee0000000000000000000000000a3258c323d3ea35bc1287589649af24c3e70069000000000000000000000000f69b630c48f109d108a6305d1c350e59cd853138000000000000000000000000fe99d4e1fe7e163ed3358a4cbf51488b1daa3ca60000000000000000000000002d2cf5059a47b7add6d845722f2f7fc9ed939dca00000000000000000000000040d2fa6ea02dfdd81ea621a1853069fbe39acc18000000000000000000000000b22de1834486c75e1d22a53655193c94429f64c300000000000000000000000030585e6d739800547f71865773d7e29fd802b94a000000000000000000000000e28c5e4c6891afb0df739910c733766305cde69a0000000000000000000000007cf209a05d1565cc63fd2364149beb5b3db62ff80000000000000000000000008386f87262fc99c32e02cd982c403f4d998a499e00000000000000000000000036acebaf7e19c1b2d8725fee911e5788935777b8000000000000000000000000f09750a5a6fc68f08d5e7ecb5b27155c8f2e45ab000000000000000000000000cdcbe578c15ac8597df43520e3188a9b8ac5571400000000000000000000000044901a91ec046cc37c40b06d8193e8a61ba9d271000000000000000000000000d822844edb8cac4123a36679550e5ab6754dcd8e0000000000000000000000004d0a53ef352ba6ec2b123f3a69d50a22728c7f690000000000000000000000002aaf975d4ed2f7d5516537e509a91a40b69e32e10000000000000000000000005f8eb5b726b45757cee0a5bdbeeacd1f1aa3ee680000000000000000000000007e60a1b7da1e59a1dc46a4f29bb35453446717bf000000000000000000000000cdf0c14b5917d57a486dfaf7f6d1ed84a22c32100000000000000000000000007cf209a05d1565cc63fd2364149beb5b3db62ff80000000000000000000000004a140bdcfdfd8ff8e78bc19042348ba1f4940c52000000000000000000000000169c5a87e9eedff4febcef0e5b23b05374f19c90000000000000000000000000cdf0c14b5917d57a486dfaf7f6d1ed84a22c321000000000000000000000000000d37fbe01be6066e26c83e061c0293251b39660000000000000000000000000549be23bb455bf8b1540b551df14d0666f33c3fc00000000000000000000000019e4d41b7171e052a3f52e42f61c80e19092e4a40000000000000000000000005ff4b28a0a24dbf1f44b63f6b269296cdd9f8f5a000000000000000000000000236f67b0ae10edd0c4bcb2ae71290750a1ecd39c000000000000000000000000cbfe29ee9e82b7197682728ea282855785ec6db000000000000000000000000019fa5172c6cabd7cb68cb32cc0e21a1fbea08b45000000000000000000000000a5eb2d16c960f3c9d9edb810a615f0e6e491de0c0000000000000000000000007cec10e8551ade40304b14ea92015c4a9e23ea2200000000000000000000000028532c928bb7275ea1312463a318e633918a2e1c000000000000000000000000787530fd41e0d99f48638a96d138071348d9212a00000000000000000000000089e973ee900b27d38f2cb6437589853b798c21c3000000000000000000000000260838357463b8bf466f9b1ef1458a11aa8cfea80000000000000000000000009555ffb0a6c3395457ee996c187315a00d29347c000000000000000000000000b491e7b4b8be4e247e258d9df7a257b21c4204b2000000000000000000000000e3bb32d1e0e60c6fbba4a53f9f90450b3b794c4e000000000000000000000000b22de1834486c75e1d22a53655193c94429f64c300000000000000000000000000138bdff88fed0076829769d5b4e2f445ab3d680000000000000000000000002d9016f7c05c598180b411e69e1dc43a25074e32000000000000000000000000cbfe29ee9e82b7197682728ea282855785ec6db0000000000000000000000000343bac92ee594bf5b7d7d5a28e73586d1ac83aab000000000000000000000000af53f3693df783132ea87ac4e282bc7b50641556000000000000000000000000ec999c58915cf9c694763be9f673b9b9927f857c", contractAddress: "", cumulativeGasUsed: "3925000", gasUsed: "1748109", confirmations: "3167705"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[11],addressList[21],addressList[20],addressList[7],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[13],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[12],addressList[40],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[31],addressList[70],addressList[71],addressList[49],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[69],addressList[79],addressList[80],addressList[78],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[66],addressList[97],addressList[98],addressList[86],addressList[99],addressList[100],addressList[101]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[11],addressList[21],addressList[20],addressList[7],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[13],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[12],addressList[40],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[31],addressList[70],addressList[71],addressList[49],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[69],addressList[79],addressList[80],addressList[78],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[66],addressList[97],addressList[98],addressList[86],addressList[99],addressList[100],addressList[101]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510941105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4571128", timeStamp: "1510942338", hash: "0xf92baf897a57fe045e30d8fe5bb1cc8a641cdeb75cf136c60df24d315b1f7277", nonce: "8", blockHash: "0x0f43be138ad06d69989c843e87d93eb458fa460a4a0ebdd5e1b2f6dda5208956", transactionIndex: "197", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "3000000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5577769", gasUsed: "55772", confirmations: "3167623"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "3000000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510942338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "beneficiary", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "value", type: "uint256", value: "3000000000000000000"}, {name: "amount", type: "uint256", value: "35502000000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4575354", timeStamp: "1511001541", hash: "0x18f842bf8865a670f59532756b9fab623b8b5da62ca5eb6dab54426848de5d8a", nonce: "13", blockHash: "0xfe66ea2b9eccea9b52699c1ac96aceab000d20cb0d3d35bc6e9d43fb257ce5d2", transactionIndex: "6", from: "0x7058ec5f04d03db4290ff387b0794774d0ccf491", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "1000000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "241757", gasUsed: "70772", confirmations: "3163397"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1511001541 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x7058ec5f04d03db4290ff387b0794774d0ccf491"}, {name: "beneficiary", type: "address", value: "0x7058ec5f04d03db4290ff387b0794774d0ccf491"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "amount", type: "uint256", value: "11834000000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "31246281205599939" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[102],addressList[103],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4576776", timeStamp: "1511021249", hash: "0x685e2b48878dc233b063e7104c9fced4764c12ce74b83dc63197f7ef6038ef4b", nonce: "12", blockHash: "0x772da37df58f787f515e926ced92427cb165c9d84a60f5cc2f1f57b6ce9c877a", transactionIndex: "96", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "160884", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000cd9fad11d5b2118a3dd32d5d43fdb33bde9e85000000000000000000000000a3008916c08a2d7012cf7a38f45926268b3cfd5800000000000000000000000048f60fb0b71fa87f3988a8f7a60fe6bd0f86c2160000000000000000000000008c85700202d7d67e1106474dea9ef491976c0e03000000000000000000000000c0cccde11859186549cbb089834212d649c61c59000000000000000000000000310fb3b44211bd8a18ea347c108e697668a4bd1b0000000000000000000000001a6417dcd02a28067b080a1fda6afbf7781d3f27", contractAddress: "", cumulativeGasUsed: "3083104", gasUsed: "160884", confirmations: "3161975"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[23]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[23]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1511021249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[108],addressList[32]] )", async function( ) {
		const txOriginal = {blockNumber: "4577302", timeStamp: "1511028659", hash: "0x98d3c125e16e6442cc5a26d48df17ea8aa9f767e5cc52a26e6944a2fa321f3e4", nonce: "13", blockHash: "0x8a9247eb5e1b78aad735aad4fa1ae73f0052b7f204639443e8d612ceeef6a32e", transactionIndex: "51", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "51567", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f2700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000c6ddf90790b433743bd050c1d1d45f673a3413f4000000000000000000000000e23d91d9d6c1b08f7f3477f902123411901bb30b", contractAddress: "", cumulativeGasUsed: "2385981", gasUsed: "51567", confirmations: "3161449"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[108],addressList[32]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[108],addressList[32]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1511028659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[109],addressList[110],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4577701", timeStamp: "1511033946", hash: "0xd4921fe243544b17c2a98899d885adbb83772146224a7c3b299f7aa3fc5f2b87", nonce: "14", blockHash: "0x4d87ec2273c906f6182ad9f96ea8b1e0dd2ae8bb88b96175856b754a250829a3", transactionIndex: "65", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "88392", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f27000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000030000000000000000000000005a84afb58f4ae43d2311f0c6665f0f7a4a58010d000000000000000000000000a20b110043445e0906f9fca259488e528850f37b00000000000000000000000095528863b0aed349933a2ad80abceb10e2ecadf6", contractAddress: "", cumulativeGasUsed: "2763843", gasUsed: "88392", confirmations: "3161050"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[109],addressList[110],addressList[111]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[109],addressList[110],addressList[111]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1511033946 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[111],addressList[112],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4579627", timeStamp: "1511060900", hash: "0xa4b4dadc318b7bf374b146bb06dbda1210b1f0001956f807ece04e546a67db8b", nonce: "15", blockHash: "0x4b53ce60a914b988558f503b579505ab840c6b66a25c0a9971df75010563774e", transactionIndex: "49", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "139059", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000600000000000000000000000095528863b0aed349933a2ad80abceb10e2ecadf6000000000000000000000000a5bbf24c93cd80b974b3b97e7f1c31c280abe2ac000000000000000000000000004c3f12b43c6dc0abc779be6c89f63d16dd8ce4000000000000000000000000a2fbbcace9d4ebe0d207ca34b5e02d7a6fb92c4d000000000000000000000000a67d755df1ba283243cd1fb40cf4d52e355c3b86000000000000000000000000bd0e2f3f8862f6302f74937c5942f2812cec7bcb", contractAddress: "", cumulativeGasUsed: "3006646", gasUsed: "139059", confirmations: "3159124"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1511060900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[109],addressList[117]] )", async function( ) {
		const txOriginal = {blockNumber: "4582891", timeStamp: "1511105813", hash: "0x879b6da89e4ea7ca997bd0f256a840a74735370fdd7aaa154d4d4b2dfc10445c", nonce: "16", blockHash: "0x42b2354e6c2a73cd92a1f9b3391774e1a797f6bd1a518be8a1f6115f86a92224", transactionIndex: "36", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "51567", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f27000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000020000000000000000000000005a84afb58f4ae43d2311f0c6665f0f7a4a58010d000000000000000000000000418582a4b6ce17a16aa4ce77e1be14f4d8f316d1", contractAddress: "", cumulativeGasUsed: "2872543", gasUsed: "51567", confirmations: "3155860"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[109],addressList[117]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[109],addressList[117]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1511105813 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4585723", timeStamp: "1511144503", hash: "0xac08cd3855a1b0a23a890796e07f8e3c971168d7b9428cc2422784c53c391ac3", nonce: "9", blockHash: "0xa4010091d3610838eac759a6bf4e42bd6a41b32721dd650eca398fc59c40ca39", transactionIndex: "36", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "3000000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1032446", gasUsed: "55772", confirmations: "3153028"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "3000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1511144503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "beneficiary", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "value", type: "uint256", value: "3000000000000000000"}, {name: "amount", type: "uint256", value: "35502000000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4586004", timeStamp: "1511148590", hash: "0x9960d44a804e983ed28934e46dd81e098d4af4f38beace3e616718f0128167c0", nonce: "10", blockHash: "0x8639d12149cc22a9fa7185524ad4cebac06c50a5b029b075d36ef67e311fd122", transactionIndex: "68", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "300000000000000000", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2063267", gasUsed: "55772", confirmations: "3152747"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1511148590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "beneficiary", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "value", type: "uint256", value: "300000000000000000"}, {name: "amount", type: "uint256", value: "3550200000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[118],addressList[119],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4589065", timeStamp: "1511190790", hash: "0xa4822fb0676f2d606e8625b9578bcbb6a815d030beedd9f6d611024e6e00aae9", nonce: "17", blockHash: "0x1493abc7d1804e8065ae23cdeb10a9f52bcb41730c680608b7de8381767e9751", transactionIndex: "129", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "88392", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f2700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000003000000000000000000000000b9cbfdb2db400fe1eb9685b963af775bec00c8fd0000000000000000000000000595042dc477c246bec9a582088296dec7416eae0000000000000000000000008edf52221605cf2d6cfc1f12d141cc85103ebdc5", contractAddress: "", cumulativeGasUsed: "6545965", gasUsed: "88392", confirmations: "3149686"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[118],addressList[119],addressList[120]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[118],addressList[119],addressList[120]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1511190790 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4589863", timeStamp: "1511201804", hash: "0x7ac385b6418a217ef5a8b3ee942b32ad47dc3b41ff22c5a57dd389ca03f80da3", nonce: "24", blockHash: "0xc48ab7b5b970da3c55016ae155179afce78116daafee3432c4b944c1cf4d6159", transactionIndex: "30", from: "0xc0cccde11859186549cbb089834212d649c61c59", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "100000000000000000", gas: "73017", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1519827", gasUsed: "70772", confirmations: "3148888"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[106], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1511201804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0xc0cccde11859186549cbb089834212d649c61c59"}, {name: "beneficiary", type: "address", value: "0xc0cccde11859186549cbb089834212d649c61c59"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "amount", type: "uint256", value: "1183400000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[106], balance: "589647000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[106], balance: ( await web3.eth.getBalance( addressList[106], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[121],addressList[122]] )", async function( ) {
		const txOriginal = {blockNumber: "4590110", timeStamp: "1511204995", hash: "0x4b19e202ba9eac3193877f0c81f9000c16d996b18adcc7f949663fe2bfc3db70", nonce: "18", blockHash: "0xd35b6b597d3d16e62a1f94a0171c05550a69cb68a894f69bc85edc7e5bab7452", transactionIndex: "15", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "66567", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000200000000000000000000000096a11f12e4b2904ef8f26d6dc39179a56c495d4b000000000000000000000000ec3b29f2f544f06e6a1c17801d060b6d6b3e2293", contractAddress: "", cumulativeGasUsed: "436443", gasUsed: "66567", confirmations: "3148641"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[121],addressList[122]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[121],addressList[122]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1511204995 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4590191", timeStamp: "1511206347", hash: "0xd5079cb261fbe138e969e539d19cd5fefb3fd58dda80184b2cd755d8fd9a7c59", nonce: "0", blockHash: "0x39158a2244449142e45a75144f6a7d0ae2b44b25322389660d7eef16686308ea", transactionIndex: "50", from: "0x8edf52221605cf2d6cfc1f12d141cc85103ebdc5", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "2854000000000000000", gas: "250000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2701877", gasUsed: "70772", confirmations: "3148560"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[120], to: addressList[2], value: "2854000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511206347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x8edf52221605cf2d6cfc1f12d141cc85103ebdc5"}, {name: "beneficiary", type: "address", value: "0x8edf52221605cf2d6cfc1f12d141cc85103ebdc5"}, {name: "value", type: "uint256", value: "2854000000000000000"}, {name: "amount", type: "uint256", value: "33774236000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[120], balance: "4867648000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[120], balance: ( await web3.eth.getBalance( addressList[120], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUser( addressList[123] )", async function( ) {
		const txOriginal = {blockNumber: "4590352", timeStamp: "1511208840", hash: "0x64d058bca9192d17682b521292aede286e1ec176f8debd356707fc5a330b45bf", nonce: "19", blockHash: "0xa7277afac3c876149b7c9c6c43aa54d60c71fdb7c5217f616feed6fa5ab4bf39", transactionIndex: "44", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "43977", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x4a4c560d00000000000000000000000000582f083582f59a0da86a0688332c77c7044a3a", contractAddress: "", cumulativeGasUsed: "1972995", gasUsed: "43977", confirmations: "3148399"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_a", value: addressList[123]}], name: "whitelistUser", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUser(address)" ]( addressList[123], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511208840 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4595256", timeStamp: "1511277751", hash: "0xc40719bc6f1b0416e72f34739e26ec3771b27ea25caa864ea456ca02c2c4c983", nonce: "253", blockHash: "0xe6c8225cb6138d451399114646c30fd9368f33956a53516c843738fafb461a93", transactionIndex: "22", from: "0x00cd9fad11d5b2118a3dd32d5d43fdb33bde9e85", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "152000000000000000000", gas: "250000", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "917155", gasUsed: "70772", confirmations: "3143495"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[102], to: addressList[2], value: "152000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511277751 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x00cd9fad11d5b2118a3dd32d5d43fdb33bde9e85"}, {name: "beneficiary", type: "address", value: "0x00cd9fad11d5b2118a3dd32d5d43fdb33bde9e85"}, {name: "value", type: "uint256", value: "152000000000000000000"}, {name: "amount", type: "uint256", value: "1798768000000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[102], balance: "15432487315511584174" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[102], balance: ( await web3.eth.getBalance( addressList[102], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[124],addressList[125],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4596019", timeStamp: "1511288774", hash: "0x29d05df3166ad8b0d4ea14a0fec9886d9102cf0e669c47212b335861c7139b5a", nonce: "20", blockHash: "0xb9972b57bad794f9bbbc52ccd4a4e79e85e9da7da28b8ddf30a862a54bd94b29", transactionIndex: "122", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "110281", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000400000000000000000000000019d0c3c28a5e243a8364a0b4114daf2d76bef31e00000000000000000000000088696c4985f64ea1ebfb9e46c1b47197f7a244ab00000000000000000000000001e7ba1dbc4b75fa04f0e61e4e261c171fd61df8000000000000000000000000001af96a32a5993396bb40e8eba987ea4d7cf52a", contractAddress: "", cumulativeGasUsed: "3754043", gasUsed: "110281", confirmations: "3142732"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[124],addressList[125],addressList[126],addressList[127]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[124],addressList[125],addressList[126],addressList[127]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511288774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4596358", timeStamp: "1511293292", hash: "0x7a0b907b23f92a86335ce58b253f72a472423b7688c2986b3cab19ea078f9894", nonce: "11", blockHash: "0x12ae58ef8112bc7189b28c66ebbc498998081c45d9f6d16ac29f43b76d188fcd", transactionIndex: "116", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "800000000000000000", gas: "25000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3735988", gasUsed: "25000", confirmations: "3142393"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "800000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4596365", timeStamp: "1511293371", hash: "0x2cc9ec1db3d72aa7eb0c101545f18bc67c75a28d68a816b924644be98094e3e7", nonce: "12", blockHash: "0xa6748c51940e4456cb31d112e7d0abdedff9d3fee425d7c2d253bf42de4e913d", transactionIndex: "6", from: "0x8386f87262fc99c32e02cd982c403f4d998a499e", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "790000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "214528", gasUsed: "55772", confirmations: "3142386"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "790000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511293371 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "beneficiary", type: "address", value: "0x8386f87262fc99c32e02cd982c403f4d998a499e"}, {name: "value", type: "uint256", value: "790000000000000000"}, {name: "amount", type: "uint256", value: "9348860000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17819441600000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4597226", timeStamp: "1511305565", hash: "0xa4f3f6b88aabaa4aaf77379fe22be214bffbb7c2c01e330a42a11d0942a42b64", nonce: "2", blockHash: "0xdf2433d23091faefcbf60d35a146a141444b9f7d5129c361aa2983cfbf0fc0b0", transactionIndex: "45", from: "0x001af96a32a5993396bb40e8eba987ea4d7cf52a", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "3000000000000000000", gas: "87620", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1963977", gasUsed: "70772", confirmations: "3141525"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[127], to: addressList[2], value: "3000000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511305565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x001af96a32a5993396bb40e8eba987ea4d7cf52a"}, {name: "beneficiary", type: "address", value: "0x001af96a32a5993396bb40e8eba987ea4d7cf52a"}, {name: "value", type: "uint256", value: "3000000000000000000"}, {name: "amount", type: "uint256", value: "35502000000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[127], balance: "517939917634039826" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[127], balance: ( await web3.eth.getBalance( addressList[127], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[128],addressList[129]] )", async function( ) {
		const txOriginal = {blockNumber: "4601177", timeStamp: "1511361001", hash: "0x7fb6745872af6fea8272e59cc6e48cd802457c4c114cf356af237d2b613b1bc6", nonce: "21", blockHash: "0x5a59a45464f5fb0b37fa2a1528abc01441c2e0e3c7b9c7de59318ce5a16a3572", transactionIndex: "67", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "66567", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f2700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000c48cbaaecc224b3ee71e4fd7da4f63d3963d87a80000000000000000000000003fd51473217cf4a556620523d9cc5e23e85e7c5f", contractAddress: "", cumulativeGasUsed: "1711404", gasUsed: "66567", confirmations: "3137574"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[128],addressList[129]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[128],addressList[129]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511361001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[130],addressList[131]] )", async function( ) {
		const txOriginal = {blockNumber: "4601709", timeStamp: "1511368175", hash: "0x38eb5b6e7ee64b2048e54d73697855ef979c1aee87d4e9b0dc30a3b5fc9e2818", nonce: "22", blockHash: "0xbff868c76825a318e84ec2da8f845bfd2ddaed8633ae96cb2c26d5dcbd9affb3", transactionIndex: "47", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "66503", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f2700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000003cb170077b8502c6d85b90ad7a505e3ed09a71000000000000000000000000c2789ddfddf6ba47ce795ffe9a15afc488fbd6c8", contractAddress: "", cumulativeGasUsed: "1629038", gasUsed: "66503", confirmations: "3137042"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[130],addressList[131]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[130],addressList[131]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511368175 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUser( addressList[132] )", async function( ) {
		const txOriginal = {blockNumber: "4601785", timeStamp: "1511369233", hash: "0x0814d1ea26695e79b4a74b2f902d94471061cfa9291445a6942a2853ebfea3b1", nonce: "23", blockHash: "0x7f85d20cfed3e78afd9068ba5ec2b55806c0e30fe8b8a48f59043c13072fe9aa", transactionIndex: "185", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "44041", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x4a4c560d000000000000000000000000725af7641c6f4718d54cc4e3c1d1fab37a7dfb93", contractAddress: "", cumulativeGasUsed: "5364011", gasUsed: "44041", confirmations: "3136966"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_a", value: addressList[132]}], name: "whitelistUser", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUser(address)" ]( addressList[132], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511369233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4601861", timeStamp: "1511370189", hash: "0xd0d4c34a5e32664c5a220cce301e225b55d3f529a786617a673456a65b87b4c5", nonce: "0", blockHash: "0x7faf9dcba07f03f4cdabaea8ed7c29c1b316b352733db1f850c5053364229cd5", transactionIndex: "71", from: "0x1511a017eafaccbd2eaffa2905d2f0b5843e0c57", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "6000000000000000000", gas: "251000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3073314", gasUsed: "70772", confirmations: "3136890"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "6000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511370189 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x1511a017eafaccbd2eaffa2905d2f0b5843e0c57"}, {name: "beneficiary", type: "address", value: "0x1511a017eafaccbd2eaffa2905d2f0b5843e0c57"}, {name: "value", type: "uint256", value: "6000000000000000000"}, {name: "amount", type: "uint256", value: "71004000000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "18989954000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4601864", timeStamp: "1511370227", hash: "0x72f0bd9ad20e0960c22a30e0a417115fa213de4b73ff7bc45fe7e9031cc2a372", nonce: "1", blockHash: "0x27797855d7d45b46145b1cf5bb6ad3a921a8c7e4347a7e7ec50c21c1d2df7a9d", transactionIndex: "18", from: "0x1511a017eafaccbd2eaffa2905d2f0b5843e0c57", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "6000000000000000000", gas: "251000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "645072", gasUsed: "55772", confirmations: "3136887"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "6000000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511370227 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x1511a017eafaccbd2eaffa2905d2f0b5843e0c57"}, {name: "beneficiary", type: "address", value: "0x1511a017eafaccbd2eaffa2905d2f0b5843e0c57"}, {name: "value", type: "uint256", value: "6000000000000000000"}, {name: "amount", type: "uint256", value: "71004000000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "18989954000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[133],addressList[134]] )", async function( ) {
		const txOriginal = {blockNumber: "4603667", timeStamp: "1511394826", hash: "0x935eafb0213d42f34486fd525a3ad7251979ea5e31b82a845018cd79270ec81a", nonce: "24", blockHash: "0x896f624fb1e63d9d74950fc6c179a59fb77faf3410977c956ac6c42ed756efb6", transactionIndex: "13", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "66567", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f2700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000002000000000000000000000000a80e7163aaf5c829cdd5b49c49306f01cca43c46000000000000000000000000954811f54b44e3c957159ef7990663f775b5825d", contractAddress: "", cumulativeGasUsed: "442072", gasUsed: "66567", confirmations: "3135084"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[133],addressList[134]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[133],addressList[134]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[135],addressList[136],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4604949", timeStamp: "1511412605", hash: "0xbf8860ea06021b06c1d6a1dfcbcef0cada755b03e24f157f7c977b8a2c59ac98", nonce: "25", blockHash: "0x8960fc81ff63913898716cc842e1f59aa7e4bb660972456be58b2ddc8f22f7fc", transactionIndex: "14", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "132170", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f2700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005000000000000000000000000849cb83281d88975649368b840953b0caaf32c4b000000000000000000000000949b82dfc04558bc4d3ca033a1b194915a3a3bee0000000000000000000000002e4da7c0de1e3dac66c5709c6d4e93eacfb3a7a2000000000000000000000000b12e36667364a00068520b77fd0d71539cd35d63000000000000000000000000a35b3883db39d2b86cde589ce8bda092f814d18a", contractAddress: "", cumulativeGasUsed: "686896", gasUsed: "132170", confirmations: "3133802"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[135],addressList[136],addressList[137],addressList[138],addressList[139]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[135],addressList[136],addressList[137],addressList[138],addressList[139]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511412605 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUser( addressList[140] )", async function( ) {
		const txOriginal = {blockNumber: "4605031", timeStamp: "1511413782", hash: "0x10e16a74ac949f4cd1893ca163fafd9966d0ff76b55f7b3e723ff2bfad4eafea", nonce: "26", blockHash: "0xb9b86d7b6df1e0cdc32395c06ddddfae75a392bc53ad6911557377a9012a1aba", transactionIndex: "47", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "44041", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x4a4c560d0000000000000000000000009c4fca4c220efaf55c7531aaaebf0936b7c54227", contractAddress: "", cumulativeGasUsed: "1068269", gasUsed: "44041", confirmations: "3133720"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_a", value: addressList[140]}], name: "whitelistUser", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUser(address)" ]( addressList[140], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511413782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4605233", timeStamp: "1511416546", hash: "0xc461965f5850df679f77a89d422ba77041fb3b82b878ea7a10df6dbea9f7b606", nonce: "1", blockHash: "0xee5b9c1bd38538a966a4e1c1ddcf4b74e29746c787e77d88c71f5c5677aacabc", transactionIndex: "39", from: "0x4a140bdcfdfd8ff8e78bc19042348ba1f4940c52", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "3645000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1178452", gasUsed: "70772", confirmations: "3133518"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[79], to: addressList[2], value: "3645000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511416546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x4a140bdcfdfd8ff8e78bc19042348ba1f4940c52"}, {name: "beneficiary", type: "address", value: "0x4a140bdcfdfd8ff8e78bc19042348ba1f4940c52"}, {name: "value", type: "uint256", value: "3645000000000000000"}, {name: "amount", type: "uint256", value: "43134930000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[79], balance: "861100000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[79], balance: ( await web3.eth.getBalance( addressList[79], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4605262", timeStamp: "1511416864", hash: "0x5b9846e404756869ff64a679bfd57b549768aa59f8356023a761c36e99ef59ba", nonce: "2", blockHash: "0xea358528d17e04bbb9f3756f0749467df8bada00d5143fff92e6856d996eb6f8", transactionIndex: "64", from: "0x4a140bdcfdfd8ff8e78bc19042348ba1f4940c52", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "5741376", gasUsed: "22874", confirmations: "3133489"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[79], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511416864 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[79], balance: "861100000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[79], balance: ( await web3.eth.getBalance( addressList[79], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4605275", timeStamp: "1511417049", hash: "0x0d2cc1ed2447dfc6e2fb9ffe6244c292fcaf99016304452b041a4e420ed48245", nonce: "3", blockHash: "0xd913275770dca31cedd91a823c04d65803e93354d9ff275d4ef11194bc025d20", transactionIndex: "98", from: "0x4a140bdcfdfd8ff8e78bc19042348ba1f4940c52", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "640000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3590581", gasUsed: "55772", confirmations: "3133476"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[79], to: addressList[2], value: "640000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511417049 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x4a140bdcfdfd8ff8e78bc19042348ba1f4940c52"}, {name: "beneficiary", type: "address", value: "0x4a140bdcfdfd8ff8e78bc19042348ba1f4940c52"}, {name: "value", type: "uint256", value: "640000000000000000"}, {name: "amount", type: "uint256", value: "7573760000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[79], balance: "861100000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[79], balance: ( await web3.eth.getBalance( addressList[79], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[141],addressList[142],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4607540", timeStamp: "1511449150", hash: "0x8f2dda3106a883b37b08c1f292419878d643baa1133540d766555b08740f14c2", nonce: "27", blockHash: "0xdf01577e403b23c651c00b992b01b79ba956f9cf8362acf26a347df05bb02bdb", transactionIndex: "128", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "226679", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000075531b664c6dca5d489d82d99a2a2ee9565e802c000000000000000000000000b6fad4b15657429fbff0bd5bc874b47c1dc452ec0000000000000000000000000c148703b23652a498137b3c1802eb433b86e7910000000000000000000000009ce943d92b20cc81b8b11fa8b27a9182f59acf410000000000000000000000009d9388e7f7170e8a7bdd8e5ac4e1e02e64fca0eb0000000000000000000000007b2710b1750f7d3862ba62aa335f2f14e1cf3477000000000000000000000000636eb42c4f8fc8b9d37316ac586943c29f9bdf620000000000000000000000008427eba4340fbaebbaa923ffd028fab9c28ba4ba000000000000000000000000652e53fa9af39e15fc4f19b2eb8223c2dc23545e00000000000000000000000001e7ba1dbc4b75fa04f0e61e4e261c171fd61df8", contractAddress: "", cumulativeGasUsed: "3819277", gasUsed: "226679", confirmations: "3131211"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[126]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[126]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511449150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4611382", timeStamp: "1511501754", hash: "0x825545bf81f99dbb952eb3be180a3f65b793a9d1d3cf728a6b399aabf8947672", nonce: "0", blockHash: "0x9cbf7e1a59623da25979d99f81eb4ea20d08b6283ac3600c3a887c35311ddb91", transactionIndex: "32", from: "0x849cb83281d88975649368b840953b0caaf32c4b", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "2175100000000000000", gas: "250000", gasPrice: "5427760000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "917969", gasUsed: "70772", confirmations: "3127369"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[135], to: addressList[2], value: "2175100000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511501754 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x849cb83281d88975649368b840953b0caaf32c4b"}, {name: "beneficiary", type: "address", value: "0x849cb83281d88975649368b840953b0caaf32c4b"}, {name: "value", type: "uint256", value: "2175100000000000000"}, {name: "amount", type: "uint256", value: "25740133400000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[135], balance: "1482721589280000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[135], balance: ( await web3.eth.getBalance( addressList[135], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4612785", timeStamp: "1511522242", hash: "0x93b085939a28c2a2773ff01b39251a9d635e85495ec455322437e69a5ec00042", nonce: "29", blockHash: "0x11c45aed20a185d17311efa7e8ff873b9ebf1753b36ac1d4fa8194255953ed2e", transactionIndex: "7", from: "0x9d9388e7f7170e8a7bdd8e5ac4e1e02e64fca0eb", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "5580000000000000000", gas: "100000", gasPrice: "29000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "377758", gasUsed: "70772", confirmations: "3125966"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[145], to: addressList[2], value: "5580000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511522242 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x9d9388e7f7170e8a7bdd8e5ac4e1e02e64fca0eb"}, {name: "beneficiary", type: "address", value: "0x9d9388e7f7170e8a7bdd8e5ac4e1e02e64fca0eb"}, {name: "value", type: "uint256", value: "5580000000000000000"}, {name: "amount", type: "uint256", value: "66033720000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[145], balance: "24863043681242021397" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[145], balance: ( await web3.eth.getBalance( addressList[145], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistUsers( [addressList[150],addressList[151],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4613909", timeStamp: "1511537698", hash: "0x0ec53732e97698a16c5a4224f74a389c97349a430d85f50dcea7e2d951c2dad1", nonce: "28", blockHash: "0x5821200dc93ae78988234ba727808e4dd175a5556ec2fcb9520ee9fdb8086802", transactionIndex: "41", from: "0x0000003937c42d613c9eb87e233f7ce3bf99e261", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "0", gas: "263568", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xedec5f270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000a0e4949eda31898ce6863047bd9649e8f8a57e30000000000000000000000000f86fd121bd825ffabb7709116ae0eebdc8dc6365000000000000000000000000dcc261bfff8ffc509803c26fd0aad2c70238a04400000000000000000000000065caf645185e2361c70b099ff579e0d54e5765be00000000000000000000000077e10731f17444570c19320b6a63912f89611b71000000000000000000000000cc09bdc2edf656b5ca45858d3d710d451da5a3050000000000000000000000000c78ed0edc389aa466e6519a7e111ff6d474a23a000000000000000000000000b4644415a639bf48418f50717ea59e7299682173000000000000000000000000b1de0dc512415356f68155bd8ba65120564e3343000000000000000000000000036992d2fe2d7aeefab894ff173113c37cde4ec900000000000000000000000049390272d570f1957836272102f95e29df1bcec5", contractAddress: "", cumulativeGasUsed: "1489342", gasUsed: "263568", confirmations: "3124842"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "users", value: [addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160]]}], name: "whitelistUsers", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistUsers(address[])" ]( [addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511537698 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "38757668200000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4614698", timeStamp: "1511548921", hash: "0x40735d109a74ff807fa46361b316081da5ccb9621e41cd4b51d2815698a5af98", nonce: "14", blockHash: "0xae076f43bf85c9b238bb426dba63f061b3c1830e7fbfe354eb8a894a35b2639e", transactionIndex: "65", from: "0x65caf645185e2361c70b099ff579e0d54e5765be", to: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825", value: "300000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1812038", gasUsed: "70772", confirmations: "3124053"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[153], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511548921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x65caf645185e2361c70b099ff579e0d54e5765be"}, {name: "beneficiary", type: "address", value: "0x65caf645185e2361c70b099ff579e0d54e5765be"}, {name: "value", type: "uint256", value: "300000000000000000"}, {name: "amount", type: "uint256", value: "3550200000000000000000"}], address: "0xe0fc5d52576e05dd7403782ba1d9a7fc82cf2825"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[153], balance: "10282530596707806" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[153], balance: ( await web3.eth.getBalance( addressList[153], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
