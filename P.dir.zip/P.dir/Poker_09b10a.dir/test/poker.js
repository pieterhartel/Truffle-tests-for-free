const Poker = artifacts.require( "./Poker.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Poker" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xf12a2E2a1a1D714D6C7dB114806411596A09B10a", "0x00DaA9a2D88BEd5a29A6ca93e0B7d860cd1d403F", "0x729D19f657BD0614b4985Cf1D82531c67569197B"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "read", outputs: [{name: "", type: "bytes32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "peek", outputs: [{name: "", type: "bytes32"}, {name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "zzz", outputs: [{name: "", type: "uint128"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "authority", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: true, inputs: [{indexed: true, name: "sig", type: "bytes4"}, {indexed: true, name: "guy", type: "address"}, {indexed: true, name: "foo", type: "bytes32"}, {indexed: true, name: "bar", type: "bytes32"}, {indexed: false, name: "wad", type: "uint256"}, {indexed: false, name: "fax", type: "bytes"}], name: "LogNote", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "authority", type: "address"}], name: "LogSetAuthority", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}], name: "LogSetOwner", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogNote(bytes4,address,bytes32,bytes32,uint256,bytes)", "LogSetAuthority(address)", "LogSetOwner(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x644843f351d3fba4abcd60109eaff9f54bac8fb8ccf0bab941009c21df21cf31", "0x1abebea81bfa2637f28358c371278fb15ede7ea8dd28d2e03b112ff6d936ada4", "0xce241d7ca1f669fee44b6fc00b8eba2df3bb514eed0f6f668f8f89096e81ed94"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3899132 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3909339 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Poker", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "read", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "read()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "peek", outputs: [{name: "", type: "bytes32"}, {name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "peek()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "zzz", outputs: [{name: "", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "zzz()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "authority", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "authority()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Poker", function( accounts ) {

	it( "TEST: Poker(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3899132", timeStamp: "1497891979", hash: "0x969363c6c73aa3c63eff2bfec2e7b7690552e664fcd71dc0fb022ff9a237e568", nonce: "2504", blockHash: "0x9459eaa28492480aafa3e973fb4d8d62587dc36533c1fd334f06dd29a91888cd", transactionIndex: "54", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: 0, value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x4505a096", contractAddress: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", cumulativeGasUsed: "2446246", gasUsed: "668148", confirmations: "3777738"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Poker", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Poker.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1497891979 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Poker.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}], name: "LogSetOwner", type: "event"} ;
		console.error( "eventCallOriginal[0,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetOwner", events: [{name: "owner", type: "address", value: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f"}], address: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a"}] ;
		console.error( "eventResultOriginal[0,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3899158", timeStamp: "1497892391", hash: "0x017e87189d0188c72602ffa0c1fe66081de6607ee1cb7a05b72c7a9189d9c6ca", nonce: "2506", blockHash: "0x6009b99043f3b4a52a83de0fd6166be2d2cac6c28d834ec0afa42278091a87d5", transactionIndex: "64", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001367d4ea64c69500000000000000000000000000000000000000000000000000000000000059482fff", contractAddress: "", cumulativeGasUsed: "2216400", gasUsed: "105841", confirmations: "3777712"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001367d4ea64c6950000"}, {type: "uint128", name: "zzz", value: "1497903103"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001367d4ea64c6950000", "1497903103", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1497892391 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3899658", timeStamp: "1497900599", hash: "0xf0c5050f3b10b988b31afc9c36399b1a171eea6c6c568456922ee3832a5b5a4d", nonce: "2509", blockHash: "0xe144875b7546750007ca72b737ca28a11543e0dbaf4716d36ff1a06a028fd7b8", transactionIndex: "22", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001333832f5e335c00000000000000000000000000000000000000000000000000000000000059485031", contractAddress: "", cumulativeGasUsed: "1405400", gasUsed: "76680", confirmations: "3777212"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001333832f5e335c0000"}, {type: "uint128", name: "zzz", value: "1497911345"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001333832f5e335c0000", "1497911345", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1497900599 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3900290", timeStamp: "1497911116", hash: "0x60cfca247c62a069c1d5ede5287665b8e86b51ff18a490b7ed3fa0ab7b0f77db", nonce: "2511", blockHash: "0x6fe0f96e101efeef53ec825152795559e11737471740736c354c2ff58983eaef", transactionIndex: "43", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001358fb831010ea0000000000000000000000000000000000000000000000000000000000005948796f", contractAddress: "", cumulativeGasUsed: "2275426", gasUsed: "75841", confirmations: "3776580"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001358fb831010ea0000"}, {type: "uint128", name: "zzz", value: "1497921903"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001358fb831010ea0000", "1497921903", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1497911116 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3900936", timeStamp: "1497921725", hash: "0xb4fbce12a4f1a360130849287f0dfcf5fab988a743f2e79846e09598905f982b", nonce: "2513", blockHash: "0x00df241edf1ee2027433a9d22d0a3e0c4f3f6045c2474a1b6602e29736b36fad", transactionIndex: "103", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000013756e93338e770000000000000000000000000000000000000000000000000000000000005948a2af", contractAddress: "", cumulativeGasUsed: "4053784", gasUsed: "76680", confirmations: "3775934"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000013756e93338e770000"}, {type: "uint128", name: "zzz", value: "1497932463"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000013756e93338e770000", "1497932463", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1497921725 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3901360", timeStamp: "1497929413", hash: "0x521287c0c1b719b347a88ad3f9620e8de8440d280d67959a74094bd20c4ace23", nonce: "2515", blockHash: "0x538ec06d5cd53d0eb379cbf0f59028d68f5e8185b5298bdd2cd7b8c0632e24e2", transactionIndex: "42", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000013a99cc747b1ef0000000000000000000000000000000000000000000000000000000000005948c073", contractAddress: "", cumulativeGasUsed: "2398648", gasUsed: "75841", confirmations: "3775510"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000013a99cc747b1ef0000"}, {type: "uint128", name: "zzz", value: "1497940083"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000013a99cc747b1ef0000", "1497940083", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1497929413 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3901950", timeStamp: "1497939906", hash: "0x3343a7b26cf0179f8c2952ea5a4683d00ad65f67eb6be3dcdeb175da7a89efd0", nonce: "2517", blockHash: "0x2463f37dc083d111e81176a392014dd2e9468176832b432c1173c35c0d8dae35", transactionIndex: "32", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "20000000010", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000013a52be8f9b9cf0000000000000000000000000000000000000000000000000000000000005948e9b3", contractAddress: "", cumulativeGasUsed: "1123524", gasUsed: "76680", confirmations: "3774920"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000013a52be8f9b9cf0000"}, {type: "uint128", name: "zzz", value: "1497950643"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000013a52be8f9b9cf0000", "1497950643", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1497939906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3902557", timeStamp: "1497950411", hash: "0x333e420c521da5a5fc142db629b47578c11d40d3104acc2c4b291e43adff35b4", nonce: "2519", blockHash: "0xb74f7c9125b04dfa906f3b6dc0dbd78658377b7dbf00ab513e91f00e61611735", transactionIndex: "62", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "25387963393", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000013a47a463d8b0a000000000000000000000000000000000000000000000000000000000000594912f3", contractAddress: "", cumulativeGasUsed: "1618620", gasUsed: "76680", confirmations: "3774313"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000013a47a463d8b0a0000"}, {type: "uint128", name: "zzz", value: "1497961203"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000013a47a463d8b0a0000", "1497961203", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1497950411 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3903175", timeStamp: "1497961095", hash: "0xa6eef9a446a55435d14d0234e398c24232e18a9b3e264d5c39509410422dbf5f", nonce: "2521", blockHash: "0x4d174859ebfa982b7292d75cd037fb112257b29ec918f00777a50faf402b3380", transactionIndex: "71", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "24313966608", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000013bc9fff05803800000000000000000000000000000000000000000000000000000000000059493c35", contractAddress: "", cumulativeGasUsed: "2848410", gasUsed: "75841", confirmations: "3773695"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000013bc9fff0580380000"}, {type: "uint128", name: "zzz", value: "1497971765"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000013bc9fff0580380000", "1497971765", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1497961095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904305", timeStamp: "1497981560", hash: "0x8c7edef2543e805acdf0ed4a02a74082d90985879f3eecfccd84314b4412fb6f", nonce: "2525", blockHash: "0xf8ba117abea3253be2bc3b6b71d79023a26e2b872b7cd6ac28a34c52a7b7c218", transactionIndex: "28", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "58000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000013c80138ad4c0a00000000000000000000000000000000000000000000000000000000000059496573", contractAddress: "", cumulativeGasUsed: "2361811", gasUsed: "74376", confirmations: "3772565"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000013c80138ad4c0a0000"}, {type: "uint128", name: "zzz", value: "1497982323"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000013c80138ad4c0a0000", "1497982323", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1497981560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904312", timeStamp: "1497981623", hash: "0xaa1a98fcc2b38ea0346a2b40a1c6c28a4f2ed6ec603b8f5d006180b3ef266ae7", nonce: "2526", blockHash: "0x6312be76c79274d6d612c70d8c144d11e36e897c3a2e4bb3d488337131bd0c23", transactionIndex: "26", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001352bcca726bfd00000000000000000000000000000000000000000000000000000000000059498cd6", contractAddress: "", cumulativeGasUsed: "763834", gasUsed: "74376", confirmations: "3772558"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001352bcca726bfd0000"}, {type: "uint128", name: "zzz", value: "1497992406"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001352bcca726bfd0000", "1497992406", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1497981623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904370", timeStamp: "1497982450", hash: "0x8d10139b1a77b476bac48242a7fcef7de30256451a028ad4f3b890fc3038284c", nonce: "2529", blockHash: "0xd8208157170b0f10044b5e97eed0e0a3bd343edca6ca85db38bd3f0c9082b6f9", transactionIndex: "34", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001317572d1f95510000000000000000000000000000000000000000000000000000000000005949901c", contractAddress: "", cumulativeGasUsed: "1218114", gasUsed: "76680", confirmations: "3772500"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001317572d1f95510000"}, {type: "uint128", name: "zzz", value: "1497993244"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001317572d1f95510000", "1497993244", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1497982450 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904380", timeStamp: "1497982630", hash: "0xc7c5569661dec7d4bed3861b793d6c6b5f1fb318d1b66f9227d4f64348d3e873", nonce: "2530", blockHash: "0x9ff6fab52538eec87ac1e453543d633437b37ad88ef5016f6bb9a579af22f60d", transactionIndex: "38", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012b986d4f07bad000000000000000000000000000000000000000000000000000000000000594990d1", contractAddress: "", cumulativeGasUsed: "1138031", gasUsed: "76680", confirmations: "3772490"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012b986d4f07bad0000"}, {type: "uint128", name: "zzz", value: "1497993425"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012b986d4f07bad0000", "1497993425", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1497982630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904396", timeStamp: "1497982898", hash: "0xc1283084e91f698a8ac72dca473ce72ca94a69a0241f2ff803dbc3bc992ebcf0", nonce: "2533", blockHash: "0x8e48524d4a17284cb37954b0f65b7e2e21fdc09f78b019ccd6c966e7887c649a", transactionIndex: "28", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000126e72a69a50d0000000000000000000000000000000000000000000000000000000000000594991c0", contractAddress: "", cumulativeGasUsed: "1264980", gasUsed: "76680", confirmations: "3772474"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000126e72a69a50d00000"}, {type: "uint128", name: "zzz", value: "1497993664"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000126e72a69a50d00000", "1497993664", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1497982898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904412", timeStamp: "1497983114", hash: "0x5c461d57ea50c9d1294c2e08c1e5a3233bba92ed71c72e9c4878cce1817e4a68", nonce: "2536", blockHash: "0xf7e1ac457888247f79f0ca2390d5755175d9611b9b43ac368893d2a3f3b32936", transactionIndex: "21", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000120bc6db45efc9000000000000000000000000000000000000000000000000000000000000594992b1", contractAddress: "", cumulativeGasUsed: "929841", gasUsed: "75841", confirmations: "3772458"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000120bc6db45efc90000"}, {type: "uint128", name: "zzz", value: "1497993905"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000120bc6db45efc90000", "1497993905", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1497983114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904418", timeStamp: "1497983236", hash: "0x9b4e309ffb8ee34bcf3bb58b8815d62102f5dd56d58bb33a862176f53ebaac20", nonce: "2538", blockHash: "0xdae18aa5c671927d75b6744b7144b38173d5abd38bfbc470ab33388bdbf8629b", transactionIndex: "36", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000119e47f21381f400000000000000000000000000000000000000000000000000000000000059499328", contractAddress: "", cumulativeGasUsed: "2540840", gasUsed: "76680", confirmations: "3772452"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000119e47f21381f40000"}, {type: "uint128", name: "zzz", value: "1497994024"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000119e47f21381f40000", "1497994024", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1497983236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904427", timeStamp: "1497983372", hash: "0x6a8007a15ae612ed02e24ca636c7eedf8e3dfe28245e5cfcd57cb8310383d48e", nonce: "2540", blockHash: "0x5171576894a96317ec84b18e74d4fbb14b763e026e8607662999c4ab12bae480", transactionIndex: "137", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000011e056dcdb4cd000000000000000000000000000000000000000000000000000000000000059499364", contractAddress: "", cumulativeGasUsed: "4125736", gasUsed: "75841", confirmations: "3772443"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000011e056dcdb4cd00000"}, {type: "uint128", name: "zzz", value: "1497994084"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000011e056dcdb4cd00000", "1497994084", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1497983372 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904430", timeStamp: "1497983434", hash: "0x885fb947bc89ffc53870c0bf3f0c7bb476536a6e0f99134dadedc28b8b9a1e5d", nonce: "2541", blockHash: "0x975147a3431c99ebfb6c4866e357a81bed9fe6eaace068788ea4bbc0def30f62", transactionIndex: "25", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012c19367ddcd67000000000000000000000000000000000000000000000000000000000000594993dd", contractAddress: "", cumulativeGasUsed: "1091356", gasUsed: "75841", confirmations: "3772440"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012c19367ddcd670000"}, {type: "uint128", name: "zzz", value: "1497994205"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012c19367ddcd670000", "1497994205", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1497983434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904441", timeStamp: "1497983697", hash: "0x832a019fb4ed0318844a7a074db484eeee7716ff0bfc10a2a2ae594325709779", nonce: "2544", blockHash: "0xd9d137c0beb3abb42aec3b0f97ae10d9ecedc3e243edd8034bd86cf9c7112f00", transactionIndex: "80", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012f50ff935c21a000000000000000000000000000000000000000000000000000000000000594994cd", contractAddress: "", cumulativeGasUsed: "3184069", gasUsed: "75841", confirmations: "3772429"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012f50ff935c21a0000"}, {type: "uint128", name: "zzz", value: "1497994445"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012f50ff935c21a0000", "1497994445", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1497983697 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904463", timeStamp: "1497983954", hash: "0x963d0e3c3b4e0e97ac00c58268d32c7664dcec4075f39eba62c01cf4fa257f7e", nonce: "2546", blockHash: "0x525a8b031040b510c6a3be1fa038a54c4581a673d740be6b6ab23372341555fd", transactionIndex: "16", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001338ecbe4d39c3000000000000000000000000000000000000000000000000000000000000594995f7", contractAddress: "", cumulativeGasUsed: "825155", gasUsed: "75841", confirmations: "3772407"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001338ecbe4d39c30000"}, {type: "uint128", name: "zzz", value: "1497994743"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001338ecbe4d39c30000", "1497994743", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1497983954 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904480", timeStamp: "1497984266", hash: "0xb513ba66bb595ae8545ad395d18424151d802147d2ad881860243069826a79c6", nonce: "2548", blockHash: "0x2719dac78292cc0d33936a2c15d701f258595827a6333694207093fa1caa41e7", transactionIndex: "82", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012eacaf721745000000000000000000000000000000000000000000000000000000000000059499723", contractAddress: "", cumulativeGasUsed: "3510035", gasUsed: "76680", confirmations: "3772390"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012eacaf72174500000"}, {type: "uint128", name: "zzz", value: "1497995043"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012eacaf72174500000", "1497995043", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1497984266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904509", timeStamp: "1497984893", hash: "0xa565c95362e41d19f69714945660a942266fb416f1a9c7cff6f1feb6ecac9188", nonce: "2551", blockHash: "0x10fc95bf497ec3af2569a2a7b7faa30ffe91636ca8526628be16190d4f6b3c8f", transactionIndex: "72", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012b86a9d5cfda50000000000000000000000000000000000000000000000000000000000005949997b", contractAddress: "", cumulativeGasUsed: "2451541", gasUsed: "76680", confirmations: "3772361"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012b86a9d5cfda50000"}, {type: "uint128", name: "zzz", value: "1497995643"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012b86a9d5cfda50000", "1497995643", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1497984893 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904537", timeStamp: "1497985268", hash: "0x5686fbdafd6f4e604339a3f8c006d6ae9d5233e08ed4040747b47821ac26f939", nonce: "2553", blockHash: "0xfac18013a6e238c250461f6e9674bc1e2f47a58a7c191cf75f40db9217a60e4a", transactionIndex: "17", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000127fcb8afae20d00000000000000000000000000000000000000000000000000000000000059499ae7", contractAddress: "", cumulativeGasUsed: "604733", gasUsed: "76680", confirmations: "3772333"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000127fcb8afae20d0000"}, {type: "uint128", name: "zzz", value: "1497996007"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000127fcb8afae20d0000", "1497996007", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1497985268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904542", timeStamp: "1497985329", hash: "0x8f6b3cc6d15d86a54447d888c923af1ed80358194ea27cfdd844713600d0927e", nonce: "2554", blockHash: "0x68182e96420954351ab91a6875ac6b0f0c1de671fdd9a61776a1d9b11af1610b", transactionIndex: "15", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012bf7e7fa9411800000000000000000000000000000000000000000000000000000000000059499b5d", contractAddress: "", cumulativeGasUsed: "638841", gasUsed: "75841", confirmations: "3772328"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012bf7e7fa941180000"}, {type: "uint128", name: "zzz", value: "1497996125"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012bf7e7fa941180000", "1497996125", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1497985329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904546", timeStamp: "1497985404", hash: "0xaece76f28a022d9b6dfaa25d640fabbd9e5920996f33a8b1c4e40ff3ed0a6fe8", nonce: "2556", blockHash: "0x1c42dcf64ec506dbeba56f1df860c3798be4832d69582f1223fe5f4264575bc5", transactionIndex: "59", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012f8f2bbb9fb3600000000000000000000000000000000000000000000000000000000000059499b98", contractAddress: "", cumulativeGasUsed: "2451450", gasUsed: "75841", confirmations: "3772324"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012f8f2bbb9fb360000"}, {type: "uint128", name: "zzz", value: "1497996184"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012f8f2bbb9fb360000", "1497996184", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1497985404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904575", timeStamp: "1497985812", hash: "0xb2facdb1ad5febf6d8f0c5af060500825196fdeaf8443a6df03eb17e863dbac8", nonce: "2558", blockHash: "0xa9b495f47381b6d6b9f20dbb7ac0d342ba7ca507b7aa87de4ff71cede3bc5cdd", transactionIndex: "44", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012c1b6eed03d2800000000000000000000000000000000000000000000000000000000000059499d3b", contractAddress: "", cumulativeGasUsed: "2678743", gasUsed: "76680", confirmations: "3772295"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012c1b6eed03d280000"}, {type: "uint128", name: "zzz", value: "1497996603"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012c1b6eed03d280000", "1497996603", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1497985812 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904592", timeStamp: "1497986040", hash: "0xddcd978ce3ad384284290037ff2e4e53f9d70057a0a5a453adf20e620fcea399", nonce: "2559", blockHash: "0xaced8250dab38904ffb19f8320e4c9d1c0eb8545a0b81008d8d083f319e11e42", transactionIndex: "28", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012f8f2bbb9fb3600000000000000000000000000000000000000000000000000000000000059499df0", contractAddress: "", cumulativeGasUsed: "1273427", gasUsed: "76680", confirmations: "3772278"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012f8f2bbb9fb360000"}, {type: "uint128", name: "zzz", value: "1497996784"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012f8f2bbb9fb360000", "1497996784", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1497986040 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904618", timeStamp: "1497986296", hash: "0x961d36f9a555e8dfcb7ca7764c67b7ee1ea5f225279b9651403ba91c8cb44721", nonce: "2560", blockHash: "0x7ac5b7e44a09136939597548ff289223119b1ced1f105b2edc1b630314eb8996", transactionIndex: "26", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000132f595ef51abe00000000000000000000000000000000000000000000000000000000000059499f1c", contractAddress: "", cumulativeGasUsed: "1708463", gasUsed: "75841", confirmations: "3772252"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000132f595ef51abe0000"}, {type: "uint128", name: "zzz", value: "1497997084"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000132f595ef51abe0000", "1497997084", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1497986296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904626", timeStamp: "1497986483", hash: "0xb0631b737cea7b236b70b14acc616d2f7a5569ec51170c3409b1d68b7d405837", nonce: "2562", blockHash: "0xf422ede3deb084bb147755d186dbae3f52ee0c9a3b11838007098c5b71880f37", transactionIndex: "34", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012f939c99edab800000000000000000000000000000000000000000000000000000000000059499fd1", contractAddress: "", cumulativeGasUsed: "2174318", gasUsed: "76680", confirmations: "3772244"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012f939c99edab80000"}, {type: "uint128", name: "zzz", value: "1497997265"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012f939c99edab80000", "1497997265", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1497986483 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904726", timeStamp: "1497988304", hash: "0x94a56f1e71918785c5d67b6dabb19d5e075498de08c9cdb5ebcd2059509b2b78", nonce: "2565", blockHash: "0x1cd60e2bda4d0f11b9b6af9eb0e6e0d786d5056e877b13bf9e91a82711752f4c", transactionIndex: "42", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012bdd42c4c040c0000000000000000000000000000000000000000000000000000000000005949a5e7", contractAddress: "", cumulativeGasUsed: "2592296", gasUsed: "76680", confirmations: "3772144"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012bdd42c4c040c0000"}, {type: "uint128", name: "zzz", value: "1497998823"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012bdd42c4c040c0000", "1497998823", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1497988304 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904847", timeStamp: "1497990135", hash: "0x32e7db6cabc05d315fdf715218c8a2e9921fc550149ac7ebabc404031240c849", nonce: "2569", blockHash: "0x5e5bec81b64affb2f5df6d9ad48f410f15697901e265594dc3b4b8fe3eebf9bd", transactionIndex: "12", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000128059a6c4a1110000000000000000000000000000000000000000000000000000000000005949ae1b", contractAddress: "", cumulativeGasUsed: "1174818", gasUsed: "76680", confirmations: "3772023"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000128059a6c4a1110000"}, {type: "uint128", name: "zzz", value: "1498000923"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000128059a6c4a1110000", "1498000923", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1497990135 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3904999", timeStamp: "1497992989", hash: "0xc2a7b0d8ad7cc60bc17ee20f4a623fa2117e5c96006511bb3009c85e6dfa4b21", nonce: "2572", blockHash: "0xee20cc148badcd9a68addcd5e6264352abcc7839c01199b370d3538b4d57c3a2", transactionIndex: "57", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012b08191621bac0000000000000000000000000000000000000000000000000000000000005949b922", contractAddress: "", cumulativeGasUsed: "3248758", gasUsed: "75841", confirmations: "3771871"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012b08191621bac0000"}, {type: "uint128", name: "zzz", value: "1498003746"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012b08191621bac0000", "1498003746", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1497992989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3905011", timeStamp: "1497993207", hash: "0x3bb2284aad2125bbf683b5edd97cdc079ea816e98269e6864f5e41ab97f51060", nonce: "2574", blockHash: "0x869d684d861ffd961176d9a5e1db7e925ac8746951baaabb3610005fccbea7ac", transactionIndex: "12", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012e752c9748a770000000000000000000000000000000000000000000000000000000000005949ba11", contractAddress: "", cumulativeGasUsed: "957527", gasUsed: "75841", confirmations: "3771859"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012e752c9748a770000"}, {type: "uint128", name: "zzz", value: "1498003985"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012e752c9748a770000", "1498003985", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1497993207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3905037", timeStamp: "1497993566", hash: "0xc9a9bc1fb7f6b55d79c82f0e3a01d4ed0e268f0277833078219bae5724e1a4e2", nonce: "2576", blockHash: "0xb174aa37d0accc085522164d7cb27dcb42ea4afb0d42d183ec0e7ef2e2896b9c", transactionIndex: "28", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000131c0f19526cf30000000000000000000000000000000000000000000000000000000000005949bb3a", contractAddress: "", cumulativeGasUsed: "1607442", gasUsed: "75841", confirmations: "3771833"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000131c0f19526cf30000"}, {type: "uint128", name: "zzz", value: "1498004282"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000131c0f19526cf30000", "1498004282", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1497993566 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3905449", timeStamp: "1498001126", hash: "0x8ae383bf680f6bb948cff2987e29a6d3dae3471ad541d52639cc6ff8886193c6", nonce: "2579", blockHash: "0x21b78d650ade6a347e67614f886ceeaadbbd3adbb346da8285f338e638b87fbe", transactionIndex: "33", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012b41d460175460000000000000000000000000000000000000000000000000000000000005949d901", contractAddress: "", cumulativeGasUsed: "4345530", gasUsed: "76680", confirmations: "3771421"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012b41d460175460000"}, {type: "uint128", name: "zzz", value: "1498011905"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012b41d460175460000", "1498011905", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1498001126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3905520", timeStamp: "1498002316", hash: "0x4dd66081fb6e67eccd0d6b495b40d9387039bc4451cc861fd523bf3e0aef6aee", nonce: "2581", blockHash: "0xaaa50c258dd6815d4b224d11b183cd975791af4e089c9650340e9628dca59765", transactionIndex: "16", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012e445309eefe10000000000000000000000000000000000000000000000000000000000005949ddb1", contractAddress: "", cumulativeGasUsed: "1136851", gasUsed: "75841", confirmations: "3771350"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012e445309eefe10000"}, {type: "uint128", name: "zzz", value: "1498013105"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012e445309eefe10000", "1498013105", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1498002316 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3905775", timeStamp: "1498006654", hash: "0x7df544dbc23f9725f5ccd443fcd970ad4ea04a7e390b36ffd0593de2fb22ffaf", nonce: "2583", blockHash: "0x5535bf4d20092c788ecc879b38465ecca1ee42fa40c8118206e244780c17ca96", transactionIndex: "21", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001314fb370629800000000000000000000000000000000000000000000000000000000000005949eda0", contractAddress: "", cumulativeGasUsed: "4330635", gasUsed: "75841", confirmations: "3771095"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001314fb370629800000"}, {type: "uint128", name: "zzz", value: "1498017184"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001314fb370629800000", "1498017184", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1498006654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3905891", timeStamp: "1498008620", hash: "0x4b673bc0f5dcd8aa20703c3bee937bdc81f2e2fde01cb31058f73c7e4b7aeaf1", nonce: "2584", blockHash: "0xd0b9cffa386f0ffbf5f90c01e74fe758f133557cd969278701c7d39e78eec1e1", transactionIndex: "20", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "57475936256", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012e03ee72847040000000000000000000000000000000000000000000000000000000000005949f64d", contractAddress: "", cumulativeGasUsed: "2156873", gasUsed: "76680", confirmations: "3770979"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012e03ee72847040000"}, {type: "uint128", name: "zzz", value: "1498019405"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012e03ee72847040000", "1498019405", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1498008620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3906525", timeStamp: "1498019038", hash: "0x0e8cc8a927dcc24cbd9ea447a2c445f2078b0f09ecd37af83e24ce3db047c5c3", nonce: "2586", blockHash: "0xb3305ee0ad868e5d7ca18a281143f6c54d7ba0692de07ee25af51a7cb80e2fbb", transactionIndex: "5", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000012ae6ca92d8f5d000000000000000000000000000000000000000000000000000000000000594a1e10", contractAddress: "", cumulativeGasUsed: "267001", gasUsed: "76680", confirmations: "3770345"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000012ae6ca92d8f5d0000"}, {type: "uint128", name: "zzz", value: "1498029584"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000012ae6ca92d8f5d0000", "1498029584", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1498019038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3906577", timeStamp: "1498019827", hash: "0x4151625485e655bfaef528501f616b0410f15aa0fbbc81bf717cebd568985e19", nonce: "2588", blockHash: "0x9d98bf59ad644692f180a05c16dbebbb3e3671e6fe68d3618aa93f7c26a373ae", transactionIndex: "8", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "61000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000122fb8628d000c000000000000000000000000000000000000000000000000000000000000594a21e8", contractAddress: "", cumulativeGasUsed: "381462", gasUsed: "76616", confirmations: "3770293"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000122fb8628d000c0000"}, {type: "uint128", name: "zzz", value: "1498030568"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000122fb8628d000c0000", "1498030568", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1498019827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3906605", timeStamp: "1498020523", hash: "0x56382878fe26e99fb34bc258e46ff25d70aec7b4d3339df6cb32d5b0bd920092", nonce: "2590", blockHash: "0x0c4022267474d7c3632cdde40b08223b5530b4533c273852d47273cef493211a", transactionIndex: "66", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000011fd9f16ad68e3000000000000000000000000000000000000000000000000000000000000594a2400", contractAddress: "", cumulativeGasUsed: "1764098", gasUsed: "76616", confirmations: "3770265"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000011fd9f16ad68e30000"}, {type: "uint128", name: "zzz", value: "1498031104"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000011fd9f16ad68e30000", "1498031104", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1498020523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3906686", timeStamp: "1498022082", hash: "0xc299d6ea206639e68c498a8b1ca48bc0819bfe7b6a5595f67414fdfc28bde727", nonce: "2591", blockHash: "0x90d9e60b51319f2ce060eda675c1b24522eb4b8943e9d400005d4ab725aad8a8", transactionIndex: "26", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000122f4dcdb5b0c9000000000000000000000000000000000000000000000000000000000000594a252d", contractAddress: "", cumulativeGasUsed: "2979116", gasUsed: "76680", confirmations: "3770184"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000122f4dcdb5b0c90000"}, {type: "uint128", name: "zzz", value: "1498031405"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000122f4dcdb5b0c90000", "1498031405", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1498022082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3906734", timeStamp: "1498022867", hash: "0x50c22cb596590b1fdd7b1895b5729a75b4b7adb62900bf8be9eaaf1c8051ba56", nonce: "2592", blockHash: "0xb3cd5b71d4176dc3d720b8fd65e47bbc88a33feaf64bfe8b7962cab620379b1a", transactionIndex: "23", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "55000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001287267b2c0502000000000000000000000000000000000000000000000000000000000000594a2ce8", contractAddress: "", cumulativeGasUsed: "2737811", gasUsed: "75841", confirmations: "3770136"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001287267b2c05020000"}, {type: "uint128", name: "zzz", value: "1498033384"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001287267b2c05020000", "1498033384", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1498022867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3906747", timeStamp: "1498023179", hash: "0xe892552f1ab416e2bce513806036f3f0b681e479124e459a32975fe5f94fdd5a", nonce: "2593", blockHash: "0xe3b10c9ea3ff9e5cebf11fe2020e21d0f68aa877fec703a39745b0469b149567", transactionIndex: "10", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "55000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001287267b2c0502000000000000000000000000000000000000000000000000000000000000594a2ce8", contractAddress: "", cumulativeGasUsed: "842291", gasUsed: "75841", confirmations: "3770123"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001287267b2c05020000"}, {type: "uint128", name: "zzz", value: "1498033384"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001287267b2c05020000", "1498033384", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1498023179 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3908634", timeStamp: "1498056862", hash: "0x3b86d8ed86c5571d7001dc1322cd2e3bfb3168443ded624f706fed69f100b1af", nonce: "2598", blockHash: "0x317f8fe511ab9f3f58b0fbfa3c8d7264ee6b61e3d6f8c1987a0aadbdb9539115", transactionIndex: "9", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000011828684ac332c000000000000000000000000000000000000000000000000000000000000594ab2bc", contractAddress: "", cumulativeGasUsed: "392141", gasUsed: "75841", confirmations: "3768236"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000011828684ac332c0000"}, {type: "uint128", name: "zzz", value: "1498067644"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000011828684ac332c0000", "1498067644", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1498056862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3908758", timeStamp: "1498058970", hash: "0x543393fee3d8d538184b7c37402eeffac1a8120368232627a6b453e9b77a1b4c", nonce: "2600", blockHash: "0xee99f972223c44033c4322d8d9c7a1c15140d3b5c93a250881259f5ff85aa274", transactionIndex: "24", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000113d22f329ee38000000000000000000000000000000000000000000000000000000000000594ab85f", contractAddress: "", cumulativeGasUsed: "922107", gasUsed: "75841", confirmations: "3768112"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000113d22f329ee380000"}, {type: "uint128", name: "zzz", value: "1498069087"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000113d22f329ee380000", "1498069087", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1498058970 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3908917", timeStamp: "1498061638", hash: "0x0e07fc5a383d19815db05c5426e38da3e995f269e24b2b3cf54d7401f8006b00", nonce: "2601", blockHash: "0x59ea38ecc918d52c3d5fc169e51ab4b3936de446d0aec5113663363e11c1c79d", transactionIndex: "13", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "55000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001105a0185b50a8000000000000000000000000000000000000000000000000000000000000594ac340", contractAddress: "", cumulativeGasUsed: "636795", gasUsed: "76680", confirmations: "3767953"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001105a0185b50a80000"}, {type: "uint128", name: "zzz", value: "1498071872"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001105a0185b50a80000", "1498071872", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1498061638 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3909026", timeStamp: "1498063545", hash: "0x3940f562d0a44335b8daf71a9eb047bad426cf5d3b0d73d7cdfd9f904a1436c9", nonce: "2603", blockHash: "0x7bce2c016cb42159eca489b7c5c6ab54d09c4127afff49a82472292723fe6a07", transactionIndex: "37", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b00000000000000000000000000000000000000000000001147446e4bcc41000000000000000000000000000000000000000000000000000000000000594accde", contractAddress: "", cumulativeGasUsed: "2547500", gasUsed: "76680", confirmations: "3767844"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x00000000000000000000000000000000000000000000001147446e4bcc410000"}, {type: "uint128", name: "zzz", value: "1498074334"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x00000000000000000000000000000000000000000000001147446e4bcc410000", "1498074334", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1498063545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3909197", timeStamp: "1498066989", hash: "0xa3555b2f6b2bd133f7f58b779ccdb919106242f91514042db87c3e7f29ef2248", nonce: "2604", blockHash: "0x986b71740d5bbac1529cdaa0ef885a534948fe67f3c39d8ea6c6b76e41e6d32e", transactionIndex: "24", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "55000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b0000000000000000000000000000000000000000000000107f90e1899e62000000000000000000000000000000000000000000000000000000000000594ad9fe", contractAddress: "", cumulativeGasUsed: "2152493", gasUsed: "76680", confirmations: "3767673"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x0000000000000000000000000000000000000000000000107f90e1899e620000"}, {type: "uint128", name: "zzz", value: "1498077694"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x0000000000000000000000000000000000000000000000107f90e1899e620000", "1498077694", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1498066989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: prod( addressList[4], \"0x00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3909339", timeStamp: "1498069671", hash: "0xaae5d174e98fa7186448ec686fda0c7461eb3a3e4accc3f995bd028b6cb0c6c6", nonce: "2607", blockHash: "0x52ba2786f6f56bfae41ab1fbf701dd972401a3803c6a958eb08efb5824999379", transactionIndex: "31", from: "0x00daa9a2d88bed5a29a6ca93e0b7d860cd1d403f", to: "0xf12a2e2a1a1d714d6c7db114806411596a09b10a", value: "0", gas: "200000", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0x552ac31e000000000000000000000000729d19f657bd0614b4985cf1d82531c67569197b000000000000000000000000000000000000000000000010dbda6d4deabb000000000000000000000000000000000000000000000000000000000000594ae4b5", contractAddress: "", cumulativeGasUsed: "2007626", gasUsed: "75841", confirmations: "3767531"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "med", value: addressList[4]}, {type: "bytes32", name: "wut", value: "0x000000000000000000000000000000000000000000000010dbda6d4deabb0000"}, {type: "uint128", name: "zzz", value: "1498080437"}], name: "prod", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "prod(address,bytes32,uint128)" ]( addressList[4], "0x000000000000000000000000000000000000000000000010dbda6d4deabb0000", "1498080437", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1498069671 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4786203118227657073" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
