const Pixel = artifacts.require( "./Pixel.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Pixel" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x92BCBc2240D581a3Fac5911Cb4d807E7A79590d8", "0xe2aB2851699d7A3e38f2fFF8F23a4EEe6B9Ca2B8", "0x79D0268B019610aB8d7f853fc2a06fD3cC440567", "0x730b81Aa9A98359E03C74254Fa4817E0cAB661F9", "0xA6E927157C5b4CeDa91E7444d325c50A38Ef6d38", "0x9d15ee903F2064745ACdF4605A342A9e71dc4f47", "0x0C7fa85d2975c442FC4E58c39539dED4ae4c6219", "0x42f1Ed2211a3e963d2E8F640823b2aCE9B28126b", "0x721c89c5E11036cBe86Bf7a2970DA2461462e602", "0x0BF913bedF5C6ACA673DB3B697A4e543550CeB4D"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "pool", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "totalSupply", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "sections", outputs: [{name: "owner", type: "address"}, {name: "price", type: "uint256"}, {name: "for_sale", type: "bool"}, {name: "initial_purchase_done", type: "bool"}, {name: "image_id", type: "uint256"}, {name: "md5", type: "string"}, {name: "last_update", type: "uint256"}, {name: "sell_only_to", type: "address"}, {name: "index", type: "uint16"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "standard", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "ipo_price", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "mapWidth", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "ethBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "mapHeight", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "NewListing", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Delisted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "NewImage", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}], name: "PriceUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "msg", type: "string"}], name: "WithdrawEvent", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Buy(uint256)", "NewListing(uint256,uint256)", "Delisted(uint256)", "NewImage(uint256)", "AreaPrice(uint256,uint256,uint256)", "SentValue(uint256)", "PriceUpdate(uint256)", "WithdrawEvent(string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x3e32821836f4caf5b64b2c8c6b460049a9797526960d31502f7575b8da39d5ae", "0xb0d7fd9aee4dbd2ba9a81ca84e5205eaf98e61ab2e9647d11e1d07ee9d4b8615", "0xc40fdc946efe80191c467f60727c4abc08254a056035d467a4516a86005ab763", "0x161c389af95e8499dd073054bfc4ed81696ed6d1cfc34e4481bcf3a1e46500b0", "0xb7598cca507cc3c2e08c80bffa710dde855c03a916a2bc1cbe170e6decf07476", "0xac82b296a68f111a983b21c3ef8d3581c8871622671c547fda6612912214eb71", "0xae46785019700e30375a5d7b4f91e32f8060ef085111f896ebf889450aa2ab5a", "0xd87ddcccc7994bd0a1cf24357995492435a3563413d41d9b0d10a8f5e37b5d49"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3966136 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3968954 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Pixel", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pool", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pool()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "totalSupply", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "sections", outputs: [{name: "owner", type: "address"}, {name: "price", type: "uint256"}, {name: "for_sale", type: "bool"}, {name: "initial_purchase_done", type: "bool"}, {name: "image_id", type: "uint256"}, {name: "md5", type: "string"}, {name: "last_update", type: "uint256"}, {name: "sell_only_to", type: "address"}, {name: "index", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sections(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "standard", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "standard()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ipo_price", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ipo_price()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "mapWidth", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "mapWidth()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "ethBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ethBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "mapHeight", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "mapHeight()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Pixel", function( accounts ) {

	it( "TEST: Pixel(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3966136", timeStamp: "1499055726", hash: "0x922ecffaeff2ac48653c9e3f70b2e6dafc06bf00040c419b25bca0f5d3bc254e", nonce: "0", blockHash: "0xf7b79a7f250c4b8030bf61b3eb4a7efa1ee8f0cadb07dee7b8e3c375d8b055f1", transactionIndex: "25", from: "0xe2ab2851699d7a3e38f2fff8f23a4eee6b9ca2b8", to: 0, value: "0", gas: "4000000", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x99aa5d97", contractAddress: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", cumulativeGasUsed: "4284740", gasUsed: "3618457", confirmations: "3711151"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Pixel", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Pixel.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1499055726 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Pixel.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: updateIPOPrice( \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3966164", timeStamp: "1499056114", hash: "0x2d30b9dbaf987d2fe8f333d93c99e7cf4d413ff45d07e33f8714bce5ec9a8cf5", nonce: "1", blockHash: "0x8f13d8a0008703f5d1c6865f3e8f703cc2d0cc6fdfcfdc2a06286bf17e8ceea2", transactionIndex: "4", from: "0xe2ab2851699d7a3e38f2fff8f23a4eee6b9ca2b8", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "22000", gasPrice: "40000000000", isError: "1", txreceipt_status: "", input: "0xc6114aaf000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "164472", gasUsed: "22000", confirmations: "3711123"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_new_price", value: "10000000000000000"}], name: "updateIPOPrice", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: updateIPOPrice( \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3966170", timeStamp: "1499056238", hash: "0x96038db8c37e79c57149392652d26db0b942e9f7f379f449c7daa1fec38949fe", nonce: "2", blockHash: "0x43aae468b9bb5507dc2accead8ef83ad7b0ed4cb89deee5a587a88c34a320b09", transactionIndex: "10", from: "0xe2ab2851699d7a3e38f2fff8f23a4eee6b9ca2b8", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "22500", gasPrice: "40000000000", isError: "1", txreceipt_status: "", input: "0xc6114aaf000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "612932", gasUsed: "22500", confirmations: "3711117"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_new_price", value: "10000000000000000"}], name: "updateIPOPrice", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: updateIPOPrice( \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3966192", timeStamp: "1499056600", hash: "0x3d4950cb49a6110c96cb95ad24d7e4c8f6e140dde12b9307859f3dc3bac0ce3e", nonce: "3", blockHash: "0xa5d1524f90978fe88ce79cda1f3ade788d11dca20e4d92815501ae28eaf4eebe", transactionIndex: "9", from: "0xe2ab2851699d7a3e38f2fff8f23a4eee6b9ca2b8", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "29075", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0xc6114aaf000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "307869", gasUsed: "29074", confirmations: "3711095"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_new_price", value: "10000000000000000"}], name: "updateIPOPrice", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateIPOPrice(uint256)" ]( "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1499056600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}], name: "PriceUpdate", type: "event"} ;
		console.error( "eventCallOriginal[3,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PriceUpdate", events: [{name: "price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[3,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"0\", \"404\", \"5312\", `f37b42fa2d2c3... )", async function( ) {
		const txOriginal = {blockNumber: "3966368", timeStamp: "1499059770", hash: "0x440f0ef5a37427b0fb62a921c9753375f2368ec07ea702af004efbedb36f7ca5", nonce: "0", blockHash: "0x2eca1eb4bce4f4d20fd8d90eca9ef54c7a14ea2e180933cc2411ac158264ac6b", transactionIndex: "20", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "25000000000000000", gas: "4787500", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000019400000000000000000000000000000000000000000000000000000000000014c0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206633376234326661326432633330633265346136623166356634343131373966", contractAddress: "", cumulativeGasUsed: "6521913", gasUsed: "4787500", confirmations: "3710919"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "0"}, {type: "uint256", name: "_end_section_index", value: "404"}, {type: "uint256", name: "_image_id", value: "5312"}, {type: "string", name: "_md5", value: `f37b42fa2d2c30c2e4a6b1f5f441179f`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"99\", \"99\", \"5316\", `74e23d876c5c3... )", async function( ) {
		const txOriginal = {blockNumber: "3966429", timeStamp: "1499060998", hash: "0xf94429e96ca21bba14c5ffd3cac49add0ee487ed51e42964b163503d672b6acf", nonce: "5", blockHash: "0x1e3f051d9d74ffc0c67e8d67d50ab169dc8b4fb9abf0249db44c00c74a64b757", transactionIndex: "58", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000063000000000000000000000000000000000000000000000000000000000000006300000000000000000000000000000000000000000000000000000000000014c4000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203734653233643837366335633330396530356162376536393033326164626562", contractAddress: "", cumulativeGasUsed: "2482969", gasUsed: "191629", confirmations: "3710858"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "99"}, {type: "uint256", name: "_end_section_index", value: "99"}, {type: "uint256", name: "_image_id", value: "5316"}, {type: "string", name: "_md5", value: `74e23d876c5c309e05ab7e69032adbeb`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "99", "99", "5316", `74e23d876c5c309e05ab7e69032adbeb`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1499060998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "99"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "99"}, {name: "end_section_index", type: "uint256", value: "99"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"51\", \"51\", \"5318\", `de564b1ef2eb6... )", async function( ) {
		const txOriginal = {blockNumber: "3966450", timeStamp: "1499061346", hash: "0x27bf24c03deb6ef989cb635363bbd942c38f571a7a7d773bb7d0fbeb41c5a0ae", nonce: "0", blockHash: "0x0369d85ccc55b3f9894ad6741bead72f56b0adb4a7a6b59b212255f2445b57a1", transactionIndex: "15", from: "0xa6e927157c5b4ceda91e7444d325c50a38ef6d38", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000033000000000000000000000000000000000000000000000000000000000000003300000000000000000000000000000000000000000000000000000000000014c6000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206465353634623165663265623637376132343262323537333364643364393865", contractAddress: "", cumulativeGasUsed: "617652", gasUsed: "176629", confirmations: "3710837"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "51"}, {type: "uint256", name: "_end_section_index", value: "51"}, {type: "uint256", name: "_image_id", value: "5318"}, {type: "string", name: "_md5", value: `de564b1ef2eb677a242b25733dd3d98e`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "51", "51", "5318", `de564b1ef2eb677a242b25733dd3d98e`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1499061346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "51"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "51"}, {name: "end_section_index", type: "uint256", value: "51"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"0\", \"303\", \"5324\", `f37b42fa2d2c3... )", async function( ) {
		const txOriginal = {blockNumber: "3966469", timeStamp: "1499061649", hash: "0xdcda53ee8a2a7095d859044bd066406cac994fec74e4f3cabcb603e959fe7e21", nonce: "1", blockHash: "0x1f3b1485dc0f4cbb691b9e1f46d957277a227dd79e1dbdbe3f8225aca4088d0d", transactionIndex: "11", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "160000000000000000", gas: "4184439", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000012f00000000000000000000000000000000000000000000000000000000000014cc000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206633376234326661326432633330633265346136623166356634343131373966", contractAddress: "", cumulativeGasUsed: "2516789", gasUsed: "2054386", confirmations: "3710818"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "160000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "0"}, {type: "uint256", name: "_end_section_index", value: "303"}, {type: "uint256", name: "_image_id", value: "5324"}, {type: "string", name: "_md5", value: `f37b42fa2d2c30c2e4a6b1f5f441179f`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "0", "303", "5324", `f37b42fa2d2c30c2e4a6b1f5f441179f`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1499061649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "0"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "100"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "200"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "300"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "101"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "201"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "301"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "2"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "102"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "202"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "302"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "103"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "203"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "303"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "0"}, {name: "end_section_index", type: "uint256", value: "303"}, {name: "area_price", type: "uint256", value: "160000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "160000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "3966484", timeStamp: "1499061956", hash: "0x31a34c265805caa0eb20a2079176828d03628110e74ce4b7a8daf7b443cb539f", nonce: "4", blockHash: "0x2526d5607edd6a1ed6d763a3a66fede14824a9967eb2f5487a5206f02e42be3d", transactionIndex: "22", from: "0xe2ab2851699d7a3e38f2fff8f23a4eee6b9ca2b8", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "38393", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2869474", gasUsed: "21209", confirmations: "3710803"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1499061956 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "msg", type: "string"}], name: "WithdrawEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawEvent", events: [{name: "msg", type: "string", value: "Reset Sender"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[8,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "3966486", timeStamp: "1499062056", hash: "0x6daa5926aa2666395809a1ddafe984e3b16b7ccc9b3ea970b53da5caa7f09c61", nonce: "5", blockHash: "0xaa75f985f54e28e2f9b24cb4c628bbe58edd1dc2b8e87c50cd964d0c07563f1b", transactionIndex: "45", from: "0xe2ab2851699d7a3e38f2fff8f23a4eee6b9ca2b8", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "21981", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2199141", gasUsed: "21980", confirmations: "3710801"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1499062056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"4\", \"307\", \"5373\", `f37b42fa2d2c3... )", async function( ) {
		const txOriginal = {blockNumber: "3966497", timeStamp: "1499062304", hash: "0x0cdd927f0b0df90d9522f93eafc9999f37f61a0e110598fd68f549114f5210f1", nonce: "2", blockHash: "0x5bd1a31bad3c53749a198c8ff70d7f841bb18721dcb9265b82a4d22c31c4fe25", transactionIndex: "19", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "160000000000000000", gas: "4184439", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000013300000000000000000000000000000000000000000000000000000000000014fd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206633376234326661326432633330633265346136623166356634343131373966", contractAddress: "", cumulativeGasUsed: "3065437", gasUsed: "2054450", confirmations: "3710790"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "160000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "4"}, {type: "uint256", name: "_end_section_index", value: "307"}, {type: "uint256", name: "_image_id", value: "5373"}, {type: "string", name: "_md5", value: `f37b42fa2d2c30c2e4a6b1f5f441179f`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "4", "307", "5373", `f37b42fa2d2c30c2e4a6b1f5f441179f`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1499062304 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "4"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "104"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "204"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "304"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "5"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "105"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "205"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "305"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "6"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "106"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "206"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "306"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "7"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "107"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "207"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "307"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "4"}, {name: "end_section_index", type: "uint256", value: "307"}, {name: "area_price", type: "uint256", value: "160000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "160000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"25\", \"226\", \"5344\", `4473f395e624... )", async function( ) {
		const txOriginal = {blockNumber: "3966497", timeStamp: "1499062304", hash: "0x3679960a6dbcb4e77a86d227f840dbe83b2e16fb6679eb11f0f616ad6f59d89f", nonce: "0", blockHash: "0x5bd1a31bad3c53749a198c8ff70d7f841bb18721dcb9265b82a4d22c31c4fe25", transactionIndex: "21", from: "0x9d15ee903f2064745acdf4605a342a9e71dc4f47", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "60000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000e200000000000000000000000000000000000000000000000000000000000014e0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203434373366333935653632346230616238646461346139646363386565633634", contractAddress: "", cumulativeGasUsed: "3904805", gasUsed: "802640", confirmations: "3710790"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "25"}, {type: "uint256", name: "_end_section_index", value: "226"}, {type: "uint256", name: "_image_id", value: "5344"}, {type: "string", name: "_md5", value: `4473f395e624b0ab8dda4a9dcc8eec64`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "25", "226", "5344", `4473f395e624b0ab8dda4a9dcc8eec64`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1499062304 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "25"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "125"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "225"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "26"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "126"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "226"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "25"}, {name: "end_section_index", type: "uint256", value: "226"}, {name: "area_price", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"5050\", \"5050\", \"5377\", `942c6de3f... )", async function( ) {
		const txOriginal = {blockNumber: "3966497", timeStamp: "1499062304", hash: "0xc07f6950c2641ed451d62b035c7edfc3b04e5e1d684eb606189cd558716ba1b6", nonce: "0", blockHash: "0x5bd1a31bad3c53749a198c8ff70d7f841bb18721dcb9265b82a4d22c31c4fe25", transactionIndex: "23", from: "0x0c7fa85d2975c442fc4e58c39539ded4ae4c6219", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000013ba00000000000000000000000000000000000000000000000000000000000013ba0000000000000000000000000000000000000000000000000000000000001501000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203934326336646533666339616464353032373738363239396438383063353235", contractAddress: "", cumulativeGasUsed: "4118299", gasUsed: "176757", confirmations: "3710790"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "5050"}, {type: "uint256", name: "_end_section_index", value: "5050"}, {type: "uint256", name: "_image_id", value: "5377"}, {type: "string", name: "_md5", value: `942c6de3fc9add5027786299d880c525`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "5050", "5050", "5377", `942c6de3fc9add5027786299d880c525`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1499062304 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "5050"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "5050"}, {name: "end_section_index", type: "uint256", value: "5050"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1752961000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"1764\", \"1966\", \"5392\", `7bb3561dc... )", async function( ) {
		const txOriginal = {blockNumber: "3966503", timeStamp: "1499062416", hash: "0xd0ddc71d0dd3b0290b0c478ef16eda625287c6a04978d16fc58f20910eb1c40c", nonce: "6", blockHash: "0x0200bb1698be5539cc841dd6d082d5f72c245d2ee94ae944f1b147888da32cc8", transactionIndex: "33", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "90000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000006e400000000000000000000000000000000000000000000000000000000000007ae0000000000000000000000000000000000000000000000000000000000001510000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203762623335363164633831356431643266623564643961366166366661373931", contractAddress: "", cumulativeGasUsed: "2517601", gasUsed: "1163301", confirmations: "3710784"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "1764"}, {type: "uint256", name: "_end_section_index", value: "1966"}, {type: "uint256", name: "_image_id", value: "5392"}, {type: "string", name: "_md5", value: `7bb3561dc815d1d2fb5dd9a6af6fa791`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "1764", "1966", "5392", `7bb3561dc815d1d2fb5dd9a6af6fa791`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1499062416 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "1764"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1864"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1964"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1765"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1865"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1965"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1766"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1866"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1966"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "1764"}, {name: "end_section_index", type: "uint256", value: "1966"}, {name: "area_price", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"52\", \"52\", \"5326\", `3ac1f303ee65f... )", async function( ) {
		const txOriginal = {blockNumber: "3966503", timeStamp: "1499062416", hash: "0x200730e8ddba554a0c893c46f8c41c72664064893e87d6fbef53c44aa02f8520", nonce: "1", blockHash: "0x0200bb1698be5539cc841dd6d082d5f72c245d2ee94ae944f1b147888da32cc8", transactionIndex: "42", from: "0xa6e927157c5b4ceda91e7444d325c50a38ef6d38", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000014ce000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203361633166333033656536356661616339343364636531383061323736336230", contractAddress: "", cumulativeGasUsed: "3115076", gasUsed: "161629", confirmations: "3710784"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "52"}, {type: "uint256", name: "_end_section_index", value: "52"}, {type: "uint256", name: "_image_id", value: "5326"}, {type: "string", name: "_md5", value: `3ac1f303ee65faac943dce180a2763b0`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "52", "52", "5326", `3ac1f303ee65faac943dce180a2763b0`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1499062416 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "52"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "52"}, {name: "end_section_index", type: "uint256", value: "52"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"49\", \"49\", \"5335\", `de564b1ef2eb6... )", async function( ) {
		const txOriginal = {blockNumber: "3966507", timeStamp: "1499062452", hash: "0x5fb9489028c23ecbce82fd96fa6f0cc37d2e2b4b2ca448144c43fc0d6b418b85", nonce: "2", blockHash: "0x26795a8afffb56100d081a30f9ea85868f40f73eaf3223f83605d32da396f3ee", transactionIndex: "44", from: "0xa6e927157c5b4ceda91e7444d325c50a38ef6d38", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000031000000000000000000000000000000000000000000000000000000000000003100000000000000000000000000000000000000000000000000000000000014d7000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206465353634623165663265623637376132343262323537333364643364393865", contractAddress: "", cumulativeGasUsed: "2088012", gasUsed: "161629", confirmations: "3710780"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "49"}, {type: "uint256", name: "_end_section_index", value: "49"}, {type: "uint256", name: "_image_id", value: "5335"}, {type: "string", name: "_md5", value: `de564b1ef2eb677a242b25733dd3d98e`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "49", "49", "5335", `de564b1ef2eb677a242b25733dd3d98e`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1499062452 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "49"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "49"}, {name: "end_section_index", type: "uint256", value: "49"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"149\", \"351\", \"5363\", `8f4dc10ac40... )", async function( ) {
		const txOriginal = {blockNumber: "3966507", timeStamp: "1499062452", hash: "0x62cedcae305088951ddbd75010588485de9e1a8fe8f6c905202bf44a273d505e", nonce: "3", blockHash: "0x26795a8afffb56100d081a30f9ea85868f40f73eaf3223f83605d32da396f3ee", transactionIndex: "50", from: "0xa6e927157c5b4ceda91e7444d325c50a38ef6d38", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "90000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000095000000000000000000000000000000000000000000000000000000000000015f00000000000000000000000000000000000000000000000000000000000014f3000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203866346463313061633430306235333734616566383238353061613863376531", contractAddress: "", cumulativeGasUsed: "3356249", gasUsed: "1163237", confirmations: "3710780"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "149"}, {type: "uint256", name: "_end_section_index", value: "351"}, {type: "uint256", name: "_image_id", value: "5363"}, {type: "string", name: "_md5", value: `8f4dc10ac400b5374aef82850aa8c7e1`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "149", "351", "5363", `8f4dc10ac400b5374aef82850aa8c7e1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1499062452 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "149"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "249"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "349"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "150"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "250"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "350"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "151"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "251"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "351"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "149"}, {name: "end_section_index", type: "uint256", value: "351"}, {name: "area_price", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"838\", \"838\", \"5423\", `8c64c951d10... )", async function( ) {
		const txOriginal = {blockNumber: "3966535", timeStamp: "1499062781", hash: "0x30a2f751ffcc6011c1655a045686d00d5c999353cdb1292ae8808accf49cec1d", nonce: "0", blockHash: "0xb9d056710b7d013d4f87846a358c7a02983cd5cebccc946454530fa27546429a", transactionIndex: "28", from: "0x42f1ed2211a3e963d2e8f640823b2ace9b28126b", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000003460000000000000000000000000000000000000000000000000000000000000346000000000000000000000000000000000000000000000000000000000000152f000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203863363463393531643130383034336561346533336635326562346336393563", contractAddress: "", cumulativeGasUsed: "4569923", gasUsed: "176757", confirmations: "3710752"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "838"}, {type: "uint256", name: "_end_section_index", value: "838"}, {type: "uint256", name: "_image_id", value: "5423"}, {type: "string", name: "_md5", value: `8c64c951d108043ea4e33f52eb4c695c`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "838", "838", "5423", `8c64c951d108043ea4e33f52eb4c695c`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1499062781 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "838"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "838"}, {name: "end_section_index", type: "uint256", value: "838"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"50\", \"50\", \"5419\", `aab9d6cbbc708... )", async function( ) {
		const txOriginal = {blockNumber: "3966536", timeStamp: "1499062789", hash: "0x364771748250308cba1315c5d49d23953259e42104758d136197503a01e11341", nonce: "4", blockHash: "0x92bdd795bf97fd2b53942961cca7f15b5c475306476304b5e65fb52ba943a319", transactionIndex: "18", from: "0xa6e927157c5b4ceda91e7444d325c50a38ef6d38", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000152b000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206161623964366362626337303863323964343161366133623961613234313434", contractAddress: "", cumulativeGasUsed: "886146", gasUsed: "161629", confirmations: "3710751"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "50"}, {type: "uint256", name: "_end_section_index", value: "50"}, {type: "uint256", name: "_image_id", value: "5419"}, {type: "string", name: "_md5", value: `aab9d6cbbc708c29d41a6a3b9aa24144`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "50", "50", "5419", `aab9d6cbbc708c29d41a6a3b9aa24144`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1499062789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "50"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "50"}, {name: "end_section_index", type: "uint256", value: "50"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"839\", \"839\", \"5441\", `baae5e08616... )", async function( ) {
		const txOriginal = {blockNumber: "3966562", timeStamp: "1499063066", hash: "0x6866f45956206498615afaa8c1b3e37901d175a9c057af7e76176d7110e127a3", nonce: "1", blockHash: "0x17ad5c08c306b2b6b9d1c44dd500b98613b31d206435b04e564b73a7ef0a3620", transactionIndex: "69", from: "0x42f1ed2211a3e963d2e8f640823b2ace9b28126b", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000034700000000000000000000000000000000000000000000000000000000000003470000000000000000000000000000000000000000000000000000000000001541000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206261616535653038363136316366613731366664353733393537383062363262", contractAddress: "", cumulativeGasUsed: "3189150", gasUsed: "161757", confirmations: "3710725"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "839"}, {type: "uint256", name: "_end_section_index", value: "839"}, {type: "uint256", name: "_image_id", value: "5441"}, {type: "string", name: "_md5", value: `baae5e086161cfa716fd57395780b62b`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "839", "839", "5441", `baae5e086161cfa716fd57395780b62b`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1499063066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "839"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "839"}, {name: "end_section_index", type: "uint256", value: "839"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"4349\", \"4551\", \"5431\", `b915b4136... )", async function( ) {
		const txOriginal = {blockNumber: "3966562", timeStamp: "1499063066", hash: "0xce70530a3e1652c6ea50c11b4fb3a26a9407bd1a82a0e603b14a7a9344eb50c2", nonce: "1", blockHash: "0x17ad5c08c306b2b6b9d1c44dd500b98613b31d206435b04e564b73a7ef0a3620", transactionIndex: "72", from: "0x0c7fa85d2975c442fc4e58c39539ded4ae4c6219", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "90000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000010fd00000000000000000000000000000000000000000000000000000000000011c70000000000000000000000000000000000000000000000000000000000001537000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206239313562343133366633383965623938363464623837303562376234306261", contractAddress: "", cumulativeGasUsed: "4394451", gasUsed: "1163301", confirmations: "3710725"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "4349"}, {type: "uint256", name: "_end_section_index", value: "4551"}, {type: "uint256", name: "_image_id", value: "5431"}, {type: "string", name: "_md5", value: `b915b4136f389eb9864db8705b7b40ba`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "4349", "4551", "5431", `b915b4136f389eb9864db8705b7b40ba`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1499063066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "4349"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4449"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4549"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4350"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4450"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4550"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4351"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4451"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4551"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "4349"}, {name: "end_section_index", type: "uint256", value: "4551"}, {name: "area_price", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1752961000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"4352\", \"4554\", \"5468\", `2802ece3c... )", async function( ) {
		const txOriginal = {blockNumber: "3966586", timeStamp: "1499063365", hash: "0xac898a91ab6b277ab9d9d58232fac9ce5d09da2bbdb827ef7dd0e4ac7f4cc11d", nonce: "3", blockHash: "0x907e8e9c6cb508625247bb2ed6a1b645a8b85f5a1e5e2edbec91d0e7a85a9584", transactionIndex: "7", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "90000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000011ca000000000000000000000000000000000000000000000000000000000000155c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203238303265636533636263363134373730383665656533646133616333643535", contractAddress: "", cumulativeGasUsed: "1581761", gasUsed: "1163237", confirmations: "3710701"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "4352"}, {type: "uint256", name: "_end_section_index", value: "4554"}, {type: "uint256", name: "_image_id", value: "5468"}, {type: "string", name: "_md5", value: `2802ece3cbc61477086eee3da3ac3d55`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "4352", "4554", "5468", `2802ece3cbc61477086eee3da3ac3d55`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1499063365 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "4352"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4452"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4552"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4353"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4453"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4553"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4354"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4454"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "4554"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "4352"}, {name: "end_section_index", type: "uint256", value: "4554"}, {name: "area_price", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"2851\", \"2851\", \"5539\", `957477266... )", async function( ) {
		const txOriginal = {blockNumber: "3966611", timeStamp: "1499063750", hash: "0x111fa13d54e6887d62310da1e65d1854a0807808f69300c9c5e499f6092292e8", nonce: "7", blockHash: "0xf0dca4558fe47278fb495faebba41d0a6e019b3fc0c80d96dc35c620e02dc5e6", transactionIndex: "18", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000b230000000000000000000000000000000000000000000000000000000000000b2300000000000000000000000000000000000000000000000000000000000015a3000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203935373437373236366431653637373066323036373632636539333332363433", contractAddress: "", cumulativeGasUsed: "834785", gasUsed: "161757", confirmations: "3710676"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "2851"}, {type: "uint256", name: "_end_section_index", value: "2851"}, {type: "uint256", name: "_image_id", value: "5539"}, {type: "string", name: "_md5", value: `957477266d1e6770f206762ce9332643`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "2851", "2851", "5539", `957477266d1e6770f206762ce9332643`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1499063750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "2851"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "2851"}, {name: "end_section_index", type: "uint256", value: "2851"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"3749\", \"3951\", \"5550\", `aa069f24e... )", async function( ) {
		const txOriginal = {blockNumber: "3966611", timeStamp: "1499063750", hash: "0x7825667e031da3c60900c0b4ca498f424bf7a255d687b6c5e60d4b97d131e3a9", nonce: "2", blockHash: "0xf0dca4558fe47278fb495faebba41d0a6e019b3fc0c80d96dc35c620e02dc5e6", transactionIndex: "19", from: "0x0c7fa85d2975c442fc4e58c39539ded4ae4c6219", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "90000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000ea50000000000000000000000000000000000000000000000000000000000000f6f00000000000000000000000000000000000000000000000000000000000015ae000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206161303639663234653566616538666363306433356433366533656161313937", contractAddress: "", cumulativeGasUsed: "1998086", gasUsed: "1163301", confirmations: "3710676"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "3749"}, {type: "uint256", name: "_end_section_index", value: "3951"}, {type: "uint256", name: "_image_id", value: "5550"}, {type: "string", name: "_md5", value: `aa069f24e5fae8fcc0d35d36e3eaa197`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "3749", "3951", "5550", `aa069f24e5fae8fcc0d35d36e3eaa197`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1499063750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "3749"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3849"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3949"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3750"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3850"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3950"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3751"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3851"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "3951"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "3749"}, {name: "end_section_index", type: "uint256", value: "3951"}, {name: "area_price", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "90000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1752961000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"47\", \"548\", \"5497\", `fe7468fb03e9... )", async function( ) {
		const txOriginal = {blockNumber: "3966613", timeStamp: "1499063764", hash: "0xb72d4764bed43a55ee5075a9899cdb15546f9085601e01b7bdb410014a6e17fc", nonce: "5", blockHash: "0xc23366eda1abca8c6a5e57eaf6fa496abad6c4d658f99a20c85850497f5a57be", transactionIndex: "18", from: "0xa6e927157c5b4ceda91e7444d325c50a38ef6d38", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "120000000000000000", gas: "4184439", gasPrice: "3000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000002f00000000000000000000000000000000000000000000000000000000000002240000000000000000000000000000000000000000000000000000000000001579000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206665373436386662303365393136646364326463613965333465626330346464", contractAddress: "", cumulativeGasUsed: "2809176", gasUsed: "1538862", confirmations: "3710674"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "47"}, {type: "uint256", name: "_end_section_index", value: "548"}, {type: "uint256", name: "_image_id", value: "5497"}, {type: "string", name: "_md5", value: `fe7468fb03e916dcd2dca9e34ebc04dd`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "47", "548", "5497", `fe7468fb03e916dcd2dca9e34ebc04dd`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1499063764 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "47"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "147"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "247"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "347"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "447"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "547"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "48"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "148"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "248"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "348"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "448"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "548"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "47"}, {name: "end_section_index", type: "uint256", value: "548"}, {name: "area_price", type: "uint256", value: "120000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "120000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"2148\", \"2148\", \"5560\", `957477266... )", async function( ) {
		const txOriginal = {blockNumber: "3966617", timeStamp: "1499063856", hash: "0x20939d6a906f3c7eba78ceca18656599dd54dae55cc22099c4a5aa356f6be702", nonce: "8", blockHash: "0x73b81a6a93fee0203b3cafa0693ab122fe53e1563bd4d00ce2c5dc9370c6e251", transactionIndex: "118", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000864000000000000000000000000000000000000000000000000000000000000086400000000000000000000000000000000000000000000000000000000000015b8000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203935373437373236366431653637373066323036373632636539333332363433", contractAddress: "", cumulativeGasUsed: "3833891", gasUsed: "161757", confirmations: "3710670"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "2148"}, {type: "uint256", name: "_end_section_index", value: "2148"}, {type: "uint256", name: "_image_id", value: "5560"}, {type: "string", name: "_md5", value: `957477266d1e6770f206762ce9332643`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "2148", "2148", "5560", `957477266d1e6770f206762ce9332643`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1499063856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "2148"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "2148"}, {name: "end_section_index", type: "uint256", value: "2148"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"2852\", \"2855\", \"5596\", `f31ac88a0... )", async function( ) {
		const txOriginal = {blockNumber: "3966638", timeStamp: "1499064138", hash: "0x668f2e8888bec63f0a6a2d54bb9ec220c4386c8298984cb786fed57fe91cb36d", nonce: "9", blockHash: "0xc6dfcd1a00c67d4f4af396a062a563aff9c8576c04a94ff481233fec344b1bc4", transactionIndex: "39", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "40000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000b240000000000000000000000000000000000000000000000000000000000000b2700000000000000000000000000000000000000000000000000000000000015dc000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206633316163383861306561643136623163323033356335303639616436356232", contractAddress: "", cumulativeGasUsed: "2399791", gasUsed: "537474", confirmations: "3710649"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "2852"}, {type: "uint256", name: "_end_section_index", value: "2855"}, {type: "uint256", name: "_image_id", value: "5596"}, {type: "string", name: "_md5", value: `f31ac88a0ead16b1c2035c5069ad65b2`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "2852", "2855", "5596", `f31ac88a0ead16b1c2035c5069ad65b2`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1499064138 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "2852"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "2853"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "2854"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "2855"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "2852"}, {name: "end_section_index", type: "uint256", value: "2855"}, {name: "area_price", type: "uint256", value: "40000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "40000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionImageDataCloud( \"2851\", \"2855\", \"5613\", `aa8e2cf5f... )", async function( ) {
		const txOriginal = {blockNumber: "3966648", timeStamp: "1499064294", hash: "0xb52070729de07d37f8e45b827a7ac7441bcbdd31a318e84306f704ad252dcc83", nonce: "10", blockHash: "0x8c6c2537d7dc917024320b368d3276d18ea0ea83e54aa96a4661988248f93173", transactionIndex: "35", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xc84a87660000000000000000000000000000000000000000000000000000000000000b230000000000000000000000000000000000000000000000000000000000000b2700000000000000000000000000000000000000000000000000000000000015ed000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206161386532636635663739633230326261326637386235333533333037393739", contractAddress: "", cumulativeGasUsed: "2061932", gasUsed: "109500", confirmations: "3710639"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "2851"}, {type: "uint256", name: "_end_section_index", value: "2855"}, {type: "uint256", name: "_image_id", value: "5613"}, {type: "string", name: "_md5", value: `aa8e2cf5f79c202ba2f78b5353307979`}], name: "setRegionImageDataCloud", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionImageDataCloud(uint256,uint256,uint256,string)" ]( "2851", "2855", "5613", `aa8e2cf5f79c202ba2f78b5353307979`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1499064294 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "NewImage", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewImage", events: [{name: "section_id", type: "uint256", value: "2851"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"9947\", \"9954\", \"5673\", `6dbb1c4c1... )", async function( ) {
		const txOriginal = {blockNumber: "3966671", timeStamp: "1499064590", hash: "0x896ec0ede5783271bc6fc45f063373a9d53917a42b5aaa9988533885c4ea1ce4", nonce: "4", blockHash: "0x4dd9f2fe2176dc322cdaf2328d85691550e86473c8684776bfb2b3198111e862", transactionIndex: "22", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "80000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000026db00000000000000000000000000000000000000000000000000000000000026e20000000000000000000000000000000000000000000000000000000000001629000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203664626231633463313330666561633235393935636330326462323534336637", contractAddress: "", cumulativeGasUsed: "4678521", gasUsed: "1038430", confirmations: "3710616"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "9947"}, {type: "uint256", name: "_end_section_index", value: "9954"}, {type: "uint256", name: "_image_id", value: "5673"}, {type: "string", name: "_md5", value: `6dbb1c4c130feac25995cc02db2543f7`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "9947", "9954", "5673", `6dbb1c4c130feac25995cc02db2543f7`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1499064590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "9947"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9948"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9949"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9950"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9951"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9952"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9953"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9954"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "9947"}, {name: "end_section_index", type: "uint256", value: "9954"}, {name: "area_price", type: "uint256", value: "80000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "80000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"773\", \"1175\", \"5688\", `db3771f9a4... )", async function( ) {
		const txOriginal = {blockNumber: "3966701", timeStamp: "1499065060", hash: "0xfaf7aeb5fd02878800cdef56f35b38cad3f71fb1e60c23250ac9bee4ba7a84db", nonce: "6", blockHash: "0x6f69f02ccb20ff0ea84f5acd717388863c82a2129b8e42bef1c84261ff6928e9", transactionIndex: "19", from: "0xa6e927157c5b4ceda91e7444d325c50a38ef6d38", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "150000000000000000", gas: "4184439", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000030500000000000000000000000000000000000000000000000000000000000004970000000000000000000000000000000000000000000000000000000000001638000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206462333737316639613439393839373564323161323135313630623237326366", contractAddress: "", cumulativeGasUsed: "2519924", gasUsed: "1914367", confirmations: "3710586"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "773"}, {type: "uint256", name: "_end_section_index", value: "1175"}, {type: "uint256", name: "_image_id", value: "5688"}, {type: "string", name: "_md5", value: `db3771f9a4998975d21a215160b272cf`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "773", "1175", "5688", `db3771f9a4998975d21a215160b272cf`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1499065060 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "773"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "873"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "973"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1073"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1173"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "774"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "874"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "974"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1074"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1174"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "775"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "875"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "975"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1075"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "1175"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "773"}, {name: "end_section_index", type: "uint256", value: "1175"}, {name: "area_price", type: "uint256", value: "150000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "150000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"325\", \"526\", \"5711\", `b0653d844a2... )", async function( ) {
		const txOriginal = {blockNumber: "3966707", timeStamp: "1499065247", hash: "0xd84c48bf466c996df60f02b923638c65900a8d50d3c3974cb4fd45ce6e893a5c", nonce: "1", blockHash: "0xa38a69fc78b76b17b686edc043eafeff7b24e584c1c18e2ba2553c6e69a4b94c", transactionIndex: "72", from: "0x9d15ee903f2064745acdf4605a342a9e71dc4f47", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "60000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000000145000000000000000000000000000000000000000000000000000000000000020e000000000000000000000000000000000000000000000000000000000000164f000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206230363533643834346132616139353337616437636339316333333133656162", contractAddress: "", cumulativeGasUsed: "4388634", gasUsed: "787768", confirmations: "3710580"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "325"}, {type: "uint256", name: "_end_section_index", value: "526"}, {type: "uint256", name: "_image_id", value: "5711"}, {type: "string", name: "_md5", value: `b0653d844a2aa9537ad7cc91c3313eab`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "325", "526", "5711", `b0653d844a2aa9537ad7cc91c3313eab`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1499065247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "325"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "425"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "525"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "326"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "426"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "526"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "325"}, {name: "end_section_index", type: "uint256", value: "526"}, {name: "area_price", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionForSale( \"2148\", \"2148\", \"10000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "3966749", timeStamp: "1499065862", hash: "0xff4026c7b2c02d4d6b3cefeb716a6cb1da235938216f7ad0166d00a5fe22bcd6", nonce: "11", blockHash: "0x07c657b18f51b7173548d130f6fa717cbd2706852797dcd6514d44f81a4455c9", transactionIndex: "21", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "973723", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6a7625ca00000000000000000000000000000000000000000000000000000000000008640000000000000000000000000000000000000000000000000000000000000864000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "967688", gasUsed: "55547", confirmations: "3710538"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "2148"}, {type: "uint256", name: "_end_section_index", value: "2148"}, {type: "uint256", name: "_price", value: "10000000000000000"}], name: "setRegionForSale", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionForSale(uint256,uint256,uint256)" ]( "2148", "2148", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1499065862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "NewListing", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewListing", events: [{name: "section_id", type: "uint256", value: "2148"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transferRegion( \"9954\", \"9954\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "3966767", timeStamp: "1499066186", hash: "0x21ba1ace7266620d609813aeb01423ff923d424b574f5dec671ea486f95e1e84", nonce: "5", blockHash: "0xc0a054b8b8ed3d75ff80a0f6d43d6cbfca54b9885309f750c9654164384fed03", transactionIndex: "66", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "583596", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x7c61d56700000000000000000000000000000000000000000000000000000000000026e200000000000000000000000000000000000000000000000000000000000026e2000000000000000000000000730b81aa9a98359e03c74254fa4817e0cab661f9", contractAddress: "", cumulativeGasUsed: "4069922", gasUsed: "46503", confirmations: "3710520"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "9954"}, {type: "uint256", name: "_end_section_index", value: "9954"}, {type: "address", name: "_to", value: addressList[5]}], name: "transferRegion", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferRegion(uint256,uint256,address)" ]( "9954", "9954", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1499066186 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"2148\", \"2148\", \"5787\", `6dbb1c4c1... )", async function( ) {
		const txOriginal = {blockNumber: "3966777", timeStamp: "1499066352", hash: "0xf038f5e7b0c2c188c6ae728c1b3a50425917f64ffc5b8af228ff1cea53020282", nonce: "6", blockHash: "0x0615c792d6917bb3cd3a45688d153332af017735e2a3470756047aafc99eb8ee", transactionIndex: "78", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000008640000000000000000000000000000000000000000000000000000000000000864000000000000000000000000000000000000000000000000000000000000169b000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203664626231633463313330666561633235393935636330326462323534336637", contractAddress: "", cumulativeGasUsed: "3387084", gasUsed: "109433", confirmations: "3710510"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "2148"}, {type: "uint256", name: "_end_section_index", value: "2148"}, {type: "uint256", name: "_image_id", value: "5787"}, {type: "string", name: "_md5", value: `6dbb1c4c130feac25995cc02db2543f7`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "2148", "2148", "5787", `6dbb1c4c130feac25995cc02db2543f7`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1499066352 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "2148"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "2148"}, {name: "end_section_index", type: "uint256", value: "2148"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "3966781", timeStamp: "1499066461", hash: "0x8307d12039dc55d7e2955ddb45e58b5a7c8d132f7ce056a13edb47ed3ac377c4", nonce: "12", blockHash: "0x9c7bfe127ddeb23a41c6b71dc2574c3e2f048a6a02191cf8a2e7ec3503b1683b", transactionIndex: "81", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "198266", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2897540", gasUsed: "21209", confirmations: "3710506"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1499066461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "msg", type: "string"}], name: "WithdrawEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawEvent", events: [{name: "msg", type: "string", value: "Reset Sender"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[34,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"27\", \"228\", \"5789\", `19b326405dad... )", async function( ) {
		const txOriginal = {blockNumber: "3966786", timeStamp: "1499066514", hash: "0x4c159c96ebc803dcf69c2b2721aa547c4279da0e98138f31df790ef5a61fcd7d", nonce: "2", blockHash: "0x3de7b11bd851ff7473718d504b8a7637f5926c12ac922f3158e5bcce6406e3ea", transactionIndex: "21", from: "0x9d15ee903f2064745acdf4605a342a9e71dc4f47", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "60000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000e4000000000000000000000000000000000000000000000000000000000000169d000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203139623332363430356461643863386331613166323133386461363732643038", contractAddress: "", cumulativeGasUsed: "2486622", gasUsed: "787640", confirmations: "3710501"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "27"}, {type: "uint256", name: "_end_section_index", value: "228"}, {type: "uint256", name: "_image_id", value: "5789"}, {type: "string", name: "_md5", value: `19b326405dad8c8c1a1f2138da672d08`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "27", "228", "5789", `19b326405dad8c8c1a1f2138da672d08`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1499066514 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "27"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "127"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "227"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "28"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "128"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "228"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "27"}, {name: "end_section_index", type: "uint256", value: "228"}, {name: "area_price", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionForSaleToAddress( \"9954\", \"9954\", \"10000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "3966806", timeStamp: "1499067006", hash: "0xfd98fccab1d80ec30fafee0c08ee5e8061cea925d49ceda1c2138197eecefe6c", nonce: "13", blockHash: "0x5f5f9da5f7c3a0a688ad525b1fae234da6c72dd31c176c522db3c5399706002a", transactionIndex: "20", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "973723", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x7e83027f00000000000000000000000000000000000000000000000000000000000026e200000000000000000000000000000000000000000000000000000000000026e2000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000079d0268b019610ab8d7f853fc2a06fd3cc440567", contractAddress: "", cumulativeGasUsed: "1677446", gasUsed: "72119", confirmations: "3710481"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "9954"}, {type: "uint256", name: "_end_section_index", value: "9954"}, {type: "uint256", name: "_price", value: "10000000000000000"}, {type: "address", name: "_only_sell_to", value: addressList[4]}], name: "setRegionForSaleToAddress", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionForSaleToAddress(uint256,uint256,uint256,address)" ]( "9954", "9954", "10000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1499067006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "NewListing", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewListing", events: [{name: "section_id", type: "uint256", value: "9954"}, {name: "price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"400\", \"502\", \"5942\", `34605e0f84e... )", async function( ) {
		const txOriginal = {blockNumber: "3966846", timeStamp: "1499067836", hash: "0x04b80cc52a548f674699319cf9057e383e43cce01edc5c522f60113b32ece370", nonce: "14", blockHash: "0xc4ca27ace3ecade701d2364da6fcde12ff4523a4da7bdda013500e013f1cbbca", transactionIndex: "58", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "60000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000001f60000000000000000000000000000000000000000000000000000000000001736000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203334363035653066383465373931373838393230396165313161396263323461", contractAddress: "", cumulativeGasUsed: "2903850", gasUsed: "787768", confirmations: "3710441"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "400"}, {type: "uint256", name: "_end_section_index", value: "502"}, {type: "uint256", name: "_image_id", value: "5942"}, {type: "string", name: "_md5", value: `34605e0f84e7917889209ae11a9bc24a`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "400", "502", "5942", `34605e0f84e7917889209ae11a9bc24a`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1499067836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "400"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "500"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "401"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "501"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "402"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "502"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "400"}, {name: "end_section_index", type: "uint256", value: "502"}, {name: "area_price", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"711\", \"918\", \"5926\", `f8b467dc4e3... )", async function( ) {
		const txOriginal = {blockNumber: "3966851", timeStamp: "1499067883", hash: "0xbb799b38493cbc282d3908b9b635c38f711e20f09c3fb0900e60fabce429eb7a", nonce: "0", blockHash: "0x7bbc550175b83d34254430e90c492601c687ab1cde8e9099e8e2bb9dc72db8e4", transactionIndex: "13", from: "0x721c89c5e11036cbe86bf7a2970da2461462e602", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "240000000000000000", gas: "6223750", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000002c700000000000000000000000000000000000000000000000000000000000003960000000000000000000000000000000000000000000000000000000000001726000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206638623436376463346533633663633165663732323030636337653539626631", contractAddress: "", cumulativeGasUsed: "3532568", gasUsed: "3055966", confirmations: "3710436"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "240000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "711"}, {type: "uint256", name: "_end_section_index", value: "918"}, {type: "uint256", name: "_image_id", value: "5926"}, {type: "string", name: "_md5", value: `f8b467dc4e3c6cc1ef72200cc7e59bf1`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "711", "918", "5926", `f8b467dc4e3c6cc1ef72200cc7e59bf1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1499067883 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "711"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "811"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "911"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "712"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "812"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "912"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "713"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "813"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "913"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "714"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "814"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "914"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "715"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "815"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "915"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "716"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "816"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "916"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "717"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "817"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "917"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "718"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "818"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "918"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "711"}, {name: "end_section_index", type: "uint256", value: "918"}, {name: "area_price", type: "uint256", value: "240000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "240000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "198014345000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"403\", \"505\", \"5963\", `34605e0f84e... )", async function( ) {
		const txOriginal = {blockNumber: "3966872", timeStamp: "1499068301", hash: "0x0ef9ee984c01f12f09d0ea62b31753b2c1b2ef355ecfc67717e089a56708a427", nonce: "15", blockHash: "0x7082082db9896fcb3a0634a3fc5ae0d9d197a8626ea7708fcc00a6d29f14377b", transactionIndex: "7", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "60000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000019300000000000000000000000000000000000000000000000000000000000001f9000000000000000000000000000000000000000000000000000000000000174b000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203334363035653066383465373931373838393230396165313161396263323461", contractAddress: "", cumulativeGasUsed: "1310071", gasUsed: "787768", confirmations: "3710415"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "403"}, {type: "uint256", name: "_end_section_index", value: "505"}, {type: "uint256", name: "_image_id", value: "5963"}, {type: "string", name: "_md5", value: `34605e0f84e7917889209ae11a9bc24a`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "403", "505", "5963", `34605e0f84e7917889209ae11a9bc24a`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1499068301 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "403"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "503"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "404"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "504"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "405"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "505"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "403"}, {name: "end_section_index", type: "uint256", value: "505"}, {name: "area_price", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionImageDataCloud( \"400\", \"505\", \"5990\", `422757ad243... )", async function( ) {
		const txOriginal = {blockNumber: "3966897", timeStamp: "1499068662", hash: "0xaa036cfde1e1dae0da6147c87befb494eb863490f1ef69853f349ec4d17c5d35", nonce: "16", blockHash: "0x021d6f56f59cf6317f4b95e1ca48c36de1aa45059232eb34b212222ef0391bfd", transactionIndex: "46", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "4184439", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xc84a8766000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000001f90000000000000000000000000000000000000000000000000000000000001766000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203432323735376164323433303865653937333234643963313363663363666438", contractAddress: "", cumulativeGasUsed: "2087867", gasUsed: "222208", confirmations: "3710390"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "400"}, {type: "uint256", name: "_end_section_index", value: "505"}, {type: "uint256", name: "_image_id", value: "5990"}, {type: "string", name: "_md5", value: `422757ad24308ee97324d9c13cf3cfd8`}], name: "setRegionImageDataCloud", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionImageDataCloud(uint256,uint256,uint256,string)" ]( "400", "505", "5990", `422757ad24308ee97324d9c13cf3cfd8`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1499068662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "NewImage", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewImage", events: [{name: "section_id", type: "uint256", value: "400"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: unsetRegionForSale( \"9954\", \"9954\" )", async function( ) {
		const txOriginal = {blockNumber: "3966946", timeStamp: "1499069510", hash: "0x3ec8de9b83bcd7f35db7de1cdeac69dc4e400ad076cdca05a749ce73c49e8f0b", nonce: "17", blockHash: "0xe8b16a415a07d49bc8c3558059f89caef795aa2c2b573f7026161bddaadd2f1e", transactionIndex: "69", from: "0x730b81aa9a98359e03c74254fa4817e0cab661f9", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "390648", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xc17ffac600000000000000000000000000000000000000000000000000000000000026e200000000000000000000000000000000000000000000000000000000000026e2", contractAddress: "", cumulativeGasUsed: "4475620", gasUsed: "19807", confirmations: "3710341"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "9954"}, {type: "uint256", name: "_end_section_index", value: "9954"}], name: "unsetRegionForSale", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unsetRegionForSale(uint256,uint256)" ]( "9954", "9954", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1499069510 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Delisted", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Delisted", events: [{name: "section_id", type: "uint256", value: "9954"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionForSale( \"715\", \"918\", \"2000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3966950", timeStamp: "1499069576", hash: "0x4d1857f79d3664f2f63060ee1ae3e75a25f28edb4a215c0bd3f237546cc6abc8", nonce: "1", blockHash: "0xd8d0337fe9136107ead29ea036693fba46c77ca4f66b0192ee0427d83ccd8bf3", transactionIndex: "79", from: "0x721c89c5e11036cbe86bf7a2970da2461462e602", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "1744646", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6a7625ca00000000000000000000000000000000000000000000000000000000000002cb000000000000000000000000000000000000000000000000000000000000039600000000000000000000000000000000000000000000000000071afd498d0000", contractAddress: "", cumulativeGasUsed: "4390504", gasUsed: "411424", confirmations: "3710337"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "715"}, {type: "uint256", name: "_end_section_index", value: "918"}, {type: "uint256", name: "_price", value: "2000000000000000"}], name: "setRegionForSale", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionForSale(uint256,uint256,uint256)" ]( "715", "918", "2000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1499069576 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "NewListing", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewListing", events: [{name: "section_id", type: "uint256", value: "715"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "815"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "915"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "716"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "816"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "916"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "717"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "817"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "917"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "718"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "818"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "918"}, {name: "price", type: "uint256", value: "2000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "198014345000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: unsetRegionForSale( \"715\", \"918\" )", async function( ) {
		const txOriginal = {blockNumber: "3966950", timeStamp: "1499069576", hash: "0x37e0567fb02953b1b6c75074b84bce3e3edd145843325bcd3875bb131010dbd1", nonce: "2", blockHash: "0xd8d0337fe9136107ead29ea036693fba46c77ca4f66b0192ee0427d83ccd8bf3", transactionIndex: "112", from: "0x721c89c5e11036cbe86bf7a2970da2461462e602", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "581412", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xc17ffac600000000000000000000000000000000000000000000000000000000000002cb0000000000000000000000000000000000000000000000000000000000000396", contractAddress: "", cumulativeGasUsed: "5991812", gasUsed: "82323", confirmations: "3710337"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "715"}, {type: "uint256", name: "_end_section_index", value: "918"}], name: "unsetRegionForSale", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unsetRegionForSale(uint256,uint256)" ]( "715", "918", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1499069576 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Delisted", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Delisted", events: [{name: "section_id", type: "uint256", value: "715"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "815"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "915"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "716"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "816"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "916"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "717"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "817"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "917"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "718"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "818"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Delisted", events: [{name: "section_id", type: "uint256", value: "918"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "198014345000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionForSale( \"715\", \"918\", \"1000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "3966954", timeStamp: "1499069664", hash: "0xea4adbb8a07454e95b31b2add5c1baffbf1d9376064783cb7f41ee9a643d65fb", nonce: "3", blockHash: "0x9d59712cf65937171a737c932b6a25626d07d4578f02403c8ccdd292cfaf7229", transactionIndex: "70", from: "0x721c89c5e11036cbe86bf7a2970da2461462e602", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "1744646", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x6a7625ca00000000000000000000000000000000000000000000000000000000000002cb00000000000000000000000000000000000000000000000000000000000003960000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "4996663", gasUsed: "411488", confirmations: "3710333"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "715"}, {type: "uint256", name: "_end_section_index", value: "918"}, {type: "uint256", name: "_price", value: "1000000000000000000"}], name: "setRegionForSale", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionForSale(uint256,uint256,uint256)" ]( "715", "918", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1499069664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "NewListing", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewListing", events: [{name: "section_id", type: "uint256", value: "715"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "815"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "915"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "716"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "816"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "916"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "717"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "817"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "917"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "718"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "818"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "NewListing", events: [{name: "section_id", type: "uint256", value: "918"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "198014345000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"327\", \"528\", \"6003\", `4473f395e62... )", async function( ) {
		const txOriginal = {blockNumber: "3966957", timeStamp: "1499069737", hash: "0x5931ff08f91178c484651b9037b3a1c162e69e85cd4526be4b30060b3f0fcb53", nonce: "3", blockHash: "0xfff4fa45fa7c02566433ff99fd4fe37a42398acf45177ce7a1dd04e6e464ba34", transactionIndex: "75", from: "0x9d15ee903f2064745acdf4605a342a9e71dc4f47", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "60000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed78000000000000000000000000000000000000000000000000000000000000014700000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000000000000000001773000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203434373366333935653632346230616238646461346139646363386565633634", contractAddress: "", cumulativeGasUsed: "4123464", gasUsed: "787768", confirmations: "3710330"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "327"}, {type: "uint256", name: "_end_section_index", value: "528"}, {type: "uint256", name: "_image_id", value: "6003"}, {type: "string", name: "_md5", value: `4473f395e624b0ab8dda4a9dcc8eec64`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "327", "528", "6003", `4473f395e624b0ab8dda4a9dcc8eec64`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1499069737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "327"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "427"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "527"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "328"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "428"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "528"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "327"}, {name: "end_section_index", type: "uint256", value: "528"}, {name: "area_price", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "60000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionImageDataCloud( \"0\", \"305\", \"6041\", `fd685a2ee746b... )", async function( ) {
		const txOriginal = {blockNumber: "3967024", timeStamp: "1499070952", hash: "0x45a80048067de0b7de287ec9e025c37d2952afa909baa10003bfb3d61e3ad61b", nonce: "7", blockHash: "0x2924af0c74581953a3b4ec7bd3d88216ebf2d7343c37894db44c1a8cf3d4491f", transactionIndex: "16", from: "0x79d0268b019610ab8d7f853fc2a06fd3cc440567", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "6223750", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xc84a8766000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001310000000000000000000000000000000000000000000000000000000000001799000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206664363835613265653734366265363866343832343562386435353339306539", contractAddress: "", cumulativeGasUsed: "856341", gasUsed: "415320", confirmations: "3710263"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "0"}, {type: "uint256", name: "_end_section_index", value: "305"}, {type: "uint256", name: "_image_id", value: "6041"}, {type: "string", name: "_md5", value: `fd685a2ee746be68f48245b8d55390e9`}], name: "setRegionImageDataCloud", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionImageDataCloud(uint256,uint256,uint256,string)" ]( "0", "305", "6041", `fd685a2ee746be68f48245b8d55390e9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1499070952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "NewImage", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewImage", events: [{name: "section_id", type: "uint256", value: "0"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "297720000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"6969\", \"6969\", \"6070\", `621dc2467... )", async function( ) {
		const txOriginal = {blockNumber: "3968838", timeStamp: "1499101987", hash: "0xe05648839b20a843fec6e31bd812f5d6db02583ac6f0042b74afa2318e4a3eda", nonce: "87", blockHash: "0x7f2becfe527fd8b001a842152e143ce515ed19606fa1d71cd88b37086e68c3fb", transactionIndex: "37", from: "0x0bf913bedf5c6aca673db3b697a4e543550ceb4d", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "10000000000000000", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed780000000000000000000000000000000000000000000000000000000000001b390000000000000000000000000000000000000000000000000000000000001b3900000000000000000000000000000000000000000000000000000000000017b6000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000203632316463323436373233333737653434376431613832616539303039336261", contractAddress: "", cumulativeGasUsed: "2389225", gasUsed: "176757", confirmations: "3708449"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "6969"}, {type: "uint256", name: "_end_section_index", value: "6969"}, {type: "uint256", name: "_image_id", value: "6070"}, {type: "string", name: "_md5", value: `621dc246723377e447d1a82ae90093ba`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "6969", "6969", "6070", `621dc246723377e447d1a82ae90093ba`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1499101987 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "6969"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "6969"}, {name: "end_section_index", type: "uint256", value: "6969"}, {name: "area_price", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "10000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "305211347401422111" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyRegion( \"9696\", \"9999\", \"6204\", `c4a842545... )", async function( ) {
		const txOriginal = {blockNumber: "3968904", timeStamp: "1499103389", hash: "0x37c4ba40aaf11b6bafaf4bbeaa81602bac17a053c8d2e1bdfaaf7cbc1b5286d1", nonce: "88", blockHash: "0x0d226600db40d0c511e4bd361316e27644750790fe6695ecfa6cef67b1b4bbd9", transactionIndex: "63", from: "0x0bf913bedf5c6aca673db3b697a4e543550ceb4d", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "160000000000000000", gas: "4184439", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5ebfed7800000000000000000000000000000000000000000000000000000000000025e0000000000000000000000000000000000000000000000000000000000000270f000000000000000000000000000000000000000000000000000000000000183c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206334613834323534353763326638636438313032623339616131383837393232", contractAddress: "", cumulativeGasUsed: "4219185", gasUsed: "2039514", confirmations: "3708383"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "160000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "9696"}, {type: "uint256", name: "_end_section_index", value: "9999"}, {type: "uint256", name: "_image_id", value: "6204"}, {type: "string", name: "_md5", value: `c4a8425457c2f8cd8102b39aa1887922`}], name: "buyRegion", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyRegion(uint256,uint256,uint256,string)" ]( "9696", "9999", "6204", `c4a8425457c2f8cd8102b39aa1887922`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1499103389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "Buy", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Buy", events: [{name: "section_id", type: "uint256", value: "9696"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9796"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9896"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9996"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9697"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9797"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9897"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9997"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9698"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9798"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9898"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9998"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9699"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9799"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9899"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}, {name: "Buy", events: [{name: "section_id", type: "uint256", value: "9999"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "start_section_index", type: "uint256"}, {indexed: false, name: "end_section_index", type: "uint256"}, {indexed: false, name: "area_price", type: "uint256"}], name: "AreaPrice", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AreaPrice", events: [{name: "start_section_index", type: "uint256", value: "9696"}, {name: "end_section_index", type: "uint256", value: "9999"}, {name: "area_price", type: "uint256", value: "160000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}], name: "SentValue", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SentValue", events: [{name: "value", type: "uint256", value: "160000000000000000"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "305211347401422111" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setRegionImageDataCloud( \"6969\", \"6969\", \"6221\", `c61b92a5f... )", async function( ) {
		const txOriginal = {blockNumber: "3968954", timeStamp: "1499104228", hash: "0x8b73955ac46fa15b76be2944028804c652eda42b2c9176f1ae92d7734c238246", nonce: "89", blockHash: "0x207288102a4e04098d2106c69dce9f9ac43bef5c62298bf104e92713212b612d", transactionIndex: "18", from: "0x0bf913bedf5c6aca673db3b697a4e543550ceb4d", to: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8", value: "0", gas: "2239502", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xc84a87660000000000000000000000000000000000000000000000000000000000001b390000000000000000000000000000000000000000000000000000000000001b39000000000000000000000000000000000000000000000000000000000000184d000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000206336316239326135663130383932343130666662336535643235386564396139", contractAddress: "", cumulativeGasUsed: "743295", gasUsed: "45148", confirmations: "3708333"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_start_section_index", value: "6969"}, {type: "uint256", name: "_end_section_index", value: "6969"}, {type: "uint256", name: "_image_id", value: "6221"}, {type: "string", name: "_md5", value: `c61b92a5f10892410ffb3e5d258ed9a9`}], name: "setRegionImageDataCloud", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRegionImageDataCloud(uint256,uint256,uint256,string)" ]( "6969", "6969", "6221", `c61b92a5f10892410ffb3e5d258ed9a9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1499104228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "section_id", type: "uint256"}], name: "NewImage", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewImage", events: [{name: "section_id", type: "uint256", value: "6969"}], address: "0x92bcbc2240d581a3fac5911cb4d807e7a79590d8"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "305211347401422111" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "114123000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
