const PacioICO = artifacts.require( "./PacioICO.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PacioICO" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x2b94E0c6cCB25ccF6B2DfA1A286712eb565437Ee", "0xb612126318cF820b5220bD287567FD2DEA8D604B", "0x18dfd8c468ed83397C0E1caDAe01E1e65E86d275", "0xFc8692E9B6f8dfE3Ba764545404abA5F266a4191", "0x2181eCc71f13018Befb9A556079379faA6937702", "0x7A02C3aD8158FF57968049dEf5630e2c2081a32A", "0x9c72833f60bcf02203D8C117E854D88b7369887C", "0xe778822c34398fD940f781aC40Df6D90298E0574", "0x95Ff52084Fe5b9A9a28c322aF847546092fbA3D1", "0x17BbA6a0F55bb41B809ad935a86E7e08bb5881A1", "0x7BCc11Ecc419fBBA0cC5EBB9Dc15B1f5BBc97558", "0xdB7305465Ab5fa3197717573beB26b64ac6f36DD", "0x35D12069493acFd577d14589A7df60207fF8B2a0", "0x86751D220019258756ec48E42d552Ed248237b07", "0xdAdF18C232489eF479F2f9E6f72F64a47e90a256", "0xF27E3DcB929b29aA4d3D2fd9141de0582198b41f", "0x00a9b4F4c3a0D4D1a4D9Db720dc9a0E5b91b5E29", "0x352c120A675aB6D887E2dbDA2ff8EE67f56361A9", "0x4D22d4Bbc8CAFAc903E50b53002CDC8ca6979acA", "0x53Ee4B7D14bfB44C14653d2f73fDfE3958BB72D0", "0x9fF3Aed9524D14774325D91bE2B62DeB4A1f6596"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "picosCap", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "picosPerEther", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "picosSold", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "PIOE", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "ownerA", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "pausedB", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "Name", type: "string"}, {indexed: false, name: "StartTime", type: "uint256"}, {indexed: false, name: "PicosCap", type: "uint256"}, {indexed: false, name: "TokenContract", type: "address"}, {indexed: false, name: "PCwallet", type: "address"}], name: "LogPrepareToStart", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "PCwallet", type: "address"}], name: "LogChangePCWallet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "WeiRaised", type: "uint256"}, {indexed: false, name: "PicosSold", type: "uint256"}], name: "LogSaleCapReached", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "PreviousOwner", type: "address"}, {indexed: false, name: "NewOwner", type: "address"}], name: "LogOwnerChange", type: "event"}, {anonymous: false, inputs: [], name: "LogPaused", type: "event"}, {anonymous: false, inputs: [], name: "LogResumed", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogPrepareToStart(string,uint256,uint256,address,address)", "LogSetPicosPerEther(uint256)", "LogChangePCWallet(address)", "LogSale(address,uint256,uint256)", "LogAllocate(address,uint256,uint256)", "LogSaleCapReached(uint256,uint256)", "LogOwnerChange(address,address)", "LogPaused()", "LogResumed()"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc786ebd11b2406255fcfe71e3e273badb0ae7d04503d6e82292d9d694db4f9a2", "0xd569872690f8e19f85bda6e2bb78cd35af51847647e5a2802fbd3755e379c242", "0xd880b0b069f3550b55071ab7b7ed69f11f96fd8dcaa3b80c2c28fef12784c3d1", "0x2efeb4e599a9cdc7e84fb52b9742e512906588521242c14e461a209ed79cedc8", "0x142e0bdf77d904b23c4615b290dc39f47eef278d765a0482965765f9fa06ab4c", "0x21eeb9a71f05a2345050db17a83d1ba79faee5ac3ad613cd51321e2683217cf0", "0xe516f4dd5cedc9fa569ffc0fe731ed5801fb5ff4a1860847fe1c7db3c590c551", "0x777ecb744cfc69794c3985ebff0496449aafc907c556f1d4003201beb364e80f", "0x7f4d6aa4949e2b9a4b6f2e8d032e8e289b4ce5fe924db2d9e18e92d2edb955c5"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4412496 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 5653907 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "PacioICO", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "picosCap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "picosCap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "picosPerEther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "picosPerEther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "picosSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "picosSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PIOE", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PIOE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ownerA", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerA()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pausedB", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pausedB()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PacioICO", function( accounts ) {

	it( "TEST: PacioICO(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4412496", timeStamp: "1508735304", hash: "0x8eca8d995fa5e97931b4eeeb71f87ecdd8f53b59bda5d1b8150decf1c21bca06", nonce: "6", blockHash: "0x1d5fd579068fbc841a645c4f5154c6a228ae27ae520609664ed134056fc3bf17", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: 0, value: "0", gas: "4712388", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0x0d81558d", contractAddress: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", cumulativeGasUsed: "1411815", gasUsed: "1411815", confirmations: "3310587"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "PacioICO", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PacioICO.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508735304 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PacioICO.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: PrepareToStart( `Pacio Presale`, \"1508749200\", \"20000... )", async function( ) {
		const txOriginal = {blockNumber: "4412728", timeStamp: "1508738674", hash: "0x6d0b410f057d34e18c76923c55c3c77e9ef4f2a2c531d0829ecb11d8bb005357", nonce: "9", blockHash: "0x432204088a0f26e4e458d94b121ffce11e53fc4de9e095c2fdb74a05d7acbb89", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "200000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0x6897c1b600000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000059edaf90000000000000000000000000000000000000000000000001158e460913d00000000000000000000000000000000000000000000000000000000a4d88ddd9400000000000000000000000000018dfd8c468ed83397c0e1cadae01e1e65e86d275000000000000000000000000fc8692e9b6f8dfe3ba764545404aba5f266a4191000000000000000000000000000000000000000000000000000000000000000d506163696f2050726573616c6500000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "181494", gasUsed: "181494", confirmations: "3310355"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "vNameS", value: `Pacio Presale`}, {type: "uint256", name: "vStartTime", value: "1508749200"}, {type: "uint256", name: "vPicosCap", value: "20000000000000000000"}, {type: "uint256", name: "vPicosPerEther", value: "2900000000000000"}, {type: "address", name: "vTokenA", value: addressList[4]}, {type: "address", name: "vPCwalletA", value: addressList[5]}], name: "PrepareToStart", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "PrepareToStart(string,uint256,uint256,uint256,address,address)" ]( `Pacio Presale`, "1508749200", "20000000000000000000", "2900000000000000", addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508738674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Name", type: "string"}, {indexed: false, name: "StartTime", type: "uint256"}, {indexed: false, name: "PicosCap", type: "uint256"}, {indexed: false, name: "TokenContract", type: "address"}, {indexed: false, name: "PCwallet", type: "address"}], name: "LogPrepareToStart", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPrepareToStart", events: [{name: "Name", type: "string", value: "Pacio Presale"}, {name: "StartTime", type: "uint256", value: "1508749200"}, {name: "PicosCap", type: "uint256", value: "20000000000000000000"}, {name: "TokenContract", type: "address", value: "0x18dfd8c468ed83397c0e1cadae01e1e65e86d275"}, {name: "PCwallet", type: "address", value: "0xfc8692e9b6f8dfe3ba764545404aba5f266a4191"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "2900000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4413539", timeStamp: "1508749384", hash: "0xe147cc5c88aa0178414d70c779c1d57a1be9c2fdc702c3f1011ac9814e8e2785", nonce: "0", blockHash: "0x33f2426ac98f9ec272a137fa17b913797d3f5f874c61990fe69f5c8212eb5313", transactionIndex: "36", from: "0x2181ecc71f13018befb9a556079379faa6937702", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "500000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1419885", gasUsed: "151775", confirmations: "3309544"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508749384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x2181ecc71f13018befb9a556079379faa6937702"}, {name: "SaleWei", type: "uint256", value: "500000000000000000"}, {name: "Picos", type: "uint256", value: "1450000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "95571247000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4413539", timeStamp: "1508749384", hash: "0xcf212081e00098715f28e991929c5cad3c99b45a2dea2d22d221f61c057c5305", nonce: "2", blockHash: "0x33f2426ac98f9ec272a137fa17b913797d3f5f874c61990fe69f5c8212eb5313", transactionIndex: "42", from: "0x7a02c3ad8158ff57968049def5630e2c2081a32a", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "880000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1723130", gasUsed: "91775", confirmations: "3309544"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "880000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508749384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x7a02c3ad8158ff57968049def5630e2c2081a32a"}, {name: "SaleWei", type: "uint256", value: "880000000000000000"}, {name: "Picos", type: "uint256", value: "2552000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "32068498000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4413561", timeStamp: "1508749771", hash: "0xc669fa8d6a817b34bcf27637953f0ab4d8a2a795ebb03aedae49194555f822bd", nonce: "0", blockHash: "0xfe5387963feb31b478fd3c7b1edfee6646368357cb9739b586a6f38a6beb455f", transactionIndex: "27", from: "0x9c72833f60bcf02203d8c117e854d88b7369887c", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "610000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1402041", gasUsed: "91775", confirmations: "3309522"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "610000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508749771 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x9c72833f60bcf02203d8c117e854d88b7369887c"}, {name: "SaleWei", type: "uint256", value: "610000000000000000"}, {name: "Picos", type: "uint256", value: "1769000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "11450051000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4413588", timeStamp: "1508750047", hash: "0x5fd02d5fdfece75807f8241c91674f813f6429d92a53f77efa5ef5aa3c14854d", nonce: "0", blockHash: "0x85665a93b76049298839489648b27438ff58f321336143e09e717e841db2dc4d", transactionIndex: "60", from: "0xe778822c34398fd940f781ac40df6d90298e0574", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "8000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1682828", gasUsed: "91775", confirmations: "3309495"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "8000000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508750047 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0xe778822c34398fd940f781ac40df6d90298e0574"}, {name: "SaleWei", type: "uint256", value: "8000000000000000000"}, {name: "Picos", type: "uint256", value: "23200000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "88072725000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4413612", timeStamp: "1508750483", hash: "0xeb1e3098d6dbf0d014f430ba095b69eecab567567957bfee30e3db5dd5668ade", nonce: "3", blockHash: "0x1ed0afeedd20126d4db38435369e8730a698139365548b27f994e9d1c16cb8ce", transactionIndex: "24", from: "0x7a02c3ad8158ff57968049def5630e2c2081a32a", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "400000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1149313", gasUsed: "71560", confirmations: "3309471"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508750483 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x7a02c3ad8158ff57968049def5630e2c2081a32a"}, {name: "SaleWei", type: "uint256", value: "400000000000000000"}, {name: "Picos", type: "uint256", value: "1160000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "32068498000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4416371", timeStamp: "1508789472", hash: "0x65ae962ee13170236f6b6bd7492b3fdbe2845a6700f9192e86f871fcf771289d", nonce: "0", blockHash: "0xee9542c8150e5201e862b40220e63279840ffe65e0587b1990e1d33a7c494c03", transactionIndex: "10", from: "0x95ff52084fe5b9a9a28c322af847546092fba3d1", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "340000000000000000", gas: "21000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "477177", gasUsed: "21000", confirmations: "3306712"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "340000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3520832000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4416426", timeStamp: "1508790204", hash: "0xb14bf972dbff89bc6f02342fd53dccc2e19748cbcf26d05f86919d92ea618a0b", nonce: "1", blockHash: "0xe3c556f9da5eb19896194583a20e82aa419db59a5638b06132bc4025b4056141", transactionIndex: "14", from: "0x95ff52084fe5b9a9a28c322af847546092fba3d1", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "450000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "4189261", gasUsed: "91775", confirmations: "3306657"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "450000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508790204 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x95ff52084fe5b9a9a28c322af847546092fba3d1"}, {name: "SaleWei", type: "uint256", value: "450000000000000000"}, {name: "Picos", type: "uint256", value: "1305000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3520832000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4417012", timeStamp: "1508797880", hash: "0x86a334f0f454f6273e76de165fe069e722a3d498d974d7a6a4884fee516f8cd6", nonce: "2", blockHash: "0x633d58b789d0d313f1826fd3d225e87a06da633d922dc57393637fa0ccc6c713", transactionIndex: "15", from: "0x17bba6a0f55bb41b809ad935a86e7e08bb5881a1", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "13000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "587096", gasUsed: "91775", confirmations: "3306071"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "13000000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508797880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x17bba6a0f55bb41b809ad935a86e7e08bb5881a1"}, {name: "SaleWei", type: "uint256", value: "13000000000000000000"}, {name: "Picos", type: "uint256", value: "37700000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "796320000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4418231", timeStamp: "1508814370", hash: "0xa2c9a647e1d1e20817560bf4538dd3abf358b99bad351bea884e5b70447d9873", nonce: "0", blockHash: "0x2199743593e9ed9ddf7daa08304a49f7a13af7a30cdae776b2ddf74de2d62e8d", transactionIndex: "26", from: "0x7bcc11ecc419fbba0cc5ebb9dc15b1f5bbc97558", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "7950000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1208825", gasUsed: "91775", confirmations: "3304852"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "7950000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508814370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x7bcc11ecc419fbba0cc5ebb9dc15b1f5bbc97558"}, {name: "SaleWei", type: "uint256", value: "7950000000000000000"}, {name: "Picos", type: "uint256", value: "23055000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "38072725000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"3100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4419179", timeStamp: "1508827810", hash: "0xe394c29f4e63d12a9b242737052e547ee924950be18ac152cc1c5a401c848f5b", nonce: "10", blockHash: "0x2789a29c59f60a04965cad5f1992d0d115fce668d951a65438bb8b710b3e680a", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "4712388", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e000000000000000000000000000000000000000000000000000b036efecdc000", contractAddress: "", cumulativeGasUsed: "28747", gasUsed: "28747", confirmations: "3303904"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "3100000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "3100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508827810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "3100000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4420078", timeStamp: "1508840020", hash: "0x7fce8ec49fb0873832baa7932c634c9950a632dcc189fe423a35620e9f96ab9a", nonce: "0", blockHash: "0x52998f51f79e399ee5479d13a835128b0a7f39524ad911430ae1e0059b74b453", transactionIndex: "11", from: "0xdb7305465ab5fa3197717573beb26b64ac6f36dd", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "25000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "473331", gasUsed: "91775", confirmations: "3303005"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "25000000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508840020 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0xdb7305465ab5fa3197717573beb26b64ac6f36dd"}, {name: "SaleWei", type: "uint256", value: "25000000000000000000"}, {name: "Picos", type: "uint256", value: "77500000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "10072725000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4420546", timeStamp: "1508846426", hash: "0x79c349eaefaa2eb25b63ecdc06a987972ac8745532c0d90c226c3b2f1feae319", nonce: "0", blockHash: "0x6ce218a9a06eb90cc05f500533b1a871bb827d42ccec36aecd37e84126806684", transactionIndex: "26", from: "0x35d12069493acfd577d14589a7df60207ff8b2a0", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "3870967741935480000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1100219", gasUsed: "91775", confirmations: "3302537"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "3870967741935480000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508846426 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x35d12069493acfd577d14589a7df60207ff8b2a0"}, {name: "SaleWei", type: "uint256", value: "3870967741935480000"}, {name: "Picos", type: "uint256", value: "11999999999999988"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "9632675000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4421645", timeStamp: "1508862046", hash: "0x30b89c1a0c14709cf3a3992fdc1b621c9690814e3f2b36caa73703dad5a59ddb", nonce: "2", blockHash: "0x2d7b810de2540ceb8eec195c378d44e5c0144cd4ae775e3baf09cb7a4d236752", transactionIndex: "58", from: "0x95ff52084fe5b9a9a28c322af847546092fba3d1", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "130000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1621116", gasUsed: "71560", confirmations: "3301438"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "130000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508862046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x95ff52084fe5b9a9a28c322af847546092fba3d1"}, {name: "SaleWei", type: "uint256", value: "130000000000000000"}, {name: "Picos", type: "uint256", value: "403000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3520832000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[14], \"12\", \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "4422263", timeStamp: "1508870588", hash: "0xb8137390028da9f592a14dfcdcbb00643d45e6da80ab053114b70fc36a5efa3f", nonce: "11", blockHash: "0x9b881053e43ca849ece01b0dc04e2dc8f4126608c8b40137c44149c8450a3de3", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "150000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb500000000000000000000000035d12069493acfd577d14589a7df60207ff8b2a0000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "59628", gasUsed: "59628", confirmations: "3300820"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[14]}, {type: "uint256", name: "wad", value: "12"}, {type: "uint256", name: "picos", value: "12"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[14], "12", "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508870588 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x35d12069493acfd577d14589a7df60207ff8b2a0"}, {name: "SuppliedWei", type: "uint256", value: "12"}, {name: "Picos", type: "uint256", value: "12"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4426184", timeStamp: "1508925345", hash: "0xd6d40b65c01f7b9bbd313ad3e64c35449a6abe927d1df9fe0462c1507393fbe7", nonce: "101", blockHash: "0xf46ff8c73177dc7bcaa689bcff53c64b460fcaed17100e85449875a1661a6123", transactionIndex: "17", from: "0x86751d220019258756ec48e42d552ed248237b07", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "2000000000000000000", gas: "200000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "633454", gasUsed: "91775", confirmations: "3296899"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508925345 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x86751d220019258756ec48e42d552ed248237b07"}, {name: "SaleWei", type: "uint256", value: "2000000000000000000"}, {name: "Picos", type: "uint256", value: "6200000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "82421111308095661" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"3000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4426357", timeStamp: "1508927921", hash: "0x919fc1f66a5c06441680c2d310a8e43a0b90c1f7610642947fd01597b10e4f93", nonce: "12", blockHash: "0x2b55fbeca0d37877713b4bceda4562ea92d951808c6b7e160ab134a7c7417e22", transactionIndex: "1", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "28747", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e000000000000000000000000000000000000000000000000000aa87bee538000", contractAddress: "", cumulativeGasUsed: "207875", gasUsed: "28747", confirmations: "3296726"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "3000000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "3000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508927921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "3000000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4426459", timeStamp: "1508929383", hash: "0xdd55c2928cc91a1a23c50b9992ac147b896c8dbf441ed6f377d47650c38eefa0", nonce: "1", blockHash: "0x1073c41ab6406f798079db98e078576663339c1b53f53bbb2c7e5ed7cc5160a5", transactionIndex: "11", from: "0x35d12069493acfd577d14589a7df60207ff8b2a0", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "4333333333333333333", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "556521", gasUsed: "71560", confirmations: "3296624"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "4333333333333333333" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508929383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x35d12069493acfd577d14589a7df60207ff8b2a0"}, {name: "SaleWei", type: "uint256", value: "4333333333333333333"}, {name: "Picos", type: "uint256", value: "12999999999999999"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "9632675000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[14], \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4426538", timeStamp: "1508930452", hash: "0x3292607e253ed0fb4fea06e03336c2b0e6e259dc3938d899552a55163f7d248b", nonce: "13", blockHash: "0x976c43d202b799c3ce070d5cc454c5d413dfe309df44158cecb65d227397d120", transactionIndex: "98", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "60000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb500000000000000000000000035d12069493acfd577d14589a7df60207ff8b2a000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2372037", gasUsed: "59628", confirmations: "3296545"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[14]}, {type: "uint256", name: "wad", value: "1"}, {type: "uint256", name: "picos", value: "1"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[14], "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508930452 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x35d12069493acfd577d14589a7df60207ff8b2a0"}, {name: "SuppliedWei", type: "uint256", value: "1"}, {name: "Picos", type: "uint256", value: "1"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4437199", timeStamp: "1509078778", hash: "0xb5b5f4dc35b9717baf17a5c62f3e05e853aec0103cea32348f6df06d3e1304a9", nonce: "0", blockHash: "0x65e2dbf202aa8fa7cb6ed36a20a94bafb3e9019510af210a4bf86a39a3a8f7ab", transactionIndex: "30", from: "0xdadf18c232489ef479f2f9e6f72f64a47e90a256", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "12000000000000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1150069", gasUsed: "91775", confirmations: "3285884"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "12000000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509078778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0xdadf18c232489ef479f2f9e6f72f64a47e90a256"}, {name: "SaleWei", type: "uint256", value: "12000000000000000000"}, {name: "Picos", type: "uint256", value: "36000000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "170640000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"3100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4453880", timeStamp: "1509311292", hash: "0x3decfc1ed2c6201e38083e92f0353bc3ba197bdefab1609b7bf22493e87ffb2e", nonce: "14", blockHash: "0x293ccd90cca7f012cd5689f3ed7ef2f1d7d10747427ca035ad463d7cb40bea97", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "28747", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e000000000000000000000000000000000000000000000000000b036efecdc000", contractAddress: "", cumulativeGasUsed: "28747", gasUsed: "28747", confirmations: "3269203"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "3100000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "3100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509311292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "3100000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: PrepareToStart( `Pacio Seed Presale`, \"1508749200\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "4463022", timeStamp: "1509439528", hash: "0xe9044e7a0dad8f3b94f37f2cc3b2f0bbd4ba58d8c36a992f12ef7d2a6e595e21", nonce: "15", blockHash: "0x66de2a2fac163b989c31e09e52180c8fe992bd18d827e23b8532d27fa0deeb8b", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "200000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0x6897c1b600000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000059edaf900000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000b036efecdc00000000000000000000000000018dfd8c468ed83397c0e1cadae01e1e65e86d275000000000000000000000000fc8692e9b6f8dfe3ba764545404aba5f266a41910000000000000000000000000000000000000000000000000000000000000012506163696f20536565642050726573616c650000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "81799", gasUsed: "81799", confirmations: "3260061"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "vNameS", value: `Pacio Seed Presale`}, {type: "uint256", name: "vStartTime", value: "1508749200"}, {type: "uint256", name: "vPicosCap", value: "1000000000000000000"}, {type: "uint256", name: "vPicosPerEther", value: "3100000000000000"}, {type: "address", name: "vTokenA", value: addressList[4]}, {type: "address", name: "vPCwalletA", value: addressList[5]}], name: "PrepareToStart", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "PrepareToStart(string,uint256,uint256,uint256,address,address)" ]( `Pacio Seed Presale`, "1508749200", "1000000000000000000", "3100000000000000", addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509439528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Name", type: "string"}, {indexed: false, name: "StartTime", type: "uint256"}, {indexed: false, name: "PicosCap", type: "uint256"}, {indexed: false, name: "TokenContract", type: "address"}, {indexed: false, name: "PCwallet", type: "address"}], name: "LogPrepareToStart", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPrepareToStart", events: [{name: "Name", type: "string", value: "Pacio Seed Presale"}, {name: "StartTime", type: "uint256", value: "1508749200"}, {name: "PicosCap", type: "uint256", value: "1000000000000000000"}, {name: "TokenContract", type: "address", value: "0x18dfd8c468ed83397c0e1cadae01e1e65e86d275"}, {name: "PCwallet", type: "address", value: "0xfc8692e9b6f8dfe3ba764545404aba5f266a4191"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "3100000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4464344", timeStamp: "1509458168", hash: "0x3dcfd2b056fcca5eedbe339718edd4d51a96e17d82b96e06c4c666d56abcde99", nonce: "3", blockHash: "0xab1a1aa0c8655ed0230ed4af04f9502b6a2ea49af6e4d89aa0c08fbb934427c4", transactionIndex: "4", from: "0xf27e3dcb929b29aa4d3d2fd9141de0582198b41f", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "1511201783218104197", gas: "191775", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "178775", gasUsed: "91775", confirmations: "3258739"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1511201783218104197" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509458168 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0xf27e3dcb929b29aa4d3d2fd9141de0582198b41f"}, {name: "SaleWei", type: "uint256", value: "1511201783218104197"}, {name: "Picos", type: "uint256", value: "4684725527976123"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "6506539094540678847" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4465864", timeStamp: "1509478896", hash: "0xe20dafd04098de12059cb41c1e45bbfc6fc242a6d454b6ac1c88f2b303858e41", nonce: "30", blockHash: "0xe6d8241a9420bda25ff234bc04c4f2d284ba1aa730675dbfafd690821e6e9601", transactionIndex: "97", from: "0x00a9b4f4c3a0d4d1a4d9db720dc9a0e5b91b5e29", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "2000000000000000000", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "4721684", gasUsed: "91775", confirmations: "3257219"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509478896 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x00a9b4f4c3a0d4d1a4d9db720dc9a0e5b91b5e29"}, {name: "SaleWei", type: "uint256", value: "2000000000000000000"}, {name: "Picos", type: "uint256", value: "6200000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "29535324199686807" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4466031", timeStamp: "1509481433", hash: "0x6ffa1e90e959423dc6eb7cff37171cfde6b0bc33f114b9ba07ca1956fca5eae6", nonce: "6", blockHash: "0x49cac04c934511c295b1239e72371329b51fe7d6e0991771c3160a2e9cd7442d", transactionIndex: "1", from: "0x352c120a675ab6d887e2dbda2ff8ee67f56361a9", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "200000000000000000", gas: "100000", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "112775", gasUsed: "91775", confirmations: "3257052"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509481433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x352c120a675ab6d887e2dbda2ff8ee67f56361a9"}, {name: "SaleWei", type: "uint256", value: "200000000000000000"}, {name: "Picos", type: "uint256", value: "620000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "14477845000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4471143", timeStamp: "1509552341", hash: "0x16f3cb1dc82a4543c559b83d279ffdfa9278691f8faae40785b556836d732dd0", nonce: "0", blockHash: "0x082465295a5505e4bbb9e2d4580e9b3164741e3afb2c1b7bf0ab19e175043644", transactionIndex: "96", from: "0x4d22d4bbc8cafac903e50b53002cdc8ca6979aca", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "1900000000000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2710074", gasUsed: "21061", confirmations: "3251940"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "1900000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509552341 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "94447684000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4471217", timeStamp: "1509553391", hash: "0x9e6b5c9e3d409cf7435ba9ef22847e5dfe96ac0f75151116710a1c2f41365a85", nonce: "1", blockHash: "0xba2d6b1bdae7a71edbd7d9fe82b7f2d504207ce2a213a669eedfd4611dd23850", transactionIndex: "98", from: "0x4d22d4bbc8cafac903e50b53002cdc8ca6979aca", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "1900000000000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "2712591", gasUsed: "91775", confirmations: "3251866"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "1900000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509553391 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x4d22d4bbc8cafac903e50b53002cdc8ca6979aca"}, {name: "SaleWei", type: "uint256", value: "1900000000000000000"}, {name: "Picos", type: "uint256", value: "5890000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "94447684000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4471254", timeStamp: "1509554110", hash: "0xce3d6911d9ef9880a596b53618a9ca1de8fdaea87adc919f02b2156d3d006d38", nonce: "2", blockHash: "0xeab7edb7bdeef6aaac036a3b2d17ca3587fecd014bfc035c2727bdc39fdebdc5", transactionIndex: "15", from: "0x4d22d4bbc8cafac903e50b53002cdc8ca6979aca", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "1000000000000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "668450", gasUsed: "71560", confirmations: "3251829"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509554110 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x4d22d4bbc8cafac903e50b53002cdc8ca6979aca"}, {name: "SaleWei", type: "uint256", value: "1000000000000000000"}, {name: "Picos", type: "uint256", value: "3100000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "94447684000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4476974", timeStamp: "1509634494", hash: "0x25bb4fd962ad829d55b2d4187520fc50bc9d62bbededfee6e1d258a163f106e4", nonce: "3", blockHash: "0x9a08b57b52a69812039a80c36e42914ab4c473a6dfa162d764ad1a3b96419d5c", transactionIndex: "6", from: "0x95ff52084fe5b9a9a28c322af847546092fba3d1", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "220000000000000000", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "231814", gasUsed: "71560", confirmations: "3246109"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "220000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509634494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x95ff52084fe5b9a9a28c322af847546092fba3d1"}, {name: "SaleWei", type: "uint256", value: "220000000000000000"}, {name: "Picos", type: "uint256", value: "682000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3520832000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4485987", timeStamp: "1509760516", hash: "0xd177578a4d097f831ba7ee003f15f1c7e0a194385f63d953c8a9203ff68cca00", nonce: "0", blockHash: "0xf2c96a93606235101e0c261f9e44bfcf79d35e543ce7ad061b2bdcc77f46916d", transactionIndex: "12", from: "0x53ee4b7d14bfb44c14653d2f73fdfe3958bb72d0", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "1099000000000000000", gas: "100000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "659314", gasUsed: "91775", confirmations: "3237096"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1099000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509760516 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x53ee4b7d14bfb44c14653d2f73fdfe3958bb72d0"}, {name: "SaleWei", type: "uint256", value: "1099000000000000000"}, {name: "Picos", type: "uint256", value: "3406900000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "364320000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"3300000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4522174", timeStamp: "1510262573", hash: "0x42042c77715107a507165e22746020c1a801e90d5d88ecfc3ebb621824aabc88", nonce: "16", blockHash: "0x6f5c6195c724e451c6ead53dbfe0e45771a3a5e347e5e721fca6d7b0dc412dfc", transactionIndex: "1", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "28747", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e000000000000000000000000000000000000000000000000000bb9551fc24000", contractAddress: "", cumulativeGasUsed: "88037", gasUsed: "28747", confirmations: "3200909"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "3300000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "3300000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510262573 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "3300000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"3100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4532128", timeStamp: "1510400227", hash: "0x3ffc588083fafe82cfa104978071d96d01ad6d151881df88006df9264bd1826b", nonce: "17", blockHash: "0xb6124f288e219e2d3a14029ba252ac6a2b09ccfd4fd63330025c2176bd20aa24", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "28747", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e000000000000000000000000000000000000000000000000000b036efecdc000", contractAddress: "", cumulativeGasUsed: "28747", gasUsed: "28747", confirmations: "3190955"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "3100000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "3100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510400227 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "3100000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"4700000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4627792", timeStamp: "1511731233", hash: "0x5e253d3c45bd4a0332ba16566b543b40ef479cdd5cd0b07f1010a33daa8f13b7", nonce: "18", blockHash: "0x7495c1739ddeb81369fb6f7921c3042200a6c2db8b989c37f421a931f2a1dfbf", transactionIndex: "55", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "28747", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e0000000000000000000000000000000000000000000000000010b2a00671c000", contractAddress: "", cumulativeGasUsed: "1295074", gasUsed: "28747", confirmations: "3095291"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "4700000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "4700000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511731233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "4700000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"4900000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4631464", timeStamp: "1511782921", hash: "0xed2f9ab543ed58fbad95db155461e4b542e823aec7888e55dff3d63ee214f397", nonce: "19", blockHash: "0x10f3ec01e07798bf4ec6656a4a48a83bdb26fc2c1a8dedc6cccc391013bab963", transactionIndex: "28", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "28747", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e0000000000000000000000000000000000000000000000000011688627664000", contractAddress: "", cumulativeGasUsed: "1958451", gasUsed: "28747", confirmations: "3091619"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "4900000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "4900000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511782921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "4900000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4632611", timeStamp: "1511799241", hash: "0xe6ca15bb79b0d5d5d4742dcc01a61a6172662d99cc7477ef6ed9cebf63453465", nonce: "42", blockHash: "0x7e279c61d048eb973b8c3ff3bbb4d832cae6568095e101d2ed493ccf8d9ed261", transactionIndex: "61", from: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "35600000000000000000", gas: "137662", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "1825701", gasUsed: "91775", confirmations: "3090472"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "35600000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511799241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596"}, {name: "SaleWei", type: "uint256", value: "35600000000000000000"}, {name: "Picos", type: "uint256", value: "174440000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "197272630890968266" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: SetPicosPerEther( \"7500000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4747788", timeStamp: "1513503181", hash: "0x92a7c50a4447bfbab63596951e0b5de6508ede8b8048f6f7e92178a8650b4d41", nonce: "20", blockHash: "0x116ff2783e49b4d928cee5929340a1074057af37575faf69744c69e8006f857a", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "28747", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xd00dba5e000000000000000000000000000000000000000000000000001aa535d3d0c000", contractAddress: "", cumulativeGasUsed: "28747", gasUsed: "28747", confirmations: "2975295"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "vPicosPerEther", value: "7500000000000000"}], name: "SetPicosPerEther", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "SetPicosPerEther(uint256)" ]( "7500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1513503181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "7500000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4795416", timeStamp: "1514218496", hash: "0x5a584d116248dd4e9fa6363a2d1758d61423dc96264bf9e0c7bd9a3a4682323b", nonce: "44", blockHash: "0xd577ac3ebe675b23fb4c1a61f74f343c39df8cbf9f5882498b35d0bf9135a1a6", transactionIndex: "113", from: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "32000000000000000000", gas: "107340", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "3815600", gasUsed: "71560", confirmations: "2927667"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "32000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1514218496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596"}, {name: "SaleWei", type: "uint256", value: "32000000000000000000"}, {name: "Picos", type: "uint256", value: "240000000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "197272630890968266" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4801460", timeStamp: "1514305087", hash: "0xcecd81200a73d2e0213277c6d13202741d8bdea549f7dbcb07a0ba1293fd4009", nonce: "45", blockHash: "0xdf5d8e282dd01ab5730ed12f0c17be7b35232528567b271a8a97abf1b9173ccf", transactionIndex: "219", from: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "31000000000000000000", gas: "107340", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "6494418", gasUsed: "71560", confirmations: "2921623"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "31000000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1514305087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596"}, {name: "SaleWei", type: "uint256", value: "31000000000000000000"}, {name: "Picos", type: "uint256", value: "232500000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "197272630890968266" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: Buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4807615", timeStamp: "1514394069", hash: "0x619dcf349b19df051bba7bd8248a0e33315277b898cb5e3d471a100056d15935", nonce: "46", blockHash: "0x647b41a4e0d9dfd90fddc8faaf1cdcbe9a9e2ced6623bffc9b94137887cd5f5d", transactionIndex: "187", from: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "12157650000000000000", gas: "131703", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x974c86b5", contractAddress: "", cumulativeGasUsed: "6717000", gasUsed: "72802", confirmations: "2915468"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "12157650000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1514394069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Purchaser", type: "address"}, {indexed: false, name: "SaleWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogSale", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSale", events: [{name: "Purchaser", type: "address", value: "0x9ff3aed9524d14774325d91be2b62deb4a1f6596"}, {name: "SaleWei", type: "uint256", value: "12157650000000000000"}, {name: "Picos", type: "uint256", value: "91182375000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "WeiRaised", type: "uint256"}, {indexed: false, name: "PicosSold", type: "uint256"}], name: "LogSaleCapReached", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSaleCapReached", events: [{name: "WeiRaised", type: "uint256", value: "197812152858486917530"}, {name: "PicosSold", type: "uint256", value: "1000000000527976123"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "197272630890968266" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[6], \"0\", \"145000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653626", timeStamp: "1526933050", hash: "0xa062f5656cd3c1087da2f46f2be6c811f5fedf78452be597efcd68c1839631b8", nonce: "23", blockHash: "0xf89a365a099d28436133f7139de45fbf672d227a3081b821edc1fdbba0d2de4b", transactionIndex: "17", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "150000", gasPrice: "100000000000", isError: "1", txreceipt_status: "0", input: "0xe2a6fbb50000000000000000000000002181ecc71f13018befb9a556079379faa69377020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000526c46eeca000", contractAddress: "", cumulativeGasUsed: "861792", gasUsed: "24665", confirmations: "2069457"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[6]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "1450000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[6], "0", "1450000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1526933050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: PrepareToStart( `Pacio Seed Presale`, \"1508749200\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "5653758", timeStamp: "1526935010", hash: "0x81cb46865ac4a1648497932036b52a4abf370483ad108e9f56c0a2a300ef9748", nonce: "24", blockHash: "0xcb2ce9c58e6d0e4e2fef233fde1da8e92032addc7ec67f8fd2cfe2693e475736", transactionIndex: "0", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "200000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0x6897c1b600000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000059edaf900000000000000000000000000000000000000000000000001bc16d674ec800000000000000000000000000000000000000000000000000000031bced02db000000000000000000000000000018dfd8c468ed83397c0e1cadae01e1e65e86d275000000000000000000000000fc8692e9b6f8dfe3ba764545404aba5f266a41910000000000000000000000000000000000000000000000000000000000000012506163696f20536565642050726573616c650000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "96735", gasUsed: "96735", confirmations: "2069325"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "vNameS", value: `Pacio Seed Presale`}, {type: "uint256", name: "vStartTime", value: "1508749200"}, {type: "uint256", name: "vPicosCap", value: "2000000000000000000"}, {type: "uint256", name: "vPicosPerEther", value: "14000000000000000"}, {type: "address", name: "vTokenA", value: addressList[4]}, {type: "address", name: "vPCwalletA", value: addressList[5]}], name: "PrepareToStart", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "PrepareToStart(string,uint256,uint256,uint256,address,address)" ]( `Pacio Seed Presale`, "1508749200", "2000000000000000000", "14000000000000000", addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1526935010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Name", type: "string"}, {indexed: false, name: "StartTime", type: "uint256"}, {indexed: false, name: "PicosCap", type: "uint256"}, {indexed: false, name: "TokenContract", type: "address"}, {indexed: false, name: "PCwallet", type: "address"}], name: "LogPrepareToStart", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPrepareToStart", events: [{name: "Name", type: "string", value: "Pacio Seed Presale"}, {name: "StartTime", type: "uint256", value: "1508749200"}, {name: "PicosCap", type: "uint256", value: "2000000000000000000"}, {name: "TokenContract", type: "address", value: "0x18dfd8c468ed83397c0e1cadae01e1e65e86d275"}, {name: "PCwallet", type: "address", value: "0xfc8692e9b6f8dfe3ba764545404aba5f266a4191"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "PicosPerEther", type: "uint256"}], name: "LogSetPicosPerEther", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetPicosPerEther", events: [{name: "PicosPerEther", type: "uint256", value: "14000000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[6], \"0\", \"145000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653775", timeStamp: "1526935234", hash: "0xd0c860793457e6fa9172193d8a02e4f26682ec3a3828cf30db2b371e3820b5cc", nonce: "25", blockHash: "0xacdd7f0351b5a55d1c6896fd4c4ad836d16a1ffe297b042a6ec281bf2bdf135b", transactionIndex: "41", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "150000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb50000000000000000000000002181ecc71f13018befb9a556079379faa69377020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000526c46eeca000", contractAddress: "", cumulativeGasUsed: "968015", gasUsed: "59884", confirmations: "2069308"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[6]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "1450000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[6], "0", "1450000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1526935234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x2181ecc71f13018befb9a556079379faa6937702"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "1450000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[7], \"0\", \"371200000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653789", timeStamp: "1526935483", hash: "0xf99a29476d8018d682164f9a75cc8a3522489afd3c9562aa85edf093e7cbdd54", nonce: "26", blockHash: "0x0649cd3221ba036984665de8ad703145a4e1202971fe3ea367047b66c4f9c0f5", transactionIndex: "6", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "60000", gasPrice: "100000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb50000000000000000000000007a02c3ad8158ff57968049def5630e2c2081a32a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d300b59680000", contractAddress: "", cumulativeGasUsed: "1571452", gasUsed: "59820", confirmations: "2069294"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[7]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "3712000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[7], "0", "3712000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1526935483 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x7a02c3ad8158ff57968049def5630e2c2081a32a"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "3712000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[8], \"0\", \"176900000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653824", timeStamp: "1526936060", hash: "0xade8bc02e49933b7f240ecc1f883cd4a96a9eb631da0317fc2b339bf228ab4f6", nonce: "27", blockHash: "0xd4f4f735e682fbf4e2f337dbce2bf337cea5c9205d71dc06d2bd0f49ed2aff83", transactionIndex: "17", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "6721975", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb50000000000000000000000009c72833f60bcf02203d8c117e854d88b7369887c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000648e5689b9000", contractAddress: "", cumulativeGasUsed: "801536", gasUsed: "59884", confirmations: "2069259"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[8]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "1769000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[8], "0", "1769000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1526936060 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x9c72833f60bcf02203d8c117e854d88b7369887c"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "1769000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[9], \"0\", \"232000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653838", timeStamp: "1526936250", hash: "0x2a040327b43b1480dce09b4ffcc2d70e794640de904259be147741248b0d8666", nonce: "28", blockHash: "0x057ebcd7b2b41039305762c0d9b5308aeee3a8cd2014951ae0d0b42777e12ca5", transactionIndex: "13", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "6721975", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb5000000000000000000000000e778822c34398fd940f781ac40df6d90298e0574000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000526c46eeca0000", contractAddress: "", cumulativeGasUsed: "467184", gasUsed: "59820", confirmations: "2069245"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[9]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "23200000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[9], "0", "23200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1526936250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0xe778822c34398fd940f781ac40df6d90298e0574"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "23200000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[10], \"0\", \"23900000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653861", timeStamp: "1526936657", hash: "0x99c064f883c759d90a0939882947b258cf4ff3973b830bbf26edc929dad15d65", nonce: "29", blockHash: "0xe973246168bb0f7ac403499130f28f9350353a8157b5939120257967abff5c20", transactionIndex: "254", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "60000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb500000000000000000000000095ff52084fe5b9a9a28c322af847546092fba3d1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000087db13d036000", contractAddress: "", cumulativeGasUsed: "7131889", gasUsed: "59884", confirmations: "2069222"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[10]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "2390000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[10], "0", "2390000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1526936657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x95ff52084fe5b9a9a28c322af847546092fba3d1"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "2390000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[11], \"0\", \"37700000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653881", timeStamp: "1526936973", hash: "0x37b93954395c8d2fbec19c7584106b23e651a3412bc2afb7f02e2528b014fe91", nonce: "30", blockHash: "0x19303c69d7a64baaeaa7c10e9495531b6a676324fc6d98d0331510ef476a3174", transactionIndex: "205", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "60000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb500000000000000000000000017bba6a0f55bb41b809ad935a86e7e08bb5881a100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000085eff344084000", contractAddress: "", cumulativeGasUsed: "6130280", gasUsed: "59884", confirmations: "2069202"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[11]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "37700000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[11], "0", "37700000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1526936973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x17bba6a0f55bb41b809ad935a86e7e08bb5881a1"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "37700000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[12], \"0\", \"23055000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653893", timeStamp: "1526937264", hash: "0x22d97d944698d42ee43112602828676c13fcdcf65853660d2042a0f9fcfb61f1", nonce: "31", blockHash: "0x953faad603c1ce8e896126b832fea6e4c7a36d80c4b07b633dcb754a63d0bd8f", transactionIndex: "25", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "60000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb50000000000000000000000007bcc11ecc419fbba0cc5ebb9dc15b1f5bbc9755800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000051e8667d4bf000", contractAddress: "", cumulativeGasUsed: "1053972", gasUsed: "59884", confirmations: "2069190"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[12]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "23055000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[12], "0", "23055000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1526937264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0x7bcc11ecc419fbba0cc5ebb9dc15b1f5bbc97558"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "23055000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: Allocate( addressList[13], \"0\", \"77500000000000... )", async function( ) {
		const txOriginal = {blockNumber: "5653907", timeStamp: "1526937493", hash: "0x78d856a6f31da1b95e049e00076ca900e6815b5f8dcf3c779c1e910609cb2b58", nonce: "32", blockHash: "0xf55faa94031a5887bbd8a92a78ec5d32ebd8631e7982e32c60f45a62b0079c00", transactionIndex: "170", from: "0xb612126318cf820b5220bd287567fd2dea8d604b", to: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee", value: "0", gas: "60000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe2a6fbb5000000000000000000000000db7305465ab5fa3197717573beb26b64ac6f36dd0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011355d6e217c000", contractAddress: "", cumulativeGasUsed: "7459990", gasUsed: "59948", confirmations: "2069176"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "vSupplierA", value: addressList[13]}, {type: "uint256", name: "wad", value: "0"}, {type: "uint256", name: "picos", value: "77500000000000000"}], name: "Allocate", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "Allocate(address,uint256,uint256)" ]( addressList[13], "0", "77500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1526937493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "Supplier", type: "address"}, {indexed: false, name: "SuppliedWei", type: "uint256"}, {indexed: false, name: "Picos", type: "uint256"}], name: "LogAllocate", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAllocate", events: [{name: "Supplier", type: "address", value: "0xdb7305465ab5fa3197717573beb26b64ac6f36dd"}, {name: "SuppliedWei", type: "uint256", value: "0"}, {name: "Picos", type: "uint256", value: "77500000000000000"}], address: "0x2b94e0c6ccb25ccf6b2dfa1a286712eb565437ee"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1303106432100000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
