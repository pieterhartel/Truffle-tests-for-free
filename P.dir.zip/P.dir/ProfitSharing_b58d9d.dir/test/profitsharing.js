const ProfitSharing = artifacts.require( "./ProfitSharing.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ProfitSharing" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6822aaF4aB22e6Cca8352a927B9ae0A8FdB58D9D", "0xf8536CA7a25CBF70DF754fA310079aDa4c6114C2", "0x1B9743f556D65e757c4c650B4555bAF354cB8bd3", "0xDC8624670c344651A6140C57e38A8E36ef664638", "0x86bcF77b0d699B4FB97E1B253245e7320fB14941", "0x614bC1a334745eFD74960edA729168CFE976A782", "0x980dD5da6eB83C2927d46f7eaDB0284dbcDCca0d", "0x1755f8354Cb48ADdd1D24E4CbC48311955B784aC", "0xcd3C509A1aFeE8d4b92b5893ef7C4BD37203B4d7", "0x0c2BD8CaBe467BC0409A9aB84a0D7538580Ea3D7", "0x04035F558b0A5dD652a1bdc379cCAf00c4F62647", "0xB321Bea2E7aa89D7dBa4cCCa238Ea4DB0c00077e", "0x9e9bf452bD4DE555aa25Cd8f2bc7f2416CE4B74C", "0xCeCC220fc08069f91875d61AcE008ECE14cf3fCa", "0x38121c93F4A4EBAA9E3676676644e6844CC47CE3", "0x7Bcc82729F619a7d6ce27C2cC04A9ee92E91767D", "0x67e53197D892C209dA1a32056D5e8BE98475Dfe2", "0xD28F732B12947f2DE3718c43Be4D2954A492E30c", "0xA25942D870dc984d2483Fab0F731AF6fbB5e1479", "0x1f24B1b0d4121317E427fd0149EE5207D54A7a62", "0x3b7ab3521d9AD91d62a92A0570C24d4328A6f69a", "0x022b66C7Fd8aB5F1a9636C4608B4BDF3D453a050", "0xA0be78D2Bac6A692adBa423C7af50ec86A18BdDf", "0x47D92E4Cc562C7cFED8fD24f384B76f1D9DCF714", "0x6AC4C78A570C1B4C43110d4c6c456cE4F46C17C9", "0x4B43041E418b16BB7dcf94A09F721cC73574FC04", "0xee470c3D4153492c0566b184B272516CF5f1718F", "0xA106379acb22DF279F1AC3C0299742531B3ba6eE", "0x239aA2d158695Ac7282aFaA90bbB0806e9466563", "0xbaBFa0DE0f5548778bfA219f0FaEBa8FB557a4fD", "0xe5Ae51871f3B58E4Be4c29783D7fF8571473f488", "0x5383402964a33845a163F608dD142D29F6e842EA", "0x0656d8b7b1Fcc09788F4A7B657B38A3A4EeB3f9B", "0xbbd7e435B7BA2FD68e5DE85887ceE70D4aD35BBa", "0xcD07679A857C49B6CC0b1181a57a2F480a8ddf50", "0xd96ba8F3a69E1a5A8033Fa2a0bA6D7B7C1346DeF", "0x76927E2CCAb0084BD19cEe74F78B63134b9d181E"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "miniMeToken", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "RECYCLE_TIME", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "dividends", outputs: [{name: "blockNumber", type: "uint256"}, {name: "timestamp", type: "uint256"}, {name: "amount", type: "uint256"}, {name: "claimedAmount", type: "uint256"}, {name: "totalSupply", type: "uint256"}, {name: "recycled", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_depositor", type: "address"}, {indexed: false, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_totalSupply", type: "uint256"}, {indexed: false, name: "_dividendIndex", type: "uint256"}], name: "DividendDeposited", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_recycler", type: "address"}, {indexed: false, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_totalSupply", type: "uint256"}, {indexed: false, name: "_dividendIndex", type: "uint256"}], name: "DividendRecycled", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["DividendDeposited(address,uint256,uint256,uint256,uint256)", "DividendClaimed(address,uint256,uint256)", "DividendRecycled(address,uint256,uint256,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xcbf89ed8b63aa0a8f6e744e4023554f41dc830838d138eb2d4099cbcfe4a0831", "0xa1c93169468f71ef26f4adf10bca8df21460f11843a01ed9c69da306e33c3847", "0x820e5e0bd7a055839c0210e84ddba311de47df61f9c489947f436bcf0f302ff1"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4190739 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4225375 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_miniMeToken", value: 4}], name: "ProfitSharing", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "miniMeToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "miniMeToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "RECYCLE_TIME", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "RECYCLE_TIME()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "dividends", outputs: [{name: "blockNumber", type: "uint256"}, {name: "timestamp", type: "uint256"}, {name: "amount", type: "uint256"}, {name: "claimedAmount", type: "uint256"}, {name: "totalSupply", type: "uint256"}, {name: "recycled", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dividends(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ProfitSharing", function( accounts ) {

	it( "TEST: ProfitSharing( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4190739", timeStamp: "1503419766", hash: "0xb6267a2991bc48988572c1abd69296adc1285972d44eb6d01ff95ce482e52cd0", nonce: "66", blockHash: "0x883b7c00eab5cb7efe1a5f0241efb3c5765f0c1a1c0175a6ced720704e2ef52e", transactionIndex: "17", from: "0xf8536ca7a25cbf70df754fa310079ada4c6114c2", to: 0, value: "0", gas: "4612388", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x54beb2f40000000000000000000000001b9743f556d65e757c4c650b4555baf354cb8bd3", contractAddress: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", cumulativeGasUsed: "2602376", gasUsed: "827984", confirmations: "3510844"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_miniMeToken", value: addressList[4]}], name: "ProfitSharing", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ProfitSharing.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1503419766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ProfitSharing.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8877648503623912945" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4191011", timeStamp: "1503425387", hash: "0xab8c384a5a624bb170adeef8172a2bfcb829085f68bdd877bf05fdc29a7e6477", nonce: "68", blockHash: "0xe67985feea9f55ca3a979afbcf7b23d8a07eb32f70fe6dcc08b660bcada21ae4", transactionIndex: "25", from: "0xf8536ca7a25cbf70df754fa310079ada4c6114c2", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "128899", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xf2fde38b000000000000000000000000dc8624670c344651a6140c57e38a8e36ef664638", contractAddress: "", cumulativeGasUsed: "855483", gasUsed: "28898", confirmations: "3510572"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[5]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1503425387 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8877648503623912945" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: depositDividend(  )", async function( ) {
		const txOriginal = {blockNumber: "4220752", timeStamp: "1504118041", hash: "0x768175e28b41d58d042c5729f8bb1a04863a062c24581939fe639eb5aaf43e22", nonce: "20", blockHash: "0xdd938fbab5ff12ba9905151309771909e391366658a1d7a4e6e059150c9dea35", transactionIndex: "50", from: "0xdc8624670c344651a6140c57e38a8e36ef664638", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "50000000000000000", gas: "140826", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa289d187", contractAddress: "", cumulativeGasUsed: "4814888", gasUsed: "140825", confirmations: "3480831"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositDividend", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositDividend()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1504118041 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_depositor", type: "address"}, {indexed: false, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_totalSupply", type: "uint256"}, {indexed: false, name: "_dividendIndex", type: "uint256"}], name: "DividendDeposited", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DividendDeposited", events: [{name: "_depositor", type: "address", value: "0xdc8624670c344651a6140c57e38a8e36ef664638"}, {name: "_blockNumber", type: "uint256", value: "4220751"}, {name: "_amount", type: "uint256", value: "50000000000000000"}, {name: "_totalSupply", type: "uint256", value: "1634690762741201212"}, {name: "_dividendIndex", type: "uint256", value: "0"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "30198725000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4220771", timeStamp: "1504118466", hash: "0x9a2372ae72551cceb82fa902fa434a204ac0464d22951200d5e3472b8007dcb5", nonce: "3", blockHash: "0x6b9c9801a5d930ffe8ff32c7cc81fc1cecfd15d11f23a078a52dbf5b7986c63c", transactionIndex: "73", from: "0x86bcf77b0d699b4fb97e1b253245e7320fb14941", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "102045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2991714", gasUsed: "101836", confirmations: "3480812"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1504118466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x86bcf77b0d699b4fb97e1b253245e7320fb14941"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "232535968676162"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "234617161368676162" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4220822", timeStamp: "1504120007", hash: "0x4186e7b300a352efcb616f4a9e4bf86657b01cf501ad0f0ee97cd45ad2d9efb9", nonce: "45", blockHash: "0x8bf08cd91a080123f03016f400731669f53b872f8f1da2798b2ee091ee01f841", transactionIndex: "54", from: "0x614bc1a334745efd74960eda729168cfe976a782", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "87045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2225813", gasUsed: "86836", confirmations: "3480761"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1504120007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x614bc1a334745efd74960eda729168cfe976a782"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "399188650767037"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "90227038863954242" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4220822", timeStamp: "1504120007", hash: "0xda24afca2d1179abe6eb737b70c84fbbdbdd9fb3020147b6fbe238f41234322f", nonce: "36", blockHash: "0x8bf08cd91a080123f03016f400731669f53b872f8f1da2798b2ee091ee01f841", transactionIndex: "98", from: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "87045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "4198349", gasUsed: "86836", confirmations: "3480761"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1504120007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "1498754416334"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "87538762011929427" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4220836", timeStamp: "1504120335", hash: "0x5b2bac84961fece8aa0d36a02a101f553722cfced80b2434de393cfa2e3ec6ed", nonce: "49", blockHash: "0x1dc2f744e6459694ad524fefda496314cdbb62c6cc213a9c03d083c7ed759efe", transactionIndex: "183", from: "0x1755f8354cb48addd1d24e4cbc48311955b784ac", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "87045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "5921969", gasUsed: "86836", confirmations: "3480747"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1504120335 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1755f8354cb48addd1d24e4cbc48311955b784ac"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "114430567554482"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4220871", timeStamp: "1504121286", hash: "0x65fdcef7e326506239df0d1226a57b89822c755da30a42a80467f995f61e09b1", nonce: "5", blockHash: "0x7f0eb5c2e1471fc9fd6882b943c6c7a6c03cdea517f16059d4deab2334012c51", transactionIndex: "176", from: "0xcd3c509a1afee8d4b92b5893ef7c4bd37203b4d7", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "87045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "5192726", gasUsed: "86836", confirmations: "3480712"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1504121286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd3c509a1afee8d4b92b5893ef7c4bd37203b4d7"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "559738894263795"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "455850379703474" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224432", timeStamp: "1504209079", hash: "0x19964c485b43153406697be7c742a775a52e63872e52482c5ba330d40d0155b4", nonce: "50", blockHash: "0x41af4572dee05f796f3218b052074d2e72f0fdd89b880ffa07b03d66859cb745", transactionIndex: "76", from: "0x1755f8354cb48addd1d24e4cbc48311955b784ac", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "250000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3309659", gasUsed: "250000", confirmations: "3477151"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224462", timeStamp: "1504209887", hash: "0xbb30a3fd9435c233451fee7486d4833102e135ab544a2f5006b14780faf71374", nonce: "51", blockHash: "0xece530ac0c63d381999b8d175f3fe546d7d33c8a556a69d9ebda092116f66378", transactionIndex: "133", from: "0x1755f8354cb48addd1d24e4cbc48311955b784ac", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "21272", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2927412", gasUsed: "21272", confirmations: "3477121"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224468", timeStamp: "1504210062", hash: "0x24560e5384ab4b90ca392805e4a0b5da5919ccbe735d95b674ad3a4fe83af263", nonce: "52", blockHash: "0xffe0bb7d8d510360186252fa3e6660882209bfd4e35b23adb3b3910f7d82cb0a", transactionIndex: "141", from: "0x1755f8354cb48addd1d24e4cbc48311955b784ac", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "250000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "4554261", gasUsed: "250000", confirmations: "3477115"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224478", timeStamp: "1504210269", hash: "0x9923f4910795eab64f54ca7305df85b4a23d88a294b5abaf2c31f859467ad897", nonce: "53", blockHash: "0x8be3810499abcaf7a3185faa96efb72dc27e0f350441e54d59cea881d2eb2ad1", transactionIndex: "145", from: "0x1755f8354cb48addd1d24e4cbc48311955b784ac", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "25000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "6538352", gasUsed: "25000", confirmations: "3477105"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: depositDividend(  )", async function( ) {
		const txOriginal = {blockNumber: "4224539", timeStamp: "1504211852", hash: "0x9d67489ccc0b9f73c2c38810022b9909b5dc81f76a5bd879d081d7c581917302", nonce: "21", blockHash: "0xf58a6cd47064c747790c3dc0f37da885b6d382d22850a98596cf192c52a632aa", transactionIndex: "140", from: "0xdc8624670c344651a6140c57e38a8e36ef664638", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "2000000000000000000", gas: "125826", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa289d187", contractAddress: "", cumulativeGasUsed: "5535505", gasUsed: "125825", confirmations: "3477044"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositDividend", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositDividend()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1504211852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_depositor", type: "address"}, {indexed: false, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_totalSupply", type: "uint256"}, {indexed: false, name: "_dividendIndex", type: "uint256"}], name: "DividendDeposited", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DividendDeposited", events: [{name: "_depositor", type: "address", value: "0xdc8624670c344651a6140c57e38a8e36ef664638"}, {name: "_blockNumber", type: "uint256", value: "4224538"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}, {name: "_totalSupply", type: "uint256", value: "1634690762741201212"}, {name: "_dividendIndex", type: "uint256", value: "1"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "30198725000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224567", timeStamp: "1504212472", hash: "0x93e6a2452478965de3cb7980381ab88883bff52112a7b3f2cb80deefa617968f", nonce: "54", blockHash: "0x52e43d203e6e28487a8611aa9f05382c14a2d01634151cb0060622c5481d9f2c", transactionIndex: "85", from: "0x1755f8354cb48addd1d24e4cbc48311955b784ac", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "87045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "4167839", gasUsed: "86836", confirmations: "3477016"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1504212472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1755f8354cb48addd1d24e4cbc48311955b784ac"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "4577222702179318"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224580", timeStamp: "1504213087", hash: "0x0d89d9a6a565bd751584ed1e140bfd871140d1d920c33823ea9fd019de6a2d50", nonce: "37", blockHash: "0x26392a80a1b271dfcc3490f31f6303d8c09216890c109630904ad64d5f76d235", transactionIndex: "144", from: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "72045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "6611941", gasUsed: "71836", confirmations: "3477003"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1504213087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "59950176653390"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "87538762011929427" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: depositDividend(  )", async function( ) {
		const txOriginal = {blockNumber: "4224641", timeStamp: "1504214528", hash: "0xe44ac1a081190a6d56f0483873a468e5b268f84e528cefd252f34fd2d274c3ec", nonce: "22", blockHash: "0x674e5dd9750fd08a8b2d1348e3e461041ab567aff66d6371413755433c8c204b", transactionIndex: "116", from: "0xdc8624670c344651a6140c57e38a8e36ef664638", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "50000000000000000000", gas: "125826", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa289d187", contractAddress: "", cumulativeGasUsed: "5576247", gasUsed: "125825", confirmations: "3476942"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositDividend", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositDividend()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1504214528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_depositor", type: "address"}, {indexed: false, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_totalSupply", type: "uint256"}, {indexed: false, name: "_dividendIndex", type: "uint256"}], name: "DividendDeposited", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DividendDeposited", events: [{name: "_depositor", type: "address", value: "0xdc8624670c344651a6140c57e38a8e36ef664638"}, {name: "_blockNumber", type: "uint256", value: "4224640"}, {name: "_amount", type: "uint256", value: "50000000000000000000"}, {name: "_totalSupply", type: "uint256", value: "1634690762741201212"}, {name: "_dividendIndex", type: "uint256", value: "2"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "30198725000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: depositDividend(  )", async function( ) {
		const txOriginal = {blockNumber: "4224650", timeStamp: "1504214853", hash: "0xa15f0d9f7a9715f422b44799dddb3acaf6eb65ad276302f546e0acfb6fa3b3b2", nonce: "23", blockHash: "0xfa8fa6ea27eb86e35655b039c30d1df36d3dd8d4737399233fad071a00b340c5", transactionIndex: "100", from: "0xdc8624670c344651a6140c57e38a8e36ef664638", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "78000000000000000000", gas: "125826", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa289d187", contractAddress: "", cumulativeGasUsed: "4027855", gasUsed: "125825", confirmations: "3476933"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "78000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositDividend", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositDividend()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1504214853 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_depositor", type: "address"}, {indexed: false, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_totalSupply", type: "uint256"}, {indexed: false, name: "_dividendIndex", type: "uint256"}], name: "DividendDeposited", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DividendDeposited", events: [{name: "_depositor", type: "address", value: "0xdc8624670c344651a6140c57e38a8e36ef664638"}, {name: "_blockNumber", type: "uint256", value: "4224649"}, {name: "_amount", type: "uint256", value: "78000000000000000000"}, {name: "_totalSupply", type: "uint256", value: "1634690762741201212"}, {name: "_dividendIndex", type: "uint256", value: "3"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "30198725000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224670", timeStamp: "1504215223", hash: "0xa5bd891fcaf3eb00e1d9e019c37b0e0df707441d8c09f88a9245a40dfa00359d", nonce: "38", blockHash: "0x65e89ca6fc6679ab86a770304826c130bfc6df818790c15f9e32d4445fed3614", transactionIndex: "49", from: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "87045", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "1346498", gasUsed: "87045", confirmations: "3476913"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "87538762011929427" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224674", timeStamp: "1504215400", hash: "0x9db8cd627b6aa34be7b36c727ef3444b3c75dc89ffa501465ac1681fe8cc10cd", nonce: "39", blockHash: "0x49ac30ab2d81c7e8641f931764175778b416417811f456d60daf0e32e8742901", transactionIndex: "100", from: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "151240", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2836470", gasUsed: "151031", confirmations: "3476909"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1504215400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "1498754416334752"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x980dd5da6eb83c2927d46f7eadb0284dbcdcca0d"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "2338056889482213"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "87538762011929427" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224873", timeStamp: "1504220069", hash: "0x8940a86aa4c4bb6aaa42b4b5bde1bf0fd0e016a0c1922097af0cf96179907ccd", nonce: "266", blockHash: "0x5fe38f27c0fd2239d638b47ff1224accab8f1df715604382d7b779754b077b7b", transactionIndex: "65", from: "0x0c2bd8cabe467bc0409a9ab84a0d7538580ea3d7", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2428144", gasUsed: "234421", confirmations: "3476710"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1504220069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0c2bd8cabe467bc0409a9ab84a0d7538580ea3d7"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "84786678409794"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0c2bd8cabe467bc0409a9ab84a0d7538580ea3d7"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "3391467136391782"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0c2bd8cabe467bc0409a9ab84a0d7538580ea3d7"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "84786678409794556"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0c2bd8cabe467bc0409a9ab84a0d7538580ea3d7"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "132267218319279507"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "29558304042011085" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224873", timeStamp: "1504220069", hash: "0xe808069056dd95e3f76c3feb1df4b80c4a2859cfbe5a10666b0ccf2eaf16cc43", nonce: "55", blockHash: "0x5fe38f27c0fd2239d638b47ff1224accab8f1df715604382d7b779754b077b7b", transactionIndex: "75", from: "0x1755f8354cb48addd1d24e4cbc48311955b784ac", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "121240", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3062355", gasUsed: "121031", confirmations: "3476710"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1504220069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1755f8354cb48addd1d24e4cbc48311955b784ac"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "114430567554482958"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1755f8354cb48addd1d24e4cbc48311955b784ac"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "178511685384993415"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224892", timeStamp: "1504220666", hash: "0x17deb8e56b6aff8d31635c9d1ee3896fdc3d1eda037e9f46fe6c4206fa22350c", nonce: "51", blockHash: "0xbbbb51cb37b500163b361254cf08d730c70a10eefede9b04b56ee1db81a432a3", transactionIndex: "118", from: "0x04035f558b0a5dd652a1bdc379ccaf00c4f62647", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3831955", gasUsed: "234421", confirmations: "3476691"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1504220666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x04035f558b0a5dd652a1bdc379ccaf00c4f62647"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "15293412411579"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x04035f558b0a5dd652a1bdc379ccaf00c4f62647"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "611736496463164"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x04035f558b0a5dd652a1bdc379ccaf00c4f62647"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "15293412411579104"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x04035f558b0a5dd652a1bdc379ccaf00c4f62647"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "23857723362063403"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "551818000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224914", timeStamp: "1504221147", hash: "0x697517afbeaa1651d5c579265fd775d29a23771cad7fd83704b67626c8734b40", nonce: "4", blockHash: "0x1826a0bf4406514a261fb9a8a4dc01d8915f6807d9cb32dc14adcaaf853facb8", transactionIndex: "73", from: "0xb321bea2e7aa89d7dba4ccca238ea4db0c00077e", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2705612", gasUsed: "234421", confirmations: "3476669"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1504221147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xb321bea2e7aa89d7dba4ccca238ea4db0c00077e"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "4802131497235"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xb321bea2e7aa89d7dba4ccca238ea4db0c00077e"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "192085259889433"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xb321bea2e7aa89d7dba4ccca238ea4db0c00077e"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "4802131497235838"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xb321bea2e7aa89d7dba4ccca238ea4db0c00077e"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "7491325135687908"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "9293147000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224919", timeStamp: "1504221239", hash: "0x198dde5bbc8c10fef52271542795ef7b19b1d66d946ff3c624f147380b572db8", nonce: "6", blockHash: "0xed182383714e506c103137cb593ffe2d2f0a4e9eb162056c675f00c12185920e", transactionIndex: "61", from: "0xcd3c509a1afee8d4b92b5893ef7c4bd37203b4d7", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "170435", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "1799003", gasUsed: "170226", confirmations: "3476664"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1504221239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd3c509a1afee8d4b92b5893ef7c4bd37203b4d7"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "22389555770551809"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd3c509a1afee8d4b92b5893ef7c4bd37203b4d7"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "559738894263795229"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd3c509a1afee8d4b92b5893ef7c4bd37203b4d7"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "873192675051520558"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "455850379703474" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224922", timeStamp: "1504221263", hash: "0x6f09456889548b7010da5c219407a107b57d411d22881a9ddd79532d714988dd", nonce: "1", blockHash: "0xfaa643aea336224d93724a484c4f1da40bcdc8be9ee2ac06dd4975866a7ec9cb", transactionIndex: "24", from: "0x9e9bf452bd4de555aa25cd8f2bc7f2416ce4b74c", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2559820", gasUsed: "234421", confirmations: "3476661"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1504221263 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x9e9bf452bd4de555aa25cd8f2bc7f2416ce4b74c"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "48349851975650"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x9e9bf452bd4de555aa25cd8f2bc7f2416ce4b74c"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "1933994079026012"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x9e9bf452bd4de555aa25cd8f2bc7f2416ce4b74c"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "48349851975650322"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x9e9bf452bd4de555aa25cd8f2bc7f2416ce4b74c"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "75425769082014503"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "121654573000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224955", timeStamp: "1504222205", hash: "0x027d3f159682e0b93c61c42a51d04691603b2e45b9826033ca33ab24f3f1fe0e", nonce: "304", blockHash: "0xb5a670ce3adf95ce0bae646649542863be71e932a53688ed1f4c31ed0baeabb8", transactionIndex: "75", from: "0xcecc220fc08069f91875d61ace008ece14cf3fca", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3897868", gasUsed: "234421", confirmations: "3476628"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1504222205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcecc220fc08069f91875d61ace008ece14cf3fca"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "16136505022678"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcecc220fc08069f91875d61ace008ece14cf3fca"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "645460200907151"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcecc220fc08069f91875d61ace008ece14cf3fca"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "16136505022678780"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcecc220fc08069f91875d61ace008ece14cf3fca"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "25172947835378897"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "21000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4224968", timeStamp: "1504222534", hash: "0x7efa50669c4fed61862b30973cc6610d3f9b8aa6b5f878dc37203400caf23f8d", nonce: "52", blockHash: "0x00330fd20f07e3eca4b5301cf0b6543bd35ff9cb7188e154f2f994ee5f942032", transactionIndex: "68", from: "0x38121c93f4a4ebaa9e3676676644e6844cc47ce3", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "19000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "5854696", gasUsed: "234421", confirmations: "3476615"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1504222534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x38121c93f4a4ebaa9e3676676644e6844cc47ce3"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "941133071481791"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x38121c93f4a4ebaa9e3676676644e6844cc47ce3"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "37645322859271641"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x38121c93f4a4ebaa9e3676676644e6844cc47ce3"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "941133071481791047"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x38121c93f4a4ebaa9e3676676644e6844cc47ce3"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "1468167591511594034"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "199369842251659358472" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225020", timeStamp: "1504223690", hash: "0xc918acf87fd6344e765b172956b027f3f052b79eef46ae2a82caf6bb25c81af4", nonce: "10", blockHash: "0xc57c6d9b9ea8a49900f82158f9111b17103abce8ac892761b0c62a7f283866fa", transactionIndex: "1", from: "0x7bcc82729f619a7d6ce27c2cc04a9ee92e91767d", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "255421", gasUsed: "234421", confirmations: "3476563"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1504223690 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x7bcc82729f619a7d6ce27c2cc04a9ee92e91767d"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "5128390962016"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x7bcc82729f619a7d6ce27c2cc04a9ee92e91767d"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "205135638480646"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x7bcc82729f619a7d6ce27c2cc04a9ee92e91767d"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "5128390962016172"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x7bcc82729f619a7d6ce27c2cc04a9ee92e91767d"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "8000289900745229"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "16304054892204063" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225023", timeStamp: "1504223728", hash: "0x7a71fb626841cddb7c81673291bfd499af803875d472d2e2c76b9fde13c16860", nonce: "18", blockHash: "0xdfcae0522c157f748fe8fb73a4492ca5b1c923d763ecf67829972e1df3fa9ccb", transactionIndex: "42", from: "0x67e53197d892c209da1a32056d5e8be98475dfe2", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "4314717", gasUsed: "234421", confirmations: "3476560"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1504223728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x67e53197d892c209da1a32056d5e8be98475dfe2"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "21495808749219"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x67e53197d892c209da1a32056d5e8be98475dfe2"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "859832349968765"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x67e53197d892c209da1a32056d5e8be98475dfe2"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "21495808749219126"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x67e53197d892c209da1a32056d5e8be98475dfe2"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "33533461648781837"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "406589652386928" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225038", timeStamp: "1504224059", hash: "0x450214616720077b292ab9fef8efcef0afddab5b2a9bff67eed7349f0acabc72", nonce: "4", blockHash: "0xea6e8332b1c45672905e97caf33a67934533278648a224ea276272ac8c836442", transactionIndex: "203", from: "0xd28f732b12947f2de3718c43be4d2954a492e30c", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "6193322", gasUsed: "234421", confirmations: "3476545"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1504224059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd28f732b12947f2de3718c43be4d2954a492e30c"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "22077294373234"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd28f732b12947f2de3718c43be4d2954a492e30c"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "883091774929381"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd28f732b12947f2de3718c43be4d2954a492e30c"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "22077294373234540"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd28f732b12947f2de3718c43be4d2954a492e30c"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "34440579222245882"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "35722318664783037" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225038", timeStamp: "1504224059", hash: "0xf8252901f440dc6913d57473a9035c1a2b9adcea9095e060ac78da131fd8a8a0", nonce: "68", blockHash: "0xea6e8332b1c45672905e97caf33a67934533278648a224ea276272ac8c836442", transactionIndex: "204", from: "0xa25942d870dc984d2483fab0f731af6fbb5e1479", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "6427743", gasUsed: "234421", confirmations: "3476545"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1504224059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa25942d870dc984d2483fab0f731af6fbb5e1479"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "131727077207274"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa25942d870dc984d2483fab0f731af6fbb5e1479"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "5269083088290970"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa25942d870dc984d2483fab0f731af6fbb5e1479"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "131727077207274253"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa25942d870dc984d2483fab0f731af6fbb5e1479"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "205494240443347834"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "2128900235786204970" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225057", timeStamp: "1504224675", hash: "0x9cfae06cb5689203b8f4a713303965afd7059d5b888f8011665247aa93c0c61c", nonce: "218", blockHash: "0x53f9ee58aa552ebafbb2454107571ede2abd8274a779845f3ef86803b95a3fd2", transactionIndex: "3", from: "0x1f24b1b0d4121317e427fd0149ee5207d54a7a62", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "297421", gasUsed: "234421", confirmations: "3476526"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1504224675 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1f24b1b0d4121317e427fd0149ee5207d54a7a62"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "45994810140265"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1f24b1b0d4121317e427fd0149ee5207d54a7a62"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "1839792405610637"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1f24b1b0d4121317e427fd0149ee5207d54a7a62"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "45994810140265930"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x1f24b1b0d4121317e427fd0149ee5207d54a7a62"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "71751903818814851"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "35678169691558797" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225082", timeStamp: "1504225287", hash: "0x2b2c70d373547a534cceb349ffcb4234790b9e054409d03a99b69d9da6a1811e", nonce: "20", blockHash: "0x779accfbdfc95f992e18a596ee677fd4324bc368b0c69c1d57fff3321d65904b", transactionIndex: "13", from: "0x3b7ab3521d9ad91d62a92a0570c24d4328a6f69a", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "1035681", gasUsed: "234421", confirmations: "3476501"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1504225287 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x3b7ab3521d9ad91d62a92a0570c24d4328a6f69a"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "929187589249"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x3b7ab3521d9ad91d62a92a0570c24d4328a6f69a"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "37167503569981"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x3b7ab3521d9ad91d62a92a0570c24d4328a6f69a"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "929187589249547"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x3b7ab3521d9ad91d62a92a0570c24d4328a6f69a"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "1449532639229293"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225088", timeStamp: "1504225398", hash: "0xac4c76cf4ac8ed2de665a154dc7b2461dc020630f7273f0846a83820c8fa51df", nonce: "65", blockHash: "0x54523c546c2fe60e9e7d77c87adf990d284b9ebf0ef219aac39dede35deab7db", transactionIndex: "28", from: "0x022b66c7fd8ab5f1a9636c4608b4bdf3d453a050", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "1312299", gasUsed: "234421", confirmations: "3476495"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1504225398 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x022b66c7fd8ab5f1a9636c4608b4bdf3d453a050"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "382029442041246"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x022b66c7fd8ab5f1a9636c4608b4bdf3d453a050"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "15281177681649841"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x022b66c7fd8ab5f1a9636c4608b4bdf3d453a050"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "382029442041246033"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x022b66c7fd8ab5f1a9636c4608b4bdf3d453a050"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "595965929584343812"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "47088693749280932" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225125", timeStamp: "1504226074", hash: "0xde5181f8a25890a6122079a9996cb03df4b1f9f441830f49d41b108c2067d1e1", nonce: "220", blockHash: "0x569158fde047d0c7f9ab344dc9cc1428334ee900a7ba03daae70f6824aaa56e3", transactionIndex: "50", from: "0xa0be78d2bac6a692adba423c7af50ec86a18bddf", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "5614185", gasUsed: "234421", confirmations: "3476458"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1504226074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa0be78d2bac6a692adba423c7af50ec86a18bddf"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "174375476370617"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa0be78d2bac6a692adba423c7af50ec86a18bddf"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "6975019054824718"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa0be78d2bac6a692adba423c7af50ec86a18bddf"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "174375476370617971"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa0be78d2bac6a692adba423c7af50ec86a18bddf"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "272025743138164034"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "16813887732055554" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225164", timeStamp: "1504227190", hash: "0x343ab5ded24c7142b60619bbaa538c317597f7839532f508ef9de0eded49c9f5", nonce: "9", blockHash: "0x89f4d44023570cbade0c2ff7421469ac4797a12c81860f90e9692bc32833322f", transactionIndex: "230", from: "0x47d92e4cc562c7cfed8fd24f384b76f1d9dcf714", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "6629532", gasUsed: "234421", confirmations: "3476419"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1504227190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x47d92e4cc562c7cfed8fd24f384b76f1d9dcf714"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "114884114035782"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x47d92e4cc562c7cfed8fd24f384b76f1d9dcf714"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "4595364561431289"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x47d92e4cc562c7cfed8fd24f384b76f1d9dcf714"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "114884114035782234"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x47d92e4cc562c7cfed8fd24f384b76f1d9dcf714"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "179219217895820285"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "10134480829756402577" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225184", timeStamp: "1504227768", hash: "0x77b931a2f6d423080f4aea09c5490b8972853ca821d27736bad76c9de88e5c71", nonce: "2", blockHash: "0x7604a9cd960d0b76a89b2524668671d76281418954fd86b61ee745455699f77a", transactionIndex: "144", from: "0x6ac4c78a570c1b4c43110d4c6c456ce4f46c17c9", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "6258042", gasUsed: "234421", confirmations: "3476399"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1504227768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x6ac4c78a570c1b4c43110d4c6c456ce4f46c17c9"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "9053700147654"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x6ac4c78a570c1b4c43110d4c6c456ce4f46c17c9"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "362148005906193"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x6ac4c78a570c1b4c43110d4c6c456ce4f46c17c9"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "9053700147654829"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x6ac4c78a570c1b4c43110d4c6c456ce4f46c17c9"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "14123772230341534"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "54362960084050210" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225187", timeStamp: "1504227818", hash: "0xcb2a5ed1809d4020631e15d9e3589f8c69698be63f94b8f46c03dcd1befb537d", nonce: "605", blockHash: "0x9c93a534d9ab31933115a231ec90ff7bc0a3dc9e09253eb0cc589a9b60bb7a2b", transactionIndex: "3", from: "0x4b43041e418b16bb7dcf94a09f721cc73574fc04", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "332331", gasUsed: "234421", confirmations: "3476396"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1504227818 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x4b43041e418b16bb7dcf94a09f721cc73574fc04"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "2548117791036"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x4b43041e418b16bb7dcf94a09f721cc73574fc04"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "101924711641477"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x4b43041e418b16bb7dcf94a09f721cc73574fc04"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "2548117791036939"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x4b43041e418b16bb7dcf94a09f721cc73574fc04"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "3975063754017626"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "690788424092789676" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225215", timeStamp: "1504228524", hash: "0x927f3c3c3897ac1253da9ed364d82e50afbd1a36eb817d87d57d6c59f6979cb7", nonce: "13", blockHash: "0x4d5ae915e006e1a2eff40a52ce9c325c48e78c4f5b2473c4ed07228ab0cc4f75", transactionIndex: "37", from: "0xee470c3d4153492c0566b184b272516cf5f1718f", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "1614101", gasUsed: "234421", confirmations: "3476368"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1504228524 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xee470c3d4153492c0566b184b272516cf5f1718f"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "152934124115791"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xee470c3d4153492c0566b184b272516cf5f1718f"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "6117364964631641"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xee470c3d4153492c0566b184b272516cf5f1718f"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "152934124115791046"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xee470c3d4153492c0566b184b272516cf5f1718f"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "238577233620634032"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "754572853409687042" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225221", timeStamp: "1504228679", hash: "0x8d408db4ff88d6ba77a90089de3f51c53c5ef2cb57db70e8beeccd3a803650d4", nonce: "15", blockHash: "0x4be77aae03fb0536ab09905060f55a4edf6d6498f60634d040d5e554bea2427c", transactionIndex: "66", from: "0xa106379acb22df279f1ac3c0299742531b3ba6ee", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2807569", gasUsed: "234421", confirmations: "3476362"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1504228679 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa106379acb22df279f1ac3c0299742531b3ba6ee"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "30556237998335"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa106379acb22df279f1ac3c0299742531b3ba6ee"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "1222249519933402"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa106379acb22df279f1ac3c0299742531b3ba6ee"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "30556237998335051"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xa106379acb22df279f1ac3c0299742531b3ba6ee"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "47667731277402679"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "345459919765943244" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225228", timeStamp: "1504228848", hash: "0x636db4240b26f7404e4e77dda2e23014717897b96091433c5a1265016475bf46", nonce: "12", blockHash: "0x693ae6edcf2342e3f351d9ceeee938aac2d75315f428393caf8d476aef7d7150", transactionIndex: "126", from: "0x239aa2d158695ac7282afaa90bbb0806e9466563", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3752069", gasUsed: "234421", confirmations: "3476355"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1504228848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x239aa2d158695ac7282afaa90bbb0806e9466563"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "3701005803602"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x239aa2d158695ac7282afaa90bbb0806e9466563"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "148040232144085"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x239aa2d158695ac7282afaa90bbb0806e9466563"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "3701005803602143"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x239aa2d158695ac7282afaa90bbb0806e9466563"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "5773569053619343"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "14707197499765787" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225261", timeStamp: "1504229560", hash: "0x1d81d23befef7f163626fae7d884ee432a716d9d7f4be1f7a6093331c75daedc", nonce: "46", blockHash: "0x184913adb0f4049eb329787af8139f3eda905f206a4244a9dbc4a0d06f7a8432", transactionIndex: "72", from: "0xbabfa0de0f5548778bfa219f0faeba8fb557a4fd", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3948333", gasUsed: "234421", confirmations: "3476322"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1504229560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbabfa0de0f5548778bfa219f0faeba8fb557a4fd"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "2136829658417"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbabfa0de0f5548778bfa219f0faeba8fb557a4fd"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "85473186336703"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbabfa0de0f5548778bfa219f0faeba8fb557a4fd"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "2136829658417577"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbabfa0de0f5548778bfa219f0faeba8fb557a4fd"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "3333454267131420"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "17707853070507172" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225267", timeStamp: "1504229768", hash: "0xcce01db9450ab801de3446fba8101d5b12d6119fac6b1a2e13c1d9c7e87b6556", nonce: "34", blockHash: "0x99caa84a33cc1d636867af2de09717097dfa503cefe8f678a1ed44f26f102d4c", transactionIndex: "68", from: "0xe5ae51871f3b58e4be4c29783d7ff8571473f488", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2482842", gasUsed: "234421", confirmations: "3476316"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1504229768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xe5ae51871f3b58e4be4c29783d7ff8571473f488"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "76990277224637"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xe5ae51871f3b58e4be4c29783d7ff8571473f488"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "3079611088985518"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xe5ae51871f3b58e4be4c29783d7ff8571473f488"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "76990277224637954"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xe5ae51871f3b58e4be4c29783d7ff8571473f488"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "120104832470435209"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "545035465677024283" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225285", timeStamp: "1504230300", hash: "0x18975f8cb00aacf757b2937e6b32f2bc5b60aee574930ae28a1e77ac406c07ce", nonce: "22", blockHash: "0x93596917f795b02acb1f8b42a36915d1171433043fc49774f64a76724f39c50f", transactionIndex: "101", from: "0x5383402964a33845a163f608dd142d29f6e842ea", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3369419", gasUsed: "234421", confirmations: "3476298"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1504230300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x5383402964a33845a163f608dd142d29f6e842ea"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "21533124675503"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x5383402964a33845a163f608dd142d29f6e842ea"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "861324987020135"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x5383402964a33845a163f608dd142d29f6e842ea"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "21533124675503379"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x5383402964a33845a163f608dd142d29f6e842ea"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "33591674493785271"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "316682000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225307", timeStamp: "1504230916", hash: "0xc9b2a5c01382fce7284d5310cea8417d7fe7e036ab64bb0ee1c6efda10ba62c7", nonce: "26", blockHash: "0x8401afec3366a12da17babe5c531190fe1b478e95eae6b0dfd1d70f494bd4fdd", transactionIndex: "81", from: "0x0656d8b7b1fcc09788f4a7b657b38a3a4eeb3f9b", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2959602", gasUsed: "234421", confirmations: "3476276"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1504230916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0656d8b7b1fcc09788f4a7b657b38a3a4eeb3f9b"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "12571185002318"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0656d8b7b1fcc09788f4a7b657b38a3a4eeb3f9b"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "502847400092720"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0656d8b7b1fcc09788f4a7b657b38a3a4eeb3f9b"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "12571185002318024"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x0656d8b7b1fcc09788f4a7b657b38a3a4eeb3f9b"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "19611048603616117"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "188771387168743441" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225326", timeStamp: "1504231364", hash: "0x34c04d1cf9e162d9ca916b9067aa98c115b032492a918a3c162e3f65610672b5", nonce: "0", blockHash: "0xa8a22043a017bec2492a5cb8b267abab91ce15432722490c836a488d9a8236ac", transactionIndex: "89", from: "0xbbd7e435b7ba2fd68e5de85887cee70d4ad35bba", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "6679245", gasUsed: "234421", confirmations: "3476257"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1504231364 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbbd7e435b7ba2fd68e5de85887cee70d4ad35bba"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "7909011368192"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbbd7e435b7ba2fd68e5de85887cee70d4ad35bba"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "316360454727713"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbbd7e435b7ba2fd68e5de85887cee70d4ad35bba"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "7909011368192849"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xbbd7e435b7ba2fd68e5de85887cee70d4ad35bba"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "12338057734380844"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "4643339068669598" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225343", timeStamp: "1504231820", hash: "0x22fc17a049ef253bee2ff6f8419d1a9ef71bf068bf4b768338be879373536612", nonce: "21", blockHash: "0x0a114128dc85437fe83ea2f190b44b7bf6b85d13895691702f0ac1d040c4174f", transactionIndex: "120", from: "0xcd07679a857c49b6cc0b1181a57a2f480a8ddf50", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "4312274", gasUsed: "234421", confirmations: "3476240"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1504231820 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd07679a857c49b6cc0b1181a57a2f480a8ddf50"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "774322991143"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd07679a857c49b6cc0b1181a57a2f480a8ddf50"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "30972919645729"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd07679a857c49b6cc0b1181a57a2f480a8ddf50"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "774322991143245"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xcd07679a857c49b6cc0b1181a57a2f480a8ddf50"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "1207943866183462"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "1143106804963744" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225348", timeStamp: "1504231911", hash: "0x83e9a4b86865510acdb05aacc25713016900ee969e6470290d4c06d5f01ac163", nonce: "157", blockHash: "0x161e72aa1977908ad02dc804f6c94dc74166c425061252f50989cc1aa2ec66fd", transactionIndex: "80", from: "0xd96ba8f3a69e1a5a8033fa2a0ba6d7b7c1346def", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "234630", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "2804878", gasUsed: "234421", confirmations: "3476235"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1504231911 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd96ba8f3a69e1a5a8033fa2a0ba6d7b7c1346def"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "94076447671434"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd96ba8f3a69e1a5a8033fa2a0ba6d7b7c1346def"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "3763057906857380"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd96ba8f3a69e1a5a8033fa2a0ba6d7b7c1346def"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "94076447671434521"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0xd96ba8f3a69e1a5a8033fa2a0ba6d7b7c1346def"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "146759258367437852"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "1358129538174959" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225355", timeStamp: "1504232094", hash: "0xc3774660852b674ad698683b92c45d16bb4899f963673e402a74985bcf473198", nonce: "22", blockHash: "0x15b79a2b23998ce0dcf8aa9abbcbfff1961e8463dfc9712d5ea788059e89b588", transactionIndex: "48", from: "0xcd07679a857c49b6cc0b1181a57a2f480a8ddf50", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "87045", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "3024315", gasUsed: "87045", confirmations: "3476228"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "1143106804963744" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: claimDividendAll(  )", async function( ) {
		const txOriginal = {blockNumber: "4225375", timeStamp: "1504232534", hash: "0x89501a1f001761e92e15015f70b3974463665bd115921f71168f73187ce30d34", nonce: "126", blockHash: "0xb09fa08e5248efb167e29bb51501976bfc5d8f33fef9a6b2fe69c6ed5a53f0c1", transactionIndex: "31", from: "0x76927e2ccab0084bd19cee74f78b63134b9d181e", to: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d", value: "0", gas: "351945", gasPrice: "10000000000", isError: "0", txreceipt_status: "", input: "0x30e1f16f", contractAddress: "", cumulativeGasUsed: "1963825", gasUsed: "234421", confirmations: "3476208"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimDividendAll", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimDividendAll()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1504232534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_claimer", type: "address"}, {indexed: false, name: "_dividendIndex", type: "uint256"}, {indexed: false, name: "_claim", type: "uint256"}], name: "DividendClaimed", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x76927e2ccab0084bd19cee74f78b63134b9d181e"}, {name: "_dividendIndex", type: "uint256", value: "0"}, {name: "_claim", type: "uint256", value: "30586824823158"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x76927e2ccab0084bd19cee74f78b63134b9d181e"}, {name: "_dividendIndex", type: "uint256", value: "1"}, {name: "_claim", type: "uint256", value: "1223472992926328"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x76927e2ccab0084bd19cee74f78b63134b9d181e"}, {name: "_dividendIndex", type: "uint256", value: "2"}, {name: "_claim", type: "uint256", value: "30586824823158209"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}, {name: "DividendClaimed", events: [{name: "_claimer", type: "address", value: "0x76927e2ccab0084bd19cee74f78b63134b9d181e"}, {name: "_dividendIndex", type: "uint256", value: "3"}, {name: "_claim", type: "uint256", value: "47715446724126806"}], address: "0x6822aaf4ab22e6cca8352a927b9ae0a8fdb58d9d"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "336904253593094" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "111783440307557526671" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
