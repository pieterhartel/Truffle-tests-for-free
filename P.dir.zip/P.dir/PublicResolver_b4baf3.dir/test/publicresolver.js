const PublicResolver = artifacts.require( "./PublicResolver.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PublicResolver" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xD3ddcCDD3b25A8a7423B5bEe360a42146eb4Baf3", "0x5D509F653d7e4914AF9da434bF25c53Cd122763D", "0x314159265dD8dbb310642f98f50C066173C1259b", "0xDDF369C3bf18b1B12EA295d597B943b955eF4671", "0x7FC92BAcd8e6382cB7d1D99B9b9788E7568F9ea6", "0x8ba1f109551bD432803012645Ac136ddd64DBA72", "0xaC0d092D7962d6d05FB7947951f10CE88E54759e", "0xe3262995F56373Ba2606cCF4f8FA9dCeF2104A7c", "0x0C784d3d7E35CaCB51Dc57d7200DF754FfD6C19E", "0xCA922531053831e4CD9B4671CCf103d2DAc1b671", "0x6719a70e3B9652d0Cd3D4Cd28A93556497e2bF96", "0x31e7E27EC175870c2b3396a0F0c7812E823ba33b", "0x16308dc5279EdCc5302BfA135BbF703bF003360D", "0x839395e20bbB182fa440d08F850E6c7A8f6F0780", "0xDa77eB50dA282bb1BC54a0677622854AeFE05B94", "0x610fdf7C708CE4CEC6732EE5e8275FAc36F9B880", "0xe12Aa5FB5659bb0DB3f488e29701fE303bcBAf65", "0xc895629d1EEE12eCe78fc3F20984895D8e6e1182", "0xEa2a5F1A7c0ca11C86f23dA424e1A71bb5984D5f", "0x5Bb35c9576Ef6E42d4447aDcb3272f0b8582E82e", "0xD66B0d2aA3a4775784d7Fb7f1A8Aca9a202a7ADF", "0xfBe3532b5b80922b7b01B58738bAfe89a5a226d4", "0xB74e01b50dE2c8Da3FECa59c636141A1A2560D58", "0x201dCa0C9a4321770C4cC26274A3aEF6f7175cd4", "0x4Fe992E566F8a28248acC4cB401b7FfD7dF959B0", "0xa30BebE9959E3e1340BD7C5f0Ac0aDC8e85fdaEE", "0xac374F3a37C8c4181084A2552410532748e7d02C", "0x8627E08C712EbdDd1b48f1a19234Fb1e47AB2654", "0x2d12330093c4ffe5faD36bcd1477f73c45a4913B", "0x2253830caCeD969A0Df94f2326BB71D05a94dAf5", "0x41c7b33b8E7Fec43e4F860F79c2a4314e3C54089", "0x2D2e6264d02c6E42153910CD02FC7F16Ac305079", "0x7afbf5Bb4771822126C0bc4d58EC21310834c55E", "0x2aC2b3C5588e98B5da17213d8C341219ffcE9AFD", "0xeA66A285392da2180A594DD0cAa7b857EB3a6bcB", "0x583EcDf42ABF8a1f89878dE66fae3227a0692A9a", "0x369799e8308Bfd8D32fe4709dB82af51e6F1cc60", "0x18C6045651826824FEBBD39d8560584078d1b247", "0x029AA204C017138a772aC69d10B195dA4c28cD84", "0x07C41Ef6a4EA96BA8D86FbfE95aaEdf1bcD48ddD", "0xB6dD16ebA7155cC2EA4Af77A69CFF8661E9fbb09", "0xae085DDd678f6dC7aA9C5d795453cc8753721F03", "0x1787e5aF30F7BaEAC0f5b0D001b15d9Fe210d9B9", "0x0a263AD57976Cf88f779fb4b8B790f929B185763", "0x6bAB1BD10Aa94431FF5d5bad537C93fCC2A78843", "0xdd6CA7D9D4d2A190a5C940F499Cb32494a6Fd31C", "0x3E5b1d302f18D1FB6D4e04d78F3E9D7bec2433AC"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "interfaceID", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "node", type: "bytes32"}, {name: "contentTypes", type: "uint256"}], name: "ABI", outputs: [{name: "contentType", type: "uint256"}, {name: "data", type: "bytes"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "node", type: "bytes32"}], name: "addr", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "node", type: "bytes32"}, {name: "key", type: "string"}], name: "text", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "node", type: "bytes32"}], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "node", type: "bytes32"}], name: "contenthash", outputs: [{name: "", type: "bytes"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "node", type: "bytes32"}], name: "pubkey", outputs: [{name: "x", type: "bytes32"}, {name: "y", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "name", type: "string"}], name: "NameChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: true, name: "contentType", type: "uint256"}], name: "ABIChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "x", type: "bytes32"}, {indexed: false, name: "y", type: "bytes32"}], name: "PubkeyChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "indexedKey", type: "string"}, {indexed: false, name: "key", type: "string"}], name: "TextChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "hash", type: "bytes"}], name: "ContenthashChanged", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["AddrChanged(bytes32,address)", "NameChanged(bytes32,string)", "ABIChanged(bytes32,uint256)", "PubkeyChanged(bytes32,bytes32,bytes32)", "TextChanged(bytes32,string,string)", "ContenthashChanged(bytes32,bytes)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x52d7d861f09ab3d26239d492e8968629f95e9e318cf0b73bfddc441522a15fd2", "0xb7d29e911041e8d9b843369e890bcb72c9388692ba48b65ac54e7214c4c348f7", "0xaa121bbeef5f32f5961a2a28966e769023910fc9479059ee3495d4c1a696efe3", "0x1d6f5e03d3f63eb58751986629a5439baee5079ff04f345becb66e23eb154e46", "0xd8c9334b1a9c2f9da342a0a2b32629c1a229b6445dad78947f674b44444a7550", "0xe379c1624ed7e714cc0937528a32359d69d5281337765313dba4e081b72d7578"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6705947 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6818625 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "ensAddr", value: 4}], name: "PublicResolver", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes4", name: "interfaceID", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "node", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "uint256", name: "contentTypes", value: random.range( maxRandom )}], name: "ABI", outputs: [{name: "contentType", type: "uint256"}, {name: "data", type: "bytes"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ABI(bytes32,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "node", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "addr", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addr(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "node", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "string", name: "key", value: random.string( maxRandom )}], name: "text", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "text(bytes32,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "node", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "node", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "contenthash", outputs: [{name: "", type: "bytes"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contenthash(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "node", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "pubkey", outputs: [{name: "x", type: "bytes32"}, {name: "y", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pubkey(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PublicResolver", function( accounts ) {

	it( "TEST: PublicResolver( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6705947", timeStamp: "1542241311", hash: "0xe2433a63e31859b264f1dbdf7a76a946ebaa3fb214bb526206e7045bdb60e8ae", nonce: "15", blockHash: "0x18c33531bf02cab5a0707fc14dc8cf15453a88a88b75a26b5c325e5e0bb38301", transactionIndex: "22", from: "0x5d509f653d7e4914af9da434bf25c53cd122763d", to: 0, value: "0", gas: "1985026", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xebb045fa000000000000000000000000314159265dd8dbb310642f98f50c066173c1259b", contractAddress: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", cumulativeGasUsed: "3219325", gasUsed: "1985026", confirmations: "1004312"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "ensAddr", value: addressList[4]}], name: "PublicResolver", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PublicResolver.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542241311 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PublicResolver.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "124297212176072291" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x553352698c449c2837b7c9c9654d23ee4ec2... )", async function( ) {
		const txOriginal = {blockNumber: "6709232", timeStamp: "1542288246", hash: "0x50fddd4e73c7f9840a779ac5da868b6c2df2e7d3f1906ee9fea3fdb7c5b7c72a", nonce: "2314", blockHash: "0xcc8968275a55937266f3bcd0751a1d4f90aa42fd9b0be2bcc5d4af1215ce3242", transactionIndex: "93", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00553352698c449c2837b7c9c9654d23ee4ec2eac990e7775f50372cd14bee72d20000000000000000000000007fc92bacd8e6382cb7d1d99b9b9788e7568f9ea6", contractAddress: "", cumulativeGasUsed: "4751401", gasUsed: "49499", confirmations: "1001027"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x553352698c449c2837b7c9c9654d23ee4ec2eac990e7775f50372cd14bee72d2"}, {type: "address", name: "addr", value: addressList[6]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x553352698c449c2837b7c9c9654d23ee4ec2eac990e7775f50372cd14bee72d2", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542288246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x553352698c449c2837b7c9c9654d23ee4ec2eac990e7775f50372cd14bee72d2"}, {name: "a", type: "address", value: "0x7fc92bacd8e6382cb7d1d99b9b9788e7568f9ea6"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xd1fc816e28b21d7a6cfcc223ca14f4c4392d... )", async function( ) {
		const txOriginal = {blockNumber: "6712079", timeStamp: "1542328468", hash: "0xc2344bca5d8ccf9b5d1e861a8a42fc50cac78dffb872932e64b1698c669a055c", nonce: "2317", blockHash: "0x0f39e37d520401dbf1445029187a6aecdfd166d62cf483cfb9ee5c737bb9d5b9", transactionIndex: "49", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "4100000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00d1fc816e28b21d7a6cfcc223ca14f4c4392dd290fe0c5c0f29701b571d0863860000000000000000000000008ba1f109551bd432803012645ac136ddd64dba72", contractAddress: "", cumulativeGasUsed: "3095279", gasUsed: "49499", confirmations: "998180"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xd1fc816e28b21d7a6cfcc223ca14f4c4392dd290fe0c5c0f29701b571d086386"}, {type: "address", name: "addr", value: addressList[7]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xd1fc816e28b21d7a6cfcc223ca14f4c4392dd290fe0c5c0f29701b571d086386", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542328468 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xd1fc816e28b21d7a6cfcc223ca14f4c4392dd290fe0c5c0f29701b571d086386"}, {name: "a", type: "address", value: "0x8ba1f109551bd432803012645ac136ddd64dba72"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x72a49fa620678d944f81a33cc8a65972aaaa... )", async function( ) {
		const txOriginal = {blockNumber: "6714168", timeStamp: "1542357129", hash: "0x80222b7ff6c0d38b1367166f96e9f741b00bee42ae24d970703af07bfc923724", nonce: "189", blockHash: "0x58589175411b75c532eb5314674ca32fa8ecef81c27e01be581e8243b2962d31", transactionIndex: "149", from: "0xac0d092d7962d6d05fb7947951f10ce88e54759e", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0072a49fa620678d944f81a33cc8a65972aaaaa251542f170ca42fde377b749147000000000000000000000000e3262995f56373ba2606ccf4f8fa9dcef2104a7c", contractAddress: "", cumulativeGasUsed: "6690006", gasUsed: "49499", confirmations: "996091"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x72a49fa620678d944f81a33cc8a65972aaaaa251542f170ca42fde377b749147"}, {type: "address", name: "addr", value: addressList[9]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x72a49fa620678d944f81a33cc8a65972aaaaa251542f170ca42fde377b749147", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542357129 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x72a49fa620678d944f81a33cc8a65972aaaaa251542f170ca42fde377b749147"}, {name: "a", type: "address", value: "0xe3262995f56373ba2606ccf4f8fa9dcef2104a7c"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "621643397182385581" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xa04cb7c600818494e298cfd48dd0340e86f5... )", async function( ) {
		const txOriginal = {blockNumber: "6714944", timeStamp: "1542367972", hash: "0x5e771fb38cddc9e77c6597a76478fbdb08e6f11acdd05027469736937e156def", nonce: "2320", blockHash: "0x5f6519afca1b439a9015347457ae9057eb04d5e47867adf00e0ba9ebfe9a6dc0", transactionIndex: "33", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00a04cb7c600818494e298cfd48dd0340e86f5e53dcb2181f29e27be14eabf3b950000000000000000000000000c784d3d7e35cacb51dc57d7200df754ffd6c19e", contractAddress: "", cumulativeGasUsed: "1122683", gasUsed: "49435", confirmations: "995315"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xa04cb7c600818494e298cfd48dd0340e86f5e53dcb2181f29e27be14eabf3b95"}, {type: "address", name: "addr", value: addressList[10]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xa04cb7c600818494e298cfd48dd0340e86f5e53dcb2181f29e27be14eabf3b95", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542367972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xa04cb7c600818494e298cfd48dd0340e86f5e53dcb2181f29e27be14eabf3b95"}, {name: "a", type: "address", value: "0x0c784d3d7e35cacb51dc57d7200df754ffd6c19e"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xaccaaf446875479f15f5f02a042aa277ff2f... )", async function( ) {
		const txOriginal = {blockNumber: "6716013", timeStamp: "1542383015", hash: "0x59307bb0e336b3207b8f8eacb87df4dd89447257a65cb98d82afa74466611a90", nonce: "2323", blockHash: "0xfa4f4f883d98fe4db6397d1830d38170ee60b1ab64cc2257dd24b5555faa9d0b", transactionIndex: "28", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00accaaf446875479f15f5f02a042aa277ff2fd6164a37afbdc171d97ad59c7dfc000000000000000000000000ca922531053831e4cd9b4671ccf103d2dac1b671", contractAddress: "", cumulativeGasUsed: "1315091", gasUsed: "49499", confirmations: "994246"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xaccaaf446875479f15f5f02a042aa277ff2fd6164a37afbdc171d97ad59c7dfc"}, {type: "address", name: "addr", value: addressList[11]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xaccaaf446875479f15f5f02a042aa277ff2fd6164a37afbdc171d97ad59c7dfc", addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542383015 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xaccaaf446875479f15f5f02a042aa277ff2fd6164a37afbdc171d97ad59c7dfc"}, {name: "a", type: "address", value: "0xca922531053831e4cd9b4671ccf103d2dac1b671"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xe5a83211495d31b14f915e9fc28e64159109... )", async function( ) {
		const txOriginal = {blockNumber: "6718042", timeStamp: "1542411951", hash: "0xb7f017a3ed04aa8b88fff23c8e40c569602547c39f817e1d63c5074875ff7324", nonce: "2326", blockHash: "0xb665eb7c8a04dfe1b9729fb85c529da0c69ae8103f83d939d09246d65f39039f", transactionIndex: "15", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00e5a83211495d31b14f915e9fc28e64159109abb5da0ee9a9f5c284d578db10570000000000000000000000006719a70e3b9652d0cd3d4cd28a93556497e2bf96", contractAddress: "", cumulativeGasUsed: "3197048", gasUsed: "49499", confirmations: "992217"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xe5a83211495d31b14f915e9fc28e64159109abb5da0ee9a9f5c284d578db1057"}, {type: "address", name: "addr", value: addressList[12]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xe5a83211495d31b14f915e9fc28e64159109abb5da0ee9a9f5c284d578db1057", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1542411951 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xe5a83211495d31b14f915e9fc28e64159109abb5da0ee9a9f5c284d578db1057"}, {name: "a", type: "address", value: "0x6719a70e3b9652d0cd3d4cd28a93556497e2bf96"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xb71248ed58fe868bc5b07a877ea9885d382e... )", async function( ) {
		const txOriginal = {blockNumber: "6721466", timeStamp: "1542460767", hash: "0x8c000133b1c230e6c78b426f3632759c5436443df52e933db85b41d4a176ef29", nonce: "2329", blockHash: "0xdd19ab81b906fb615d7499c46d0bd2de31c9092087505d845487e48bc7834bc3", transactionIndex: "8", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00b71248ed58fe868bc5b07a877ea9885d382ee1b0b92f23584cecf4334fdcd77500000000000000000000000031e7e27ec175870c2b3396a0f0c7812e823ba33b", contractAddress: "", cumulativeGasUsed: "418064", gasUsed: "49499", confirmations: "988793"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xb71248ed58fe868bc5b07a877ea9885d382ee1b0b92f23584cecf4334fdcd775"}, {type: "address", name: "addr", value: addressList[13]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xb71248ed58fe868bc5b07a877ea9885d382ee1b0b92f23584cecf4334fdcd775", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542460767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xb71248ed58fe868bc5b07a877ea9885d382ee1b0b92f23584cecf4334fdcd775"}, {name: "a", type: "address", value: "0x31e7e27ec175870c2b3396a0f0c7812e823ba33b"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xb0adbcf505d4c635a914623b3e92219cae50... )", async function( ) {
		const txOriginal = {blockNumber: "6722373", timeStamp: "1542473728", hash: "0x6477392e2f538c55902d75e46ba4651c0555ceb2356d51d0d23b36297686053f", nonce: "2332", blockHash: "0xe51f36f6d7f7212952ecba57d42ae335dba8413491be59d7b6bb8c54b77b3aa2", transactionIndex: "38", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00b0adbcf505d4c635a914623b3e92219cae503badef3a8b72561a4be191e2a53600000000000000000000000016308dc5279edcc5302bfa135bbf703bf003360d", contractAddress: "", cumulativeGasUsed: "1702949", gasUsed: "49499", confirmations: "987886"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xb0adbcf505d4c635a914623b3e92219cae503badef3a8b72561a4be191e2a536"}, {type: "address", name: "addr", value: addressList[14]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xb0adbcf505d4c635a914623b3e92219cae503badef3a8b72561a4be191e2a536", addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542473728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xb0adbcf505d4c635a914623b3e92219cae503badef3a8b72561a4be191e2a536"}, {name: "a", type: "address", value: "0x16308dc5279edcc5302bfa135bbf703bf003360d"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x0721a68bec888f1e922f5ac3361b185b8675... )", async function( ) {
		const txOriginal = {blockNumber: "6730699", timeStamp: "1542590590", hash: "0xd470fc64dafe9b4213b70fed480dec6dfa19794992f8b75f87ec5ee681b4ced3", nonce: "1862", blockHash: "0xb45bdd125cf9479a14f5fb3954109c042795d4747c96e4053e13fae6c3cfe316", transactionIndex: "78", from: "0x839395e20bbb182fa440d08f850e6c7a8f6f0780", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b000721a68bec888f1e922f5ac3361b185b8675b7a3f5516bc31d8a46e8607e4235000000000000000000000000da77eb50da282bb1bc54a0677622854aefe05b94", contractAddress: "", cumulativeGasUsed: "6499686", gasUsed: "49499", confirmations: "979560"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x0721a68bec888f1e922f5ac3361b185b8675b7a3f5516bc31d8a46e8607e4235"}, {type: "address", name: "addr", value: addressList[16]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x0721a68bec888f1e922f5ac3361b185b8675b7a3f5516bc31d8a46e8607e4235", addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542590590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x0721a68bec888f1e922f5ac3361b185b8675b7a3f5516bc31d8a46e8607e4235"}, {name: "a", type: "address", value: "0xda77eb50da282bb1bc54a0677622854aefe05b94"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "32474058800498165913" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x7d1b9116219aa695690e49081a67dc3de1f6... )", async function( ) {
		const txOriginal = {blockNumber: "6730702", timeStamp: "1542590621", hash: "0xee9829dc906117a76759c3e65ec78250d18b4f1d3cc2d80ae9abcb6f2b973cd4", nonce: "1863", blockHash: "0xb36ab39b57d6cd62af4f4b4a43189e6d548029cfa0319831a9a9559ebf4200c8", transactionIndex: "32", from: "0x839395e20bbb182fa440d08f850e6c7a8f6f0780", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "2500000100", isError: "0", txreceipt_status: "1", input: "0xd5fa2b007d1b9116219aa695690e49081a67dc3de1f67ed22fb7a0906b3b76be4ada0345000000000000000000000000da77eb50da282bb1bc54a0677622854aefe05b94", contractAddress: "", cumulativeGasUsed: "4816385", gasUsed: "49499", confirmations: "979557"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x7d1b9116219aa695690e49081a67dc3de1f67ed22fb7a0906b3b76be4ada0345"}, {type: "address", name: "addr", value: addressList[16]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x7d1b9116219aa695690e49081a67dc3de1f67ed22fb7a0906b3b76be4ada0345", addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1542590621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x7d1b9116219aa695690e49081a67dc3de1f67ed22fb7a0906b3b76be4ada0345"}, {name: "a", type: "address", value: "0xda77eb50da282bb1bc54a0677622854aefe05b94"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "32474058800498165913" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x69492d212a6d038b96b9433013045fa5ca46... )", async function( ) {
		const txOriginal = {blockNumber: "6734526", timeStamp: "1542645521", hash: "0xc2797cb752c6618fc1c522024820aeb1ebf9cd405e9de8d78d77de3d17bd25ae", nonce: "2335", blockHash: "0xed3fd4abcb2a1cb69b6fe1c99a3818b1b19a92678a7172ef2d7890a8d3000ba5", transactionIndex: "171", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0069492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c000000000000000000000000610fdf7c708ce4cec6732ee5e8275fac36f9b880", contractAddress: "", cumulativeGasUsed: "7059834", gasUsed: "49499", confirmations: "975733"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x69492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c"}, {type: "address", name: "addr", value: addressList[17]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x69492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1542645521 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x69492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c"}, {name: "a", type: "address", value: "0x610fdf7c708ce4cec6732ee5e8275fac36f9b880"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x69492d212a6d038b96b9433013045fa5ca46... )", async function( ) {
		const txOriginal = {blockNumber: "6734541", timeStamp: "1542645722", hash: "0xaf59369d5966d4f3fff3d596b154b6659906ee563d5c6858a9a12617bccd6baf", nonce: "2338", blockHash: "0x2d369fb87dfdb6c2ea479ad8cf1b1f648124a5a0d1f71c9d0c3fe7ced0d6d22b", transactionIndex: "95", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0069492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c000000000000000000000000610fdf7c708ce4cec6732ee5e8275fac36f9b880", contractAddress: "", cumulativeGasUsed: "4598402", gasUsed: "34499", confirmations: "975718"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x69492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c"}, {type: "address", name: "addr", value: addressList[17]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x69492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c", addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542645722 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x69492d212a6d038b96b9433013045fa5ca46ded7afef20b91805682adfd93c7c"}, {name: "a", type: "address", value: "0x610fdf7c708ce4cec6732ee5e8275fac36f9b880"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x9086458b03eda6d157f07728f5aaa91344d3... )", async function( ) {
		const txOriginal = {blockNumber: "6735402", timeStamp: "1542658136", hash: "0xa4fcbe514bffe22d0680fe7f688d6ebd13a66ea4020408156229e2568b34c015", nonce: "2341", blockHash: "0x4232991458548cb27e65da0149032f9c6aee4bdc9e4f8d5065086251d71d6a1d", transactionIndex: "48", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b009086458b03eda6d157f07728f5aaa91344d3a0eb937597b48f90aad2ab808d95000000000000000000000000e12aa5fb5659bb0db3f488e29701fe303bcbaf65", contractAddress: "", cumulativeGasUsed: "3417165", gasUsed: "49499", confirmations: "974857"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x9086458b03eda6d157f07728f5aaa91344d3a0eb937597b48f90aad2ab808d95"}, {type: "address", name: "addr", value: addressList[18]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x9086458b03eda6d157f07728f5aaa91344d3a0eb937597b48f90aad2ab808d95", addressList[18], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542658136 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x9086458b03eda6d157f07728f5aaa91344d3a0eb937597b48f90aad2ab808d95"}, {name: "a", type: "address", value: "0xe12aa5fb5659bb0db3f488e29701fe303bcbaf65"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x66f7f9d54e8c6a5ba8d1371e9cbe6c79ef8f... )", async function( ) {
		const txOriginal = {blockNumber: "6737887", timeStamp: "1542693439", hash: "0xdcb78e88d111e180eb15f45a28624b794fcef99684ac4667af5009082af3197f", nonce: "2344", blockHash: "0xfa0dda1f1d91703ab37e4ea558e711bd83c2f013e58b4a5cf63e10f41e9f1f1f", transactionIndex: "160", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0066f7f9d54e8c6a5ba8d1371e9cbe6c79ef8f8156a5fd59cdee86e7171f5ade5c000000000000000000000000c895629d1eee12ece78fc3f20984895d8e6e1182", contractAddress: "", cumulativeGasUsed: "6472562", gasUsed: "49499", confirmations: "972372"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x66f7f9d54e8c6a5ba8d1371e9cbe6c79ef8f8156a5fd59cdee86e7171f5ade5c"}, {type: "address", name: "addr", value: addressList[19]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x66f7f9d54e8c6a5ba8d1371e9cbe6c79ef8f8156a5fd59cdee86e7171f5ade5c", addressList[19], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542693439 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x66f7f9d54e8c6a5ba8d1371e9cbe6c79ef8f8156a5fd59cdee86e7171f5ade5c"}, {name: "a", type: "address", value: "0xc895629d1eee12ece78fc3f20984895d8e6e1182"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xe8aa63145d6f614d9489d8f286367097a328... )", async function( ) {
		const txOriginal = {blockNumber: "6740138", timeStamp: "1542725756", hash: "0xbb34b5a01fe3cc5eefb70e94be00ef55b273a14aa36b8b2d35c55d096a791a61", nonce: "11", blockHash: "0xa622e4e7a96961a00e88356b0f8fba3d3deb85999dcf8f9f5b2eb614f3531c5c", transactionIndex: "104", from: "0xea2a5f1a7c0ca11c86f23da424e1a71bb5984d5f", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00e8aa63145d6f614d9489d8f286367097a328e71c136faf64f1f7ceb968ca3fda000000000000000000000000ea2a5f1a7c0ca11c86f23da424e1a71bb5984d5f", contractAddress: "", cumulativeGasUsed: "6181005", gasUsed: "49499", confirmations: "970121"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xe8aa63145d6f614d9489d8f286367097a328e71c136faf64f1f7ceb968ca3fda"}, {type: "address", name: "addr", value: addressList[20]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xe8aa63145d6f614d9489d8f286367097a328e71c136faf64f1f7ceb968ca3fda", addressList[20], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542725756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xe8aa63145d6f614d9489d8f286367097a328e71c136faf64f1f7ceb968ca3fda"}, {name: "a", type: "address", value: "0xea2a5f1a7c0ca11c86f23da424e1a71bb5984d5f"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "31911014778000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6740628", timeStamp: "1542733078", hash: "0xa9f773d4f391e2721af822e093d0d245f614cff2b3c6dd550299e96b4b6292f9", nonce: "14", blockHash: "0x8146245cef76a591aecca347c21647b5053fec4579a13f5b892c4a60226010cb", transactionIndex: "1", from: "0xea2a5f1a7c0ca11c86f23da424e1a71bb5984d5f", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "7603716", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0xc3d014d6e8aa63145d6f614d9489d8f286367097a328e71c136faf64f1f7ceb968ca3fdac01224491ad5a8278719c43d6c5667ebc289a9098f5d72b045bca4a9750aa96b", contractAddress: "", cumulativeGasUsed: "80510", gasUsed: "25979", confirmations: "969631"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542733078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "31911014778000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xde6cc29dadcd99034b0040b2c008c2d3c24f... )", async function( ) {
		const txOriginal = {blockNumber: "6742900", timeStamp: "1542765067", hash: "0xf92f809b36a44df32c9f2b22be44fb1077cb904a2c6bf6e3a93084476cf15c73", nonce: "2347", blockHash: "0x5ca3e0bc00ef05fdc24381e1edf0eec91c7a6aa1aa0b6971aeeb74847bef97df", transactionIndex: "42", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00de6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc0000000000000000000000005bb35c9576ef6e42d4447adcb3272f0b8582e82e", contractAddress: "", cumulativeGasUsed: "4038496", gasUsed: "49435", confirmations: "967359"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xde6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc"}, {type: "address", name: "addr", value: addressList[21]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xde6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc", addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542765067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xde6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc"}, {name: "a", type: "address", value: "0x5bb35c9576ef6e42d4447adcb3272f0b8582e82e"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xde6cc29dadcd99034b0040b2c008c2d3c24f... )", async function( ) {
		const txOriginal = {blockNumber: "6742904", timeStamp: "1542765159", hash: "0xf19d92288a1b40c258b355ac25d7f47c399570a8551ce4bb63f889591dc6d744", nonce: "2350", blockHash: "0x258307bcd9723550250d5696234701ddd7710d48c41378734f83e23f2c3fb57e", transactionIndex: "48", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00de6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc0000000000000000000000005bb35c9576ef6e42d4447adcb3272f0b8582e82e", contractAddress: "", cumulativeGasUsed: "2763630", gasUsed: "34435", confirmations: "967355"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xde6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc"}, {type: "address", name: "addr", value: addressList[21]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xde6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc", addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542765159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xde6cc29dadcd99034b0040b2c008c2d3c24f133190714ed185ebb816215e1ccc"}, {name: "a", type: "address", value: "0x5bb35c9576ef6e42d4447adcb3272f0b8582e82e"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x6d1f3adeae3c2f3892eaf7872b6c72bb7cb0... )", async function( ) {
		const txOriginal = {blockNumber: "6743462", timeStamp: "1542773059", hash: "0xc847c7bcf205034fe5a1a69faa467ba7c11bf530db2fe57d6a6759a255d395df", nonce: "2353", blockHash: "0x9ddb4d834fa84eb88fa654aef5cc4051a458cf699f69e723d261c670c85e09b3", transactionIndex: "108", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6800000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b006d1f3adeae3c2f3892eaf7872b6c72bb7cb0547acb88a82b175f7d2164a00ca7000000000000000000000000d66b0d2aa3a4775784d7fb7f1a8aca9a202a7adf", contractAddress: "", cumulativeGasUsed: "6040734", gasUsed: "49499", confirmations: "966797"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x6d1f3adeae3c2f3892eaf7872b6c72bb7cb0547acb88a82b175f7d2164a00ca7"}, {type: "address", name: "addr", value: addressList[22]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x6d1f3adeae3c2f3892eaf7872b6c72bb7cb0547acb88a82b175f7d2164a00ca7", addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542773059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x6d1f3adeae3c2f3892eaf7872b6c72bb7cb0547acb88a82b175f7d2164a00ca7"}, {name: "a", type: "address", value: "0xd66b0d2aa3a4775784d7fb7f1a8aca9a202a7adf"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x03ed9e91eaa78cf8a6a5340740161e46957b... )", async function( ) {
		const txOriginal = {blockNumber: "6747667", timeStamp: "1542832990", hash: "0x07893d42ee173cd90df9a2b2ac617a6a4ed5d37ccada9cd120de5aee6330484d", nonce: "2356", blockHash: "0xa1a1bbfd2664cb575260cfd97684610e60ba96c260269e72bafb1cb94cf6d463", transactionIndex: "37", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0003ed9e91eaa78cf8a6a5340740161e46957bcc15b0acb75a3e6fa71e976708c8000000000000000000000000fbe3532b5b80922b7b01b58738bafe89a5a226d4", contractAddress: "", cumulativeGasUsed: "2234457", gasUsed: "49499", confirmations: "962592"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x03ed9e91eaa78cf8a6a5340740161e46957bcc15b0acb75a3e6fa71e976708c8"}, {type: "address", name: "addr", value: addressList[23]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x03ed9e91eaa78cf8a6a5340740161e46957bcc15b0acb75a3e6fa71e976708c8", addressList[23], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542832990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x03ed9e91eaa78cf8a6a5340740161e46957bcc15b0acb75a3e6fa71e976708c8"}, {name: "a", type: "address", value: "0xfbe3532b5b80922b7b01b58738bafe89a5a226d4"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xc8f4601a342ec4fe6f60977db2381077e17f... )", async function( ) {
		const txOriginal = {blockNumber: "6748180", timeStamp: "1542840016", hash: "0xf49549fd8588ae58a94b025a47977017aba00e4f09f26c9abec4a5ef48910482", nonce: "4", blockHash: "0xeb0d2b22a36e657c01301a310e535edd6b5e568a7ab10929491aee160074b9a9", transactionIndex: "128", from: "0xb74e01b50de2c8da3feca59c636141a1a2560d58", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00c8f4601a342ec4fe6f60977db2381077e17fad01a2909ae37683afab65597aa6000000000000000000000000b74e01b50de2c8da3feca59c636141a1a2560d58", contractAddress: "", cumulativeGasUsed: "7625493", gasUsed: "49499", confirmations: "962079"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xc8f4601a342ec4fe6f60977db2381077e17fad01a2909ae37683afab65597aa6"}, {type: "address", name: "addr", value: addressList[24]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xc8f4601a342ec4fe6f60977db2381077e17fad01a2909ae37683afab65597aa6", addressList[24], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542840016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xc8f4601a342ec4fe6f60977db2381077e17fad01a2909ae37683afab65597aa6"}, {name: "a", type: "address", value: "0xb74e01b50de2c8da3feca59c636141a1a2560d58"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "82973536000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setName( \"0xe0b4b0e015d750e6fe4d8a54c4163e9fdf17... )", async function( ) {
		const txOriginal = {blockNumber: "6748235", timeStamp: "1542840764", hash: "0x4d3bb130aa37fa1533e56fda51efc9197ff259f5c3d345d4715d486d1c16f4a3", nonce: "6", blockHash: "0xd9b382b5a932c81b9502dd318d2baf2e902ac396423a0c132ea3df0048dca173", transactionIndex: "39", from: "0xb74e01b50de2c8da3feca59c636141a1a2560d58", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "75979", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x77372213e0b4b0e015d750e6fe4d8a54c4163e9fdf1766bbb9d7769d339d98d2c0f5373d0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000c676f74686d6f74682e6574680000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2486374", gasUsed: "50653", confirmations: "962024"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xe0b4b0e015d750e6fe4d8a54c4163e9fdf1766bbb9d7769d339d98d2c0f5373d"}, {type: "string", name: "name", value: `gothmoth.eth`}], name: "setName", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setName(bytes32,string)" ]( "0xe0b4b0e015d750e6fe4d8a54c4163e9fdf1766bbb9d7769d339d98d2c0f5373d", `gothmoth.eth`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542840764 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "name", type: "string"}], name: "NameChanged", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NameChanged", events: [{name: "node", type: "bytes32", value: "0xe0b4b0e015d750e6fe4d8a54c4163e9fdf1766bbb9d7769d339d98d2c0f5373d"}, {name: "name", type: "string", value: "gothmoth.eth"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "82973536000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x49cefd37093a8623c4959d53be617ecac46b... )", async function( ) {
		const txOriginal = {blockNumber: "6748564", timeStamp: "1542845165", hash: "0x46efe8ab027e706dd2572cc93d1fe1479020ebfc39a969f8585bf787db31d668", nonce: "2359", blockHash: "0x83198a2c8f24ca3e60a50b8d54a32620c694023cbac3d1c2ecc84d84f1c0bf2b", transactionIndex: "67", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0049cefd37093a8623c4959d53be617ecac46bcda80ee4048aaf684414df7fc0d7000000000000000000000000201dca0c9a4321770c4cc26274a3aef6f7175cd4", contractAddress: "", cumulativeGasUsed: "4603283", gasUsed: "49499", confirmations: "961695"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x49cefd37093a8623c4959d53be617ecac46bcda80ee4048aaf684414df7fc0d7"}, {type: "address", name: "addr", value: addressList[25]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x49cefd37093a8623c4959d53be617ecac46bcda80ee4048aaf684414df7fc0d7", addressList[25], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542845165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x49cefd37093a8623c4959d53be617ecac46bcda80ee4048aaf684414df7fc0d7"}, {name: "a", type: "address", value: "0x201dca0c9a4321770c4cc26274a3aef6f7175cd4"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6749106", timeStamp: "1542852952", hash: "0x653f48e2443b3ba05bacf74df0a9a13c7ebf671adc57263dcd92ea43e3be2413", nonce: "97", blockHash: "0xe9fdab979e9d1fe1a51306943d2a39d38a77ae428285dcf3c56e126376fcf5ee", transactionIndex: "91", from: "0x4fe992e566f8a28248acc4cb401b7ffd7df959b0", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xc3d014d6f7c9b153f4a6ff8a0e507938f8fb6f4c7b1c55229c1460f545f790f6a58ba27f64383930363536353336373964376137313032616565366638623436626434383465376166653735646261663838633936363062383931666363353535316334", contractAddress: "", cumulativeGasUsed: "7274414", gasUsed: "28155", confirmations: "961153"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542852952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "189401910889615600" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6749131", timeStamp: "1542853238", hash: "0x1b039bacef615f8227f8a303cf95f5e442ca0a297a41c603d38ca3921acd7912", nonce: "98", blockHash: "0x5cdc192195ae98323273b0261d6f5ad2648db7ee859a91902948fd34925185d2", transactionIndex: "79", from: "0x4fe992e566f8a28248acc4cb401b7ffd7df959b0", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xc3d014d6f7c9b153f4a6ff8a0e507938f8fb6f4c7b1c55229c1460f545f790f6a58ba27fd89065653679d7a7102aee6f8b46bd484e7afe75dbaf88c9660b891fcc5551c4", contractAddress: "", cumulativeGasUsed: "7651305", gasUsed: "25979", confirmations: "961128"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542853238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "189401910889615600" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x78f53719ab5667e610898705efada314b560... )", async function( ) {
		const txOriginal = {blockNumber: "6751973", timeStamp: "1542894375", hash: "0xa929af4b1e8b79a09cb5cafa309b8c4928dd5beb742e72860ea3e7311fadd138", nonce: "2362", blockHash: "0xc89671a05f68e7c7dbe56d0aced2d3a88ebc36aec222d56877efb41b11741403", transactionIndex: "53", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0078f53719ab5667e610898705efada314b560e42aa538a94d279035cc1107498a000000000000000000000000a30bebe9959e3e1340bd7c5f0ac0adc8e85fdaee", contractAddress: "", cumulativeGasUsed: "2892873", gasUsed: "49499", confirmations: "958286"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x78f53719ab5667e610898705efada314b560e42aa538a94d279035cc1107498a"}, {type: "address", name: "addr", value: addressList[27]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x78f53719ab5667e610898705efada314b560e42aa538a94d279035cc1107498a", addressList[27], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542894375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x78f53719ab5667e610898705efada314b560e42aa538a94d279035cc1107498a"}, {name: "a", type: "address", value: "0xa30bebe9959e3e1340bd7c5f0ac0adc8e85fdaee"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x92596ef767a07cf79c80d10ffa86fdb2ed29... )", async function( ) {
		const txOriginal = {blockNumber: "6752584", timeStamp: "1542903007", hash: "0x6332597dc76b01340447807223674cb8f36ab7fc71c27468195f9214183161f2", nonce: "204", blockHash: "0x9fdf986e257334a0e86951a7f9ed4258cc8f523d1f81ed417b1393fa665cb0f0", transactionIndex: "103", from: "0xac0d092d7962d6d05fb7947951f10ce88e54759e", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0092596ef767a07cf79c80d10ffa86fdb2ed29325036b40c140a542f2d78c788c1000000000000000000000000ac374f3a37c8c4181084a2552410532748e7d02c", contractAddress: "", cumulativeGasUsed: "5950899", gasUsed: "49499", confirmations: "957675"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x92596ef767a07cf79c80d10ffa86fdb2ed29325036b40c140a542f2d78c788c1"}, {type: "address", name: "addr", value: addressList[28]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x92596ef767a07cf79c80d10ffa86fdb2ed29325036b40c140a542f2d78c788c1", addressList[28], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542903007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x92596ef767a07cf79c80d10ffa86fdb2ed29325036b40c140a542f2d78c788c1"}, {name: "a", type: "address", value: "0xac374f3a37c8c4181084a2552410532748e7d02c"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "621643397182385581" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x719b2d39f3b2c411e5f0e24fa290149519ed... )", async function( ) {
		const txOriginal = {blockNumber: "6752609", timeStamp: "1542903312", hash: "0xa8d8bc2af8cd9d5cb70b5770a8ad42ce1d3e88d5416f23d14adcc2efc0291211", nonce: "205", blockHash: "0x88e1958554d5455e0f8e4194ac5755f1a3503064e61128dfa956d419005dcc18", transactionIndex: "207", from: "0xac0d092d7962d6d05fb7947951f10ce88e54759e", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00719b2d39f3b2c411e5f0e24fa290149519ed796de08c2aa6f9f516edaa5094fa0000000000000000000000008627e08c712ebddd1b48f1a19234fb1e47ab2654", contractAddress: "", cumulativeGasUsed: "7908301", gasUsed: "49499", confirmations: "957650"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x719b2d39f3b2c411e5f0e24fa290149519ed796de08c2aa6f9f516edaa5094fa"}, {type: "address", name: "addr", value: addressList[29]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x719b2d39f3b2c411e5f0e24fa290149519ed796de08c2aa6f9f516edaa5094fa", addressList[29], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542903312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x719b2d39f3b2c411e5f0e24fa290149519ed796de08c2aa6f9f516edaa5094fa"}, {name: "a", type: "address", value: "0x8627e08c712ebddd1b48f1a19234fb1e47ab2654"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "621643397182385581" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xc5be6154d3aed08b3bfbd860ea9a85811588... )", async function( ) {
		const txOriginal = {blockNumber: "6752620", timeStamp: "1542903441", hash: "0x10165b8b5c50c918003d2ccdb6068d52820de848f55a9231deb56b018665dc6a", nonce: "206", blockHash: "0x44dbd22b5c58d776f6ce08478b0cbea5f20d418d88ce29f3d6fc9f64177b85ee", transactionIndex: "181", from: "0xac0d092d7962d6d05fb7947951f10ce88e54759e", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74152", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00c5be6154d3aed08b3bfbd860ea9a85811588be87ce89da3a83d13ffe8c7e93030000000000000000000000002d12330093c4ffe5fad36bcd1477f73c45a4913b", contractAddress: "", cumulativeGasUsed: "7411176", gasUsed: "49435", confirmations: "957639"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xc5be6154d3aed08b3bfbd860ea9a85811588be87ce89da3a83d13ffe8c7e9303"}, {type: "address", name: "addr", value: addressList[30]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xc5be6154d3aed08b3bfbd860ea9a85811588be87ce89da3a83d13ffe8c7e9303", addressList[30], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542903441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xc5be6154d3aed08b3bfbd860ea9a85811588be87ce89da3a83d13ffe8c7e9303"}, {name: "a", type: "address", value: "0x2d12330093c4ffe5fad36bcd1477f73c45a4913b"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "621643397182385581" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x5e8010238cc0eb3dea1cf1054f4c80d80d6f... )", async function( ) {
		const txOriginal = {blockNumber: "6757169", timeStamp: "1542967558", hash: "0x6e68c087ac6216197a4c5c149e6ec7fd95f669fc3a200ba80a17094d3a1a66d1", nonce: "2365", blockHash: "0x97c3f8fa403ff4d4d656887c164d2026bc3bcb473e221ad88039d457b764fe25", transactionIndex: "21", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b005e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f51756250000000000000000000000002253830caced969a0df94f2326bb71d05a94daf5", contractAddress: "", cumulativeGasUsed: "3014967", gasUsed: "49499", confirmations: "953090"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x5e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f5175625"}, {type: "address", name: "addr", value: addressList[31]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x5e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f5175625", addressList[31], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542967558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x5e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f5175625"}, {name: "a", type: "address", value: "0x2253830caced969a0df94f2326bb71d05a94daf5"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x5e8010238cc0eb3dea1cf1054f4c80d80d6f... )", async function( ) {
		const txOriginal = {blockNumber: "6757174", timeStamp: "1542967597", hash: "0x1631f8a00fea6820bc7db4da12f22f65b50471ef6d5d42566a8a227164c861e8", nonce: "2368", blockHash: "0xf260da8567d35608f73bc67527fd7c5f8c194a10624f88a6437783dd2c48f961", transactionIndex: "101", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b005e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f51756250000000000000000000000002253830caced969a0df94f2326bb71d05a94daf5", contractAddress: "", cumulativeGasUsed: "5440621", gasUsed: "34499", confirmations: "953085"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x5e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f5175625"}, {type: "address", name: "addr", value: addressList[31]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x5e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f5175625", addressList[31], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542967597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x5e8010238cc0eb3dea1cf1054f4c80d80d6f43e8224a44e22088d4e7f5175625"}, {name: "a", type: "address", value: "0x2253830caced969a0df94f2326bb71d05a94daf5"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xb3ae8958411c6c30102a0f4056e61a37ec1a... )", async function( ) {
		const txOriginal = {blockNumber: "6770914", timeStamp: "1543161289", hash: "0x4965b02ff8b574fb38aabf7773d443a92926cb09de9593be2100f27cab57681e", nonce: "91", blockHash: "0x27b55c97ee432dc4b31fa7159215b38d352e15abbc362fbbf91d539aaf27df50", transactionIndex: "51", from: "0x41c7b33b8e7fec43e4f860f79c2a4314e3c54089", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00b3ae8958411c6c30102a0f4056e61a37ec1a3b13ee2ff5476aa62c08b9255cb00000000000000000000000002d2e6264d02c6e42153910cd02fc7f16ac305079", contractAddress: "", cumulativeGasUsed: "4978199", gasUsed: "49499", confirmations: "939345"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xb3ae8958411c6c30102a0f4056e61a37ec1a3b13ee2ff5476aa62c08b9255cb0"}, {type: "address", name: "addr", value: addressList[33]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xb3ae8958411c6c30102a0f4056e61a37ec1a3b13ee2ff5476aa62c08b9255cb0", addressList[33], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543161289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xb3ae8958411c6c30102a0f4056e61a37ec1a3b13ee2ff5476aa62c08b9255cb0"}, {name: "a", type: "address", value: "0x2d2e6264d02c6e42153910cd02fc7f16ac305079"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "33622257648178090023" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x8d77f17595017e55d404636ce8fbe57c8f58... )", async function( ) {
		const txOriginal = {blockNumber: "6773299", timeStamp: "1543194434", hash: "0x15d16c0e50bbe61d7c6eaca7534d52cc54e65a5241eaa1210d6733ea5a23bdfc", nonce: "4", blockHash: "0x7643015fd2d4a3af32a96b02adfe2090bdde48eb3c636459172a0c40817eeb34", transactionIndex: "163", from: "0x7afbf5bb4771822126c0bc4d58ec21310834c55e", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "49499", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b008d77f17595017e55d404636ce8fbe57c8f5821bb9c76fe24e92e9569994c6af80000000000000000000000007afbf5bb4771822126c0bc4d58ec21310834c55e", contractAddress: "", cumulativeGasUsed: "7986022", gasUsed: "49499", confirmations: "936960"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x8d77f17595017e55d404636ce8fbe57c8f5821bb9c76fe24e92e9569994c6af8"}, {type: "address", name: "addr", value: addressList[34]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x8d77f17595017e55d404636ce8fbe57c8f5821bb9c76fe24e92e9569994c6af8", addressList[34], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543194434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x8d77f17595017e55d404636ce8fbe57c8f5821bb9c76fe24e92e9569994c6af8"}, {name: "a", type: "address", value: "0x7afbf5bb4771822126c0bc4d58ec21310834c55e"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "1000000000000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xb283946f2525a3517aa8279621671e5ea136... )", async function( ) {
		const txOriginal = {blockNumber: "6773631", timeStamp: "1543199217", hash: "0x862f2ee2e1bf5d621a168448a46735dcb7cf86b771aabb616a311961689944ce", nonce: "2371", blockHash: "0xe402c2e061456862d42fbc98c78b9bdb281abd8bbb8f9ab9c438aa374d37aa2c", transactionIndex: "52", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00b283946f2525a3517aa8279621671e5ea1367567185cf7ffe32c8fe3eff540250000000000000000000000002ac2b3c5588e98b5da17213d8c341219ffce9afd", contractAddress: "", cumulativeGasUsed: "2321122", gasUsed: "49499", confirmations: "936628"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xb283946f2525a3517aa8279621671e5ea1367567185cf7ffe32c8fe3eff54025"}, {type: "address", name: "addr", value: addressList[35]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xb283946f2525a3517aa8279621671e5ea1367567185cf7ffe32c8fe3eff54025", addressList[35], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543199217 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xb283946f2525a3517aa8279621671e5ea1367567185cf7ffe32c8fe3eff54025"}, {name: "a", type: "address", value: "0x2ac2b3c5588e98b5da17213d8c341219ffce9afd"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x4c637b8a74c2cdc706489781da6be9080db3... )", async function( ) {
		const txOriginal = {blockNumber: "6776026", timeStamp: "1543233695", hash: "0x9a76d40e2c412ab6e210322b50e0a0b26f5624f6cf19f6d921f8c8714ef26617", nonce: "2374", blockHash: "0xbd29b3f4f4bf54cac4eb34dc485899e4237569bc27115b1bd82976c8877b3cd5", transactionIndex: "41", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b004c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee000000000000000000000000ea66a285392da2180a594dd0caa7b857eb3a6bcb", contractAddress: "", cumulativeGasUsed: "1518281", gasUsed: "49499", confirmations: "934233"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x4c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee"}, {type: "address", name: "addr", value: addressList[36]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x4c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee", addressList[36], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543233695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x4c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee"}, {name: "a", type: "address", value: "0xea66a285392da2180a594dd0caa7b857eb3a6bcb"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x4c637b8a74c2cdc706489781da6be9080db3... )", async function( ) {
		const txOriginal = {blockNumber: "6776032", timeStamp: "1543233828", hash: "0xe3752f3625af6803fda7c58b1d2fbdbec6cee189d8f1fbf474f05c2137dd5bb5", nonce: "2377", blockHash: "0xc1a565020b3daf88631ba0bc05f627459cf26883fc7a388b5eedead757f578d3", transactionIndex: "86", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b004c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee000000000000000000000000ea66a285392da2180a594dd0caa7b857eb3a6bcb", contractAddress: "", cumulativeGasUsed: "3238683", gasUsed: "34499", confirmations: "934227"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x4c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee"}, {type: "address", name: "addr", value: addressList[36]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x4c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee", addressList[36], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543233828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x4c637b8a74c2cdc706489781da6be9080db3500e2f5a97f7b3e6e3c1b5eed5ee"}, {name: "a", type: "address", value: "0xea66a285392da2180a594dd0caa7b857eb3a6bcb"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x5b5754328b90bf8667beabfcf27722afb6ab... )", async function( ) {
		const txOriginal = {blockNumber: "6776451", timeStamp: "1543239772", hash: "0x3620a5623b320b82e3e5126f57c2dcb46df932d0e3e82fc581b0acb0cb6f150e", nonce: "2380", blockHash: "0x52b60a14425aa7f1ae48a7b08ab80361acbf81a35d7af4f97d9814b1dee4331c", transactionIndex: "84", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b005b5754328b90bf8667beabfcf27722afb6ab13f7dd41710a3ff4de4075e2e719000000000000000000000000583ecdf42abf8a1f89878de66fae3227a0692a9a", contractAddress: "", cumulativeGasUsed: "6899895", gasUsed: "49499", confirmations: "933808"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x5b5754328b90bf8667beabfcf27722afb6ab13f7dd41710a3ff4de4075e2e719"}, {type: "address", name: "addr", value: addressList[37]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x5b5754328b90bf8667beabfcf27722afb6ab13f7dd41710a3ff4de4075e2e719", addressList[37], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543239772 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x5b5754328b90bf8667beabfcf27722afb6ab13f7dd41710a3ff4de4075e2e719"}, {name: "a", type: "address", value: "0x583ecdf42abf8a1f89878de66fae3227a0692a9a"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x9f26348174af60702ec8442ceec71dabc7be... )", async function( ) {
		const txOriginal = {blockNumber: "6782035", timeStamp: "1543320198", hash: "0x88cdf98b85ca5510b076540ba340d03619dc132860a2f03db9190262fc5236cc", nonce: "2383", blockHash: "0x35dd027761636120e5e6a1ba61befb044c8c61d2cc005d55c5ac2f5fe46ae737", transactionIndex: "17", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b009f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d000000000000000000000000369799e8308bfd8d32fe4709db82af51e6f1cc60", contractAddress: "", cumulativeGasUsed: "1146604", gasUsed: "49499", confirmations: "928224"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x9f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d"}, {type: "address", name: "addr", value: addressList[38]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x9f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d", addressList[38], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543320198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x9f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d"}, {name: "a", type: "address", value: "0x369799e8308bfd8d32fe4709db82af51e6f1cc60"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x9f26348174af60702ec8442ceec71dabc7be... )", async function( ) {
		const txOriginal = {blockNumber: "6782128", timeStamp: "1543321619", hash: "0x26412260e044cefe51ac00da14d408c064925ffb92a59973158463b62d8ea782", nonce: "2386", blockHash: "0x31fcc06e97918f0f4ed0fd61145ad95a4f824356a21c9bb47ca23c1ff926ada9", transactionIndex: "114", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "4100000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b009f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d000000000000000000000000369799e8308bfd8d32fe4709db82af51e6f1cc60", contractAddress: "", cumulativeGasUsed: "6787280", gasUsed: "34499", confirmations: "928131"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x9f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d"}, {type: "address", name: "addr", value: addressList[38]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x9f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d", addressList[38], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543321619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x9f26348174af60702ec8442ceec71dabc7be8f2ae5abc95f0b9e7e2615dcf14d"}, {name: "a", type: "address", value: "0x369799e8308bfd8d32fe4709db82af51e6f1cc60"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setText( \"0xf439007c07376d22f24cbe0142fccc9425d7... )", async function( ) {
		const txOriginal = {blockNumber: "6784412", timeStamp: "1543354200", hash: "0xe59c71fef4a5b7d4b68290138f9e418eae2e5f3375ce96f6516d67a4a1d44983", nonce: "551", blockHash: "0x30ac3a1a346807fecb65be913378f48e6bcd1b944f2c4f3eb6f1a14a5ec70fa5", transactionIndex: "56", from: "0x18c6045651826824febbd39d8560584078d1b247", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "500000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x10f13a8cf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000010766e642e6170702e6d65657365656b7300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d6454454250644e784a46467348317752453359655748524557446953657838786867546e716b6e7978576775000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5319404", gasUsed: "96059", confirmations: "925847"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e"}, {type: "string", name: "key", value: `vnd.app.meeseeks`}, {type: "string", name: "value", value: `QmdTEBPdNxJFFsH1wRE3YeWHREWDiSex8xhgTnqknyxWgu`}], name: "setText", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setText(bytes32,string,string)" ]( "0xf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e", `vnd.app.meeseeks`, `QmdTEBPdNxJFFsH1wRE3YeWHREWDiSex8xhgTnqknyxWgu`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543354200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "indexedKey", type: "string"}, {indexed: false, name: "key", type: "string"}], name: "TextChanged", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TextChanged", events: [{name: "node", type: "bytes32", value: "0xf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e"}, {name: "indexedKey", type: "string", value: "vnd.app.meeseeks"}, {name: "key", type: "string", value: "vnd.app.meeseeks"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "4551954488598165552" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6784421", timeStamp: "1543354309", hash: "0xcf6e36c14e712f7c4238f53ccfaaa0dada04696299e19d7f281bed01b072a2f2", nonce: "552", blockHash: "0x303704fd0f9ec111254ec63e2e8ec6a1cc195501c631bf7c61da8184361cfe66", transactionIndex: "112", from: "0x18c6045651826824febbd39d8560584078d1b247", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "500000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x70687fcbf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000023011220e08ea2458249e8f26aee72b95b39c33849a992a3eff40bd06d26c12197adef160000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7471233", gasUsed: "26619", confirmations: "925838"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543354309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "4551954488598165552" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setContenthash( \"0xf439007c07376d22f24cbe0142fccc9425d7... )", async function( ) {
		const txOriginal = {blockNumber: "6784430", timeStamp: "1543354432", hash: "0xf2a657aaa66e5365a0b81b22bf6faab75bfa1840e9ea9bce34f59e4e9b3ecd0d", nonce: "553", blockHash: "0x48fe967d921ea38c722218ef69fce8048437bb1a06ce0b219ebcd612f3e230ca", transactionIndex: "85", from: "0x18c6045651826824febbd39d8560584078d1b247", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "500000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x304e6adef439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000023011220e08ea2458249e8f26aee72b95b39c33849a992a3eff40bd06d26c12197adef160000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6739780", gasUsed: "92592", confirmations: "925829"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e"}, {type: "bytes", name: "hash", value: "0x011220e08ea2458249e8f26aee72b95b39c33849a992a3eff40bd06d26c12197adef16"}], name: "setContenthash", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setContenthash(bytes32,bytes)" ]( "0xf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e", "0x011220e08ea2458249e8f26aee72b95b39c33849a992a3eff40bd06d26c12197adef16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543354432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "hash", type: "bytes"}], name: "ContenthashChanged", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContenthashChanged", events: [{name: "node", type: "bytes32", value: "0xf439007c07376d22f24cbe0142fccc9425d7b1cd4cc56b4f562290f910c83c6e"}, {name: "hash", type: "bytes", value: "0x011220e08ea2458249e8f26aee72b95b39c33849a992a3eff40bd06d26c12197adef16"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "4551954488598165552" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x7d496f87ad4fdf5986a339def810dbb5d64d... )", async function( ) {
		const txOriginal = {blockNumber: "6790714", timeStamp: "1543444176", hash: "0x91d2adc038c59f1deb235f0a44b8566e58d8c3ca8c03832ace9d5c8b6351fbed", nonce: "2389", blockHash: "0x72ec8bbc4a418d1cdb544fa979af5692119deb54f9500ea2dd355c770b83f3f1", transactionIndex: "69", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b007d496f87ad4fdf5986a339def810dbb5d64d73982e0dc2735e95cb1eff3ed7bd000000000000000000000000029aa204c017138a772ac69d10b195da4c28cd84", contractAddress: "", cumulativeGasUsed: "6142852", gasUsed: "49499", confirmations: "919545"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x7d496f87ad4fdf5986a339def810dbb5d64d73982e0dc2735e95cb1eff3ed7bd"}, {type: "address", name: "addr", value: addressList[40]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x7d496f87ad4fdf5986a339def810dbb5d64d73982e0dc2735e95cb1eff3ed7bd", addressList[40], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543444176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x7d496f87ad4fdf5986a339def810dbb5d64d73982e0dc2735e95cb1eff3ed7bd"}, {name: "a", type: "address", value: "0x029aa204c017138a772ac69d10b195da4c28cd84"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x68c9eb13d322e9701f4fa16616234092087a... )", async function( ) {
		const txOriginal = {blockNumber: "6802534", timeStamp: "1543611821", hash: "0x6ef916ae8f7139bec21888ae38167c226a3aad920aa446feea4e6a53fd7c5d07", nonce: "2392", blockHash: "0x92385173e1b5b7192aaded632043c5948a2d5246398b289176eb1c4b5678e853", transactionIndex: "19", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0068c9eb13d322e9701f4fa16616234092087a6a3d5a885e272736d88bdd9e565100000000000000000000000007c41ef6a4ea96ba8d86fbfe95aaedf1bcd48ddd", contractAddress: "", cumulativeGasUsed: "1417685", gasUsed: "49499", confirmations: "907725"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x68c9eb13d322e9701f4fa16616234092087a6a3d5a885e272736d88bdd9e5651"}, {type: "address", name: "addr", value: addressList[41]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x68c9eb13d322e9701f4fa16616234092087a6a3d5a885e272736d88bdd9e5651", addressList[41], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543611821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x68c9eb13d322e9701f4fa16616234092087a6a3d5a885e272736d88bdd9e5651"}, {name: "a", type: "address", value: "0x07c41ef6a4ea96ba8d86fbfe95aaedf1bcd48ddd"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xff479a47babf09723609a6a21c05cb997bb3... )", async function( ) {
		const txOriginal = {blockNumber: "6803214", timeStamp: "1543621746", hash: "0x534ad0f2b63ddf06ded15b4748534da0d1b1b6c6c92368da66b69f6ddb15bce7", nonce: "2395", blockHash: "0x704b57fdba26010c9b404b8fa80690ea2c182126cf905a06985cd39918ecc1c4", transactionIndex: "15", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "9100000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00ff479a47babf09723609a6a21c05cb997bb3579be20a9bf1bbe3fea28d5c4a30000000000000000000000000b6dd16eba7155cc2ea4af77a69cff8661e9fbb09", contractAddress: "", cumulativeGasUsed: "812108", gasUsed: "49499", confirmations: "907045"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xff479a47babf09723609a6a21c05cb997bb3579be20a9bf1bbe3fea28d5c4a30"}, {type: "address", name: "addr", value: addressList[42]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xff479a47babf09723609a6a21c05cb997bb3579be20a9bf1bbe3fea28d5c4a30", addressList[42], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543621746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xff479a47babf09723609a6a21c05cb997bb3579be20a9bf1bbe3fea28d5c4a30"}, {name: "a", type: "address", value: "0xb6dd16eba7155cc2ea4af77a69cff8661e9fbb09"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x14b4224ceb3208ee88d18d1623c0f5da7673... )", async function( ) {
		const txOriginal = {blockNumber: "6806226", timeStamp: "1543664439", hash: "0xe73e00cbf3a7c7d926818281801e201790c6db36705480bb4d13234292449ca7", nonce: "2398", blockHash: "0xbbb20ce124645f72c5bdf5e34ae46f2964485916af86b681ba86890601931781", transactionIndex: "90", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0014b4224ceb3208ee88d18d1623c0f5da7673059b0f8e62b58a6680dbd426fa6a000000000000000000000000ae085ddd678f6dc7aa9c5d795453cc8753721f03", contractAddress: "", cumulativeGasUsed: "4885517", gasUsed: "49499", confirmations: "904033"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x14b4224ceb3208ee88d18d1623c0f5da7673059b0f8e62b58a6680dbd426fa6a"}, {type: "address", name: "addr", value: addressList[43]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x14b4224ceb3208ee88d18d1623c0f5da7673059b0f8e62b58a6680dbd426fa6a", addressList[43], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543664439 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x14b4224ceb3208ee88d18d1623c0f5da7673059b0f8e62b58a6680dbd426fa6a"}, {name: "a", type: "address", value: "0xae085ddd678f6dc7aa9c5d795453cc8753721f03"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0xf8ae1c7dce74e94e0de5cf95ce109eddfec4... )", async function( ) {
		const txOriginal = {blockNumber: "6810088", timeStamp: "1543720004", hash: "0xf7f7eb4574cf56d0ffc4de59de9d5f3127bcafa514c7c3b1cd3f748e91e31ea9", nonce: "2401", blockHash: "0x79602dfa7c6a8440f7be598a4e12a72a5a65732c7efd65f126b402342b10077f", transactionIndex: "42", from: "0xddf369c3bf18b1b12ea295d597b943b955ef4671", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "100000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b00f8ae1c7dce74e94e0de5cf95ce109eddfec45a19a38cc263c5b5cba59ce8f43c0000000000000000000000001787e5af30f7baeac0f5b0d001b15d9fe210d9b9", contractAddress: "", cumulativeGasUsed: "2664025", gasUsed: "49499", confirmations: "900171"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0xf8ae1c7dce74e94e0de5cf95ce109eddfec45a19a38cc263c5b5cba59ce8f43c"}, {type: "address", name: "addr", value: addressList[44]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0xf8ae1c7dce74e94e0de5cf95ce109eddfec45a19a38cc263c5b5cba59ce8f43c", addressList[44], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543720004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0xf8ae1c7dce74e94e0de5cf95ce109eddfec45a19a38cc263c5b5cba59ce8f43c"}, {name: "a", type: "address", value: "0x1787e5af30f7baeac0f5b0d001b15d9fe210d9b9"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "98809908900000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x95b260089ce072c54f210828aa24b16822a3... )", async function( ) {
		const txOriginal = {blockNumber: "6815016", timeStamp: "1543790155", hash: "0xb7aa602fbd2d207d75119dc5753e3933dcc1ddfff9a6c1e294c30082b8d750b7", nonce: "7", blockHash: "0xef4f9e49a5bc71c2581de14fae84d38b3b8f32fcfe93afd176a6635a1918276d", transactionIndex: "21", from: "0x0a263ad57976cf88f779fb4b8b790f929b185763", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0095b260089ce072c54f210828aa24b16822a30bd49e2524ef6c16cb4dc3176a440000000000000000000000006bab1bd10aa94431ff5d5bad537c93fcc2a78843", contractAddress: "", cumulativeGasUsed: "2661311", gasUsed: "49499", confirmations: "895243"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x95b260089ce072c54f210828aa24b16822a30bd49e2524ef6c16cb4dc3176a44"}, {type: "address", name: "addr", value: addressList[46]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x95b260089ce072c54f210828aa24b16822a30bd49e2524ef6c16cb4dc3176a44", addressList[46], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543790155 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x95b260089ce072c54f210828aa24b16822a30bd49e2524ef6c16cb4dc3176a44"}, {name: "a", type: "address", value: "0x6bab1bd10aa94431ff5d5bad537c93fcc2a78843"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "111318066000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setAddr( \"0x02c128883ef2a757af0bbaaa80d468a01cd7... )", async function( ) {
		const txOriginal = {blockNumber: "6818625", timeStamp: "1543842462", hash: "0xa629a9c826b9f84f328a42e82a4b51e43ed81eefab9086f3e77f8b3c88744b69", nonce: "16", blockHash: "0xe2f61aa5726f4c22733ce08555c1eb0401e23db383801a9855ece966ab3a5efc", transactionIndex: "138", from: "0xdd6ca7d9d4d2a190a5c940f499cb32494a6fd31c", to: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3", value: "0", gas: "74248", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd5fa2b0002c128883ef2a757af0bbaaa80d468a01cd7608250d5fc3974ed9c42955f79050000000000000000000000003e5b1d302f18d1fb6d4e04d78f3e9d7bec2433ac", contractAddress: "", cumulativeGasUsed: "6772202", gasUsed: "49499", confirmations: "891634"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "node", value: "0x02c128883ef2a757af0bbaaa80d468a01cd7608250d5fc3974ed9c42955f7905"}, {type: "address", name: "addr", value: addressList[48]}], name: "setAddr", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAddr(bytes32,address)" ]( "0x02c128883ef2a757af0bbaaa80d468a01cd7608250d5fc3974ed9c42955f7905", addressList[48], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543842462 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "node", type: "bytes32"}, {indexed: false, name: "a", type: "address"}], name: "AddrChanged", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddrChanged", events: [{name: "node", type: "bytes32", value: "0x02c128883ef2a757af0bbaaa80d468a01cd7608250d5fc3974ed9c42955f7905"}, {name: "a", type: "address", value: "0x3e5b1d302f18d1fb6d4e04d78f3e9d7bec2433ac"}], address: "0xd3ddccdd3b25a8a7423b5bee360a42146eb4baf3"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "1906202191699946257" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
