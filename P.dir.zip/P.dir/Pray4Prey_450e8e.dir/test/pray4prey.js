const Pray4Prey = artifacts.require( "./Pray4Prey.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Pray4Prey" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x807A3EF8A8dBDD7fc9863Df695bbe8691E450e8e", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x93BBBe5ce77034E3095F0479919962a903f898Ad", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0xa4F970e6425e316984208CA1Ee95ca618C11A34d", "0xB8B47E70DD5046882Cb32152796ac63ab40CC596", "0x47b5Ed2279478151d1631014Aa90F876FEc4a136", "0x9ec5EA5015Bd19C265990Ab0A71B84611739d1eD", "0xf975D98bD0A21435c6c764bEca1eeb1c1C656a2B", "0x3085ec50eB94E6Fa9F60a0aA50974C08f5B1E044", "0x151ef3D2adb56b574fc62fAc88Fc98BE05DC659a", "0xc114f48b3f9828E68bF253F0B9CFB713Fc54Eb44", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0x31b26E43651e9371C88aF3D36c14CfD938BaF4Fd", "0x2fAeA7E734aCaE57b16325Dd7Aa9e089a587Aa79", "0x00A1B27aBA96C12a8e7198a94b83C8A396d90158", "0x13D537fAE2576d6BE22698d6891D577BC8De472b", "0x532c278d4E91F12de1b87588D530E1f766d4f425"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint8"}], name: "numAnimalsXType", outputs: [{name: "", type: "uint16"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numAnimals", outputs: [{name: "", type: "uint16"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "animalId", type: "uint32"}], name: "getAnimal", outputs: [{name: "", type: "uint8"}, {name: "", type: "uint128"}, {name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "oldest", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "oraclizeGas", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "costs", outputs: [{name: "", type: "uint128"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "startIndex", type: "uint16"}], name: "get10Animals", outputs: [{name: "animalIds", type: "uint32[10]"}, {name: "types", type: "uint8[10]"}, {name: "values", type: "uint128[10]"}, {name: "owners", type: "address[10]"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "values", outputs: [{name: "", type: "uint128"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "nextId", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxAnimals", outputs: [{name: "", type: "uint16"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getFees", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "playerAddress", type: "address"}], name: "getPlayerBalance", outputs: [{name: "playerBalance", type: "uint128"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "nextAttackTimestamp", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "ids", outputs: [{name: "", type: "uint32"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "totalBalance", type: "uint256"}], name: "newExit", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["newPurchase(address,uint8,uint8,uint32)", "newExit(address,uint256)", "newAttack(uint32[])"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xaa7f6a618db3cb76bca4d47310fbd06ad8b2497046377d4e4404ce26aa7d8e9d", "0x313c40939ea55b1e0d953726a58438e52664c3dcda25b209f6de87d741e7ebb6", "0x95217ec91f01e5519421b0a0dd9b060ef9b628dc77798b96c36521854d82d20d"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3142890 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3202752 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Pray4Prey", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint8", name: "", value: random.range( maxRandom )}], name: "numAnimalsXType", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numAnimalsXType(uint8)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numAnimals", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numAnimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "animalId", value: random.range( maxRandom )}], name: "getAnimal", outputs: [{name: "", type: "uint8"}, {name: "", type: "uint128"}, {name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAnimal(uint32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "oldest", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "oldest()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "oraclizeGas", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "oraclizeGas()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "costs", outputs: [{name: "", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "costs(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "startIndex", value: random.range( maxRandom )}], name: "get10Animals", outputs: [{name: "animalIds", type: "uint32[10]"}, {name: "types", type: "uint8[10]"}, {name: "values", type: "uint128[10]"}, {name: "owners", type: "address[10]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "get10Animals(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "values", outputs: [{name: "", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "values(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextId", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxAnimals", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxAnimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getFees", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFees()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "playerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerBalance", outputs: [{name: "playerBalance", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextAttackTimestamp", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextAttackTimestamp()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "ids", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ids(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Pray4Prey", function( accounts ) {

	it( "TEST: Pray4Prey(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3142890", timeStamp: "1486519096", hash: "0x44ca00268a0fdf3428482a5e18865cbf08e9c242279d0e6df53edf44c47386dd", nonce: "86", blockHash: "0x144b3067e947e91fc9202722233ab640460b530a1b08fb6d0f9f842c22640829", transactionIndex: "0", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: 0, value: "0", gas: "4000000", gasPrice: "41000000000", isError: "0", txreceipt_status: "", input: "0x7bdc011e", contractAddress: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", cumulativeGasUsed: "3663120", gasUsed: "3663120", confirmations: "4530869"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Pray4Prey", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Pray4Prey.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1486519096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Pray4Prey.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3143079", timeStamp: "1486521848", hash: "0x6cbd1a9a99aaff3db007d4ed936be9f8baef05d428b8f60a2c6beb68cc4959e0", nonce: "7", blockHash: "0xc5cafa27b186a593176282061b5df8341b6b4c603184686559745ac13db2d4c8", transactionIndex: "1", from: "0xb8b47e70dd5046882cb32152796ac63ab40cc596", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "300000000000000000", gas: "400000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "333410", gasUsed: "268882", confirmations: "4530680"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1486521848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0xb8b47e70dd5046882cb32152796ac63ab40cc596"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "3"}, {name: "startId", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "13111124973467043" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3143086", timeStamp: "1486521913", hash: "0xb73e2cb58a6f8f404fd8cac7426d9a1713e10c75edede6379595e4e14f970b30", nonce: "8", blockHash: "0x150dad4a9e7eb2b8c72bf533261c58a3cd3e0fd0193ca1ea91bb53949d7b9904", transactionIndex: "0", from: "0xb8b47e70dd5046882cb32152796ac63ab40cc596", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "400000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "175037", gasUsed: "175037", confirmations: "4530673"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "1"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1486521913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0xb8b47e70dd5046882cb32152796ac63ab40cc596"}, {name: "animalType", type: "uint8", value: "1"}, {name: "amount", type: "uint8", value: "2"}, {name: "startId", type: "uint32", value: {s: 1, e: 0, c: [4]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "13111124973467043" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3143119", timeStamp: "1486522390", hash: "0xe8d6c5698cb7c6bc143f299e35f6d5c61e916a0bb6979c1d0fdf2548909cd1ec", nonce: "9", blockHash: "0x871e0f8b433be243ec15cc282a37931792bd9aac2338012894b2c2ebc465ed5c", transactionIndex: "0", from: "0xb8b47e70dd5046882cb32152796ac63ab40cc596", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "110828", gasUsed: "110828", confirmations: "4530640"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "3"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1486522390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0xb8b47e70dd5046882cb32152796ac63ab40cc596"}, {name: "animalType", type: "uint8", value: "3"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 0, c: [6]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "13111124973467043" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3143129", timeStamp: "1486522527", hash: "0x3078fb468bc995ab521383c510d2599e2cb9737407210d30e4470e7d248d8593", nonce: "10", blockHash: "0x684583a38818636c0a54097819dcf2a617544b3ef88da713255e4f02ac765f14", transactionIndex: "0", from: "0x47b5ed2279478151d1631014aa90f876fec4a136", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "95614", gasUsed: "95614", confirmations: "4530630"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1486522527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x47b5ed2279478151d1631014aa90f876fec4a136"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 0, c: [7]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2853025628824767413" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3143156", timeStamp: "1486522808", hash: "0xbfff8915c4df087e6d2d2a342b247a081a4ad1f8a017c8ce83d079275b388509", nonce: "11", blockHash: "0x17b9b615019873bcfc98969c832e238b4950435a302a62acfdad7f2c167fe8e2", transactionIndex: "4", from: "0x47b5ed2279478151d1631014aa90f876fec4a136", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "200000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "285877", gasUsed: "174723", confirmations: "4530603"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1486522808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x47b5ed2279478151d1631014aa90f876fec4a136"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "2"}, {name: "startId", type: "uint32", value: {s: 1, e: 0, c: [8]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2853025628824767413" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"0\", addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "3143198", timeStamp: "1486523465", hash: "0x04a5b0c6e57278ffb2dc0ad997dcfbccf516acd3b201446f16cde111e4c0be7e", nonce: "88", blockHash: "0x04bd158ca14310feec3afecee6f57362d9a32cfe43bd50b08732b7b64d928a46", transactionIndex: "0", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "1000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c53500000000000000000000000000000000000000000000000000000000000000000000000000000000000000009ec5ea5015bd19c265990ab0a71b84611739d1ed", contractAddress: "", cumulativeGasUsed: "97269", gasUsed: "97269", confirmations: "4530561"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}, {type: "address", name: "receiver", value: addressList[11]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "0", addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1486523465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [10]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"1\", addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "3143204", timeStamp: "1486523558", hash: "0x85334999c7d9a18fa57ab4e1e655c1fc7b61492a51a8bc6c0429a7f6d151fc87", nonce: "89", blockHash: "0xb5f45f8626df7a5bfbbbc4028fc43efdc74551cb7cc76896418f94a6dcbb4d00", transactionIndex: "3", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "200000000000000000", gas: "1000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c53500000000000000000000000000000000000000000000000000000000000000010000000000000000000000009ec5ea5015bd19c265990ab0a71b84611739d1ed", contractAddress: "", cumulativeGasUsed: "160483", gasUsed: "97483", confirmations: "4530555"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "1"}, {type: "address", name: "receiver", value: addressList[11]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "1", addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1486523558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "1"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [11]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"0\", addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "3143209", timeStamp: "1486523638", hash: "0xd782cf77dbd50551ef923230580718131d4cdcc2feba8fc25657a955362b6693", nonce: "90", blockHash: "0x21aef64977ad50cb6675a8791c845680d294814fb102ec03cfb2d7f046dffa83", transactionIndex: "2", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "1000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c5350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f975d98bd0a21435c6c764beca1eeb1c1c656a2b", contractAddress: "", cumulativeGasUsed: "139269", gasUsed: "97269", confirmations: "4530550"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}, {type: "address", name: "receiver", value: addressList[12]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "0", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1486523638 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0xf975d98bd0a21435c6c764beca1eeb1c1c656a2b"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [12]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"0\", addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "3143216", timeStamp: "1486523716", hash: "0x10d877f294c15be5260fdb350f0669e80e8cc1546341e2ab473af1cfa78cbf57", nonce: "91", blockHash: "0x95e6db2a7d06d25edb8858548f0a883e366dccc26724a21d761e19212bceb755", transactionIndex: "3", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "1000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c53500000000000000000000000000000000000000000000000000000000000000000000000000000000000000003085ec50eb94e6fa9f60a0aa50974c08f5b1e044", contractAddress: "", cumulativeGasUsed: "186129", gasUsed: "97269", confirmations: "4530543"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}, {type: "address", name: "receiver", value: addressList[13]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "0", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1486523716 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x3085ec50eb94e6fa9f60a0aa50974c08f5b1e044"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [13]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"0\", addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "3143220", timeStamp: "1486523796", hash: "0x836963c70f6642582502d94c17360448f67700e5df382f22f66db34f269ecd93", nonce: "92", blockHash: "0x1d210ece9a62f83f15d6f8861169b9f75aad955c266424f43d1ca6d7ccf8a651", transactionIndex: "2", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "1000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c5350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000151ef3d2adb56b574fc62fac88fc98be05dc659a", contractAddress: "", cumulativeGasUsed: "140692", gasUsed: "97269", confirmations: "4530539"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}, {type: "address", name: "receiver", value: addressList[14]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "0", addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1486523796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x151ef3d2adb56b574fc62fac88fc98be05dc659a"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [14]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"0\", addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "3143232", timeStamp: "1486524019", hash: "0x6a7e4f8d34262294441e314132305c6645eeddbcadbd0c8ce0a368e20d5f4758", nonce: "93", blockHash: "0xb1e11f08257f3733143a76276ec798e08e70e9b857798778aaa81b455df262cb", transactionIndex: "2", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "1000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c5350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c114f48b3f9828e68bf253f0b9cfb713fc54eb44", contractAddress: "", cumulativeGasUsed: "139269", gasUsed: "97269", confirmations: "4530527"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}, {type: "address", name: "receiver", value: addressList[15]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "0", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1486524019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0xc114f48b3f9828e68bf253f0b9cfb713fc54eb44"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [15]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: triggerAttackManually( \"52200\" )", async function( ) {
		const txOriginal = {blockNumber: "3143306", timeStamp: "1486525267", hash: "0x2dc1f6623318c9296489a4889e0865251ece8102a9ff3fe5ab0bc3db2d787121", nonce: "94", blockHash: "0x2ea628e81609eb6c530789500a405d50fd08aac36748574a7aaa6d83631f5604", transactionIndex: "0", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "1000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0x1402f031000000000000000000000000000000000000000000000000000000000000cbe8", contractAddress: "", cumulativeGasUsed: "157409", gasUsed: "157409", confirmations: "4530453"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "inseconds", value: "52200"}], name: "triggerAttackManually", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "triggerAttackManually(uint32)" ]( "52200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1486525267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3146746", timeStamp: "1486573891", hash: "0x23c7fc05ad490b3e71fa9943ee024d34080b48ad9b99d82212a0cc7a9093ff55", nonce: "63", blockHash: "0xa582b916d1eda3391607137d4ed4b1abd70156e5489e3ec8b637298f744c12ce", transactionIndex: "2", from: "0xc114f48b3f9828e68bf253f0b9cfb713fc54eb44", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "500000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "159458", gasUsed: "110678", confirmations: "4527013"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "2"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1486573891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0xc114f48b3f9828e68bf253f0b9cfb713fc54eb44"}, {name: "animalType", type: "uint8", value: "2"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [16]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "285859409164934" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3146918", timeStamp: "1486576464", hash: "0x4c7f9824796dadff765ac5261d880e85f86bb7bcac492aa15ff147e9def27c43", nonce: "13", blockHash: "0xe7380b88f68bc8444673e54f8eb16f507f1907dc7ab7983fa5f15ffe052dc937", transactionIndex: "3", from: "0x151ef3d2adb56b574fc62fac88fc98be05dc659a", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "200000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "174957", gasUsed: "110778", confirmations: "4526841"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "1"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1486576464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x151ef3d2adb56b574fc62fac88fc98be05dc659a"}, {name: "animalType", type: "uint8", value: "1"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [17]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "277026337448562" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xdf09f914116df375674af76f16f28eae69c1... )", async function( ) {
		const txOriginal = {blockNumber: "3146982", timeStamp: "1486577488", hash: "0xd670db55b8d1d4c0003e60940660d6bd43cd701d9492c91dc80837c0c9d9271d", nonce: "61654", blockHash: "0xacbaadc6a34fb4c1e0e7b4e18257dcffcac74851a6ff16a32e236a9d670e2698", transactionIndex: "2", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "418928", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297edf09f914116df375674af76f16f28eae69c18fce189b2455b38793e7731a0929000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000317b3335342c2035372c203931392c203430362c203132352c203235322c203736342c203830342c203538322c203934337d000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "312884", gasUsed: "270884", confirmations: "4526777"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xdf09f914116df375674af76f16f28eae69c18fce189b2455b38793e7731a0929"}, {type: "string", name: "result", value: `{354, 57, 919, 406, 125, 252, 764, 804, 582, 943}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xdf09f914116df375674af76f16f28eae69c18fce189b2455b38793e7731a0929", `{354, 57, 919, 406, 125, 252, 764, 804, 582, 943}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1486577488 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 0, c: [7]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3147203", timeStamp: "1486580414", hash: "0x7d30ab5226f8242a563a05b9f8fff0309641c5abf4eb1bee2057893766f34ab2", nonce: "26", blockHash: "0x36f0c892d18e2112d849a1e9e914bb4b30c774fc5ba62144a91467b5be290937", transactionIndex: "4", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "392449", gasUsed: "169578", confirmations: "4526556"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "2"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1486580414 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "2"}, {name: "amount", type: "uint8", value: "2"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [18]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3147216", timeStamp: "1486580598", hash: "0xcfea13ecfbc290a1843b4d2c16e2943526552ecbaf9080a6664b473ddfbbe0c1", nonce: "27", blockHash: "0xad75d5d388b8fd9be1ae1f97a99bef84dce887d5ed3682c98529b28316e9d3ff", transactionIndex: "4", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "181122", gasUsed: "95828", confirmations: "4526543"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "3"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1486580598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "3"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [20]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3147232", timeStamp: "1486580775", hash: "0xd59d0b577c221c3d17e2e665ad89ba84f638a7280f8469575679817a04cc7393", nonce: "28", blockHash: "0x930001f225c29428821744cb03384f85646a0e7968be7832a15acc5c154619c4", transactionIndex: "1", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "116828", gasUsed: "95828", confirmations: "4526527"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "3"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1486580775 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "3"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [21]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3147891", timeStamp: "1486590296", hash: "0xd4ea92e31401507cf83315dc544c4f0917f7d2c3a2dd5a33a8414d7ff517da50", nonce: "22", blockHash: "0x3c5b7527f229b5406675d3336718607b84bf49bf7fde5e8a7d659a7daf769e82", transactionIndex: "1", from: "0x31b26e43651e9371c88af3d36c14cfd938baf4fd", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "200000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "228481", gasUsed: "95828", confirmations: "4525868"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "1"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1486590296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x31b26e43651e9371c88af3d36c14cfd938baf4fd"}, {name: "animalType", type: "uint8", value: "1"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [22]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3152599", timeStamp: "1486657932", hash: "0x7a156b61efada7db655aba185dcbca2e47e3e231f74c4c678dbf18375c75e95b", nonce: "12", blockHash: "0xb351c4a0b6c58209c9e7eb92964b51a27719f8021e84857f938098f99ce139e6", transactionIndex: "0", from: "0x47b5ed2279478151d1631014aa90f876fec4a136", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "95614", gasUsed: "95614", confirmations: "4521160"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1486657932 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x47b5ed2279478151d1631014aa90f876fec4a136"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [23]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2853025628824767413" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"0\", addressList[18] )", async function( ) {
		const txOriginal = {blockNumber: "3152863", timeStamp: "1486661501", hash: "0x55430418d8a8cb921dbffc3607932e07e0efb9988e9cffdb57f88d1418940291", nonce: "13", blockHash: "0xe4f1c9d212acb7f9b247992ffedb7027191922cba3efb295a4b68f23887dde5a", transactionIndex: "0", from: "0x47b5ed2279478151d1631014aa90f876fec4a136", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c53500000000000000000000000000000000000000000000000000000000000000000000000000000000000000002faea7e734acae57b16325dd7aa9e089a587aa79", contractAddress: "", cumulativeGasUsed: "97269", gasUsed: "97269", confirmations: "4520896"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}, {type: "address", name: "receiver", value: addressList[18]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "0", addressList[18], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1486661501 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x2faea7e734acae57b16325dd7aa9e089a587aa79"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [24]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2853025628824767413" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x7fc4b1a3d8349dac73b4383a78c30ee1cd95... )", async function( ) {
		const txOriginal = {blockNumber: "3153029", timeStamp: "1486663906", hash: "0x257b1c5eb62a7eef8b47ac5528d862e81033ef87ad937a50814bc57db7111301", nonce: "61772", blockHash: "0x2005ecb118a46bce98e26563da1ade4e07801016f0bc412c7eac92cd0e7a22fc", transactionIndex: "1", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "428928", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e7fc4b1a3d8349dac73b4383a78c30ee1cd95d1f567e193f10a2fc4c41f83e08b000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000327b3939372c203939362c203435362c203430362c203434382c203638342c203233372c203836322c203734372c203131397d0000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "394032", gasUsed: "372952", confirmations: "4520730"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x7fc4b1a3d8349dac73b4383a78c30ee1cd95d1f567e193f10a2fc4c41f83e08b"}, {type: "string", name: "result", value: `{997, 996, 456, 406, 448, 684, 237, 862, 747, 119}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x7fc4b1a3d8349dac73b4383a78c30ee1cd95d1f567e193f10a2fc4c41f83e08b", `{997, 996, 456, 406, 448, 684, 237, 862, 747, 119}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1486663906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 1, c: [24]}, {s: 1, e: 1, c: [23]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa56f3f90ea9f5c02b5dbd44c4cb665ce04ff... )", async function( ) {
		const txOriginal = {blockNumber: "3159080", timeStamp: "1486750404", hash: "0xbdd6de2644550f9f3dd32ee3df00c1cffe0bd229fb73527222f43a6242ac46b3", nonce: "61969", blockHash: "0x07a658f48fbf2388c2e37ed49df617d99ed60aa870d217bec45a492f9ca7938d", transactionIndex: "20", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "413392", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ea56f3f90ea9f5c02b5dbd44c4cb665ce04ffcfdd6a98fb6255cc2792f190d60f000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000307b3139312c2038372c203338352c203332332c2032382c203237372c203437382c203331312c203238392c203139387d00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1096837", gasUsed: "356997", confirmations: "4514679"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xa56f3f90ea9f5c02b5dbd44c4cb665ce04ffcfdd6a98fb6255cc2792f190d60f"}, {type: "string", name: "result", value: `{191, 87, 385, 323, 28, 277, 478, 311, 289, 198}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xa56f3f90ea9f5c02b5dbd44c4cb665ce04ffcfdd6a98fb6255cc2792f190d60f", `{191, 87, 385, 323, 28, 277, 478, 311, 289, 198}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1486750404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 0, c: [5]}, {s: 1, e: 0, c: [2]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: giveAnimals( \"0\", addressList[18] )", async function( ) {
		const txOriginal = {blockNumber: "3159698", timeStamp: "1486759116", hash: "0xfd61d64f84e32afa4e0121a2744d94bcc05ba1b68bff240cda19375e5fce3a7b", nonce: "14", blockHash: "0x6dd285f701e5915e3d648eaf281e4a6a33d828aac3424621d6051b092d0053c0", transactionIndex: "1", from: "0x47b5ed2279478151d1631014aa90f876fec4a136", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xcfe8c53500000000000000000000000000000000000000000000000000000000000000000000000000000000000000002faea7e734acae57b16325dd7aa9e089a587aa79", contractAddress: "", cumulativeGasUsed: "113060", gasUsed: "92060", confirmations: "4514061"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}, {type: "address", name: "receiver", value: addressList[18]}], name: "giveAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAnimals(uint8,address)" ]( "0", addressList[18], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1486759116 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x2faea7e734acae57b16325dd7aa9e089a587aa79"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [25]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2853025628824767413" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3164352", timeStamp: "1486825621", hash: "0x3bc5d43615fbc4279cf78090b23fb28268787a9b178d1ad410e0f820954ec6fd", nonce: "96", blockHash: "0x1e2291b23d04d311f29271919584bfd9144404ffc69c0a84632279fbce1910a1", transactionIndex: "1", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "111405", gasUsed: "90405", confirmations: "4509407"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1486825621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0xa4f970e6425e316984208ca1ee95ca618c11a34d"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [26]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "3164360", timeStamp: "1486825734", hash: "0x5520053d7ed39b0e68480c70703e486603cf26960e963a1ba45de20bbdb6d777", nonce: "97", blockHash: "0x5201731f6bb543ace22a610e9a4b632c71ea5291c8a271a011c472a1be365cd9", transactionIndex: "4", from: "0xa4f970e6425e316984208ca1ee95ca618c11a34d", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "152869", gasUsed: "55399", confirmations: "4509399"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "exit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1486825734 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "totalBalance", type: "uint256"}], name: "newExit", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newExit", events: [{name: "player", type: "address", value: "0xa4f970e6425e316984208ca1ee95ca618c11a34d"}, {name: "totalBalance", type: "uint256", value: "95000000000000000"}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "249053042736540558" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfa8a3d2c5d2337e79d46d892abb1c6aa9a4a... )", async function( ) {
		const txOriginal = {blockNumber: "3165124", timeStamp: "1486836823", hash: "0x6e35871245f3b8cd49fd303f3e51433fa3ee68ebd3bed5a3fabba933763e9d2e", nonce: "62138", blockHash: "0x922355147881a07dac24dd295ff7efacc2671ff395b66f48889af7939eddc265", transactionIndex: "1", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "458928", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297efa8a3d2c5d2337e79d46d892abb1c6aa9a4a9bedc48d6ae4e9031e611b0d4748000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000317b3131362c203434392c203434382c203136302c203336382c203637322c203338342c203831392c2036362c203937347d000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "371451", gasUsed: "350451", confirmations: "4508635"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfa8a3d2c5d2337e79d46d892abb1c6aa9a4a9bedc48d6ae4e9031e611b0d4748"}, {type: "string", name: "result", value: `{116, 449, 448, 160, 368, 672, 384, 819, 66, 974}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xfa8a3d2c5d2337e79d46d892abb1c6aa9a4a9bedc48d6ae4e9031e611b0d4748", `{116, 449, 448, 160, 368, 672, 384, 819, 66, 974}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1486836823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 0, c: [3]}, {s: 1, e: 0, c: [9]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3170312", timeStamp: "1486911282", hash: "0xbee97585c2e11f997fea905f42f23bfb71be24114dac76e7cc18018e2f9800ad", nonce: "15", blockHash: "0xa4fc33b0214e9ba9a4b09ddc0b709c05a1eb0f07f8a74c45d750450e03167498", transactionIndex: "4", from: "0x47b5ed2279478151d1631014aa90f876fec4a136", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "191181", gasUsed: "90405", confirmations: "4503447"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1486911282 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x47b5ed2279478151d1631014aa90f876fec4a136"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [27]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2853025628824767413" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3170598", timeStamp: "1486915278", hash: "0x9d7725ee035aaab060529a5b50033be8019de5e8e9733b7d34839ccebde0bc26", nonce: "13", blockHash: "0xbcb34c95f0a8647bf398f06c7e2d805cf0b5e44114504e4da7a4e355a3388f78", transactionIndex: "3", from: "0x00a1b27aba96c12a8e7198a94b83c8a396d90158", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "100000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "198269", gasUsed: "90405", confirmations: "4503161"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1486915278 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x00a1b27aba96c12a8e7198a94b83c8a396d90158"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [28]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "18614078507735942" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x83624839e68a250ea2a2090e89f9aeb2459e... )", async function( ) {
		const txOriginal = {blockNumber: "3171182", timeStamp: "1486923260", hash: "0x0d4ffcf90a43ee44a1a008cfbf663c33b9e34d980646ca53fbbe4c9cfbd37ba0", nonce: "62455", blockHash: "0x9d17ffd148f36837b2a8a49cab587bf17d7999fe4f6e1e0ca79270e077a2c59d", transactionIndex: "7", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "448928", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e83624839e68a250ea2a2090e89f9aeb2459ec583b3174496363acffe3f7703e1000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000317b3332332c203936382c203935312c203630372c203338392c203633392c2037332c203734372c203136332c203838347d000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "749558", gasUsed: "350751", confirmations: "4502577"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x83624839e68a250ea2a2090e89f9aeb2459ec583b3174496363acffe3f7703e1"}, {type: "string", name: "result", value: `{323, 968, 951, 607, 389, 639, 73, 747, 163, 884}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x83624839e68a250ea2a2090e89f9aeb2459ec583b3174496363acffe3f7703e1", `{323, 968, 951, 607, 389, 639, 73, 747, 163, 884}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1486923260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 1, c: [17]}, {s: 1, e: 1, c: [27]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3171208", timeStamp: "1486923723", hash: "0xdad7d5708d76c0307be181722019ee41b4b7e79f8df0a5acd490f6deb26da9cf", nonce: "0", blockHash: "0x1c2f63998adab10d2040c3c470f00bc16e8fe4cc279aa3fc14904b44b6c95822", transactionIndex: "5", from: "0x13d537fae2576d6be22698d6891d577bc8de472b", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "500000000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "478014", gasUsed: "326205", confirmations: "4502551"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1486923723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x13d537fae2576d6be22698d6891d577bc8de472b"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "5"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [29]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "41246696000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x17f4869e010c72d4ef22ce45d98374e61db2... )", async function( ) {
		const txOriginal = {blockNumber: "3177245", timeStamp: "1487009673", hash: "0x06201eb365f2009be9e36ea244a14f479c902b5dc150960a5e60c1672de19682", nonce: "62570", blockHash: "0xf15c62034e3bd99179a1b6b9b671e5e40043292fa076cf49cce84598f066df87", transactionIndex: "1", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "448928", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e17f4869e010c72d4ef22ce45d98374e61db29fa2399016a32943368a29c50bbc000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000317b3431392c203636322c203539322c203737312c203536312c203636322c2034312c203439352c203639392c203237367d000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "409999", gasUsed: "372888", confirmations: "4496514"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x17f4869e010c72d4ef22ce45d98374e61db29fa2399016a32943368a29c50bbc"}, {type: "string", name: "result", value: `{419, 662, 592, 771, 561, 662, 41, 495, 699, 276}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x17f4869e010c72d4ef22ce45d98374e61db29fa2399016a32943368a29c50bbc", `{419, 662, 592, 771, 561, 662, 41, 495, 699, 276}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1487009673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [15]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "3177364", timeStamp: "1487011166", hash: "0xcb80371cb400c5ca90cbc44408a426ebf9f21b6a6e8b99d697ca2d9a82a30446", nonce: "29", blockHash: "0x728b1c957fd664d61c49eb40ad3af1b422a2a01ccd98540d1e8d4e1edcf0da01", transactionIndex: "73", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "2900601", gasUsed: "175166", confirmations: "4496395"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "exit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1487011166 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "totalBalance", type: "uint256"}], name: "newExit", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newExit", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "totalBalance", type: "uint256", value: "3642890816416291667"}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3177401", timeStamp: "1487011736", hash: "0x2c8b891fb1899f58a93ccef92c67e95756d62236da1135e5ad2ad4bdaa5141a6", nonce: "30", blockHash: "0x4931961211b559aedd2ab5816b1fc179d9fe6a7bce999202303c4c4c2a15262a", transactionIndex: "11", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "685313", gasUsed: "90569", confirmations: "4496358"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "3"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1487011736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "3"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [34]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3177423", timeStamp: "1487012107", hash: "0xc0448f0af363d11af08648bc24af62ed865c848df878378d5a220b28f278bb4b", nonce: "31", blockHash: "0xc4ed39d87ee134e3013a4eae42d8c068a2dafbb514e669cf573766b1b4477a79", transactionIndex: "16", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "500000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1732405", gasUsed: "90469", confirmations: "4496336"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "2"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1487012107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "2"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [35]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3179327", timeStamp: "1487039302", hash: "0x70411f193006af7302f877db8a6dc678fa3567dad167b6769f69b02e779cea22", nonce: "1", blockHash: "0x1bbded1d8696f7ef7bf26455250dcfe0c8697497b788f5aed3047db5b584c8b5", transactionIndex: "10", from: "0x13d537fae2576d6be22698d6891d577bc8de472b", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "200000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "300619", gasUsed: "90619", confirmations: "4494432"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "1"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1487039302 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x13d537fae2576d6be22698d6891d577bc8de472b"}, {name: "animalType", type: "uint8", value: "1"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [36]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "41246696000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x7ac09e2ce061d1b662295a8f874a7b1c0ddc... )", async function( ) {
		const txOriginal = {blockNumber: "3183316", timeStamp: "1487096097", hash: "0x40f28b9cf17a2e887341b54b58b1706ecc07fe560cadf03ed7ed61fdd1847b96", nonce: "62741", blockHash: "0x9ebc780933161cc8dd4195dabdb35c6766ab76829349ce3e75d5d176a0bc3180", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "413392", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e7ac09e2ce061d1b662295a8f874a7b1c0ddc58574c25a283815a1734de5bdb75000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000317b3637342c203934342c203235362c2035362c203335352c203135382c203939372c203233362c203632312c203439357d000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "363642", gasUsed: "300642", confirmations: "4490443"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x7ac09e2ce061d1b662295a8f874a7b1c0ddc58574c25a283815a1734de5bdb75"}, {type: "string", name: "result", value: `{674, 944, 256, 56, 355, 158, 997, 236, 621, 495}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x7ac09e2ce061d1b662295a8f874a7b1c0ddc58574c25a283815a1734de5bdb75", `{674, 944, 256, 56, 355, 158, 997, 236, 621, 495}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1487096097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 1, c: [13]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4943556f5676b12b64339edf87cb28905284... )", async function( ) {
		const txOriginal = {blockNumber: "3189343", timeStamp: "1487182514", hash: "0xec102c532b4df344ffd83b493e8d25430b648178639e836916eb4b6a0564bc4b", nonce: "63041", blockHash: "0x4721fe86e91cc16b20323bad0c000bc1cc51ccf4c28bf34e513cca9cbdd91f54", transactionIndex: "5", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "448928", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e4943556f5676b12b64339edf87cb28905284d051a133bd1c7200eec84334f4d1000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000307b3634332c203834342c203632362c203333392c203931332c203234382c203935392c2036302c2035332c203634337d00000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "499728", gasUsed: "293135", confirmations: "4484416"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4943556f5676b12b64339edf87cb28905284d051a133bd1c7200eec84334f4d1"}, {type: "string", name: "result", value: `{643, 844, 626, 339, 913, 248, 959, 60, 53, 643}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x4943556f5676b12b64339edf87cb28905284d051a133bd1c7200eec84334f4d1", `{643, 844, 626, 339, 913, 248, 959, 60, 53, 643}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1487182514 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 1, c: [12]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "3195167", timeStamp: "1487266048", hash: "0xfc7bcd32ea7bd5682d48cf878c0ec1aa8ec8f46c906d92ca97c9edffc2ae9cbf", nonce: "12", blockHash: "0x0baaca2c1e34c0ef924107759bebbfc89237a15f7940394f349579904273ca63", transactionIndex: "3", from: "0xb8b47e70dd5046882cb32152796ac63ab40cc596", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "400000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "229586", gasUsed: "166586", confirmations: "4478592"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "exit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1487266048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "totalBalance", type: "uint256"}], name: "newExit", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newExit", events: [{name: "player", type: "address", value: "0xb8b47e70dd5046882cb32152796ac63ab40cc596"}, {name: "totalBalance", type: "uint256", value: "1702737400926565965"}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "13111124973467043" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x6edd0b7da5437a4feafc9bc0e91387a019d6... )", async function( ) {
		const txOriginal = {blockNumber: "3195359", timeStamp: "1487268931", hash: "0x6f3dcc22868b3e04c7c14a0a5714e0a6ec81c26942924be285f09e9aaca5c6fe", nonce: "63429", blockHash: "0x218ac5936fd85a7ffea36c44a9992658bcd545c65312a1385eaebf0867247fd9", transactionIndex: "4", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "438928", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e6edd0b7da5437a4feafc9bc0e91387a019d62d5912ed58138c6f011047ad0bad000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000327b3638392c203335352c203330392c203731332c203632322c203331312c203332352c203736332c203739362c203830327d0000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "373771", gasUsed: "263911", confirmations: "4478400"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x6edd0b7da5437a4feafc9bc0e91387a019d62d5912ed58138c6f011047ad0bad"}, {type: "string", name: "result", value: `{689, 355, 309, 713, 622, 311, 325, 763, 796, 802}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x6edd0b7da5437a4feafc9bc0e91387a019d62d5912ed58138c6f011047ad0bad", `{689, 355, 309, 713, 622, 311, 325, 763, 796, 802}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1487268931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 1, c: [33]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "3195742", timeStamp: "1487274688", hash: "0xeca1319b0f0d399afd25c799c5f49b88cdfb4588706a76abb23a47ed1da8acaa", nonce: "66", blockHash: "0x169cbbbd3a0acb1f6e1b4b83b8e0512c82f4e30edbcab62761d91bc20848ac27", transactionIndex: "2", from: "0xc114f48b3f9828e68bf253f0b9cfb713fc54eb44", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "235394", gasUsed: "91404", confirmations: "4478017"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "exit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1487274688 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "totalBalance", type: "uint256"}], name: "newExit", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newExit", events: [{name: "player", type: "address", value: "0xc114f48b3f9828e68bf253f0b9cfb713fc54eb44"}, {name: "totalBalance", type: "uint256", value: "625597045916971978"}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "285859409164934" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x481468117922b4b943d9ff0f88221a881ee5... )", async function( ) {
		const txOriginal = {blockNumber: "3201463", timeStamp: "1487355388", hash: "0x34f5b49455b8ac3f7843b4fa31bbfeb7e0e6fbe4cbd1b249b102354422b8bc34", nonce: "63692", blockHash: "0xead12439716ab05d6d5679f220ac564def7d048066370acf5a36a5bac7ba2834", transactionIndex: "8", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "0", gas: "464464", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e481468117922b4b943d9ff0f88221a881ee5f3183d41876b7df95f6799b44054000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000317b3932362c203335302c203432312c203930312c203339332c2034372c203135342c203430352c203333352c203931397d000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "508548", gasUsed: "232074", confirmations: "4472296"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x481468117922b4b943d9ff0f88221a881ee5f3183d41876b7df95f6799b44054"}, {type: "string", name: "result", value: `{926, 350, 421, 901, 393, 47, 154, 405, 335, 919}`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x481468117922b4b943d9ff0f88221a881ee5f3183d41876b7df95f6799b44054", `{926, 350, 421, 901, 393, 47, 154, 405, 335, 919}`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1487355388 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "killedAnimals", type: "uint32[]"}], name: "newAttack", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newAttack", events: [{name: "killedAnimals", type: "uint32[]", value: [{s: 1, e: 1, c: [35]}]}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3202012", timeStamp: "1487363254", hash: "0x081b52b174b4f00df8669e982eeadfc24d533e46b0b2de235f33328c24cd3898", nonce: "32", blockHash: "0x4a24529470293c1b50d5d0b2562ec4e8dfb2bfac010d76f57e391389381314ee", transactionIndex: "22", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "675237", gasUsed: "164419", confirmations: "4471747"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "2"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1487363254 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "2"}, {name: "amount", type: "uint8", value: "2"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [37]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3202028", timeStamp: "1487363456", hash: "0x495eb8e0739103cf2e692638d143660701c172ccc3f780556f6a2147b41d87d3", nonce: "33", blockHash: "0xb3431fe0d4cd2830c80f68da3eeb6e6274e5a9a184aa8790c27212f88c7da84d", transactionIndex: "0", from: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "400000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "149619", gasUsed: "149619", confirmations: "4471731"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "1"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1487363456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x9ec5ea5015bd19c265990ab0a71b84611739d1ed"}, {name: "animalType", type: "uint8", value: "1"}, {name: "amount", type: "uint8", value: "2"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [39]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3202670", timeStamp: "1487373019", hash: "0xaef0ef2cb05c358ec24ea294cb69e89db81853676b6a646f1ad9253b2a8f2e67", nonce: "0", blockHash: "0x7c3978e64285e68a94293b3a186554302df3f49cd7190ac6f9ae56580b47ac87", transactionIndex: "2", from: "0x532c278d4e91f12de1b87588d530e1f766d4f425", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "177483", gasUsed: "90619", confirmations: "4471089"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "3"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1487373019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x532c278d4e91f12de1b87588d530e1f766d4f425"}, {name: "animalType", type: "uint8", value: "3"}, {name: "amount", type: "uint8", value: "1"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [41]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "316084662282922022" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3202679", timeStamp: "1487373166", hash: "0x3d1654d210a00d094e6b8e3cc23a2f055f11a5b0fc07b455b0bbf6b0756f39d5", nonce: "1", blockHash: "0xa9a0b4eb315d41556ec65e5fea63f2a86212e9d7447cc73718ff085f261d2ec0", transactionIndex: "4", from: "0x532c278d4e91f12de1b87588d530e1f766d4f425", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1500000000000000000", gas: "400000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "374735", gasUsed: "223319", confirmations: "4471080"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "2"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1487373166 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x532c278d4e91f12de1b87588d530e1f766d4f425"}, {name: "animalType", type: "uint8", value: "2"}, {name: "amount", type: "uint8", value: "3"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [42]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "316084662282922022" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3202688", timeStamp: "1487373295", hash: "0x09a685f9583056fe9ff6c97445dfd22f23ee6281a0a077f96714ece9650f0d2d", nonce: "2", blockHash: "0x900ccf8bffa4605e3e89466244dc7e9e2c52536112de8680a36ce27249d7ed07", transactionIndex: "4", from: "0x532c278d4e91f12de1b87588d530e1f766d4f425", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "1000000000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "728411", gasUsed: "331828", confirmations: "4471071"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "1"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1487373295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x532c278d4e91f12de1b87588d530e1f766d4f425"}, {name: "animalType", type: "uint8", value: "1"}, {name: "amount", type: "uint8", value: "5"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [45]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "316084662282922022" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3202712", timeStamp: "1487373607", hash: "0x5101c3d2dda178b783a94b9851eba8cc2e2c5d8b59ab195556602e95b0f5515b", nonce: "3", blockHash: "0x193cc22a60f3ff9bff59b5ee0257e496562dc65436339dcacad7c6b90390557e", transactionIndex: "7", from: "0x532c278d4e91f12de1b87588d530e1f766d4f425", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "2000000000000000000", gas: "2100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1643637", gasUsed: "1359493", confirmations: "4471047"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1487373607 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x532c278d4e91f12de1b87588d530e1f766d4f425"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "20"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [50]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "316084662282922022" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addAnimals( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3202752", timeStamp: "1487374084", hash: "0xf7fa5cf02f53ed6268e786f5a8dc5dd6db5e9c2e95c7b966a9e1da1dba589d2b", nonce: "4", blockHash: "0xa2fc862ecd43fd29cfe8093d5b6151b031eaaa74a40689b805cb882ef8fc1bdb", transactionIndex: "8", from: "0x532c278d4e91f12de1b87588d530e1f766d4f425", to: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e", value: "2000000000000000000", gas: "2100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3ff8c9540000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1948927", gasUsed: "1344543", confirmations: "4471007"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "animalType", value: "0"}], name: "addAnimals", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAnimals(uint8)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1487374084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "animalType", type: "uint8"}, {indexed: false, name: "amount", type: "uint8"}, {indexed: false, name: "startId", type: "uint32"}], name: "newPurchase", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "newPurchase", events: [{name: "player", type: "address", value: "0x532c278d4e91f12de1b87588d530e1f766d4f425"}, {name: "animalType", type: "uint8", value: "0"}, {name: "amount", type: "uint8", value: "20"}, {name: "startId", type: "uint32", value: {s: 1, e: 1, c: [70]}}], address: "0x807a3ef8a8dbdd7fc9863df695bbe8691e450e8e"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "316084662282922022" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
