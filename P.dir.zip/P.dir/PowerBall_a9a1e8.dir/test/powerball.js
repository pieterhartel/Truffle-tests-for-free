const PowerBall = artifacts.require( "./PowerBall.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PowerBall" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x611A99AefEF3736507752cc5628300C5E6A9a1e8", "0x374cC1ed754A448276380872786659ab532CD7fC", "0xF73823D62f8006E8cBF39Ba630479EFDA59419C9", "0x0b744af1F0E55AFBeAb8212B00bBf2586F0EBB8F", "0x6dD465891AcB3570F122f5E7E52eeAA406992Dcf", "0xbD6E06b04c2582c4373741ef6EDf39AB37Eb964C", "0x105f00Ad5f0E6931128F31F33cbd9C350deE14Ce", "0xf46F868B112019EFA99b597410cb10e8660ffE43", "0x36DEC6C2EA0423FE75Ae520FFFBca25BF033FB3C", "0xC5B43Df6Ae0FfC80bDb3E3470055d2285036e848", "0xe353631e52dB3705A008253e055043F0787Bf539", "0xcCaA465cBe4060c742f85CB03209d80d810f8B24", "0xFD11AcF1304aC03A99EE1dD0785958Cce2D48DcA", "0x164d5147063E61FD662600AeA72502BFe2a2aB67", "0x0Eb2Fd4929957C93d337A18D986A43aF59d41cb5", "0xdADA735fdcB5dA0cE3620bf94081A2737673af01", "0xa35b534D1b7BeB1a1770FF65e7f575d9D33E42cc", "0x4b88e5a578633e2820fe815FC2E5dFFDD658021b", "0xBDb09b85c9B5E5f79a692F9D20B13a6D32b0c63F", "0xAFF5D4B0C86Fd41930Cc98aA9806bd929ef588e9", "0x7ff6A533bFE240a51F83F04F8Df7149fDf8e00eB", "0x37fc3c160bF0D16eA418e9528f2b51c0f1e5D89B", "0x80a4b153f51F090EDA445dF7c31f57BDbd437bAe", "0xa4D19771D32d1A196944A41Fd41c22a254Bc0011", "0xd4377C74d8E7F68cB7ED9fa5db0931be2391BDE4", "0x357f74F60F518Bd99c90d366Ba2EAE17413283b0", "0xCe2c0072C25F397F95A7CA7565319FE4B20f1925", "0x5aAb56a7FF435b05Ef48981f86C9A81e5c3FB067", "0x287219EF81f77716b976D242C93070833d610657", "0xEb612D1bcFF6d31eAEa10eb77a622C5d140485A1", "0xD19C20C77ef533D6c834382970De3f5477bF6249"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "prizes", outputs: [{name: "special", type: "address"}, {name: "first", type: "address"}, {name: "second", type: "address"}, {name: "third", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_player", type: "address"}, {name: "_drawDate", type: "uint32"}], name: "ticketsOfPlayer", outputs: [{name: "_count", type: "uint32"}, {name: "_tickets", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_drawDate", type: "uint32"}], name: "viewTicketsInRound", outputs: [{name: "_count", type: "uint32"}, {name: "_tickets", type: "string"}, {name: "_revenue", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_ticketID", type: "uint256"}], name: "ticket", outputs: [{name: "_player", type: "address"}, {name: "_drawDate", type: "uint32"}, {name: "_price", type: "uint64"}, {name: "_balls", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_drawDate", type: "uint32"}], name: "viewResult", outputs: [{name: "_revenue", type: "uint256"}, {name: "_special", type: "string"}, {name: "_first", type: "string"}, {name: "_second", type: "string"}, {name: "_third", type: "string"}, {name: "_result", type: "string"}, {name: "_wasDrawn", type: "bool"}, {name: "_wasAwarded", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ViewCumulativeAward", outputs: [{name: "_special", type: "uint256"}, {name: "_first", type: "uint256"}, {name: "_second", type: "uint256"}, {name: "_third", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ticketInfo", outputs: [{name: "priceTicket", type: "uint64"}, {name: "specialPrize", type: "uint8"}, {name: "firstPrize", type: "uint8"}, {name: "secondPrize", type: "uint8"}, {name: "thirdPrize", type: "uint8"}, {name: "commission", type: "uint8"}, {name: "sales", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "prize", type: "string"}, {indexed: false, name: "drawDate", type: "uint256"}, {indexed: false, name: "amout", type: "uint256"}, {indexed: false, name: "winners", type: "address[]"}, {indexed: false, name: "result", type: "uint8[5]"}], name: "logGetPrize", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "prize", type: "string"}, {indexed: false, name: "drawDate", type: "uint256"}, {indexed: false, name: "amout", type: "uint256"}, {indexed: false, name: "winners", type: "address[]"}, {indexed: false, name: "result", type: "uint8[5]"}], name: "logAward", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}, {indexed: false, name: "amout", type: "uint256"}], name: "logWithdraw", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["logBuyTicketSumary(address,uint32[],uint256)", "logGetPrize(string,uint256,uint256,address[],uint8[5])", "logAward(string,uint256,uint256,address[],uint8[5])", "logWithdraw(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x7b56205e0cf16380fab77d2e7a9cca5728c77bc199e749341eec38f76dcada64", "0x072dba670d3e471798860767ea4ef1dd22d64f63ba92c6a063d8cd9b9326c39e", "0x75b3832cbbab64ec1d994ae708b2160067005d1c238cc31fb9943b53f8912290", "0x92f465beff468d0ef38bda350d800e7fad71e00c97651730cd166bfe10893a8f"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6583100 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6624490 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "PowerBall", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "prizes", outputs: [{name: "special", type: "address"}, {name: "first", type: "address"}, {name: "second", type: "address"}, {name: "third", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prizes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint32", name: "_drawDate", value: random.range( maxRandom )}], name: "ticketsOfPlayer", outputs: [{name: "_count", type: "uint32"}, {name: "_tickets", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ticketsOfPlayer(address,uint32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "_drawDate", value: random.range( maxRandom )}], name: "viewTicketsInRound", outputs: [{name: "_count", type: "uint32"}, {name: "_tickets", type: "string"}, {name: "_revenue", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "viewTicketsInRound(uint32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_ticketID", value: random.range( maxRandom )}], name: "ticket", outputs: [{name: "_player", type: "address"}, {name: "_drawDate", type: "uint32"}, {name: "_price", type: "uint64"}, {name: "_balls", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ticket(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint32", name: "_drawDate", value: random.range( maxRandom )}], name: "viewResult", outputs: [{name: "_revenue", type: "uint256"}, {name: "_special", type: "string"}, {name: "_first", type: "string"}, {name: "_second", type: "string"}, {name: "_third", type: "string"}, {name: "_result", type: "string"}, {name: "_wasDrawn", type: "bool"}, {name: "_wasAwarded", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "viewResult(uint32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ViewCumulativeAward", outputs: [{name: "_special", type: "uint256"}, {name: "_first", type: "uint256"}, {name: "_second", type: "uint256"}, {name: "_third", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ViewCumulativeAward()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ticketInfo", outputs: [{name: "priceTicket", type: "uint64"}, {name: "specialPrize", type: "uint8"}, {name: "firstPrize", type: "uint8"}, {name: "secondPrize", type: "uint8"}, {name: "thirdPrize", type: "uint8"}, {name: "commission", type: "uint8"}, {name: "sales", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ticketInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PowerBall", function( accounts ) {

	it( "TEST: PowerBall(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6583100", timeStamp: "1540501785", hash: "0xeaca712cec6af01b4f2e8ac6e6d24231154b35093c2ddd29c48371bae49bca27", nonce: "429", blockHash: "0x4aff63d7b55eadab2c2f1036a0f450ce6ac3f92d1b61d3dbd2ce82e334c7c817", transactionIndex: "7", from: "0x105f00ad5f0e6931128f31f33cbd9c350dee14ce", to: 0, value: "0", gas: "4421023", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xe207afd5", contractAddress: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", cumulativeGasUsed: "4824355", gasUsed: "4421023", confirmations: "1151242"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "PowerBall", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PowerBall.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540501785 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PowerBall.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "43450950400673200" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6583157", timeStamp: "1540502548", hash: "0x1c44a281889c743c96dce4c158f8c32d515185e26b447bb617d6cfe3dbce111f", nonce: "430", blockHash: "0x90c304dfecfb95c27158dbe44974686c035fd634c2bf8679ad9e2031c081e3c7", transactionIndex: "126", from: "0x105f00ad5f0e6931128f31f33cbd9c350dee14ce", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "28945", gasPrice: "4700000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b000000000000000000000000f46f868b112019efa99b597410cb10e8660ffe43", contractAddress: "", cumulativeGasUsed: "6031649", gasUsed: "28945", confirmations: "1151185"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[9]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540502548 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "43450950400673200" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[8], \"20181030\", [\"40\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6583264", timeStamp: "1540504012", hash: "0x85a0bc91986435a3801d28508b9616569bc0c3b06443b4a0a64fc70a000857fe", nonce: "7", blockHash: "0x3d9af6245f3bbe421135f3f6d16443ac406aceafacee02c2c1842fbba9df9a2a", transactionIndex: "51", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "158660", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000105f00ad5f0e6931128f31f33cbd9c350dee14ce000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000280000000000000000000000000000000000000000000000000000000000000031000000000000000000000000000000000000000000000000000000000000003b000000000000000000000000000000000000000000000000000000000000003f0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "4122022", gasUsed: "158660", confirmations: "1151078"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[8]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["40","49","59","63","20"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[8], "20181030", ["40","49","59","63","20"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540504012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x105f00ad5f0e6931128f31f33cbd9c350dee14ce"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 0, c: [1]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[8], \"20181030\", [\"21\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6583287", timeStamp: "1540504392", hash: "0xc7894baab58fd0b5d7665cb861235aef5c616517251d3b394a3d31fd2a5cac11", nonce: "8", blockHash: "0x48d6b636c0ef93aac65983bbb4f47c1ca69042cddb1a95d85a63d605bcdfe45a", transactionIndex: "1", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000105f00ad5f0e6931128f31f33cbd9c350dee14ce000000000000000000000000000000000000000000000000000000000133f026000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000015000000000000000000000000000000000000000000000000000000000000001e0000000000000000000000000000000000000000000000000000000000000039000000000000000000000000000000000000000000000000000000000000003a0000000000000000000000000000000000000000000000000000000000000018", contractAddress: "", cumulativeGasUsed: "150556", gasUsed: "113710", confirmations: "1151055"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[8]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["21","30","57","58","24"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[8], "20181030", ["21","30","57","58","24"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540504392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x105f00ad5f0e6931128f31f33cbd9c350dee14ce"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 0, c: [2]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[8], \"20181030\", [\"30\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6583302", timeStamp: "1540504650", hash: "0xc7da1c500dd61e3c303a33c874530e3a6b8b7b91c302e2a200fdb6ced0fe54fd", nonce: "9", blockHash: "0xb8c8b0ff517b9d3e723e94a510bbe06266e97646f17147801adbff639022f7c1", transactionIndex: "50", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000105f00ad5f0e6931128f31f33cbd9c350dee14ce000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000002300000000000000000000000000000000000000000000000000000000000000310000000000000000000000000000000000000000000000000000000000000044000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "2683817", gasUsed: "113710", confirmations: "1151040"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[8]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["30","35","49","68","14"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[8], "20181030", ["30","35","49","68","14"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540504650 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x105f00ad5f0e6931128f31f33cbd9c350dee14ce"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 0, c: [3]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[8], \"20181102\", [\"24\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6583312", timeStamp: "1540504766", hash: "0x9093d5ecb95beed18b1f5ebf9b23894b5cfce988e53aa0250e81e144a49a39f9", nonce: "10", blockHash: "0x740d9f0b41d872c98d70d4701bf7c590100f525bce45958d6d6174e2f0424085", transactionIndex: "31", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000105f00ad5f0e6931128f31f33cbd9c350dee14ce000000000000000000000000000000000000000000000000000000000133f06e00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000250000000000000000000000000000000000000000000000000000000000000026000000000000000000000000000000000000000000000000000000000000003d0000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "1902575", gasUsed: "143660", confirmations: "1151030"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[8]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["24","37","38","61","7"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[8], "20181102", ["24","37","38","61","7"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540504766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x105f00ad5f0e6931128f31f33cbd9c350dee14ce"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 0, c: [4]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: cumulativeAward( \"11920800\", \"794720\", \"169500\", \"... )", async function( ) {
		const txOriginal = {blockNumber: "6583566", timeStamp: "1540508551", hash: "0xc5527a970528003adb022ed48cd351d14cd91dcf4ea2ede7dd7278d9e3e76f3a", nonce: "11", blockHash: "0x70ce48e9063df321f01058690de532e2d26c6c6b1fe3f54f601f91931ada6ab7", transactionIndex: "33", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "90195", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4b886f7e0000000000000000000000000000000000000000000000000000000000b5e5a000000000000000000000000000000000000000000000000000000000000c2060000000000000000000000000000000000000000000000000000000000002961c0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7654368", gasUsed: "90195", confirmations: "1150776"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_special", value: "11920800"}, {type: "uint256", name: "_first", value: "794720"}, {type: "uint256", name: "_second", value: "169500"}, {type: "uint256", name: "_third", value: "0"}], name: "cumulativeAward", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cumulativeAward(uint256,uint256,uint256,uint256)" ]( "11920800", "794720", "169500", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540508551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[10], \"20181030\", [\"8\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6584521", timeStamp: "1540521843", hash: "0x014267c8dfa5065c684ed15b379aab32186b9114e43f90d9bed7e0efc6cb92bf", nonce: "12", blockHash: "0x625e0ee11a71cee44744300f471421a990d134f4d4165b5809dc763ef0246e80", transactionIndex: "44", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000036dec6c2ea0423fe75ae520fffbca25bf033fb3c000000000000000000000000000000000000000000000000000000000133f026000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000002f00000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "1986977", gasUsed: "113774", confirmations: "1149821"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[10]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["8","11","47","56","7"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[10], "20181030", ["8","11","47","56","7"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540521843 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x36dec6c2ea0423fe75ae520fffbca25bf033fb3c"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 0, c: [5]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[11], \"20181030\", [\"12\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6587545", timeStamp: "1540564864", hash: "0x2bfcdf7f0e51d1e93ba5c1b03a9894af418541a9fec99519183fc07f2993fac8", nonce: "13", blockHash: "0x2495aa63d42dc4df87e477ef19390001273c1e81aa6e8d0875d9bc6d6fc5715d", transactionIndex: "0", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000c5b43df6ae0ffc80bdb3e3470055d2285036e848000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000002e000000000000000000000000000000000000000000000000000000000000004300000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000042000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000002b00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000001d00000000000000000000000000000000000000000000000000000000000000270000000000000000000000000000000000000000000000000000000000000029000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000001a0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003c000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001d0000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000002900000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000002b00000000000000000000000000000000000000000000000000000000000000370000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003b00000000000000000000000000000000000000000000000000000000000000410000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000002d00000000000000000000000000000000000000000000000000000000000000360000000000000000000000000000000000000000000000000000000000000037000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000002e0000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001d00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000210000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000002700000000000000000000000000000000000000000000000000000000000000430000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000270000000000000000000000000000000000000000000000000000000000000035000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000370000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000036000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000000000000000130000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000003e0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002300000000000000000000000000000000000000000000000000000000000000240000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003800000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000015000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000033000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000220000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002e00000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001700000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002f000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "1688866", gasUsed: "1688866", confirmations: "1146797"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[11]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["12","30","46","67","8","24","28","57","66","14","15","16","36","43","20","22","29","39","41","13","23","26","48","60","15","27","29","35","41","20","24","43","55","56","14","34","44","59","65","9","45","54","55","60","20","10","11","25","46","23","28","29","32","35","25","33","34","39","67","17","12","20","39","53","8","16","36","48","55","7","18","38","54","60","17","13","19","36","62","16","35","36","48","56","16","21","30","50","51","6","34","40","46","56","18","23","25","40","47","13"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[11], "20181030", ["12","30","46","67","8","24","28","57","66","14","15","16","36","43","20","22","29","39","41","13","23","26","48","60","15","27","29","35","41","20","24","43","55","56","14","34","44","59","65","9","45","54","55","60","20","10","11","25","46","23","28","29","32","35","25","33","34","39","67","17","12","20","39","53","8","16","36","48","55","7","18","38","54","60","17","13","19","36","62","16","35","36","48","56","16","21","30","50","51","6","34","40","46","56","18","23","25","40","47","13"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540564864 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xc5b43df6ae0ffc80bdb3e3470055d2285036e848"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 0, c: [6]}, {s: 1, e: 0, c: [7]}, {s: 1, e: 0, c: [8]}, {s: 1, e: 0, c: [9]}, {s: 1, e: 1, c: [10]}, {s: 1, e: 1, c: [11]}, {s: 1, e: 1, c: [12]}, {s: 1, e: 1, c: [13]}, {s: 1, e: 1, c: [14]}, {s: 1, e: 1, c: [15]}, {s: 1, e: 1, c: [16]}, {s: 1, e: 1, c: [17]}, {s: 1, e: 1, c: [18]}, {s: 1, e: 1, c: [19]}, {s: 1, e: 1, c: [20]}, {s: 1, e: 1, c: [21]}, {s: 1, e: 1, c: [22]}, {s: 1, e: 1, c: [23]}, {s: 1, e: 1, c: [24]}, {s: 1, e: 1, c: [25]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[12], \"20181030\", [\"8\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6587701", timeStamp: "1540566931", hash: "0x3b4f03367a229566f4828cc8d416db16e0fe63317b23061fbf2f79663512ff09", nonce: "14", blockHash: "0x69895d4ae835ea05a576513a8fc50678721f1271862cc1f72f41077ef5d7d2b9", transactionIndex: "9", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000e353631e52db3705a008253e055043f0787bf539000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000016", contractAddress: "", cumulativeGasUsed: "569077", gasUsed: "128724", confirmations: "1146641"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[12]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["8","40","44","57","22"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[12], "20181030", ["8","40","44","57","22"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540566931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xe353631e52db3705a008253e055043f0787bf539"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [26]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[13], \"20181030\", [\"14\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6588362", timeStamp: "1540576349", hash: "0x5b55f790ac5a244471f6ef5f731129e0c126b2d97d69ecf5ba485ab250d7a937", nonce: "15", blockHash: "0x9d3d55cb1b0eba979c2c29cc863f01150495031232ca7073f585855b11c0d146", transactionIndex: "20", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000ccaa465cbe4060c742f85cb03209d80d810f8b24000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000001d000000000000000000000000000000000000000000000000000000000000003d0000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "878779", gasUsed: "113774", confirmations: "1145980"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[13]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["14","26","29","61","8"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[13], "20181030", ["14","26","29","61","8"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540576349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xccaa465cbe4060c742f85cb03209d80d810f8b24"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [27]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[14], \"20181030\", [\"17\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6588362", timeStamp: "1540576349", hash: "0x781106dcd313866a18331c896ef9a854ffc2ffea7ca1b08204e65764f139d418", nonce: "16", blockHash: "0x9d3d55cb1b0eba979c2c29cc863f01150495031232ca7073f585855b11c0d146", transactionIndex: "23", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000fd11acf1304ac03a99ee1dd0785958cce2d48dca000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000002a00000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "1200318", gasUsed: "113774", confirmations: "1145980"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[14]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["17","22","42","57","8"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[14], "20181030", ["17","22","42","57","8"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540576349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xfd11acf1304ac03a99ee1dd0785958cce2d48dca"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [28]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[15], \"20181030\", [\"19\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6588365", timeStamp: "1540576367", hash: "0x38e34df5534c868c211cc3dbf11fbc9f33218bff8fd89ebf3f3a62a47171648f", nonce: "17", blockHash: "0xbb783ecf2512b2db5f100b27697f36a0da982147b9d543f0610727d2b3b780c7", transactionIndex: "70", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000164d5147063e61fd662600aea72502bfe2a2ab67000000000000000000000000000000000000000000000000000000000133f026000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000013000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000230000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000230000000000000000000000000000000000000000000000000000000000000033000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000026000000000000000000000000000000000000000000000000000000000000002a0000000000000000000000000000000000000000000000000000000000000041000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003e000000000000000000000000000000000000000000000000000000000000004600000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "3294278", gasUsed: "439021", confirmations: "1145977"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[15]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["19","30","35","64","12","25","28","35","51","12","17","38","42","65","10","34","44","62","70","7","2","11","12","14","9"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[15], "20181030", ["19","30","35","64","12","25","28","35","51","12","17","38","42","65","10","34","44","62","70","7","2","11","12","14","9"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540576367 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x164d5147063e61fd662600aea72502bfe2a2ab67"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [29]}, {s: 1, e: 1, c: [30]}, {s: 1, e: 1, c: [31]}, {s: 1, e: 1, c: [32]}, {s: 1, e: 1, c: [33]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[16], \"20181030\", [\"11\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6588382", timeStamp: "1540576596", hash: "0x6cdb2d698eb54bf70c3532b096752a37c7ff88693f665d521c807b2114749e65", nonce: "18", blockHash: "0x64e0fded21bb89076b87dee3a4712a61109c42310e931cbd93dd95af4e4dc8de", transactionIndex: "21", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb85610000000000000000000000000eb2fd4929957c93d337a18d986a43af59d41cb5000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000033000000000000000000000000000000000000000000000000000000000000003d000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000002b000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000002f0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000210000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000002a000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000013000000000000000000000000000000000000000000000000000000000000002a000000000000000000000000000000000000000000000000000000000000003f0000000000000000000000000000000000000000000000000000000000000044000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "1819624", gasUsed: "454035", confirmations: "1145960"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[16]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["11","38","51","61","11","15","43","44","47","16","10","33","34","42","12","19","42","63","68","11","4","10","23","28","18"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[16], "20181030", ["11","38","51","61","11","15","43","44","47","16","10","33","34","42","12","19","42","63","68","11","4","10","23","28","18"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540576596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x0eb2fd4929957c93d337a18d986a43af59d41cb5"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [34]}, {s: 1, e: 1, c: [35]}, {s: 1, e: 1, c: [36]}, {s: 1, e: 1, c: [37]}, {s: 1, e: 1, c: [38]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[17], \"20181030\", [\"10\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6588382", timeStamp: "1540576596", hash: "0xb0e3fcee75a757a7ab36aeba240254de0a220a9ff4fba0524df944c6086491a3", nonce: "19", blockHash: "0x64e0fded21bb89076b87dee3a4712a61109c42310e931cbd93dd95af4e4dc8de", transactionIndex: "22", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000dada735fdcb5da0ce3620bf94081a2737673af01000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000220000000000000000000000000000000000000000000000000000000000000033000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000002b000000000000000000000000000000000000000000000000000000000000002f0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000003e00000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000002b00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000003500000000000000000000000000000000000000000000000000000000000000410000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "2273659", gasUsed: "454035", confirmations: "1145960"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[17]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["10","25","34","51","1","21","35","43","47","8","16","25","35","62","17","22","27","36","43","6","1","27","53","65","7"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[17], "20181030", ["10","25","34","51","1","21","35","43","47","8","16","25","35","62","17","22","27","36","43","6","1","27","53","65","7"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540576596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xdada735fdcb5da0ce3620bf94081a2737673af01"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [39]}, {s: 1, e: 1, c: [40]}, {s: 1, e: 1, c: [41]}, {s: 1, e: 1, c: [42]}, {s: 1, e: 1, c: [43]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[18], \"20181030\", [\"18\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6588382", timeStamp: "1540576596", hash: "0xdf02a3ac167d72af0a88738461eacb77ae33077e7bfd566c19594525dcfbbe24", nonce: "20", blockHash: "0x64e0fded21bb89076b87dee3a4712a61109c42310e931cbd93dd95af4e4dc8de", transactionIndex: "23", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000a35b534d1b7beb1a1770ff65e7f575d9d33e42cc000000000000000000000000000000000000000000000000000000000133f026000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001f0000000000000000000000000000000000000000000000000000000000000026000000000000000000000000000000000000000000000000000000000000002e00000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001300000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000039000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000026000000000000000000000000000000000000000000000000000000000000002d00000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000000000000043000000000000000000000000000000000000000000000000000000000000004400000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000360000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "2712744", gasUsed: "439085", confirmations: "1145960"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[18]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["18","31","38","46","21","18","19","32","57","9","18","38","45","48","6","10","45","67","68","5","5","12","28","54","4"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[18], "20181030", ["18","31","38","46","21","18","19","32","57","9","18","38","45","48","6","10","45","67","68","5","5","12","28","54","4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540576596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xa35b534d1b7beb1a1770ff65e7f575d9d33e42cc"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [44]}, {s: 1, e: 1, c: [45]}, {s: 1, e: 1, c: [46]}, {s: 1, e: 1, c: [47]}, {s: 1, e: 1, c: [48]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[19], \"20181030\", [\"8\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6588861", timeStamp: "1540583629", hash: "0xdd9ad77b77f13133bbb5abd8290cbdbc320cd60b67407c69ec2bfaa2c63db47b", nonce: "21", blockHash: "0xb18ff256aa2737155a78d3212e2b41280ace6aa65aeaa8f1ceb4325335e46751", transactionIndex: "49", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb85610000000000000000000000004b88e5a578633e2820fe815fc2e5dffdd658021b000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000130000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000002b0000000000000000000000000000000000000000000000000000000000000019", contractAddress: "", cumulativeGasUsed: "2636695", gasUsed: "113774", confirmations: "1145481"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[19]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["8","19","36","43","25"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[19], "20181030", ["8","19","36","43","25"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540583629 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x4b88e5a578633e2820fe815fc2e5dffdd658021b"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [49]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[19], \"20181102\", [\"30\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6588861", timeStamp: "1540583629", hash: "0x08f82d79a90195bac2e5eca3c509b55fb4652cc9f30ecd4c09f3be72767cacb1", nonce: "22", blockHash: "0xb18ff256aa2737155a78d3212e2b41280ace6aa65aeaa8f1ceb4325335e46751", transactionIndex: "50", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb85610000000000000000000000004b88e5a578633e2820fe815fc2e5dffdd658021b000000000000000000000000000000000000000000000000000000000133f06e00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000001e0000000000000000000000000000000000000000000000000000000000000031000000000000000000000000000000000000000000000000000000000000003700000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2750469", gasUsed: "113774", confirmations: "1145481"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[19]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["30","49","55","66","3"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[19], "20181102", ["30","49","55","66","3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540583629 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x4b88e5a578633e2820fe815fc2e5dffdd658021b"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [50]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[20], \"20181030\", [\"5\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6590672", timeStamp: "1540608744", hash: "0x28d03ca814746ec58955764743ed1f882d7299accc4578574f8a7b2d9c330091", nonce: "23", blockHash: "0x8d41c086efdcd7e02f509759e4ef4c325bf20aef40a6b4df47ffa8cd67310483", transactionIndex: "56", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000bdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "2023834", gasUsed: "128724", confirmations: "1143670"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[20]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["5","16","36","45","7"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[20], "20181030", ["5","16","36","45","7"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540608744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xbdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [51]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[20], \"20181030\", [\"9\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6590791", timeStamp: "1540610296", hash: "0x5ef4c6af6fa75a65a7501be50c84e453df329226c672894ccbd1a554ef6c4d77", nonce: "24", blockHash: "0xd99fb78ead60ff48bcfc40b7c854c0ad66e58c7dc180174651627d069da4541d", transactionIndex: "49", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000bdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "1970929", gasUsed: "113774", confirmations: "1143551"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[20]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["9","16","33","57","18"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[20], "20181030", ["9","16","33","57","18"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540610296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xbdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [52]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[20], \"20181030\", [\"6\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6590915", timeStamp: "1540611998", hash: "0x437b96d22bed6597c86b5271547eb27a382762796330cdce51a4fc134dc47adf", nonce: "25", blockHash: "0xa121fc920105b8bd533e942b095e405c26a98f3c092da5d880eb197fc34b7266", transactionIndex: "45", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000bdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001a00000000000000000000000000000000000000000000000000000000000000310000000000000000000000000000000000000000000000000000000000000010", contractAddress: "", cumulativeGasUsed: "1817955", gasUsed: "113774", confirmations: "1143427"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[20]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["6","18","26","49","16"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[20], "20181030", ["6","18","26","49","16"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540611998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xbdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [53]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[21], \"20181030\", [\"11\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6592925", timeStamp: "1540640865", hash: "0xea8d07f6814d00f183c6df507ea21438ab16f0b0abb38324cde91b1ccde855b9", nonce: "26", blockHash: "0xbd1431dd718d6097b705ca0d0faa42461294d86a58a4ee4ff8ce5e00bdd3cb81", transactionIndex: "32", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000aff5d4b0c86fd41930cc98aa9806bd929ef588e9000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000002a0000000000000000000000000000000000000000000000000000000000000046000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000037000000000000000000000000000000000000000000000000000000000000003b000000000000000000000000000000000000000000000000000000000000004400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000330000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000001f0000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000003900000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000031000000000000000000000000000000000000000000000000000000000000003400000000000000000000000000000000000000000000000000000000000000350000000000000000000000000000000000000000000000000000000000000037000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000000000000000000280000000000000000000000000000000000000000000000000000000000000029000000000000000000000000000000000000000000000000000000000000002f000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000220000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000003f000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000310000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000230000000000000000000000000000000000000000000000000000000000000035000000000000000000000000000000000000000000000000000000000000003e000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000170000000000000000000000000000000000000000000000000000000000000027000000000000000000000000000000000000000000000000000000000000003a00000000000000000000000000000000000000000000000000000000000000130000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000002b000000000000000000000000000000000000000000000000000000000000002e00000000000000000000000000000000000000000000000000000000000000410000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000270000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000002e000000000000000000000000000000000000000000000000000000000000002f000000000000000000000000000000000000000000000000000000000000003500000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000002a000000000000000000000000000000000000000000000000000000000000002b000000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000210000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003f0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000004300000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000003a000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000460000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000220000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000003f0000000000000000000000000000000000000000000000000000000000000016", contractAddress: "", cumulativeGasUsed: "4349124", gasUsed: "1688930", confirmations: "1141417"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[21]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["11","34","42","70","2","20","55","59","68","3","17","26","28","51","9","28","34","44","60","7","26","31","40","57","6","49","52","53","55","26","33","40","41","47","12","27","34","50","63","14","14","23","48","49","3","25","35","53","62","6","18","24","50","64","16","14","23","39","58","19","24","43","46","65","24","25","39","48","60","25","23","46","47","53","21","24","42","43","45","8","16","33","52","63","2","26","27","30","67","18","35","58","60","70","18","11","34","56","63","22"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[21], "20181030", ["11","34","42","70","2","20","55","59","68","3","17","26","28","51","9","28","34","44","60","7","26","31","40","57","6","49","52","53","55","26","33","40","41","47","12","27","34","50","63","14","14","23","48","49","3","25","35","53","62","6","18","24","50","64","16","14","23","39","58","19","24","43","46","65","24","25","39","48","60","25","23","46","47","53","21","24","42","43","45","8","16","33","52","63","2","26","27","30","67","18","35","58","60","70","18","11","34","56","63","22"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540640865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xaff5d4b0c86fd41930cc98aa9806bd929ef588e9"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [54]}, {s: 1, e: 1, c: [55]}, {s: 1, e: 1, c: [56]}, {s: 1, e: 1, c: [57]}, {s: 1, e: 1, c: [58]}, {s: 1, e: 1, c: [59]}, {s: 1, e: 1, c: [60]}, {s: 1, e: 1, c: [61]}, {s: 1, e: 1, c: [62]}, {s: 1, e: 1, c: [63]}, {s: 1, e: 1, c: [64]}, {s: 1, e: 1, c: [65]}, {s: 1, e: 1, c: [66]}, {s: 1, e: 1, c: [67]}, {s: 1, e: 1, c: [68]}, {s: 1, e: 1, c: [69]}, {s: 1, e: 1, c: [70]}, {s: 1, e: 1, c: [71]}, {s: 1, e: 1, c: [72]}, {s: 1, e: 1, c: [73]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[21], \"20181030\", [\"20\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6592928", timeStamp: "1540640895", hash: "0x41ee0c0e90830f7e01dcff10a9205fbf2957fdf8054fd4d98fa56a1e6dad4e5e", nonce: "27", blockHash: "0x9abdd311c70f274013b3fc19b8a6e400759ee49e2e587b400ecec47dcd3341fd", transactionIndex: "34", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000aff5d4b0c86fd41930cc98aa9806bd929ef588e9000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000002b0000000000000000000000000000000000000000000000000000000000000045000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001300000000000000000000000000000000000000000000000000000000000000210000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000003a0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000220000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000002c0000000000000000000000000000000000000000000000000000000000000039000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000001a00000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000045000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000003b000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002e000000000000000000000000000000000000000000000000000000000000003d000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000210000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001f000000000000000000000000000000000000000000000000000000000000003e00000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003900000000000000000000000000000000000000000000000000000000000000410000000000000000000000000000000000000000000000000000000000000043000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000021000000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000004200000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001d000000000000000000000000000000000000000000000000000000000000002a0000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000027000000000000000000000000000000000000000000000000000000000000003b000000000000000000000000000000000000000000000000000000000000001a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000004300000000000000000000000000000000000000000000000000000000000000450000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001e0000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000170000000000000000000000000000000000000000000000000000000000000034000000000000000000000000000000000000000000000000000000000000003a000000000000000000000000000000000000000000000000000000000000003e00000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000002e000000000000000000000000000000000000000000000000000000000000003900000000000000000000000000000000000000000000000000000000000000430000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003700000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "3635216", gasUsed: "1703880", confirmations: "1141414"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[21]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["20","25","43","69","12","19","33","35","58","2","15","16","30","34","5","10","44","57","60","25","23","26","50","69","15","18","50","59","60","24","28","32","46","61","13","11","26","30","38","4","12","13","14","33","24","12","27","31","62","3","16","57","65","67","14","33","45","64","66","17","16","29","42","52","10","17","18","39","59","26","32","34","67","69","22","10","27","30","52","4","23","52","58","62","7","24","46","57","67","22","28","38","50","60","7","27","48","55","57","23"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[21], "20181030", ["20","25","43","69","12","19","33","35","58","2","15","16","30","34","5","10","44","57","60","25","23","26","50","69","15","18","50","59","60","24","28","32","46","61","13","11","26","30","38","4","12","13","14","33","24","12","27","31","62","3","16","57","65","67","14","33","45","64","66","17","16","29","42","52","10","17","18","39","59","26","32","34","67","69","22","10","27","30","52","4","23","52","58","62","7","24","46","57","67","22","28","38","50","60","7","27","48","55","57","23"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540640895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xaff5d4b0c86fd41930cc98aa9806bd929ef588e9"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [74]}, {s: 1, e: 1, c: [75]}, {s: 1, e: 1, c: [76]}, {s: 1, e: 1, c: [77]}, {s: 1, e: 1, c: [78]}, {s: 1, e: 1, c: [79]}, {s: 1, e: 1, c: [80]}, {s: 1, e: 1, c: [81]}, {s: 1, e: 1, c: [82]}, {s: 1, e: 1, c: [83]}, {s: 1, e: 1, c: [84]}, {s: 1, e: 1, c: [85]}, {s: 1, e: 1, c: [86]}, {s: 1, e: 1, c: [87]}, {s: 1, e: 1, c: [88]}, {s: 1, e: 1, c: [89]}, {s: 1, e: 1, c: [90]}, {s: 1, e: 1, c: [91]}, {s: 1, e: 1, c: [92]}, {s: 1, e: 1, c: [93]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[22], \"20181030\", [\"7\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6593080", timeStamp: "1540643092", hash: "0xc68b71b93622a81b1c3917a09cb9e050214aea2320a6c741b16fd11a33787e56", nonce: "28", blockHash: "0x7eff0e24ee7585f84dec0597d6b217e426a6c3ded697d936f0089cc391ee8430", transactionIndex: "4", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb85610000000000000000000000007ff6a533bfe240a51f83f04f8df7149fdf8e00eb000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000002f0000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "326214", gasUsed: "113710", confirmations: "1141262"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[22]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["7","17","27","47","7"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[22], "20181030", ["7","17","27","47","7"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540643092 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x7ff6a533bfe240a51f83f04f8df7149fdf8e00eb"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [94]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[10], \"20181030\", [\"29\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6593082", timeStamp: "1540643114", hash: "0xc740967f1b884d663b60dd13d4abda358e28f2c6ee497b46389da6a10d71c710", nonce: "29", blockHash: "0x20b6ee6fa0597494236f6f2fe937e024e496b67aa3224459a5c278c56ce9b0f2", transactionIndex: "56", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000036dec6c2ea0423fe75ae520fffbca25bf033fb3c000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000001d0000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000002d00000000000000000000000000000000000000000000000000000000000000310000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "3108479", gasUsed: "113774", confirmations: "1141260"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[10]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["29","34","45","49","23"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[10], "20181030", ["29","34","45","49","23"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540643114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x36dec6c2ea0423fe75ae520fffbca25bf033fb3c"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [95]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[23], \"20181030\", [\"2\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6593535", timeStamp: "1540649327", hash: "0xb55d7e26cd7ab26293a3f8ebab927b33fd34decbeed05308ec3b620403543b85", nonce: "30", blockHash: "0xbc06e485000e468fa5a88b853581ae89f699921066b6ff4dec66f1aa2cb1daac", transactionIndex: "21", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000037fc3c160bf0d16ea418e9528f2b51c0f1e5d89b000000000000000000000000000000000000000000000000000000000133f026000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000002300000000000000000000000000000000000000000000000000000000000000360000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "1330706", gasUsed: "113774", confirmations: "1140807"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[23]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["2","30","35","54","9"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[23], "20181030", ["2","30","35","54","9"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540649327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x37fc3c160bf0d16ea418e9528f2b51c0f1e5d89b"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [96]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[24], \"20181030\", [\"9\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6596564", timeStamp: "1540692284", hash: "0xb400a84c2a7c76c4da890bb9d9a2251e75627096867641a17363fbd462074a1d", nonce: "31", blockHash: "0xfa590e536e462efd1fcc3c0b7e78a245b12b04388aae54db95a89e8ea1b7a232", transactionIndex: "4", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000080a4b153f51f090eda445df7c31f57bdbd437bae000000000000000000000000000000000000000000000000000000000133f026000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000002f000000000000000000000000000000000000000000000000000000000000003e0000000000000000000000000000000000000000000000000000000000000016", contractAddress: "", cumulativeGasUsed: "239911", gasUsed: "113774", confirmations: "1137778"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[24]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["9","12","47","62","22"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[24], "20181030", ["9","12","47","62","22"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540692284 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x80a4b153f51f090eda445df7c31f57bdbd437bae"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [97]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[25], \"20181030\", [\"7\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6596570", timeStamp: "1540692424", hash: "0x42ebefb879e4bb9ec78592b5d19f0355909af8e4c66b3e8c8e7e35e8fe31e613", nonce: "32", blockHash: "0x55a57bde205b517046528773b4394f059cc88696fa32c0dbb17e34c89b978bb4", transactionIndex: "19", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000a4d19771d32d1a196944a41fd41c22a254bc0011000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000029000000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "925144", gasUsed: "113710", confirmations: "1137772"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[25]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["7","41","45","50","11"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[25], "20181030", ["7","41","45","50","11"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540692424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xa4d19771d32d1a196944a41fd41c22a254bc0011"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [98]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[12], \"20181030\", [\"26\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6597179", timeStamp: "1540701097", hash: "0xd709bebcb3d8165e2f70d69b76643071cfb3a78b140238225713b57fbadffd22", nonce: "33", blockHash: "0x142b3e4d4be2d46c66cd6524bf06869a89035885365c57d0903e5adaabb6006f", transactionIndex: "38", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000e353631e52db3705a008253e055043f0787bf539000000000000000000000000000000000000000000000000000000000133f02600000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000001a00000000000000000000000000000000000000000000000000000000000000250000000000000000000000000000000000000000000000000000000000000027000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000001a", contractAddress: "", cumulativeGasUsed: "1721575", gasUsed: "128724", confirmations: "1137163"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[12]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["26","37","39","45","26"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[12], "20181030", ["26","37","39","45","26"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540701097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xe353631e52db3705a008253e055043f0787bf539"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 1, c: [99]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[26], \"20181030\", [\"2\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6599194", timeStamp: "1540729129", hash: "0x14c5e8ddef0a8505fe7414c7fa7fe1a0ae3d05bd9dddad1b477853a6cc27931e", nonce: "34", blockHash: "0xd8595b9b9b0836e95c0ea0194f2961afc17fc5b5fd080b254a1955fd8341edfa", transactionIndex: "34", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000d4377c74d8e7f68cb7ed9fa5db0931be2391bde4000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "1926477", gasUsed: "113774", confirmations: "1135148"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[26]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["2","3","11","18","23"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[26], "20181030", ["2","3","11","18","23"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540729129 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xd4377c74d8e7f68cb7ed9fa5db0931be2391bde4"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [100]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[27], \"20181030\", [\"6\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6599454", timeStamp: "1540732774", hash: "0x47830dc3c8843664945885241fb5a92b77d00cda11e3b9c7bd429cdc944f75db", nonce: "35", blockHash: "0xdfe8cfa06bc17ca5d7abde5926c89aa35d3ad9b4e43ae16465119008382050eb", transactionIndex: "47", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000357f74f60f518bd99c90d366ba2eae17413283b0000000000000000000000000000000000000000000000000000000000133f026000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000002700000000000000000000000000000000000000000000000000000000000000310000000000000000000000000000000000000000000000000000000000000037000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "2836224", gasUsed: "113774", confirmations: "1134888"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[27]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["6","39","49","55","14"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[27], "20181030", ["6","39","49","55","14"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540732774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x357f74f60f518bd99c90d366ba2eae17413283b0"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [101]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[23], \"20181030\", [\"8\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6600078", timeStamp: "1540741787", hash: "0x7d1bd35bca9403e1a688c80664bc1a4d0415256a94d368ccca1b248594462c39", nonce: "36", blockHash: "0x08eba534be7d77e3d37a31dce599fb8a31843debe49eac70e57631162c616165", transactionIndex: "17", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000037fc3c160bf0d16ea418e9528f2b51c0f1e5d89b000000000000000000000000000000000000000000000000000000000133f0260000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001d00000000000000000000000000000000000000000000000000000000000000290000000000000000000000000000000000000000000000000000000000000018", contractAddress: "", cumulativeGasUsed: "1152830", gasUsed: "113774", confirmations: "1134264"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[23]}, {type: "uint32", name: "_drawDate", value: "20181030"}, {type: "uint8[]", name: "_balls", value: ["8","18","29","41","24"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[23], "20181030", ["8","18","29","41","24"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540741787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x37fc3c160bf0d16ea418e9528f2b51c0f1e5d89b"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [102]}]}, {name: "drawDate", type: "uint256", value: "20181030"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[11], \"20181102\", [\"16\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6611135", timeStamp: "1540898221", hash: "0x1eac8c26d126eb4d0881a82285c412a3c438283368886d3be9095ee16259c3b2", nonce: "37", blockHash: "0xab801637cc243ef6ec9e12eaf421704cd00320a2c8b38d6f1abc6be1922ef401", transactionIndex: "54", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000c5b43df6ae0ffc80bdb3e3470055d2285036e848000000000000000000000000000000000000000000000000000000000133f06e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000460000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "2259873", gasUsed: "113710", confirmations: "1123207"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[11]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["16","24","60","70","23"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[11], "20181102", ["16","24","60","70","23"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540898221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xc5b43df6ae0ffc80bdb3e3470055d2285036e848"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [103]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[11], \"20181102\", [\"11\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6611135", timeStamp: "1540898221", hash: "0xe9d1dc10879b4095e4604e7da89ee237c1b8b84d5c419d6ca8368c466a628a87", nonce: "38", blockHash: "0xab801637cc243ef6ec9e12eaf421704cd00320a2c8b38d6f1abc6be1922ef401", transactionIndex: "55", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000c5b43df6ae0ffc80bdb3e3470055d2285036e848000000000000000000000000000000000000000000000000000000000133f06e00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000013000000000000000000000000000000000000000000000000000000000000001e0000000000000000000000000000000000000000000000000000000000000037000000000000000000000000000000000000000000000000000000000000003f00000000000000000000000000000000000000000000000000000000000000170000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000001f0000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000003e0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000003d000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000130000000000000000000000000000000000000000000000000000000000000021000000000000000000000000000000000000000000000000000000000000003b00000000000000000000000000000000000000000000000000000000000000410000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "2698894", gasUsed: "439021", confirmations: "1123207"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[11]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["11","23","30","32","21","19","30","55","63","23","22","31","56","62","7","22","32","48","61","2","19","33","59","65","4"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[11], "20181102", ["11","23","30","32","21","19","30","55","63","23","22","31","56","62","7","22","32","48","61","2","19","33","59","65","4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540898221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xc5b43df6ae0ffc80bdb3e3470055d2285036e848"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [104]}, {s: 1, e: 2, c: [105]}, {s: 1, e: 2, c: [106]}, {s: 1, e: 2, c: [107]}, {s: 1, e: 2, c: [108]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[20], \"20181102\", [\"8\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6616068", timeStamp: "1540968109", hash: "0x7c1249daf8a9cc85c8ae69fd0f0752f41b50ea10e4a39a1ff2ce3ce6a67013a2", nonce: "39", blockHash: "0x9e9261e6bce4f6346955e8c0180562e15bdacccded1d7c01e067d61298b6b36d", transactionIndex: "26", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000bdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f000000000000000000000000000000000000000000000000000000000133f06e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002300000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "1484715", gasUsed: "128724", confirmations: "1118274"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[20]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["8","28","35","57","9"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[20], "20181102", ["8","28","35","57","9"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540968109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xbdb09b85c9b5e5f79a692f9d20b13a6d32b0c63f"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [109]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[28], \"20181102\", [\"16\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6616096", timeStamp: "1540968496", hash: "0x6417bf95550e79a66f23b7b04ab640ade3e90d2a676e3186fdeeeda0e0505a5b", nonce: "40", blockHash: "0xc59d993e49797dbe2cd5b400832f737525844c68745e6cf4bbef5af354616af0", transactionIndex: "34", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000ce2c0072c25f397f95a7ca7565319fe4b20f1925000000000000000000000000000000000000000000000000000000000133f06e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000027000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000430000000000000000000000000000000000000000000000000000000000000010", contractAddress: "", cumulativeGasUsed: "2093115", gasUsed: "113710", confirmations: "1118246"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[28]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["16","39","60","67","16"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[28], "20181102", ["16","39","60","67","16"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540968496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xce2c0072c25f397f95a7ca7565319fe4b20f1925"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [110]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[23], \"20181102\", [\"17\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6617499", timeStamp: "1540988316", hash: "0xf0ad62b2472fd862477cfbf8d829a4d3befb3ecb2f5f74f09682f4070812ee0e", nonce: "41", blockHash: "0xc18ff8ee4965d008e6d69a960c20a170a280b76ab60847044f63560a20c6c983", transactionIndex: "13", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000037fc3c160bf0d16ea418e9528f2b51c0f1e5d89b000000000000000000000000000000000000000000000000000000000133f06e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000029000000000000000000000000000000000000000000000000000000000000003a0000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "1191888", gasUsed: "113774", confirmations: "1116843"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[23]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["17","27","41","58","19"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[23], "20181102", ["17","27","41","58","19"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540988316 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x37fc3c160bf0d16ea418e9528f2b51c0f1e5d89b"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [111]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[23], \"20181102\", [\"47\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6617508", timeStamp: "1540988432", hash: "0x0918064740eda14054a0e305af8c0e18131d1c92006a2bd810d2428808a844ed", nonce: "42", blockHash: "0x4b549a8e6fdc956bc2b6107d7854f0e672c1a5958428cc02dfd07cfb2722c419", transactionIndex: "4", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000037fc3c160bf0d16ea418e9528f2b51c0f1e5d89b000000000000000000000000000000000000000000000000000000000133f06e00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000002f0000000000000000000000000000000000000000000000000000000000000031000000000000000000000000000000000000000000000000000000000000003f0000000000000000000000000000000000000000000000000000000000000043000000000000000000000000000000000000000000000000000000000000001a", contractAddress: "", cumulativeGasUsed: "366386", gasUsed: "113774", confirmations: "1116834"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[23]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["47","49","63","67","26"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[23], "20181102", ["47","49","63","67","26"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540988432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x37fc3c160bf0d16ea418e9528f2b51c0f1e5d89b"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [112]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[25], \"20181102\", [\"9\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6617508", timeStamp: "1540988432", hash: "0x47f3be196f12bbe6c29660a2a6ad5fefca55fe22ae62689bb5b26dc5ede33cb3", nonce: "43", blockHash: "0x4b549a8e6fdc956bc2b6107d7854f0e672c1a5958428cc02dfd07cfb2722c419", transactionIndex: "5", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000a4d19771d32d1a196944a41fd41c22a254bc0011000000000000000000000000000000000000000000000000000000000133f06e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000002e00000000000000000000000000000000000000000000000000000000000000360000000000000000000000000000000000000000000000000000000000000019", contractAddress: "", cumulativeGasUsed: "480096", gasUsed: "113710", confirmations: "1116834"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[25]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["9","27","46","54","25"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[25], "20181102", ["9","27","46","54","25"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540988432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xa4d19771d32d1a196944a41fd41c22a254bc0011"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [113]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[24], \"20181102\", [\"8\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6617547", timeStamp: "1540988913", hash: "0x4384ef30b5a3e209f41754852de42a5e7f546e8cfe8578caec8ffd9024adda04", nonce: "44", blockHash: "0x4e7cc12edb8d201e4a3073fcefdb0506e32e9352b965e943a87ccf1a32a6428a", transactionIndex: "49", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb856100000000000000000000000080a4b153f51f090eda445df7c31f57bdbd437bae000000000000000000000000000000000000000000000000000000000133f06e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000001d00000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "2114780", gasUsed: "113774", confirmations: "1116795"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[24]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["8","22","29","57","7"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[24], "20181102", ["8","22","29","57","7"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540988913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x80a4b153f51f090eda445df7c31f57bdbd437bae"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [114]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[29], \"20181102\", [\"21\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6618181", timeStamp: "1540998144", hash: "0x2df56e0e3759877b1a911c6815389c0011c727011ee7b6e609a1cb3b29e15779", nonce: "45", blockHash: "0xec6b986ceebd7eeca006606ebabab0f8838e855a0ebeb0d3124f1d3c47534340", transactionIndex: "19", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb85610000000000000000000000005aab56a7ff435b05ef48981f86c9a81e5c3fb067000000000000000000000000000000000000000000000000000000000133f06e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001d0000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "731830", gasUsed: "113774", confirmations: "1116161"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[29]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["21","22","28","29","4"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[29], "20181102", ["21","22","28","29","4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540998144 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x5aab56a7ff435b05ef48981f86c9a81e5c3fb067"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [115]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[30], \"20181102\", [\"3\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6621318", timeStamp: "1541042846", hash: "0x89c883ef21ce5a7ed0b42d37e533008a1a21c2e84b5faa2dec152cdbc6bd68cf", nonce: "46", blockHash: "0x0a4ca8a1fc314940a2164d4e003e163c259f11f4ae5e4b93f84eff8f20e8c41e", transactionIndex: "23", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000287219ef81f77716b976d242c93070833d610657000000000000000000000000000000000000000000000000000000000133f06e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000003200000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000013000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000330000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000003f00000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000029000000000000000000000000000000000000000000000000000000000000003e000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001d0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000027000000000000000000000000000000000000000000000000000000000000003500000000000000000000000000000000000000000000000000000000000000360000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000001d000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000003300000000000000000000000000000000000000000000000000000000000000440000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000270000000000000000000000000000000000000000000000000000000000000036000000000000000000000000000000000000000000000000000000000000003d000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000026000000000000000000000000000000000000000000000000000000000000002700000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000002a000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000003c000000000000000000000000000000000000000000000000000000000000003d000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000440000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "3780557", gasUsed: "875629", confirmations: "1113024"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[30]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["3","19","24","51","23","15","45","63","66","8","1","5","41","62","1","7","24","27","29","16","15","39","53","54","20","29","30","51","68","8","12","39","54","61","5","22","38","39","57","2","42","45","60","61","18","38","40","64","68","9"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[30], "20181102", ["3","19","24","51","23","15","45","63","66","8","1","5","41","62","1","7","24","27","29","16","15","39","53","54","20","29","30","51","68","8","12","39","54","61","5","22","38","39","57","2","42","45","60","61","18","38","40","64","68","9"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541042846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x287219ef81f77716b976d242c93070833d610657"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [116]}, {s: 1, e: 2, c: [117]}, {s: 1, e: 2, c: [118]}, {s: 1, e: 2, c: [119]}, {s: 1, e: 2, c: [120]}, {s: 1, e: 2, c: [121]}, {s: 1, e: 2, c: [122]}, {s: 1, e: 2, c: [123]}, {s: 1, e: 2, c: [124]}, {s: 1, e: 2, c: [125]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[31], \"20181102\", [\"13\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6621993", timeStamp: "1541052399", hash: "0xc0e6268dac8a7ea733dd6315932815b1058127a059e110e28691d30668af0732", nonce: "47", blockHash: "0xeef2839a84f4671a216dccb1466c1a2e79847bc41cb7aac8ee615740a02a4075", transactionIndex: "13", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000eb612d1bcff6d31eaea10eb77a622c5d140485a1000000000000000000000000000000000000000000000000000000000133f06e00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000002600000000000000000000000000000000000000000000000000000000000000370000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "734019", gasUsed: "113774", confirmations: "1112349"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[31]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["13","23","38","55","18"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[31], "20181102", ["13","23","38","55","18"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541052399 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xeb612d1bcff6d31eaea10eb77a622c5d140485a1"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [126]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[12], \"20181102\", [\"29\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6622001", timeStamp: "1541052515", hash: "0x0ea5392d401a02b8eb425558f83e29561ed24c70426017b236f0bb9558e5a97d", nonce: "48", blockHash: "0xb43260d8ce1c9b4f5e20e077fbbbb0ea502a269cd53645580a30be3beabf8819", transactionIndex: "17", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000e353631e52db3705a008253e055043f0787bf539000000000000000000000000000000000000000000000000000000000133f06e00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000001d0000000000000000000000000000000000000000000000000000000000000021000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000360000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "1531635", gasUsed: "113774", confirmations: "1112341"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[12]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["29","33","48","54","4"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[12], "20181102", ["29","33","48","54","4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541052515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xe353631e52db3705a008253e055043f0787bf539"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [127]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[18], \"20181102\", [\"6\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6622727", timeStamp: "1541062570", hash: "0xb3643d15680fca188b2a24345ec5957f8ed62db2599d39e5725c3cb457a229cd", nonce: "49", blockHash: "0x0b971fb76fd0dbbda570718cbabde126d572ef041769ffc1eb738885e2e5ecca", transactionIndex: "1", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000a35b534d1b7beb1a1770ff65e7f575d9d33e42cc000000000000000000000000000000000000000000000000000000000133f06e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000043000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000001300000000000000000000000000000000000000000000000000000000000000130000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000000000000000002e000000000000000000000000000000000000000000000000000000000000003f000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000000000000000000250000000000000000000000000000000000000000000000000000000000000015000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000035000000000000000000000000000000000000000000000000000000000000003a0000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "519070", gasUsed: "439085", confirmations: "1111615"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[18]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["6","20","21","67","15","6","15","17","19","19","35","44","46","63","24","18","20","33","37","21","7","25","53","58","9"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[18], "20181102", ["6","20","21","67","15","6","15","17","19","19","35","44","46","63","24","18","20","33","37","21","7","25","53","58","9"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541062570 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xa35b534d1b7beb1a1770ff65e7f575d9d33e42cc"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [128]}, {s: 1, e: 2, c: [129]}, {s: 1, e: 2, c: [130]}, {s: 1, e: 2, c: [131]}, {s: 1, e: 2, c: [132]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[16], \"20181102\", [\"2\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6622727", timeStamp: "1541062570", hash: "0xa6d9411e84b509f4ba9718784977270fcb32a0fdc5dd1ee923597e9aee7253f1", nonce: "50", blockHash: "0x0b971fb76fd0dbbda570718cbabde126d572ef041769ffc1eb738885e2e5ecca", transactionIndex: "2", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb85610000000000000000000000000eb2fd4929957c93d337a18d986a43af59d41cb5000000000000000000000000000000000000000000000000000000000133f06e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003e00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000016", contractAddress: "", cumulativeGasUsed: "647794", gasUsed: "128724", confirmations: "1111615"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[16]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["2","16","62","64","22"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[16], "20181102", ["2","16","62","64","22"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541062570 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x0eb2fd4929957c93d337a18d986a43af59d41cb5"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [133]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[17], \"20181102\", [\"12\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6622739", timeStamp: "1541062727", hash: "0x5169174ce1a187dba61e0276549e0978520280f818e944d82845089a2cb1655c", nonce: "51", blockHash: "0xfcc83f706c95ecd2a4573cb1df3642bc9fe6f21770197f6100b75eb9d7c08497", transactionIndex: "0", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000dada735fdcb5da0ce3620bf94081a2737673af01000000000000000000000000000000000000000000000000000000000133f06e00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000290000000000000000000000000000000000000000000000000000000000000038000000000000000000000000000000000000000000000000000000000000003d000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "113774", gasUsed: "113774", confirmations: "1111603"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[17]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["12","41","56","61","10"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[17], "20181102", ["12","41","56","61","10"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541062727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xdada735fdcb5da0ce3620bf94081a2737673af01"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [134]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[27], \"20181102\", [\"21\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6623736", timeStamp: "1541077092", hash: "0x75454fb4627cae219a0a8b80e706e6ec3341f04525fd2a9263e42c07535fcfa7", nonce: "52", blockHash: "0x0a9b535c8403904c3a068c3f91c3dab833c83660465b30b2d32ecd42a836a554", transactionIndex: "66", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000357f74f60f518bd99c90d366ba2eae17413283b0000000000000000000000000000000000000000000000000000000000133f06e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000150000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000370000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "2850620", gasUsed: "113774", confirmations: "1110606"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[27]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["21","25","48","55","19"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[27], "20181102", ["21","25","48","55","19"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541077092 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x357f74f60f518bd99c90d366ba2eae17413283b0"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [135]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[15], \"20181102\", [\"8\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6623753", timeStamp: "1541077308", hash: "0x5eb98f49cacad5c144ef32988267e59724c8f1c0bce40d44745159e64040185d", nonce: "53", blockHash: "0x369a4d319c70565a28224c1a3cfe0a37b6e0281d0d173d8bce4a404584eed469", transactionIndex: "24", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000164d5147063e61fd662600aea72502bfe2a2ab67000000000000000000000000000000000000000000000000000000000133f06e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000001a00000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "2424890", gasUsed: "113710", confirmations: "1110589"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[15]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["8","11","26","38","23"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[15], "20181102", ["8","11","26","38","23"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541077308 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0x164d5147063e61fd662600aea72502bfe2a2ab67"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [136]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: giveTickets( addressList[32], \"20181102\", [\"6\",\"... )", async function( ) {
		const txOriginal = {blockNumber: "6624490", timeStamp: "1541087572", hash: "0x68a5f1e421309f054461f12ee28b5a84dd3248bf83ca46be5b0640cbec68eb0c", nonce: "54", blockHash: "0x6a1024e72c8ba7182fa152318e8df08a814d49fa48f13394c0775b354a0d61bf", transactionIndex: "38", from: "0xf46f868b112019efa99b597410cb10e8660ffe43", to: "0x611a99aefef3736507752cc5628300c5e6a9a1e8", value: "0", gas: "5000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb4bb8561000000000000000000000000d19c20c77ef533d6c834382970de3f5477bf6249000000000000000000000000000000000000000000000000000000000133f06e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000002900000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000018", contractAddress: "", cumulativeGasUsed: "1746982", gasUsed: "113774", confirmations: "1109852"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[32]}, {type: "uint32", name: "_drawDate", value: "20181102"}, {type: "uint8[]", name: "_balls", value: ["6","27","41","48","24"]}], name: "giveTickets", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveTickets(address,uint32,uint8[])" ]( addressList[32], "20181102", ["6","27","41","48","24"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541087572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "user", type: "address"}, {indexed: false, name: "ticketId", type: "uint32[]"}, {indexed: false, name: "drawDate", type: "uint256"}], name: "logBuyTicketSumary", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logBuyTicketSumary", events: [{name: "user", type: "address", value: "0xd19c20c77ef533d6c834382970de3f5477bf6249"}, {name: "ticketId", type: "uint32[]", value: [{s: 1, e: 2, c: [137]}]}, {name: "drawDate", type: "uint256", value: "20181102"}], address: "0x611a99aefef3736507752cc5628300c5e6a9a1e8"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2291380343598218000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
