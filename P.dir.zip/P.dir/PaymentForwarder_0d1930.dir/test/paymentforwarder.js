const PaymentForwarder = artifacts.require( "./PaymentForwarder.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "PaymentForwarder" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x51D3AaC348d1A26652c6e8eaB065A269830d1930", "0x18359735E06cDB531AC895FD41D46DD231D9A147", "0x83E82ceA898b1Ed1785Bc3beAc86034913831E60", "0x1c5e4db864861D9b6203bd86Af0C0B5ffcD6115d", "0x6efD5665ab4B345A7eBE63c679b651f375DDdB7E", "0x6487ebcA59844844bf3C7291251ae26AFf577d54", "0xAF64aB7C444B295B69C126A079FC72459FA1690C", "0x46791639ccA9f8405e7FEea870d2b0C3769A69E4", "0xDcEE70205aEcB682A41781e626A17E16dACd2865", "0x48f7B64E3C6267B7Db4a2448577Fc629F53EBc5C", "0x118229B2e05702d83602cAa64E3294D01394484C", "0x933b3704815b844bB6014a9c81FE3b7a89B8Bf72", "0xF244CC540bcB9d5E34fa46163F138272aFD9E903", "0x4bCC3CB1B6697f79B2582B5bE751f7CB94aCC63C", "0x4509dA7C630e9de8759C91754741ccF46CDBBf5e", "0xbe47064863B2B819C9349a0e2E2446873660938f", "0x84d467C848329A03b93C22b51cA3BA90EbeB68aD", "0xca48BA80Cfa6CC06963B62AeE48000f031c7E2dC", "0x002143044EF9E3a81F8271907483b24C711a87CB", "0xd02A135627224Cab666BDdE27B36b6C6d09C7323", "0x3199dc213b09B9f303bC7452a38aE73197B72480", "0x0008bF86174Cc4D1410438F387776B298c9FAf93", "0xBd94bC187e407d073127656f601F765C111adc11", "0x3aA01a00Ad382098698D4aE04c27543D32FC60D5", "0x91A37680f88468CAa01B871D35286FD8393BD623", "0x180175bE758B8C9f0B42B6869cF917A793E92C53", "0x552b53Ff42D467E3EE5637aEa9961144f527a360", "0x210Ea055096A7cAd87b69fbbC815be0019F035b2", "0xAd705caD2C24Ae38a1a2C23B8E8DAe82789fB366", "0xD4e78FD9e9F2F9F41e3a7A3480e78A7F0Cc95ac0", "0x8caB03C38c8be5d76404D647a5C45aE53A027341", "0x86349C83c83F0B99AEe89C55F6Cb17c92aec9517", "0xD35184b3fb9B3376e4Af80F41C6AB012A9f81f79", "0xA158D09B3b67244c160a98De47aa06807d4b80d5", "0x99C05254937f7B39730292183d7e3e1E696eEa80"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "customerCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalTransferred", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "teamMultisig", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "paymentsByBenefactor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint128"}], name: "paymentsByCustomer", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["PaymentForwarded(address,uint256,uint128,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4e4e2d6da11427f2d85d47e2bced64efa9ccd9694ae97786772a22d465bc80a4"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4377409 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4451738 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_owner", value: 3}, {type: "address", name: "_teamMultisig", value: 4}], name: "PaymentForwarder", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "customerCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "customerCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalTransferred", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalTransferred()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "teamMultisig", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "teamMultisig()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "paymentsByBenefactor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paymentsByBenefactor(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint128", name: "", value: random.range( maxRandom )}], name: "paymentsByCustomer", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paymentsByCustomer(uint128)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "PaymentForwarder", function( accounts ) {

	it( "TEST: PaymentForwarder( addressList[3], addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4377409", timeStamp: "1508248880", hash: "0xcfb4ec685dfe8633e6552c5df2f9406ec4105660344e6ed1af3ce26e15e85c49", nonce: "0", blockHash: "0x2bea78f3aaeac6ba0a8a353b1e08f2c9f2f2a6e2bea67a5d62788f44e0e382fb", transactionIndex: "23", from: "0x18359735e06cdb531ac895fd41d46dd231d9a147", to: 0, value: "0", gas: "594209", gasPrice: "7931361444", isError: "0", txreceipt_status: "1", input: "0x392ec23000000000000000000000000018359735e06cdb531ac895fd41d46dd231d9a14700000000000000000000000083e82cea898b1ed1785bc3beac86034913831e60", contractAddress: "0x51d3aac348d1a26652c6e8eab065a269830d1930", cumulativeGasUsed: "3078832", gasUsed: "494209", confirmations: "3342194"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[3]}, {type: "address", name: "_teamMultisig", value: addressList[4]}], name: "PaymentForwarder", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = PaymentForwarder.new( addressList[3], addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508248880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = PaymentForwarder.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "493875732454622204" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"12497207027318447826598848409082770999... )", async function( ) {
		const txOriginal = {blockNumber: "4389366", timeStamp: "1508415192", hash: "0x390f38095b386041be6575a962ea8dd73c85cb27bfb4ed3311730bc856f03072", nonce: "151", blockHash: "0x3170291a96ba279004ee5cfc29ab253b6a997721a48be238c8e771209729b28c", transactionIndex: "4", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "10000000000000000", gas: "250600", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000000966dfe0c5db4696afdd1ecc91b7b637", contractAddress: "", cumulativeGasUsed: "296383", gasUsed: "115326", confirmations: "3330237"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "12497207027318447826598848409082770999"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "12497207027318447826598848409082770999", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508415192 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [1249720702, 73184478265988, 48409082770999]}}, {name: "benefactor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"58884291938503086231773948637928638626... )", async function( ) {
		const txOriginal = {blockNumber: "4391429", timeStamp: "1508443807", hash: "0x0ac6bd9a08c8678c21ffa4aa2f3eb0291ff40c9561750b888e1cf35b58bd25ce", nonce: "152", blockHash: "0xb4eccbd5edc365f1e4313d25a52935d3df331814397873374f8a74e0071e1ffc", transactionIndex: "10", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "10000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000002c4cb3bd78724ad389483a44821e48a2", contractAddress: "", cumulativeGasUsed: "544604", gasUsed: "70326", confirmations: "3328174"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "58884291938503086231773948637928638626"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "58884291938503086231773948637928638626", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508443807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [5888429193, 85030862317739, 48637928638626]}}, {name: "benefactor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4391650", timeStamp: "1508446886", hash: "0x4dc41f68eb6e70bd1d60439fd857c412e28c852ca3a3a7a3e489048caa7f4ec4", nonce: "9063", blockHash: "0x4a177a193af42965a37da0981687b14cb7b6673cf7a770dfccce8c18e24d055f", transactionIndex: "21", from: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "100000000000000", gas: "21000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "462000", gasUsed: "21000", confirmations: "3327953"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1099686269954821905" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"21535741720954731968677456538220182091... )", async function( ) {
		const txOriginal = {blockNumber: "4391665", timeStamp: "1508447037", hash: "0x792988977ab1bd6874acd2480de14000dbf5b24d799809181a8f74dfa13af31b", nonce: "9064", blockHash: "0xf7105d8e0ec490bcf6614739d81fd4a2be997da9c40da87af98a10a44955dc7d", transactionIndex: "57", from: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "10000000000000", gas: "260300", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000a2045471602f4bbca3ef95841fcc46f2", contractAddress: "", cumulativeGasUsed: "2831210", gasUsed: "85326", confirmations: "3327938"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "215357417209547319686774565382201820914"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "215357417209547319686774565382201820914", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508447037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e"}, {name: "amount", type: "uint256", value: "10000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21535741720, 95473196867745, 65382201820914]}}, {name: "benefactor", type: "address", value: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1099686269954821905" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"21535741720954731968677456538220182091... )", async function( ) {
		const txOriginal = {blockNumber: "4391730", timeStamp: "1508447905", hash: "0x08ebd851c5d9777e49a4b8c3fc644e4f0b2a93c7fb33c899b79c22a49d8f4f91", nonce: "9065", blockHash: "0x355d360f795e39e09c6b74727983bb08fa81631e52de75f7d52391ebd9a4131c", transactionIndex: "52", from: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "0", gas: "260300", gasPrice: "9450000001", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000a2045471602f4bbca3ef95841fcc46f2", contractAddress: "", cumulativeGasUsed: "1926693", gasUsed: "41906", confirmations: "3327873"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "215357417209547319686774565382201820914"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "215357417209547319686774565382201820914", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508447905 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e"}, {name: "amount", type: "uint256", value: "0"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21535741720, 95473196867745, 65382201820914]}}, {name: "benefactor", type: "address", value: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1099686269954821905" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"21535741720954731968677456538220182091... )", async function( ) {
		const txOriginal = {blockNumber: "4391820", timeStamp: "1508449139", hash: "0x8a487d5c645004a208efe354e5521732922c82b17a3c49269b9774d2701317a4", nonce: "9066", blockHash: "0xc27070f0fcf2b492fdf04b5fdf1c06b94a797dc3462c8cd33a3733b84a245186", transactionIndex: "73", from: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "10000000000000", gas: "260300", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000a2045471602f4bbca3ef95841fcc46f2", contractAddress: "", cumulativeGasUsed: "3918493", gasUsed: "50111", confirmations: "3327783"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "215357417209547319686774565382201820914"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "215357417209547319686774565382201820914", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508449139 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e"}, {name: "amount", type: "uint256", value: "10000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21535741720, 95473196867745, 65382201820914]}}, {name: "benefactor", type: "address", value: "0x6efd5665ab4b345a7ebe63c679b651f375dddb7e"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1099686269954821905" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"30980252989635465297579872789187016637... )", async function( ) {
		const txOriginal = {blockNumber: "4400716", timeStamp: "1508572503", hash: "0x42be884026c0b64919cb8bca83e31ab290f948b7a448839fb2ccd988afb9b2c2", nonce: "2", blockHash: "0x0279ca0c9592b1a1143740626e9780bf97e63b97b6ab0461b7d656f74857b4b4", transactionIndex: "39", from: "0x6487ebca59844844bf3c7291251ae26aff577d54", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "10000000000000000", gas: "260300", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000e911cc02c7e04faa80f21b6d927a2d63", contractAddress: "", cumulativeGasUsed: "2181188", gasUsed: "85326", confirmations: "3318887"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "309802529896354652975798727891870166371"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "309802529896354652975798727891870166371", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508572503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x6487ebca59844844bf3c7291251ae26aff577d54"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [30980252989, 63546529757987, 27891870166371]}}, {name: "benefactor", type: "address", value: "0x6487ebca59844844bf3c7291251ae26aff577d54"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "14593657890520961146" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4406853", timeStamp: "1508656755", hash: "0x1942554cc8c5d7f4d6c44f7a6e38c03a46bf2dbcfe27d15e2daf7c41c527b2f0", nonce: "22", blockHash: "0xd72bd7c61dd362fd51b395749627ac934fdb01254fdc3eff5738e0e95f2a8b07", transactionIndex: "4", from: "0xaf64ab7c444b295b69c126a079fc72459fa1690c", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "636000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "108546", gasUsed: "21043", confirmations: "3312750"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "636000000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508656755 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "145754238126380032" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4406975", timeStamp: "1508658630", hash: "0xfbddb0a23df412a510d762bae6d9328c169a6995e5f96724360badb9a120d248", nonce: "23", blockHash: "0x5b904c26a6f38d060fd9d794bdc0f17dff7726903040e4dadef176d15bdbb66f", transactionIndex: "5", from: "0xaf64ab7c444b295b69c126a079fc72459fa1690c", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "636000000000000000000", gas: "260300", gasPrice: "40000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "225043", gasUsed: "21043", confirmations: "3312628"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "636000000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508658630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "145754238126380032" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"12212894891818810301423374608604196257... )", async function( ) {
		const txOriginal = {blockNumber: "4407002", timeStamp: "1508659025", hash: "0xe84af1589f41c15c85675bfa0307ea7c727e313110a63d53c06a417ee1802657", nonce: "24", blockHash: "0x9f16600416ff38680386709c42f6fb205eaf89bcb8802b3988a5135ad8ebed71", transactionIndex: "1", from: "0xaf64ab7c444b295b69c126a079fc72459fa1690c", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "636000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000005be12e13281c42faa6f00a429003484f", contractAddress: "", cumulativeGasUsed: "118897", gasUsed: "85326", confirmations: "3312601"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "636000000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "122128948918188103014233746086041962575"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "122128948918188103014233746086041962575", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508659025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xaf64ab7c444b295b69c126a079fc72459fa1690c"}, {name: "amount", type: "uint256", value: "636000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [12212894891, 81881030142337, 46086041962575]}}, {name: "benefactor", type: "address", value: "0xaf64ab7c444b295b69c126a079fc72459fa1690c"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "145754238126380032" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"32640732142393448672981182559644442102... )", async function( ) {
		const txOriginal = {blockNumber: "4408956", timeStamp: "1508685620", hash: "0x1e1774f7702ba1e19bd5253384a0b6e4d9849ecf82a39382d89ea477b8f3c52f", nonce: "0", blockHash: "0x2393016f22c36b1e0d4930ecaf0f45fd478ad9c8074cd39b6625b6a930a9818c", transactionIndex: "6", from: "0x46791639cca9f8405e7feea870d2b0c3769a69e4", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "53000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000188e6058142c4fedb5bd0d97beea5df6", contractAddress: "", cumulativeGasUsed: "403162", gasUsed: "85326", confirmations: "3310647"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "53000000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "32640732142393448672981182559644442102"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "32640732142393448672981182559644442102", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508685620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x46791639cca9f8405e7feea870d2b0c3769a69e4"}, {name: "amount", type: "uint256", value: "53000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [3264073214, 23934486729811, 82559644442102]}}, {name: "benefactor", type: "address", value: "0x46791639cca9f8405e7feea870d2b0c3769a69e4"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"29977400571631864353014791865557119775... )", async function( ) {
		const txOriginal = {blockNumber: "4411656", timeStamp: "1508723701", hash: "0x6c78efbdf423b0dc7272f3d80d5ed74adc9cd91f01f223a94c94abc380de5204", nonce: "7", blockHash: "0xb8a3c6fe4527f259793afae2e7cd8ea362beae7eb1c32df24403d0aa16cc499f", transactionIndex: "4", from: "0xdcee70205aecb682a41781e626a17e16dacd2865", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "500000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000e1865f982d7b467abf1522309fe17f36", contractAddress: "", cumulativeGasUsed: "272830", gasUsed: "85326", confirmations: "3307947"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "299774005716318643530147918655571197750"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "299774005716318643530147918655571197750", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508723701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xdcee70205aecb682a41781e626a17e16dacd2865"}, {name: "amount", type: "uint256", value: "500000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [29977400571, 63186435301479, 18655571197750]}}, {name: "benefactor", type: "address", value: "0xdcee70205aecb682a41781e626a17e16dacd2865"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "19525679000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"15185925073385411276757591141800282891... )", async function( ) {
		const txOriginal = {blockNumber: "4412425", timeStamp: "1508734211", hash: "0xb1056cb3970c046b94f8b5ee715c1787397cf8c0be906d41b91732676c731bee", nonce: "24", blockHash: "0x826f6f748f71f252f96d5fc021923c98693465a3c65edde94abafb185375f402", transactionIndex: "1", from: "0x48f7b64e3c6267b7db4a2448577fc629f53ebc5c", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "72000000000000000000", gas: "260300", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000723f07200061433080f3ea11ecc26e6e", contractAddress: "", cumulativeGasUsed: "106262", gasUsed: "85262", confirmations: "3307178"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "72000000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "151859250733854112767575911418002828910"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "151859250733854112767575911418002828910", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508734211 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x48f7b64e3c6267b7db4a2448577fc629f53ebc5c"}, {name: "amount", type: "uint256", value: "72000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [15185925073, 38541127675759, 11418002828910]}}, {name: "benefactor", type: "address", value: "0x48f7b64e3c6267b7db4a2448577fc629f53ebc5c"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "478557569420632000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"14719362120289410499411107742775972783... )", async function( ) {
		const txOriginal = {blockNumber: "4419491", timeStamp: "1508832284", hash: "0xcb80d51608b0102cfde18e35662fb9e3133b1cee4c0e50f831f85380761a1554", nonce: "6", blockHash: "0x687b75b7408737f8b6aeb3f75ece4b62210c825e669f81c90f60e4061487f720", transactionIndex: "13", from: "0x118229b2e05702d83602caa64e3294d01394484c", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "53000000000000000000", gas: "250600", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000006ebc75d43cec449d9c8a8e25f176c4dc", contractAddress: "", cumulativeGasUsed: "561940", gasUsed: "85326", confirmations: "3300112"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "53000000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "147193621202894104994111077427759727836"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "147193621202894104994111077427759727836", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508832284 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x118229b2e05702d83602caa64e3294d01394484c"}, {name: "amount", type: "uint256", value: "53000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [14719362120, 28941049941110, 77427759727836]}}, {name: "benefactor", type: "address", value: "0x118229b2e05702d83602caa64e3294d01394484c"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "4209821000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"25014968162984164023420723092180081551... )", async function( ) {
		const txOriginal = {blockNumber: "4420280", timeStamp: "1508842886", hash: "0xc1fed7353b89cdb948464e1f86ca43a1d41742576756eb5aaf4d6087638e375c", nonce: "0", blockHash: "0xc89f19e4ae495916c5f37a3fc8a4909bccf79b8acfda41d28621d764c2ff9673", transactionIndex: "26", from: "0x933b3704815b844bb6014a9c81fe3b7a89b8bf72", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "51800000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000bc311384a9054321bd942f32aad2139f", contractAddress: "", cumulativeGasUsed: "1347799", gasUsed: "85326", confirmations: "3299323"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "51800000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "250149681629841640234207230921800815519"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "250149681629841640234207230921800815519", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508842886 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x933b3704815b844bb6014a9c81fe3b7a89b8bf72"}, {name: "amount", type: "uint256", value: "51800000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [25014968162, 98416402342072, 30921800815519]}}, {name: "benefactor", type: "address", value: "0x933b3704815b844bb6014a9c81fe3b7a89b8bf72"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "75386304000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"24756552156422165762672895971147525104... )", async function( ) {
		const txOriginal = {blockNumber: "4421885", timeStamp: "1508865540", hash: "0xa1c1ae87c9a0abde63b8437ba527f3a9a9f3b122ad0c81c4e4460c285bbe88bd", nonce: "2", blockHash: "0x25fce409df49ae7e0dfdee0d4966d0614c7cff1e813a6c005605af2f795e5c4b", transactionIndex: "9", from: "0xf244cc540bcb9d5e34fa46163f138272afd9e903", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "255000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000129ff0424eea43e99360279195d22bf0", contractAddress: "", cumulativeGasUsed: "708807", gasUsed: "85326", confirmations: "3297718"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "255000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "24756552156422165762672895971147525104"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "24756552156422165762672895971147525104", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508865540 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xf244cc540bcb9d5e34fa46163f138272afd9e903"}, {name: "amount", type: "uint256", value: "255000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2475655215, 64221657626728, 95971147525104]}}, {name: "benefactor", type: "address", value: "0xf244cc540bcb9d5e34fa46163f138272afd9e903"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "529200000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"16211217561361361897965812660867727614... )", async function( ) {
		const txOriginal = {blockNumber: "4426351", timeStamp: "1508927792", hash: "0x0279f7fbb9fd3a2841222e7e637c72b42cfb3b81bf04a019d5d1a7a10244ecca", nonce: "6", blockHash: "0x04c467564a8afa9f290f6c73a6b995f50353987ff195425e25635d4f9073e0e7", transactionIndex: "10", from: "0x4bcc3cb1b6697f79b2582b5be751f7cb94acc63c", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "52000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000000c322abc29bd4a74aaeb1f62a09c80fe", contractAddress: "", cumulativeGasUsed: "1027518", gasUsed: "85326", confirmations: "3293252"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "52000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "16211217561361361897965812660867727614"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "16211217561361361897965812660867727614", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508927792 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x4bcc3cb1b6697f79b2582b5be751f7cb94acc63c"}, {name: "amount", type: "uint256", value: "52000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [1621121756, 13613618979658, 12660867727614]}}, {name: "benefactor", type: "address", value: "0x4bcc3cb1b6697f79b2582b5be751f7cb94acc63c"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "329734812394528000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"31657347442948819559210031821510807235... )", async function( ) {
		const txOriginal = {blockNumber: "4426557", timeStamp: "1508930691", hash: "0x9fee0f1a6192b954f5d0d36247edb6b9cfb4985bd5fbbaa26a1fb6002532a112", nonce: "153", blockHash: "0xc50d296982cb662760524dc5a5f5a52e7e4bb9286e8a428fb55bbc054048ccbc", transactionIndex: "5", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "10000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000ee29d559b7f049f9b2e96ff67324939e", contractAddress: "", cumulativeGasUsed: "294106", gasUsed: "70326", confirmations: "3293046"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "316573474429488195592100318215108072350"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "316573474429488195592100318215108072350", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508930691 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [31657347442, 94881955921003, 18215108072350]}}, {name: "benefactor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"31657347442948819559210031821510807235... )", async function( ) {
		const txOriginal = {blockNumber: "4426601", timeStamp: "1508931319", hash: "0xb347de80cb41134547e9b50eb2bb9cc8c46fa414db4023166eeeefd67f03ec8f", nonce: "154", blockHash: "0x58494606efdfb9e25346237aae7199723b1b733abfce14fa15dcba5f9b09b576", transactionIndex: "49", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "20000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000ee29d559b7f049f9b2e96ff67324939e", contractAddress: "", cumulativeGasUsed: "1821349", gasUsed: "50111", confirmations: "3293002"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "316573474429488195592100318215108072350"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "316573474429488195592100318215108072350", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508931319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "amount", type: "uint256", value: "20000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [31657347442, 94881955921003, 18215108072350]}}, {name: "benefactor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"26068408169686497024908680647513546653... )", async function( ) {
		const txOriginal = {blockNumber: "4426771", timeStamp: "1508933710", hash: "0x64faf3aefe9e85c97c482067dfbf917cce27e645d652a66a42a603df50adea98", nonce: "1", blockHash: "0x4cf320f375e15b157ef67d60cdfe08486dcc73fb2eb7898ce05e2dc48f9a33b3", transactionIndex: "98", from: "0x4509da7c630e9de8759c91754741ccf46cdbbf5e", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "1110000000000000000", gas: "129003", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000c41ded8aa02446b1b02ee42f352b3c26", contractAddress: "", cumulativeGasUsed: "5423127", gasUsed: "85326", confirmations: "3292832"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "1110000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "260684081696864970249086806475135466534"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "260684081696864970249086806475135466534", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508933710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x4509da7c630e9de8759c91754741ccf46cdbbf5e"}, {name: "amount", type: "uint256", value: "1110000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26068408169, 68649702490868, 6475135466534]}}, {name: "benefactor", type: "address", value: "0x4509da7c630e9de8759c91754741ccf46cdbbf5e"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7012482000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"22442684416381126380964857320204134409... )", async function( ) {
		const txOriginal = {blockNumber: "4430972", timeStamp: "1508991939", hash: "0x83689dbcafeb2510fcf058ebfd1eea32ed8020101a7addb25666c4cd29c7d06f", nonce: "0", blockHash: "0xa640b4aacea878d68db812d3c040a5010449e2fb41f1ec284f3e19096d1356d4", transactionIndex: "43", from: "0xbe47064863b2b819c9349a0e2e2446873660938f", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "50581689430000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000a8d709b7165c49069da4fe6b8ae71061", contractAddress: "", cumulativeGasUsed: "1852736", gasUsed: "85326", confirmations: "3288631"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "50581689430000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "224426844163811263809648573202041344097"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "224426844163811263809648573202041344097", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508991939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xbe47064863b2b819c9349a0e2e2446873660938f"}, {name: "amount", type: "uint256", value: "50581689430000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [22442684416, 38112638096485, 73202041344097]}}, {name: "benefactor", type: "address", value: "0xbe47064863b2b819c9349a0e2e2446873660938f"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "305586406664065107" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4431416", timeStamp: "1508998256", hash: "0x143d8a7c70fc9d37d4f51399dd97373d0f06fe1c1931942160787140bec26c9a", nonce: "2", blockHash: "0x0ccdda32990c9eba5341355590db27eb430ad1d7a557882639ee2efc0b39d259", transactionIndex: "13", from: "0x84d467c848329a03b93c22b51ca3ba90ebeb68ad", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "3000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "441716", gasUsed: "21043", confirmations: "3288187"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "3000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1508998256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "20639673511000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"10183871085576853120194794370607110246... )", async function( ) {
		const txOriginal = {blockNumber: "4431870", timeStamp: "1509004346", hash: "0xf2262a9c176d5538a466a6ab4c019a5a71e537f102568d08133cd48134819fee", nonce: "0", blockHash: "0xa3aabfd4edd0c7b13437ff2d86b62a6cac8e24ce81f3c003a8503b69dfda27ef", transactionIndex: "29", from: "0xca48ba80cfa6cc06963b62aee48000f031c7e2dc", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "1121000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000004c9d6c1a1d9548689fbf5a49c6d37401", contractAddress: "", cumulativeGasUsed: "1043940", gasUsed: "85326", confirmations: "3287733"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1121000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "101838710855768531201947943706071102465"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "101838710855768531201947943706071102465", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509004346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xca48ba80cfa6cc06963b62aee48000f031c7e2dc"}, {name: "amount", type: "uint256", value: "1121000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10183871085, 57685312019479, 43706071102465]}}, {name: "benefactor", type: "address", value: "0xca48ba80cfa6cc06963b62aee48000f031c7e2dc"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "593636719000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"30071695020231623574562182424882679631... )", async function( ) {
		const txOriginal = {blockNumber: "4432200", timeStamp: "1509009471", hash: "0xfb8923119d447de4a697e2965558f8c79f5d2691e6edac4198e1b6f335d3608d", nonce: "1", blockHash: "0x4d71cf47023721f117e3bd423b7df91a9b3a801e70008d9596faf86a774bd7ab", transactionIndex: "4", from: "0x002143044ef9e3a81f8271907483b24c711a87cb", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "4000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000e23bfa58d496437288d56eb4e2ef9919", contractAddress: "", cumulativeGasUsed: "302207", gasUsed: "85326", confirmations: "3287403"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "300716950202316235745621824248826796313"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "300716950202316235745621824248826796313", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509009471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x002143044ef9e3a81f8271907483b24c711a87cb"}, {name: "amount", type: "uint256", value: "4000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [30071695020, 23162357456218, 24248826796313]}}, {name: "benefactor", type: "address", value: "0x002143044ef9e3a81f8271907483b24c711a87cb"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "103346085580000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"30071695020231623574562182424882679631... )", async function( ) {
		const txOriginal = {blockNumber: "4432967", timeStamp: "1509020368", hash: "0x2094ec1809d32dac11d6c02946631fcbd910c60621ac5f6409a27ae0979ac2d1", nonce: "2", blockHash: "0x531abb87c0716655cd0c6993979fd86dc1206a7756b7f669d2effa4401ebe0eb", transactionIndex: "39", from: "0x002143044ef9e3a81f8271907483b24c711a87cb", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "5580000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000e23bfa58d496437288d56eb4e2ef9919", contractAddress: "", cumulativeGasUsed: "1407568", gasUsed: "50111", confirmations: "3286636"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5580000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "300716950202316235745621824248826796313"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "300716950202316235745621824248826796313", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509020368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x002143044ef9e3a81f8271907483b24c711a87cb"}, {name: "amount", type: "uint256", value: "5580000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [30071695020, 23162357456218, 24248826796313]}}, {name: "benefactor", type: "address", value: "0x002143044ef9e3a81f8271907483b24c711a87cb"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "103346085580000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"25214576969057296218386568314174131384... )", async function( ) {
		const txOriginal = {blockNumber: "4433161", timeStamp: "1509023226", hash: "0x48095dd14eea95dc716dec6c29191aa2f0eea7c125d52401ea59e5a2f8f73659", nonce: "83", blockHash: "0x3a2f52def5a293eb6b39471281236b8c906b7067d3906e9eb2f3390859209866", transactionIndex: "90", from: "0xd02a135627224cab666bdde27b36b6c6d09c7323", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "30000000000000000", gas: "260300", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0x274465b40000000000000000000000000000000012f826a033824739a046d90a5ced4cb8", contractAddress: "", cumulativeGasUsed: "3552677", gasUsed: "85326", confirmations: "3286442"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "25214576969057296218386568314174131384"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "25214576969057296218386568314174131384", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509023226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xd02a135627224cab666bdde27b36b6c6d09c7323"}, {name: "amount", type: "uint256", value: "30000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2521457696, 90572962183865, 68314174131384]}}, {name: "benefactor", type: "address", value: "0xd02a135627224cab666bdde27b36b6c6d09c7323"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "86728458350190727" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"18098570966066258891464715773920687316... )", async function( ) {
		const txOriginal = {blockNumber: "4433210", timeStamp: "1509023942", hash: "0x977a4f78ce918ce901ba8a664ba56d76a9989e590303e199027e425a28167c81", nonce: "0", blockHash: "0x7b8e8b3d550e065ae88751e26276b95bc200b7f7185bbe7c3219d2a67df2176d", transactionIndex: "17", from: "0x3199dc213b09b9f303bc7452a38ae73197b72480", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "51994533700000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000008828946c14634c7fa1cd3071a79a1050", contractAddress: "", cumulativeGasUsed: "734768", gasUsed: "85326", confirmations: "3286393"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "51994533700000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "180985709660662588914647157739206873168"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "180985709660662588914647157739206873168", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509023942 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x3199dc213b09b9f303bc7452a38ae73197b72480"}, {name: "amount", type: "uint256", value: "51994533700000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [18098570966, 6625889146471, 57739206873168]}}, {name: "benefactor", type: "address", value: "0x3199dc213b09b9f303bc7452a38ae73197b72480"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"11188792256268474992056358723943914853... )", async function( ) {
		const txOriginal = {blockNumber: "4433539", timeStamp: "1509028741", hash: "0xa6756e113e83bfe316266fb3674c2f3823557f283ca2bec17928664a222a3c9d", nonce: "2", blockHash: "0x08caa85ee8b5726d572f3522a6ff4b0650b70b8dbf37ab321971802031b68f5d", transactionIndex: "56", from: "0x0008bf86174cc4d1410438f387776b298c9faf93", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "52000000000000000000", gas: "260300", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000542cd47e047f4c268f969b099c36a5f4", contractAddress: "", cumulativeGasUsed: "2347947", gasUsed: "85326", confirmations: "3286064"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "52000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "111887922562684749920563587239439148532"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "111887922562684749920563587239439148532", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509028741 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x0008bf86174cc4d1410438f387776b298c9faf93"}, {name: "amount", type: "uint256", value: "52000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [11188792256, 26847499205635, 87239439148532]}}, {name: "benefactor", type: "address", value: "0x0008bf86174cc4d1410438f387776b298c9faf93"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "6160948000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4435191", timeStamp: "1509051124", hash: "0x2f0e0d7c2804c86ff4feccd7816965d35b3ee0b6c620533b4cf18d24ff908e46", nonce: "0", blockHash: "0xa00b906a4a7bfa9e171313b43e589ae82e6dd663c472c8d8d264e688ad29cd03", transactionIndex: "91", from: "0xbd94bc187e407d073127656f601f765c111adc11", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "1000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3976004", gasUsed: "21043", confirmations: "3284412"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509051124 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"27095346991911423827881009523093454750... )", async function( ) {
		const txOriginal = {blockNumber: "4435376", timeStamp: "1509053881", hash: "0x013b9a91abd31eae718f25d6f80d194889539110964062f2b5519db1949c1b99", nonce: "7", blockHash: "0x7e6919a67db27e1bd45b005bff5fa71da288635f05b090f91ad950c2c048a223", transactionIndex: "3", from: "0x3aa01a00ad382098698d4ae04c27543d32fc60d5", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "17000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000cbd7bd78d9c54609ac1d2416936f7c2e", contractAddress: "", cumulativeGasUsed: "164142", gasUsed: "85326", confirmations: "3284227"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "17000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "270953469919114238278810095230934547502"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "270953469919114238278810095230934547502", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509053881 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x3aa01a00ad382098698d4ae04c27543d32fc60d5"}, {name: "amount", type: "uint256", value: "17000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [27095346991, 91142382788100, 95230934547502]}}, {name: "benefactor", type: "address", value: "0x3aa01a00ad382098698d4ae04c27543d32fc60d5"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"30071695020231623574562182424882679631... )", async function( ) {
		const txOriginal = {blockNumber: "4437550", timeStamp: "1509083586", hash: "0xf9c8175b649cdaccd5f534f59014d34cff4dcbde7cab3c31c089f45161dd228a", nonce: "3", blockHash: "0x0e9a2b520f95715bec1c974c133f0fecdaa7eea48d6b29a16b286d1c324e0e39", transactionIndex: "13", from: "0x002143044ef9e3a81f8271907483b24c711a87cb", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "48000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000e23bfa58d496437288d56eb4e2ef9919", contractAddress: "", cumulativeGasUsed: "901280", gasUsed: "50111", confirmations: "3282053"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "48000000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "300716950202316235745621824248826796313"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "300716950202316235745621824248826796313", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509083586 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x002143044ef9e3a81f8271907483b24c711a87cb"}, {name: "amount", type: "uint256", value: "48000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [30071695020, 23162357456218, 24248826796313]}}, {name: "benefactor", type: "address", value: "0x002143044ef9e3a81f8271907483b24c711a87cb"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "103346085580000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"28630837038568283679724203837745033269... )", async function( ) {
		const txOriginal = {blockNumber: "4438683", timeStamp: "1509099361", hash: "0x00377927cb31c8f27b6b304a6e1026c1188c902d2b5616735284c69474290625", nonce: "16", blockHash: "0x102e8edc204b33d8ac85a080f7c732a50bd1ecafd7f81c88323c0e98fded830a", transactionIndex: "7", from: "0x91a37680f88468caa01b871d35286fd8393bd623", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "55000000000000000000", gas: "260300", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000d764fc83c1c041e1b82c113aacc4621b", contractAddress: "", cumulativeGasUsed: "335064", gasUsed: "85326", confirmations: "3280920"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "55000000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "286308370385682836797242038377450332699"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "286308370385682836797242038377450332699", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509099361 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x91a37680f88468caa01b871d35286fd8393bd623"}, {name: "amount", type: "uint256", value: "55000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [28630837038, 56828367972420, 38377450332699]}}, {name: "benefactor", type: "address", value: "0x91a37680f88468caa01b871d35286fd8393bd623"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "695541924390039340" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"19455225079870404084055053845854609029... )", async function( ) {
		const txOriginal = {blockNumber: "4439290", timeStamp: "1509107857", hash: "0x061f0c9977074bae6eeb7d0414afc69632307b0740f2fd9f826c1201326c68cd", nonce: "34", blockHash: "0x9f55d469b199fa17ad6f3d1a1d0bc4143ea5465ea7089a6c0411b0d9a9315aca", transactionIndex: "32", from: "0x180175be758b8c9f0b42b6869cf917a793e92c53", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "50900000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000925d668ad87a46b5ab8d060021f4b135", contractAddress: "", cumulativeGasUsed: "1170258", gasUsed: "85262", confirmations: "3280313"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "50900000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "194552250798704040840550538458546090293"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "194552250798704040840550538458546090293", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509107857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x180175be758b8c9f0b42b6869cf917a793e92c53"}, {name: "amount", type: "uint256", value: "50900000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [19455225079, 87040408405505, 38458546090293]}}, {name: "benefactor", type: "address", value: "0x180175be758b8c9f0b42b6869cf917a793e92c53"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "14093823129555555554" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"25591207169164264780000207772940984527... )", async function( ) {
		const txOriginal = {blockNumber: "4439425", timeStamp: "1509109717", hash: "0x69c8476a5dfc6324a052e13c8d7b0202a43f8f843086748127ffa799c61225e9", nonce: "1", blockHash: "0x5a7305f8876136e4d68f1785ed46eb2180bad78d15a8511e1794a97c8726636e", transactionIndex: "8", from: "0xbd94bc187e407d073127656f601f765c111adc11", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "60000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000c086df4881a74c75bef6530b8c49c81c", contractAddress: "", cumulativeGasUsed: "457217", gasUsed: "85326", confirmations: "3280178"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "60000000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "255912071691642647800002077729409845276"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "255912071691642647800002077729409845276", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509109717 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xbd94bc187e407d073127656f601f765c111adc11"}, {name: "amount", type: "uint256", value: "60000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [25591207169, 16426478000020, 77729409845276]}}, {name: "benefactor", type: "address", value: "0xbd94bc187e407d073127656f601f765c111adc11"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"25591207169164264780000207772940984527... )", async function( ) {
		const txOriginal = {blockNumber: "4439455", timeStamp: "1509110294", hash: "0x8d6eb2b564b990c387a2679879410b6b626cbdec227c936c2db4b4ca3ebe295d", nonce: "2", blockHash: "0x027c98779039c0609a674fd3f41097640fd18ae08752eaa0a1cc8817a8ca0858", transactionIndex: "18", from: "0xbd94bc187e407d073127656f601f765c111adc11", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "80000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000c086df4881a74c75bef6530b8c49c81c", contractAddress: "", cumulativeGasUsed: "912764", gasUsed: "50111", confirmations: "3280148"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "80000000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "255912071691642647800002077729409845276"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "255912071691642647800002077729409845276", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509110294 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xbd94bc187e407d073127656f601f765c111adc11"}, {name: "amount", type: "uint256", value: "80000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [25591207169, 16426478000020, 77729409845276]}}, {name: "benefactor", type: "address", value: "0xbd94bc187e407d073127656f601f765c111adc11"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4439648", timeStamp: "1509112878", hash: "0x3c9166d395b10fce3e1ce31f54eab8bd7ffb957f8e1f83f8683e80f974fe12d6", nonce: "0", blockHash: "0x45718ba9a83773530b7f00f225727c90eb82fe4afde6c823866c2963b67a36ee", transactionIndex: "7", from: "0x552b53ff42d467e3ee5637aea9961144f527a360", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "50800000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "206452", gasUsed: "21043", confirmations: "3279955"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "50800000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509112878 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"12134659249865762997645917846834407072... )", async function( ) {
		const txOriginal = {blockNumber: "4439827", timeStamp: "1509115354", hash: "0x2ce0a0ef5c0fba161dda7b08fe3aa281cf37987cf1cb58a28920bc696b8bb821", nonce: "1", blockHash: "0xab690499ce2d3b3a05ea401fa9a3d7a80c0462c849c6d0b19e1bbb4d4323827a", transactionIndex: "17", from: "0x552b53ff42d467e3ee5637aea9961144f527a360", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "52000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000005b4a80ecdd16405ebb6ea49a03880248", contractAddress: "", cumulativeGasUsed: "1065586", gasUsed: "85326", confirmations: "3279776"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "52000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "121346592498657629976459178468344070728"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "121346592498657629976459178468344070728", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509115354 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x552b53ff42d467e3ee5637aea9961144f527a360"}, {name: "amount", type: "uint256", value: "52000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [12134659249, 86576299764591, 78468344070728]}}, {name: "benefactor", type: "address", value: "0x552b53ff42d467e3ee5637aea9961144f527a360"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"21456097047085904485968134489604310287... )", async function( ) {
		const txOriginal = {blockNumber: "4439960", timeStamp: "1509117208", hash: "0xa812a3317d8df8d3ef84b52c382ae5ac3a5b49942a1073e16b6cfcbb5eda44a6", nonce: "6", blockHash: "0xb09819f67c22778b2af6d9db570eb3d8f00fcf82af0b5f843ce966434c1e1eae", transactionIndex: "10", from: "0x210ea055096a7cad87b69fbbc815be0019f035b2", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "90400000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000a16af0964079447b9014326b4d38b29d", contractAddress: "", cumulativeGasUsed: "1074279", gasUsed: "85326", confirmations: "3279643"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "90400000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "214560970470859044859681344896043102877"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "214560970470859044859681344896043102877", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509117208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x210ea055096a7cad87b69fbbc815be0019f035b2"}, {name: "amount", type: "uint256", value: "90400000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21456097047, 8590448596813, 44896043102877]}}, {name: "benefactor", type: "address", value: "0x210ea055096a7cad87b69fbbc815be0019f035b2"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "35547181527765548988" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4442200", timeStamp: "1509148384", hash: "0xa2a0a568d2bbfacc49546adbbd5b39c7a09d241ec8c2be52a97ab315ed94253f", nonce: "2", blockHash: "0xb81066152881a3feee2c3825662f2f00745e527d8732f719002b218849f5cab2", transactionIndex: "22", from: "0xad705cad2c24ae38a1a2c23b8e8dae82789fb366", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "150000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1168143", gasUsed: "21043", confirmations: "3277403"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509148384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "4334018000000032" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4442221", timeStamp: "1509148760", hash: "0xbc996332804cf44b0c9710214951880839e568cd1b8e5c2aa5797391db1aea1b", nonce: "3", blockHash: "0x4afbbec25d4c56d5c2eb47261f707d0efebbfd985c403a79239633c4169e4c72", transactionIndex: "53", from: "0xad705cad2c24ae38a1a2c23b8e8dae82789fb366", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "150000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3067043", gasUsed: "21043", confirmations: "3277382"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509148760 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "4334018000000032" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4444271", timeStamp: "1509177198", hash: "0x24641d2309a0bcff85b3dda69a9b658d98d9794f7f54a2724ba4a207391212b5", nonce: "9", blockHash: "0xd8d3048478a2fc6d56dd356212dd4d836e8c9cd8c380b901a9eea633de0bf6b1", transactionIndex: "54", from: "0xd4e78fd9e9f2f9f41e3a7a3480e78a7f0cc95ac0", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "1000000000000000000", gas: "260300", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2433097", gasUsed: "21043", confirmations: "3275332"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509177198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "5569775174730000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"20456199101359239863877323272128384226... )", async function( ) {
		const txOriginal = {blockNumber: "4444311", timeStamp: "1509177662", hash: "0xcc8c976f21049fdae3816f195f6a16673002e0b4b274a393cf54cd6a62968a37", nonce: "10", blockHash: "0xe09c46f148d694bac87c5a379aca75263d15868f13ce34333f1b3f5f0b1e9b5e", transactionIndex: "21", from: "0xd4e78fd9e9f2f9f41e3a7a3480e78a7f0cc95ac0", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "1000000000000000000", gas: "260300", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x274465b40000000000000000000000000000000099e534d67a0a4d89aabf387f50cd00d8", contractAddress: "", cumulativeGasUsed: "1294431", gasUsed: "85262", confirmations: "3275292"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "204561991013592398638773232721283842264"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "204561991013592398638773232721283842264", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509177662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xd4e78fd9e9f2f9f41e3a7a3480e78a7f0cc95ac0"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [20456199101, 35923986387732, 32721283842264]}}, {name: "benefactor", type: "address", value: "0xd4e78fd9e9f2f9f41e3a7a3480e78a7f0cc95ac0"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "5569775174730000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"82256238350762155995943964226338098454... )", async function( ) {
		const txOriginal = {blockNumber: "4444870", timeStamp: "1509185652", hash: "0xb6b0f50ca3100bece6a94625aeef37e3be085b77148dcaa4f9e4205a51382e34", nonce: "9", blockHash: "0x5b7ed8de26c893c58ddaebb51d1329b45d66c94c5ab05acd8433d178e64a025b", transactionIndex: "28", from: "0x8cab03c38c8be5d76404d647a5c45ae53a027341", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "52000000000000000000", gas: "260300", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x274465b4000000000000000000000000000000003de1f9aa53cb497f83827105b61b0d16", contractAddress: "", cumulativeGasUsed: "1398264", gasUsed: "85326", confirmations: "3274733"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "52000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "82256238350762155995943964226338098454"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "82256238350762155995943964226338098454", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1509185652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x8cab03c38c8be5d76404d647a5c45ae53a027341"}, {name: "amount", type: "uint256", value: "52000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [8225623835, 7621559959439, 64226338098454]}}, {name: "benefactor", type: "address", value: "0x8cab03c38c8be5d76404d647a5c45ae53a027341"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "24336471262876849" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"27095346991911423827881009523093454750... )", async function( ) {
		const txOriginal = {blockNumber: "4446129", timeStamp: "1509202884", hash: "0xa3b5cb313aafae99c17ccb4271c3bd114684ee0fe5e3c53d9b5c6e7272688434", nonce: "8", blockHash: "0xb4f22481d684021a2601765109154f42788230d4a2dfd6476d92b7b56948f0bf", transactionIndex: "8", from: "0x3aa01a00ad382098698d4ae04c27543d32fc60d5", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "70000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000cbd7bd78d9c54609ac1d2416936f7c2e", contractAddress: "", cumulativeGasUsed: "928794", gasUsed: "50111", confirmations: "3273474"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "70000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "270953469919114238278810095230934547502"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "270953469919114238278810095230934547502", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1509202884 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x3aa01a00ad382098698d4ae04c27543d32fc60d5"}, {name: "amount", type: "uint256", value: "70000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [27095346991, 91142382788100, 95230934547502]}}, {name: "benefactor", type: "address", value: "0x3aa01a00ad382098698d4ae04c27543d32fc60d5"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"25488981176914375090639149462055090113... )", async function( ) {
		const txOriginal = {blockNumber: "4446616", timeStamp: "1509209661", hash: "0xc6f864d4580644d3ea63e79deb63cf14e670d21f9d3cff3653012221b0c31967", nonce: "29", blockHash: "0x5bb5adaee8a888bdb68e1bae8b76e392f6157c0fbd31c3f1781c10db488f3000", transactionIndex: "29", from: "0x86349c83c83f0b99aee89c55f6cb17c92aec9517", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "1000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000bfc1fdfa4d1640238250ec2db511ad8b", contractAddress: "", cumulativeGasUsed: "1738496", gasUsed: "85326", confirmations: "3272987"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "254889811769143750906391494620550901131"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "254889811769143750906391494620550901131", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1509209661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x86349c83c83f0b99aee89c55f6cb17c92aec9517"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [25488981176, 91437509063914, 94620550901131]}}, {name: "benefactor", type: "address", value: "0x86349c83c83f0b99aee89c55f6cb17c92aec9517"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "24274051336169826310" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"25591207169164264780000207772940984527... )", async function( ) {
		const txOriginal = {blockNumber: "4447685", timeStamp: "1509224479", hash: "0xeec72227649a678170ddcf2e7605c63dcb52b618e6c280cbb9eb67d190019195", nonce: "3", blockHash: "0xf3e67f0450cba2ecb6f4f4ae114c11113a3a1792ba40e4b91daa517075dde08a", transactionIndex: "3", from: "0xbd94bc187e407d073127656f601f765c111adc11", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "135000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000c086df4881a74c75bef6530b8c49c81c", contractAddress: "", cumulativeGasUsed: "113111", gasUsed: "50111", confirmations: "3271918"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "135000000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "255912071691642647800002077729409845276"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "255912071691642647800002077729409845276", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1509224479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xbd94bc187e407d073127656f601f765c111adc11"}, {name: "amount", type: "uint256", value: "135000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [25591207169, 16426478000020, 77729409845276]}}, {name: "benefactor", type: "address", value: "0xbd94bc187e407d073127656f601f765c111adc11"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"25669760953321509939000008403319730230... )", async function( ) {
		const txOriginal = {blockNumber: "4450561", timeStamp: "1509263981", hash: "0x99619a7f1c4a6bef8743d9c4cf9e10d5f4f507ffb0ca4b2d3b80709e60955045", nonce: "35", blockHash: "0x04af8c2b93b948fcd5a32ce4dff9a9c26924bca25370e8d6017348a0a06d3275", transactionIndex: "6", from: "0xd35184b3fb9b3376e4af80f41c6ab012a9f81f79", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "55000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000134fd0edcc92473aa588c8d9b5cf3036", contractAddress: "", cumulativeGasUsed: "933126", gasUsed: "85326", confirmations: "3269042"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "55000000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "25669760953321509939000008403319730230"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "25669760953321509939000008403319730230", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1509263981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0xd35184b3fb9b3376e4af80f41c6ab012a9f81f79"}, {name: "amount", type: "uint256", value: "55000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2566976095, 33215099390000, 8403319730230]}}, {name: "benefactor", type: "address", value: "0xd35184b3fb9b3376e4af80f41c6ab012a9f81f79"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "6197446095807210" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4451300", timeStamp: "1509275106", hash: "0x3823228a33ab299ada700dcea908dc68287a6baf26586a84ba4dfc5f070fa763", nonce: "11", blockHash: "0x554dd16c7aeea1e68169492da958dc19e2377aa55f63a24ce64fdb87350df54c", transactionIndex: "10", from: "0xa158d09b3b67244c160a98de47aa06807d4b80d5", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "2000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "720314", gasUsed: "21043", confirmations: "3268303"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1509275106 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "533676748000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: payForMyself( \"24543270124948621758025920384246973777... )", async function( ) {
		const txOriginal = {blockNumber: "4451738", timeStamp: "1509281696", hash: "0x0f3cc71291a1843ff73068d912c3f3f8d3aacc62ba72ef84e57e5b4d8f28a269", nonce: "39", blockHash: "0xa4913ab042847c25d3876d9a75bc8c759ce172f50b45c172d56ccfbb739c6d7f", transactionIndex: "46", from: "0x99c05254937f7b39730292183d7e3e1e696eea80", to: "0x51d3aac348d1a26652c6e8eab065a269830d1930", value: "75000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x274465b400000000000000000000000000000000b8a49e6e0e5e401094e93844fd033531", contractAddress: "", cumulativeGasUsed: "2008599", gasUsed: "85326", confirmations: "3267865"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "75000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "customerId", value: "245432701249486217580259203842469737777"}], name: "payForMyself", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payForMyself(uint128)" ]( "245432701249486217580259203842469737777", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1509281696 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}, {indexed: false, name: "benefactor", type: "address"}], name: "PaymentForwarded", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PaymentForwarded", events: [{name: "source", type: "address", value: "0x99c05254937f7b39730292183d7e3e1e696eea80"}, {name: "amount", type: "uint256", value: "75000000000000000000"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [24543270124, 94862175802592, 3842469737777]}}, {name: "benefactor", type: "address", value: "0x99c05254937f7b39730292183d7e3e1e696eea80"}], address: "0x51d3aac348d1a26652c6e8eab065a269830d1930"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "175755080429999550" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
