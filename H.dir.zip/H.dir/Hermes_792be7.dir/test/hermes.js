const Hermes = artifacts.require( "./Hermes.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Hermes" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xcB5f8bB5C11B1Fd20dEcFF442FfA2e48Fd792be7", "0xbA9e1EDDbfB265BF2992B28cF03355372bE7162e", "0x49be3A14a839FF03AF6E4A1572f13AfC3844EdE9", "0xdBAeBAC531f4E345b1D66aF84498377D9781F26B", "0xa095d48e805F165A1B8351cF5dB90C7bE12c21dF", "0x2F3fe46d370228943C537af2a7dEa7d7f2BE58A1", "0x524c277e9774D31b0FD5A4B7EBCB4c1Bc6EFFcA2", "0x06D867bcf29f2E03d93D0b153f85DFC802cA8f46", "0x542C30d3F83F1145d31426102e6E7953Ba6c626b", "0xd6411DA97BF67fad0EA6e9Aa1A88D42FAAB06849", "0xE45d46C1D1Aa5bcbF1258E5e7FCd6a5E8b7483e8", "0xCa807e12E7253102af98a9E524121C64973Cf7f2", "0xd19F788E27D123Bdd18C83F074B136105EB1E435", "0x4e6265555E11452358051fE18464c6fcAe035886", "0x016D9F8c1C25A04370E9f6b89CA2e57c3A8ecD87"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "DAY_LIMIT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MINIMUM_INVEST", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "INVESTORS", outputs: [{name: "id", type: "uint256"}, {name: "percentCount", type: "uint256"}, {name: "deposit", type: "uint256"}, {name: "date", type: "uint256"}, {name: "referrer", type: "address"}, {name: "reinvestID", type: "uint256"}, {name: "actualValue", type: "uint256"}, {name: "stage", type: "uint256"}, {name: "startReinvestDate", type: "uint256"}, {name: "dayLimitValue", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "ADDRESSES", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ADMIN_ADDR", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "DAY_VALUE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "PERCENT_FOR_MARKETING", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "DEPOSIT_AMOUNT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "active", type: "uint256"}], name: "reinvest", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["reinvest(uint256,address,uint256)", "payout(uint256,address,uint256,string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4146c4559b81e0fa5e63839b55927bd231ca0f06d08ac6a47b6c86eb4426a991", "0x7a2fe93ad1fcaf10b8d71ae38bb403baf0d9496d357059f65e73ab7847d96fe4"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6771907 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6856848 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Hermes", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "DAY_LIMIT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DAY_LIMIT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MINIMUM_INVEST", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MINIMUM_INVEST()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "INVESTORS", outputs: [{name: "id", type: "uint256"}, {name: "percentCount", type: "uint256"}, {name: "deposit", type: "uint256"}, {name: "date", type: "uint256"}, {name: "referrer", type: "address"}, {name: "reinvestID", type: "uint256"}, {name: "actualValue", type: "uint256"}, {name: "stage", type: "uint256"}, {name: "startReinvestDate", type: "uint256"}, {name: "dayLimitValue", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "INVESTORS(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "ADDRESSES", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ADDRESSES(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ADMIN_ADDR", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ADMIN_ADDR()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DAY_VALUE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DAY_VALUE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PERCENT_FOR_MARKETING", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PERCENT_FOR_MARKETING()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DEPOSIT_AMOUNT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DEPOSIT_AMOUNT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Hermes", function( accounts ) {

	it( "TEST: Hermes(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6771907", timeStamp: "1543175309", hash: "0x9fc6a197f92d65e308a5e8c30e2bc712c4340fee5767a60a94a3e24bc9ac884b", nonce: "5", blockHash: "0xaff3dff2b7a09cd35279ec255ed824fea4d05d49d20b6a1aecbf63a2db96cf2b", transactionIndex: "9", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: 0, value: "0", gas: "3298342", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x6067bbfe", contractAddress: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", cumulativeGasUsed: "3570470", gasUsed: "3298342", confirmations: "932508"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Hermes", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Hermes.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543175309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Hermes.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6774935", timeStamp: "1543217400", hash: "0x60bdde2e21c06b0fc4d0cbfcfb5a804f06b94559949aa24ecd647c9356f40cb0", nonce: "6", blockHash: "0x039ed5f8c551250cd1d92cea5a8e85ebb71f654a01688c40d1d3e9e9f7730092", transactionIndex: "156", from: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "30000000000000000", gas: "105304", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "6725080", gasUsed: "105304", confirmations: "929480"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "6319926000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6774947", timeStamp: "1543217606", hash: "0x6270e3b559eb0ca3de2dfe18ae106ff7bcce4f527dd58ba77e82fe10d038ef19", nonce: "7", blockHash: "0x92db61b42412fe7788e1737a324c7af917ec16fab78b5e7c843a28afbc356351", transactionIndex: "132", from: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "30000000000000000", gas: "110000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7555446", gasUsed: "110000", confirmations: "929468"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "6319926000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6775284", timeStamp: "1543222737", hash: "0xf6c85952d578ac7920bb3ffdf6771ea90b16fa04b8998d8eb397a0b28204cf89", nonce: "6", blockHash: "0x483a2b7e57a77bbf814437393697070089873b65639e2252de67163b13517a5c", transactionIndex: "176", from: "0xdbaebac531f4e345b1d66af84498377d9781f26b", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "300000000000000000", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7797978", gasUsed: "244523", confirmations: "929131"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543222737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "307525957000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6775285", timeStamp: "1543222758", hash: "0xd30f1d4413c169bab2ce9c0f5b9844f8db727c47b543a0f9323ccb020e725c0c", nonce: "1", blockHash: "0xe55bc4e205ca19dd82da3529814fbf1c22a174b96ff782dafbb3fe5beae5e67c", transactionIndex: "101", from: "0xa095d48e805f165a1b8351cf5db90c7be12c21df", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "300000000000000000", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4121031", gasUsed: "199523", confirmations: "929130"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543222758 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "307603994000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6776278", timeStamp: "1543237235", hash: "0x8ed77fdeb5cca97159d71ecf8b440c497a0fe2501982a3ff9da98d1368363a33", nonce: "21", blockHash: "0xad8025e53dc302766b0f90b7beabdfbe1566a1f0409689cd873589139d9fffe1", transactionIndex: "64", from: "0x2f3fe46d370228943c537af2a7dea7d7f2be58a1", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "300000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3193548", gasUsed: "70203", confirmations: "928137"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543237235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1543237235"}, {name: "addr", type: "address", value: "0x2f3fe46d370228943c537af2a7dea7d7f2be58a1"}, {name: "amount", type: "uint256", value: "0"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "720856461549570" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6776629", timeStamp: "1543242616", hash: "0xdda92ebeacbd88795c64a287b957747bf099eb88f6b3460402735368b7a44139", nonce: "0", blockHash: "0xfa16988f360b79a79d0dce9a811a23208c7ebda0965c06b9f1be285278e508b0", transactionIndex: "87", from: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "200000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xdbaebac531f4e345b1d66af84498377d9781f26b", contractAddress: "", cumulativeGasUsed: "4756641", gasUsed: "200000", confirmations: "927786"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2536199999979000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6776644", timeStamp: "1543242776", hash: "0x084854587cca6178d85c6a30524c4783b05b012b133c48b640ddcde5ad65ac0f", nonce: "1", blockHash: "0xb0e30eea3ee37b45f06c62728e6147b381145e787895a718e46b2551b07b7933", transactionIndex: "26", from: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "250000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xdbaebac531f4e345b1d66af84498377d9781f26b", contractAddress: "", cumulativeGasUsed: "1528365", gasUsed: "216860", confirmations: "927771"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543242776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2536199999979000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6776699", timeStamp: "1543243511", hash: "0x3fb6aef32205851ad1000fb87bf8fc8e3e388881aa161ddf9e8825add4628f8d", nonce: "7", blockHash: "0x7f126c158126936d9dd0cf298f6052d206e9f3ad9b551adb043a5afb2e8eca1d", transactionIndex: "112", from: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "250000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2", contractAddress: "", cumulativeGasUsed: "6923024", gasUsed: "250000", confirmations: "927716"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "793310985833334332" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6776735", timeStamp: "1543244109", hash: "0x56cb0aa14390556a1a8b256cc7acea0ac1256ecf0cb3de96c7fc992d9368fba1", nonce: "8", blockHash: "0x5fc26ab30a60f7d3ca861c77d55b27bca7c6bc5cd9309458eeb938c9cdc04586", transactionIndex: "66", from: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "255656", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2", contractAddress: "", cumulativeGasUsed: "5602724", gasUsed: "255656", confirmations: "927680"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543244109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "793310985833334332" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6777987", timeStamp: "1543261327", hash: "0x57f86bc8b444d26c429c2e430d4eb37b607d0b38851b7f930c5d24791e13727c", nonce: "0", blockHash: "0x74c567c67c4e448c128ac0b122eea75b603e57174ae1b89ffbe4b4379ac2bb0c", transactionIndex: "21", from: "0x542c30d3f83f1145d31426102e6e7953ba6c626b", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "3000000000000000000", gas: "199523", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "739964", gasUsed: "199523", confirmations: "926428"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "3000000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543261327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "952401000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6781378", timeStamp: "1543310545", hash: "0x9d2134eb1476ae742ba7e59ec3a48e436b2e00ed59a681947f5c27c5ff4b824f", nonce: "0", blockHash: "0x9a8de037b80f61451b6f15d4fc460c9f7910c9e8dd04803ec986bf7611bb5512", transactionIndex: "80", from: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "282241", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46", contractAddress: "", cumulativeGasUsed: "4399650", gasUsed: "282241", confirmations: "923037"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543310545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "148801000000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6781660", timeStamp: "1543314765", hash: "0x26812df24158d47ddae892e51b12e4d90242179772d565a208dc2f167766c886", nonce: "24", blockHash: "0x11fa372e7c9e4ae0543e5f61ac027ed9aac35b24a5ccf40f21cb311e14097234", transactionIndex: "128", from: "0x2f3fe46d370228943c537af2a7dea7d7f2be58a1", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "400000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7368913", gasUsed: "21588", confirmations: "922755"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543314765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "720856461549570" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6783087", timeStamp: "1543335440", hash: "0x879c49bf452d6ef6fcf45843e8a6341ffa15bc9442342f01f5d99e0c6c617226", nonce: "26", blockHash: "0xe3f6ee206a05112fa6f8f189a3706f1314dea140d32fed962ad5796ddfd69407", transactionIndex: "6", from: "0x2f3fe46d370228943c537af2a7dea7d7f2be58a1", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "7600027", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "332875", gasUsed: "21588", confirmations: "921328"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543335440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "720856461549570" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6783135", timeStamp: "1543336190", hash: "0x52436dad23b79e239dd8fd87f087ad01956f928010f47a2e1936a996a1351318", nonce: "27", blockHash: "0xd44a42d756b183be12039191e4d45cf7788efc324a70b020b8ecb252eb6831d4", transactionIndex: "58", from: "0x2f3fe46d370228943c537af2a7dea7d7f2be58a1", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "300000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2493137", gasUsed: "21588", confirmations: "921280"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543336190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "720856461549570" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6789413", timeStamp: "1543426156", hash: "0xde9b08a834e87ca462b233e7615ce2deef1730e7e11a67510a64b8d7aac8d529", nonce: "9", blockHash: "0xa38886bf8e90c13c6d63aba33c5d221a61d6c9514d6ceddf75d6a9c0a17b9a44", transactionIndex: "59", from: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "40000000000000000", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4989672", gasUsed: "199523", confirmations: "915002"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543426156 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "6319926000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6789514", timeStamp: "1543427621", hash: "0xbf8d32633d6f3582f04b0b4ea654b44e119aacd527fe1a1c26913eb4d71ebcaf", nonce: "11", blockHash: "0xced1d960cfd5ebd80e7d8360d645c7a62f91b560e2034f4f8663b0ec9655ec01", transactionIndex: "4", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "322208", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "318726", gasUsed: "202208", confirmations: "914901"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543427621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1543427621"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "7500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543427621"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "7500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543427621"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "145000000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543427621"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "135000000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543427621"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543427621"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6789719", timeStamp: "1543430215", hash: "0x3a53fc9e49bc10b195e6fd088a3cd75cd2d285b53369b2caadf6f6be4059479a", nonce: "0", blockHash: "0x5ee69c394d0719a69705145d0590f8fed5daaac675703784d4f2815085ac6fa0", transactionIndex: "147", from: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "699000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2", contractAddress: "", cumulativeGasUsed: "7543529", gasUsed: "250546", confirmations: "914696"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "699000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543430215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "1913132000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6795897", timeStamp: "1543517860", hash: "0x3bb037e51d13ac7a9f3dc8a65ce35d9de696d5d0dcc9bab3b9030ae32ed2806e", nonce: "12", blockHash: "0x9d4af076f221e00d21f3f2a70d9ce6028b95c872c1096ec30ff96ad954aa62ad", transactionIndex: "42", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "315449", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3576250", gasUsed: "285449", confirmations: "908518"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543517860 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "72500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "67500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543517860"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6801415", timeStamp: "1543596145", hash: "0x833acce7d9334a9136a3b7ae08ed7956144c4e3a21a63fc8cf04e41590bc01de", nonce: "13", blockHash: "0x75abf7eed986306db7dd09b9a27b3e9d207ed5d7a0272286732f6f9e8e971f3f", transactionIndex: "40", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1364986", gasUsed: "105058", confirmations: "903000"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543596145 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6808061", timeStamp: "1543690966", hash: "0x1055b76f55be4d1e7f587b04aef510e71fcf361f0d0fcf7dc45009a2f77aab0b", nonce: "15", blockHash: "0x6ef43942d75a46241529a5685746595df80bacbac08f30e518620c7353735ca1", transactionIndex: "39", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "285449", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4679339", gasUsed: "285449", confirmations: "896354"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543690966 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "7500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "7500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "145000000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "135000000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "75000000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "125000000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "1000000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543690966"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "17475000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6814095", timeStamp: "1543777457", hash: "0x6393d425b3bc99c5c6852d669d3b568b2ece9c34c56b8a52383a32be4e753451", nonce: "16", blockHash: "0x8369727cd2dd0f8f20a775f8e1e058cae0f3fda887629a88d02434969b4dc529", transactionIndex: "20", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "105058", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1397325", gasUsed: "105058", confirmations: "890320"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6814097", timeStamp: "1543777521", hash: "0x5274b81bb3dad9f5140d6d254d02a8c9fb671293e3838405e87e1286d70c1fd3", nonce: "17", blockHash: "0x0363efd078fb556e36a04497fc8e88efa293d2b272f8005971e9b69e3b14979f", transactionIndex: "9", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "285449", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "591056", gasUsed: "285449", confirmations: "890318"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543777521 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "72500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "67500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543777521"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6820104", timeStamp: "1543864013", hash: "0x72925b9a76e02b61c71896dad342288d4f00251da2d484cac3e3a9381d3c1627", nonce: "18", blockHash: "0xb23ebbc7b5421f22fca6bc97405ddb0b39d201900b73ae79bba9ab188a6006d9", transactionIndex: "25", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "285449", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1332064", gasUsed: "285449", confirmations: "884311"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543864013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "72500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "67500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543864013"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6826209", timeStamp: "1543950454", hash: "0xe02470f9e1f921613e1603aa2d3acfbe3a188e2b753193b916704c6548efeef2", nonce: "19", blockHash: "0x8045f42d243665ccab2ea050c55e86d01d671acc4e3d1d37db08d339a080e31a", transactionIndex: "9", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "105058", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2669717", gasUsed: "105058", confirmations: "878206"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6826248", timeStamp: "1543950956", hash: "0x7888024dabc978137e4ee8635dfd1eb608e9b91cc27048593a7391b7e45d5a9c", nonce: "20", blockHash: "0xd07b4f3921dfefe0767ab0fa20bef6241e8ba4594052cacf3efc4e0cd6ce0cc8", transactionIndex: "27", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "300000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1038910", gasUsed: "285449", confirmations: "878167"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543950956 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "72500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "67500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1543950956"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6826825", timeStamp: "1543958270", hash: "0xbd296c059974d8e57b10733061a09794329e2752d34c97ac95dd649e50a0e608", nonce: "0", blockHash: "0x851ce487051803a02bbb6f5e572b282573e57face8acfb098484d53dc19ff976", transactionIndex: "35", from: "0xca807e12e7253102af98a9e524121c64973cf7f2", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5100000000000000000", gas: "323826", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849", contractAddress: "", cumulativeGasUsed: "7481080", gasUsed: "323826", confirmations: "877590"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "5100000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543958270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "2139000000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6831529", timeStamp: "1544026822", hash: "0x7a478d3b5f85e95effc85cef12d5693b4cfe8353cf6628650faca7068191cf35", nonce: "0", blockHash: "0x8d018e8987ce56ff733705ac746d0e3212889e2434d28c77ee8e8bc29ef31d02", transactionIndex: "100", from: "0xd19f788e27d123bdd18c83f074b136105eb1e435", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "210000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0xca807e12e7253102af98a9e524121c64973cf7f2", contractAddress: "", cumulativeGasUsed: "5181623", gasUsed: "210000", confirmations: "872886"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "5143275062000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6831590", timeStamp: "1544027599", hash: "0x704c056dc4f953a1c4700639267f7804b9084e07eee73970dc33edd64635c39e", nonce: "1", blockHash: "0x3d645734ac4cee3cf33aa501d46d8920bbe133f1d78aa5e459112413208f7e67", transactionIndex: "38", from: "0xd19f788e27d123bdd18c83f074b136105eb1e435", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "250000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xca807e12e7253102af98a9e524121c64973cf7f2", contractAddress: "", cumulativeGasUsed: "7790894", gasUsed: "250000", confirmations: "872825"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "5143275062000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6831650", timeStamp: "1544028337", hash: "0xa9438788c29a8969896f5e4b44eed9bf76a30833b3d310a182453d3f752fd3da", nonce: "2", blockHash: "0x37e89c111cd45be983e76224f6bc0ea77c500cfd5e9ed17b8a3f4d70743bc796", transactionIndex: "109", from: "0xd19f788e27d123bdd18c83f074b136105eb1e435", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "320000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xca807e12e7253102af98a9e524121c64973cf7f2", contractAddress: "", cumulativeGasUsed: "7241608", gasUsed: "320000", confirmations: "872765"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "5143275062000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6831661", timeStamp: "1544028516", hash: "0x4c76be750004763cbc5beacd4acd07ddf38c2aa34ca75dff904174375830780a", nonce: "3", blockHash: "0x03778b4e020859b4e98fef27e917d113811dcdaf404c064d25208a682069ac3d", transactionIndex: "67", from: "0xd19f788e27d123bdd18c83f074b136105eb1e435", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "360000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xca807e12e7253102af98a9e524121c64973cf7f2", contractAddress: "", cumulativeGasUsed: "4378924", gasUsed: "326241", confirmations: "872754"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544028516 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "5143275062000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6832239", timeStamp: "1544036971", hash: "0x809652a850a551b688a9ddf2b254ff5b55c6afa465bcc5347444b8179027c2bd", nonce: "21", blockHash: "0xd67575e1b8654d8ccd7d3e2749e7547d9341970f92867f1dd1f7aee55e852b7d", transactionIndex: "16", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3862311", gasUsed: "76352", confirmations: "872176"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544036971 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6832863", timeStamp: "1544045781", hash: "0x4d87d705982b92f4c7ec444d60089c01b0323082026fc6b81139c4a77cf11bb2", nonce: "0", blockHash: "0xb80a0816ef8952f96cd76a2e34e77eec5562cc88ab48f1627317cc9371830032", transactionIndex: "230", from: "0x4e6265555e11452358051fe18464c6fcae035886", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "250523", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xca807e12e7253102af98a9e524121c64973cf7f2", contractAddress: "", cumulativeGasUsed: "7963405", gasUsed: "250523", confirmations: "871552"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "1961000000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6832872", timeStamp: "1544045917", hash: "0x16cfe5e774bfb60704d1e5d0298767064b813b4e6b7924b75e62240b10de0e69", nonce: "1", blockHash: "0x8bfafb751ceda99b1b1e0a0fbb79a5064345a431bcdb2ff3582574f24c82449b", transactionIndex: "30", from: "0x4e6265555e11452358051fe18464c6fcae035886", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "5000000000000000000", gas: "350523", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xca807e12e7253102af98a9e524121c64973cf7f2", contractAddress: "", cumulativeGasUsed: "1557240", gasUsed: "301445", confirmations: "871543"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544045917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "1961000000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838279", timeStamp: "1544123441", hash: "0xeda425d0ee0dc749b128358a0d35912f4b16921b5afbeac1b5dfddef468560c3", nonce: "22", blockHash: "0xa8aec0096a827a035e1e030d1c6207452853f9bf50f6650d3e1c1179ae497e56", transactionIndex: "0", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "384984", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "354984", gasUsed: "354984", confirmations: "866136"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544123441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "82500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "77500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "72500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0xca807e12e7253102af98a9e524121c64973cf7f2"}, {name: "amount", type: "uint256", value: "68850000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544123441"}, {name: "addr", type: "address", value: "0xd19f788e27d123bdd18c83f074b136105eb1e435"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838612", timeStamp: "1544128216", hash: "0xbf857c67200c93b5c146b4d278c38ae5b675d1896ddce74384ed8b98167b4ec5", nonce: "0", blockHash: "0x08b4be85c333cc5e6768940cea65e31aedb508bb5646a4fd364523b9f6b470fc", transactionIndex: "81", from: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "9950000000000000000", gas: "250523", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0x4e6265555e11452358051fe18464c6fcae035886", contractAddress: "", cumulativeGasUsed: "3343060", gasUsed: "250523", confirmations: "865803"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9950000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1979795000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838619", timeStamp: "1544128328", hash: "0x3270db11ba04d1ab7ce4f8b635fba8d5bf5d2689bc3730f7854b8ec8b51f29de", nonce: "1", blockHash: "0xe89865d43bfc90dd9a42aa4335685aab16916ae82033c936870286808c2be20c", transactionIndex: "68", from: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "9900000000000000000", gas: "350523", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0x4e6265555e11452358051fe18464c6fcae035886", contractAddress: "", cumulativeGasUsed: "6817643", gasUsed: "350523", confirmations: "865796"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9900000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1979795000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838633", timeStamp: "1544128452", hash: "0xd757ddb5f2ca6578ce4646799894551e0df1dede20a69807930934c4ad885e3d", nonce: "2", blockHash: "0xc7ba655cc969ff823397816a2748322d8ee186007111539250a9d869f0b0a6a3", transactionIndex: "56", from: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "9900000000000000000", gas: "350523", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x4e6265555e11452358051fe18464c6fcae035886", contractAddress: "", cumulativeGasUsed: "6362164", gasUsed: "350523", confirmations: "865782"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9900000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1979795000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838664", timeStamp: "1544128849", hash: "0x82d97f3b72608552d51fab7f505efb90351c248fd57c214c3756f28123dc61de", nonce: "3", blockHash: "0x6290cb09f473e9822a0aaad6d15b3bb03b7aa4c7f6293513036f1c7605460f9f", transactionIndex: "105", from: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "9800000000000000000", gas: "350523", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x4e6265555e11452358051fe18464c6fcae035886", contractAddress: "", cumulativeGasUsed: "3845086", gasUsed: "350523", confirmations: "865751"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9800000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1979795000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838673", timeStamp: "1544128943", hash: "0xea95b7c673cbd0d2f23df572c31aa3c171b25da20d4142029a6e5e48dc8fe6bf", nonce: "4", blockHash: "0xfb58c610c43262f17ebdb1ce47494cccbf8363b039194a6a5038921dabfde713", transactionIndex: "13", from: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "9800000000000000000", gas: "350523", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x4e6265555e11452358051fe18464c6fcae035886", contractAddress: "", cumulativeGasUsed: "716397", gasUsed: "350523", confirmations: "865742"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9800000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1979795000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838685", timeStamp: "1544129072", hash: "0xd0c5747895a257931a74d9ad8617bac18bedb33950923e840bb86fbbf8f877ca", nonce: "5", blockHash: "0x8227d526c5b7d4ba6f3d1c43732086265ed0cece0c4c4fa9d73aae83ed4d304c", transactionIndex: "46", from: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "9900000000000000000", gas: "350523", gasPrice: "11000000000", isError: "1", txreceipt_status: "0", input: "0x4e6265555e11452358051fe18464c6fcae035886", contractAddress: "", cumulativeGasUsed: "4655265", gasUsed: "350523", confirmations: "865730"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9900000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1979795000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6838692", timeStamp: "1544129200", hash: "0x03ae2f37ab9db4e3a5c30a109d966829a806a42088b789755a9b0c3c4383281b", nonce: "6", blockHash: "0x29f72b0a8c3ad355d9605eccffbeefd650e5011ed96662de260555ed68de1f50", transactionIndex: "80", from: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "9900000000000000000", gas: "360523", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x4e6265555e11452358051fe18464c6fcae035886", contractAddress: "", cumulativeGasUsed: "5823828", gasUsed: "356261", confirmations: "865723"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "9900000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544129200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1979795000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6844288", timeStamp: "1544209878", hash: "0x6cd4bd5b075e118a7fbec9b6371c92b364bc3f717e9954ae49044c87bfdb6286", nonce: "23", blockHash: "0xeb7fcfc64458528a45aeb52e0e07e87251d9caad87cf1338c67a369fd116cdc1", transactionIndex: "147", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "175208", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3909067", gasUsed: "175208", confirmations: "860127"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6844296", timeStamp: "1544209975", hash: "0xfb53991e19f47ca7133c70dd8722052454cc2e682fee50459344dc9e7e2d3639", nonce: "24", blockHash: "0xa945f5ff832090c45295baa65c34144d570c7402f3b78c04324f4b6c88e9ab22", transactionIndex: "1", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "400678", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "544434", gasUsed: "370678", confirmations: "860119"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544209975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "87500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "82500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "77500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0xca807e12e7253102af98a9e524121c64973cf7f2"}, {name: "amount", type: "uint256", value: "73950000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0xd19f788e27d123bdd18c83f074b136105eb1e435"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544209975"}, {name: "addr", type: "address", value: "0x4e6265555e11452358051fe18464c6fcae035886"}, {name: "amount", type: "uint256", value: "67500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6850465", timeStamp: "1544298121", hash: "0x313a21e1f5a51e79ca655df3f8b281a8154ca0c0f4853c63b8fe6fffc3293728", nonce: "25", blockHash: "0xc22b152fc4692a3133ef69d6e1184722f021265f8ad5a3cb11537364d7f02b53", transactionIndex: "99", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "300000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "6354572", gasUsed: "300000", confirmations: "853950"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6850493", timeStamp: "1544298485", hash: "0x8de6562222049dbdc730c04ccdd3be173e7792a247997745c15b4e1db726f27e", nonce: "26", blockHash: "0xcdd3e25c741839d24f9f0cfc6784bd0182b960b86b5303fa40bd2a0de05f5a69", transactionIndex: "36", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "300000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "4368448", gasUsed: "300000", confirmations: "853922"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6850792", timeStamp: "1544302749", hash: "0x4a5eec120e59cb5e9816f08069f5278046a5761a9f976068ef62a3645857fdb8", nonce: "27", blockHash: "0x568bc1f87c6956e44d52d5fa5b3d12467232b1010a2bbb545b773b7187dbc44c", transactionIndex: "21", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "900000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7171158", gasUsed: "423225", confirmations: "853623"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544302749 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "87500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "82500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "77500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0xca807e12e7253102af98a9e524121c64973cf7f2"}, {name: "amount", type: "uint256", value: "73950000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0xd19f788e27d123bdd18c83f074b136105eb1e435"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0x4e6265555e11452358051fe18464c6fcae035886"}, {name: "amount", type: "uint256", value: "67500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544302749"}, {name: "addr", type: "address", value: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87"}, {name: "amount", type: "uint256", value: "247500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6856390", timeStamp: "1544382912", hash: "0x024e4304eb4bf98b8841181bc038c58a4a744091ddf7d349bcd5c8f0fe87dc2b", nonce: "28", blockHash: "0x55093d5fa69168b294f4c2322e029865b4dc7407ab9950e2b40ade9e0865c107", transactionIndex: "17", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "137646", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "528315", gasUsed: "137646", confirmations: "848025"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544382912 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6856846", timeStamp: "1544389183", hash: "0x144b5bb87cbb562e99c3807c7ecff21672ffaa77f3063d2ced4f436a9e79d734", nonce: "29", blockHash: "0x8de189a836b52135c3c4b3123ce0d490e674c1168bf0ddfcfa054de573fd4ac6", transactionIndex: "1", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "137646", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "175251", gasUsed: "137646", confirmations: "847569"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6856848", timeStamp: "1544389217", hash: "0x071b3b82759f049eb6acd2d76fa9dffb0338367e23ab8841f3b75a531ec81ed9", nonce: "30", blockHash: "0xb80a64bacca037acb276907ccc7ef91e56b688cdf2b916ccc5fc8e012301311a", transactionIndex: "22", from: "0xba9e1eddbfb265bf2992b28cf03355372be7162e", to: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7", value: "0", gas: "408225", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1178769", gasUsed: "408225", confirmations: "847567"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544389217 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "date", type: "uint256"}, {indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "eventType", type: "string"}], name: "payout", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0xdbaebac531f4e345b1d66af84498377d9781f26b"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0xa095d48e805f165a1b8351cf5db90c7be12c21df"}, {name: "amount", type: "uint256", value: "3750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0x524c277e9774d31b0fd5a4b7ebcb4c1bc6effca2"}, {name: "amount", type: "uint256", value: "87500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0x06d867bcf29f2e03d93d0b153f85dfc802ca8f46"}, {name: "amount", type: "uint256", value: "82500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0x542c30d3f83f1145d31426102e6e7953ba6c626b"}, {name: "amount", type: "uint256", value: "37500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0xd6411da97bf67fad0ea6e9aa1a88d42faab06849"}, {name: "amount", type: "uint256", value: "77500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0x49be3a14a839ff03af6e4a1572f13afc3844ede9"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0xe45d46c1d1aa5bcbf1258e5e7fcd6a5e8b7483e8"}, {name: "amount", type: "uint256", value: "8737500000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0xca807e12e7253102af98a9e524121c64973cf7f2"}, {name: "amount", type: "uint256", value: "73950000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0xd19f788e27d123bdd18c83f074b136105eb1e435"}, {name: "amount", type: "uint256", value: "62500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0x4e6265555e11452358051fe18464c6fcae035886"}, {name: "amount", type: "uint256", value: "67500000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}, {name: "payout", events: [{name: "date", type: "uint256", value: "1544389217"}, {name: "addr", type: "address", value: "0x016d9f8c1c25a04370e9f6b89ca2e57c3a8ecd87"}, {name: "amount", type: "uint256", value: "123750000000000000"}, {name: "eventType", type: "string", value: "Interest payment"}], address: "0xcb5f8bb5c11b1fd20decff442ffa2e48fd792be7"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5584636000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "222035937500000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
