const HamsterWars = artifacts.require( "./HamsterWars.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "HamsterWars" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xb80ECaF2236e3A8e28FB736651C51cCdF25E2D7B", "0x9dD3D639deA2e74A89220c3f80ED20549F27984d", "0xc951D3463EbBa4e9Ec8dDfe1f42bc5895C46eC8f", "0xDECADE71c62Ed0775e2831448A49586025e462B2", "0xF4e5e695D1c7285CAD1EFb9830A4fd18302A6Bf3", "0xb03bEF1D9659363a9357aB29a05941491AcCb4eC", "0x41a21b264F9ebF6cF571D4543a5b3AB1c6bEd98C", "0x081Fdc110B8AD4834289AbA38c8293Ff68e85dd4", "0x95096780Efd48FA66483Bc197677e89f37Ca0CB5", "0x7dE2f46f4DafEbc223926e97a2b7D238B764A16a"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_ethereumToSpend", type: "uint256"}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokensToSell", type: "uint256"}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_includeReferralBonus", type: "bool"}], name: "myDividends", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onTokenPurchase(address,uint256,uint256,address,uint256,uint256)", "onTokenSell(address,uint256,uint256,uint256,uint256)", "onReinvestment(address,uint256,uint256)", "onWithdraw(address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8032875b28d82ddbd303a9e4e5529d047a14ecb6290f80012a81b7e6227ff1ab", "0x8d3a0130073dbd54ab6ac632c05946df540553d3b514c9f8165b4ab7f2b1805e", "0xbe339fc14b041c2b0e0f3dd2cd325d0c3668b78378001e53160eab3615326458", "0xccad973dcd043c7d680389db4378bd6b9775db7124092e9e0422c9e46d7985dc", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6691709 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6693175 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "HamsterWars", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dividendsOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_ethereumToSpend", value: random.range( maxRandom )}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateTokensReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokensToSell", value: random.range( maxRandom )}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateEthereumReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sellPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stakingRequirement()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bool", name: "_includeReferralBonus", value: ( random.range( 2 ) === 0 )}], name: "myDividends", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myDividends(bool)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalEthereumBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "HamsterWars", function( accounts ) {

	it( "TEST: HamsterWars(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6691709", timeStamp: "1542040003", hash: "0x3557cf648c79976a1755c11157b666083ebef835522b1c39ad8c57a05321d717", nonce: "0", blockHash: "0x4dc7a8b4563f2b2e9b9175d1aa7e181878f3901c09534d53a64c890347453f19", transactionIndex: "102", from: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d", to: 0, value: "0", gas: "1179993", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x13dd5707", contractAddress: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", cumulativeGasUsed: "4300248", gasUsed: "1179993", confirmations: "1024311"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "HamsterWars", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = HamsterWars.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542040003 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = HamsterWars.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "895548" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691719", timeStamp: "1542040168", hash: "0x2f82f8f5701ccad286585ecd42b9c52a9172c6803f8c1553fa6b89852727fb9f", nonce: "7957", blockHash: "0x4bdd4821eaace39a675f94cbc907787918c3a8ac8529a62ee1bbdb7085900df8", transactionIndex: "2", from: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "100000000000000000", gas: "152233", gasPrice: "23000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "174141", gasUsed: "101489", confirmations: "1024301"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542040168 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "4357899058248538978203"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040168"}, {name: "price", type: "uint256", value: "45738000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "333456065115059910" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691720", timeStamp: "1542040183", hash: "0xa8aaf0009e0374a419d33f0e90a17aa912fff3e270b9d4af97b1a443501ebf98", nonce: "23", blockHash: "0xc1dc9425ce324f814cfe7aac487701a27c75a01124616ecafa330ca341364d3d", transactionIndex: "2", from: "0xdecade71c62ed0775e2831448a49586025e462b2", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "100000000000000000", gas: "600000", gasPrice: "69000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "170881", gasUsed: "92321", confirmations: "1024300"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542040183 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xdecade71c62ed0775e2831448a49586025e462b2"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1805515025831147503804"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040183"}, {name: "price", type: "uint256", value: "64701000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "7101028036952429" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691720", timeStamp: "1542040183", hash: "0xaeb9cb9e28ee1b6761c55578a485dc463dd9015622e39ddcf8bbb88f9d0652bf", nonce: "1", blockHash: "0xc1dc9425ce324f814cfe7aac487701a27c75a01124616ecafa330ca341364d3d", transactionIndex: "56", from: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "50000000000000000", gas: "152052", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2339821", gasUsed: "92321", confirmations: "1024300"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542040183 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "incomingEthereum", type: "uint256", value: "50000000000000000"}, {name: "tokensMinted", type: "uint256", value: "727610364513049031141"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040183"}, {name: "price", type: "uint256", value: "72345000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "895548" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691724", timeStamp: "1542040208", hash: "0x4363c23ec819cb2416191e1f38105f8b2c945dd3aaf0052e768c24df6cdf91d1", nonce: "80", blockHash: "0x614abbd81163cce00e8ce26b4d9f02160c4ff17b1f653c14743d05e0a20d5323", transactionIndex: "121", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "100000000000000000", gas: "250000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3913709", gasUsed: "92442", confirmations: "1024296"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542040208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1262728827871243442906"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040208"}, {name: "price", type: "uint256", value: "85596000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26949159782585170" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6691736", timeStamp: "1542040377", hash: "0xeb8c1efaa6535b5c491d5ff87195fbce9af56b8412bda582ea93b88bdcd35ddf", nonce: "2", blockHash: "0xcbc95b90722b5d9ff35e5f2481448bed6fba0b1a03d75e7988fce6c464baf04b", transactionIndex: "80", from: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "116823", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "4229705", gasUsed: "77882", confirmations: "1024284"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542040377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "incomingEthereum", type: "uint256", value: "710151566655072"}, {name: "tokensMinted", type: "uint256", value: "8268823081290791516"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040377"}, {name: "price", type: "uint256", value: "85690500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "ethereumReinvested", type: "uint256", value: "710151566655072"}, {name: "tokensMinted", type: "uint256", value: "8268823081290791516"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "895548" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691739", timeStamp: "1542040398", hash: "0xa2bdb6b17319bc23df7411b52230a488c97a526f2bf0f8eb79b8b1e89c3a96b2", nonce: "5877", blockHash: "0xbc3a984f64eb90ec8d8ff9cb43560b409a9e88993f2b6960c3dd737b3ca9aa98", transactionIndex: "5", from: "0xb03bef1d9659363a9357ab29a05941491accb4ec", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "1000000000000000000", gas: "21000", gasPrice: "45000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "290678", gasUsed: "21000", confirmations: "1024281"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "4315328126289636616" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691751", timeStamp: "1542040461", hash: "0x4a417a92714a5b07d131ab79868a2cbd6df9480bd183b2e4b1f0e43f6a8ddff6", nonce: "5878", blockHash: "0xc558f3843f3cb06f9374e7a716f8b5951f404125267650aa29dd651f45afd235", transactionIndex: "15", from: "0xb03bef1d9659363a9357ab29a05941491accb4ec", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "100000000000000000", gas: "138663", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "859704", gasUsed: "92442", confirmations: "1024269"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542040461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb03bef1d9659363a9357ab29a05941491accb4ec"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1090892196452098295050"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040461"}, {name: "price", type: "uint256", value: "97135500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "4315328126289636616" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691759", timeStamp: "1542040568", hash: "0x7bc51b0f1b18ad5f9c71622d5b5f87874d4a0fad096e9e0000a26f2d71f1a491", nonce: "913", blockHash: "0x27463288f622cf0451227fa6ef2031b6ce74d0adff2c0c93e135489aaba74be0", transactionIndex: "28", from: "0x41a21b264f9ebf6cf571d4543a5b3ab1c6bed98c", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "200000000000000000", gas: "138663", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1399848", gasUsed: "92442", confirmations: "1024261"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542040568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x41a21b264f9ebf6cf571d4543a5b3ab1c6bed98c"}, {name: "incomingEthereum", type: "uint256", value: "200000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1865210210800119194515"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040568"}, {name: "price", type: "uint256", value: "116728500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1285635044499661630" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6691761", timeStamp: "1542040609", hash: "0x23ab81b8a8485d4b54405d3d3457b7aaf0d3719dcb65fc5e0da68811be834d89", nonce: "139", blockHash: "0x2819f1c8b0d236375fdf749344467a282e3aba9e3d35465dcf864b765ff88192", transactionIndex: "159", from: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "100000000000000000", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7405012", gasUsed: "92442", confirmations: "1024259"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542040609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "823862129620744299424"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542040609"}, {name: "price", type: "uint256", value: "125370000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "193183928835213363" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6691780", timeStamp: "1542040876", hash: "0x5203fb291e0bac76b7c36b957a1a19ad91a434d34306975df627e6a15b09b5b6", nonce: "5879", blockHash: "0x4cc420f0e4e85e865c6eebb21804333bcfe6f6c578ac03ae0818c82c3e840616", transactionIndex: "18", from: "0xb03bef1d9659363a9357ab29a05941491accb4ec", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "621361", gasUsed: "43481", confirmations: "1024240"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1542040876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xb03bef1d9659363a9357ab29a05941491accb4ec"}, {name: "ethereumWithdrawn", type: "uint256", value: "2027415914995877"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "4315328126289636616" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6691787", timeStamp: "1542040940", hash: "0xf464a9972b428d59536dd74d3ce48b9e0236390aee6ce01928d5d54b972ac4fa", nonce: "24", blockHash: "0x287f0dce251ea54c100ce3f103cd72a72c868498679f97a0b9e0b06349311d69", transactionIndex: "14", from: "0xdecade71c62ed0775e2831448a49586025e462b2", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "600000", gasPrice: "42000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "2023445", gasUsed: "600000", confirmations: "1024233"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "7101028036952429" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6691787", timeStamp: "1542040940", hash: "0x9d5957ef3ab74829f821dde9996aa22b9902286566d91ea40e129da69072bb93", nonce: "82", blockHash: "0x287f0dce251ea54c100ce3f103cd72a72c868498679f97a0b9e0b06349311d69", transactionIndex: "65", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "250000", gasPrice: "14000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "7034952", gasUsed: "250000", confirmations: "1024233"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26949159782585170" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6691792", timeStamp: "1542040994", hash: "0x709e8ed80d4367e5255f83a81fd91ccc79683a75f083e12609a3a992ace96ce1", nonce: "83", blockHash: "0x2f800f2dd0c818169cb42ed3a46987793e6ef25f482e4643a802c0a7d0cbb9af", transactionIndex: "23", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "350000", gasPrice: "14000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "1010640", gasUsed: "350000", confirmations: "1024228"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26949159782585170" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6691794", timeStamp: "1542041012", hash: "0xc36d88ea2cb749a7556a5c71717c466010dc8110e6f27d12b32d903b3be6dba3", nonce: "140", blockHash: "0x1b369e494e495a14a76af75b99b80a3aa4a3932b1ac14088e18fc5933118fcb8", transactionIndex: "141", from: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "150000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "7264457", gasUsed: "150000", confirmations: "1024226"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "193183928835213363" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6691797", timeStamp: "1542041100", hash: "0x5be79b2c106161686fac7ce12f8ee0b26db2d34e8e5de63ff43edb5f6477f8ea", nonce: "84", blockHash: "0xa00737c0e2884f96638ec7ac57f9c59a948e94128af2486602486d1c605ecdac", transactionIndex: "133", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "250000", gasPrice: "13000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "7601350", gasUsed: "250000", confirmations: "1024223"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26949159782585170" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6691798", timeStamp: "1542041104", hash: "0xb7c9b0131f89cee73b6db0c4b38070c7c142bda5b2fe534d418cf12a308b3a1b", nonce: "141", blockHash: "0xbaa60bf4aa8da213ffd5f3ba629da59b9f79fc82f19aeae3ceda785dafd3e761", transactionIndex: "53", from: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4840234", gasUsed: "43481", confirmations: "1024222"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542041104 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4"}, {name: "ethereumWithdrawn", type: "uint256", value: "344943498390897"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "193183928835213363" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6691800", timeStamp: "1542041127", hash: "0x5c298cf7081c7b421a05275bb3fc7ca743252a8da17d96f2cff45f5947fba454", nonce: "3", blockHash: "0xf7e1766412a54bff290f4f4d614fe5cd6da6165d66745d889f3ba2c4e8fa9385", transactionIndex: "79", from: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7080239", gasUsed: "43481", confirmations: "1024220"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542041127 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "ethereumWithdrawn", type: "uint256", value: "1370827916911826"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "895548" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6691805", timeStamp: "1542041202", hash: "0xbffbf34fbce474bf8fdce3bc5b3e33cfd6ed892f4c3df07b024ffa501c81d159", nonce: "85", blockHash: "0xe99973dbdc266dc1ecdf06c3973cb8394e55933ea40e7a79c0977c1df2d55c9d", transactionIndex: "61", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "250000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2262770", gasUsed: "43481", confirmations: "1024215"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542041202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "3126590123428273"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26949159782585170" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6691827", timeStamp: "1542041612", hash: "0x508c216db5967b758c6b188dec6390c6d2e464e473748c5b6d485f59f9e948c8", nonce: "86", blockHash: "0x421634e30eb0bec2c0545edca107fb973ae4ef01de6cde543d9b1f9c7dcaf515", transactionIndex: "104", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "6313820", gasUsed: "22846", confirmations: "1024193"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542041612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26949159782585170" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6691977", timeStamp: "1542043637", hash: "0x2f28417b820fbc832185809ac29efaa1d9632e2f8d28303400a2df30f1e37e5d", nonce: "914", blockHash: "0x0408416f74324f813a97e740f3938accaaedd4e1ba87b07b90e72cbaf491c57a", transactionIndex: "47", from: "0x41a21b264f9ebf6cf571d4543a5b3ab1c6bed98c", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3536718", gasUsed: "43481", confirmations: "1024043"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542043637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x41a21b264f9ebf6cf571d4543a5b3ab1c6bed98c"}, {name: "ethereumWithdrawn", type: "uint256", value: "2458576625036011"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1285635044499661630" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6692011", timeStamp: "1542044121", hash: "0xe08ab4e97ea700298493b4dfa3d6abf2ea08128c6eaaabd1389efd54d2b26df6", nonce: "7963", blockHash: "0x897d3ca9acdab5c6c295b6eb539ee9349157ce3a41dd1e6a4ead4ce374f83466", transactionIndex: "55", from: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "10100000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3855801", gasUsed: "43481", confirmations: "1024009"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542044121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f"}, {name: "ethereumWithdrawn", type: "uint256", value: "20906713746541124"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "333456065115059910" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6692154", timeStamp: "1542045925", hash: "0x474f7701adcfdb7a9351a3ac957f4f32d1d121cff512102aed73ef674c0cd1b9", nonce: "1753", blockHash: "0xf9d0d833378e8d0898ddee6abad9880bc34dd5ae0fcab3d46511e16269da3c4e", transactionIndex: "17", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "150000000000000000", gas: "140157", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1604343", gasUsed: "93438", confirmations: "1023866"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542045925 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "incomingEthereum", type: "uint256", value: "150000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1138868346636138945026"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1542045925"}, {name: "price", type: "uint256", value: "137329500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"1138\" )", async function( ) {
		const txOriginal = {blockNumber: "6692212", timeStamp: "1542046802", hash: "0xc305c3d5a5ee94e51642d08eb15a7f9160967b2990ff6566e90b4b730e44a6b3", nonce: "1755", blockHash: "0x25058a2c9ec4b6efde48043692577e18d9ee0544128b6e620f5c08ae4008e194", transactionIndex: "18", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "30000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b320000000000000000000000000000000000000000000000000000000000000472", contractAddress: "", cumulativeGasUsed: "1314239", gasUsed: "30000", confirmations: "1023808"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "1138"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"1138\" )", async function( ) {
		const txOriginal = {blockNumber: "6692220", timeStamp: "1542046895", hash: "0x78e274fa51e0cb709c94f522304cece5fa5fa1660d3c6ac0d426c97a2b4e395c", nonce: "1756", blockHash: "0xc37e80b51aa9674134d165e38c9682ffb82f0d1a32dfada66ace19fc5738de55", transactionIndex: "0", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "30000", gasPrice: "80000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b320000000000000000000000000000000000000000000000000000000000000472", contractAddress: "", cumulativeGasUsed: "30000", gasUsed: "30000", confirmations: "1023800"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "1138"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"1138750000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692263", timeStamp: "1542047565", hash: "0x2e7886f8626b359ae2a751d365198fe59e74dbc1fe30c4424bad7f22e61ec335", nonce: "1757", blockHash: "0x4984e9323202b541dbcdc39dc3eed8830b2f88f4ae124da399455767e12da61e", transactionIndex: "0", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "7600027", gasPrice: "4300000000", isError: "1", txreceipt_status: "0", input: "0xe4849b3200000000000000000000000000000000000000000000003dbb54b3a4d8130000", contractAddress: "", cumulativeGasUsed: "7600027", gasUsed: "7600027", confirmations: "1023757"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "1138750000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6692263", timeStamp: "1542047565", hash: "0xe8ee9903ea637f721b837d3008cb6e8e3bf2cbdce0f391100b77277a37313c97", nonce: "1758", blockHash: "0x4984e9323202b541dbcdc39dc3eed8830b2f88f4ae124da399455767e12da61e", transactionIndex: "1", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "30000", gasPrice: "50000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "7630027", gasUsed: "30000", confirmations: "1023757"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6692374", timeStamp: "1542049096", hash: "0xc869d6ae15140c875f53868824f0d0cbb0f91d2d994127d6e33baa15196874e2", nonce: "1760", blockHash: "0x9436d869f0c78a41f35f62228e56485fd69860d473af57401858374e08ee94b8", transactionIndex: "53", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3814702", gasUsed: "43481", confirmations: "1023646"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542049096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "ethereumWithdrawn", type: "uint256", value: "652978158601663"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"500000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692410", timeStamp: "1542049710", hash: "0x1b589d41a03dfaf9bc4f411b69e4d0d55a45ce64899443a33a6443bddb6d246c", nonce: "1761", blockHash: "0xf4cf3588a165cdf8964cffcd4276981f1e514f18a70f711c4a08650cafb67f1b", transactionIndex: "21", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "131005", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b3200000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "1150146", gasUsed: "87337", confirmations: "1023610"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "500000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542049710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "tokensBurned", type: "uint256", value: "500000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "58994995400000000"}, {name: "timestamp", type: "uint256", value: "1542049710"}, {name: "price", type: "uint256", value: "132027000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "495000000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"50000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692416", timeStamp: "1542049798", hash: "0x24762db542b0384dae70c52e19d8457b7bdf61f8d063c034005d5df6597963c0", nonce: "1762", blockHash: "0x96901d58f4b2ee0f5a4ec2f49a97f5e981e01f7e1a246c4c82b36bd799925d02", transactionIndex: "22", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "163951", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b32000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "4113452", gasUsed: "109301", confirmations: "1023604"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "50000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542049798 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "tokensBurned", type: "uint256", value: "50000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "5772995400000000"}, {name: "timestamp", type: "uint256", value: "1542049798"}, {name: "price", type: "uint256", value: "131502000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "ethereumWithdrawn", type: "uint256", value: "59083590395263604"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "49500000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6692418", timeStamp: "1542049887", hash: "0x1ecdc447e31fe9dde17772814db086aa70cf4ba8536985e9e4e19097338246d1", nonce: "1763", blockHash: "0x9ecf56886a246d90d9ca2519c9f529b9ad04bd8d73bdde66e9537332cc55da1b", transactionIndex: "83", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3559654", gasUsed: "43481", confirmations: "1023602"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542049887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "ethereumWithdrawn", type: "uint256", value: "5774997476756655"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "489974187600253" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6692439", timeStamp: "1542050147", hash: "0x64403c4055a26799c128230bb1aae0e409848236c44d56ef1d9815db59f873b9", nonce: "92", blockHash: "0x75a0d9dcbeab4d8cf73a2a7fff92f894051a365b5796fe90fafe106ed45b7e27", transactionIndex: "33", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4954297", gasUsed: "43481", confirmations: "1023581"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542050147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "1359157719875543"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26880411782585170" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"823000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692491", timeStamp: "1542050958", hash: "0x983bf02519a0b84b15ed3b6440630735de72ebcdc8ab089758d10e9fe1715035", nonce: "145", blockHash: "0xe10a898e6b84e18f9ab97055939f66431ac47f8ff0acef92b49c40759dcb52a2", transactionIndex: "66", from: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "100000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b3200000000000000000000000000000000000000000000002c9d6b5b8f227c0000", contractAddress: "", cumulativeGasUsed: "2874784", gasUsed: "100000", confirmations: "1023529"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "823000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "193183928835213363" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6692498", timeStamp: "1542051058", hash: "0x336b0a48d4cb11ceaedff79106e94bebf91623ceb8adf00a4e043d3b0fef7b89", nonce: "93", blockHash: "0x940108b99fb25a024b13d7f8013ebe7012f2139a908ad9d58676605d66f03114", transactionIndex: "65", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "152052", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "4150526", gasUsed: "152052", confirmations: "1023522"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "26880411782585170" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6692499", timeStamp: "1542051062", hash: "0x70f26bb8c94edc0747fa40b7f17aae9636a445beb7f58196ea4ad989f95db7aa", nonce: "146", blockHash: "0x54bdae816c564f3ffaf700d11fde94e70672e76f406198a27baecc4be0652c69", transactionIndex: "96", from: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7067666", gasUsed: "43481", confirmations: "1023521"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542051062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0x081fdc110b8ad4834289aba38c8293ff68e85dd4"}, {name: "ethereumWithdrawn", type: "uint256", value: "886776755920645"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "193183928835213363" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"250000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692790", timeStamp: "1542055016", hash: "0xe6afc2047c7f05ff17276bb16e4037bc2f93a38c36457c9da7e18290df2d101b", nonce: "94", blockHash: "0xd587a5c23e83c59eec9a6c666bda4e1052866055606ea1daad710d09fbd55a72", transactionIndex: "13", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "100000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b3200000000000000000000000000000000000000000000000d8d726b7177a80000", contractAddress: "", cumulativeGasUsed: "682651", gasUsed: "87337", confirmations: "1023230"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "250000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "250000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542055016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "tokensBurned", type: "uint256", value: "250000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "28513095400000000"}, {name: "timestamp", type: "uint256", value: "1542055016"}, {name: "price", type: "uint256", value: "128845500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "247500000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"218000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692839", timeStamp: "1542055664", hash: "0x9c15d9c83752e7dd45f754b5643262fbeb42628e1d5b9bf07b1d5ec08a0d507f", nonce: "95", blockHash: "0xa294175576d36bbc786e04c2bb5f6091f8ac120b555354cf49e31a512be3ee45", transactionIndex: "76", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "100000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b3200000000000000000000000000000000000000000000000bd15b94fc8b280000", contractAddress: "", cumulativeGasUsed: "2723519", gasUsed: "100000", confirmations: "1023181"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "218000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692854", timeStamp: "1542055813", hash: "0x8b07aa55ab2cd526e37b4e8eb79d95194dfd348f896f8175cf0c9ffa8a9128e1", nonce: "96", blockHash: "0xffab2411a4fc209b0de84485de75ba63d7acc772ede1b833db86a63e8b1abe1a", transactionIndex: "38", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "150000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b320000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "2375805", gasUsed: "109237", confirmations: "1023166"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "5000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542055813 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "tokensBurned", type: "uint256", value: "5000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "564392400000000"}, {name: "timestamp", type: "uint256", value: "1542055813"}, {name: "price", type: "uint256", value: "128793000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "28692503830240188"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "4950000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"100000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692862", timeStamp: "1542055925", hash: "0x1955f569d2cb2469c222bfb5ea53b1d4e1b07eb597de4546398355aba160d33a", nonce: "97", blockHash: "0x47132b9d0b6b775859f98f24350834b1f8b720b0da15909ad76661466b58adaa", transactionIndex: "28", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "150000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b320000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "1916267", gasUsed: "109301", confirmations: "1023158"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "100000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542055925 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "tokensBurned", type: "uint256", value: "100000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "11238715400000000"}, {name: "timestamp", type: "uint256", value: "1542055925"}, {name: "price", type: "uint256", value: "127732500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "567782236869854"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "99000000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692867", timeStamp: "1542056022", hash: "0xe60dcf3058a4bd51b61f05e681213d2fd213f583e5e4e7245371987c934e8c9b", nonce: "98", blockHash: "0x20e67e0456b6aa983b0111951b0a6d309c1e92c236fc88121a1b9a71f78d70fc", transactionIndex: "21", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "150000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b320000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "1628868", gasUsed: "109237", confirmations: "1023153"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "5000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542056022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "tokensBurned", type: "uint256", value: "5000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "559516400000000"}, {name: "timestamp", type: "uint256", value: "1542056022"}, {name: "price", type: "uint256", value: "127680000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "11289639339415955"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "4950000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692887", timeStamp: "1542056281", hash: "0x33027a7b47ab1a879a8eca71a6470b5b5298925d3328d0ae707fa61dc2fa5c60", nonce: "99", blockHash: "0x167e665b7e45f7c059ee5bbdb713f14d745b5c5f7c9bd1d216cd4eaa7bd4b0c9", transactionIndex: "92", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "150000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b320000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "5012332", gasUsed: "109237", confirmations: "1023133"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "5000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542056281 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "tokensBurned", type: "uint256", value: "5000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "559286400000000"}, {name: "timestamp", type: "uint256", value: "1542056281"}, {name: "price", type: "uint256", value: "127627500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "561961230717373"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "4950000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"50000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692899", timeStamp: "1542056427", hash: "0x457ff4a5cba2c67d1727e4f9d27934412b0f2e3ee31e1ce90e9609da23ab3e36", nonce: "100", blockHash: "0x7fb291bb537724fe0ee20bf1155d517f4dcb466eb3ac9aa0e886ca4fd4875a44", transactionIndex: "17", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "150000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe4849b32000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "1496368", gasUsed: "109301", confirmations: "1023121"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "50000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sell(uint256)" ]( "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542056427 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTokenSell", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "tokensBurned", type: "uint256", value: "50000000000000000000"}, {name: "ethereumEarned", type: "uint256", value: "5580255400000000"}, {name: "timestamp", type: "uint256", value: "1542056427"}, {name: "price", type: "uint256", value: "127102500000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "561686239627564"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "to", type: "address", value: "0x9dd3d639dea2e74a89220c3f80ed20549f27984d"}, {name: "tokens", type: "uint256", value: "49500000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"2000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692924", timeStamp: "1542056743", hash: "0x28793bb5326bab35b946484c30dc26522d829c2a514f17ae6ec9e7b539744a06", nonce: "101", blockHash: "0x28306bb3061469673532274c59a98e65d012a290bcac9b7ff1ca21b00997d860", transactionIndex: "60", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b320000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "3801507", gasUsed: "66319", confirmations: "1023096"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "2000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"218000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6692995", timeStamp: "1542057578", hash: "0x98767603e80e9fbba1b6b5e2ea5aa2a937da458973f2567676923be5dc2f5987", nonce: "102", blockHash: "0xa0842835dc4bcdff68f13771ef390ea7c78e76ab52a68dd06483f87078360c46", transactionIndex: "15", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b3200000000000000000000000000000000000000000000000bd15b94fc8b280000", contractAddress: "", cumulativeGasUsed: "944198", gasUsed: "66319", confirmations: "1023025"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "218000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6693024", timeStamp: "1542057972", hash: "0x9d5c382dd6c1798696deceb3a438aa7757aa215a2d2377f2b2cdf2054a34465d", nonce: "103", blockHash: "0xe49e6946388401538b57c825e34bdf0dc4515fbbc8ccc22e6edf66c6b536c660", transactionIndex: "70", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b320000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "3001917", gasUsed: "66319", confirmations: "1022996"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "5000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"432000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6693037", timeStamp: "1542058138", hash: "0xeb910d0618fa422d219ade6743df3b39d2f69da722836ff93b10d228e3416d02", nonce: "104", blockHash: "0xf6a0ea4e8d3a7bf8f41ccf6a5923854c71688a5bd5af68cf617afeab2e4bdf90", transactionIndex: "48", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b320000000000000000000000000000000000000000000000176b344f2a78c00000", contractAddress: "", cumulativeGasUsed: "2875605", gasUsed: "66319", confirmations: "1022983"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "432000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sell( \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6693060", timeStamp: "1542058389", hash: "0x34367576d0eb02d20cb61cbcd7ce42c377178535d5206d79ef99ad1524f6fc06", nonce: "105", blockHash: "0xce7491b88020cf1afd03ba9f2b66cc588e99820cb12b9c52d37bbb76f6443aee", transactionIndex: "36", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "66319", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe4849b320000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "3112637", gasUsed: "66319", confirmations: "1022960"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_amountOfTokens", value: "5000000000000000000"}], name: "sell", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: exit(  )", async function( ) {
		const txOriginal = {blockNumber: "6693068", timeStamp: "1542058477", hash: "0x67cc7bc95b7eccabbd241f4dc7ace78b4867718a7d643d3ad168daeb275c8dd6", nonce: "106", blockHash: "0xfc69e2bdeb696e870de450e1773d5d3b37882f27f751452c1f0b649b71c4be8f", transactionIndex: "51", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "120000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe9fad8ee", contractAddress: "", cumulativeGasUsed: "1674575", gasUsed: "120000", confirmations: "1022952"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "exit", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6693078", timeStamp: "1542058561", hash: "0xef1386ac11a5a1aae965e6b6558d2b86a704639cd303b1ff7ff149ebe3263daa", nonce: "107", blockHash: "0xaef200e8ccf29af36821c1773cadb9360dde8cabefbb2406cbf22167ccd7a80c", transactionIndex: "38", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "120000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1367165", gasUsed: "43481", confirmations: "1022942"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542058561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "customerAddress", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "ethereumWithdrawn", type: "uint256", value: "5600013345369311"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6693175", timeStamp: "1542059950", hash: "0x398dd59626a4a0e74972ba3979cc7b7ae4802d5cd23e5ac8265026036d85f538", nonce: "108", blockHash: "0x191faa7cdd94314809a7a7bbfac81dae212c1ea245a0fde7c3e1806892be2cc4", transactionIndex: "27", from: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3", to: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b", value: "0", gas: "120000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000007de2f46f4dafebc223926e97a2b7d238b764a16a0000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "1057227", gasUsed: "91590", confirmations: "1022845"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_toAddress", value: addressList[11]}, {type: "uint256", name: "_amountOfTokens", value: "100000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542059950 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4e5e695d1c7285cad1efb9830a4fd18302a6bf3"}, {name: "to", type: "address", value: "0x7de2f46f4dafebc223926e97a2b7d238b764a16a"}, {name: "tokens", type: "uint256", value: "99000000000000000000"}], address: "0xb80ecaf2236e3a8e28fb736651c51ccdf25e2d7b"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "188939948518335673" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "754728030844113438" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
