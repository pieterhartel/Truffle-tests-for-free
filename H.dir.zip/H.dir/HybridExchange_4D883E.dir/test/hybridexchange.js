const HybridExchange = artifacts.require( "./HybridExchange.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "HybridExchange" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x2cB4B49C0d6E9db2164d94Ce48853BF77C4D883E", "0x967A2d1D753B1c21011b395caAC96274f142b01F", "0x74622073a4821dbfd046E9AA2ccF691341A076e1", "0x9AF839687F6C94542ac5ece2e317dAAE355493A1", "0x49497a4D914ae91D34Ce80030fE620687Bf333FD", "0xB15367Df8A39ea06f8F81ED35D49e056eE05f3b7"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "proxyAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "filled", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "cancelled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "relayerDelegates", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "DOMAIN_SEPARATOR", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "discountConfig", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "relayer", type: "address"}], name: "canMatchOrdersFrom", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "user", type: "address"}], name: "getDiscountedRate", outputs: [{name: "result", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EIP712_ORDER_TYPE", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "FEE_RATE_BASE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "DISCOUNT_RATE_BASE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "relayer", type: "address"}], name: "isParticipant", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EIP712_DOMAIN_TYPEHASH", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "hotTokenAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "orderHash", type: "bytes32"}], name: "Cancel", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "relayer", type: "address"}, {indexed: true, name: "delegate", type: "address"}], name: "RelayerApproveDelegate", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "relayer", type: "address"}, {indexed: true, name: "delegate", type: "address"}], name: "RelayerRevokeDelegate", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "relayer", type: "address"}], name: "RelayerExit", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "relayer", type: "address"}], name: "RelayerJoin", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Cancel(bytes32)", "Match(address,address,address,address,address,uint256,uint256,uint256,uint256,uint256,uint256,uint256)", "OwnershipTransferred(address,address)", "RelayerApproveDelegate(address,address)", "RelayerRevokeDelegate(address,address)", "RelayerExit(address)", "RelayerJoin(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xe8d9861dbc9c663ed3accd261bbe2fe01e0d3d9e5f51fa38523b265c7757a93a", "0xdcc6682c66bde605a9e21caeb0cb8f1f6fbd5bbfb2250c3b8d1f43bb9b06df3f", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0x7fa92f6e23fcdb0b7a7001ea137560a8ebee9b8302d16e3b37c64ae7116b69ad", "0xa6568d7ca1ae4c87043ca12f90308b8ef94330ee3a047c2101e1a40812d26c98", "0x9bdfcd96a99ab6dad403b4ef4562bb3471fdeaab5e699160abf7c3f2cbe66805", "0xc3dd8edec722273de2ffd31b47b4f106689ae891ac1bfddf7ae6190589ab0f67"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6885289 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6941420 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_proxyAddress", value: 4}, {type: "address", name: "hotTokenAddress", value: 5}], name: "HybridExchange", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "proxyAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "proxyAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "filled", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "filled(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "cancelled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cancelled(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "relayerDelegates", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "relayerDelegates(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DOMAIN_SEPARATOR", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DOMAIN_SEPARATOR()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "discountConfig", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "discountConfig()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "relayer", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "canMatchOrdersFrom", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canMatchOrdersFrom(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getDiscountedRate", outputs: [{name: "result", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDiscountedRate(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EIP712_ORDER_TYPE", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EIP712_ORDER_TYPE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "FEE_RATE_BASE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "FEE_RATE_BASE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DISCOUNT_RATE_BASE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DISCOUNT_RATE_BASE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "relayer", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isParticipant", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isParticipant(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EIP712_DOMAIN_TYPEHASH", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EIP712_DOMAIN_TYPEHASH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hotTokenAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hotTokenAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "HybridExchange", function( accounts ) {

	it( "TEST: HybridExchange( addressList[4], addressList[5] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6885289", timeStamp: "1544793898", hash: "0x7c25a87eb6363875110974c70d2695f4711343b4518396f07dd03429fef5fe02", nonce: "1", blockHash: "0xf5e10d8edd382b944c088e7675eafafcb4bbe8f10f3167da1b8593a138109adc", transactionIndex: "41", from: "0x967a2d1d753b1c21011b395caac96274f142b01f", to: 0, value: "0", gas: "4000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf23dd7be00000000000000000000000074622073a4821dbfd046e9aa2ccf691341a076e10000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1", contractAddress: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", cumulativeGasUsed: "5053582", gasUsed: "3448502", confirmations: "793043"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_proxyAddress", value: addressList[4]}, {type: "address", name: "hotTokenAddress", value: addressList[5]}], name: "HybridExchange", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = HybridExchange.new( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544793898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = HybridExchange.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[0,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x967a2d1d753b1c21011b395caac96274f142b01f"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[0,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790599363000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: changeDiscountConfig( \"0x0532000013886400004e205a000186a05000... )", async function( ) {
		const txOriginal = {blockNumber: "6901012", timeStamp: "1545017780", hash: "0xfc00ef96680442d4cba76da1295a73491d1960dde6e2d6fe8015634ff15b38ba", nonce: "3", blockHash: "0xb8974a581ce32fc37e10381fdb506f42b5c1cbe473f2fd7266e664dd0730f330", transactionIndex: "54", from: "0x967a2d1d753b1c21011b395caac96274f142b01f", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "42382", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x156066e40532000013886400004e205a000186a0500007a12046001e84803c0000000000", contractAddress: "", cumulativeGasUsed: "1733168", gasUsed: "28255", confirmations: "777320"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "newConfig", value: "0x0532000013886400004e205a000186a0500007a12046001e84803c0000000000"}], name: "changeDiscountConfig", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeDiscountConfig(bytes32)" ]( "0x0532000013886400004e205a000186a0500007a12046001e84803c0000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1545017780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790599363000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6903366", timeStamp: "1545052878", hash: "0xdb6132bed6998adae1e53bb7830526aee54f988c6dcf768b75dea93af7252091", nonce: "1", blockHash: "0x4ab8349d59531cbf1343fe3c808dfe2c529bcba9dd20546dbe4d59d5096fae75", transactionIndex: "134", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000085cf54dd216997bcf324c72aa1c845be2f05929900000000000000000000000000000000000000000000003635c9adc5dea00000000000000000000000000000000000000000000000000000006c9228785600000000000000000000000000000000000000000000000000000002aa1efb94e00001000007b3c8c432006400c80064000000000009b345000000000000000000001c010000000000000000000000000000000000000000000000000000000000005537f307474888be1c78f12db39646d9a61143a90a17373dc3ac3c0f252c238c49dd2b8f0846e899fe6a035e71ba3e645e55c5893cd7c7154105c6142dc490d300000000000000000000000000000000000000000000000000000000000001800000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000003ae88dfb252fe623a7fb6b4df96d96eb150e830a00000000000000000000000000000000000000000000003635c9adc5dea00000000000000000000000000000000000000000000000000000006c92287856000000000000000000000000000000000000000000000000000000031bced02db000010100005c17a5a7006400c8006400000000000987b9000000000000000000001b0100000000000000000000000000000000000000000000000000000000000016a56de7dc60580a7011dddec29caee136004374bfd69e7b1d1d3e7fa5c378cc07737eabcc7023f1c1bc922f62a492cd2ccd9c198164b75812afc2b2f63a59bd", contractAddress: "", cumulativeGasUsed: "5765721", gasUsed: "206148", confirmations: "774966"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1545052878 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x3ae88dfb252fe623a7fb6b4df96d96eb150e830a"}, {name: "taker", type: "address", value: "0x85cf54dd216997bcf324c72aa1c845be2f059299"}, {name: "baseTokenAmount", type: "uint256", value: "1000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "30560000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "61120000000000"}, {name: "makerGasFee", type: "uint256", value: "875000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "750000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6913457", timeStamp: "1545201343", hash: "0xf41c380a6b0998b40c5eee32025cdb3d951b36408e78646f42e4e4f5a40d5298", nonce: "4", blockHash: "0x3639b1423dcd88d4230e4839dd82c9f337a21969f57a2d0a0e824e80e0d185ab", transactionIndex: "58", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "10300000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000085cf54dd216997bcf324c72aa1c845be2f05929900000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000001cdda4faccd0000000000000000000000000000000000000000000000000000003a9c635dc2a27de01010007b3cb12b4000000c8006400000000000d176f000000000000000000001b01000000000000000000000000000000000000000000000000000000000000bcea74cafbe8c6f160763808eee22c622c464b81b270c9035f092c288c3fba872f9779ce5b6608002973504e51c9e227c9bdb7e0eccd00b4a3628a4101f20a880000000000000000000000000000000000000000000000000000000000000180000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000003ae88dfb252fe623a7fb6b4df96d96eb150e830a00000000000000000000000000000000000000000000000000470de4df8200000000000000000000000000000000000000000000000000001cdda4faccd0000000000000000000000000000000000000000000000000000003b0d239b8894d7e010000005c19f467000000c80064000000000007ba0b000000000000000000001b010000000000000000000000000000000000000000000000000000000000001f668bc4eee3eaa0e24a3f7135b2d8f73dfe3ef2e79767ed06321c39d8b0675917a78e4a4d976f66fb6a87befe57ff897c0695f532f95a5264b81afbbea1fe70", contractAddress: "", cumulativeGasUsed: "2669000", gasUsed: "212540", confirmations: "764875"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1545201343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "quoteToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x3ae88dfb252fe623a7fb6b4df96d96eb150e830a"}, {name: "taker", type: "address", value: "0x85cf54dd216997bcf324c72aa1c845be2f059299"}, {name: "baseTokenAmount", type: "uint256", value: "20000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "2080000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "4160000000000000"}, {name: "makerGasFee", type: "uint256", value: "265943523365834110"}, {name: "makerRebate", type: "uint256", value: "2080000000000000"}, {name: "takerGasFee", type: "uint256", value: "263959987807201246"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6913615", timeStamp: "1545203745", hash: "0x9111adbb2eb9adc2be06a08cc0c0cd49dc59c9a7a069790cc168d9d8e575905f", nonce: "5", blockHash: "0x418d9601acc2f212ed084eab09cf368e414c81c3cc00e834cc948981de11d38e", transactionIndex: "21", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "1500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000003ae88dfb252fe623a7fb6b4df96d96eb150e830a0000000000000000000000000000000000000000000000878678326eac900000000000000000000000000000000000000000000000000000010a741a462780000000000000000000000000000000000000000000000000000008e1bc9bf0400001000007b3cb1bfa000000c8006400000000000b334c000000000000000000001c01000000000000000000000000000000000000000000000000000000000000b3a7d34499ab7b85f29724c53e45ea0828206d6222cd6691e05c937e150bd73948d6e81af0268fe9b5f60b65ffe0881dc6744ac62efed5ca3a030e4271f061be00000000000000000000000000000000000000000000000000000000000001800000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000300000000000000000000000085cf54dd216997bcf324c72aa1c845be2f05929900000000000000000000000000000000000000000000001b1ae4d6e2ef5000000000000000000000000000000000000000000000000000000031bced02db00000000000000000000000000000000000000000000000000000007fe5cf2bea00001010007b3cb15d2000000c8006400000000000274bc000000000000000000001c010000000000000000000000000000000000000000000000000000000000003b713e1d0597d7b2034de6008e568bd18003c68240d4a82ba7c441bb4fd05158125ec4f8b11e4746b1bdb86c2110c7f047c5596501c1030ef91d044110bc9a3e00000000000000000000000085cf54dd216997bcf324c72aa1c845be2f05929900000000000000000000000000000000000000000000003635c9adc5dea0000000000000000000000000000000000000000000000000000000670758aa7c80000000000000000000000000000000000000000000000000000007e7a02ea0100001010007b3cb15a1000000c8006400000000000ae0ca000000000000000000001c0100000000000000000000000000000000000000000000000000000000000062775367781ecc7a088115ea25eed3a42f027e38a70b001ef6af2d6f11d5f2a3584bb7875ea3eff3f06e28f23f60bfe14db8a3b28c6bfaac0b05091a554970af00000000000000000000000085cf54dd216997bcf324c72aa1c845be2f05929900000000000000000000000000000000000000000000003635c9adc5dea00000000000000000000000000000000000000000000000000000006a94d74f4300000000000000000000000000000000000000000000000000000007e7a02ea0100001010007b3cb1597000000c800640000000000021f25000000000000000000001b01000000000000000000000000000000000000000000000000000000000000c143c7f0afca5836e56dd5397800523f3581102d9cee25f8a806546a6e55d31f5b0570d81ff3040b85f1a5671737e0afcf8750588515fe0f45b5a8219a4987eb", contractAddress: "", cumulativeGasUsed: "2494588", gasUsed: "379980", confirmations: "764717"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1545203745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x85cf54dd216997bcf324c72aa1c845be2f059299"}, {name: "taker", type: "address", value: "0x3ae88dfb252fe623a7fb6b4df96d96eb150e830a"}, {name: "baseTokenAmount", type: "uint256", value: "500000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "14000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "19600000000000"}, {name: "makerGasFee", type: "uint256", value: "2250000000000000"}, {name: "makerRebate", type: "uint256", value: "14000000000000"}, {name: "takerGasFee", type: "uint256", value: "2500000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x85cf54dd216997bcf324c72aa1c845be2f059299"}, {name: "taker", type: "address", value: "0x3ae88dfb252fe623a7fb6b4df96d96eb150e830a"}, {name: "baseTokenAmount", type: "uint256", value: "1000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "29000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "40600000000000"}, {name: "makerGasFee", type: "uint256", value: "2225000000000000"}, {name: "makerRebate", type: "uint256", value: "29000000000000"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x85cf54dd216997bcf324c72aa1c845be2f059299"}, {name: "taker", type: "address", value: "0x3ae88dfb252fe623a7fb6b4df96d96eb150e830a"}, {name: "baseTokenAmount", type: "uint256", value: "1000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "30000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "42000000000000"}, {name: "makerGasFee", type: "uint256", value: "2225000000000000"}, {name: "makerRebate", type: "uint256", value: "30000000000000"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6918378", timeStamp: "1545274195", hash: "0xf3da31a51bf8b454d12c17944b6f05379887b9f189b953e5f38ad51bbd5c17ec", nonce: "6", blockHash: "0x1a68034ae6d5d5a5b77d140908eba5196a80667b0d033cd9117c974c9effb8ff", transactionIndex: "134", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8600000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000008593274465d6ad79357e10bcd21c56e6b75a74270000000000000000000000000000000000000000000000056bc75e2d63100000000000000000000000000000000000000000000000000000087727c4a0fd00000000000000000000000000000000000000000000000000000007a369e244600001000002540be3ff000000c80064000000000005ffec000000000000000000001b00000000000000000000000000000000000000000000000000000000000000cde8f247dd13bb1648c5274a763d7cf41e7b39fa0c01239c39ae669a5cd0d9f912f8ea01bf9344d4e954b3f9b6313b00e56dd710014a608d737da22e559f2f01000000000000000000000000000000000000000000000000000000000000018000000000000000000000000033b919f54692ddbf702065763ea2b50ca02e6bff000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000100000000000000000000000060c462286a197b42a96c97b172f6f3db40a755290000000000000000000000000000000000000000000000056bc75e2d63100000000000000000000000000000000000000000000000000000087727c4a0fd000000000000000000000000000000000000000000000000000000071afd498d000001010002540be3ff000000c80064000000000009de0c000000000000000000001b00000000000000000000000000000000000000000000000000000000000000953aa85a800f528d36885587fd316359ba40a35a152aee61131d0a6659594ed61b0989e8a72263fd48f4d9caea73481f500032064e6c7b1bd465d19fa930e6e4", contractAddress: "", cumulativeGasUsed: "6403474", gasUsed: "192631", confirmations: "759954"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1545274195 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x33b919f54692ddbf702065763ea2b50ca02e6bff"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x60c462286a197b42a96c97b172f6f3db40a75529"}, {name: "taker", type: "address", value: "0x8593274465d6ad79357e10bcd21c56e6b75a7427"}, {name: "baseTokenAmount", type: "uint256", value: "100000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "610000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "1220000000000000"}, {name: "makerGasFee", type: "uint256", value: "2000000000000000"}, {name: "makerRebate", type: "uint256", value: "610000000000000"}, {name: "takerGasFee", type: "uint256", value: "2150000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6919578", timeStamp: "1545292007", hash: "0x12a6d5e72b1e9de4eca750c1194ddc72d8ca002c07e6083e0fd0f31b205370c7", nonce: "7", blockHash: "0x9d678ab52a0e91c193d57619d2c646e5cc235c575fa37e3a56eaae6a0ddbfd16", transactionIndex: "59", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000009c59990ec0177d87ed7d60a56f584e6b06c639a200000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002c75477297b62f501010107b3cc74d10064012c00640000000000079758000000000000000000001c01000000000000000000000000000000000000000000000000000000000000679c44fbf461e5ecb9f191cc0c643851d5487e8dab89f8ad65ae2deb09f16b81728dd26b6043578a66b70129f9e2dd51a073681934196adef10d25fcd75ef1920000000000000000000000000000000000000000000000000000000000000180000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a6c75ad003fa6fcaa0c353ddfac458d928ea9c0e00000000000000000000000000000000000000000000000191e696903750000000000000000000000000000000000000000000000000009ce1f0c0acca94000000000000000000000000000000000000000000000000000002c75477297b62f501000002540be3ff0064012c0064000000000009a8c0000000000000000000001c000000000000000000000000000000000000000000000000000000000000001103a7e19a12a8de94e51ff3001f07c449cd067df19fddb38620f88c960454e600cd3d437d9089788b2fa22afad1cee6f340d9ba2fae80dd5e82e98b1e90958f", contractAddress: "", cumulativeGasUsed: "2711209", gasUsed: "179518", confirmations: "758754"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1545292007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "quoteToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xa6c75ad003fa6fcaa0c353ddfac458d928ea9c0e"}, {name: "taker", type: "address", value: "0x9c59990ec0177d87ed7d60a56f584e6b06c639a2"}, {name: "baseTokenAmount", type: "uint256", value: "200000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "19986000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "47966400000000000"}, {name: "makerGasFee", type: "uint256", value: "200221579215069941"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "200221579215069941"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6919602", timeStamp: "1545292453", hash: "0x4cca5579f8ae49d8588080539760876a6e084ca4beaff4b7efdf89d965e8b8d4", nonce: "8", blockHash: "0x71921424ee59c63178aa24187f11ef6ae1420ee5663e511d74066c73f3059c64", transactionIndex: "103", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "10700000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000009c59990ec0177d87ed7d60a56f584e6b06c639a2000000000000000000000000000000000000000000000001156abf16a40f0000000000000000000000000000000000000000000000000000004704cc910f6000000000000000000000000000000000000000000000000000000980e5f8c6300001010007b3cc76840064012c00640000000000071980000000000000000000001c0100000000000000000000000000000000000000000000000000000000000079ac94141be55690f7d31e0326484ed78c6bbaac9d5200860ff47bc439911316259260d5ad56340c34b340a90898476a625f53397668cbb8aa53b7fd13ca53e90000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f498000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000100000000000000000000000037bb07d111de576c757c4bf909581d792d5189190000000000000000000000000000000000000000000000480b947aa7fe2400000000000000000000000000000000000000000000000000003b80af7dc6ee7000000000000000000000000000000000000000000000000000000980e5f8c6300001000002540be3ff0064012c0064000000000009f575000000000000000000001b00000000000000000000000000000000000000000000000000000000000000b3f394a38dbc8735235f50ec22c9227448d0f3d33e6fc1e77155d3eec3e30840350f95e8086c4355bbc18ec8435a4fb3a952ad923825937b9d00718b4d1ba4da", contractAddress: "", cumulativeGasUsed: "4552177", gasUsed: "178663", confirmations: "758730"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1545292453 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe41d2489571d322189246dafa5ebde1f4699f498"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x37bb07d111de576c757c4bf909581d792d518919"}, {name: "taker", type: "address", value: "0x9c59990ec0177d87ed7d60a56f584e6b06c639a2"}, {name: "baseTokenAmount", type: "uint256", value: "19990000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "64491738000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "154780171200000"}, {name: "makerGasFee", type: "uint256", value: "2675000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "2675000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6919784", timeStamp: "1545295165", hash: "0x16d54fe279439945f9b282da81e84c1aff3e3f8c470e778fd2feee634567a275", nonce: "5", blockHash: "0x9429c900424bddbf6404ab3380a8be42449b87c8c071b33fb2054050301452e3", transactionIndex: "172", from: "0x967a2d1d753b1c21011b395caac96274f142b01f", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "46132", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b000000000000000000000000b15367df8a39ea06f8f81ed35d49e056ee05f3b7", contractAddress: "", cumulativeGasUsed: "7940281", gasUsed: "30755", confirmations: "758548"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[7]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1545295165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x967a2d1d753b1c21011b395caac96274f142b01f"}, {name: "newOwner", type: "address", value: "0xb15367df8a39ea06f8f81ed35d49e056ee05f3b7"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790599363000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6920477", timeStamp: "1545305327", hash: "0xcd3f354b4a2b60de0cd5872d2245c126984ea139e4f340e1787e8db31dd86d14", nonce: "9", blockHash: "0xc591ee0691135f6844fc9599f1d6debceeac0a3d92c7d53ee1235f906e3bd388", transactionIndex: "144", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000008593274465d6ad79357e10bcd21c56e6b75a74270000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000d8b72d434c800000000000000000000000000000000000000000000000000000071afd498d000001000002540be3ff0064012c0064000000000002cb75000000000000000000001b00000000000000000000000000000000000000000000000000000000000000004c0ab93342795043d4d5ec91236150aa014164caaa2c7b0e3a570bb29be9fc08454a0d5d819dedeb3da9cd1aefb7743cffa923cd929d22abe749cb1f89e923000000000000000000000000000000000000000000000000000000000000018000000000000000000000000033b919f54692ddbf702065763ea2b50ca02e6bff000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000100000000000000000000000060c462286a197b42a96c97b172f6f3db40a755290000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000d8b72d434c800000000000000000000000000000000000000000000000000000071afd498d000001010002540be3ff0064012c0064000000000009f1a9000000000000000000001b000000000000000000000000000000000000000000000000000000000000008829369bac051397662ade75ddd443b8bdf19c727125d02625a0714e80242a1c50361fd3105cc5159d46a6b135c001c247a7b763424d8ae70fb469c25c264e4b", contractAddress: "", cumulativeGasUsed: "6106734", gasUsed: "179541", confirmations: "757855"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1545305327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x33b919f54692ddbf702065763ea2b50ca02e6bff"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x60c462286a197b42a96c97b172f6f3db40a75529"}, {name: "taker", type: "address", value: "0x8593274465d6ad79357e10bcd21c56e6b75a7427"}, {name: "baseTokenAmount", type: "uint256", value: "10000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "61000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "183000000000000"}, {name: "makerGasFee", type: "uint256", value: "2000000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "2000000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6920751", timeStamp: "1545308866", hash: "0x679407e52893b780aef4812f26e066f0f73912d00e0292fb485b15e5a75fb3bf", nonce: "10", blockHash: "0x5e8c20654c49efeeacd51b05107ed609da7d1de6c205feb2c523c4a5dc1b05e9", transactionIndex: "207", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000e809efdb159df117b6fde12fe98358e55b7d10cc00000000000000000000000000000000000000000000000ad78ebc5ac620000000000000000000000000000000000000000000000000000000164859cc08000000000000000000000000000000000000000000000000000000071afd498d000001000002540be3ff0064012c006400000000000a32ba000000000000000000001c00000000000000000000000000000000000000000000000000000000000000e2f1f624e14c5d7b86c862498a9aa889a8a9fd9d9da841cb3faa693768d97ee25221d6184e59e0a48abcd82730db87b11dfc2959b8ba4e19c00baa8d7fecbff900000000000000000000000000000000000000000000000000000000000001800000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000008adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a000000000000000000000000000000000000000000001ee21c5457f7a78800000000000000000000000000000000000000000000000000003f78b59fe882000000000000000000000000000000000000000000000000000000071afd498d000001010002540be3ff0064012c0064000000000007c2ef000000000000000000001c00000000000000000000000000000000000000000000000000000000000000155f69c93cc94886850c7a9040ee2cec21c0cdaa390558d3f148b43bd4afb08b60baacaf388c50f6d573341027b32b096adfae989a2f5adf7c4e568ed0655510", contractAddress: "", cumulativeGasUsed: "7055221", gasUsed: "192303", confirmations: "757581"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1545308866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x8adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a"}, {name: "taker", type: "address", value: "0xe809efdb159df117b6fde12fe98358e55b7d10cc"}, {name: "baseTokenAmount", type: "uint256", value: "200000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "6272000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "18816000000000"}, {name: "makerGasFee", type: "uint256", value: "2000000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "2000000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6920771", timeStamp: "1545309133", hash: "0xbefc4a8807471df5ba209b82f13dd20ba27bdf11ac2994382fd498b43f9ac51c", nonce: "11", blockHash: "0x008e2729169f9396f3a13be375bd8a5c53e90d2473170bcc3ee03194d88d1a54", transactionIndex: "131", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000008adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a000000000000000000000000000000000000000000001ed5e9d3c41188a400000000000000000000000000000000000000000000000000003f5fa43ae2f9000000000000000000000000000000000000000000000000000000071afd498d000001010002540be3ff0064012c006400000000000b358d000000000000000000001b00000000000000000000000000000000000000000000000000000000000000a4f306d94f177f9acb9e942ef30c3e654bf7d2b837655950eaeb5a39e791255a624b956f177c688a8d89a86ef4e2b8e4032b6f3c61eb91d271899235c8e4a95200000000000000000000000000000000000000000000000000000000000001800000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e809efdb159df117b6fde12fe98358e55b7d10cc000000000000000000000000000000000000000000000045d29737e22f200000000000000000000000000000000000000000000000000000008f8004da48000000000000000000000000000000000000000000000000000000071afd498d000001000002540be3ff0064012c00640000000000021257000000000000000000001c00000000000000000000000000000000000000000000000000000000000000d1fc2be1f3ecbd069da50ec49b6280b8dc7d01c84f3b67014c48fb4ca58943124aee952e8efba20458daf35302f175009a0ab24db442dc0126d8da2b44d4b924", contractAddress: "", cumulativeGasUsed: "5090121", gasUsed: "185780", confirmations: "757561"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1545309133 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xe809efdb159df117b6fde12fe98358e55b7d10cc"}, {name: "taker", type: "address", value: "0x8adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a"}, {name: "baseTokenAmount", type: "uint256", value: "1288000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "40391680000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "72705024000000"}, {name: "makerGasFee", type: "uint256", value: "2000000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "2000000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6925846", timeStamp: "1545383789", hash: "0x402a1521e55198edb15a41efdba321865324d16d49c81f5e7e82ad5beec9764c", nonce: "12", blockHash: "0x072165cb4a98536308faec8e8fc247c17a7c0fb98bd33138bfeb07f55e7d2b5a", transactionIndex: "32", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8600000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000e809efdb159df117b6fde12fe98358e55b7d10cc0000000000000000000000000000000000000000000000372f968667a3a8000000000000000000000000000000000000000000000000000000653afa7364d8000000000000000000000000000000000000000000000000000007a369e244600001010001fd4b0c960064012c0064056c9bc6783f6398000000000000000000001b00000000000000000000000000000000000000000000000000000000000000dd252182fe092b046a801a50c85dedbc22942f41c8df7ceb21548b6cc891b17d2ad496dfa47508275caea978904c8375a5fadce0ba263b5df83a6bb9d32b8b8b00000000000000000000000000000000000000000000000000000000000001800000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000008adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a000000000000000000000000000000000000000000000878678326eac900000000000000000000000000000000000000000000000000000010a2fe3f9cbd00000000000000000000000000000000000000000000000000000007a369e24460000100000259b235ab0064012c006404f48f25b809aea0000000000000000000001b00000000000000000000000000000000000000000000000000000000000000b7dbe569d0b7778cc704ad2eaf352acab70e8122f5c8099220fca80eae6a17cb19e2f9ffbad69111aca7015abcdcdaa80e67c6b4e404cc48af43e0301b978a68", contractAddress: "", cumulativeGasUsed: "3692161", gasUsed: "180776", confirmations: "752486"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1545383789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x8adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a"}, {name: "taker", type: "address", value: "0xe809efdb159df117b6fde12fe98358e55b7d10cc"}, {name: "baseTokenAmount", type: "uint256", value: "1018000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "30509460000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "91528380000000"}, {name: "makerGasFee", type: "uint256", value: "2150000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "2150000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6926800", timeStamp: "1545397730", hash: "0x51223c9684e77075f261b20c81db8d6c693c31cb38afd0a95bd304fcc8f85330", nonce: "13", blockHash: "0xbb82c59dc4085b0ca660d45bf086d3481bdbf2cacac5442938af660b2ba33bbd", transactionIndex: "99", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000de6f889d24471f618bc371d68232fb99f3ce4d2a00000000000000000000000000000000000000000000010f0cf064dd59200000000000000000000000000000000000000000000000000000021d140b074ac00000000000000000000000000000000000000000000000000000071afd498d000001000007b3ce11ae0064012c006407a807b0edcbe6e8000000000000000000001b01000000000000000000000000000000000000000000000000000000000000a6137c5f47e6fd64849edcfe675b53c4ec27e84796e91d478b1f47c0b41c0dd2542e6addb341a35c1a2d72fb77169c08d6f850050a47624d194034761761e92f00000000000000000000000000000000000000000000000000000000000001800000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000008adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a0000000000000000000000000000000000000000000001c61e3a7cc077440000000000000000000000000000000000000000000000000000038a85c750c6180000000000000000000000000000000000000000000000000000071afd498d000001010002540be3ff0064012c006400000000000b50fc000000000000000000001c000000000000000000000000000000000000000000000000000000000000001399ebbb34fd42257545465b8e27d35a52c3d8690917fe161c76417e6134b4df5153e4f033089bf8bc4a55130528e1842a52d7158b00f805f2d71ec72bc80121", contractAddress: "", cumulativeGasUsed: "4381731", gasUsed: "193002", confirmations: "751532"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1545397730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x8adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a"}, {name: "taker", type: "address", value: "0xde6f889d24471f618bc371d68232fb99f3ce4d2a"}, {name: "baseTokenAmount", type: "uint256", value: "5000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "152300000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "319830000000000"}, {name: "makerGasFee", type: "uint256", value: "2000000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "2000000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12164254752156711485" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6926891", timeStamp: "1545399351", hash: "0x0bb2254d76f48860326335086b18658da38fa86791ffe7c9ba31b2d13f720c37", nonce: "14", blockHash: "0x57c4797d924c2570218382f92968da17126a20eb29bd5c2e4bc5c458e57d4347", transactionIndex: "105", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000de6f889d24471f618bc371d68232fb99f3ce4d2a00000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000074b4e6a4df2000000000000000000000000000000000000000000000000000000577b65c4f300001000007b3ce18260064012c000002d366aca64f4680000000000000000000001c010000000000000000000000000000000000000000000000000000000000000b331de34679e295a06b74a21a38dd362c5d048dbd6a7bc9e4c77680f830eb653416550c2d4af39b743a887099ac8482f1dddb9ca6dc76f48e6ee15b4851625d00000000000000000000000000000000000000000000000000000000000001800000000000000000000000009af839687f6c94542ac5ece2e317daae355493a1000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000008adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a0000000000000000000000000000000000000000000004134606bf9eb894000000000000000000000000000000000000000000000000000008c604f576dfa4000000000000000000000000000000000000000000000000000005666e940f000001010004db0048130064012c0000079f05ba265c1ae8000000000000000000001c00000000000000000000000000000000000000000000000000000000000000bda728060614acee037cd1d4d77a0667dd174fd832ab768c3a867ed0ed21652e1176ca8dde6bc584bf1c5bc92b27139c497add67b3db327e613dd03c3f0d248b", contractAddress: "", cumulativeGasUsed: "4953718", gasUsed: "193178", confirmations: "751441"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1545399351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x9af839687f6c94542ac5ece2e317daae355493a1"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x8adfc6cd9fb99ca9ac487aff4a0cb23e62a3591a"}, {name: "taker", type: "address", value: "0xde6f889d24471f618bc371d68232fb99f3ce4d2a"}, {name: "baseTokenAmount", type: "uint256", value: "1000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "32850000000000000"}, {name: "makerFee", type: "uint256", value: "19710000000000"}, {name: "takerFee", type: "uint256", value: "68985000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1539000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6927312", timeStamp: "1545405449", hash: "0xf5c1def5bd2c8399cd35e854e0cc5ae16e81dc18800980bdd4a9853b5cb94e95", nonce: "15", blockHash: "0x0c10c31a91e4ab8e0f98cbf54c763fba36205094cff192c1705ce1130d90b66f", transactionIndex: "105", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000002e39124e92760ba2975a22ea30c3670d117f095000000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000031bced02db00000000000000000000000000000000000000000000000000000005666e940f000001000007b3ce2fe30064012c0000079c1f6f85b33b18000000000000000000001c01000000000000000000000000000000000000000000000000000000000000466a612393f5cbb223cad1d6bbb0903d8e835d19b45bb6a1d94e68e27caea8003eb678542bbbbb4d9dac3c7fed6c53a0be2d3f4c5948650665dfd8dc705600ff0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000009b601497296dab50349a32cb42dd793d45fc499600000000000000000000000000000000000000000000012a27d53bc04870000000000000000000000000000000000000000000000000000000ea7aa67b2d00000000000000000000000000000000000000000000000000000005666e940f000001010007b3ce2a820064012c00000102e33ec370edfe000000000000000000001b010000000000000000000000000000000000000000000000000000000000002dfb31da2de41b60b3f70234c040d510f52b685c1359d0fe2a23d0300b1c2a2c79a6130b2495d41afed623d33d842a2f046544b844f04edf7d373dcb186af0ce", contractAddress: "", cumulativeGasUsed: "4097415", gasUsed: "191224", confirmations: "751020"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1545405449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x9b601497296dab50349a32cb42dd793d45fc4996"}, {name: "taker", type: "address", value: "0x2e39124e92760ba2975a22ea30c3670d117f0950"}, {name: "baseTokenAmount", type: "uint256", value: "1000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "12000000000000000"}, {name: "makerFee", type: "uint256", value: "12000000000000"}, {name: "takerFee", type: "uint256", value: "36000000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6928163", timeStamp: "1545418404", hash: "0x087f1637b07ee7105b21002e180d85e14aad7114563a2e57bc2d15e56e9e8c4b", nonce: "16", blockHash: "0xfb7c9d2af6d7461152b0108f58652346ae6e3d79efd728e19c51a80c16f52b42", transactionIndex: "129", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000dff43df7d233de46da4ed629163955b735471cd100000000000000000000000000000000000000000106956b513b77a536a40000000000000000000000000000000000000000000000000000069baeb21526df000000000000000000000000000000000000000000000000000005666e940f0000010000005c1d44860064012c000006a9213a7411450c000000000000000000001b010000000000000000000000000000000000000000000000000000000000004fe311defdd385b2aed7bcd233ac943c4896f52eaae0072c5ba206d698754b86375e9a5698ed3eef00e6b4121fbf42bb78a6d11e1629e9257dd6f1b9ebc560a00000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f213400000000000000000000000000000000000000000052b7d2dcc80cd2e40000000000000000000000000000000000000000000000000000000214e8348c4f000000000000000000000000000000000000000000000000000000059a45eccf900001010007b3ce5bc40064012c00000619c41077e5ea00000000000000000000001c0100000000000000000000000000000000000000000000000000000000000003abcc056b4979b8160fee52cdc2abac2547dd6f20f94215e7734e94e15e198368f5e7d41cd4a004f1ac64bd99918caded19a8d55ce8821281821fcee3bb80bc", contractAddress: "", cumulativeGasUsed: "5485938", gasUsed: "191557", confirmations: "750169"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1545418404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "taker", type: "address", value: "0xdff43df7d233de46da4ed629163955b735471cd1"}, {name: "baseTokenAmount", type: "uint256", value: "100000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "150000000000000000"}, {name: "makerFee", type: "uint256", value: "150000000000000"}, {name: "takerFee", type: "uint256", value: "450000000000000"}, {name: "makerGasFee", type: "uint256", value: "1577000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6928180", timeStamp: "1545418651", hash: "0x186e7a1b8d54d4154ac187fa174977eaa02008e5827a9630dd04b344878fa7de", nonce: "17", blockHash: "0xae8ad7537b0b3870a75d98670ad86143cd17cef8819444b074892ab44e9a4e4c", transactionIndex: "49", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0x8d10883d000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f2134000000000000000000000000000000000000000000b3dd9874736ad252a400000000000000000000000000000000000000000000000000000486c67d88d7df000000000000000000000000000000000000000000000000000005666e940f000001010007b3ce63790064012c000004d2267715aca1f0000000000000000000001c01000000000000000000000000000000000000000000000000000000000000bd2e3df6cd5c896906141dc7233a74f760cceef67150a849842b3cf105188d9f65b6634ad3e189898a545c126adf2fdf04231fa82351e89896ac3369b6ec0c0a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000dff43df7d233de46da4ed629163955b735471cd100000000000000000000000000000000000000000106956b513b77a536a40000000000000000000000000000000000000000000000000000069baeb21526df000000000000000000000000000000000000000000000000000005666e940f0000010000005c1d44860064012c000006a9213a7411450c000000000000000000001b010000000000000000000000000000000000000000000000000000000000004fe311defdd385b2aed7bcd233ac943c4896f52eaae0072c5ba206d698754b86375e9a5698ed3eef00e6b4121fbf42bb78a6d11e1629e9257dd6f1b9ebc560a0", contractAddress: "", cumulativeGasUsed: "4591918", gasUsed: "494429", confirmations: "750152"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1545418651 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6928699", timeStamp: "1545426228", hash: "0xd9b5cfa09885754cfba98a4875a2fad9e8e95f6dbe250ec1d15a6b5fc3b90fde", nonce: "18", blockHash: "0xa39ae2a902cea3827617f476f44adb0a9ff201b9950dbf2cabf2340e1f74de99", transactionIndex: "53", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a300000000000000000000000000000000000000000000023942a6575148f40000000000000000000000000000000000000000000000000000baf17aa2c7f6e0000000000000000000000000000000000000000000000000000005666e940f00000101000739293a070064012c0000036caaa67d03b680000000000000000000001b000000000000000000000000000000000000000000000000000000000000004e719f6000d0e863fcbd669f53528069d385993b44b451e66dcf3971e401b3b75190e60f877d5c14736fbb76c4d14d7dbc0bd1e32877f38f41c5a8801c371c9c00000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf0000000000000000000000000000000000000000000000001c586aeda9bc400000000000000000000000000000000000000000000000000000094efbfe43a60000000000000000000000000000000000000000000000000000005666e940f000001000007b3ce723b0064012c0000042a4c15aff64a0c000000000000000000001c000000000000000000000000000000000000000000000000000000000000006105b8ebf574ddbe5994d0aa98882643f3ef14592259e1022e8f147b508c0ef41eda7f5f0a27a8ae3bad6b97c8d68ace4832d8f0f1420b6e7968bcc1b91ee244", contractAddress: "", cumulativeGasUsed: "5440376", gasUsed: "198876", confirmations: "749633"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1545426228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "32680000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "41921904000000000"}, {name: "makerFee", type: "uint256", value: "41921904000000"}, {name: "takerFee", type: "uint256", value: "125765712000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6928911", timeStamp: "1545429724", hash: "0xd2e6a92d5b3bf3a26af333a56de0acc2c099d3819214c88eb8f77abd343dbe5b", nonce: "19", blockHash: "0xd000b52b4c969ef211ab2cd151c3e9c21262ecc16b72fd60bc3ccb5a8fc951af", transactionIndex: "50", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0x8d10883d000000000000000000000000e43c8da274d85b335d7b53f474357dfcf74c3c3a0000000000000000000000000000000000000000002018bd2347665ce3d0000000000000000000000000000000000000000000000000000000cec7efcfcfac000000000000000000000000000000000000000000000000000005666e940f000001000007b3ce8ec10064012c00000701579940415382000000000000000000001b01000000000000000000000000000000000000000000000000000000000000672cef80b334433067d3bfe39231c0a70456927e3989c7073e36da25c996c87a49f0c3beca348b24e1cad053396ebaf3d742dbc59c2b42626b39e861bc9e53b30000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f213400000000000000000000000000000000000000000052b7d2dcc80cd2e40000000000000000000000000000000000000000000000000000000214e8348c4f00000000000000000000000000000000000000000000000000000005666e940f000001010007b3ce64ee0064012c00000592306643a2878c000000000000000000001c01000000000000000000000000000000000000000000000000000000000000b55f34854bf18c80169586d9cd9a8fa27e812f778701ec9074800f1c94551a784e5a1459b44c51daad188ca23581b82b76a4a4591bda999ca5a57d096b6527bd", contractAddress: "", cumulativeGasUsed: "3138861", gasUsed: "495092", confirmations: "749421"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1545429724 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6929075", timeStamp: "1545432075", hash: "0x7e25cfc67e58630af5cc9bc4c534303843e62f844d046323c085ec767fddbe2f", nonce: "20", blockHash: "0x95d531dbeac14cf400877e3478c77a8eaa4b935ae21ee7a2118ca330918671a6", transactionIndex: "32", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000a6c75ad003fa6fcaa0c353ddfac458d928ea9c0e0000000000000000000000000000000000000000000000019d00c25323a000000000000000000000000000000000000000000000000000add933141dcbc000000000000000000000000000000000000000000000000000000242acd68f1831250101000746d19aa90064012c0000039bc5d57be87d84000000000000000000001c00000000000000000000000000000000000000000000000000000000000000d5875199aa9a3215a67ccfa4f65dc36a35ee575a8db5b3daeef764823a3697a41d107567e1bd6e112a22b9405b821287942a49a38c29a83e681a4bb80bee10c80000000000000000000000000000000000000000000000000000000000000180000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000001c81f209b612b4d6f488335e9ed8b6bde9649057000000000000000000000000000000000000000000000000011c37937e08000000000000000000000000000000000000000000000000000077bcd049721200000000000000000000000000000000000000000000000000000248a0e23cec278001000007b3ce8eb70064012c000004e0e5d0efe4b41c000000000000000000001b01000000000000000000000000000000000000000000000000000000000000cda69b24f4aaa1b39630421d4cc546830937145d5ef5ad954b9aabf2bd651f5077d3e687eafe57b9fde7084f52b22729dd1a73f11f996ab68c2b1b903c13f141", contractAddress: "", cumulativeGasUsed: "2471657", gasUsed: "180245", confirmations: "749257"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545432075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "quoteToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x1c81f209b612b4d6f488335e9ed8b6bde9649057"}, {name: "taker", type: "address", value: "0xa6c75ad003fa6fcaa0c353ddfac458d928ea9c0e"}, {name: "baseTokenAmount", type: "uint256", value: "80000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "8628000000000000000"}, {name: "makerFee", type: "uint256", value: "7765200000000000"}, {name: "takerFee", type: "uint256", value: "25884000000000000"}, {name: "makerGasFee", type: "uint256", value: "164558279944185728"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "162882574062465317"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6929956", timeStamp: "1545444236", hash: "0x522bf216998abb286e9020d831873c172db7fa74d10e8cf658950b0fd80bb6e0", nonce: "21", blockHash: "0xead79dc43a8ca335a694f4f1229238e4d57d5ef66ca3ea5574041e3a90e6a9cc", transactionIndex: "98", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000042e77bbaea70a9da173bbacd75578e6feb3b8b3e000000000000000000000000000000000000000000000000013fbe85edc900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000024086496a48dc9801010107b3cec75c0064012c000007c98d598aea6b08000000000000000000001b010000000000000000000000000000000000000000000000000000000000008822885084179092eb0c230453a4589adeaf3fbfc9a4a3a11ec03266fe65f8d857658d1b407ffb15dff82a4ffd49361391f9ca958832a7aaf12bc5444797814c0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a6c75ad003fa6fcaa0c353ddfac458d928ea9c0e0000000000000000000000000000000000000000000000019134f3d4088b00000000000000000000000000000000000000000000000000a70099f93809380000000000000000000000000000000000000000000000000000024086496a48dc9801000003c94566380064012c000002e4dc691de8160c000000000000000000001c0000000000000000000000000000000000000000000000000000000000000091a9b94fe837eafa119c4b1815542b287c036425fc9f768299c89dee36af1513020b3a49e9fb10259807d145a6f237dfb7e5d7861ebd43ecbc832e9597a8f7a2", contractAddress: "", cumulativeGasUsed: "4152677", gasUsed: "194095", confirmations: "748376"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545444236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "quoteToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xa6c75ad003fa6fcaa0c353ddfac458d928ea9c0e"}, {name: "taker", type: "address", value: "0x42e77bbaea70a9da173bbacd75578e6feb3b8b3e"}, {name: "baseTokenAmount", type: "uint256", value: "90000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "9590400000000000000"}, {name: "makerFee", type: "uint256", value: "9590400000000000"}, {name: "takerFee", type: "uint256", value: "28771200000000000"}, {name: "makerGasFee", type: "uint256", value: "162277236459232408"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "162277236459232408"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6931677", timeStamp: "1545470139", hash: "0xc86e2ec8b2a96c02461c208d0414d37a596cac79f0b930c5d8844e5fe36c9066", nonce: "22", blockHash: "0x074a92fbf4e3903d462ddb27e631bcc910ff994085f10088cd7ac097aa81dea9", transactionIndex: "106", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000cfce89648c011ce5370333e0ede554c018fe3734000000000000000000000000000000000000000000ecf0172e59de6078e4000000000000000000000000000000000000000000000000000001970e5ebe1504000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf2ca50064012c0000046bf75ab1a9810c000000000000000000001c01000000000000000000000000000000000000000000000000000000000000e07b29ad0c52143ebfc4d6ca46e6563c52e438e07720efad3294da8a9a37e75137c5d2fa516d0b2fe62390f4b6e0116f983ade881e82b278e94ff41bbb6f52990000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf000000000000000000000000000000000000000000039e7139a8c08fa06000000000000000000000000000000000000000000000000000000006379da05b6000000000000000000000000000000000000000000000000000000059a45eccf900001000007b3cf21070064012c0000007b4e3b77e17702000000000000000000001c000000000000000000000000000000000000000000000000000000000000008b7178a40e0f90f85d1a2c81cc47c413dd1ad85f207b36e31c7605c39a9223b6147fef794569d00ddb2a9a4b3b6b33202aaa70c1bab9e9aa21effebc79644408", contractAddress: "", cumulativeGasUsed: "3933599", gasUsed: "185511", confirmations: "746655"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545470139 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "taker", type: "address", value: "0xcfce89648c011ce5370333e0ede554c018fe3734"}, {name: "baseTokenAmount", type: "uint256", value: "70000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "28000000000000000"}, {name: "makerFee", type: "uint256", value: "28000000000000"}, {name: "takerFee", type: "uint256", value: "84000000000000"}, {name: "makerGasFee", type: "uint256", value: "1577000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6931748", timeStamp: "1545470969", hash: "0xdc5e2cc511507b1b711406d8ccbc0cf5626ce3f2cbf2ce88d9c0008f1c9415d9", nonce: "23", blockHash: "0xe93d45603da9618e2f37e1c74eff92db342edcdadc0c2d84aec148c9cfeaa0af", transactionIndex: "79", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000c16ac560ecb7459ed75908381e276846e5e96624000000000000000000000000000000000000000000295be96e64066972000000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf2fd60064012c000000f1ba5311754980000000000000000000001c01000000000000000000000000000000000000000000000000000000000000484b238924d171e578b2fc7cd50e2f7fa1d193c96d7189a6e0b3f99947af57fc2dc0eeff97440c0dd0fb99836b58d02ed53db45c5808811f022ed8d2393387b60000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000151b10492aa6f6a067be41e7ef9233b7256086d800000000000000000000000000000000000000000052b7d2dcc80cd2e400000000000000000000000000000000000000000000000000000000470de4df820000000000000000000000000000000000000000000000000000000588fe248f600001000007b3cede270064012c00000094b8ee5c36a0fe000000000000000000001b0100000000000000000000000000000000000000000000000000000000000054ec5f518d725eb19f98dc54eafcca985183423ff7195263f7184130048e34e465dbc4989d919e98a3f63266cfc5f790b7ab1486950415ad043d445be69df80b", contractAddress: "", cumulativeGasUsed: "5313187", gasUsed: "184880", confirmations: "746584"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545470969 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x151b10492aa6f6a067be41e7ef9233b7256086d8"}, {name: "taker", type: "address", value: "0xc16ac560ecb7459ed75908381e276846e5e96624"}, {name: "baseTokenAmount", type: "uint256", value: "50000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "10000000000000000"}, {name: "makerFee", type: "uint256", value: "10000000000000"}, {name: "takerFee", type: "uint256", value: "30000000000000"}, {name: "makerGasFee", type: "uint256", value: "1558000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6932371", timeStamp: "1545480082", hash: "0x1891a67ffec1876112bb6c4540370bb4673d39767a1a9e2b19a6720037d006c3", nonce: "24", blockHash: "0x10bcba7fd1e3df83418b8e9b42e63b95f6abaca85998ea4530cf5cc6126d038e", transactionIndex: "13", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000006c8505c6d296fb035fd8391937923e4f648336d1000000000000000000000000000000000000000000000001158e460913d00000000000000000000000000000000000000000000000000000005cd1756566e0000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf53840064012c0000040d3f6bb91f1060000000000000000000001c01000000000000000000000000000000000000000000000000000000000000a2e7e53956ed247c024bcfb90fd69916abb2abce44cf75946851a714a7559b673a0dc8b5a0585645c85d5a78a46b810927418bb98965658c63124681cfd50b9a00000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000100000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a300000000000000000000000000000000000000000000030473eddc4a771c0000000000000000000000000000000000000000000000000001020fa0cf9dab70000000000000000000000000000000000000000000000000000005666e940f000001010000bd03ced10064012c000007b529b018a6b4a0000000000000000000001c00000000000000000000000000000000000000000000000000000000000000eaf59aa5533c302074447f52e07d35001f82b8153e985eaa65f076f1cf00795e123c715a50213ec141b1579244b9a98c4e18edc0ec7ce5544553f2f0543bc17a", contractAddress: "", cumulativeGasUsed: "569705", gasUsed: "189906", confirmations: "745961"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545480082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "taker", type: "address", value: "0x6c8505c6d296fb035fd8391937923e4f648336d1"}, {name: "baseTokenAmount", type: "uint256", value: "20000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "26100000000000000"}, {name: "makerFee", type: "uint256", value: "26100000000000"}, {name: "takerFee", type: "uint256", value: "78300000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6932842", timeStamp: "1545487082", hash: "0xd6487655a00cb09512a905e28775d01a8df84ae8ebe1a10b1466b5c066a0c5d4", nonce: "25", blockHash: "0x0c22da8bd70f00cf25e9089744e64b6802056edde5a26bb84a9d6f9578490df6", transactionIndex: "73", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000003d776800ed851fb86044cd2ba0d380b1b86d14c70000000000000000000000000000000000000000033b2e3c9fd0803ce800000000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf6ec20064012c0000004d2416278ec580000000000000000000001b01000000000000000000000000000000000000000000000000000000000000a8a9fe9585768df900b92c6c35a3ab3fd07e561beaf5e6c49b1c4acd0385c61a5db93c61b411c91a55be729cedb5c82a454bff41c7dbf163676ad3d0894e373f0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000100000000000000000000000099c6a86ca56532441800ad2cb9fb449c7dc9177a0000000000000000000000000000000000000000033b2e3c9fd0803ce800000000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf6ea20064012c00000540b4d4fd0ffba0000000000000000000001c01000000000000000000000000000000000000000000000000000000000000d053418cff9bf75da9926c749ab5708fda950af71f1e6ac615df2e1688aa895e545a4b3cf2f16abc4f03029aedb9928f7676742534b2a51133039f6c4ffe72eb", contractAddress: "", cumulativeGasUsed: "3432206", gasUsed: "191429", confirmations: "745490"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1545487082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x99c6a86ca56532441800ad2cb9fb449c7dc9177a"}, {name: "taker", type: "address", value: "0x3d776800ed851fb86044cd2ba0d380b1b86d14c7"}, {name: "baseTokenAmount", type: "uint256", value: "1000000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "500000000000000000"}, {name: "makerFee", type: "uint256", value: "500000000000000"}, {name: "takerFee", type: "uint256", value: "1500000000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6932878", timeStamp: "1545487715", hash: "0xa0bb4430337599f752e57928e075386b0f1fe6420ab000136ad04c021f10e8b1", nonce: "26", blockHash: "0x5b060ebdc08d8c447a79c55f9530b3143b5d2a784fd97b9a8271663b46de45b9", transactionIndex: "95", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000dff43df7d233de46da4ed629163955b735471cd1000000000000000000000000000000000000000001be4409ad9dab361dbc0000000000000000000000000000000000000000000000000000047e04a4c85dea000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf71090064012c000000ca32c8b68f957c000000000000000000001c010000000000000000000000000000000000000000000000000000000000008b23ed643e858fc284ca6194f2579fa30712a34dc3ed81607c55a16d513eb65746bd13b5d307e01933dc48105310afc505c2907874d90257c12c5f1c80b0946a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000006ed4002e903c7057e261f2b69c4867ac83ea1d530000000000000000000000000000000000000000001c208f4b7afb7cee48000000000000000000000000000000000000000000000000000000487bb37fffcc000000000000000000000000000000000000000000000000000005666e940f0000010100005c1e52a60064012c00000415a7d921e06ff8000000000000000000001c0100000000000000000000000000000000000000000000000000000000000031b8cbb81143d09ede9c65849fed24b2bb1ea6ddbc09446a9d28d590670776e4639751fbc49e313561e8573c5e4f58ea067034c3cdc07f0eaae5222c8bf52072", contractAddress: "", cumulativeGasUsed: "4109156", gasUsed: "191621", confirmations: "745454"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1545487715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x6ed4002e903c7057e261f2b69c4867ac83ea1d53"}, {name: "taker", type: "address", value: "0xdff43df7d233de46da4ed629163955b735471cd1"}, {name: "baseTokenAmount", type: "uint256", value: "34003682000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "20402209200000000"}, {name: "makerFee", type: "uint256", value: "20402209200000"}, {name: "takerFee", type: "uint256", value: "61206627600000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6932893", timeStamp: "1545487995", hash: "0xc1b2ebe89b3c55a0d76d931ac78d89dcb4bbf9c5d15121e4d262ced635f8b002", nonce: "27", blockHash: "0xef56aa25cf7d4bce76d1c5f52f8bce8d9cabe8a02caeeeb0d3b7d1dfbbf304f3", transactionIndex: "103", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000cfce89648c011ce5370333e0ede554c018fe3734000000000000000000000000000000000000000000de76712e0da824ac0c0000000000000000000000000000000000000000000000000000023d482bfbc522000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf721d0064012c000004fc0c297abe3e20000000000000000000001c01000000000000000000000000000000000000000000000000000000000000974287c9964449d24a1c1ed726a6b703fcce84f83d33b19bc6cb414b478771c764f0ee2c0907545c422929d8277e99c0bc5309d92463a48a0850fa94a1d790e40000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000dff43df7d233de46da4ed629163955b735471cd1000000000000000000000000000000000000000001be4409ad9dab361dbc0000000000000000000000000000000000000000000000000000047e04a4c85dea000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf71090064012c000000ca32c8b68f957c000000000000000000001c010000000000000000000000000000000000000000000000000000000000008b23ed643e858fc284ca6194f2579fa30712a34dc3ed81607c55a16d513eb65746bd13b5d307e01933dc48105310afc505c2907874d90257c12c5f1c80b0946a", contractAddress: "", cumulativeGasUsed: "4809538", gasUsed: "170304", confirmations: "745439"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1545487995 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xdff43df7d233de46da4ed629163955b735471cd1"}, {name: "taker", type: "address", value: "0xcfce89648c011ce5370333e0ede554c018fe3734"}, {name: "baseTokenAmount", type: "uint256", value: "268940859000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "161364515400000000"}, {name: "makerFee", type: "uint256", value: "161364515400000"}, {name: "takerFee", type: "uint256", value: "484093546200000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12162668592156711485" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6932908", timeStamp: "1545488247", hash: "0xb1df641bfc0441f6dc07a811edf5803309e62c04f3a13f95f51b286985082028", nonce: "28", blockHash: "0x2b78572574fbd4e0c1774f2533c6b360491c7d2adfdcc90de1e146270398c2a5", transactionIndex: "119", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000cfce89648c011ce5370333e0ede554c018fe3734000000000000000000000000000000000000000000c3ad09341507948368000000000000000000000000000000000000000000000000000001f840c54c98fc000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf73460064012c000001a6e9a2570cc804000000000000000000001b01000000000000000000000000000000000000000000000000000000000000c3f44fa8e795f4eb25b45a37d0badf4a63b1c5aae83df2e2eff8116a9597993c22d05f78293dd753d2aa547b633c2ade6c750d3bfb31193fd3ef47121a1491c40000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000dff43df7d233de46da4ed629163955b735471cd1000000000000000000000000000000000000000001be4409ad9dab361dbc0000000000000000000000000000000000000000000000000000047e04a4c85dea000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf71090064012c000000ca32c8b68f957c000000000000000000001c010000000000000000000000000000000000000000000000000000000000008b23ed643e858fc284ca6194f2579fa30712a34dc3ed81607c55a16d513eb65746bd13b5d307e01933dc48105310afc505c2907874d90257c12c5f1c80b0946a", contractAddress: "", cumulativeGasUsed: "4451431", gasUsed: "170317", confirmations: "745424"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1545488247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xdff43df7d233de46da4ed629163955b735471cd1"}, {name: "taker", type: "address", value: "0xcfce89648c011ce5370333e0ede554c018fe3734"}, {name: "baseTokenAmount", type: "uint256", value: "236557674000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "141934604400000000"}, {name: "makerFee", type: "uint256", value: "141934604400000"}, {name: "takerFee", type: "uint256", value: "425803813200000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12161193512156711485" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6933257", timeStamp: "1545492744", hash: "0x0f1ccabec51526bbfef9716dd626bae4d926726fffd8fd318269452190aa58f7", nonce: "29", blockHash: "0xb8fec03fd33c60dd286c078b93a2099e13e08e3aae78d263a11d0077c6405bfe", transactionIndex: "131", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000006ed4002e903c7057e261f2b69c4867ac83ea1d53000000000000000000000000000000000000000000238a81c3ccc34af2d00000000000000000000000000000000000000000000000000000002dcb563cd1fc000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf84f30064012c000001190cc85716e284000000000000000000001b010000000000000000000000000000000000000000000000000000000000001006e5836ba7fa03a34ad4f988b8b7f08bab02e5cbf62b6775c0698765ab133952cb418a7609edd8178fec27cdbea092b6adcf04e78ef1e48ed598248d2c41be0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf000000000000000000000000000000000000000000039e7139a8c08fa06000000000000000000000000000000000000000000000000000000004a9b63844880000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf81d70064012c00000641aae1846ffd94000000000000000000001c000000000000000000000000000000000000000000000000000000000000004b5549209a12e1a91b71a8a35d9404c947b03f4558a12ccf58fc247764c4b0c1743d289deb3733d41cd7330dc8089e959d10c59c48c05002acb1566668990e12", contractAddress: "", cumulativeGasUsed: "4980438", gasUsed: "191907", confirmations: "745075"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1545492744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "taker", type: "address", value: "0x6ed4002e903c7057e261f2b69c4867ac83ea1d53"}, {name: "baseTokenAmount", type: "uint256", value: "42966484000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "12889945200000000"}, {name: "makerFee", type: "uint256", value: "12889945200000"}, {name: "takerFee", type: "uint256", value: "38669835600000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12161193512156711485" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6933270", timeStamp: "1545492913", hash: "0x09182a2e58b6fb0bf04dc902e5f7868e8484f59061dfadc41362426356bd3a90", nonce: "30", blockHash: "0x2fa85d661b495f9f00dcb0cc9bb7b4c509ad9d8c2e74266aad5cc3a1584b15aa", transactionIndex: "92", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000099c6a86ca56532441800ad2cb9fb449c7dc9177a000000000000000000000000000000000000000000165c91d6bf45af13300000000000000000000000000000000000000000000000000000001cd00d477684000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf855f0064012c000006f315aa903d9e70000000000000000000001b01000000000000000000000000000000000000000000000000000000000000c27fe62694a6ad37f1766348142fc68d23abe1f137c1c42b3eb64a003dd98e3c25b8a4c92d181a2233380f7b5f0286574172bbd974d1d9bdca9ba8892b3236770000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf000000000000000000000000000000000000000000039e7139a8c08fa06000000000000000000000000000000000000000000000000000000004a9b63844880000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf81d70064012c00000641aae1846ffd94000000000000000000001c000000000000000000000000000000000000000000000000000000000000004b5549209a12e1a91b71a8a35d9404c947b03f4558a12ccf58fc247764c4b0c1743d289deb3733d41cd7330dc8089e959d10c59c48c05002acb1566668990e12", contractAddress: "", cumulativeGasUsed: "4360713", gasUsed: "176832", confirmations: "745062"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1545492913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "taker", type: "address", value: "0x99c6a86ca56532441800ad2cb9fb449c7dc9177a"}, {name: "baseTokenAmount", type: "uint256", value: "27033516000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "8110054800000000"}, {name: "makerFee", type: "uint256", value: "8110054800000"}, {name: "takerFee", type: "uint256", value: "24330164400000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12159497064156711485" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6933388", timeStamp: "1545494871", hash: "0x6c9d66bec652c1d8d7699ddba08828f7b03ff67841aa7f11db82f3ac7e2e6bf9", nonce: "31", blockHash: "0xe34f53ac0bbb1450e45660b2f4ce94a34c478b9adc74af8741a124181dedab19", transactionIndex: "66", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000bea666caafc827bb02afee22186a31c25fe3f65d000000000000000000000000000000000000000000069e10de76676d080000000000000000000000000000000000000000000000000000000019945ca26200000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf8d180064012c000004a94359892a3680000000000000000000001c01000000000000000000000000000000000000000000000000000000000000b4c2f55d1a566b307633e7ae374f6e0b28556f2d5f8597bac43cf7103c54e0a66f6100d6551de813d72e0157b8d6d3d9f6e340f9563044de7dc91273f3ff30970000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f21340000000000000000000000000000000000000000019d971e4fe8401e74000000000000000000000000000000000000000000000000000000063eb89da4ed00000000000000000000000000000000000000000000000000000005666e940f000001010007b3cf5ff60064012c000003bfa9de782a6980000000000000000000001c01000000000000000000000000000000000000000000000000000000000000ed963ec633c9448ec0b48a106c2b69e4722faa9e7608009ef4719526078d0c9a7fccf2d049240c11b0d09dfddba7868f643d9adfbb92aff9772095685acf7bcf", contractAddress: "", cumulativeGasUsed: "3315939", gasUsed: "191352", confirmations: "744944"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1545494871 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "taker", type: "address", value: "0xbea666caafc827bb02afee22186a31c25fe3f65d"}, {name: "baseTokenAmount", type: "uint256", value: "8000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "7200000000000000"}, {name: "makerFee", type: "uint256", value: "7200000000000"}, {name: "takerFee", type: "uint256", value: "21600000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12159497064156711485" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6935088", timeStamp: "1545519803", hash: "0xf085d40c1295f358b5f0d41690f53c860acd956b03e3534d14b23227d7c1ede9", nonce: "32", blockHash: "0xf5365c3db946388a470bbb4ad8aa3500371cbd13e63eaf2ed0723fb3ba8ebf32", transactionIndex: "136", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f213400000000000000000000000000000000000000000073ce27351811f40c000000000000000000000000000000000000000000000000000000009536c7089100000000000000000000000000000000000000000000000000000005666e940f000001010007b3cfeea60064012c0000072fa04b1a509600000000000000000000001b0100000000000000000000000000000000000000000000000000000000000003a917c31ec68ed08284de4d44efd4e8b04eb58db751dd27b154958f820247a160800e3246150bce44ba3f0e7c598faa9f4dc5e8deb1f56ac312cd1fd98ebe6e0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf000000000000000000000000000000000000000000039e7139a8c08fa06000000000000000000000000000000000000000000000000000000004a9b63844880000000000000000000000000000000000000000000000000000005666e940f000001000007b3cf88590064012c00000533c052ef6eb384000000000000000000001c0000000000000000000000000000000000000000000000000000000000000055ce1cfa16eaf8df68d32c97a6b42d459e1c7374ad3ba205ba740f034ea1a6c35b2e44b0bd31937ce1120113a551a8232462c355f236cbf5a6959ba29549922a000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf000000000000000000000000000000000000000000039e7139a8c08fa06000000000000000000000000000000000000000000000000000000004a9b63844880000000000000000000000000000000000000000000000000000005666e940f000001000007b3cfd33e0064012c000003952d270ac44482000000000000000000001c00000000000000000000000000000000000000000000000000000000000000a668e0aa5b212df561aedde1dd48565dd83f67f23f8b14d9a0a669871b84a5165eae7652c12ac36a49b5696b7b302d2c74b5b70b15835407ae1ed37939d986e9", contractAddress: "", cumulativeGasUsed: "4526788", gasUsed: "284388", confirmations: "743244"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1545519803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "taker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "baseTokenAmount", type: "uint256", value: "70000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "21000000000000000"}, {name: "makerFee", type: "uint256", value: "21000000000000"}, {name: "takerFee", type: "uint256", value: "63000000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "taker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "baseTokenAmount", type: "uint256", value: "70000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "21000000000000000"}, {name: "makerFee", type: "uint256", value: "21000000000000"}, {name: "takerFee", type: "uint256", value: "63000000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12159497064156711485" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6935771", timeStamp: "1545530167", hash: "0x9c86fb25d730f9d86928e5931e9a283ecce8fb91fbb91257a3b0ef23c7e208d1", nonce: "33", blockHash: "0xe7be61b1f4b07be8b3e910f75f505d1c5907a8d0f1a70f58b4887b4d7711e894", transactionIndex: "49", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "9900000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000fd26f25d6588b752a90e600aff038a654d64a42c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ab97eab74f56f60000000000000000000000000000000000000000000000000000034fa611f7d557cb01000107b3d0172d0064012c0000007c716840a71002000000000000000000001b01000000000000000000000000000000000000000000000000000000000000513a93349b4e355b478777722b71bde2bc619ed096497d5e80ed4889c7591b3f06a4a8e515b5f504135ebbf6ab6c2933d06c27a402a9ca3abf4f7bb01549e6250000000000000000000000000000000000000000000000000000000000000180000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a6c75ad003fa6fcaa0c353ddfac458d928ea9c0e00000000000000000000000000000000000000000000000193d7f7d253de00000000000000000000000000000000000000000000000000c496fe19496d210000000000000000000000000000000000000000000000000000034fa611f7d557cb010100035b52e2ef0064012c000003dced0d3f6928fe000000000000000000001c000000000000000000000000000000000000000000000000000000000000002cda20ef95580fe690ae7238c9c7ae2cc3e1430a50d8c6d9ba7a9a660c468053231f184825ef06f559da9918d32ec68cce02c8ab40209b71712debf91ffbfae8", contractAddress: "", cumulativeGasUsed: "1741152", gasUsed: "187181", confirmations: "742561"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545530167 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "quoteToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xa6c75ad003fa6fcaa0c353ddfac458d928ea9c0e"}, {name: "taker", type: "address", value: "0xfd26f25d6588b752a90e600aff038a654d64a42c"}, {name: "baseTokenAmount", type: "uint256", value: "25399935804846734071"}, {name: "quoteTokenAmount", type: "uint256", value: "3165340000000000000000"}, {name: "makerFee", type: "uint256", value: "3165340000000000000"}, {name: "takerFee", type: "uint256", value: "8546418000000000000"}, {name: "makerGasFee", type: "uint256", value: "238591901376534475"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "238591901376534475"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12159497064156711485" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6935779", timeStamp: "1545530273", hash: "0x60eb5f8dd4a213932de2d7f2ae8a44315942b76dd7acbd0f1ce7a6c8fb664bb3", nonce: "34", blockHash: "0x9e540442f08998a39ab24b0c03f87812efedf2f8238cbe1b59d8d2ae53cccf6e", transactionIndex: "161", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "1000000", gasPrice: "9900000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000fd26f25d6588b752a90e600aff038a654d64a42c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b62e1c2b9e80ff0000000000000000000000000000000000000000000000000000035588d3ddc574ff01000107b3d017850064012c000003bdc6120045f800000000000000000000001c01000000000000000000000000000000000000000000000000000000000000e16bcdc4d06a08e109b90da23ba3ce3d501ef8f38a0b1415f1d83f7b4e041f015f5623b558c2f3a54cd9cf0e8ca18b25c338325e927572a6ce23edc22e6bb7230000000000000000000000000000000000000000000000000000000000000180000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000a6c75ad003fa6fcaa0c353ddfac458d928ea9c0e0000000000000000000000000000000000000000000000014093af9c6786000000000000000000000000000000000000000000000000009bb15365deb7b58000000000000000000000000000000000000000000000000000035588d3ddc574ff0101000740b98b420064012c0000068d0444b68273e0000000000000000000001c000000000000000000000000000000000000000000000000000000000000002010f9568508da0cf7a499c541037da6f1b1a5722a7eef598f3846f2ec7e121c5a79a5818d9e21967e949be58ad8cfa7900b7c50308eb01be7f2874835022f7c00000000000000000000000083671580fd3ea9a970747df985e36f048fc3cdb900000000000000000000000000000000000000000000000004db732547630000000000000000000000000000000000000000000000000018aa64b94e82bc00000000000000000000000000000000000000000000000000000339feb59bd9121e01010007b3ce0b880064012c00640434046e8c4644fc000000000000000000001c01000000000000000000000000000000000000000000000000000000000000b6c47896d2f829db7cc857b41e9edcb0f5aa3ea43af033f2b969ccd360b0214e696421b41110adf00292902c9a417bacc05df7a1a022736e0e0415dce1f9a8ba", contractAddress: "", cumulativeGasUsed: "6998579", gasUsed: "301413", confirmations: "742553"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545530273 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "quoteToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xa6c75ad003fa6fcaa0c353ddfac458d928ea9c0e"}, {name: "taker", type: "address", value: "0xfd26f25d6588b752a90e600aff038a654d64a42c"}, {name: "baseTokenAmount", type: "uint256", value: "23100000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "2872023000000000000000"}, {name: "makerFee", type: "uint256", value: "2872023000000000000"}, {name: "takerFee", type: "uint256", value: "7754462100000000000"}, {name: "makerGasFee", type: "uint256", value: "240248598674371839"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "240248598674371839"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "quoteToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x83671580fd3ea9a970747df985e36f048fc3cdb9"}, {name: "taker", type: "address", value: "0xfd26f25d6588b752a90e600aff038a654d64a42c"}, {name: "baseTokenAmount", type: "uint256", value: "350000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "455000000000000000000"}, {name: "makerFee", type: "uint256", value: "0"}, {name: "takerFee", type: "uint256", value: "1228500000000000000"}, {name: "makerGasFee", type: "uint256", value: "232496911743521310"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12159497064156711485" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6936846", timeStamp: "1545546065", hash: "0xf18723b05d25b252ae6ce09150f0d8d6ab779bd7e02bb740dfbf41f8ec0bb0e0", nonce: "35", blockHash: "0xa5a54c49667fc2d1f4a370d2a625a6c43a1cfb5c5d265124df937b7dde504f1d", transactionIndex: "104", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d0000000000000000000000009b601497296dab50349a32cb42dd793d45fc49960000000000000000000000000000000000000000004e03696202fa7bf2f400000000000000000000000000000000000000000000000000000043034fdde9ca000000000000000000000000000000000000000000000000000005666e940f000001010007b3d055510064012c000003d4ab3c5e68467e000000000000000000001b010000000000000000000000000000000000000000000000000000000000005090dcdd9496aa7a371882228cbb7ccfda5f87b16d2013cc0b76d6262e2e709915d985d3ef6a17742e19e07294503cca0dfc17fd2e53ed1c8494df200dc34fea0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f2134000000000000000000000000000000000000000000bafff027f7b505e710000000000000000000000000000000000000000000000000000000a0a1ae84e9c8000000000000000000000000000000000000000000000000000005666e940f000001000007b3cffeb90064012c0000057fe62554aae97c000000000000000000001c01000000000000000000000000000000000000000000000000000000000000f3da1b8aac3c9d2017660c97fd2cb89a945e24f1c16606a95acda81103ff89f418c2663f452495e0b61208be905c6f6b51d3f66978766e8efddf48bee54321cf", contractAddress: "", cumulativeGasUsed: "4188811", gasUsed: "185136", confirmations: "741486"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545546065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "taker", type: "address", value: "0x9b601497296dab50349a32cb42dd793d45fc4996"}, {name: "baseTokenAmount", type: "uint256", value: "94312325000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "18862465000000000"}, {name: "makerFee", type: "uint256", value: "18862465000000"}, {name: "takerFee", type: "uint256", value: "56587395000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12159497064156711485" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6937802", timeStamp: "1545560040", hash: "0x99044f27eb35bd79394812a726f42ef4f4a39c61806f8c052ae5fc94e9e78c48", nonce: "36", blockHash: "0x5101a7cfd99cc4a5b51cad6a39a706b5549cd6e8136d7cc128c741d480ba73d7", transactionIndex: "43", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf0000000000000000000000000000000000000000000108b2a2c28029094000000000000000000000000000000000000000000000000000000000e35fa931a00000000000000000000000000000000000000000000000000000005666e940f000001010007b3d08bd90064012c000002b7f0836f3f3a84000000000000000000001b000000000000000000000000000000000000000000000000000000000000007d7fb490acf3d88e711d3b8f122e008362f4d3e9f3d8f3dd5923fa9db08b05d776a87af357d24b7f7d03ac40f7d1fef085f93d09268766d015d9b859f2a492200000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f2134000000000000000000000000000000000000000000bafff027f7b505e710000000000000000000000000000000000000000000000000000000a0a1ae84e9c8000000000000000000000000000000000000000000000000000005666e940f000001000007b3cffeb90064012c0000057fe62554aae97c000000000000000000001c01000000000000000000000000000000000000000000000000000000000000f3da1b8aac3c9d2017660c97fd2cb89a945e24f1c16606a95acda81103ff89f418c2663f452495e0b61208be905c6f6b51d3f66978766e8efddf48bee54321cf", contractAddress: "", cumulativeGasUsed: "2480212", gasUsed: "170282", confirmations: "740530"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1545560040 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "taker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "baseTokenAmount", type: "uint256", value: "20000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "4000000000000000"}, {name: "makerFee", type: "uint256", value: "4000000000000"}, {name: "takerFee", type: "uint256", value: "12000000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12159497064156711485" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6939619", timeStamp: "1545586338", hash: "0xfa31f1cf0492c7077ec4ac381bcad793ff81a4ded191b9a10fa021994952898f", nonce: "37", blockHash: "0x2ba5152d9ee0deeb8a584b68e248c5276fd6c8255d33e80cff90b3a23803fd2b", transactionIndex: "191", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000f871f1a8c4dc66bef60b02b1a848a131001f2134000000000000000000000000000000000000000002f24d18df02712fcef400000000000000000000000000000000000000000000000000000287f09454c7ca000000000000000000000000000000000000000000000000000005666e940f000001010007b3d0f2920064012c000007a27b827dc7971c000000000000000000001b0100000000000000000000000000000000000000000000000000000000000009e6a13dbff14592b2fd2a9ab7e7f55ec59486484e85719a1c06ba64c08d852c7a12d817c60032244aee8039f9e22dacc9f395c60a40edcae76eac97c383d5070000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf000000000000000000000000000000000000000000018d0bf423c03d8de000000000000000000000000000000000000000000000000000000001550f7dca700000000000000000000000000000000000000000000000000000005666e940f000001000007b3d08c5d0064012c0000067c951a8ada6a1c000000000000000000001b00000000000000000000000000000000000000000000000000000000000000f1c9b2ad0600b5787cfaabbcd18e6bec6f9188f2b583247b9217d1e4975e2a2541bc780349903535ad4dbba2fcb4c2699892a4d8ad2c9d33e72b5975e1886907000000000000000000000000d490b498dea6e097b976bd9639d9a0e92fd90ffc00000000000000000000000000000000000000000005a66a94a4c199bb3000000000000000000000000000000000000000000000000000000004da76509858000000000000000000000000000000000000000000000000000005666e940f000001000007b3d0bcdc0064012c0000008fc63e1320847c000000000000000000001c0100000000000000000000000000000000000000000000000000000000000057be3d9dcbdfed5de11671aeead99ea2cbb37f8da79a7869923fd9357be5d1a37feb808c68819e5c1bb6328a6d0d137e9d03afae17bd94296979ee0ab602119c", contractAddress: "", cumulativeGasUsed: "5727874", gasUsed: "284149", confirmations: "738713"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545586338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "taker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "baseTokenAmount", type: "uint256", value: "30000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "6000000000000000"}, {name: "makerFee", type: "uint256", value: "6000000000000"}, {name: "takerFee", type: "uint256", value: "18000000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xd490b498dea6e097b976bd9639d9a0e92fd90ffc"}, {name: "taker", type: "address", value: "0xf871f1a8c4dc66bef60b02b1a848a131001f2134"}, {name: "baseTokenAmount", type: "uint256", value: "6830508000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "1366101600000000"}, {name: "makerFee", type: "uint256", value: "1366101600000"}, {name: "takerFee", type: "uint256", value: "4098304800000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6939832", timeStamp: "1545589623", hash: "0x0412fa724b74ae8f1e0263bc8e818bfa2ec3eb2ad112f5f0d55a529d64f6d261", nonce: "38", blockHash: "0xb1464bac7a3821e1de8fe0ace6ca94935826370348c743ae88d689583bfe8acd", transactionIndex: "22", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000f84eab079fa7bc64bf5ec60e1768e988eb36eaf000000000000000000000000000000000000000000018d0bf423c03d8de000000000000000000000000000000000000000000000000000000000aa87bee5380000000000000000000000000000000000000000000000000000005666e940f000001010007b3d0ff540064012c000007bfdfbd06452698000000000000000000001c000000000000000000000000000000000000000000000000000000000000003a966d448052e5695b3edc23d25b933880147e58fcb3419550b20dad56b0d453640cdd031fd7e92ec13bafa2325d647020bd5cd520cbab7d3572d8317e1623880000000000000000000000000000000000000000000000000000000000000180000000000000000000000000e7d7b37e72510309db27c460378f957b1b04bd5d000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000cd095e54b771850f5b5a50457e6769a8ab12e0f800000000000000000000000000000000000000000052b7d2dcc80cd2e4000000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000005666e940f000001000007b3ce74ba0064012c000002696d9e50d54d88000000000000000000001c01000000000000000000000000000000000000000000000000000000000000f9919b991414a1aea029c9641110038cd92bbcb5fc42c5edc28fb964a95b932b2bb0d16f4553048f1029aaa38b1d219670245147d256a7ad973d06b260eb9a3e", contractAddress: "", cumulativeGasUsed: "1144839", gasUsed: "186233", confirmations: "738500"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545589623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0xe7d7b37e72510309db27c460378f957b1b04bd5d"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xcd095e54b771850f5b5a50457e6769a8ab12e0f8"}, {name: "taker", type: "address", value: "0xf84eab079fa7bc64bf5ec60e1768e988eb36eaf0"}, {name: "baseTokenAmount", type: "uint256", value: "30000000000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "3000000000000000"}, {name: "makerFee", type: "uint256", value: "2700000000000"}, {name: "takerFee", type: "uint256", value: "9000000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941299", timeStamp: "1545611142", hash: "0x92229afc3482f79847b42b6e44aec48b7e1bf687983ed938c8eaefc3119b3cd4", nonce: "39", blockHash: "0xf3949235962c159378669a533e7ec6a878be7377f7edc0691c7a995cb2ebfc01", transactionIndex: "98", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a30000000000000000000000000000000000000000000002196282b2accf44000000000000000000000000000000000000000000000000000093edf84c61eda8000000000000000000000000000000000000000000000000000005666e940f000001000006044b89120064012c000007a1d7ab25200408000000000000000000001c00000000000000000000000000000000000000000000000000000000000000b5e43a297e7818fbe0c885bebf7938bc318a28f12b0c1cb316099e11ab6f243e54ae2fbbd6dcbeac10effeeda9a41e154398a1b3ce751ff85462f4fca9e871de00000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005ccec5d16f6cc00000000000000000000000000000000000000000000000000000005666e940f000001010007b3d153610064012c000004d594a9eaeccafe000000000000000000001c0000000000000000000000000000000000000000000000000000000000000012b7e1d2b3a39341a9022cb015bfdc3c347a19e69dbca95880721f5945470d2239aa8d34a11570d68b5f1773f87868022d526c0650542a929ad0a1ecd0a0e96a", contractAddress: "", cumulativeGasUsed: "5007325", gasUsed: "179560", confirmations: "737033"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545611142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "9913000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "10606910000000000000"}, {name: "makerFee", type: "uint256", value: "10606910000000000"}, {name: "takerFee", type: "uint256", value: "31820730000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941299", timeStamp: "1545611142", hash: "0xa1d9eb7a6adb192b658f76018fdd3c51a0b6c259c5be917c137b04202c35e0dc", nonce: "40", blockHash: "0xf3949235962c159378669a533e7ec6a878be7377f7edc0691c7a995cb2ebfc01", transactionIndex: "99", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a30000000000000000000000000000000000000000000003182c1cfd01ff340000000000000000000000000000000000000000000000000000d9f1ea662242d8000000000000000000000000000000000000000000000000000005666e940f000001000002bf5889c70064012c00000504d93c9231fb80000000000000000000001b00000000000000000000000000000000000000000000000000000000000000163f7de0849280caaee3a7b677cefa50c949899648ab6583b3c4a7d84e014fc63dffb255b0644cf55c9737ded09d758367566c73d8e5235e449975ea16cebd6700000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005ccec5d16f6cc00000000000000000000000000000000000000000000000000000005666e940f000001010007b3d153610064012c000004d594a9eaeccafe000000000000000000001c0000000000000000000000000000000000000000000000000000000000000012b7e1d2b3a39341a9022cb015bfdc3c347a19e69dbca95880721f5945470d2239aa8d34a11570d68b5f1773f87868022d526c0650542a929ad0a1ecd0a0e96a", contractAddress: "", cumulativeGasUsed: "5171861", gasUsed: "164536", confirmations: "737033"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545611142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "14613000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "15635910000000000000"}, {name: "makerFee", type: "uint256", value: "15635910000000000"}, {name: "takerFee", type: "uint256", value: "46907730000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941299", timeStamp: "1545611142", hash: "0xe93c79c2f1831b8b4bdac72f3898d3256c9feae5f3262f06db0addc02a5db8e7", nonce: "41", blockHash: "0xf3949235962c159378669a533e7ec6a878be7377f7edc0691c7a995cb2ebfc01", transactionIndex: "100", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "1500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005ccec5d16f6cc00000000000000000000000000000000000000000000000000000005666e940f000001010007b3d153610064012c000004d594a9eaeccafe000000000000000000001c0000000000000000000000000000000000000000000000000000000000000012b7e1d2b3a39341a9022cb015bfdc3c347a19e69dbca95880721f5945470d2239aa8d34a11570d68b5f1773f87868022d526c0650542a929ad0a1ecd0a0e96a00000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000300000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a300000000000000000000000000000000000000000000034f086f3b33b6840000000000000000000000000000000000000000000000000000e9dcc6cf72cb28000000000000000000000000000000000000000000000000000005666e940f0000010000028e96562d0064012c000005b67feba796629c000000000000000000001b00000000000000000000000000000000000000000000000000000000000000ed5ab1f0f287d12df93758e7f9717f3178933bb37526b7ede2b1cd899b748378603984fdde232e23c50a04b9431d97131859ab6c5d4f66f62d4b753b8d57202600000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a30000000000000000000000000000000000000000000002b505a3ab7711c00000000000000000000000000000000000000000000000000000beaa9bb1859880000000000000000000000000000000000000000000000000000005666e940f0000010000064d931d500064012c000005324c973d80327c000000000000000000001b000000000000000000000000000000000000000000000000000000000000002dd650de931230620a5c5d61120abca7a625474f6efbe467d9c4fd617ac0d8e17504fe48ff0fe45e7f2088371d763b39b4fe95ec75e7b7b84a7061f094008c9e00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a3000000000000000000000000000000000000000000000220eb85e638b2900000000000000000000000000000000000000000000000000000959cfd322f3020000000000000000000000000000000000000000000000000000005666e940f00000100000358a264380064012c0000065f51c35977c274000000000000000000001b000000000000000000000000000000000000000000000000000000000000008f6d0fba4a1ad49f21fd3829575996b582b1a7a814a6d648daf9b380dbefa95d706018e285ad01e1d531e19a0ed2742325c62626a825ff3b47ea81a5bbe8000a", contractAddress: "", cumulativeGasUsed: "5518656", gasUsed: "346795", confirmations: "737033"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545611142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "taker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "baseTokenAmount", type: "uint256", value: "15625000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "16851562500000000000"}, {name: "makerFee", type: "uint256", value: "16851562500000000"}, {name: "takerFee", type: "uint256", value: "50554687500000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "taker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "baseTokenAmount", type: "uint256", value: "12784000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "13738964800000000000"}, {name: "makerFee", type: "uint256", value: "13738964800000000"}, {name: "takerFee", type: "uint256", value: "41216894400000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "taker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "baseTokenAmount", type: "uint256", value: "10052000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "10780770000000000000"}, {name: "makerFee", type: "uint256", value: "10780770000000000"}, {name: "takerFee", type: "uint256", value: "32342310000000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941299", timeStamp: "1545611142", hash: "0x7315d96bfa32b1385b6d1b28370af4e5ae34d76a116a67e27471fc541f07fca0", nonce: "42", blockHash: "0xf3949235962c159378669a533e7ec6a878be7377f7edc0691c7a995cb2ebfc01", transactionIndex: "101", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a300000000000000000000000000000000000000000000039651b9b8088d300000000000000000000000000000000000000000000000000000fc767dbe0b81a0000000000000000000000000000000000000000000000000000005666e940f000001000006b5ac2d420064012c00000319ddab83031780000000000000000000001c00000000000000000000000000000000000000000000000000000000000000fdddc5aab08a63da3a237d66fc1e3c9c3f3fa07d5cc530e7ea977a3026b2179455391fe3be361fabf9b67d7592d9668d33d7fac2ecc269193254ce3a2391f85100000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005ccec5d16f6cc00000000000000000000000000000000000000000000000000000005666e940f000001010007b3d153610064012c000004d594a9eaeccafe000000000000000000001c0000000000000000000000000000000000000000000000000000000000000012b7e1d2b3a39341a9022cb015bfdc3c347a19e69dbca95880721f5945470d2239aa8d34a11570d68b5f1773f87868022d526c0650542a929ad0a1ecd0a0e96a", contractAddress: "", cumulativeGasUsed: "5683192", gasUsed: "164536", confirmations: "737033"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545611142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "16940000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "18125800000000000000"}, {name: "makerFee", type: "uint256", value: "18125800000000000"}, {name: "takerFee", type: "uint256", value: "54377400000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941299", timeStamp: "1545611142", hash: "0x4a12bdd9a564df0e951ddd34223caed7858eb2d2c7029a3e2e6768741046ea66", nonce: "43", blockHash: "0xf3949235962c159378669a533e7ec6a878be7377f7edc0691c7a995cb2ebfc01", transactionIndex: "102", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a300000000000000000000000000000000000000000000024d27cc42de41500000000000000000000000000000000000000000000000000000a2a9d8e8e55520000000000000000000000000000000000000000000000000000005666e940f0000010000060564d6110064012c000002b53ee50c0b4e00000000000000000000001c000000000000000000000000000000000000000000000000000000000000008520a4aa185690f75098a7ee0ce6361e94d008ca4f53533a89e531eb16e173a018e1b43bab3a10ed8b093d86e1cbc38af155a13a8993631a3deefcb96638949100000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005ccec5d16f6cc00000000000000000000000000000000000000000000000000000005666e940f000001010007b3d153610064012c000004d594a9eaeccafe000000000000000000001c0000000000000000000000000000000000000000000000000000000000000012b7e1d2b3a39341a9022cb015bfdc3c347a19e69dbca95880721f5945470d2239aa8d34a11570d68b5f1773f87868022d526c0650542a929ad0a1ecd0a0e96a", contractAddress: "", cumulativeGasUsed: "5847664", gasUsed: "164472", confirmations: "737033"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545611142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "10868000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "11628760000000000000"}, {name: "makerFee", type: "uint256", value: "11628760000000000"}, {name: "takerFee", type: "uint256", value: "34886280000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941299", timeStamp: "1545611142", hash: "0x7e94dbaa9b73f3a4ace59e25d0052ad60b5cb317ab32e4636e6ea81ab9402adc", nonce: "44", blockHash: "0xf3949235962c159378669a533e7ec6a878be7377f7edc0691c7a995cb2ebfc01", transactionIndex: "103", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a30000000000000000000000000000000000000000000002220ef4e2f56dc40000000000000000000000000000000000000000000000000000964678a40a32b0000000000000000000000000000000000000000000000000000005666e940f0000010000064312ba220064012c00000120d42c3103dd80000000000000000000001b000000000000000000000000000000000000000000000000000000000000005abe6fac5f25196200a9de1ca4c2a074354505ff0c4e8f768acf76815e2e5bf574143e5d22e2c879872c5d2b6de230d45e6ba967afd261b99d312004fb74124e00000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005ccec5d16f6cc00000000000000000000000000000000000000000000000000000005666e940f000001010007b3d153610064012c000004d594a9eaeccafe000000000000000000001c0000000000000000000000000000000000000000000000000000000000000012b7e1d2b3a39341a9022cb015bfdc3c347a19e69dbca95880721f5945470d2239aa8d34a11570d68b5f1773f87868022d526c0650542a929ad0a1ecd0a0e96a", contractAddress: "", cumulativeGasUsed: "6012149", gasUsed: "164485", confirmations: "737033"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545611142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "9205000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "9849350000000000000"}, {name: "makerFee", type: "uint256", value: "9849350000000000"}, {name: "takerFee", type: "uint256", value: "29548050000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941420", timeStamp: "1545612998", hash: "0x41e667c711b94db00a8b2e5d773095c6f2e8a08846bbc1c1105b0fb21a13abf3", nonce: "45", blockHash: "0x2f1dee7964bf3817f11a0cbfc5fc4359aec4d9d93e9e952f4949c36b82a7a484", transactionIndex: "112", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005b12aefafa80400000000000000000000000000000000000000000000000000000005666e940f000001010007b3d15aac0064012c000001386af52d251900000000000000000000001c00000000000000000000000000000000000000000000000000000000000000a44c2c89c6467bb2a7e63fc32a9f1302c82e70fbc282745952d1b1a600beaad81536705bd81d3ef063971f49d07b8efa05e4c3f451a7ad779d41181b4e77dba100000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd000000000000000000000000000000000000000000000000000000000000000200000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a3000000000000000000000000000000000000000000000255e21f29da87340000000000000000000000000000000000000000000000000000a3a26a866d3918000000000000000000000000000000000000000000000000000005666e940f000001000003eeef3b0b0064012c00000732c7f2e9218c88000000000000000000001c000000000000000000000000000000000000000000000000000000000000001db732cd76ee523a05a93bdb8e77355a27e61b19bdf9ea3ef52a0b81bede339762c6eec1157ab6e4c8a9a35cf23c88a216d242377ee81c731030863fb3cc960100000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a3000000000000000000000000000000000000000000000332a079437915d40000000000000000000000000000000000000000000000000000de64e1657744a0000000000000000000000000000000000000000000000000000005666e940f000001000007bc02e1be0064012c0000022897ead35176f8000000000000000000001c0000000000000000000000000000000000000000000000000000000000000001463b422c796cbae2782fce531c23edd90902b749d674ab385dbca970a14111290a9d9cec8491b274a6209603fc7eca469bd06cb81852cdad06b9f47ed4b425", contractAddress: "", cumulativeGasUsed: "5655367", gasUsed: "270297", confirmations: "736912"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545612998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "taker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "baseTokenAmount", type: "uint256", value: "11029000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "11791103900000000000"}, {name: "makerFee", type: "uint256", value: "11791103900000000"}, {name: "takerFee", type: "uint256", value: "35373311700000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}, {name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "taker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "baseTokenAmount", type: "uint256", value: "15101000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "16025181200000000000"}, {name: "makerFee", type: "uint256", value: "16025181200000000"}, {name: "takerFee", type: "uint256", value: "48075543600000000"}, {name: "makerGasFee", type: "uint256", value: "1520000000000000"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "0"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941420", timeStamp: "1545612998", hash: "0xdfc03cef53b2eddc81a525b2379aef16982fcfa7217d958e4b9bcd142d4d17ff", nonce: "46", blockHash: "0x2f1dee7964bf3817f11a0cbfc5fc4359aec4d9d93e9e952f4949c36b82a7a484", transactionIndex: "113", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a3000000000000000000000000000000000000000000000212b78aea5b623800000000000000000000000000000000000000000000000000009042896f0e5ee0000000000000000000000000000000000000000000000000000005666e940f00000100000169fbaf8e0064012c000006975fe2723a33f4000000000000000000001c0000000000000000000000000000000000000000000000000000000000000072687446b2ec8e32ffabb3494042b68eb05e4d7f42bebf6bdd817f63dab1b6f31719e229a212ff4d2c5999112ab56a0bc96aac79c4c13258d47155e8ee39dbc200000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005b12aefafa80400000000000000000000000000000000000000000000000000000005666e940f000001010007b3d15aac0064012c000001386af52d251900000000000000000000001c00000000000000000000000000000000000000000000000000000000000000a44c2c89c6467bb2a7e63fc32a9f1302c82e70fbc282745952d1b1a600beaad81536705bd81d3ef063971f49d07b8efa05e4c3f451a7ad779d41181b4e77dba1", contractAddress: "", cumulativeGasUsed: "5819775", gasUsed: "164408", confirmations: "736912"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545612998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "9790000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "10279500000000000000"}, {name: "makerFee", type: "uint256", value: "10279500000000000"}, {name: "takerFee", type: "uint256", value: "30838500000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941420", timeStamp: "1545612998", hash: "0xabfaabbec7e5d162fb65162f476c22ae9f0bc621afa7897a79e49227f086e306", nonce: "47", blockHash: "0x2f1dee7964bf3817f11a0cbfc5fc4359aec4d9d93e9e952f4949c36b82a7a484", transactionIndex: "114", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a300000000000000000000000000000000000000000000031041f4ca8c882c0000000000000000000000000000000000000000000000000000d49d89c81f8b90000000000000000000000000000000000000000000000000000005666e940f0000010000035cfd803c0064012c0000016c620d336c3e04000000000000000000001b00000000000000000000000000000000000000000000000000000000000000ec291b9f2454da7bf6edaab52dc3ec793350d79cf992d0bd450fe1f69ac7ac23524a47ca8682dc204177fd7c8f5c97659201ea7edf425493ecf41dcc03b46a4000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005b12aefafa80400000000000000000000000000000000000000000000000000000005666e940f000001010007b3d15aac0064012c000001386af52d251900000000000000000000001c00000000000000000000000000000000000000000000000000000000000000a44c2c89c6467bb2a7e63fc32a9f1302c82e70fbc282745952d1b1a600beaad81536705bd81d3ef063971f49d07b8efa05e4c3f451a7ad779d41181b4e77dba1", contractAddress: "", cumulativeGasUsed: "5984183", gasUsed: "164408", confirmations: "736912"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545612998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "14467000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "15190350000000000000"}, {name: "makerFee", type: "uint256", value: "15190350000000000"}, {name: "takerFee", type: "uint256", value: "45571050000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941420", timeStamp: "1545612998", hash: "0x0c3ef1fc3990a4d6fc9f5d5b1ccd5b786e643effdb243e1cef754abe6024bdad", nonce: "48", blockHash: "0x2f1dee7964bf3817f11a0cbfc5fc4359aec4d9d93e9e952f4949c36b82a7a484", transactionIndex: "115", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a30000000000000000000000000000000000000000000002ab43a335255f700000000000000000000000000000000000000000000000000000b93c5439233740000000000000000000000000000000000000000000000000000005666e940f000001000001cbdf9b1f0064012c0000037a76b15191eb7c000000000000000000001c00000000000000000000000000000000000000000000000000000000000000f31276a4ec747758071e13cfcb2dcda5562813b19c6a2559faabeee712a7cafa6e03ec1aed2ad05012120379e5ed310dd63aaae03dc3ff9c911d524fe7a41f0b00000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005b12aefafa80400000000000000000000000000000000000000000000000000000005666e940f000001010007b3d15aac0064012c000001386af52d251900000000000000000000001c00000000000000000000000000000000000000000000000000000000000000a44c2c89c6467bb2a7e63fc32a9f1302c82e70fbc282745952d1b1a600beaad81536705bd81d3ef063971f49d07b8efa05e4c3f451a7ad779d41181b4e77dba1", contractAddress: "", cumulativeGasUsed: "6148591", gasUsed: "164408", confirmations: "736912"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545612998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "12604000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "13234200000000000000"}, {name: "makerFee", type: "uint256", value: "13234200000000000"}, {name: "takerFee", type: "uint256", value: "39702600000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6941420", timeStamp: "1545612998", hash: "0xc036d161f6f2b659e26a880e505aaa8362a2a6061a648ac16f8f29635c6cb8ae", nonce: "49", blockHash: "0x2f1dee7964bf3817f11a0cbfc5fc4359aec4d9d93e9e952f4949c36b82a7a484", transactionIndex: "116", from: "0x49497a4d914ae91d34ce80030fe620687bf333fd", to: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x8d10883d00000000000000000000000088fb562bea77bd8844beaef5ca1d2403381378a300000000000000000000000000000000000000000000023453c56574c86800000000000000000000000000000000000000000000000000009986a1675d3a30000000000000000000000000000000000000000000000000000005666e940f000001000005d6267cd20064012c000004cd7bf267aa2218000000000000000000001c00000000000000000000000000000000000000000000000000000000000000d04f64e0ca00a737c35ba0631cde75ee47378a7cac73ff400bcbf60c8ef151687d80d71b3044b8dfb3c70653c8bbb87dcb4b0e5037cbddce14369ab59512453100000000000000000000000000000000000000000000000000000000000001800000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000049497a4d914ae91d34ce80030fe620687bf333fd0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f39d30fa570db7940e5b3a3e42694665a1449e4b00000000000000000000000000000000000000000000152d02c7e14af6800000000000000000000000000000000000000000000000000005b12aefafa80400000000000000000000000000000000000000000000000000000005666e940f000001010007b3d15aac0064012c000001386af52d251900000000000000000000001c00000000000000000000000000000000000000000000000000000000000000a44c2c89c6467bb2a7e63fc32a9f1302c82e70fbc282745952d1b1a600beaad81536705bd81d3ef063971f49d07b8efa05e4c3f451a7ad779d41181b4e77dba1", contractAddress: "", cumulativeGasUsed: "6312935", gasUsed: "164344", confirmations: "736912"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545612998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "baseToken", type: "address"}, {indexed: false, name: "quoteToken", type: "address"}, {indexed: false, name: "relayer", type: "address"}, {indexed: false, name: "maker", type: "address"}, {indexed: false, name: "taker", type: "address"}, {indexed: false, name: "baseTokenAmount", type: "uint256"}, {indexed: false, name: "quoteTokenAmount", type: "uint256"}, {indexed: false, name: "makerFee", type: "uint256"}, {indexed: false, name: "takerFee", type: "uint256"}, {indexed: false, name: "makerGasFee", type: "uint256"}, {indexed: false, name: "makerRebate", type: "uint256"}, {indexed: false, name: "takerGasFee", type: "uint256"}], name: "Match", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Match", events: [{name: "baseToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "quoteToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "relayer", type: "address", value: "0x49497a4d914ae91d34ce80030fe620687bf333fd"}, {name: "maker", type: "address", value: "0xf39d30fa570db7940e5b3a3e42694665a1449e4b"}, {name: "taker", type: "address", value: "0x88fb562bea77bd8844beaef5ca1d2403381378a3"}, {name: "baseTokenAmount", type: "uint256", value: "10410000000000000000000"}, {name: "quoteTokenAmount", type: "uint256", value: "10930500000000000000"}, {name: "makerFee", type: "uint256", value: "10930500000000000"}, {name: "takerFee", type: "uint256", value: "32791500000000000"}, {name: "makerGasFee", type: "uint256", value: "0"}, {name: "makerRebate", type: "uint256", value: "0"}, {name: "takerGasFee", type: "uint256", value: "1520000000000000"}], address: "0x2cb4b49c0d6e9db2164d94ce48853bf77c4d883e"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "12157907984156711485" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
