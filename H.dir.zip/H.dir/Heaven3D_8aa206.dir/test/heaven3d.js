const Heaven3D = artifacts.require( "./Heaven3D.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Heaven3D" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x51F835D5671DecE76C3fD11d648D1da00f8AA206", "0xA9d9895245e08E3728053c798dDac0A32C3Ab98C", "0x03e5793400DFb62F8eB469f4fFa84862CC1e6acc", "0x4eE1ba168551379fD8A59e2e918fF9ee109A6abF", "0x6Ed450e062C20F929CB7Ee72fCc53e9697980a18", "0xEd5E1C52B48C8a6cfEc77DeB57Be61D097d2eE28", "0x95096780Efd48FA66483Bc197677e89f37Ca0CB5", "0x5b747dac86CF5e5d562d65ecB6394F8011E6e3f5", "0x619F27498AE534A14877b05034b0AE7773394Fb9", "0x1d12f8084F60300C075E4C69763f1FE9D6A4d3d4", "0x7ad404498ee93F7762F4eA153Dd04235c8F8050e", "0x38E123F89a7576B2942010Ad1f468CC0EA8f9F4b", "0xB74D5f0a81Ce99aC1857133E489bC2b4954935fF", "0xD9BBF08EAcc1A29FBd64881Fe0e0E04357890ACa", "0x14B82873dAB6e82230581DE0E0Cdd789234941C1", "0xC63eA85CC823c440319013d4B30E19b66466642d", "0x8e2E5ECe3b1f6F33851D62130Ea90cF5Bf523c21", "0xe44BbCF57EC46abDaBf9358724952Bf387714F9F", "0xb03bEF1D9659363a9357aB29a05941491AcCb4eC", "0x22F14Cb872871a37B1d981B342B865F8A31fbAF9", "0xa683C1b815997a7Fa38f6178c84675FC4c79AC2B", "0x5632CA98e5788edDB2397757Aa82d1Ed6171e5aD", "0x0d84597a0Cf27e73e52BC6CCcFA3a5E3CcCaE3da", "0xEFAb50eA729CD4f5Fa5729E296A7a31684026e07"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "airDropTracker_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "round_", outputs: [{name: "plyr", type: "uint256"}, {name: "team", type: "uint256"}, {name: "end", type: "uint256"}, {name: "ended", type: "bool"}, {name: "strt", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}, {name: "icoGen", type: "uint256"}, {name: "icoAvg", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "rndTmEth_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}], name: "getPlayerVaults", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "randomDecisionPhase_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "eth_went_to_gen", type: "uint256"}, {name: "ico", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "noMoreNextRound_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTimeLeft", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_rID", type: "uint256"}, {name: "_eth", type: "uint256"}], name: "calcKeysReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_keys", type: "uint256"}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "TeamDreamHub_", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "airDropPot_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "win", type: "uint256"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "lrnd", type: "uint256"}, {name: "laff", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "PlayerBook", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "senderAddress", type: "address"}, {indexed: false, name: "randNum", type: "uint256"}, {indexed: false, name: "decision", type: "bool"}], name: "onNewDecision", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onWithdrawAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onBuyAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onReLoadAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "roundID", type: "uint256"}, {indexed: false, name: "amountAddedToPot", type: "uint256"}], name: "onPotSwapDeposit", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onNewDecision(address,uint256,bool)", "onNewName(uint256,address,bytes32,bool,uint256,address,bytes32,uint256,uint256)", "onEndTx(uint256,uint256,bytes32,address,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256,uint256,uint256)", "onWithdraw(uint256,address,bytes32,uint256,uint256)", "onWithdrawAndDistribute(address,bytes32,uint256,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onDistribute(address,bytes32,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onBuyAndDistribute(address,bytes32,uint256,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onReLoadAndDistribute(address,bytes32,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onAffiliatePayout(uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onPotSwapDeposit(uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x11cc25ae1ab51c81702f199de59ca510d0a7b0dadf3c7d4c27efbaf79809d6b5", "0xdd6176433ff5026bbce96b068584b7bbe3514227e72df9c630b749ae87e64442", "0x500e72a0e114930aebdbcb371ccdbf43922c49f979794b5de4257ff7e310c746", "0x8f36579a548bc439baa172a6521207464154da77f411e2da3db2f53affe6cc3a", "0x0bd0dba8ab932212fa78150cdb7b0275da72e255875967b5cad11464cf71bedc", "0xf1e74113878acfcd6d871c7f0b6de728d7fd75fcd445b726eaf0c2c51c2240cc", "0xa7801a70b37e729a11492aad44fd3dba89b4149f0609dc0f6837bf9e57e2671a", "0x88261ac70d02d5ea73e54fa6da17043c974de1021109573ec1f6f57111c823dd", "0x590bbc0fc16915a85269a48f74783c39842b7ae9eceb7c295c95dbe8b3ec7331", "0x74b1d2f771e0eff1b2c36c38499febdbea80fe4013bdace4fc4b653322c2895c"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6657135 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6658966 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_TeamDreamHubSCaddress", value: 4}, {type: "address", name: "_PlayerBookSCaddress", value: 5}], name: "Heaven3D", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBuyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxAddr_(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "airDropTracker_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "airDropTracker_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "round_", outputs: [{name: "plyr", type: "uint256"}, {name: "team", type: "uint256"}, {name: "end", type: "uint256"}, {name: "ended", type: "bool"}, {name: "strt", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}, {name: "icoGen", type: "uint256"}, {name: "icoAvg", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "round_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrNames_(uint256,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxName_(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "rndTmEth_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndTmEth_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rID_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}], name: "getPlayerVaults", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerVaults(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentRoundInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "randomDecisionPhase_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "randomDecisionPhase_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "eth_went_to_gen", type: "uint256"}, {name: "ico", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrRnds_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "noMoreNextRound_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "noMoreNextRound_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTimeLeft", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTimeLeft()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_rID", value: random.range( maxRandom )}, {type: "uint256", name: "_eth", value: random.range( maxRandom )}], name: "calcKeysReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcKeysReceived(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_keys", value: random.range( maxRandom )}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "iWantXKeys(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TeamDreamHub_", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TeamDreamHub_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "activated_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "airDropPot_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "airDropPot_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "win", type: "uint256"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "lrnd", type: "uint256"}, {name: "laff", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyr_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerInfoByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PlayerBook", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PlayerBook()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Heaven3D", function( accounts ) {

	it( "TEST: Heaven3D( addressList[4], addressList[5] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6657135", timeStamp: "1541551088", hash: "0x7c9df595411691f7fb5f79795d7c8f947559261cf544a0c87e013f2036eac9a9", nonce: "5", blockHash: "0xf057449c19d7d09a03ad0290b0fec026a596708ba43b4757b10411d71d0cd8b4", transactionIndex: "18", from: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c", to: 0, value: "0", gas: "6393999", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x53e0497700000000000000000000000003e5793400dfb62f8eb469f4ffa84862cc1e6acc0000000000000000000000004ee1ba168551379fd8a59e2e918ff9ee109a6abf", contractAddress: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", cumulativeGasUsed: "7287378", gasUsed: "6393999", confirmations: "1064265"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_TeamDreamHubSCaddress", value: addressList[4]}, {type: "address", name: "_PlayerBookSCaddress", value: addressList[5]}], name: "Heaven3D", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Heaven3D.new( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541551088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Heaven3D.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "471223581119868" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: activate(  )", async function( ) {
		const txOriginal = {blockNumber: "6657204", timeStamp: "1541552105", hash: "0xc3390fbef131f6d84d148b01a0dfd2483fc8ad6ba4c3bbd96df499dff9441e83", nonce: "7", blockHash: "0x9e59ec441ca5f742422e978bf17cd3554e1d120bd681860a4ae6621bf05e17ae", transactionIndex: "214", from: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "153402", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x0f15f4c0", contractAddress: "", cumulativeGasUsed: "7398250", gasUsed: "102268", confirmations: "1064196"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "activate", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activate()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541552105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "471223581119868" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6657208", timeStamp: "1541552153", hash: "0xef91dade35586b030b7a6f4c45bd0ff692098489feef22aa01d06cefc27b0c94", nonce: "1996", blockHash: "0xf258a54876cc0867d650afcebf236f1c94535360db5a27bca3a521db3eb1fad2", transactionIndex: "14", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "100000000000000000", gas: "800000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1019335", gasUsed: "493633", confirmations: "1064192"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541552153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541552153000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000004"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "ethIn", type: "uint256", value: "100000000000000000"}, {name: "keysBought", type: "uint256", value: "1331487990852298917347"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "59999999999999731"}, {name: "potAmount", type: "uint256", value: "20000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "986737738721285015" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6657233", timeStamp: "1541552533", hash: "0xc8ba4387671c978b6228217eb2f20395558572fc3dca3daefeeddc87e03e6cd4", nonce: "2", blockHash: "0x55507dd7c0d2cac48ce8e30a8aeb90c64d2e53428d6a803e74dfefa13c728146", transactionIndex: "35", from: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "1000000000000000000", gas: "981417", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3492551", gasUsed: "654278", confirmations: "1064167"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541552533 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541552533000000000000000110"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000002"}, {name: "playerName", type: "bytes32", value: "0x616c000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "13117715112159186775020"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999999979"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "7594298260" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyXid( \"0\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657236", timeStamp: "1541552570", hash: "0xa30d6dd4176f5edf940251a586d7acb8fdc3bed5e9049259709a66d2da32abbf", nonce: "1689", blockHash: "0xd0e071901270b65de75ff31f5f8bfa41957949adddcaf3cb17574e21705960a1", transactionIndex: "9", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "50000000000000000", gas: "397430", gasPrice: "43000000000", isError: "1", txreceipt_status: "0", input: "0x8f38f30900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1755319", gasUsed: "397430", confirmations: "1064164"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_affCode", value: "0"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXid", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "15056914187600253" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyXid( \"0\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657238", timeStamp: "1541552637", hash: "0xec911b66bad1f589ed0e5640b55b81e4043667ad5b61a80109a3ed37c670851c", nonce: "1690", blockHash: "0xe9a39e95acafc0afb39fda0cb2534b899ac405b0949d1f896a4d7a477979725c", transactionIndex: "13", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "100000000000000000", gas: "423840", gasPrice: "35000000000", isError: "0", txreceipt_status: "1", input: "0x8f38f30900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "901210", gasUsed: "408840", confirmations: "1064162"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_affCode", value: "0"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXid", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXid(uint256,uint256)" ]( "0", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541552637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541552637000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000005"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "ethIn", type: "uint256", value: "100000000000000000"}, {name: "keysBought", type: "uint256", value: "1292681088635358908437"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "59999999999999128"}, {name: "potAmount", type: "uint256", value: "20000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "15056914187600253" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6657256", timeStamp: "1541552796", hash: "0x6b143a126771837d5c1b2e0b6ab3068cb0bf9606669ccc33b16e7c4fcad23c8f", nonce: "8", blockHash: "0xb19272d3e08dab5e2d6af9cfc65d314ab761151975663af7421ab63b2106c6b8", transactionIndex: "18", from: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "1000000000000000000", gas: "600802", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1870623", gasUsed: "400535", confirmations: "1064144"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541552796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541552796000000000000000110"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000001"}, {name: "playerName", type: "bytes32", value: "0x6c62000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "12746098447060791855871"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999996775"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "471223581119868" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657298", timeStamp: "1541553416", hash: "0x9781c9bd2795e7a7b23e3e966bf2d16604dcb3228599bbd2b8936542b85b96be", nonce: "1997", blockHash: "0x5526c5ae652295f15cbddbb7c27ed94c44c47ea9326e91d17b12f1eb76b33084", transactionIndex: "9", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "506890", gasUsed: "118838", confirmations: "1064102"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541553416 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "300000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541553416"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "986737738721285015" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657342", timeStamp: "1541554018", hash: "0x4bbd9ef21335b09f59f85303e70258ed48f6ddb6f2ef4fbf555cd7ba4dbb6b35", nonce: "9", blockHash: "0xa2ec1e78c84af330c56d6af3fb7dba97b1af19e2235f24eab8247ed7c8bc70d0", transactionIndex: "98", from: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "79451247287399", gas: "122991", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4419951", gasUsed: "81994", confirmations: "1064058"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "79451247287399" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541554018 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "471223581119868" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6657360", timeStamp: "1541554276", hash: "0xa989f33cddb4f86fa7dd1940743282a3b54044b42e109f30817a9a3055329946", nonce: "73", blockHash: "0xbec3f55cfaaabe76e0440b9a18bb0c3e277276bd072f80e5c39df2b30f2457c5", transactionIndex: "52", from: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "110000000000000000", gas: "709701", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3536107", gasUsed: "473134", confirmations: "1064040"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "110000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541554276 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541554276000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000006"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5"}, {name: "ethIn", type: "uint256", value: "110000000000000000"}, {name: "keysBought", type: "uint256", value: "1382618465730531990755"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "65999999999986581"}, {name: "potAmount", type: "uint256", value: "22000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657363", timeStamp: "1541554312", hash: "0x13030f3ae162036aa253758f619c118e5a0d44057043efe68822c0bf2c2db540", nonce: "1998", blockHash: "0xca3da3b331e75ba29a64b0799fc983c41a84fa61833a88a278050c76cd7d9c78", transactionIndex: "33", from: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "98841", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4220396", gasUsed: "65894", confirmations: "1064037"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541554312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0x6ed450e062c20f929cb7ee72fcc53e9697980a18"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1541554312"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "986737738721285015" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657365", timeStamp: "1541554327", hash: "0xf6db0fb396a17cfee8471fee960c1d492488acf896c6d18c73f63d1b244f0db7", nonce: "134", blockHash: "0x62e7712440ba9a8fa9c0a94ea5c004e3a35fd014f73d9241c29a5ce30c09acea", transactionIndex: "45", from: "0x619f27498ae534a14877b05034b0ae7773394fb9", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "79667281422669", gas: "616783", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3050737", gasUsed: "396189", confirmations: "1064035"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "79667281422669" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541554327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541554327000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000007"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x619f27498ae534a14877b05034b0ae7773394fb9"}, {name: "ethIn", type: "uint256", value: "79667281422669"}, {name: "keysBought", type: "uint256", value: "1000000000001261949"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "47800368839798"}, {name: "potAmount", type: "uint256", value: "15933456284535"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "87050362177155908812" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6657409", timeStamp: "1541555001", hash: "0x1b5740310f213f577a0379f4378d11f7e40a85def5eaf570fbbde4d011585104", nonce: "74", blockHash: "0x646cd41a4f698e4c815ae97cdeddae281cb595341fe2b2f6e12bc37d207ec203", transactionIndex: "54", from: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "80000000000000", gas: "718293", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3610431", gasUsed: "463862", confirmations: "1063991"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "80000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541555001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541555001000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000006"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5"}, {name: "ethIn", type: "uint256", value: "80000000000000"}, {name: "keysBought", type: "uint256", value: "1004174378010169162"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "47999999999618"}, {name: "potAmount", type: "uint256", value: "16000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `PM1`, \"0x00000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657429", timeStamp: "1541555305", hash: "0x7c39feb0540dbc5cb59eea32f1e57a497b5766510727e7d09aef82e0044870b3", nonce: "5", blockHash: "0x5971d25513fd5d7a7b43feba3c76cdf281c77a20efc07f130f7b606caee876d5", transactionIndex: "76", from: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "10000000000000000", gas: "309589", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003504d310000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3812968", gasUsed: "206393", confirmations: "1063971"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `PM1`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `PM1`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541555305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "2"}, {name: "playerAddress", type: "address", value: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28"}, {name: "playerName", type: "bytes32", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541555305"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "7594298260" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `changsclub`, \"0x0000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657511", timeStamp: "1541556520", hash: "0xa3dfc9a9b7dcd3720c7fa2e359d78498a37da24186eb30dcf06136d75837b482", nonce: "0", blockHash: "0x3271185dea7c443a75a05c2112cc308e9a88c9102ea65ea7d423f15f0113cce7", transactionIndex: "95", from: "0x1d12f8084f60300c075e4c69763f1fe9d6a4d3d4", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "10000000000000000", gas: "532465", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd83000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000a6368616e6773636c756200000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5905607", gasUsed: "354887", confirmations: "1063889"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `changsclub`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `changsclub`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541556520 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "8"}, {name: "playerAddress", type: "address", value: "0x1d12f8084f60300c075e4c69763f1fe9d6a4d3d4"}, {name: "playerName", type: "bytes32", value: "0x6368616e6773636c756200000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541556520"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "216571746248052" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x6c6200000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657531", timeStamp: "1541556829", hash: "0x412605ed396ccfd0651c5e02e634e4850a82acf2c23ff30af4287fe12b21ef10", nonce: "1", blockHash: "0x7cad901588bcf1d8833c22afcb28438ac083eb58b4312a369d24829babea15ba", transactionIndex: "71", from: "0x1d12f8084f60300c075e4c69763f1fe9d6a4d3d4", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "967260197397780438", gas: "643380", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a16c620000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7521230", gasUsed: "413920", confirmations: "1063869"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "967260197397780438" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x6c62000000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x6c62000000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541556829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541556829000000000000000110"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000008"}, {name: "playerName", type: "bytes32", value: "0x6368616e6773636c756200000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x1d12f8084f60300c075e4c69763f1fe9d6a4d3d4"}, {name: "ethIn", type: "uint256", value: "967260197397780438"}, {name: "keysBought", type: "uint256", value: "12000000000000001235279"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "580356118438646656"}, {name: "potAmount", type: "uint256", value: "193452039479556089"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[15,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c"}, {name: "affiliateName", type: "bytes32", value: "0x6c62000000000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "8"}, {name: "amount", type: "uint256", value: "96726019739778043"}, {name: "timeStamp", type: "uint256", value: "1541556829"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[15,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "216571746248052" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706d31000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657567", timeStamp: "1541557307", hash: "0xdbaa0140c7bb89e7c09e151c2e7fe0e14c552e8d44afb882811e79bff243de51", nonce: "0", blockHash: "0x803be246c64ee31c111c3ba03c024c8a6a87cc039631a74214f727977e3f7492", transactionIndex: "46", from: "0x7ad404498ee93f7762f4ea153dd04235c8f8050e", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "989760197397780440", gas: "780973", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a1706d3100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3011401", gasUsed: "520649", confirmations: "1063833"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "989760197397780440" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x706d310000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541557307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541557307000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000009"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7ad404498ee93f7762f4ea153dd04235c8f8050e"}, {name: "ethIn", type: "uint256", value: "989760197397780440"}, {name: "keysBought", type: "uint256", value: "12000000000000001203723"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "593856118438646122"}, {name: "potAmount", type: "uint256", value: "197952039479556088"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[16,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "2"}, {name: "affiliateAddress", type: "address", value: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28"}, {name: "affiliateName", type: "bytes32", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "9"}, {name: "amount", type: "uint256", value: "98976019739778044"}, {name: "timeStamp", type: "uint256", value: "1541557307"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[16,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691752359919" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657589", timeStamp: "1541557661", hash: "0xddfe3b9d9b0bd4c854990db71c666ea8fc30bc6b7a71db79b322a4c6e310d3a3", nonce: "1366", blockHash: "0x8a0ccc4a745fe2e408658b739da2bc340ada2059fa08ad4104657cf25b114b1b", transactionIndex: "24", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "503317598698890271", gas: "489122", gasPrice: "22500000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1211137", gasUsed: "407602", confirmations: "1063811"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "503317598698890271" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541557661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541557661000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000010"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "ethIn", type: "uint256", value: "503317598698890271"}, {name: "keysBought", type: "uint256", value: "6000000000000001186382"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "301990559219310172"}, {name: "potAmount", type: "uint256", value: "100663519739778055"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "192358345858768918" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657594", timeStamp: "1541557744", hash: "0x4e7721656285ba4df8618093948810e627e7c9d8e7156648ae331e20e75922cc", nonce: "5241", blockHash: "0xe5026aa8a28237d2d49c24ecb6acb34dc258018c181f68ea5e9b97a95e77ba2a", transactionIndex: "84", from: "0xb74d5f0a81ce99ac1857133e489bc2b4954935ff", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "1023510197397780445", gas: "747586", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5358934", gasUsed: "498391", confirmations: "1063806"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1023510197397780445" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541557744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541557744000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xb74d5f0a81ce99ac1857133e489bc2b4954935ff"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "11727287449440167021605"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999992499"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1956174493813293149" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706d31000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657594", timeStamp: "1541557744", hash: "0xe12afe3d12836f9dd230c0f89d94146187f014c65c4d0849f22f582bdeb35da9", nonce: "0", blockHash: "0xe5026aa8a28237d2d49c24ecb6acb34dc258018c181f68ea5e9b97a95e77ba2a", transactionIndex: "98", from: "0xd9bbf08eacc1a29fbd64881fe0e0e04357890aca", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "990941951097826685", gas: "760618", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a1706d3100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6369971", gasUsed: "503728", confirmations: "1063806"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "990941951097826685" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x706d310000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541557744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541557744000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000012"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xd9bbf08eacc1a29fbd64881fe0e0e04357890aca"}, {name: "ethIn", type: "uint256", value: "990941951097826685"}, {name: "keysBought", type: "uint256", value: "11380133571087297673848"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "594565170658641564"}, {name: "potAmount", type: "uint256", value: "198188390219565337"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[19,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "2"}, {name: "affiliateAddress", type: "address", value: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28"}, {name: "affiliateName", type: "bytes32", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "12"}, {name: "amount", type: "uint256", value: "99094195109782668"}, {name: "timeStamp", type: "uint256", value: "1541557744"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[19,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "400148869863" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `chang`, \"0x000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657598", timeStamp: "1541557776", hash: "0xb2b1618653c813dd5f6e383485ab2d4325aa3cc65bd6e006e9762a8684b92f51", nonce: "75", blockHash: "0x557bcb02469e505d55fec9ae5a3c80ae93fe1af284ea1b324e74fbf0039ce8c2", transactionIndex: "105", from: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "10000000000000000", gas: "386997", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x685ffd8300000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000056368616e67000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7745914", gasUsed: "257998", confirmations: "1063802"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `chang`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `chang`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541557776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "6"}, {name: "playerAddress", type: "address", value: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5"}, {name: "playerName", type: "bytes32", value: "0x6368616e67000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541557776"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657603", timeStamp: "1541557921", hash: "0xe77ce2757e0a7b2504bf40bffded7fb1ba2e9286163084cd3eb80f7ee03288d8", nonce: "1367", blockHash: "0x602bf2a19f3a8b758e0af334ce10b68fa43273ff0af765651f0776c821bbbd61", transactionIndex: "89", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "619586981889907216", gas: "460753", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6036008", gasUsed: "368961", confirmations: "1063797"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "619586981889907216" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541557921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541557921000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000010"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "ethIn", type: "uint256", value: "496682401301109729"}, {name: "keysBought", type: "uint256", value: "5618294457021519009240"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "298009440780608482"}, {name: "potAmount", type: "uint256", value: "99336480260221947"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "192358345858768918" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x6368616e6700000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657605", timeStamp: "1541558004", hash: "0xb34bd40502578d14d3d5b3003d0eb763a1b6e52d1283ba91cdfd230890cf21dd", nonce: "39", blockHash: "0x7cfb81f61cab60c6aa77a59c24431151e3433c1e0edda813dbbaf85972a6d7b1", transactionIndex: "63", from: "0x14b82873dab6e82230581de0e0cdd789234941c1", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "535872956959092445", gas: "680703", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a16368616e670000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2850475", gasUsed: "453802", confirmations: "1063795"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "535872956959092445" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x6368616e67000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x6368616e67000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541558004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541558004000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000013"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x14b82873dab6e82230581de0e0cdd789234941c1"}, {name: "ethIn", type: "uint256", value: "535872956959092445"}, {name: "keysBought", type: "uint256", value: "6000000000000001122086"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "321523774175452323"}, {name: "potAmount", type: "uint256", value: "107174591391818489"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[22,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "6"}, {name: "affiliateAddress", type: "address", value: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5"}, {name: "affiliateName", type: "bytes32", value: "0x6368616e67000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "13"}, {name: "amount", type: "uint256", value: "53587295695909244"}, {name: "timeStamp", type: "uint256", value: "1541558004"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[22,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "24790799289674" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `anlayaman`, \"0x00000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657606", timeStamp: "1541558014", hash: "0x014552589476947d7d557036807c0d38b1c4aeffdf1f30af3621b046f90f3470", nonce: "5243", blockHash: "0x512c508fa950a6fa3458e7549a8ebfae67761653ef7503fce9d2b6c237aba0d3", transactionIndex: "52", from: "0xb74d5f0a81ce99ac1857133e489bc2b4954935ff", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "10000000000000000", gas: "399825", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000009616e6c6179616d616e0000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3204131", gasUsed: "266550", confirmations: "1063794"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `anlayaman`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `anlayaman`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541558014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "11"}, {name: "playerAddress", type: "address", value: "0xb74d5f0a81ce99ac1857133e489bc2b4954935ff"}, {name: "playerName", type: "bytes32", value: "0x616e6c6179616d616e0000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541558014"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1956174493813293149" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657606", timeStamp: "1541558014", hash: "0xd88fd6dc56114d2a64c3c28fe512015ac0ac7c00bec24627cd17b80a53075e13", nonce: "1291", blockHash: "0x512c508fa950a6fa3458e7549a8ebfae67761653ef7503fce9d2b6c237aba0d3", transactionIndex: "59", from: "0xc63ea85cc823c440319013d4b30e19b66466642d", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "294057063383705160", gas: "614620", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4373672", gasUsed: "409747", confirmations: "1063794"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "294057063383705160" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541558014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541558014000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000014"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xc63ea85cc823c440319013d4b30e19b66466642d"}, {name: "ethIn", type: "uint256", value: "294057063383705160"}, {name: "keysBought", type: "uint256", value: "3265991944582026319264"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "176434238030140220"}, {name: "potAmount", type: "uint256", value: "58811412676741032"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "128551984353441262" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657607", timeStamp: "1541558037", hash: "0x35d5edf0a83740d36bcb470cd6153b1d443ccb6f7bf2c259ac297b12279f84f8", nonce: "157", blockHash: "0xd331d90dc8392ddab479b4599ca1cb7917cc6c3b95d2036efe0a4d01b00e1e0d", transactionIndex: "51", from: "0x8e2e5ece3b1f6f33851d62130ea90cf5bf523c21", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "1837074414690460084", gas: "738606", gasPrice: "44000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1658849", gasUsed: "492404", confirmations: "1063793"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "1837074414690460084" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541558037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541558037000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000015"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x8e2e5ece3b1f6f33851d62130ea90cf5bf523c21"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "10971126844317374829227"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999980888"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: reLoadXname( \"0x6368616e6700000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657613", timeStamp: "1541558130", hash: "0x0cae228fd13bff743eec07aac576a0e00f9d62702f7d09cca9d391b271cf8479", nonce: "78", blockHash: "0xaf7770f998f0dab7cf7ed69110599619825e13c8369924d81a25b32809826c2f", transactionIndex: "126", from: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "458649", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x079ce3276368616e67000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001fcf3d80cb629d1", contractAddress: "", cumulativeGasUsed: "7146718", gasUsed: "275766", confirmations: "1063787"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x6368616e67000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "0"}, {type: "uint256", name: "_eth", value: "143257397420763601"}], name: "reLoadXname", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reLoadXname(bytes32,uint256,uint256)" ]( "0x6368616e67000000000000000000000000000000000000000000000000000000", "0", "143257397420763601", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541558130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541558130000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000006"}, {name: "playerName", type: "bytes32", value: "0x6368616e67000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5"}, {name: "ethIn", type: "uint256", value: "143257397420763601"}, {name: "keysBought", type: "uint256", value: "1555000000000001085486"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "85954438452385309"}, {name: "potAmount", type: "uint256", value: "28651479484152721"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: reLoadXid( \"0\", \"0\", \"276811977199271815\" )", async function( ) {
		const txOriginal = {blockNumber: "6657614", timeStamp: "1541558158", hash: "0x277c30006299a6c9e41daeb56904af017307bcdcb9a857bbddb759d234460f78", nonce: "1368", blockHash: "0x2d8c1b5488fc6cd7e1edd44ea4840ebda828c1b65dc156ca9d0a386bbdf92e8f", transactionIndex: "156", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "107064", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x349cdcac0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003d76f06d2893f87", contractAddress: "", cumulativeGasUsed: "5894925", gasUsed: "74220", confirmations: "1063786"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_affCode", value: "0"}, {type: "uint256", name: "_team", value: "0"}, {type: "uint256", name: "_eth", value: "276811977199271815"}], name: "reLoadXid", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reLoadXid(uint256,uint256,uint256)" ]( "0", "0", "276811977199271815", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541558158 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "192358345858768918" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `H3D`, \"0x00000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657618", timeStamp: "1541558184", hash: "0x91e5e45ad3b3fdbbbca3b72bb254b9755c7c022af9b76baecc6d81ee604ffaba", nonce: "1292", blockHash: "0x7933e20a3340a7cb8a812ad4b0221bf1c24275e2d9d7a314793141aea3d89c61", transactionIndex: "58", from: "0xc63ea85cc823c440319013d4b30e19b66466642d", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "10000000000000000", gas: "377089", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd8300000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000034833440000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6144250", gasUsed: "251393", confirmations: "1063782"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `H3D`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `H3D`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541558184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "14"}, {name: "playerAddress", type: "address", value: "0xc63ea85cc823c440319013d4b30e19b66466642d"}, {name: "playerName", type: "bytes32", value: "0x6833640000000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541558184"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "128551984353441262" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706d31000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657621", timeStamp: "1541558208", hash: "0x297323cd8abfa3f3934b0fcb446fcff52f19b1c6f3c74446165d3c1fe751c21a", nonce: "0", blockHash: "0x76e9ccac35287bb51df4b20e520e72d6be7acfff2107d6cb700927a0ec7cdc82", transactionIndex: "82", from: "0xe44bbcf57ec46abdabf9358724952bf387714f9f", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "986611462371844545", gas: "662298", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a1706d3100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6994423", gasUsed: "441532", confirmations: "1063779"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "986611462371844545" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x706d310000000000000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541558208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541558208000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000016"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xe44bbcf57ec46abdabf9358724952bf387714f9f"}, {name: "ethIn", type: "uint256", value: "986611462371844545"}, {name: "keysBought", type: "uint256", value: "10600000000000001064933"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "591966877423057344"}, {name: "potAmount", type: "uint256", value: "197322292474368909"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[29,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "2"}, {name: "affiliateAddress", type: "address", value: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28"}, {name: "affiliateName", type: "bytes32", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "16"}, {name: "amount", type: "uint256", value: "98661146237184454"}, {name: "timeStamp", type: "uint256", value: "1541558208"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[29,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "1000000290444380864" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6657624", timeStamp: "1541558244", hash: "0xa38ea70a157c57d9d117d80c44594155029d514f6899ed917fe3ee0c21d1d6e8", nonce: "5856", blockHash: "0x7f78609553bf5408b22bac3e68fe600a4764689395e350b6aca3b1f0d0665cf1", transactionIndex: "2", from: "0xb03bef1d9659363a9357ab29a05941491accb4ec", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "5000000000000000000", gas: "763681", gasPrice: "119000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "551125", gasUsed: "509121", confirmations: "1063776"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541558244 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541558244000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000017"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xb03bef1d9659363a9357ab29a05941491accb4ec"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "10556385302347250384996"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999902088"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "4315328126289636616" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657624", timeStamp: "1541558244", hash: "0x804d42328238352985f852c5530e714014638349b102222a851229966cdf7446", nonce: "1369", blockHash: "0x7f78609553bf5408b22bac3e68fe600a4764689395e350b6aca3b1f0d0665cf1", transactionIndex: "10", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "82958", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "752257", gasUsed: "54132", confirmations: "1063776"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541558244 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "10"}, {name: "playerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "518561855554145287"}, {name: "timeStamp", type: "uint256", value: "1541558244"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "192358345858768918" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657628", timeStamp: "1541558301", hash: "0x060db5bd626f5778891fc4ba42a10d30863a9c1c6433f1522984234d53d0b672", nonce: "5857", blockHash: "0x02a625af7731162d9a0bcd4d51379d0c3a4f8d07b367bb7d435a9522835375a7", transactionIndex: "64", from: "0xb03bef1d9659363a9357ab29a05941491accb4ec", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "77590", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2335491", gasUsed: "36727", confirmations: "1063772"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541558301 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "17"}, {name: "playerAddress", type: "address", value: "0xb03bef1d9659363a9357ab29a05941491accb4ec"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "4000000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541558301"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "4315328126289636616" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6657630", timeStamp: "1541558408", hash: "0x4335d85175e41802543eaa29af8a88e96c1c885ec7437f080733b2a806a24555", nonce: "1387", blockHash: "0x42f9cf504dd1aa01ffa4ba901ebf2cc3f0434f40b517e1f41231eab59e846e77", transactionIndex: "38", from: "0x22f14cb872871a37b1d981b342b865f8a31fbaf9", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "5000000000000000000", gas: "728533", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1717010", gasUsed: "485689", confirmations: "1063770"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541558408 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541558408000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000018"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x22f14cb872871a37b1d981b342b865f8a31fbaf9"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "10377229485732883942033"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999916867"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "408982485127722648" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6657630", timeStamp: "1541558408", hash: "0xa252274737940ea136d5034b523c59e299af06d0f57b3adf16fd60cf05c8740a", nonce: "928", blockHash: "0x42f9cf504dd1aa01ffa4ba901ebf2cc3f0434f40b517e1f41231eab59e846e77", transactionIndex: "179", from: "0xa683c1b815997a7fa38f6178c84675fc4c79ac2b", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "1071346621231533687", gas: "738319", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5494790", gasUsed: "473862", confirmations: "1063770"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "1071346621231533687" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541558408 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541558408000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000019"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xa683c1b815997a7fa38f6178c84675fc4c79ac2b"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "10206896945994284077527"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999878958"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "655498527316678718" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `exchange`, \"0x000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657635", timeStamp: "1541558456", hash: "0xa1d677b93b3dbc82876bccf8f3df5465f2385fa133110d28ae6cfe27dc4d4157", nonce: "2874", blockHash: "0x3e46e3a856e6619bb454943dbffb778f80bedc9e409bfeb500ad6858d80513c1", transactionIndex: "23", from: "0x5632ca98e5788eddb2397757aa82d1ed6171e5ad", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "10000000000000000", gas: "526051", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd83000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000865786368616e6765000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "957758", gasUsed: "350611", confirmations: "1063765"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `exchange`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `exchange`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541558456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "20"}, {name: "playerAddress", type: "address", value: "0x5632ca98e5788eddb2397757aa82d1ed6171e5ad"}, {name: "playerName", type: "bytes32", value: "0x65786368616e6765000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541558456"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "31703542378276371621" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x65786368616e676500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657642", timeStamp: "1541558559", hash: "0x6e63726f065721015aac27de84fcf16b2a5b1a5d507a3ee1020d6b28c3fe20cd", nonce: "530", blockHash: "0x558e5b76fcd840d345e88ec5af96e3b86bbb908608ec11706d92c7c4240e1676", transactionIndex: "16", from: "0x0d84597a0cf27e73e52bc6cccfa3a5e3cccae3da", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "1010568020388326780", gas: "788088", gasPrice: "39000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a165786368616e67650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1206315", gasUsed: "525392", confirmations: "1063758"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "1010568020388326780" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x65786368616e6765000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "0"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x65786368616e6765000000000000000000000000000000000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541558559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1541558559000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000021"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x0d84597a0cf27e73e52bc6cccfa3a5e3cccae3da"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "10044686385317694689386"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "599999999999909572"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "0"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[36,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "20"}, {name: "affiliateAddress", type: "address", value: "0x5632ca98e5788eddb2397757aa82d1ed6171e5ad"}, {name: "affiliateName", type: "bytes32", value: "0x65786368616e6765000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "21"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541558559"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[36,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "105000000005704" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657654", timeStamp: "1541558810", hash: "0x12eb7faf1d76a2d0132c715b1f6feceecfa85df9df92ad08703d53440af9776f", nonce: "2875", blockHash: "0xbf53a6019f60e67dc58637d51e714216520357d8d67a7b5da351febc7db51277", transactionIndex: "41", from: "0x5632ca98e5788eddb2397757aa82d1ed6171e5ad", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "77514", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1417922", gasUsed: "36676", confirmations: "1063746"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541558810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "20"}, {name: "playerAddress", type: "address", value: "0x5632ca98e5788eddb2397757aa82d1ed6171e5ad"}, {name: "playerName", type: "bytes32", value: "0x65786368616e6765000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "100000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541558810"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "31703542378276371621" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657660", timeStamp: "1541558870", hash: "0xba5e1503006b51adce7e8d2f383155a02a89ebd214a58045e69ed8a6f9516b8f", nonce: "158", blockHash: "0x8aa6a6e5ac8c45c0c7a28c15b0cc5fbf902617c446714055b5133606d12dfe0f", transactionIndex: "47", from: "0x8e2e5ece3b1f6f33851d62130ea90cf5bf523c21", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "126198", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3067088", gasUsed: "69132", confirmations: "1063740"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541558870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "15"}, {name: "playerAddress", type: "address", value: "0x8e2e5ece3b1f6f33851d62130ea90cf5bf523c21"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "1098670129367755683"}, {name: "timeStamp", type: "uint256", value: "1541558870"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657666", timeStamp: "1541558948", hash: "0x43af882113d9a4a74620f348c6227ddfd73acc94037b21fe76e266c9c7f0b55a", nonce: "1370", blockHash: "0x53c8f1cceaf290c26303d78b2b3dffaf826ce8e28778cbef9accb02d71cb8df0", transactionIndex: "54", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "100958", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2421224", gasUsed: "69132", confirmations: "1063734"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541558948 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "10"}, {name: "playerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "147932226190202500"}, {name: "timeStamp", type: "uint256", value: "1541558948"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "192358345858768918" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657750", timeStamp: "1541560088", hash: "0x95c087003b91026545dbafc9562912fef43b4d98ad59999bebe5592ee06882ca", nonce: "40", blockHash: "0xde833c27e8d8df773aac5da5642f326ec825d31307d7587033e1786450cd8b8c", transactionIndex: "62", from: "0x14b82873dab6e82230581de0e0cdd789234941c1", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "148698", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7531218", gasUsed: "84132", confirmations: "1063650"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541560088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "13"}, {name: "playerAddress", type: "address", value: "0x14b82873dab6e82230581de0e0cdd789234941c1"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "191040247699770035"}, {name: "timeStamp", type: "uint256", value: "1541560088"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "24790799289674" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6657877", timeStamp: "1541562096", hash: "0xa10a806e244e1b17add293e716970ac4d4a632a151c2b45fd80102d768992fdc", nonce: "80", blockHash: "0x7cff9b4cb8b4dca063521d5df1962f5efaf2859eeebe772cd72cd91536c00dfa", transactionIndex: "47", from: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "103698", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7462416", gasUsed: "54132", confirmations: "1063523"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541562096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "6"}, {name: "playerAddress", type: "address", value: "0x5b747dac86cf5e5d562d65ecb6394f8011e6e3f5"}, {name: "playerName", type: "bytes32", value: "0x6368616e67000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "80887005098037679"}, {name: "timeStamp", type: "uint256", value: "1541562096"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `play`, \"0x0000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6657952", timeStamp: "1541563044", hash: "0x1112d355e38b4fd1fb7344c798e27118bfe4d0269608d829299540f5b86a4adc", nonce: "1691", blockHash: "0xda85f904418541a186a7ae2322484e627bf369aef5f254b84cf7c3171bdc173d", transactionIndex: "50", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "10000000000000000", gas: "383790", gasPrice: "9400000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2464319", gasUsed: "255860", confirmations: "1063448"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `play`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `play`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541563044 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "5"}, {name: "playerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541563044"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "15056914187600253" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6658030", timeStamp: "1541564043", hash: "0x9be5579ef971b83aee53dac36ed0890403251221e84812eabd893765298165f2", nonce: "1692", blockHash: "0xdc8c04cca181de826a5b22775d65210ff0ef0c701765096f499f44859bf18c15", transactionIndex: "33", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "148698", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1237634", gasUsed: "84132", confirmations: "1063370"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541564043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "5"}, {name: "playerAddress", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "197008931200418043"}, {name: "timeStamp", type: "uint256", value: "1541564043"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "15056914187600253" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6658281", timeStamp: "1541567667", hash: "0xc97ecea7d094f755c0eba63a7469de7e346f4f724bb9cac064384217106b1b81", nonce: "6", blockHash: "0xcc3dfcbf3cc068eeffc1d5921596a05c457960f57d693528b9ef1d9bbb04c51f", transactionIndex: "119", from: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "148698", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7798341", gasUsed: "69132", confirmations: "1063119"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541567667 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "2"}, {name: "playerAddress", type: "address", value: "0xed5e1c52b48c8a6cfec77deb57be61d097d2ee28"}, {name: "playerName", type: "bytes32", value: "0x706d310000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "2350386142274626427"}, {name: "timeStamp", type: "uint256", value: "1541567667"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "7594298260" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6658799", timeStamp: "1541575124", hash: "0xf0754973e56e42674228a0b052355786d6f6d0e3c8ea0abe5e8e3ff1c8fb9574", nonce: "191", blockHash: "0xf2b327a93e89674cb7db5020b33bf8aa0d050c7fda1ffd46a8ee7025ed43de9e", transactionIndex: "138", from: "0xefab50ea729cd4f5fa5729e296a7a31684026e07", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "100339943385203", gas: "780000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7236857", gasUsed: "780000", confirmations: "1062601"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "100339943385203" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "12617641527251805" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6658857", timeStamp: "1541575985", hash: "0xc403b95880346ec318b64039a21771d6b2b0d526b4a6714d7ee7381702be4c11", nonce: "192", blockHash: "0x17ca816179e9d16de12e33da8d8f1e560688598f5b657b17a337a19f2baa5d7c", transactionIndex: "26", from: "0xefab50ea729cd4f5fa5729e296a7a31684026e07", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "100339943385203", gas: "780000", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1912562", gasUsed: "780000", confirmations: "1062543"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "100339943385203" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "0"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "12617641527251805" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6658950", timeStamp: "1541577430", hash: "0x1e82966e5422bac77251d6f48c186a65f72bc6463a35c095ca8a95a028b0f061", nonce: "1", blockHash: "0xf2c48690b986ec29b9aa5e7a0085a38f16cfc1b712b4a4f283acb708e3922183", transactionIndex: "98", from: "0xd9bbf08eacc1a29fbd64881fe0e0e04357890aca", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "148698", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5225663", gasUsed: "84132", confirmations: "1062450"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541577430 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "12"}, {name: "playerAddress", type: "address", value: "0xd9bbf08eacc1a29fbd64881fe0e0e04357890aca"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "444512410045950292"}, {name: "timeStamp", type: "uint256", value: "1541577430"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "400148869863" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6658954", timeStamp: "1541577466", hash: "0xe72593f13f8c0ac781f1785a4991f2e38600f950053939b5fb3b2cc310f88514", nonce: "1", blockHash: "0x106b8a4851bca13b00003430893a59cd95aaa17b3d26c912b90189873873322a", transactionIndex: "52", from: "0x7ad404498ee93f7762f4ea153dd04235c8f8050e", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "148698", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4106899", gasUsed: "84132", confirmations: "1062446"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541577466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "9"}, {name: "playerAddress", type: "address", value: "0x7ad404498ee93f7762f4ea153dd04235c8f8050e"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "755895615410004076"}, {name: "timeStamp", type: "uint256", value: "1541577466"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "691752359919" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6658966", timeStamp: "1541577673", hash: "0x906eae8716aa2cf7ebb895d8f1aa54442d3b371051e5c2ce98b0c2d733ad3e45", nonce: "11", blockHash: "0x5337a2cbef47309c34079deb6f9bb1db87e056aef51c77b74efb3acc71e3464f", transactionIndex: "154", from: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c", to: "0x51f835d5671dece76c3fd11d648d1da00f8aa206", value: "0", gas: "103698", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7288845", gasUsed: "39132", confirmations: "1062434"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541577673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "1"}, {name: "playerAddress", type: "address", value: "0xa9d9895245e08e3728053c798ddac0a32c3ab98c"}, {name: "playerName", type: "bytes32", value: "0x6c62000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "1553537610497450658"}, {name: "timeStamp", type: "uint256", value: "1541577673"}], address: "0x51f835d5671dece76c3fd11d648d1da00f8aa206"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "471223581119868" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "385874116450290686" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
