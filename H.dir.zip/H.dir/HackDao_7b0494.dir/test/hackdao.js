const HackDao = artifacts.require( "./HackDao.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "HackDao" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5C430fA24F782cF8156cA97208C42127b17b0494", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x93BBBe5ce77034E3095F0479919962a903f898Ad", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0x2E73E5971326F0c04f3533fd9D82B4e70763dd03", "0x4c3e5A7Fd703225701ef7c08aDf214244038ddC3", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0x04DF40420E808a5e6abC670049126ba60CFa4c2D", "0x90Dd6A9746dEA01a8B3863d179Af227170692f70"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "bytes32"}], name: "results", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogB(bytes32)", "LogS(string)", "LogI(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xd8cfd15a18acf055da86af88b707b6b949547c68600ee3545bf254a1261bc3c7", "0x70d816668b2732e5fb6f136b2561a576ff46b80a1ced4f5fdae6ede3c87708ab", "0x91b2b30e127e1d3f311038d05d9983080a65a18d12ce799036aef822992e42ad"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3205611 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3242730 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "HackDao", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "results", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "results(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "HackDao", function( accounts ) {

	it( "TEST: HackDao(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3205611", timeStamp: "1487415229", hash: "0x7f3ddc015c1cdd95f5296d724ef2a17dab5650c2b6c293fd39fddff1a1ff8b9f", nonce: "4", blockHash: "0x8365b492559e655f720dfe4e049a3c5684043b58419c663328f3ffffcdb2f2a0", transactionIndex: "6", from: "0x2e73e5971326f0c04f3533fd9d82b4e70763dd03", to: 0, value: "0", gas: "1678221", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x392eaafa", contractAddress: "0x5c430fa24f782cf8156ca97208c42127b17b0494", cumulativeGasUsed: "1806121", gasUsed: "1678221", confirmations: "4468150"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "HackDao", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = HackDao.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1487415229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = HackDao.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: ownerDeposit(  )", async function( ) {
		const txOriginal = {blockNumber: "3205629", timeStamp: "1487415382", hash: "0x970485d5cc796677ffe37fd0e28222e002cca7a3a1685185f35c68235b963434", nonce: "5", blockHash: "0xb0faf0f7d33ce649b85520c9e9b0c392ff7bf4395ae5ae2d1a401b5a06853c19", transactionIndex: "9", from: "0x2e73e5971326f0c04f3533fd9d82b4e70763dd03", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "300000000000000000", gas: "21744", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x7b1aa45f", contractAddress: "", cumulativeGasUsed: "282402", gasUsed: "21744", confirmations: "4468132"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "ownerDeposit", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerDeposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1487415382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3205658", timeStamp: "1487415681", hash: "0x786ff04e75ad70f03bd569f9ec89b7867cfad23d7a0c5efa4bb267fe2b3079ae", nonce: "0", blockHash: "0x6663077c7a6babbe94ff790311c289c44b0ced52f01cfe7f2eb951be94396df4", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "165643", gasUsed: "165643", confirmations: "4468103"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1487415681 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x96903986262b2f27be4a3785b8374adb2c212f99f44856041c743076b43a7294"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x96903986262b2f27be4a3785b8374adb2c21... )", async function( ) {
		const txOriginal = {blockNumber: "3205662", timeStamp: "1487415704", hash: "0xf9a7740056f3d4993910f49da87bffd35c6bdf06789db85c089d1da6b4ae5db5", nonce: "63823", blockHash: "0x364d9ffcd9bbceea37f44bcf9f7eae8c13c35c56944cc74ee08a088dd89f2c12", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e96903986262b2f27be4a3785b8374adb2c212f99f44856041c743076b43a7294000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013100000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "106510", gasUsed: "41565", confirmations: "4468099"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x96903986262b2f27be4a3785b8374adb2c212f99f44856041c743076b43a7294"}, {type: "string", name: "result", value: `1`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x96903986262b2f27be4a3785b8374adb2c212f99f44856041c743076b43a7294", `1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1487415704 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x96903986262b2f27be4a3785b8374adb2c212f99f44856041c743076b43a7294"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "lose"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3205666", timeStamp: "1487415756", hash: "0x5747d1c444caf2f564ae6fdfb25cdcef8757db5530c9110e8492daebff38e38f", nonce: "0", blockHash: "0x8c368ea8b6411bd10211a4de502a42509631f795c5e101bc60eb6e6b095e36b0", transactionIndex: "0", from: "0x04df40420e808a5e6abc670049126ba60cfa4c2d", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4468095"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1487415756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x9832b08a899d2476e1427b227801b73f0ec48856eb6d2985d84169a0db7f8106"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x9832b08a899d2476e1427b227801b73f0ec4... )", async function( ) {
		const txOriginal = {blockNumber: "3205668", timeStamp: "1487415797", hash: "0xf53955fe7e33ec20ca5ada6be0ac0f6965411f379b283f50d7118f3b3f5d7c2d", nonce: "63824", blockHash: "0x175e5db77bf4e1ee11ef0b8b60d8ef5a756d82be5f2308c44c9cd011883160d8", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e9832b08a899d2476e1427b227801b73f0ec48856eb6d2985d84169a0db7f8106000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "112734", gasUsed: "47789", confirmations: "4468093"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x9832b08a899d2476e1427b227801b73f0ec48856eb6d2985d84169a0db7f8106"}, {type: "string", name: "result", value: `2`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x9832b08a899d2476e1427b227801b73f0ec48856eb6d2985d84169a0db7f8106", `2`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1487415797 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x9832b08a899d2476e1427b227801b73f0ec48856eb6d2985d84169a0db7f8106"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3205674", timeStamp: "1487415933", hash: "0x9e9caa188c85fc4220f72c83a4b89b40c9b58dc8a7681fdb71de9eb1bf0dbec6", nonce: "1", blockHash: "0x9d8bd96cd39f294f572a2b50aebc9d8b5060f1c830ed97d8014a04607c1ddf5e", transactionIndex: "1", from: "0x04df40420e808a5e6abc670049126ba60cfa4c2d", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "146818", gasUsed: "125818", confirmations: "4468087"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1487415933 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x039276b32cb62e616cc63415b2065b73904ee0bcfceb07f41af3b38c7832bf3b"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x039276b32cb62e616cc63415b2065b73904e... )", async function( ) {
		const txOriginal = {blockNumber: "3205682", timeStamp: "1487416152", hash: "0x1a0d8f04d86ba544e9295c152fa4d66d5a7019669eeea7bb93d74d7d33dacaa6", nonce: "63826", blockHash: "0xec0974311b6fe39a357b2133c902b93469a2041ebf918c9827c3e3a44c999e7a", transactionIndex: "6", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e039276b32cb62e616cc63415b2065b73904ee0bcfceb07f41af3b38c7832bf3b000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "195813", gasUsed: "41565", confirmations: "4468079"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x039276b32cb62e616cc63415b2065b73904ee0bcfceb07f41af3b38c7832bf3b"}, {type: "string", name: "result", value: `2`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x039276b32cb62e616cc63415b2065b73904ee0bcfceb07f41af3b38c7832bf3b", `2`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1487416152 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x039276b32cb62e616cc63415b2065b73904ee0bcfceb07f41af3b38c7832bf3b"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "lose"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: ownerDeposit(  )", async function( ) {
		const txOriginal = {blockNumber: "3205682", timeStamp: "1487416152", hash: "0x6b37cae79c06739e83628da111003866c980797d25cea2e6551181a239f66575", nonce: "7", blockHash: "0xec0974311b6fe39a357b2133c902b93469a2041ebf918c9827c3e3a44c999e7a", transactionIndex: "21", from: "0x2e73e5971326f0c04f3533fd9d82b4e70763dd03", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "1500000000000000000", gas: "21744", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x7b1aa45f", contractAddress: "", cumulativeGasUsed: "620153", gasUsed: "21744", confirmations: "4468079"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "ownerDeposit", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerDeposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1487416152 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3211042", timeStamp: "1487493891", hash: "0xc99cbea87245f2066b676f3910a055decf4b44c1d9d391fb81fee8e69a14ac6c", nonce: "1", blockHash: "0xd8d8d1d8fb94841bf73772c1a9335d94004df92b1ef262cd4d4a1a5a5c161202", transactionIndex: "1", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "146818", gasUsed: "125818", confirmations: "4462719"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1487493891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xe84b6a58c11817204fba644ffce831e3b0144efd27c83df4030bfa26b5157f5d"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe84b6a58c11817204fba644ffce831e3b014... )", async function( ) {
		const txOriginal = {blockNumber: "3211045", timeStamp: "1487493936", hash: "0xecf8ca723ca4f02d7c735ae00e27c40809c09c54dfb3611fbc0f9b250a09c525", nonce: "64083", blockHash: "0x5cac6ab25ce7ec10967553fcded4101490daa1655a7f830234146145f066cbae", transactionIndex: "10", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ee84b6a58c11817204fba644ffce831e3b0144efd27c83df4030bfa26b5157f5d000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013500000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "364353", gasUsed: "47789", confirmations: "4462716"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xe84b6a58c11817204fba644ffce831e3b0144efd27c83df4030bfa26b5157f5d"}, {type: "string", name: "result", value: `5`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xe84b6a58c11817204fba644ffce831e3b0144efd27c83df4030bfa26b5157f5d", `5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1487493936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xe84b6a58c11817204fba644ffce831e3b0144efd27c83df4030bfa26b5157f5d"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3211056", timeStamp: "1487494074", hash: "0x6d8da97d889c8d7182b31836ee4a6848206ce5e6a9e1961d24cec2637241edf0", nonce: "2", blockHash: "0x47bb65c9d0d9f3186137c135b037bbcd3a9dbf1b988ae853a11d07ff8399bb1b", transactionIndex: "1", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "146818", gasUsed: "125818", confirmations: "4462705"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1487494074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xdb2f6785678a8a12969579bdb1e4a9c66b9b6995a9fd95bd3a1f6fc91443be58"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xdb2f6785678a8a12969579bdb1e4a9c66b9b... )", async function( ) {
		const txOriginal = {blockNumber: "3211059", timeStamp: "1487494099", hash: "0x3c71a38a362615918efa8ab23c9afa3d45efa69298456044129d294b74ecc0fd", nonce: "64085", blockHash: "0x60ff2f45284f6d98475b10a82859ad8105ec1e0387851333a9d7005c49525a93", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297edb2f6785678a8a12969579bdb1e4a9c66b9b6995a9fd95bd3a1f6fc91443be58000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "127147", gasUsed: "47789", confirmations: "4462702"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xdb2f6785678a8a12969579bdb1e4a9c66b9b6995a9fd95bd3a1f6fc91443be58"}, {type: "string", name: "result", value: `3`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xdb2f6785678a8a12969579bdb1e4a9c66b9b6995a9fd95bd3a1f6fc91443be58", `3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1487494099 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xdb2f6785678a8a12969579bdb1e4a9c66b9b6995a9fd95bd3a1f6fc91443be58"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3211062", timeStamp: "1487494127", hash: "0x384b69a949359baeee692823626f6e008914a25e554ad59ae2d2008553b244b5", nonce: "3", blockHash: "0x1a2867497a7b4808b158e59428e72d73425350a46d4921c90fb9e04286f11d77", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4462699"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1487494127 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x90829f408c6cc68d2251b6b752fe8db3a92c8be07caa5cb65cede335d7991592"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x90829f408c6cc68d2251b6b752fe8db3a92c... )", async function( ) {
		const txOriginal = {blockNumber: "3211064", timeStamp: "1487494146", hash: "0x7e3bd0dee890e578bf7ef319a15760891f0b05511fd6bf6e7b269eb0e1954091", nonce: "64086", blockHash: "0x132cb25d19e22c6db259245942c094abd10c5a4f73e566e791d2c65278961a0b", transactionIndex: "4", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e90829f408c6cc68d2251b6b752fe8db3a92c8be07caa5cb65cede335d7991592000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000023130000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "148557", gasUsed: "48263", confirmations: "4462697"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x90829f408c6cc68d2251b6b752fe8db3a92c8be07caa5cb65cede335d7991592"}, {type: "string", name: "result", value: `10`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x90829f408c6cc68d2251b6b752fe8db3a92c8be07caa5cb65cede335d7991592", `10`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1487494146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x90829f408c6cc68d2251b6b752fe8db3a92c8be07caa5cb65cede335d7991592"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "2"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3216668", timeStamp: "1487574911", hash: "0x9bfa2d779b4c2180cd82e3a36d6e0fb7b974c99645fc79513a75d70fad0b73ac", nonce: "2", blockHash: "0xf1f63c3bc6a26ea633a4c2bf1c561724a0e94c9ce8d54bec5f4fa820e2019d28", transactionIndex: "2", from: "0x04df40420e808a5e6abc670049126ba60cfa4c2d", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "193678", gasUsed: "125818", confirmations: "4457093"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1487574911 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x8f1203adb51e92c034559963ad8220af1015e3e2e71556fad626fa7e4bab94d8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x8f1203adb51e92c034559963ad8220af1015... )", async function( ) {
		const txOriginal = {blockNumber: "3216670", timeStamp: "1487574998", hash: "0x8292ea52b9dd3112fdebca7ac6353548cef7daf928a98e7129cef7fa704a0234", nonce: "64235", blockHash: "0x3f7e42d5645b594907543137202860b307911b2375906cb099ee294a73a8a682", transactionIndex: "18", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e8f1203adb51e92c034559963ad8220af1015e3e2e71556fad626fa7e4bab94d8000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000023130000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "473072", gasUsed: "48263", confirmations: "4457091"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x8f1203adb51e92c034559963ad8220af1015e3e2e71556fad626fa7e4bab94d8"}, {type: "string", name: "result", value: `10`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x8f1203adb51e92c034559963ad8220af1015e3e2e71556fad626fa7e4bab94d8", `10`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1487574998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x8f1203adb51e92c034559963ad8220af1015e3e2e71556fad626fa7e4bab94d8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3221833", timeStamp: "1487647865", hash: "0xac2c5f71e3334b42e2c726e268d7a46705005c53a4dc93415ae78322c6fecab2", nonce: "4", blockHash: "0xec8fc0f5fc2f684429e481d8bcea6ec0708a2921c2c85b4cc403eba06bb40b7d", transactionIndex: "1", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "159389", gasUsed: "125818", confirmations: "4451928"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1487647865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x32c5b4bdb864a773d283022733d437d6447ea93aaa13f466ec698cb35de6d29d"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x32c5b4bdb864a773d283022733d437d6447e... )", async function( ) {
		const txOriginal = {blockNumber: "3221836", timeStamp: "1487647891", hash: "0x8b67690a9064db940aff6c273bccbaa119d9ce80d72ccc4c4b3b4154fba69ac3", nonce: "64417", blockHash: "0xa335de0ee92e5212136ae3c85e4329861e153b59060a8c9d5f5956b152980449", transactionIndex: "2", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e32c5b4bdb864a773d283022733d437d6447ea93aaa13f466ec698cb35de6d29d000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013500000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "93491", gasUsed: "47789", confirmations: "4451925"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x32c5b4bdb864a773d283022733d437d6447ea93aaa13f466ec698cb35de6d29d"}, {type: "string", name: "result", value: `5`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x32c5b4bdb864a773d283022733d437d6447ea93aaa13f466ec698cb35de6d29d", `5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1487647891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x32c5b4bdb864a773d283022733d437d6447ea93aaa13f466ec698cb35de6d29d"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "2"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3221845", timeStamp: "1487648035", hash: "0xae5b91f30b7ec1924127c8019bb668ed4f37ee482afcd2d3d7668f09dacf0890", nonce: "5", blockHash: "0xb240f7c5514628a069cdb74e3ebec0b15ed7008a43a10cc039103d0e35ede15e", transactionIndex: "2", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "167818", gasUsed: "125818", confirmations: "4451916"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "3"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1487648035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xfeb43fcf7bbc18656f51f82222b0333f45950763312924a85e2bde2db9daf7b4"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfeb43fcf7bbc18656f51f82222b0333f4595... )", async function( ) {
		const txOriginal = {blockNumber: "3221850", timeStamp: "1487648100", hash: "0x1b48864b49260b25d7371bcca7efe7ade95a53ec3dec177a1e5fc28fef1a1031", nonce: "64418", blockHash: "0xdbed7b7d0e710edaff1d9692697ddd688dfbbf6d55dbba58f6871911c1fe71aa", transactionIndex: "13", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297efeb43fcf7bbc18656f51f82222b0333f45950763312924a85e2bde2db9daf7b4000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013800000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "486206", gasUsed: "47789", confirmations: "4451911"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfeb43fcf7bbc18656f51f82222b0333f45950763312924a85e2bde2db9daf7b4"}, {type: "string", name: "result", value: `8`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xfeb43fcf7bbc18656f51f82222b0333f45950763312924a85e2bde2db9daf7b4", `8`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1487648100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xfeb43fcf7bbc18656f51f82222b0333f45950763312924a85e2bde2db9daf7b4"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "3"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "3221857", timeStamp: "1487648175", hash: "0x865ea556cd24fc594d31e708b519f74f4bba5582a6c5806f852b21aab09354fd", nonce: "6", blockHash: "0xeb1720f1e717e5979c7ccbca152d7a315b2087758c146c4f192f727ab91dfb9e", transactionIndex: "9", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "314818", gasUsed: "125818", confirmations: "4451904"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "4"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1487648175 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x4f67629fe3d01e87de0d7a80c73c39f07bf938f992f4aaaaccd742881a6a75a7"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4f67629fe3d01e87de0d7a80c73c39f07bf9... )", async function( ) {
		const txOriginal = {blockNumber: "3221860", timeStamp: "1487648205", hash: "0x4e3f819047e4686bdd529f3874f52c51a4ba8f4042a97b35a5ecb2369af8d90e", nonce: "64419", blockHash: "0xece763799e1c8e16eed6e5d316273370e0d690480114a9f887f73d6f074ee362", transactionIndex: "9", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e4f67629fe3d01e87de0d7a80c73c39f07bf938f992f4aaaaccd742881a6a75a7000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013600000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1683356", gasUsed: "47789", confirmations: "4451901"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4f67629fe3d01e87de0d7a80c73c39f07bf938f992f4aaaaccd742881a6a75a7"}, {type: "string", name: "result", value: `6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x4f67629fe3d01e87de0d7a80c73c39f07bf938f992f4aaaaccd742881a6a75a7", `6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1487648205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x4f67629fe3d01e87de0d7a80c73c39f07bf938f992f4aaaaccd742881a6a75a7"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "4"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3223557", timeStamp: "1487673693", hash: "0xefbc9488e7d4c929b16cc486bb8869743fc68b6c79d4d104e1b63ed9f61aa2fa", nonce: "7", blockHash: "0x202f1a7761c8e033fe831ed270d0524ff737252e754cf19d92dbc47244a7e63a", transactionIndex: "3", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "190241", gasUsed: "125818", confirmations: "4450204"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1487673693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x6a28c282ab6a6c16ca4b98b576760515c0bca4d96f07c73fe81e57eac5ec99e9"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x6a28c282ab6a6c16ca4b98b576760515c0bc... )", async function( ) {
		const txOriginal = {blockNumber: "3223559", timeStamp: "1487673721", hash: "0x5911a8b886382a156626ecea0a0cb8d0772dba8992396b0bfc52dc977fa1edbb", nonce: "64464", blockHash: "0xf0f91e270f3a944ebb43be919ae763263cfbde46ef45b76078f29c72c94568a9", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e6a28c282ab6a6c16ca4b98b576760515c0bca4d96f07c73fe81e57eac5ec99e9000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "146035", gasUsed: "47789", confirmations: "4450202"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x6a28c282ab6a6c16ca4b98b576760515c0bca4d96f07c73fe81e57eac5ec99e9"}, {type: "string", name: "result", value: `9`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x6a28c282ab6a6c16ca4b98b576760515c0bca4d96f07c73fe81e57eac5ec99e9", `9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1487673721 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x6a28c282ab6a6c16ca4b98b576760515c0bca4d96f07c73fe81e57eac5ec99e9"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3223563", timeStamp: "1487673762", hash: "0x4df0cddb75f1a80db6608ca2c631b6734881131cc0e082b1ba50f55802b9d291", nonce: "8", blockHash: "0x949ad69b06b2e41e4fdb8f73b2f2d2b53594d813698ec0a2b3319f774a37ef07", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4450198"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "3"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1487673762 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x6d1cebc8f9d5afee40b405a5c9eb11c9b37154a4aa7d7d4f7245734d2ea5c32c"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x6d1cebc8f9d5afee40b405a5c9eb11c9b371... )", async function( ) {
		const txOriginal = {blockNumber: "3223566", timeStamp: "1487673779", hash: "0x76f905862be08449f2f40477d1ad6e96e32a15a43ffc6f7d3a7122c5c7730c24", nonce: "64465", blockHash: "0x793c4d3e901efe4c63d0f29f30b831d264d30aa42ef9a63e798f83b2904d2dd1", transactionIndex: "2", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e6d1cebc8f9d5afee40b405a5c9eb11c9b37154a4aa7d7d4f7245734d2ea5c32c000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "105277", gasUsed: "41565", confirmations: "4450195"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x6d1cebc8f9d5afee40b405a5c9eb11c9b37154a4aa7d7d4f7245734d2ea5c32c"}, {type: "string", name: "result", value: `3`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x6d1cebc8f9d5afee40b405a5c9eb11c9b37154a4aa7d7d4f7245734d2ea5c32c", `3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1487673779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x6d1cebc8f9d5afee40b405a5c9eb11c9b37154a4aa7d7d4f7245734d2ea5c32c"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "lose"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3223573", timeStamp: "1487673832", hash: "0x86e2d3c8615f344d25d14a79c364f1b72cca909882220901716041f32c8d4fca", nonce: "9", blockHash: "0x1b61024d186dab9d1a523537774dcd2eb8a534cce6f59c21644047dec52a0ff3", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4450188"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1487673832 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x03d2abaf017406ac90a9587da6ec392d0ea090bbb062665cd8fb4245bdbd1a6b"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x03d2abaf017406ac90a9587da6ec392d0ea0... )", async function( ) {
		const txOriginal = {blockNumber: "3223575", timeStamp: "1487673856", hash: "0x53f489f06edb65b776d16ebd5cd73cc3f184fb0abdb1e83c8783271cee414682", nonce: "64466", blockHash: "0xeb66b9e8dbb0acebe63022b09c2ca7dcb6247bf3ce1fd4b1cadd32796418f27a", transactionIndex: "5", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e03d2abaf017406ac90a9587da6ec392d0ea090bbb062665cd8fb4245bdbd1a6b000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "197117", gasUsed: "47789", confirmations: "4450186"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x03d2abaf017406ac90a9587da6ec392d0ea090bbb062665cd8fb4245bdbd1a6b"}, {type: "string", name: "result", value: `9`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x03d2abaf017406ac90a9587da6ec392d0ea090bbb062665cd8fb4245bdbd1a6b", `9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1487673856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x03d2abaf017406ac90a9587da6ec392d0ea090bbb062665cd8fb4245bdbd1a6b"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3223578", timeStamp: "1487673898", hash: "0x2916f6bff7af88d215b1a3186fc4f4ae948adb758b90424ef8dcbd5cce3e49a4", nonce: "10", blockHash: "0x488e67eefd002992e5e243f4cb937aee59d7bf46a69e4c70de883d0fc6442921", transactionIndex: "1", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "159389", gasUsed: "125818", confirmations: "4450183"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1487673898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x158efe79d3074a68e1f460f8065845ae00fc9a538910105039fa14242be0d8b6"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x158efe79d3074a68e1f460f8065845ae00fc... )", async function( ) {
		const txOriginal = {blockNumber: "3223581", timeStamp: "1487673936", hash: "0x0482d46075d540870393105423a3665e31ae2a37b816e9461128ba0c18f8b102", nonce: "64467", blockHash: "0xc3dd3568d71cf78411b8ed87a6d25e5d7c064768ae0784a2dc4bddbbb916d654", transactionIndex: "1", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e158efe79d3074a68e1f460f8065845ae00fc9a538910105039fa14242be0d8b6000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013600000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "94553", gasUsed: "47757", confirmations: "4450180"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x158efe79d3074a68e1f460f8065845ae00fc9a538910105039fa14242be0d8b6"}, {type: "string", name: "result", value: `6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x158efe79d3074a68e1f460f8065845ae00fc9a538910105039fa14242be0d8b6", `6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1487673936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x158efe79d3074a68e1f460f8065845ae00fc9a538910105039fa14242be0d8b6"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "2"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3223586", timeStamp: "1487674001", hash: "0x32e11d6ee7876a179ee3d5ac1d08a0f02e3b843211977b872feb663b637c909a", nonce: "11", blockHash: "0x30bfbd92a5c05bc2ff4629a479a118149091f5e01781896072ff25d3d4d1fa9c", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4450175"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "3"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1487674001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x53f4027d9b39b2f66adbb338fdaa6868e1c922dd90bbb867fb14bb668d9f3bb8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x53f4027d9b39b2f66adbb338fdaa6868e1c9... )", async function( ) {
		const txOriginal = {blockNumber: "3223589", timeStamp: "1487674085", hash: "0xbfdc8455a48daa794b457976b3064fd751be280487a49c1177bc2c74dbb3464c", nonce: "64468", blockHash: "0x74ae83812d765c40f703df7ada3f5956a727dbcc7c6bf0e07a5054facafaa637", transactionIndex: "8", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e53f4027d9b39b2f66adbb338fdaa6868e1c922dd90bbb867fb14bb668d9f3bb8000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "281323", gasUsed: "47789", confirmations: "4450172"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x53f4027d9b39b2f66adbb338fdaa6868e1c922dd90bbb867fb14bb668d9f3bb8"}, {type: "string", name: "result", value: `9`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x53f4027d9b39b2f66adbb338fdaa6868e1c922dd90bbb867fb14bb668d9f3bb8", `9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1487674085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x53f4027d9b39b2f66adbb338fdaa6868e1c922dd90bbb867fb14bb668d9f3bb8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "3"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "3223591", timeStamp: "1487674134", hash: "0xf0166787e53940e6c5855d4f59a70b3f9be38401719cb542e367c83f33458b13", nonce: "12", blockHash: "0xade5603024c90eda12ce74a8588ac6459279e871723d92096fc4d948288039c1", transactionIndex: "1", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "146818", gasUsed: "125818", confirmations: "4450170"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "4"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1487674134 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xd3850186a836503795b3a467fc06f8fd176d7c0d4a945a8a6380f8c048c27cb8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd3850186a836503795b3a467fc06f8fd176d... )", async function( ) {
		const txOriginal = {blockNumber: "3223596", timeStamp: "1487674175", hash: "0x15e3010718ccabae0ab8d8b9051b768935b377a58e8ac1520bc1570e3144e2f2", nonce: "64469", blockHash: "0xc4d3ed249e145e2a1aa763bbb1a6ae2b4fefdeb88d8de6f731d1e2ab729afe72", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ed3850186a836503795b3a467fc06f8fd176d7c0d4a945a8a6380f8c048c27cb8000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "186506", gasUsed: "41565", confirmations: "4450165"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xd3850186a836503795b3a467fc06f8fd176d7c0d4a945a8a6380f8c048c27cb8"}, {type: "string", name: "result", value: `2`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xd3850186a836503795b3a467fc06f8fd176d7c0d4a945a8a6380f8c048c27cb8", `2`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1487674175 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xd3850186a836503795b3a467fc06f8fd176d7c0d4a945a8a6380f8c048c27cb8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "lose"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3223601", timeStamp: "1487674240", hash: "0xb55ff90be549b313741203024708855398a22936b76e4d259f1ab702cc6fe617", nonce: "13", blockHash: "0x42ebf8675eaefcd54fb5c6c2e077be772b882eecdbeab38de2c0e8900567259f", transactionIndex: "2", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "167818", gasUsed: "125818", confirmations: "4450160"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1487674240 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x52003b185f4aebc5adb7e86399109d48290675a843f358c8e17a9c727a2b8cc6"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x52003b185f4aebc5adb7e86399109d482906... )", async function( ) {
		const txOriginal = {blockNumber: "3223604", timeStamp: "1487674265", hash: "0xc31584ae4be5204a297317442f5e3383eff56ce591dc8b95e4da2335d4f1f9f5", nonce: "64470", blockHash: "0x3350412debf888c30ea5bcec7d33d2479eaa5835d05489c2b18f95bd87873406", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e52003b185f4aebc5adb7e86399109d48290675a843f358c8e17a9c727a2b8cc6000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013700000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "134497", gasUsed: "47757", confirmations: "4450157"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x52003b185f4aebc5adb7e86399109d48290675a843f358c8e17a9c727a2b8cc6"}, {type: "string", name: "result", value: `7`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x52003b185f4aebc5adb7e86399109d48290675a843f358c8e17a9c727a2b8cc6", `7`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1487674265 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x52003b185f4aebc5adb7e86399109d48290675a843f358c8e17a9c727a2b8cc6"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3223814", timeStamp: "1487676792", hash: "0xd9139ec4c88b599c06ca16abd29c75e501ac23f407a502fa043762475de5fdde", nonce: "14", blockHash: "0x78c10565ba7cb8d2c54c7047ea213c95cfe2c53683e0f48823f415d8d9505f29", transactionIndex: "4", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "209818", gasUsed: "125818", confirmations: "4449947"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1487676792 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x3f1eb0cf00cb64f2b6d1ea484fa82738b666a3d4cbc26634b5988b3ce1674894"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x3f1eb0cf00cb64f2b6d1ea484fa82738b666... )", async function( ) {
		const txOriginal = {blockNumber: "3223822", timeStamp: "1487676861", hash: "0x677ed0af341a7fbbd390ce8fa76f41017650b3dd9ad40940867f25f1e0ff6fac", nonce: "64475", blockHash: "0xcc26056dfcc04a41b535d9ac5c5061b0b68fc2008ec1f5c9bdc2dc0da7eb366f", transactionIndex: "12", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e3f1eb0cf00cb64f2b6d1ea484fa82738b666a3d4cbc26634b5988b3ce1674894000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013600000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "345350", gasUsed: "47757", confirmations: "4449939"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x3f1eb0cf00cb64f2b6d1ea484fa82738b666a3d4cbc26634b5988b3ce1674894"}, {type: "string", name: "result", value: `6`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x3f1eb0cf00cb64f2b6d1ea484fa82738b666a3d4cbc26634b5988b3ce1674894", `6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1487676861 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x3f1eb0cf00cb64f2b6d1ea484fa82738b666a3d4cbc26634b5988b3ce1674894"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3223826", timeStamp: "1487676995", hash: "0x5be7fbafb4649e4202c713367e5c9d6ffb1a211ea3f58fcf796909ed4fb6bd1c", nonce: "15", blockHash: "0x7172a36eaafa736bb55350314de89d8c0cf0484a48b55f89b8a9f2018a817a3d", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4449935"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1487676995 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xb3b3231b73a518ad1fbe078d6b3ab2dbf82f14c28e69157f467a7964b826a2f4"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xb3b3231b73a518ad1fbe078d6b3ab2dbf82f... )", async function( ) {
		const txOriginal = {blockNumber: "3223829", timeStamp: "1487677031", hash: "0x5ebce0c12aaa7e7a86929f730337cb2255ae122d360a8f3e8a6162577340694c", nonce: "64476", blockHash: "0xb69d0a75fb615c3c803bb9b31d06d6aba978d0bb8e8f3cb530f3036591abefbb", transactionIndex: "5", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297eb3b3231b73a518ad1fbe078d6b3ab2dbf82f14c28e69157f467a7964b826a2f4000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "253779", gasUsed: "47789", confirmations: "4449932"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xb3b3231b73a518ad1fbe078d6b3ab2dbf82f14c28e69157f467a7964b826a2f4"}, {type: "string", name: "result", value: `9`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xb3b3231b73a518ad1fbe078d6b3ab2dbf82f14c28e69157f467a7964b826a2f4", `9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1487677031 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xb3b3231b73a518ad1fbe078d6b3ab2dbf82f14c28e69157f467a7964b826a2f4"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "2"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3223848", timeStamp: "1487677284", hash: "0xca8fedfb1c81071e09d5fa75317496f41ac4fb4e85bce5b5f3ddc8dae7720e8f", nonce: "16", blockHash: "0x38c276021b11adfba2d054451ac47d9d526873b8768231ba3685ff2ddc29216b", transactionIndex: "1", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "178092", gasUsed: "125818", confirmations: "4449913"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1487677284 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xfd781e78d9c12d4bb8ff230151cfe426249538a85487967853224210ad15adca"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfd781e78d9c12d4bb8ff230151cfe4262495... )", async function( ) {
		const txOriginal = {blockNumber: "3223851", timeStamp: "1487677309", hash: "0xa8f6e573cd81cbbc7d1f7c5fad0daecc490128fff4f141632163face0a647e9b", nonce: "64477", blockHash: "0x109e6368b79d09f06a4a66c7ba7bbed8aa3b4a4bc25239cb41239b2f5e7dde1b", transactionIndex: "2", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297efd781e78d9c12d4bb8ff230151cfe426249538a85487967853224210ad15adca000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000023130000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "112103", gasUsed: "48263", confirmations: "4449910"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfd781e78d9c12d4bb8ff230151cfe426249538a85487967853224210ad15adca"}, {type: "string", name: "result", value: `10`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xfd781e78d9c12d4bb8ff230151cfe426249538a85487967853224210ad15adca", `10`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1487677309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xfd781e78d9c12d4bb8ff230151cfe426249538a85487967853224210ad15adca"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "2"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "3223892", timeStamp: "1487677883", hash: "0xb41a594e4a9351ba78f91b31c1e452243d1dc77e9acc003750e9a4bcc0271a95", nonce: "17", blockHash: "0x10b49602a82407fcec613867b61003f269fff3fcd37af8e42ba000c758615f87", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4449869"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "3"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1487677883 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x4b169277ab4cc5c5c23e41b6430cebc6c57ad6a608e17ffc88578cdf4c1949c8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4b169277ab4cc5c5c23e41b6430cebc6c57a... )", async function( ) {
		const txOriginal = {blockNumber: "3223894", timeStamp: "1487677926", hash: "0x3f673949c9b057b61b5b2d2e53c9a4221f5333e297119b47f72cac994a6695f9", nonce: "64478", blockHash: "0xcc03b5de79818c10e2985ad464ec522c031e371f6abcd6d2479a464394ed4ba1", transactionIndex: "8", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e4b169277ab4cc5c5c23e41b6430cebc6c57ad6a608e17ffc88578cdf4c1949c8000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013100000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "247722", gasUsed: "41565", confirmations: "4449867"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4b169277ab4cc5c5c23e41b6430cebc6c57ad6a608e17ffc88578cdf4c1949c8"}, {type: "string", name: "result", value: `1`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x4b169277ab4cc5c5c23e41b6430cebc6c57ad6a608e17ffc88578cdf4c1949c8", `1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1487677926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x4b169277ab4cc5c5c23e41b6430cebc6c57ad6a608e17ffc88578cdf4c1949c8"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "lose"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3229962", timeStamp: "1487765285", hash: "0xd630958e5f7a441748fd9ce56b49c18b047bf35da16fc10c78dc35f041685d25", nonce: "21", blockHash: "0xc7ed1540ad61a3f285e1d8512f193450ba1ee390bf240708d8adff2d061ade6a", transactionIndex: "0", from: "0x90dd6a9746dea01a8b3863d179af227170692f70", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4443799"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1487765285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x27e5d5622149f6472abc9068c228b1c73e631b02f1960477772b2871dcc4fc23"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "755011264000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x27e5d5622149f6472abc9068c228b1c73e63... )", async function( ) {
		const txOriginal = {blockNumber: "3229968", timeStamp: "1487765328", hash: "0x3c9936978b7dc038d7e460f3e9862e7324a494e45b2876bc12ae2254bc986552", nonce: "64730", blockHash: "0xc29f1b530a79ee6967dbb18a5388d8505e2b7befcecbe5ee9475291a39bbfe68", transactionIndex: "5", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e27e5d5622149f6472abc9068c228b1c73e631b02f1960477772b2871dcc4fc23000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013100000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "253133", gasUsed: "41565", confirmations: "4443793"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x27e5d5622149f6472abc9068c228b1c73e631b02f1960477772b2871dcc4fc23"}, {type: "string", name: "result", value: `1`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x27e5d5622149f6472abc9068c228b1c73e631b02f1960477772b2871dcc4fc23", `1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1487765328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0x27e5d5622149f6472abc9068c228b1c73e631b02f1960477772b2871dcc4fc23"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "lose"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3236650", timeStamp: "1487861459", hash: "0x16c55b06921aa8585aa4aee587492cc14f41492354b65f71a1049df5cb7177f1", nonce: "18", blockHash: "0x6b941ea2ad1d384392d3b175bace9a0e0e39aec56ce895fc049265af31fc0b9c", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4437111"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "1"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1487861459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xfbf96aae2a8fc953af8f6ff8504fa96f47a14aab55aae333929ea4ad8503a6b3"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfbf96aae2a8fc953af8f6ff8504fa96f47a1... )", async function( ) {
		const txOriginal = {blockNumber: "3236653", timeStamp: "1487861478", hash: "0xf88a6d2190c1a0787ef134bdd9c0535f5de152d6f2ba54d1986ad4ecd808d99c", nonce: "65151", blockHash: "0x36a23ed9feef0ba71f9f7dd54568249476ad71675ebc90d91c03062d7feb14db", transactionIndex: "8", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "0", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297efbf96aae2a8fc953af8f6ff8504fa96f47a14aab55aae333929ea4ad8503a6b3000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000013800000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "281976", gasUsed: "47789", confirmations: "4437108"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfbf96aae2a8fc953af8f6ff8504fa96f47a14aab55aae333929ea4ad8503a6b3"}, {type: "string", name: "result", value: `8`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xfbf96aae2a8fc953af8f6ff8504fa96f47a14aab55aae333929ea4ad8503a6b3", `8`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1487861478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xfbf96aae2a8fc953af8f6ff8504fa96f47a14aab55aae333929ea4ad8503a6b3"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "string"}], name: "LogS", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogS", events: [{name: "s", type: "string", value: "callback"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}, {name: "LogS", events: [{name: "s", type: "string", value: "win"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "s", type: "uint256"}], name: "LogI", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogI", events: [{name: "s", type: "uint256", value: "1"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: game( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "3242730", timeStamp: "1487948295", hash: "0xb94a784e6676a3b1d4ce6a673a079eeb5af6b628002db9e942d2fed25ff6c100", nonce: "19", blockHash: "0x8fb2acbdd526477eb49b2cf3a54c155830210a9140cbbf72159a92aba7dfce4c", transactionIndex: "0", from: "0x4c3e5a7fd703225701ef7c08adf214244038ddc3", to: "0x5c430fa24f782cf8156ca97208c42127b17b0494", value: "200000000000000000", gas: "600000", gasPrice: "31000000000", isError: "0", txreceipt_status: "", input: "0xcddbe7290000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "125818", gasUsed: "125818", confirmations: "4431031"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "level", value: "2"}], name: "game", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "game(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1487948295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "h", type: "bytes32"}], name: "LogB", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogB", events: [{name: "h", type: "bytes32", value: "0xdda65686d227d5aa9e5cbf25b90f78e67bf3bbf7c34084bf21f5c17d91c725de"}], address: "0x5c430fa24f782cf8156ca97208c42127b17b0494"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "30722649000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1870582338902149080" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
