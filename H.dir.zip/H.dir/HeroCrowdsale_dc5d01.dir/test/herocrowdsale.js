const HeroCrowdsale = artifacts.require( "./HeroCrowdsale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "HeroCrowdsale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xA1D2c7E6DE2fA512f1FdF486Ca17ab79b4DC5d01", "0xe7aF11370C3BaB51230D8307454350bDf6d68f4a", "0x273f7F8E6489682Df756151F5525576E322d51A3", "0xA1780310Fad8f98B0eAF8D484c8af499A67e2959", "0x7E1DCf785f0353BF657c38Ab7865C1f184EFE208", "0xc5BcFc66e795878539b32eBEF0dc9F9E53D29e2B", "0xB1f72E1a73667aC9b600685539040A48bf5F2d3B", "0x0537544De3935408246EE2Ad09949D046F92574D", "0x078dA415709285050cd9d683e08f395143256ba8", "0xd5e4868B51439ac87279B0d0117B7E2f36475058", "0x8C5fC43ad00Cc53e11F61bEce329DDc5E3ea0929", "0xD3A22d084dD16196b7862BC2D309412B508318fB", "0x1693Ae817e424C2dbC4138313B7B46c91Bb968f4", "0x5C5aaf9E86bD9a2732Fb351add176c7C6A21CBdF", "0x7Ae0048bB33650EDb349F6fC65fD23A39430E752", "0x62b8B7B7Af7CB5847Dd7335e0B6B4229CD1B7d48", "0xB130168eC63Ca7e30A8f8C7268aA56E4d6730Fb5", "0x981E6097e2bdffEFe1b0D09777c3422bB6bB24C8", "0x96080155dD976e98305fa9aEa96834A03ABDA864", "0x81d661b2b5865ECb0E331463483055215e624997", "0xd868711BD9a2C6F1548F5f4737f71DA67d821090", "0x3c11e8922bC793d2fbd7E3e454241c587AE42010", "0x583780EEBaB14b8f7082c6b2e7ddCfA60B1A7C29", "0x05eCC0958eeE0aCBe1BB2E9aae847466c20EAc47", "0x6Efd9BF1c87A2946aceA38043DC9a4C03ADE8B7f", "0x8bCc48f937a6E076EC25838436Fa6118f0c153d2", "0xae015ccDE814DA988dbcA7f09c10F7c25D6931c3", "0x7da610dC64179389591D04c602CC58F5c82725F4", "0x759dE6B9806A5F695B8FE92f58a6771fB5DB52C6", "0xD718B31115927C7a60165423B357ba59B7e38643", "0xfcFEb1c563ce8a545F25f14a44Df37360744F045", "0xB007f748f2223E205483d80a3b634bFD5268A504", "0xA52Fb91a60bF7987dd527122CE68ba0e64737B03", "0x6825e9dC7D9a43480948d451dbCb78Ad25E55937", "0x12BCEFAff8878F84Fdd4ce2f33C3b49Ee43dE948"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "heroAsset", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint16"}], name: "heroTypeToHeroSales", outputs: [{name: "highestPrice", type: "uint128"}, {name: "previousPrice", type: "uint128"}, {name: "priceIncreaseTo", type: "uint128"}, {name: "since", type: "uint64"}, {name: "until", type: "uint64"}, {name: "previousSaleAt", type: "uint64"}, {name: "lowestPriceRate", type: "uint16"}, {name: "decreaseRate", type: "uint16"}, {name: "supplyLimit", type: "uint16"}, {name: "suppliedCounts", type: "uint16"}, {name: "currency", type: "uint8"}, {name: "exists", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isPauser", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint16"}, {name: "", type: "uint256"}], name: "heroTypeIds", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint16"}, {name: "", type: "address"}], name: "hasAirDropHero", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isReferrer", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_heroType", type: "uint16"}], name: "computeCurrentPrice", outputs: [{name: "", type: "uint8"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "soldPrice", type: "uint256"}, {indexed: false, name: "soldAt", type: "uint64"}, {indexed: false, name: "priceIncreaseTo", type: "uint256"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}, {indexed: false, name: "purchasedBy", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "currency", type: "uint8"}], name: "SoldHeroEvent", type: "event"}, {anonymous: false, inputs: [], name: "Paused", type: "event"}, {anonymous: false, inputs: [], name: "Unpaused", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["AddSalesEvent(uint16,uint128,uint256,uint256)", "SoldHeroEvent(uint16,uint256,uint64,uint256,uint256,uint256,address,address,uint8)", "Paused()", "Unpaused()", "PauserAdded(address)", "PauserRemoved(address)", "ReferrerAdded(address)", "ReferrerRemoved(address)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xbb9aad0aec529392a851fee029d68b1fe345568b44c44e3e4ea716375f494952", "0x3db18ae119a752978a5fdd210c2d8457748cafadf61769dde052bb15edb62e7f", "0x9e87fac88ff661f02d44f95383c817fece4bce600a3dab7a54406878b965e752", "0xa45f47fdea8a1efdd9029a5691c7f759c32b7c698632b563573e155625d16933", "0x6719d08c1888103bea251a4ed56406bd0c3e69723c8a1686e017e7bbe159b6f8", "0xcd265ebaf09df2871cc7bd4133404a235ba12eff2041bb89d9c714a2621c7c7e", "0x51e6bb66cce1aac9478cbafcad3421bf2a600ce8ec3874296c671ab32c68ce92", "0x68e673b5cfb652e620fba208d02d6b172a0dc242d4497d94a1f92bb5fa92bc31", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6783033 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6798673 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "HeroCrowdsale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "heroAsset", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "heroAsset()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "", value: random.range( maxRandom )}], name: "heroTypeToHeroSales", outputs: [{name: "highestPrice", type: "uint128"}, {name: "previousPrice", type: "uint128"}, {name: "priceIncreaseTo", type: "uint128"}, {name: "since", type: "uint64"}, {name: "until", type: "uint64"}, {name: "previousSaleAt", type: "uint64"}, {name: "lowestPriceRate", type: "uint16"}, {name: "decreaseRate", type: "uint16"}, {name: "supplyLimit", type: "uint16"}, {name: "suppliedCounts", type: "uint16"}, {name: "currency", type: "uint8"}, {name: "exists", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "heroTypeToHeroSales(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isPauser", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPauser(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "heroTypeIds", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "heroTypeIds(uint16,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "", value: random.range( maxRandom )}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "hasAirDropHero", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasAirDropHero(uint16,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isReferrer", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isReferrer(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "_heroType", value: random.range( maxRandom )}], name: "computeCurrentPrice", outputs: [{name: "", type: "uint8"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "computeCurrentPrice(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "HeroCrowdsale", function( accounts ) {

	it( "TEST: HeroCrowdsale(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6783033", timeStamp: "1543334823", hash: "0x409857c98951f1803f9d71298759383124548a33ae89676a126a90a45b8bb750", nonce: "39", blockHash: "0xa768b34fd855f2746fca3787db4245614fe58395e0feb69ea720b4152a413c93", transactionIndex: "38", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: 0, value: "0", gas: "3370702", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x63836109", contractAddress: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", cumulativeGasUsed: "5215890", gasUsed: "3370702", confirmations: "918871"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "HeroCrowdsale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = HeroCrowdsale.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543334823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = HeroCrowdsale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setHeroAssetAddress( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6788076", timeStamp: "1543406620", hash: "0x61ce3a710474f757abbd640afb934b8c46d980a852221fc97e482177353df51b", nonce: "41", blockHash: "0x40328d756d94e07f3104bce0c0e029676435caef7722b50cc81c9432421ba499", transactionIndex: "101", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "43829", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x985df3a7000000000000000000000000273f7f8e6489682df756151f5525576e322d51a3", contractAddress: "", cumulativeGasUsed: "5908792", gasUsed: "43829", confirmations: "913828"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_heroAssetAddress", value: addressList[4]}], name: "setHeroAssetAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setHeroAssetAddress(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543406620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"5006\", \"4000000000000000000\", \"50\... )", async function( ) {
		const txOriginal = {blockNumber: "6788144", timeStamp: "1543407623", hash: "0x563e0abd4fb920d5a203253ba27378b819093638681b6a1a83a626619fe27570", nonce: "42", blockHash: "0xfb4ae26b14e2a68fd42042367a33c776b54b8427b1846fbb18991463bfe62f2e", transactionIndex: "65", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a000000000000000000000000000000000000000000000000000000000000138e0000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5592417", gasUsed: "160865", confirmations: "913760"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5006"}, {type: "uint128", name: "_startPrice", value: "4000000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "20"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "5006", "4000000000000000000", "50", "10", "1543557600", "1544421600", "20", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543407623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000138e"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 18, c: [40000]}}, {name: "lowestPrice", type: "uint256", value: "2000000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"5007\", \"4000000000000000000\", \"50\... )", async function( ) {
		const txOriginal = {blockNumber: "6788147", timeStamp: "1543407683", hash: "0x33bc74c3b06f929f4e7d32cd8032fbb4671c62064e40e0374ab43357d315b3c2", nonce: "43", blockHash: "0x92ff3f89f2afb6b6207d65d1984af30bd8d96f551a9ff64f659e73f2693c2985", transactionIndex: "30", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a000000000000000000000000000000000000000000000000000000000000138f0000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2278384", gasUsed: "160865", confirmations: "913757"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5007"}, {type: "uint128", name: "_startPrice", value: "4000000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "20"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "5007", "4000000000000000000", "50", "10", "1543557600", "1544421600", "20", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543407683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000138f"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 18, c: [40000]}}, {name: "lowestPrice", type: "uint256", value: "2000000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"5008\", \"4000000000000000000\", \"50\... )", async function( ) {
		const txOriginal = {blockNumber: "6788152", timeStamp: "1543407740", hash: "0x3936bcc9333d437cd71382085b96c4eb7f54a8af29a025e4045f983d82ea2711", nonce: "44", blockHash: "0xc91eae29440100e07e442e600ecf17e2caff5958169f6c93472253e9e6b508eb", transactionIndex: "111", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a00000000000000000000000000000000000000000000000000000000000013900000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6160420", gasUsed: "160865", confirmations: "913752"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5008"}, {type: "uint128", name: "_startPrice", value: "4000000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "20"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "5008", "4000000000000000000", "50", "10", "1543557600", "1544421600", "20", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543407740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000001390"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 18, c: [40000]}}, {name: "lowestPrice", type: "uint256", value: "2000000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"5009\", \"4000000000000000000\", \"50\... )", async function( ) {
		const txOriginal = {blockNumber: "6788156", timeStamp: "1543407827", hash: "0x6747ab2d28decd8e93889db130ee86db9efe526d99a670aa7cec0422f573738d", nonce: "45", blockHash: "0x14e7bc195aa684e355d1e736c6bffd7463ee1e537b51eed6661cc615981cf0f0", transactionIndex: "59", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a00000000000000000000000000000000000000000000000000000000000013910000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3476920", gasUsed: "160865", confirmations: "913748"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5009"}, {type: "uint128", name: "_startPrice", value: "4000000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "20"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "5009", "4000000000000000000", "50", "10", "1543557600", "1544421600", "20", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543407827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000001391"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 18, c: [40000]}}, {name: "lowestPrice", type: "uint256", value: "2000000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"5010\", \"4000000000000000000\", \"50\... )", async function( ) {
		const txOriginal = {blockNumber: "6788161", timeStamp: "1543407899", hash: "0x2c85c289631ab67f14b04146f734f389cdb0724670c128271619726432ff93ed", nonce: "46", blockHash: "0xa49d09c38d7f8e92e49a854b1d1b44c372a3047b0a222efa4493d886a10dea78", transactionIndex: "57", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a00000000000000000000000000000000000000000000000000000000000013920000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4476930", gasUsed: "160865", confirmations: "913743"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5010"}, {type: "uint128", name: "_startPrice", value: "4000000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "20"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "5010", "4000000000000000000", "50", "10", "1543557600", "1544421600", "20", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543407899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000001392"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 18, c: [40000]}}, {name: "lowestPrice", type: "uint256", value: "2000000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"4010\", \"200000000000000000\", \"50\"... )", async function( ) {
		const txOriginal = {blockNumber: "6788168", timeStamp: "1543407989", hash: "0x0299f0229f5176a29ed18f0f6858f0959ed8737f4239909ac29be433e2d8c813", nonce: "47", blockHash: "0xba3faafc7831d970fb74c88f640f3d3f1ebfd664116b00ab61ba2625840d361c", transactionIndex: "21", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000faa00000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1176722", gasUsed: "160865", confirmations: "913736"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "4010"}, {type: "uint128", name: "_startPrice", value: "200000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "100"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "4010", "200000000000000000", "50", "10", "1543557600", "1544421600", "100", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543407989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000faa"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 17, c: [2000]}}, {name: "lowestPrice", type: "uint256", value: "100000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"4011\", \"200000000000000000\", \"50\"... )", async function( ) {
		const txOriginal = {blockNumber: "6788174", timeStamp: "1543408073", hash: "0xaf18ba3cbdec45e2fd9cfc196a2d8a65068698a024e3913fd9c78ba7e57e31e2", nonce: "48", blockHash: "0xf543b67776620ce15466e0e16f6d9a4259eab588a71c91fccd6bb772369986f5", transactionIndex: "107", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000fab00000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6220466", gasUsed: "160865", confirmations: "913730"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "4011"}, {type: "uint128", name: "_startPrice", value: "200000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "100"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "4011", "200000000000000000", "50", "10", "1543557600", "1544421600", "100", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543408073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000fab"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 17, c: [2000]}}, {name: "lowestPrice", type: "uint256", value: "100000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"4012\", \"200000000000000000\", \"50\"... )", async function( ) {
		const txOriginal = {blockNumber: "6788178", timeStamp: "1543408132", hash: "0xc74fca0bddaa2f50ba5e2af96ac6fe6a62d8cc88b076d3645ab5d6704e107601", nonce: "49", blockHash: "0x15cc574734abe10688efdd70048ab3b5d4c35c11888f1e943e27a089616d2a0b", transactionIndex: "32", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000fac00000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2468548", gasUsed: "160865", confirmations: "913726"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "4012"}, {type: "uint128", name: "_startPrice", value: "200000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "100"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "4012", "200000000000000000", "50", "10", "1543557600", "1544421600", "100", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543408132 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000fac"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 17, c: [2000]}}, {name: "lowestPrice", type: "uint256", value: "100000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"4013\", \"200000000000000000\", \"50\"... )", async function( ) {
		const txOriginal = {blockNumber: "6788184", timeStamp: "1543408198", hash: "0x4b9f60a224d50e52028d77d9c690c53c10a584b87ee927baeabc3624cc4ff68e", nonce: "50", blockHash: "0x36b0ee69fe6724a85b631926b716642f22ecbe703f5fb49734250291484ad002", transactionIndex: "41", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000fad00000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2440830", gasUsed: "160865", confirmations: "913720"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "4013"}, {type: "uint128", name: "_startPrice", value: "200000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "100"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "4013", "200000000000000000", "50", "10", "1543557600", "1544421600", "100", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543408198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000fad"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 17, c: [2000]}}, {name: "lowestPrice", type: "uint256", value: "100000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"4014\", \"200000000000000000\", \"50\"... )", async function( ) {
		const txOriginal = {blockNumber: "6788192", timeStamp: "1543408311", hash: "0xea255b008991ad48144bcebddec98a77b379fd82e9c9a1f586640ab83d0e9941", nonce: "51", blockHash: "0x89cd299f92714b86d968f9d2b314c2388acfb93b72c6827f6a923ad36de6a639", transactionIndex: "126", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160865", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000fae00000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7074134", gasUsed: "160865", confirmations: "913712"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "4014"}, {type: "uint128", name: "_startPrice", value: "200000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "100"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "4014", "200000000000000000", "50", "10", "1543557600", "1544421600", "100", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543408311 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000fae"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 17, c: [2000]}}, {name: "lowestPrice", type: "uint256", value: "100000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"3002\", \"50000000000000000\", \"50\",... )", async function( ) {
		const txOriginal = {blockNumber: "6788203", timeStamp: "1543408489", hash: "0x916ed2b6c853055b945f8170dd36944b62a021f66d5db9e9ef7993672194cdc9", nonce: "52", blockHash: "0x0b21652a2ca3415b69143a0d152307cb9f3611dd0d57e58f2318354891d439e4", transactionIndex: "75", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160801", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000bba00000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000fa0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3676254", gasUsed: "160801", confirmations: "913701"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "3002"}, {type: "uint128", name: "_startPrice", value: "50000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "250"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "3002", "50000000000000000", "50", "10", "1543557600", "1544421600", "250", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543408489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000bba"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 16, c: [500]}}, {name: "lowestPrice", type: "uint256", value: "25000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"3003\", \"50000000000000000\", \"50\",... )", async function( ) {
		const txOriginal = {blockNumber: "6788218", timeStamp: "1543408801", hash: "0xf8914f046e85b638c43af472f82514c555421640ec9b71e96fb65119500bc682", nonce: "53", blockHash: "0xc877c57f720a1a7a3f443c852f30f01f51c006f55cd9ab9a77cb7c33db6beb35", transactionIndex: "165", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160801", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000bbb00000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000fa0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6148002", gasUsed: "160801", confirmations: "913686"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "3003"}, {type: "uint128", name: "_startPrice", value: "50000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "250"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "3003", "50000000000000000", "50", "10", "1543557600", "1544421600", "250", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543408801 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000bbb"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 16, c: [500]}}, {name: "lowestPrice", type: "uint256", value: "25000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"3007\", \"50000000000000000\", \"50\",... )", async function( ) {
		const txOriginal = {blockNumber: "6788228", timeStamp: "1543408930", hash: "0x5fff78d7a4bed5080814cf2e4f1c15083bdc1036ec62649bc8d86b98f5d80f8f", nonce: "54", blockHash: "0x542580f9a632fc11d50c36b17287afe58e78157c16f30b2a2fc110c88caa2b5c", transactionIndex: "188", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160801", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000bbf00000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000fa0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7730574", gasUsed: "160801", confirmations: "913676"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "3007"}, {type: "uint128", name: "_startPrice", value: "50000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "250"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "3007", "50000000000000000", "50", "10", "1543557600", "1544421600", "250", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543408930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000bbf"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 16, c: [500]}}, {name: "lowestPrice", type: "uint256", value: "25000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"3008\", \"50000000000000000\", \"50\",... )", async function( ) {
		const txOriginal = {blockNumber: "6788236", timeStamp: "1543409102", hash: "0x84dd9aad7398e3f6c9fa0c81cad1ad30913729e7e7ba94588ecaf02cd97b3804", nonce: "55", blockHash: "0xd897e2c0da4fec2e723ee18d7924f01b2b6c33cea0f810e61b7f4c7b8efbbda1", transactionIndex: "136", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160801", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000bc000000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000fa0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7535455", gasUsed: "160801", confirmations: "913668"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "3008"}, {type: "uint128", name: "_startPrice", value: "50000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "250"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "3008", "50000000000000000", "50", "10", "1543557600", "1544421600", "250", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543409102 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000bc0"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 16, c: [500]}}, {name: "lowestPrice", type: "uint256", value: "25000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"3009\", \"50000000000000000\", \"50\",... )", async function( ) {
		const txOriginal = {blockNumber: "6788241", timeStamp: "1543409169", hash: "0xe0cef29c1af408ba3f37dee26acb217868af657389358ba792add209bbf9244d", nonce: "56", blockHash: "0x1c79d3c33c57ef22980023658d947d4ceb6f605761e2bea5c68b40117f8d6561", transactionIndex: "118", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "160801", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a0000000000000000000000000000000000000000000000000000000000000bc100000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000000fa0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4829781", gasUsed: "160801", confirmations: "913663"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "3009"}, {type: "uint128", name: "_startPrice", value: "50000000000000000"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "10"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "250"}, {type: "uint8", name: "_currency", value: "0"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "3009", "50000000000000000", "50", "10", "1543557600", "1544421600", "250", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543409169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000bc1"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 16, c: [500]}}, {name: "lowestPrice", type: "uint256", value: "25000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543989600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addSales( \"2005\", \"0\", \"50\", \"2\", \"154355... )", async function( ) {
		const txOriginal = {blockNumber: "6788247", timeStamp: "1543409267", hash: "0x7f7a0ca738dbd155966852df9f4f22a3d404ce8107ea37b59355fc918912aaf0", nonce: "57", blockHash: "0x46a76a978c74390b73ba65c29f5e2da146e564144464ea64702b0ab6496227e6", transactionIndex: "43", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "145543", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04803c2a00000000000000000000000000000000000000000000000000000000000007d5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000005c00d1e0000000000000000000000000000000000000000000000000000000005c0e00e000000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2395377", gasUsed: "145543", confirmations: "913657"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "2005"}, {type: "uint128", name: "_startPrice", value: "0"}, {type: "uint16", name: "_lowestPriceRate", value: "50"}, {type: "uint16", name: "_decreaseRate", value: "2"}, {type: "uint64", name: "_since", value: "1543557600"}, {type: "uint64", name: "_until", value: "1544421600"}, {type: "uint16", name: "_supplyLimit", value: "1000"}, {type: "uint8", name: "_currency", value: "2"}], name: "addSales", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addSales(uint16,uint128,uint16,uint16,uint64,uint64,uint16,uint8)" ]( "2005", "0", "50", "2", "1543557600", "1544421600", "1000", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543409267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "startPrice", type: "uint128"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}], name: "AddSalesEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddSalesEvent", events: [{name: "heroType", type: "uint16", value: "0x00000000000000000000000000000000000000000000000000000000000007d5"}, {name: "startPrice", type: "uint128", value: {s: 1, e: 0, c: [0]}}, {name: "lowestPrice", type: "uint256", value: "0"}, {name: "becomeLowestAt", type: "uint256", value: "1545717600"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6788282", timeStamp: "1543409819", hash: "0x0a2bb2eb7b3a65d9e759f20945e951ef74ad6a001ecc82e6017cf2f539543f22", nonce: "58", blockHash: "0x03bb2bfd221de431f9963ee3352eaeb5cba44d67b950c40e4a58340f9c7d7c46", transactionIndex: "80", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000a1780310fad8f98b0eaf8d484c8af499a67e2959", contractAddress: "", cumulativeGasUsed: "3511615", gasUsed: "45311", confirmations: "913622"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[5]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543409819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[18,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xa1780310fad8f98b0eaf8d484c8af499a67e2959"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[18,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6788284", timeStamp: "1543409855", hash: "0x0f0ad09adccf747389c71afa3e84e481f52b5fc46684f3cffcc8b625b20f3934", nonce: "59", blockHash: "0x86789386e1f383222544620f05db52801a7f2aaf10f04d0015181173789b0646", transactionIndex: "128", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000007e1dcf785f0353bf657c38ab7865c1f184efe208", contractAddress: "", cumulativeGasUsed: "7962869", gasUsed: "45311", confirmations: "913620"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[6]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543409855 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[19,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x7e1dcf785f0353bf657c38ab7865c1f184efe208"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[19,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6788288", timeStamp: "1543409926", hash: "0x773279290b2eef1eaa5479ebfbad568323ffd8b4513847a6e521cd07e0750b23", nonce: "60", blockHash: "0x259ee83e8811e63db1b28a1c065abd7dbead5c7273a89249e71b5a7491029102", transactionIndex: "123", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000c5bcfc66e795878539b32ebef0dc9f9e53d29e2b", contractAddress: "", cumulativeGasUsed: "6601075", gasUsed: "45311", confirmations: "913616"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[7]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543409926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[20,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xc5bcfc66e795878539b32ebef0dc9f9e53d29e2b"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[20,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6788293", timeStamp: "1543409961", hash: "0x99bfbf756673de3fd8e78178e589ffc51828c5e033aab735884f018865848cc5", nonce: "61", blockHash: "0x4c99cf5a627aa85ff63bf90f05d8fbb5f9d53359e6e5bb97ee51c710f523ff9a", transactionIndex: "65", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45247", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000b1f72e1a73667ac9b600685539040a48bf5f2d3b", contractAddress: "", cumulativeGasUsed: "4541295", gasUsed: "45247", confirmations: "913611"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[8]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543409961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[21,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xb1f72e1a73667ac9b600685539040a48bf5f2d3b"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[21,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6788297", timeStamp: "1543410000", hash: "0x87a6b846297b3772670e8561f1c603059136899639c69e7e4576adae7f962fd9", nonce: "62", blockHash: "0xf26ce572c37e501c436a46a90c645bb0a4e63884da65de4b04ce13396f727d2e", transactionIndex: "183", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000000537544de3935408246ee2ad09949d046f92574d", contractAddress: "", cumulativeGasUsed: "6053738", gasUsed: "45311", confirmations: "913607"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[9]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543410000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[22,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x0537544de3935408246ee2ad09949d046f92574d"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[22,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6788302", timeStamp: "1543410049", hash: "0x25de3d729a29998e6a89aed09309b499d48f2b1258b5d3150b6c6dc039e6b6c4", nonce: "63", blockHash: "0x9a05997a2056107c2c8360189fa2b84d734f040c35137423e7d95624000fb6c3", transactionIndex: "45", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000078da415709285050cd9d683e08f395143256ba8", contractAddress: "", cumulativeGasUsed: "2797956", gasUsed: "45311", confirmations: "913602"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[10]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543410049 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[23,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x078da415709285050cd9d683e08f395143256ba8"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[23,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6788308", timeStamp: "1543410083", hash: "0xb5889a3a185a756f1930b8125a3bd8628bdfabd459f9497de9a8852bfa31c852", nonce: "64", blockHash: "0x37f0aaffe2a8fdad002d5c5682260f650dc03724481fa3fde50684eb016ec3ff", transactionIndex: "69", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000d5e4868b51439ac87279b0d0117b7e2f36475058", contractAddress: "", cumulativeGasUsed: "2052598", gasUsed: "45311", confirmations: "913596"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[11]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543410083 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[24,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xd5e4868b51439ac87279b0d0117b7e2f36475058"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[24,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6788313", timeStamp: "1543410123", hash: "0xb4638a4862a4ff2523c571a235d291bc23f50e9288156239427336dde50216e3", nonce: "65", blockHash: "0xa64a8d09c466bdeb5dfbf10e2b85de5ab30315e01f483e87acb7da438f0cb6e4", transactionIndex: "150", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000008c5fc43ad00cc53e11f61bece329ddc5e3ea0929", contractAddress: "", cumulativeGasUsed: "7705451", gasUsed: "45311", confirmations: "913591"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[12]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543410123 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[25,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x8c5fc43ad00cc53e11f61bece329ddc5e3ea0929"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[25,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6788316", timeStamp: "1543410178", hash: "0xbafc360f236fc5f56020e4b1eaf565dd2b4900732995fcc9324dab49186d35b2", nonce: "66", blockHash: "0x71c74cc558bc0ace2683fb1560624af6b3df1849a45b44502a2f235656be2b7b", transactionIndex: "95", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000d3a22d084dd16196b7862bc2d309412b508318fb", contractAddress: "", cumulativeGasUsed: "4769275", gasUsed: "45311", confirmations: "913588"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[13]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543410178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[26,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xd3a22d084dd16196b7862bc2d309412b508318fb"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[26,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6788318", timeStamp: "1543410231", hash: "0xde5bb754eba38494de32693e8b2e8fca41169a27ef66dfc852587ca28b8b269d", nonce: "67", blockHash: "0x7f226e7217d7c24195e2768b124de2acc44ab80ce13b151bd68c2d2bdbf7aed1", transactionIndex: "147", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000001693ae817e424c2dbc4138313b7b46c91bb968f4", contractAddress: "", cumulativeGasUsed: "6423849", gasUsed: "45311", confirmations: "913586"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[14]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543410231 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[27,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x1693ae817e424c2dbc4138313b7b46c91bb968f4"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[27,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6788323", timeStamp: "1543410270", hash: "0x43311a7d434bf21459c69e2748ba573238d5b1d34edad851af782d34a5aca06b", nonce: "68", blockHash: "0xcb0da482d4096193ba5658b28459fb947a8a64ec45e4cb2c44aa151ffbf07d3d", transactionIndex: "59", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000005c5aaf9e86bd9a2732fb351add176c7c6a21cbdf", contractAddress: "", cumulativeGasUsed: "3058276", gasUsed: "45311", confirmations: "913581"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[15]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543410270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[28,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x5c5aaf9e86bd9a2732fb351add176c7c6a21cbdf"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[28,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[16] )", async function( ) {
		const txOriginal = {blockNumber: "6788327", timeStamp: "1543410366", hash: "0xdc699c05e0a4ac8beaa9d8cea7f0649161f836735f9bbd99ab51856d3b9002f4", nonce: "69", blockHash: "0x8e258c95222a5b991d260dad89bdcd9726ddc55469d4f4f98522414a2e089c61", transactionIndex: "56", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000007ae0048bb33650edb349f6fc65fd23a39430e752", contractAddress: "", cumulativeGasUsed: "4087556", gasUsed: "45311", confirmations: "913577"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[16]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[16], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543410366 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[29,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x7ae0048bb33650edb349f6fc65fd23a39430e752"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[29,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "6788330", timeStamp: "1543410406", hash: "0x6ee6a8e7ccc9e18c03cee3b4745b0616762bbaafe51e17296f1f454273381f9e", nonce: "70", blockHash: "0xba6dc0734b0bc79289b384fe5f5a5556bb094ccde44d08e22e9bb586ea01ba64", transactionIndex: "48", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb100000000000000000000000062b8b7b7af7cb5847dd7335e0b6b4229cd1b7d48", contractAddress: "", cumulativeGasUsed: "3737583", gasUsed: "45311", confirmations: "913574"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[17]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543410406 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[30,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x62b8b7b7af7cb5847dd7335e0b6b4229cd1b7d48"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[30,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[18] )", async function( ) {
		const txOriginal = {blockNumber: "6788335", timeStamp: "1543410458", hash: "0xca9b90408b160ba1465a6cc480c64a9d80ec7bb6aa27979396dee5f4e7c643fb", nonce: "71", blockHash: "0xe3af297e48bea2bf3ad53d3d50cb2ac96a48e610869239efb7ae4553036b01f8", transactionIndex: "93", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000b130168ec63ca7e30a8f8c7268aa56e4d6730fb5", contractAddress: "", cumulativeGasUsed: "4209496", gasUsed: "45311", confirmations: "913569"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[18]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[18], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543410458 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[31,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xb130168ec63ca7e30a8f8c7268aa56e4d6730fb5"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[31,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[19] )", async function( ) {
		const txOriginal = {blockNumber: "6788338", timeStamp: "1543410501", hash: "0x2b5e2489039808f9a52a9ff8752c1b36f714b98e2d4d9933f21ecfe1e9e4c44d", nonce: "72", blockHash: "0x96f2c916b09ffcde1248162e657397e8375a654900d6ceeff4b773f459fd42e7", transactionIndex: "96", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000981e6097e2bdffefe1b0d09777c3422bb6bb24c8", contractAddress: "", cumulativeGasUsed: "3975602", gasUsed: "45311", confirmations: "913566"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[19]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[19], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543410501 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[32,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x981e6097e2bdffefe1b0d09777c3422bb6bb24c8"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[32,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[20] )", async function( ) {
		const txOriginal = {blockNumber: "6788342", timeStamp: "1543410591", hash: "0x475814ceb9eb3ed65f6ad06d2cc8c42a6eb110447e17f98f8b4bb57f2863cecd", nonce: "73", blockHash: "0x3b4e5f7d332b719072a5e215d008c5c529fd24853569323ef4c4832ae3e40bfa", transactionIndex: "137", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb100000000000000000000000096080155dd976e98305fa9aea96834a03abda864", contractAddress: "", cumulativeGasUsed: "7919274", gasUsed: "45311", confirmations: "913562"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[20]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[20], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543410591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[33,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x96080155dd976e98305fa9aea96834a03abda864"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[33,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6798436", timeStamp: "1543554236", hash: "0x83a3f5c83b37e8faf6fba3fd882bf50d6fa6e17da8f3e9f66f13341c0a64809e", nonce: "96", blockHash: "0x5adf29413f20bbf5f55eac52809a52815016a4bc98ef83574ae059ac375fea15", transactionIndex: "73", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb100000000000000000000000081d661b2b5865ecb0e331463483055215e624997", contractAddress: "", cumulativeGasUsed: "6593007", gasUsed: "45311", confirmations: "903468"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[21]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543554236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[34,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x81d661b2b5865ecb0e331463483055215e624997"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[34,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6798439", timeStamp: "1543554266", hash: "0x477fc8a1f0d12b4d23a41c187cd82b0406dc36be1c02b985a86f9dbe295b30a1", nonce: "97", blockHash: "0x02be821dac7f62de9f913d6beae041f03e64f63e20609a08b8a9937a7c958b12", transactionIndex: "68", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000d868711bd9a2c6f1548f5f4737f71da67d821090", contractAddress: "", cumulativeGasUsed: "5167912", gasUsed: "45311", confirmations: "903465"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[22]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543554266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[35,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xd868711bd9a2c6f1548f5f4737f71da67d821090"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[35,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[23] )", async function( ) {
		const txOriginal = {blockNumber: "6798441", timeStamp: "1543554352", hash: "0x4bd12b39b789eb9830cd9bdd4206c79f590c0d24ff2c0a7d9e091d254e7fe60a", nonce: "98", blockHash: "0xeaf37a05fbc8acc08217c20b398bc034116765a7c9d5be01b4e4f522e094de0d", transactionIndex: "109", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000003c11e8922bc793d2fbd7e3e454241c587ae42010", contractAddress: "", cumulativeGasUsed: "6302234", gasUsed: "45311", confirmations: "903463"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[23]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[23], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543554352 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[36,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x3c11e8922bc793d2fbd7e3e454241c587ae42010"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[36,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[24] )", async function( ) {
		const txOriginal = {blockNumber: "6798446", timeStamp: "1543554442", hash: "0x49815d7a1af4e89052e02c93a35a3dab4d33acb02d453f407a27cc7fe399dca6", nonce: "99", blockHash: "0xb2f0db845db127c09ab188f2d9c6ff72fcf2eec1b08e4b2f94dea18acdde4de4", transactionIndex: "25", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000583780eebab14b8f7082c6b2e7ddcfa60b1a7c29", contractAddress: "", cumulativeGasUsed: "1094944", gasUsed: "45311", confirmations: "903458"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[24]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[24], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543554442 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[37,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x583780eebab14b8f7082c6b2e7ddcfa60b1a7c29"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[37,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[25] )", async function( ) {
		const txOriginal = {blockNumber: "6798453", timeStamp: "1543554498", hash: "0xb0a8c2f1a10e66ace18e61d3122c7d1583fdf7213fabd5387549008db52772db", nonce: "100", blockHash: "0x9f656fe08af400f407fa57a01cde6e762932971aa5d364adfc4cbaa8b25c2cd4", transactionIndex: "24", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb100000000000000000000000005ecc0958eee0acbe1bb2e9aae847466c20eac47", contractAddress: "", cumulativeGasUsed: "783766", gasUsed: "45311", confirmations: "903451"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[25]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[25], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543554498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[38,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x05ecc0958eee0acbe1bb2e9aae847466c20eac47"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[38,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[26] )", async function( ) {
		const txOriginal = {blockNumber: "6798456", timeStamp: "1543554577", hash: "0x6ade325463d7f51f166e427d2683a3226f50902574b67c7d00e3b602a1a606ea", nonce: "101", blockHash: "0xc27edb6759b2523a015c466162a2562db75e385d4d143b24e10417e738188c35", transactionIndex: "56", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000006efd9bf1c87a2946acea38043dc9a4c03ade8b7f", contractAddress: "", cumulativeGasUsed: "6465242", gasUsed: "45311", confirmations: "903448"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[26]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[26], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543554577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[39,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x6efd9bf1c87a2946acea38043dc9a4c03ade8b7f"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[39,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[27] )", async function( ) {
		const txOriginal = {blockNumber: "6798465", timeStamp: "1543554654", hash: "0xce2c210cb748a5de27ab4d7de17f267528bd6e2d344de7d3c480339b920e53e7", nonce: "102", blockHash: "0x07d1a52101983eef508516bcb4e95a91006701dddc1adada60bde567fad9afa8", transactionIndex: "89", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000008bcc48f937a6e076ec25838436fa6118f0c153d2", contractAddress: "", cumulativeGasUsed: "3505173", gasUsed: "45311", confirmations: "903439"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[27]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[27], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543554654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[40,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x8bcc48f937a6e076ec25838436fa6118f0c153d2"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[40,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[28] )", async function( ) {
		const txOriginal = {blockNumber: "6798470", timeStamp: "1543554729", hash: "0x4a5798dcca3947aa5fe210062603f7149c803b186e8a60aa78069cde50015417", nonce: "103", blockHash: "0xe02776e314aac7ffe6b0d0503eac3b111f373ffc300f2900b0f6226f35addb1a", transactionIndex: "77", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb1000000000000000000000000ae015ccde814da988dbca7f09c10f7c25d6931c3", contractAddress: "", cumulativeGasUsed: "2844295", gasUsed: "45311", confirmations: "903434"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[28]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[28], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543554729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0xae015ccde814da988dbca7f09c10f7c25d6931c3"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: addReferrer( addressList[29] )", async function( ) {
		const txOriginal = {blockNumber: "6798508", timeStamp: "1543555198", hash: "0x61932381e98d0a3d89ca0c4f7175578bd931b6f8efd6849a28e9ff8c326e51b6", nonce: "104", blockHash: "0x031877b09be300be24ced4bc5f4754692baf52aa5c64f2e636995369b1dd35ea", transactionIndex: "75", from: "0xe7af11370c3bab51230d8307454350bdf6d68f4a", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "45311", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfefa9bb10000000000000000000000007da610dc64179389591d04c602cc58f5c82725f4", contractAddress: "", cumulativeGasUsed: "4120568", gasUsed: "45311", confirmations: "903396"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[29]}], name: "addReferrer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferrer(address)" ]( addressList[29], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543555198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ReferrerAdded", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferrerAdded", events: [{name: "account", type: "address", value: "0x7da610dc64179389591d04c602cc58f5c82725f4"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "86061242372302905863" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5007\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6798672", timeStamp: "1543557641", hash: "0x6c79527407cfce9a80f3887c404c620ac93e7d61d72ec117f78536e295237e19", nonce: "348", blockHash: "0xa0b24f488d556a11055c254bdbaad5c648f0d45fd3b4e4d09bf217b5424ed3c9", transactionIndex: "34", from: "0x759de6b9806a5f695b8fe92f58a6771fb5db52c6", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "3999995370370370371", gas: "273440", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x396c8228000000000000000000000000000000000000000000000000000000000000138f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2491851", gasUsed: "235483", confirmations: "903232"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "3999995370370370371" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5007"}, {type: "address", name: "_referrer", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint16,address)" ]( "5007", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543557641 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "soldPrice", type: "uint256"}, {indexed: false, name: "soldAt", type: "uint64"}, {indexed: false, name: "priceIncreaseTo", type: "uint256"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}, {indexed: false, name: "purchasedBy", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "currency", type: "uint8"}], name: "SoldHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SoldHeroEvent", events: [{name: "heroType", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000138f"}, {name: "soldPrice", type: "uint256", value: "3999810185185185186"}, {name: "soldAt", type: "uint64", value: {s: 1, e: 9, c: [1543557641]}}, {name: "priceIncreaseTo", type: "uint256", value: "4210326510721247564"}, {name: "lowestPrice", type: "uint256", value: "2000000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1544011221"}, {name: "purchasedBy", type: "address", value: "0x759de6b9806a5f695b8fe92f58a6771fb5db52c6"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "currency", type: "uint8", value: "0"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "4720645303913327434" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4012\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6798673", timeStamp: "1543557654", hash: "0xc90208016ae8c83fbbef03a1be398a80c9859b040e39f011f7609be4080bf3b8", nonce: "436", blockHash: "0xbcf6e765475de31c6d57f195c40068a42e4b7e774c8362594cdda5532f128076", transactionIndex: "10", from: "0xd718b31115927c7a60165423b357ba59b7e38643", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "199999768518518519", gas: "282579", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x396c82280000000000000000000000000000000000000000000000000000000000000fac0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "555402", gasUsed: "235483", confirmations: "903231"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "199999768518518519" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "4012"}, {type: "address", name: "_referrer", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint16,address)" ]( "4012", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543557654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "soldPrice", type: "uint256"}, {indexed: false, name: "soldAt", type: "uint64"}, {indexed: false, name: "priceIncreaseTo", type: "uint256"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}, {indexed: false, name: "purchasedBy", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "currency", type: "uint8"}], name: "SoldHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SoldHeroEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000fac"}, {name: "soldPrice", type: "uint256", value: "199987500000000000"}, {name: "soldAt", type: "uint64", value: {s: 1, e: 9, c: [1543557654]}}, {name: "priceIncreaseTo", type: "uint256", value: "202007575757575757"}, {name: "lowestPrice", type: "uint256", value: "100000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543993947"}, {name: "purchasedBy", type: "address", value: "0xd718b31115927c7a60165423b357ba59b7e38643"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "currency", type: "uint8", value: "0"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "129336222025895695" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5007\", addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6798673", timeStamp: "1543557654", hash: "0x573d5693afb2f070cbeabfe0c298cd43d9ffc255f293a60cc0b01f510b3588b0", nonce: "23", blockHash: "0xbcf6e765475de31c6d57f195c40068a42e4b7e774c8362594cdda5532f128076", transactionIndex: "11", from: "0xfcfeb1c563ce8a545f25f14a44df37360744f045", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "5000000000000000000", gas: "270261", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x396c8228000000000000000000000000000000000000000000000000000000000000138f00000000000000000000000081d661b2b5865ecb0e331463483055215e624997", contractAddress: "", cumulativeGasUsed: "816228", gasUsed: "260826", confirmations: "903231"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5007"}, {type: "address", name: "_referrer", value: addressList[21]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint16,address)" ]( "5007", addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543557654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "soldPrice", type: "uint256"}, {indexed: false, name: "soldAt", type: "uint64"}, {indexed: false, name: "priceIncreaseTo", type: "uint256"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}, {indexed: false, name: "purchasedBy", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "currency", type: "uint8"}], name: "SoldHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SoldHeroEvent", events: [{name: "heroType", type: "uint16", value: "0x000000000000000000000000000000000000000000000000000000000000138f"}, {name: "soldPrice", type: "uint256", value: "4210263160901063101"}, {name: "soldAt", type: "uint64", value: {s: 1, e: 9, c: [1543557654]}}, {name: "priceIncreaseTo", type: "uint256", value: "4444166669840011051"}, {name: "lowestPrice", type: "uint256", value: "2105131580450531550"}, {name: "becomeLowestAt", type: "uint256", value: "1544012390"}, {name: "purchasedBy", type: "address", value: "0xfcfeb1c563ce8a545f25f14a44df37360744f045"}, {name: "referrer", type: "address", value: "0x81d661b2b5865ecb0e331463483055215e624997"}, {name: "currency", type: "uint8", value: "0"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "243228872564883423" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5007\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6798673", timeStamp: "1543557654", hash: "0x9e29a265889aaa832da9dadf1103c45e4a18f19b7b771cbeba03541f7e89b9b8", nonce: "67", blockHash: "0xbcf6e765475de31c6d57f195c40068a42e4b7e774c8362594cdda5532f128076", transactionIndex: "12", from: "0xb007f748f2223e205483d80a3b634bfd5268a504", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "3999995370370370371", gas: "273440", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x396c8228000000000000000000000000000000000000000000000000000000000000138f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "849686", gasUsed: "33458", confirmations: "903231"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "3999995370370370371" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5007"}, {type: "address", name: "_referrer", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint16,address)" ]( "5007", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543557654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "17182984727956838610" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"5007\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6798673", timeStamp: "1543557654", hash: "0x601cfb508d1ad01a9ce16398d085ab1877c3f6070390ffca757062067c369eaa", nonce: "0", blockHash: "0xbcf6e765475de31c6d57f195c40068a42e4b7e774c8362594cdda5532f128076", transactionIndex: "26", from: "0xa52fb91a60bf7987dd527122ce68ba0e64737b03", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "3999995370370370371", gas: "291440", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0x396c8228000000000000000000000000000000000000000000000000000000000000138f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1547994", gasUsed: "33458", confirmations: "903231"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "3999995370370370371" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "5007"}, {type: "address", name: "_referrer", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint16,address)" ]( "5007", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543557654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "16585193198867609" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: airDrop( \"2005\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6798673", timeStamp: "1543557654", hash: "0x7190436e53a8a93875bbe99bdfe3fd1fc608779f0a6075b618b4b18edc6eaef1", nonce: "0", blockHash: "0xbcf6e765475de31c6d57f195c40068a42e4b7e774c8362594cdda5532f128076", transactionIndex: "28", from: "0x6825e9dc7d9a43480948d451dbcb78ad25e55937", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "0", gas: "287348", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x8e2ed55700000000000000000000000000000000000000000000000000000000000007d50000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1833473", gasUsed: "239457", confirmations: "903231"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "2005"}, {type: "address", name: "_referrer", value: addressList[0]}], name: "airDrop", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airDrop(uint16,address)" ]( "2005", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543557654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "soldPrice", type: "uint256"}, {indexed: false, name: "soldAt", type: "uint64"}, {indexed: false, name: "priceIncreaseTo", type: "uint256"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}, {indexed: false, name: "purchasedBy", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "currency", type: "uint8"}], name: "SoldHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SoldHeroEvent", events: [{name: "heroType", type: "uint16", value: "0x00000000000000000000000000000000000000000000000000000000000007d5"}, {name: "soldPrice", type: "uint256", value: "1"}, {name: "soldAt", type: "uint64", value: {s: 1, e: 9, c: [1543557654]}}, {name: "priceIncreaseTo", type: "uint256", value: "1"}, {name: "lowestPrice", type: "uint256", value: "1"}, {name: "becomeLowestAt", type: "uint256", value: "1"}, {name: "purchasedBy", type: "address", value: "0x6825e9dc7d9a43480948d451dbcb78ad25e55937"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "currency", type: "uint8", value: "2"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "22482902681000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: purchase( \"4014\", addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6798673", timeStamp: "1543557654", hash: "0x1ef49cc234aa5fe91fb8441bf753d2376b1a5073541e5b746e4bd6985c2bb3bd", nonce: "430", blockHash: "0xbcf6e765475de31c6d57f195c40068a42e4b7e774c8362594cdda5532f128076", transactionIndex: "29", from: "0x12bcefaff8878f84fdd4ce2f33c3b49ee43de948", to: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01", value: "199999768518518519", gas: "353224", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x396c82280000000000000000000000000000000000000000000000000000000000000fae0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2068956", gasUsed: "235483", confirmations: "903231"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "199999768518518519" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "_heroType", value: "4014"}, {type: "address", name: "_referrer", value: addressList[0]}], name: "purchase", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "purchase(uint16,address)" ]( "4014", addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543557654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "heroType", type: "uint16"}, {indexed: false, name: "soldPrice", type: "uint256"}, {indexed: false, name: "soldAt", type: "uint64"}, {indexed: false, name: "priceIncreaseTo", type: "uint256"}, {indexed: false, name: "lowestPrice", type: "uint256"}, {indexed: false, name: "becomeLowestAt", type: "uint256"}, {indexed: false, name: "purchasedBy", type: "address"}, {indexed: true, name: "referrer", type: "address"}, {indexed: false, name: "currency", type: "uint8"}], name: "SoldHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SoldHeroEvent", events: [{name: "heroType", type: "uint16", value: "0x0000000000000000000000000000000000000000000000000000000000000fae"}, {name: "soldPrice", type: "uint256", value: "199987500000000000"}, {name: "soldAt", type: "uint64", value: {s: 1, e: 9, c: [1543557654]}}, {name: "priceIncreaseTo", type: "uint256", value: "202007575757575757"}, {name: "lowestPrice", type: "uint256", value: "100000000000000000"}, {name: "becomeLowestAt", type: "uint256", value: "1543993947"}, {name: "purchasedBy", type: "address", value: "0x12bcefaff8878f84fdd4ce2f33c3b49ee43de948"}, {name: "referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "currency", type: "uint8", value: "0"}], address: "0xa1d2c7e6de2fa512f1fdf486ca17ab79b4dc5d01"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "205109591464493899" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
