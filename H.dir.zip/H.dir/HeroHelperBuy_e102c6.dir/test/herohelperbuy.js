const HeroHelperBuy = artifacts.require( "./HeroHelperBuy.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "HeroHelperBuy" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x93F2C843f6827E48381654aa2B093e5F97E102c6", "0x095CBB73C75d4E1c62C94e0B1d4d88f8194B1941", "0x89a196a34B7820bC985B98096ED5EFc7c4DC8363", "0x85FF87f383C42E150dD2058195dE698512A591dF", "0xD38A82102951b82ab7884e64552538FbFe701bad", "0xC74A064191b5Bb340dF81646622752F283A843b2", "0x56f6bf6B793713C050Fd02147a45b563Bb4D8eFa", "0x30602250c5f1fcbA5407E99B1DFaAB992EA4fFD2", "0x5de7438E69EBC64657f4F8c5C902916150d5EEea", "0x3E9F8f31725367937691E3c15eCa355662ae3aD9", "0x7E294F0c90dc1Ab36979c27E8279cA74eaE22ecB", "0x0f59FFF9764D77434ba3204AC0Dc2F63bd6f894c", "0xd597CcA5D7CEb84A0515d48317276741293Be450", "0xa4c62b6E63C1277dDAe9eFDf5e2382e58251E9AE", "0x9Ad656B80953175C07470DceE801e551b28573C4", "0x5BA3E11aBf8c93186637847eC590fCd3aa588BD2", "0x2fAeb67d709C0C162a18C8FB2ea8Bdf9CecFB71f", "0xEE61C9F12Ee5D8E5B1275dFCAbC9310a8A701F6E", "0x9e315E9701908501f6dC68A2af6e28a20C75d970", "0x85cbe353d506a72C3Be27540C1FcEe7078fd9964", "0x20CA0D6FE51d06946f5cC90F9F4f297D398dD6DB"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_owner", type: "address"}], name: "GetHeroCount", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "percent2", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "target", type: "address"}], name: "GetInventoryHeroCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "percent1", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "partner2", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "partner1", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "m_Paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "stockhero_id", type: "uint16"}], name: "GetHeroStockPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "bitGuildAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "m_Owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "trustedContracts", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BuyStockHeroEvent(address,uint32,uint32)", "showValues(uint256,uint256,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xf5cbe560007c0144c83ca340203473af6033125969fa6eb64126cf187f88af44", "0xe804069ba6933f4f73db0b82811cd233a61f5ca5c778fa6c50c571d7c5a2c503"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6588210 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6609382 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "HeroHelperBuy", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "GetHeroCount", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GetHeroCount(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "percent2", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "percent2()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "target", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "GetInventoryHeroCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GetInventoryHeroCount(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "percent1", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "percent1()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "partner2", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "partner2()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "partner1", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "partner1()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "m_Paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "m_Paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "stockhero_id", value: random.range( maxRandom )}], name: "GetHeroStockPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GetHeroStockPrice(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "bitGuildAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bitGuildAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "m_Owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "m_Owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "trustedContracts", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "trustedContracts(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "HeroHelperBuy", function( accounts ) {

	it( "TEST: HeroHelperBuy(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6588210", blockHash: "0xc2c94a813643c0787561f49b5f14367fb98a0a2f0519a02c0a46894d80277c14", timeStamp: "1540574165", hash: "0xd0ce54c38fe6db093ea7e31f6287dd94c8bc85d8e85afba7dd200e36918ae23c", nonce: "9", transactionIndex: "31", from: "0x85ff87f383c42e150dd2058195de698512a591df", to: 0, value: "0", gas: "2142931", gasPrice: "7000000000", input: "0xfc9e5ada", contractAddress: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", cumulativeGasUsed: "6684401", txreceipt_status: "1", gasUsed: "2142931", confirmations: "1147524", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "HeroHelperBuy", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = HeroHelperBuy.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540574165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = HeroHelperBuy.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "14644011888672137985" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6588477", blockHash: "0x531aa96f811b3e0f4553d0f8ba47a7595b676ce9c8899938d1d1c083b9963747", timeStamp: "1540578126", hash: "0xd54d79bc8a664e22251bcb36b6953d45f3eee3721b0dc37d698865f5e9b739be", nonce: "1286", transactionIndex: "108", from: "0xd38a82102951b82ab7884e64552538fbfe701bad", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "415038", gasPrice: "8000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "7716690", txreceipt_status: "1", gasUsed: "275632", confirmations: "1147257", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540578126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xd38a82102951b82ab7884e64552538fbfe701bad"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "50"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "65114566754351737177" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6588498", blockHash: "0x9afb1882c5ae663cf2db8ab2c53606d207e2b4ce60565c3db0be404cd7ce2d34", timeStamp: "1540578387", hash: "0xf3869af09b71b190796020b733f8ac921be28601020c3fc1d2dbd3d7927b77b8", nonce: "1287", transactionIndex: "24", from: "0xd38a82102951b82ab7884e64552538fbfe701bad", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "326358", gasPrice: "8000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "3567350", txreceipt_status: "1", gasUsed: "217165", confirmations: "1147236", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540578387 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xd38a82102951b82ab7884e64552538fbfe701bad"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "50"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "65114566754351737177" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6588501", blockHash: "0x8dad893d16cd08f3f7fb64e563e1f6899a31501aad4c42f014c7f56f1e52c103", timeStamp: "1540578406", hash: "0x5b649f3233acbceebc36cb35f20ddb201547fb33c0a62315f420c2c5362cb3b4", nonce: "1288", transactionIndex: "94", from: "0xd38a82102951b82ab7884e64552538fbfe701bad", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323983", gasPrice: "8000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5765143", txreceipt_status: "1", gasUsed: "216325", confirmations: "1147233", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "1"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540578406 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xd38a82102951b82ab7884e64552538fbfe701bad"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "50"}, {name: "hero_id", type: "uint256", value: "1"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "65114566754351737177" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6588503", blockHash: "0x878e3ee56db7ab5b489e7fa2add8a25d7abc57ad7daf84e8639c447d64207d5e", timeStamp: "1540578420", hash: "0x96c6ba9bc5fbde9cf015092f8fe1598856fa0112c0ef25e0d2500cb3b3cefe39", nonce: "1289", transactionIndex: "16", from: "0xd38a82102951b82ab7884e64552538fbfe701bad", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323983", gasPrice: "8000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2708709", txreceipt_status: "1", gasUsed: "215612", confirmations: "1147231", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "2"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540578420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xd38a82102951b82ab7884e64552538fbfe701bad"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "50"}, {name: "hero_id", type: "uint256", value: "2"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "65114566754351737177" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6588505", blockHash: "0xcc54bd2e9b364662047fa8dd7e4f3db25009eb139bbe5f5ccad6caab9400d782", timeStamp: "1540578445", hash: "0x695e0e1f8e8d2385dd5a059fc35f08be5f63e7d6a29473bcd075359082f6a343", nonce: "1290", transactionIndex: "66", from: "0xd38a82102951b82ab7884e64552538fbfe701bad", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "325053", gasPrice: "8000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3861846", txreceipt_status: "1", gasUsed: "217155", confirmations: "1147229", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540578445 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xd38a82102951b82ab7884e64552538fbfe701bad"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "50"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "65114566754351737177" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6588559", blockHash: "0xa9cf20faa63ef159a8b16066b0aa2495b2cfe31a1572d94580676d57b93c8082", timeStamp: "1540579092", hash: "0x5d19d574ae70646aa3655efb462a22d37e940cd35f58c46273c657a8676371da", nonce: "60", transactionIndex: "36", from: "0xc74a064191b5bb340df81646622752f283a843b2", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "10000000000000000", gas: "342972", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "4299319", txreceipt_status: "1", gasUsed: "230654", confirmations: "1147175", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "6"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540579092 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xc74a064191b5bb340df81646622752f283a843b2"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 0, c: [6]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "10000000000000000"}, {name: "_price", type: "uint256", value: "10000000000000000"}, {name: "_stock", type: "uint256", value: "200"}, {name: "hero_id", type: "uint256", value: "6"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "6588701", blockHash: "0x989253d1098cc7c05c7f941160bd44453f89d9c832d2bb1f692a515ff6b4ee62", timeStamp: "1540581405", hash: "0xc82ef416875ee9a405c5348e22eb1ff279a6b69f39c9caeb75513422a325ffab", nonce: "470", transactionIndex: "109", from: "0x56f6bf6b793713c050fd02147a45b563bb4d8efa", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "10000000000000000", gas: "347473", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "6771598", txreceipt_status: "1", gasUsed: "229824", confirmations: "1147033", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "18"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540581405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x56f6bf6b793713c050fd02147a45b563bb4d8efa"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 1, c: [18]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [10]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "10000000000000000"}, {name: "_price", type: "uint256", value: "10000000000000000"}, {name: "_stock", type: "uint256", value: "200"}, {name: "hero_id", type: "uint256", value: "18"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "517552910359722765" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6588904", blockHash: "0x7a30f051fa23159ec25dad4ac6f21eef0a24256442d646c6878b02135a39203f", timeStamp: "1540584285", hash: "0xf81da21d50adbf9e84b0d66beaa51e22c1bef73f761e2a8e08387191ff0abf5e", nonce: "3262", transactionIndex: "283", from: "0x30602250c5f1fcba5407e99b1dfaab992ea4ffd2", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "10000000000000000", gas: "342972", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "7551413", txreceipt_status: "1", gasUsed: "228291", confirmations: "1146830", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "6"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540584285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x30602250c5f1fcba5407e99b1dfaab992ea4ffd2"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [11]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "10000000000000000"}, {name: "_price", type: "uint256", value: "10000000000000000"}, {name: "_stock", type: "uint256", value: "199"}, {name: "hero_id", type: "uint256", value: "6"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "11133000983339260" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6588906", blockHash: "0xfb893e8a0073753cb2b79817ecd4b76f44deee66299d0ad909aca56cc84835c1", timeStamp: "1540584325", hash: "0xd3d3db4d7e9e362649c8500a92a76e80d3693285337e3e088cae9e2dad39dc76", nonce: "3263", transactionIndex: "211", from: "0x30602250c5f1fcba5407e99b1dfaab992ea4ffd2", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "346498", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "6211684", txreceipt_status: "1", gasUsed: "215622", confirmations: "1146828", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540584325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x30602250c5f1fcba5407e99b1dfaab992ea4ffd2"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [12]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "49"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "11133000983339260" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "6588977", blockHash: "0xbe530352b01245d6a528527209117deabf73a8362190c9de1f68d6a173a98c74", timeStamp: "1540585329", hash: "0xad196cc408739ff533c3abe69a1c451ecf7a3a9d6cf7fe4ba2ba5839f85cdca1", nonce: "28", transactionIndex: "55", from: "0x5de7438e69ebc64657f4f8c5c902916150d5eeea", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "10000000000000000", gas: "344041", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "6790237", txreceipt_status: "1", gasUsed: "229814", confirmations: "1146757", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "18"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540585329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x5de7438e69ebc64657f4f8c5c902916150d5eeea"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 1, c: [18]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [13]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "10000000000000000"}, {name: "_price", type: "uint256", value: "10000000000000000"}, {name: "_stock", type: "uint256", value: "199"}, {name: "hero_id", type: "uint256", value: "18"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "58573690050611407" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6589845", blockHash: "0x6985db199c216d3ad7086afb6679bb2a57c28c4140d07f3e1ef57a19bc3e07b4", timeStamp: "1540597431", hash: "0xd8bb2d7c708351d734c98d64e02ba34ad8e7e0b3e3a82171578e45f83189d2d4", nonce: "385", transactionIndex: "146", from: "0x3e9f8f31725367937691e3c15eca355662ae3ad9", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "347538", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "7450327", txreceipt_status: "1", gasUsed: "231345", confirmations: "1145889", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540597431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x3e9f8f31725367937691e3c15eca355662ae3ad9"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [15]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "48"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "2042821059447851" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6590845", blockHash: "0xec0e4c446280ca7869349849c0838a0129b52f7d8e03862d1693b8a07eb00008", timeStamp: "1540611024", hash: "0x04277ab5d1e9eb061280567a020e0a421a99277f950580263a86c839ce8039f9", nonce: "4", transactionIndex: "96", from: "0x7e294f0c90dc1ab36979c27e8279ca74eae22ecb", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "346468", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3953250", txreceipt_status: "1", gasUsed: "233613", confirmations: "1144889", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540611024 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x7e294f0c90dc1ab36979c27e8279ca74eae22ecb"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [16]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "49"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "24045384000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6591940", blockHash: "0xc42055ccd8f0f49d06326d75e1715bf335adf7a2c6d5fe8f39bddc34ab6cc314", timeStamp: "1540626834", hash: "0x32293f7771cae28ddbf6f9d8ff20dc5183f6a8fea2c3bc275eb4fd47331e81ec", nonce: "284", transactionIndex: "135", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "326313", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "5784175", txreceipt_status: "1", gasUsed: "215612", confirmations: "1143794", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540626834 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [18]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "49"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6591944", blockHash: "0x6d0bdab6d5dc99565155fdb1285c0302f1fdf3ac6b99c6551cbb5efff20f9ff5", timeStamp: "1540626850", hash: "0x14dadbea9589e2037551eb1e069e8ecfcabc8ab7d19de39b9a6ebaac352f88af", nonce: "285", transactionIndex: "163", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "325068", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7766687", txreceipt_status: "1", gasUsed: "215612", confirmations: "1143790", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540626850 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [19]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "48"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6591949", blockHash: "0x24b1a850ccd2bf3f355441f42a2196f51c4de68c6e59ca874d615aee29f86ed2", timeStamp: "1540626905", hash: "0x33fc0f2951c75d387cb56fdff28e0550b088b5bbe99329bf40ad874e4fb6ef27", nonce: "286", transactionIndex: "123", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323983", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "6735350", txreceipt_status: "1", gasUsed: "218015", confirmations: "1143785", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540626905 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [20]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "47"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6591965", blockHash: "0x5697a22f42b3af71504460fc1c3e2cfcc58339f1899ec922ac9d3375081d326c", timeStamp: "1540627161", hash: "0x1fd17222167e06c0dbf93bff80513335dd140e7d2571c09572bc64b7fbe02d3f", nonce: "287", transactionIndex: "56", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323998", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6414463", txreceipt_status: "1", gasUsed: "215612", confirmations: "1143769", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "1"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540627161 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [21]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "49"}, {name: "hero_id", type: "uint256", value: "1"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6591979", blockHash: "0xe66bc824e3302d273ae1802051460c9af98a934e5a26073bdf64849733ff0151", timeStamp: "1540627303", hash: "0xa8ee03b3e6bef155a8872aaf258eaf5917db1f88c849164466017bde9aeb7d8d", nonce: "288", transactionIndex: "73", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "324013", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4919231", txreceipt_status: "1", gasUsed: "217155", confirmations: "1143755", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "2"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540627303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [22]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "49"}, {name: "hero_id", type: "uint256", value: "2"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6592443", blockHash: "0x1d422b8c9e688151eaf6f38c6ef766e87929997c4a18670ef7b60f3f95d4af99", timeStamp: "1540633736", hash: "0xbc1f873d2cb4843218a22fbd5494fb66929c86b3102fd9a9bc14a92edca2ef87", nonce: "292", transactionIndex: "27", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "325083", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1316267", txreceipt_status: "1", gasUsed: "218035", confirmations: "1143291", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "1"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540633736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [23]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "48"}, {name: "hero_id", type: "uint256", value: "1"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6592453", blockHash: "0xa07651d394d56a3e6996b7133821a33c821635f93c3611bfe00a94c68bcbc80a", timeStamp: "1540633838", hash: "0x0807ea8bdb3b877fd67957c767ecd768a4e2a04a0b4fb5be2452cbc348fd33a8", nonce: "293", transactionIndex: "60", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "325083", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "2445231", txreceipt_status: "1", gasUsed: "216335", confirmations: "1143281", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540633838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [24]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "48"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6592518", blockHash: "0x41ceab1992d22000f637790358cfff5dffd62f5fb5d181a0ae3247e6df605297", timeStamp: "1540634734", hash: "0x2cfcb3853365c987d7615c54568f0daafa0337417909c281e81e05c97e3f1265", nonce: "294", transactionIndex: "77", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "324013", gasPrice: "3000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "7348106", txreceipt_status: "1", gasUsed: "216335", confirmations: "1143216", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540634734 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [25]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "47"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6592554", blockHash: "0x01f2f4054da7a1a7a9ecd6982cd1c854cb5fc980a6c286e9d8b47ee524ad72fa", timeStamp: "1540635314", hash: "0x56773a8fc69344261d5dd1c42edefb9b52f5eef948be4eb64a24ba25328ab30d", nonce: "295", transactionIndex: "68", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323983", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "4067055", txreceipt_status: "1", gasUsed: "216345", confirmations: "1143180", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540635314 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [26]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "46"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6592559", blockHash: "0x249b351a4bda0105213eb29e1d587a4e0d655653f2cae492230a31dc06ba72bc", timeStamp: "1540635423", hash: "0xada2c965f5811cb6da82cbad8e01b320dd805bf60ad60746cabf09fb2ce9ff6a", nonce: "296", transactionIndex: "97", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "327648", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "5551533", txreceipt_status: "1", gasUsed: "215612", confirmations: "1143175", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540635423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [27]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "45"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6592565", blockHash: "0x42e7407a8820ef9ed0fdab81d74cca8acfdf8e127066f4024c84a95b5eeaa917", timeStamp: "1540635475", hash: "0x42290a28e9f92d1460ef86eb6a26b126889c996564d5471adab759dfb244dcf2", nonce: "297", transactionIndex: "52", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "324013", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "2579491", txreceipt_status: "1", gasUsed: "216315", confirmations: "1143169", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540635475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [28]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "44"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6592573", blockHash: "0x47d5989d75535718579188466d45b57b8a509865c2260ddccee95d4e6663fc51", timeStamp: "1540635575", hash: "0x706b1cdbbb8296613b923b676bb158ac2bb0f904b6934b070ca3400333ae9520", nonce: "298", transactionIndex: "62", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "324013", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3187119", txreceipt_status: "1", gasUsed: "216335", confirmations: "1143161", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540635575 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [29]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "47"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6592577", blockHash: "0x85fc258a79ca907f2dc0756c7e5d9bd9a2c14d275395ea3c6712cc83caf5eeb6", timeStamp: "1540635630", hash: "0x13c0390cb0be364b62172eb40fe2ef230afa74151640ab7d2096b841ae037995", nonce: "299", transactionIndex: "95", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "324013", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "4372093", txreceipt_status: "1", gasUsed: "217165", confirmations: "1143157", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540635630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [30]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "43"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6592579", blockHash: "0x02d376efc426f4e424a581eabc393e212ed00048242f5828004b32ff89567774", timeStamp: "1540635679", hash: "0x642b6f9a2e99ba9a6cc483cc239431f1ad454537558ba2cf9667eef4350c6ace", nonce: "300", transactionIndex: "117", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "325053", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6048091", txreceipt_status: "1", gasUsed: "217175", confirmations: "1143155", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540635679 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [31]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "46"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6592591", blockHash: "0x3666639514a756c0b3aba9aba5abe01df1a5e3d948e3b1f46abe63bf16fbc821", timeStamp: "1540635848", hash: "0x42f2e50e7e59d31985778ff112df0773e5b0ddcd5c594f3c9aa25b47ffb3bc1b", nonce: "301", transactionIndex: "102", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "326328", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4646324", txreceipt_status: "1", gasUsed: "217175", confirmations: "1143143", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "2"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540635848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [32]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "48"}, {name: "hero_id", type: "uint256", value: "2"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6592594", blockHash: "0xf369050ed04c0b29f1a1ebd9137ec82a03ffffac6a911db5c9128d2776894592", timeStamp: "1540635880", hash: "0xf600a0e1faeb8a30e96c5c7cc1db5a4872c85b47e002204a1e83e82029771760", nonce: "302", transactionIndex: "23", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "326328", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "1314077", txreceipt_status: "1", gasUsed: "216345", confirmations: "1143140", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540635880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [33]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "42"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6592597", blockHash: "0xf96dcd676a11176a4dc71cd02f2dc1d01d633948c0d0cc68f3aba568b246837e", timeStamp: "1540635900", hash: "0x2d0fefede6328ebadd1251588410430b80e65c8bd8ba3be2d6270055e0d5e001", nonce: "303", transactionIndex: "134", from: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "325038", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5299281", txreceipt_status: "1", gasUsed: "216325", confirmations: "1143137", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540635900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x0f59fff9764d77434ba3204ac0dc2f63bd6f894c"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [34]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "45"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "163815043000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6594127", blockHash: "0x3ad6534999208263d67e83e533fb3f24f0c422d0dd2b707b4a42ef7932f32cef", timeStamp: "1540657612", hash: "0x5c99534cabc40b845992e054e79fc94baaa50aa98ef7a9790a0910b4cef2b0eb", nonce: "3", transactionIndex: "79", from: "0xd597cca5d7ceb84a0515d48317276741293be450", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "30000000000000000", gas: "345318", gasPrice: "9000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "3176788", txreceipt_status: "1", gasUsed: "229855", confirmations: "1141607", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "20"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540657612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xd597cca5d7ceb84a0515d48317276741293be450"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 1, c: [20]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [35]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "30000000000000000"}, {name: "_price", type: "uint256", value: "30000000000000000"}, {name: "_stock", type: "uint256", value: "100"}, {name: "hero_id", type: "uint256", value: "20"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6600878", blockHash: "0xb166e4582ce56059c2514c8830779467f8baf4539d6a407f47fd67793ac16f1b", timeStamp: "1540753085", hash: "0x1e9fce04bbe7fcc8cbf1f240d95970f0cab8a9fa02861c06ef323cb523683e98", nonce: "10", transactionIndex: "42", from: "0xa4c62b6e63c1277ddae9efdf5e2382e58251e9ae", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "10000000000000000", gas: "343002", gasPrice: "2000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "2390278", txreceipt_status: "1", gasUsed: "228281", confirmations: "1134856", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "6"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540753085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xa4c62b6e63c1277ddae9efdf5e2382e58251e9ae"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [6]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [36]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "10000000000000000"}, {name: "_price", type: "uint256", value: "10000000000000000"}, {name: "_stock", type: "uint256", value: "198"}, {name: "hero_id", type: "uint256", value: "6"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "3666785578785119" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6601049", blockHash: "0xe1536593d41250a10369d54a79a04c5e5297d58f2847fe1ece9a4867bea31eaf", timeStamp: "1540755600", hash: "0xaa5d28796eb6a50211958027832bf2abc02ec8b6e53dbe0c3703b08ef9bb9919", nonce: "67", transactionIndex: "56", from: "0x9ad656b80953175c07470dcee801e551b28573c4", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "347583", gasPrice: "2000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "7584459", txreceipt_status: "1", gasUsed: "230612", confirmations: "1134685", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540755600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x9ad656b80953175c07470dcee801e551b28573c4"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [37]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "46"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "15180009289934341" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6603931", blockHash: "0x130604781fe6db945afc47b66a53ea0d27e8fa609f8a17c1bbd8b2ba608dd87d", timeStamp: "1540796776", hash: "0x8f82d0f27e60d8fda5e3422dc49b04c40b35dcc4954ff4cee35574d86e4b3c3d", nonce: "1546", transactionIndex: "40", from: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "347568", gasPrice: "6000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "4735990", txreceipt_status: "1", gasUsed: "230632", confirmations: "1131803", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540796776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x5ba3e11abf8c93186637847ec590fcd3aa588bd2"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [38]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "44"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "332979515196801282" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6605957", blockHash: "0x02c308c1bdf5fb9b697a4e789903b99b34db8e55591610e1777f05bb30070287", timeStamp: "1540825377", hash: "0x6af9926bcdb03255e2c8baa0bbf6f95001107527b7fdb982db883d52b8c008e8", nonce: "61", transactionIndex: "80", from: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "346498", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "5724642", txreceipt_status: "1", gasUsed: "231315", confirmations: "1129777", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540825377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [39]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "45"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1855044970620590" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6605960", blockHash: "0x77376252bafedc5e66d18fa6f7f21db2db9d21bee378e3295089b964976e7a6e", timeStamp: "1540825417", hash: "0xf25f4cd137b9167f8a2e508f9114291741fc36157f5ab256b9705e9bd979787a", nonce: "62", transactionIndex: "62", from: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "342052", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4759097", txreceipt_status: "1", gasUsed: "215632", confirmations: "1129774", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "1"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540825417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [40]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "47"}, {name: "hero_id", type: "uint256", value: "1"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1855044970620590" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6605962", blockHash: "0xa87791af627892fb7eadf9e1334fc69b9e5db81e05ffaf84c7decb3fc3979d13", timeStamp: "1540825433", hash: "0xe525ac24dc4a4af87ddfcce5d7a3c8f02bac137681bdbaab7c9041403bfcb211", nonce: "63", transactionIndex: "23", from: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323983", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1506641", txreceipt_status: "1", gasUsed: "215602", confirmations: "1129772", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540825433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [41]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "43"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1855044970620590" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6605972", blockHash: "0x015c2487cf539649733333db4140ad25e9cfa04031fc0a37f72d842e91eceb72", timeStamp: "1540825586", hash: "0xe85fc99fb76ebdef97a36bf918435e0c593469edb427ad9260d340ff7320df71", nonce: "64", transactionIndex: "139", from: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323983", gasPrice: "4000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6780623", txreceipt_status: "1", gasUsed: "217185", confirmations: "1129762", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "2"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540825586 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x2faeb67d709c0c162a18c8fb2ea8bdf9cecfb71f"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [42]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "47"}, {name: "hero_id", type: "uint256", value: "2"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1855044970620590" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "6607693", blockHash: "0x3d72c324d5fa2a0cdc9672d0e19073538d70826446299d2637c746e3effa7beb", timeStamp: "1540849275", hash: "0x23cbc23e476e6f7f6cd05838ff220d6f552c08a108f1ec9979a5cdb0271be06a", nonce: "26", transactionIndex: "66", from: "0xee61c9f12ee5d8e5b1275dfcabc9310a8a701f6e", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "10000000000000000", gas: "344026", gasPrice: "3200000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "5214336", txreceipt_status: "1", gasUsed: "228261", confirmations: "1128041", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "18"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540849275 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0xee61c9f12ee5d8e5b1275dfcabc9310a8a701f6e"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 1, c: [18]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [43]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "10000000000000000"}, {name: "_price", type: "uint256", value: "10000000000000000"}, {name: "_stock", type: "uint256", value: "198"}, {name: "hero_id", type: "uint256", value: "18"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "9377079324425490" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6607835", blockHash: "0x265ea2a8379ebc76b3f9bdec975e0152f3e14e1f072147fdec6ca439bd45f956", timeStamp: "1540851488", hash: "0x8e3ed8d6ca412e4f84cb17f1e44a691ec32c557d99ff27e526f679570e0bc456", nonce: "1521", transactionIndex: "31", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "350058", gasPrice: "6000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "4103115", txreceipt_status: "1", gasUsed: "231305", confirmations: "1127899", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "4"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540851488 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [4]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [44]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "41"}, {name: "hero_id", type: "uint256", value: "4"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "158827100032092667" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6607843", blockHash: "0xb1e3ea390ba8f0d8c938ec892f56dd15f9c47c7ea948cce0afb7872a45aba549", timeStamp: "1540851621", hash: "0x8a5473311bab9d8b3d889e0b926e567aec775bb6eaed8afe92790a124551353a", nonce: "6", transactionIndex: "109", from: "0x85cbe353d506a72c3be27540c1fcee7078fd9964", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "346468", gasPrice: "2000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7364920", txreceipt_status: "1", gasUsed: "216295", confirmations: "1127891", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "2"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540851621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x85cbe353d506a72c3be27540c1fcee7078fd9964"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [47]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "46"}, {name: "hero_id", type: "uint256", value: "2"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6607847", blockHash: "0x3144b361818063e1a32306e25a022599280254aa0cbe44a67beb05ce360780c7", timeStamp: "1540851649", hash: "0x7040e506a9acc0155090f5a4fcff3cb6b52010eabb18b494219500843a1b23bf", nonce: "7", transactionIndex: "11", from: "0x85cbe353d506a72c3be27540c1fcee7078fd9964", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "346498", gasPrice: "2000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6603588", txreceipt_status: "1", gasUsed: "215632", confirmations: "1127887", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "1"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540851649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x85cbe353d506a72c3be27540c1fcee7078fd9964"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [48]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "46"}, {name: "hero_id", type: "uint256", value: "1"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6607850", blockHash: "0xdef5e89cc4e41aeb8ea24815cda080bf5b68b3bbf079572b3a4369d47cdee7b5", timeStamp: "1540851710", hash: "0x8430220b62aa725d2ff630c87297ceeab32a8cf70f668e5e3189fd43ac59d2f9", nonce: "1523", transactionIndex: "98", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323968", gasPrice: "6000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5413637", txreceipt_status: "1", gasUsed: "215632", confirmations: "1127884", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "1"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540851710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [1]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [49]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "45"}, {name: "hero_id", type: "uint256", value: "1"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "158827100032092667" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6607854", blockHash: "0xb9f199c9376ef73adf5a6a1e26f5df936441fabff466b56d3967bf6a95309507", timeStamp: "1540851786", hash: "0xfb8469e7592e376c54dc78388bc90a5b23f083cce894d636594bc236b3113ac2", nonce: "1524", transactionIndex: "70", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323968", gasPrice: "6000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5877004", txreceipt_status: "1", gasUsed: "216305", confirmations: "1127880", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "2"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540851786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [50]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "45"}, {name: "hero_id", type: "uint256", value: "2"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "158827100032092667" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6607855", blockHash: "0x732c0c79a64bbb96ed04c3c73dad2f4542135347fb4ebd1f62c248cc7152548a", timeStamp: "1540851794", hash: "0x8074c0ad3ac42b3722c4abfbedf6c30571191f37d969de34db448399f8c32d56", nonce: "1525", transactionIndex: "49", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "325038", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2575682", txreceipt_status: "1", gasUsed: "216325", confirmations: "1127879", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "3"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540851794 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [3]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [51]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "42"}, {name: "hero_id", type: "uint256", value: "3"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "158827100032092667" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6607859", blockHash: "0xfc6976129394177df8d57c81130de041c9e4cf444ccfb8fde072d5dce2e35f22", timeStamp: "1540851848", hash: "0x885426dfb3fcf9793e0b156d53b4a0bcf5afab217477eb91a69775531b2dbd02", nonce: "1526", transactionIndex: "30", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "323983", gasPrice: "5000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "2193860", txreceipt_status: "1", gasUsed: "217175", confirmations: "1127875", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540851848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [52]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "44"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "158827100032092667" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6608736", blockHash: "0x828b6232eba15d0253defca756992f5f5ab54eb33b14262e2e2bb948d74d1744", timeStamp: "1540864410", hash: "0x29c3e5f09a3b5e00933b56264081ebd4dc2bc10a4f7b0c72945b5eff2fdbd96e", nonce: "10", transactionIndex: "62", from: "0x85cbe353d506a72c3be27540c1fcee7078fd9964", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "324013", gasPrice: "9000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "3804382", txreceipt_status: "1", gasUsed: "215632", confirmations: "1126998", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "5"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540864410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x85cbe353d506a72c3be27540c1fcee7078fd9964"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [5]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [55]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "43"}, {name: "hero_id", type: "uint256", value: "5"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6608746", blockHash: "0x51a289c7056fcd04f2d21089dcdab314372aa03c8a0d74a1355680cecccc4040", timeStamp: "1540864566", hash: "0xd374003f6706ba03ac365d6c73d1176da22250bb10999d1fe81cc6ebf1192488", nonce: "11", transactionIndex: "45", from: "0x85cbe353d506a72c3be27540c1fcee7078fd9964", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "30000000000000000", gas: "323857", gasPrice: "9000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "2198336", txreceipt_status: "1", gasUsed: "214835", confirmations: "1126988", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "20"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540864566 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x85cbe353d506a72c3be27540c1fcee7078fd9964"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 1, c: [20]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [56]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "30000000000000000"}, {name: "_price", type: "uint256", value: "30000000000000000"}, {name: "_stock", type: "uint256", value: "99"}, {name: "hero_id", type: "uint256", value: "20"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "6608751", blockHash: "0xe22545fe85733fe01ef922534c8c53e83766b34839810eb47b9a735c6d1e5921", timeStamp: "1540864684", hash: "0x0935efc9b9dc55f88ea017cb69f2e0e9b20c8c1dfd2e1614246fe7bfad8ca552", nonce: "12", transactionIndex: "88", from: "0x85cbe353d506a72c3be27540c1fcee7078fd9964", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "30000000000000000", gas: "323872", gasPrice: "8000000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "4747489", txreceipt_status: "1", gasUsed: "214855", confirmations: "1126983", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "17"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540864684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x85cbe353d506a72c3be27540c1fcee7078fd9964"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 1, c: [17]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [57]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "30000000000000000"}, {name: "_price", type: "uint256", value: "30000000000000000"}, {name: "_stock", type: "uint256", value: "100"}, {name: "hero_id", type: "uint256", value: "17"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: BuyStockHeroP1( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6609382", blockHash: "0x85270bab717eb8f26566479d4d729c26cad06b47bab2d5d1e4c132735d148781", timeStamp: "1540873768", hash: "0x61dafe40d4a481ac4f450078545b4793283feb321101aea9c6b274aaad5afd37", nonce: "1319", transactionIndex: "114", from: "0x20ca0d6fe51d06946f5cc90f9f4f297d398dd6db", to: "0x93f2c843f6827e48381654aa2b093e5f97e102c6", value: "40000000000000000", gas: "348798", gasPrice: "3210000000", input: "0x90e657540000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6640593", txreceipt_status: "1", gasUsed: "232995", confirmations: "1126352", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint16", name: "stock_id", value: "2"}], name: "BuyStockHeroP1", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "BuyStockHeroP1(uint16)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540873768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "stock_id", type: "uint32"}, {indexed: false, name: "hero_id", type: "uint32"}], name: "BuyStockHeroEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BuyStockHeroEvent", events: [{name: "buyer", type: "address", value: "0x20ca0d6fe51d06946f5cc90f9f4f297d398dd6db"}, {name: "stock_id", type: "uint32", value: {s: 1, e: 0, c: [2]}}, {name: "hero_id", type: "uint32", value: {s: 1, e: 1, c: [58]}}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}, {indexed: false, name: "_stock", type: "uint256"}, {indexed: false, name: "hero_id", type: "uint256"}], name: "showValues", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "showValues", events: [{name: "_value", type: "uint256", value: "40000000000000000"}, {name: "_price", type: "uint256", value: "40000000000000000"}, {name: "_stock", type: "uint256", value: "44"}, {name: "hero_id", type: "uint256", value: "2"}], address: "0x93f2c843f6827e48381654aa2b093e5f97e102c6"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "30250307952298343" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
