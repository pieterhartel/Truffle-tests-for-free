var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "ReverseRegistrar"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x9062C0A6Dbd6108336BcBe4593a3D1cE05512069","0xfDb33f8AC7ce72d7D4795Dd8610E323B4C122fbB","0x314159265dD8dbb310642f98f50C066173C1259b","0x5fBb459C49BB06083C33109fA4f14810eC2Cf358","0x6601ccBA30f9DceBaBed7D90de7cfc86a3ca17B9","0xc922C48950C599654e3F04Bb76A76B7FDd1E7a94","0xDF8663f97bE0D856f620626547482d7ABc73F422","0xb148cd1c75bFEAEb0182Bf99064CdBE94276B7Db","0xff111Ea295a1D4ae117a04Fcea1DB77cE3058DF7","0x974cf1Ee678b543f07b3C835BB0a1a0b386808f2","0x78e80c9CC2A9a1A9829a1c6708423D9b82166886","0x39aB66F6f4f046BcDd8141766028e4E8Ad71439b","0x2048A301ee41dE509D4e4D83F2bCA8035558731a","0x4dD4B89196E94550FffA1536865424795045062e","0x8cdbDb4a43CaFa26211F02263821cA9A0332d76F","0x216fC0aA752393F8f215b603B4156987d3D8bbBf","0x18158dEf12AEeEE1786F979B106fA739bdb10d00","0x00f6754F0C0962873271B1266b0E27E8D948b23f","0x8e00dD033386a96fc1DF99ccB4aC4B538F6e4153","0xf608e5Fb21c06EaC4249e4DFDA89C8C9e69De632","0x2fcf1E26d77BBC0Db15acF1Fc77b4D2f5DdB1019","0x5FfC014343cd971B7eb70732021E26C35B744cc4","0x0D68b5DC82F6DC01978A5A7BdEad322233B8C07D","0x1E2B3E14148487D26923BeEcb94b251C0A09ba5D","0xaCC8a222c7B7E14c9636623Ef2E3F0c6a3dA4C88","0x2211D5443190DC88181e21eE75E243004Bae1B2A","0x0305c14c79aCC2Ec14ac4Cd43e241Fc3E6c23bD9","0xf8A065F287d91d77cD626AF38ffA220D9B552A2b","0x680887939699061A00aef01278808a8C7a3A9561","0x47ae8375B52166e513616C8ECA798baFb9C1205a","0xAAC6Fa44D791eB310Dd395Db1181a1b8Aa33834B","0x7b8d9E9447758636b70D5713ADF07347bC5B81C3","0x529f2A0225e085E990e31f0090bB0bA2E3f0A728","0x538d455EA163b509CF18593d3cf5d4DDb4E76632","0xD2bFB16bD98a96CDBE1704A028bC7aFd68e99fc3","0x1da022710dF5002339274AaDEe8D58218e9D6AB5","0xe8C3145B85c0B744527e7400cBf87942888bc608","0xddbaa298Ff16b40293Cba433fb65eB7a7907f896","0x041357552fAA8113E5Adaa5fC3ACD312978D9Dfb","0x1b00Ffd60332c7B99e5B73f926001Fe4a5d1F6e6","0x1c3e1EFc748B6411779d025d92869e9879772B3b","0xa2D3c273A4D27012ebe9c48B34aDbf41ab886b22","0x8688a84fcFD84d8F78020d0fc0b35987cC58911f"]
addressListOriginal.length = 45
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"ens","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"defaultResolver","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"addr","type":"address"}],"name":"node","outputs":[{"name":"ret","type":"bytes32"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = []
eventSignatureListOriginal = []
topicListOriginal = []
nBlocksOriginal = 50
fromBlockOriginal = 3787060
toBlockOriginal = 3885479
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"ensAddr","value":4},{"type":"address","name":"resolverAddr","value":5}],"name":"ReverseRegistrar","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"3787060","timeStamp":"1496060104","hash":"0x0c4bb1d89d06fed54f923a6b4b67c85000af887b64b1e2c02fb6680d2843c238","nonce":"66","blockHash":"0x471e77b00c7136c5b80b670ab52b95c21e20fe159e19931471874c8889532aeb","transactionIndex":"69","from":"0xfdb33f8ac7ce72d7d4795dd8610e323b4c122fbb","to":0,"value":"0","gas":"1000000","gasPrice":"1000000000","isError":"0","txreceipt_status":"","input":"0x365896c7000000000000000000000000314159265dd8dbb310642f98f50c066173c1259b0000000000000000000000005fbb459c49bb06083c33109fa4f14810ec2cf358","contractAddress":"0x9062c0a6dbd6108336bcbe4593a3d1ce05512069","cumulativeGasUsed":"2835743","gasUsed":"622391","confirmations":"3888094"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"address","name":"ensAddr","value":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"},{"type":"address","name":"resolverAddr","value":"0x22d491Bde2303f2f43325b2108D26f1eAbA1e32b"}],"name":"ReverseRegistrar","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
