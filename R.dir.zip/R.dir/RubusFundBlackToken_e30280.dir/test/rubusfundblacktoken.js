const RubusFundBlackToken = artifacts.require( "./RubusFundBlackToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "RubusFundBlackToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xC79d4c81f87c152BA604017A7B4747232aE30280", "0x73D5f035B8CB58b4aF065d6cE49fC8E7288536F3", "0xf0EF10870308013903bd6Dc8f86E7a7EAF1a86Ab", "0x7c4C8b371d4348f7A1fd2e76f05aa60846b442DD", "0xedc3B6301d849F1080bf11E31De7eeF96d8fF94e", "0x8FD70dbe7d87ec70fC8f1B7bcE9776498c44a8f8", "0x5Ad09914ce092A737E4a97416714854C99118c7A", "0xaAD615F0B224cac7336F5e0Ec809859E948c9232", "0xe3510312040988bDf8585eCbB237999012683782", "0xbdC93290AC71a96eB8d36993A56Ff6B85aB8d799", "0x255dE1f9a17a0D84B4c93bA15FF63233F01125Bf", "0xcab1Cf97dCDbEB4d78668377037F62371e424aAD", "0x5B93C4dC5e190AC8c43db96aD03F1A8106479d5B", "0xf2802C69E087F73B22713bD8cF5b24Ee45C4B146", "0x2408e8fd0E79EB4836e13DD824A82A4F101CB4bA", "0xf0F85FD82Fb3b348310459bA90C916A00CA1b203", "0x216B223979337673493724f03b44BdA84BC4fb51", "0xc5a7D3697A5b1Bc79a19304c827aC607c0Cc23C0", "0x9E855F6A9967f79348669f7688d46168B4740d73", "0x3Be854D1f09420Ff5394A240e4d13c91FD20B799", "0x7a463015082FA60C6f36577F7F2DAFE0ed5a1F19", "0x0a75d99987a90359D34518481cBE41E89a894EE4", "0xafb4a48A1c12A5C0E06474Ed054030D9d12A3D97", "0xD43dF3BBF6d1B13C5053564C7aF7e67B45dF43DE", "0x2c91c924CA8ac89840F0BfC8d40c6204c41c72e6", "0x0A6602eD1305848c9d96570058669692e3fa9056", "0x32499854428BB75082F66ac1440B92FA9EfD1e46", "0x0F587e0ce60FDe32A169B3C14483d225D278a262", "0x358a77aD058a2B1BCeb12c46dA49669dbde16557", "0xAD1D604f85D8d0017fBa212AdbBaa3F4aB642a11", "0x79a3B843C7c3477dE78CaCc7Fc81b742D3E97Dc6", "0x26202CBE46584B154b969bCF6Dbda341e12E314c", "0xE18B2eBbF4502A3083f897748e0f66118CA1108E", "0xCDA3Ec16baF6130a3132c2c3fdbeB3AB713F4039", "0xF297f3a7FC1901BfA92b5B68eEda3a72A1757817", "0x0133A5910fcCE0ECCdA9bf1776Ae6a6333E4c343", "0xb1199F11D4268CA35D9b69DA5d16e750A5A5B541", "0x211Ef2bbEBa52ec094CD3C4d895CC359C4aA83C9", "0xD70659a8d15Ec42CE7f2Dc3ec45cA89745840652", "0x3021CB64eAfa2d280463E861DdB148bA6EedD002", "0xCbC8259F61B27D285d51A0682b5F3b4D1cD1dDD9", "0xDB846C52EFe54BA3870a6c196feceAb3F8050CD3", "0x870672caA319170D8Ff25d01811E820d23C1784e", "0xA717626CF32466a1b7AE2116122f6666BC7Af994", "0x85ee64A1ebfaC5077Acd113C7f4CCE78CF9569B4", "0x6840e8cEbE0B99Fd6c3CE09Cf77FB46E9F1e995D", "0xE96f21c53345c310a91d2251549A54090b74196C", "0xfEE5f1c0a70D5ED7831f3f1c42566ffa686a0E71", "0xbf98608d3E9F852506c96d31243663E409f5c61a", "0xACe55c42c2AacD7a93982E1C2019c9aD505c9ec3", "0x0F490D87110EcD5C82142Dab69565250B138A77B", "0x06eC97fEaeb0F4B9a75F9671D6B62BFADaF18Ddd", "0xA25da51e6Eb7Ad8C69bdc3Bd71dC5632CeA45FAa", "0xe5c9a36C5db935E85881a1A7753F8d390eA72C54", "0x264Fa15214ae7e3e0e4eC60D5b77112A422f81a4", "0x7b9D698589a76170cE200C4F440550aB58385a3D", "0xdC4682ae040147F3F13D671009F4f23befA3b500", "0x0ABe3681D83c91b0d7Dab32DdF9BD5A1ef42f45B", "0x837C3eE06e8F85E62C2dF921E18FBdf0Cd72d763", "0xE4C7dB913F86c4EF18CCd5AE22279459e490F61F", "0x1cBEF3676Ef0f4D7efB786D2Bda33e5E22b6A313", "0x1B2Ea4e00392eEccBb51D41913D976f1cC53cdF2", "0x1398740b2A181F35037D90185e48A105164cbc88", "0x7077c35f70c1c0a522720eEe883E1e78E2Be131D", "0xfdafd1ADC63CF681B8325Ab005d29232f2037131", "0x4C45Fe5AFCa6fac6c516De6106Fc75f511983b04", "0xef419272F03e1AadAA56c1ab48da81d48f9Ac8af", "0x86a971F5A7a465BC7550472487b0a23EC73C222d", "0x826cBb6552f39b055f6aEC1844046A5dCbE260B3", "0x9053814dF305d3169ca701F199d0EA8C1E3D2e14", "0x41BbB7719B599cc2D73c85486885975D473b6BB1", "0x737BE443d4bbAAfedfC29b68D98D7da4a93DC512", "0x1251b9D368169DF7129D73371B662aE13496c338", "0x237EEA7441D27ee00B90916a77401E0078ce29c8", "0x08DfCd1f0D8465d795873fb6f8C897f4aA38472f", "0x4f915C31aEB71456ec26DbB1cC87C6aD32E23171"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "depositWallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimalEthers", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "withdrawCommission", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOfUnlockTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rubusBlackAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "withdrawWallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investCommission", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "depositCommission", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "priceEthPerToken", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "lockTimestamp", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investWallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "lockTokensPercent", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "priceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "sender", type: "address"}, {name: "index", type: "uint256"}], name: "getPurchases", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "sender", type: "address"}], name: "checkVesting", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "lock", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "lockStatus", type: "bool"}], name: "Lock", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "tokensAmount", type: "uint256"}], name: "DeleteTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}], name: "AddTokens", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "weiAmount", type: "uint256"}], name: "GetWei", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "weiAmount", type: "uint256"}], name: "AddWei", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "deposit", type: "uint256"}], name: "DepositCommission", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "invest", type: "uint256"}], name: "InvestCommission", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "withdraw", type: "uint256"}], name: "WithdrawCommission", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "deposit", type: "address"}], name: "DepositWallet", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "invest", type: "address"}], name: "InvestWallet", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "withdraw", type: "address"}], name: "WithdrawWallet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Withdraw", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "isPause", type: "bool"}], name: "Pause", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "previousOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Lock(bool)", "DeleteTokens(address,uint256)", "AddTokens(address,uint256,uint256)", "NewTokenPrice(uint256)", "GetWei(uint256)", "AddWei(uint256)", "DepositCommission(uint256)", "InvestCommission(uint256)", "WithdrawCommission(uint256)", "DepositWallet(address)", "InvestWallet(address)", "WithdrawWallet(address)", "Deposit(address,uint256,uint256,uint256,uint256)", "Withdraw(address,uint256,uint256,uint256,uint256)", "Pause(bool)", "OwnershipTransferred(address,address)", "Approval(address,address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x73cb6ff886d89c3816d03270daa43e4789d7c218d9a12960651ff278e1fef1f1", "0x1b45b2e666e088aa278ddc6e9e370bf236e60383531c436e3c58b5d303ed894c", "0x58da2bed281901f7b1784e4022914a99a7acf3967207b38dccea7e5a36d01b1a", "0x9557bc722811e3470d3be6d08252c3dce6f4db6392c65b807171fbd17981c8cf", "0xbf3abc34d061b0b1e4b1edee8ae78bcd46639a35c0698cd2fbc1733809575477", "0xe111a269980b9ad78d4025ba495c3817ab9dc6b08b241aa29d630a2ce4b9b975", "0x859ec3731e29229f50ddc87fca2932855c175cea554907d516716d685b5658f1", "0x1c9b75f9ec354b757c65d8eb3cfb9f769407ffe9797c4860d947a041e7a7791c", "0x3f72c922b69c8be41ac3f2dd3984d35f00019e63e1705f74026f2fea3a723519", "0x9b28f9d7ad0bed83c740b697689c8e2c755f3bad45873beb54baeb931b7e5d9a", "0x3e2f2b577264fcb20940a9bd1216a084f62f8cb6467483b618a677d7738f352c", "0x7cae296765e6ad1c761e0d9848d243c2cbcfe51522f210c6959465880248fa1c", "0x7162984403f6c73c8639375d45a9187dfd04602231bd8e587c415718b5f7e5f9", "0xe08737ac48a1dab4b1a46c7dc9398bd5bfc6d7ad6fabb7cd8caa254de14def35", "0x9422424b175dda897495a07b091ef74a3ef715cf6d866fc972954c1c7f459304", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6593469 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6764251 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "RubusFundBlackToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "depositWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "depositWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimalEthers", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimalEthers()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "withdrawCommission", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawCommission()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOfUnlockTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOfUnlockTokens(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rubusBlackAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rubusBlackAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "withdrawWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investCommission", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investCommission()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "depositCommission", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "depositCommission()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "priceEthPerToken", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "priceEthPerToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lockTimestamp", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockTimestamp()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lockTokensPercent", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockTokensPercent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "priceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "priceOf()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getPurchases", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPurchases(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "checkVesting", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkVesting(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lock", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "RubusFundBlackToken", function( accounts ) {

	it( "TEST: RubusFundBlackToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6593469", timeStamp: "1540648620", hash: "0x8eba227cfd2117fe75df7f39eb212f84289ee1433fd7c6f6fda2c6bdc51cc433", nonce: "43", blockHash: "0x704766966b8057604c962ae4302947b3c2d8f1f0b71f1f91ea025472a1870139", transactionIndex: "119", from: "0xedc3b6301d849f1080bf11e31de7eef96d8ff94e", to: 0, value: "0", gas: "2548017", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x1bb0e09a", contractAddress: "0xc79d4c81f87c152ba604017a7b4747232ae30280", cumulativeGasUsed: "7985798", gasUsed: "2548017", confirmations: "1141741"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "RubusFundBlackToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = RubusFundBlackToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540648620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = RubusFundBlackToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "lockStatus", type: "bool"}], name: "Lock", type: "event"} ;
		console.error( "eventCallOriginal[0,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Lock", events: [{name: "lockStatus", type: "bool", value: false}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"} ;
		console.error( "eventCallOriginal[0,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewTokenPrice", events: [{name: "tokenPrice", type: "uint256", value: "33333"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deposit", type: "uint256"}], name: "DepositCommission", type: "event"} ;
		console.error( "eventCallOriginal[0,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DepositCommission", events: [{name: "deposit", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "invest", type: "uint256"}], name: "InvestCommission", type: "event"} ;
		console.error( "eventCallOriginal[0,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestCommission", events: [{name: "invest", type: "uint256", value: "80"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "withdraw", type: "uint256"}], name: "WithdrawCommission", type: "event"} ;
		console.error( "eventCallOriginal[0,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawCommission", events: [{name: "withdraw", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deposit", type: "address"}], name: "DepositWallet", type: "event"} ;
		console.error( "eventCallOriginal[0,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DepositWallet", events: [{name: "deposit", type: "address", value: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "invest", type: "address"}], name: "InvestWallet", type: "event"} ;
		console.error( "eventCallOriginal[0,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestWallet", events: [{name: "invest", type: "address", value: "0xf0ef10870308013903bd6dc8f86e7a7eaf1a86ab"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "withdraw", type: "address"}], name: "WithdrawWallet", type: "event"} ;
		console.error( "eventCallOriginal[0,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawWallet", events: [{name: "withdraw", type: "address", value: "0x7c4c8b371d4348f7a1fd2e76f05aa60846b442dd"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[0,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "25118034424451178970" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setNewPrice( \"20606\" )", async function( ) {
		const txOriginal = {blockNumber: "6593991", timeStamp: "1540655787", hash: "0x7898ab068e4bbc2c025d05204c816fc421095d045ff41b85c6540735e836eba7", nonce: "44", blockHash: "0xef5d0916dd815b02dfc8d5afaf4d96eaa303dabf5ff776513e5693bb8ea87430", transactionIndex: "106", from: "0xedc3b6301d849f1080bf11e31de7eef96d8ff94e", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "43501", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xee8cdd4e000000000000000000000000000000000000000000000000000000000000507e", contractAddress: "", cumulativeGasUsed: "5551928", gasUsed: "29001", confirmations: "1141219"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ethPerToken", value: "20606"}], name: "setNewPrice", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setNewPrice(uint256)" ]( "20606", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540655787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"} ;
		console.error( "eventCallOriginal[1,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewTokenPrice", events: [{name: "tokenPrice", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[1,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "25118034424451178970" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( [addressList[7],addressList[8],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6593999", timeStamp: "1540655862", hash: "0xcb5d6999292bc895e0cd7e90f848b27eed2801f2223ae8f27a0fe94117a0fc01", nonce: "45", blockHash: "0x9b5a64482d1f30dc79890576183790422e5358ef839b5d2fdbb243325cb2d5dd", transactionIndex: "40", from: "0xedc3b6301d849f1080bf11e31de7eef96d8ff94e", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "2793438", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x672434820000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000078000000000000000000000000000000000000000000000000000000000000000390000000000000000000000008fd70dbe7d87ec70fc8f1b7bce9776498c44a8f80000000000000000000000005ad09914ce092a737e4a97416714854c99118c7a000000000000000000000000aad615f0b224cac7336f5e0ec809859e948c9232000000000000000000000000e3510312040988bdf8585ecbb237999012683782000000000000000000000000bdc93290ac71a96eb8d36993a56ff6b85ab8d799000000000000000000000000255de1f9a17a0d84b4c93ba15ff63233f01125bf000000000000000000000000cab1cf97dcdbeb4d78668377037f62371e424aad0000000000000000000000005b93c4dc5e190ac8c43db96ad03f1a8106479d5b000000000000000000000000f2802c69e087f73b22713bd8cf5b24ee45c4b1460000000000000000000000002408e8fd0e79eb4836e13dd824a82a4f101cb4ba000000000000000000000000f0f85fd82fb3b348310459ba90c916a00ca1b203000000000000000000000000216b223979337673493724f03b44bda84bc4fb51000000000000000000000000c5a7d3697a5b1bc79a19304c827ac607c0cc23c00000000000000000000000009e855f6a9967f79348669f7688d46168b4740d730000000000000000000000003be854d1f09420ff5394a240e4d13c91fd20b799000000000000000000000000e3510312040988bdf8585ecbb2379990126837820000000000000000000000007a463015082fa60c6f36577f7f2dafe0ed5a1f190000000000000000000000000a75d99987a90359d34518481cbe41e89a894ee4000000000000000000000000afb4a48a1c12a5c0e06474ed054030d9d12a3d97000000000000000000000000d43df3bbf6d1b13c5053564c7af7e67b45df43de0000000000000000000000002c91c924ca8ac89840f0bfc8d40c6204c41c72e60000000000000000000000000a6602ed1305848c9d96570058669692e3fa905600000000000000000000000032499854428bb75082f66ac1440b92fa9efd1e460000000000000000000000000f587e0ce60fde32a169b3c14483d225d278a262000000000000000000000000358a77ad058a2b1bceb12c46da49669dbde16557000000000000000000000000ad1d604f85d8d0017fba212adbbaa3f4ab642a1100000000000000000000000079a3b843c7c3477de78cacc7fc81b742d3e97dc600000000000000000000000026202cbe46584b154b969bcf6dbda341e12e314c000000000000000000000000e18b2ebbf4502a3083f897748e0f66118ca1108e000000000000000000000000cda3ec16baf6130a3132c2c3fdbeb3ab713f4039000000000000000000000000f297f3a7fc1901bfa92b5b68eeda3a72a17578170000000000000000000000000133a5910fcce0eccda9bf1776ae6a6333e4c3430000000000000000000000007a463015082fa60c6f36577f7f2dafe0ed5a1f19000000000000000000000000b1199f11d4268ca35d9b69da5d16e750a5a5b541000000000000000000000000211ef2bbeba52ec094cd3c4d895cc359c4aa83c9000000000000000000000000d70659a8d15ec42ce7f2dc3ec45ca897458406520000000000000000000000003021cb64eafa2d280463e861ddb148ba6eedd002000000000000000000000000cbc8259f61b27d285d51a0682b5f3b4d1cd1ddd9000000000000000000000000db846c52efe54ba3870a6c196feceab3f8050cd3000000000000000000000000870672caa319170d8ff25d01811e820d23c1784e000000000000000000000000a717626cf32466a1b7ae2116122f6666bc7af99400000000000000000000000085ee64a1ebfac5077acd113c7f4cce78cf9569b40000000000000000000000006840e8cebe0b99fd6c3ce09cf77fb46e9f1e995d000000000000000000000000e96f21c53345c310a91d2251549a54090b74196c000000000000000000000000fee5f1c0a70d5ed7831f3f1c42566ffa686a0e71000000000000000000000000bf98608d3e9f852506c96d31243663e409f5c61a000000000000000000000000ace55c42c2aacd7a93982e1c2019c9ad505c9ec30000000000000000000000000f490d87110ecd5c82142dab69565250b138a77b00000000000000000000000006ec97feaeb0f4b9a75f9671d6b62bfadaf18ddd000000000000000000000000a25da51e6eb7ad8c69bdc3bd71dc5632cea45faa000000000000000000000000e5c9a36c5db935e85881a1a7753f8d390ea72c54000000000000000000000000264fa15214ae7e3e0e4ec60d5b77112a422f81a40000000000000000000000007b9d698589a76170ce200c4f440550ab58385a3d000000000000000000000000dc4682ae040147f3f13d671009f4f23befa3b5000000000000000000000000000abe3681d83c91b0d7dab32ddf9bd5a1ef42f45b000000000000000000000000837c3ee06e8f85e62c2df921e18fbdf0cd72d763000000000000000000000000e4c7db913f86c4ef18ccd5ae22279459e490f61f00000000000000000000000000000000000000000000000000000000000000390000000000000000000000000000000000000000000000119f780ed29aba00000000000000000000000000000000000000000000000000233ef01da5357400000000000000000000000000000000000000000000000000229f15ba7ad811280000000000000000000000000000000000000000000000000910550c41fcacae00000000000000000000000000000000000000000000000008fcd963b8354f800000000000000000000000000000000000000000000000000c3840a99cc8fbc0000000000000000000000000000000000000000000000000116954d340b79700000000000000000000000000000000000000000000000000137e64fe390fb55800000000000000000000000000000000000000000000000008cfbc07694d5d000000000000000000000000000000000000000000000000001158d411b0f5e4700000000000000000000000000000000000000000000000001164789e9113cb8000000000000000000000000000000000000000000000000007e7d9bc707d5c80000000000000000000000000000000000000000000000000188698592cdf500b8000000000000000000000000000000000000000000000000d1f97859c034cc00000000000000000000000000000000000000000000000000fcfb378e0fab90000000000000000000000000000000000000000000000000007f13c620fbc9a66000000000000000000000000000000000000000000000000093868a0bd9027608000000000000000000000000000000000000000000000000ed0caf0587f3120000000000000000000000000000000000000000000000000073856ebe543794000000000000000000000000000000000000000000000000007d3999d682340e00000000000000000000000000000000000000000000000004651cdf75939879fc000000000000000000000000000000000000000000000000cb513dc9dbe6f00000000000000000000000000000000000000000000000000115403cfbfd5230000000000000000000000000000000000000000000000000007c16e0c5b88b140000000000000000000000000000000000000000000000000745572b95d0262c00000000000000000000000000000000000000000000000000f5b26b21165b0e00000000000000000000000000000000000000000000000002e88944a253427800000000000000000000000000000000000000000000000000c68b013c5a7820000000000000000000000000000000000000000000000000007c16e0c5b88b140000000000000000000000000000000000000000000000000094e840ed43da18000000000000000000000000000000000000000000000000007e92373013462e00000000000000000000000000000000000000000000000000f53730827c41d0000000000000000000000000000000000000000000000000005bd0467906dd7ee800000000000000000000000000000000000000000000000106bb21b0608fa8000000000000000000000000000000000000000000000000015e4ed795d614e000000000000000000000000000000000000000000000000000bd29bf737fd00400000000000000000000000000000000000000000000000000a6f1338ff13b897a000000000000000000000000000000000000000000000000b09c0a04bc73510000000000000000000000000000000000000000000000000057dff6075788e5000000000000000000000000000000000000000000000000005e87b57ab21c48000000000000000000000000000000000000000000000000005e87b57ab21c48000000000000000000000000000000000000000000000000006bc3ab0bdf86a400000000000000000000000000000000000000000000000000808f9aa6ddc01000000000000000000000000000000000000000000000000000699df5289697480000000000000000000000000000000000000000000000000196b9a4fb752f64000000000000000000000000000000000000000000000000007439d3794c7e5800000000000000000000000000000000000000000000000000c1b5b5ca2a27e80000000000000000000000000000000000000000000000000078dffaa71c5a70000000000000000000000000000000000000000000000000004fcca2f59b3660000000000000000000000000000000000000000000000000005fc25d26ba414000000000000000000000000000000000000000000000000000a056fd4a46789120000000000000000000000000000000000000000000000000bf84ba4d748280000000000000000000000000000000000000000000000000005793b5e57585380000000000000000000000000000000000000000000000000059541ad072c03400000000000000000000000000000000000000000000000000ad6706dfedcf740000000000000000000000000000000000000000000000006512a475112397ac000000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "6319248", gasUsed: "1862292", confirmations: "1141211"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "receiver", value: [addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[10],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[22],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61]]}, {type: "uint256[]", name: "amount", value: ["325085600000000000000","650171200000000000000","638652571969440000000","167197557018564800000","165793656000000000000","225414355040000000000","321184572800000000000","359595821267961600000","162542800000000000000","319995409675200000000","320834360000000000000","145833800000000000000","452420457615831600000","242084108000000000000","291667600000000000000","146510084997438400000","170085372063115600000","273299518800000000000","133186900000000000000","144374599600000000000","1297166724609555800000","234408944000000000000","319648560000000000000","143065300000000000000","2145979500000000000000","283269294000000000000","858391800000000000000","228904480000000000000","143065300000000000000","171678360000000000000","145926606000000000000","282714320000000000000","105853845411638800000","302908200000000000000","403877600000000000000","218090180000000000000","192471244368061700000","203616922600000000000","101312801800000000000","108985800000000000000","108985800000000000000","124243812000000000000","148220688000000000000","121768136000000000000","468922199200000000000","133999320000000000000","223332200000000000000","139359292800000000000","92002400000000000000","110402880000000000000","184859206232276800000","220805760000000000000","100969400000000000000","102988788000000000000","199919412000000000000","29831431660000000000000","50000000000000000000"]}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(address[],uint256[])" ]( [addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[10],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[22],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61]], ["325085600000000000000","650171200000000000000","638652571969440000000","167197557018564800000","165793656000000000000","225414355040000000000","321184572800000000000","359595821267961600000","162542800000000000000","319995409675200000000","320834360000000000000","145833800000000000000","452420457615831600000","242084108000000000000","291667600000000000000","146510084997438400000","170085372063115600000","273299518800000000000","133186900000000000000","144374599600000000000","1297166724609555800000","234408944000000000000","319648560000000000000","143065300000000000000","2145979500000000000000","283269294000000000000","858391800000000000000","228904480000000000000","143065300000000000000","171678360000000000000","145926606000000000000","282714320000000000000","105853845411638800000","302908200000000000000","403877600000000000000","218090180000000000000","192471244368061700000","203616922600000000000","101312801800000000000","108985800000000000000","108985800000000000000","124243812000000000000","148220688000000000000","121768136000000000000","468922199200000000000","133999320000000000000","223332200000000000000","139359292800000000000","92002400000000000000","110402880000000000000","184859206232276800000","220805760000000000000","100969400000000000000","102988788000000000000","199919412000000000000","29831431660000000000000","50000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540655862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "_price", type: "uint256"}], name: "AddTokens", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddTokens", events: [{name: "user", type: "address", value: "0x8fd70dbe7d87ec70fc8f1b7bce9776498c44a8f8"}, {name: "tokensAmount", type: "uint256", value: "325085600000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x5ad09914ce092a737e4a97416714854c99118c7a"}, {name: "tokensAmount", type: "uint256", value: "650171200000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xaad615f0b224cac7336f5e0ec809859e948c9232"}, {name: "tokensAmount", type: "uint256", value: "638652571969440000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xe3510312040988bdf8585ecbb237999012683782"}, {name: "tokensAmount", type: "uint256", value: "167197557018564800000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xbdc93290ac71a96eb8d36993a56ff6b85ab8d799"}, {name: "tokensAmount", type: "uint256", value: "165793656000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x255de1f9a17a0d84b4c93ba15ff63233f01125bf"}, {name: "tokensAmount", type: "uint256", value: "225414355040000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xcab1cf97dcdbeb4d78668377037f62371e424aad"}, {name: "tokensAmount", type: "uint256", value: "321184572800000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x5b93c4dc5e190ac8c43db96ad03f1a8106479d5b"}, {name: "tokensAmount", type: "uint256", value: "359595821267961600000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xf2802c69e087f73b22713bd8cf5b24ee45c4b146"}, {name: "tokensAmount", type: "uint256", value: "162542800000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x2408e8fd0e79eb4836e13dd824a82a4f101cb4ba"}, {name: "tokensAmount", type: "uint256", value: "319995409675200000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xf0f85fd82fb3b348310459ba90c916a00ca1b203"}, {name: "tokensAmount", type: "uint256", value: "320834360000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x216b223979337673493724f03b44bda84bc4fb51"}, {name: "tokensAmount", type: "uint256", value: "145833800000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xc5a7d3697a5b1bc79a19304c827ac607c0cc23c0"}, {name: "tokensAmount", type: "uint256", value: "452420457615831600000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x9e855f6a9967f79348669f7688d46168b4740d73"}, {name: "tokensAmount", type: "uint256", value: "242084108000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x3be854d1f09420ff5394a240e4d13c91fd20b799"}, {name: "tokensAmount", type: "uint256", value: "291667600000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xe3510312040988bdf8585ecbb237999012683782"}, {name: "tokensAmount", type: "uint256", value: "146510084997438400000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x7a463015082fa60c6f36577f7f2dafe0ed5a1f19"}, {name: "tokensAmount", type: "uint256", value: "170085372063115600000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x0a75d99987a90359d34518481cbe41e89a894ee4"}, {name: "tokensAmount", type: "uint256", value: "273299518800000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xafb4a48a1c12a5c0e06474ed054030d9d12a3d97"}, {name: "tokensAmount", type: "uint256", value: "133186900000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xd43df3bbf6d1b13c5053564c7af7e67b45df43de"}, {name: "tokensAmount", type: "uint256", value: "144374599600000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x2c91c924ca8ac89840f0bfc8d40c6204c41c72e6"}, {name: "tokensAmount", type: "uint256", value: "1297166724609555800000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x0a6602ed1305848c9d96570058669692e3fa9056"}, {name: "tokensAmount", type: "uint256", value: "234408944000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x32499854428bb75082f66ac1440b92fa9efd1e46"}, {name: "tokensAmount", type: "uint256", value: "319648560000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x0f587e0ce60fde32a169b3c14483d225d278a262"}, {name: "tokensAmount", type: "uint256", value: "143065300000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x358a77ad058a2b1bceb12c46da49669dbde16557"}, {name: "tokensAmount", type: "uint256", value: "2145979500000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xad1d604f85d8d0017fba212adbbaa3f4ab642a11"}, {name: "tokensAmount", type: "uint256", value: "283269294000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x79a3b843c7c3477de78cacc7fc81b742d3e97dc6"}, {name: "tokensAmount", type: "uint256", value: "858391800000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x26202cbe46584b154b969bcf6dbda341e12e314c"}, {name: "tokensAmount", type: "uint256", value: "228904480000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xe18b2ebbf4502a3083f897748e0f66118ca1108e"}, {name: "tokensAmount", type: "uint256", value: "143065300000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xcda3ec16baf6130a3132c2c3fdbeb3ab713f4039"}, {name: "tokensAmount", type: "uint256", value: "171678360000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xf297f3a7fc1901bfa92b5b68eeda3a72a1757817"}, {name: "tokensAmount", type: "uint256", value: "145926606000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x0133a5910fcce0eccda9bf1776ae6a6333e4c343"}, {name: "tokensAmount", type: "uint256", value: "282714320000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x7a463015082fa60c6f36577f7f2dafe0ed5a1f19"}, {name: "tokensAmount", type: "uint256", value: "105853845411638800000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xb1199f11d4268ca35d9b69da5d16e750a5a5b541"}, {name: "tokensAmount", type: "uint256", value: "302908200000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x211ef2bbeba52ec094cd3c4d895cc359c4aa83c9"}, {name: "tokensAmount", type: "uint256", value: "403877600000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xd70659a8d15ec42ce7f2dc3ec45ca89745840652"}, {name: "tokensAmount", type: "uint256", value: "218090180000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x3021cb64eafa2d280463e861ddb148ba6eedd002"}, {name: "tokensAmount", type: "uint256", value: "192471244368061700000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xcbc8259f61b27d285d51a0682b5f3b4d1cd1ddd9"}, {name: "tokensAmount", type: "uint256", value: "203616922600000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xdb846c52efe54ba3870a6c196feceab3f8050cd3"}, {name: "tokensAmount", type: "uint256", value: "101312801800000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x870672caa319170d8ff25d01811e820d23c1784e"}, {name: "tokensAmount", type: "uint256", value: "108985800000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xa717626cf32466a1b7ae2116122f6666bc7af994"}, {name: "tokensAmount", type: "uint256", value: "108985800000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x85ee64a1ebfac5077acd113c7f4cce78cf9569b4"}, {name: "tokensAmount", type: "uint256", value: "124243812000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x6840e8cebe0b99fd6c3ce09cf77fb46e9f1e995d"}, {name: "tokensAmount", type: "uint256", value: "148220688000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xe96f21c53345c310a91d2251549a54090b74196c"}, {name: "tokensAmount", type: "uint256", value: "121768136000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xfee5f1c0a70d5ed7831f3f1c42566ffa686a0e71"}, {name: "tokensAmount", type: "uint256", value: "468922199200000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xbf98608d3e9f852506c96d31243663e409f5c61a"}, {name: "tokensAmount", type: "uint256", value: "133999320000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xace55c42c2aacd7a93982e1c2019c9ad505c9ec3"}, {name: "tokensAmount", type: "uint256", value: "223332200000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x0f490d87110ecd5c82142dab69565250b138a77b"}, {name: "tokensAmount", type: "uint256", value: "139359292800000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x06ec97feaeb0f4b9a75f9671d6b62bfadaf18ddd"}, {name: "tokensAmount", type: "uint256", value: "92002400000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xa25da51e6eb7ad8c69bdc3bd71dc5632cea45faa"}, {name: "tokensAmount", type: "uint256", value: "110402880000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xe5c9a36c5db935e85881a1a7753f8d390ea72c54"}, {name: "tokensAmount", type: "uint256", value: "184859206232276800000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x264fa15214ae7e3e0e4ec60d5b77112a422f81a4"}, {name: "tokensAmount", type: "uint256", value: "220805760000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x7b9d698589a76170ce200c4f440550ab58385a3d"}, {name: "tokensAmount", type: "uint256", value: "100969400000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xdc4682ae040147f3f13d671009f4f23befa3b500"}, {name: "tokensAmount", type: "uint256", value: "102988788000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x0abe3681d83c91b0d7dab32ddf9bd5a1ef42f45b"}, {name: "tokensAmount", type: "uint256", value: "199919412000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0x837c3ee06e8f85e62c2df921e18fbdf0cd72d763"}, {name: "tokensAmount", type: "uint256", value: "29831431660000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "AddTokens", events: [{name: "user", type: "address", value: "0xe4c7db913f86c4ef18ccd5ae22279459e490f61f"}, {name: "tokensAmount", type: "uint256", value: "50000000000000000000"}, {name: "_price", type: "uint256", value: "20606"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x8fd70dbe7d87ec70fc8f1b7bce9776498c44a8f8"}, {name: "value", type: "uint256", value: "325085600000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x5ad09914ce092a737e4a97416714854c99118c7a"}, {name: "value", type: "uint256", value: "650171200000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xaad615f0b224cac7336f5e0ec809859e948c9232"}, {name: "value", type: "uint256", value: "638652571969440000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xe3510312040988bdf8585ecbb237999012683782"}, {name: "value", type: "uint256", value: "167197557018564800000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xbdc93290ac71a96eb8d36993a56ff6b85ab8d799"}, {name: "value", type: "uint256", value: "165793656000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x255de1f9a17a0d84b4c93ba15ff63233f01125bf"}, {name: "value", type: "uint256", value: "225414355040000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xcab1cf97dcdbeb4d78668377037f62371e424aad"}, {name: "value", type: "uint256", value: "321184572800000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x5b93c4dc5e190ac8c43db96ad03f1a8106479d5b"}, {name: "value", type: "uint256", value: "359595821267961600000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xf2802c69e087f73b22713bd8cf5b24ee45c4b146"}, {name: "value", type: "uint256", value: "162542800000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x2408e8fd0e79eb4836e13dd824a82a4f101cb4ba"}, {name: "value", type: "uint256", value: "319995409675200000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xf0f85fd82fb3b348310459ba90c916a00ca1b203"}, {name: "value", type: "uint256", value: "320834360000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x216b223979337673493724f03b44bda84bc4fb51"}, {name: "value", type: "uint256", value: "145833800000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xc5a7d3697a5b1bc79a19304c827ac607c0cc23c0"}, {name: "value", type: "uint256", value: "452420457615831600000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x9e855f6a9967f79348669f7688d46168b4740d73"}, {name: "value", type: "uint256", value: "242084108000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x3be854d1f09420ff5394a240e4d13c91fd20b799"}, {name: "value", type: "uint256", value: "291667600000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xe3510312040988bdf8585ecbb237999012683782"}, {name: "value", type: "uint256", value: "146510084997438400000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x7a463015082fa60c6f36577f7f2dafe0ed5a1f19"}, {name: "value", type: "uint256", value: "170085372063115600000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x0a75d99987a90359d34518481cbe41e89a894ee4"}, {name: "value", type: "uint256", value: "273299518800000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xafb4a48a1c12a5c0e06474ed054030d9d12a3d97"}, {name: "value", type: "uint256", value: "133186900000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xd43df3bbf6d1b13c5053564c7af7e67b45df43de"}, {name: "value", type: "uint256", value: "144374599600000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x2c91c924ca8ac89840f0bfc8d40c6204c41c72e6"}, {name: "value", type: "uint256", value: "1297166724609555800000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x0a6602ed1305848c9d96570058669692e3fa9056"}, {name: "value", type: "uint256", value: "234408944000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x32499854428bb75082f66ac1440b92fa9efd1e46"}, {name: "value", type: "uint256", value: "319648560000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x0f587e0ce60fde32a169b3c14483d225d278a262"}, {name: "value", type: "uint256", value: "143065300000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x358a77ad058a2b1bceb12c46da49669dbde16557"}, {name: "value", type: "uint256", value: "2145979500000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xad1d604f85d8d0017fba212adbbaa3f4ab642a11"}, {name: "value", type: "uint256", value: "283269294000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x79a3b843c7c3477de78cacc7fc81b742d3e97dc6"}, {name: "value", type: "uint256", value: "858391800000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x26202cbe46584b154b969bcf6dbda341e12e314c"}, {name: "value", type: "uint256", value: "228904480000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xe18b2ebbf4502a3083f897748e0f66118ca1108e"}, {name: "value", type: "uint256", value: "143065300000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xcda3ec16baf6130a3132c2c3fdbeb3ab713f4039"}, {name: "value", type: "uint256", value: "171678360000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xf297f3a7fc1901bfa92b5b68eeda3a72a1757817"}, {name: "value", type: "uint256", value: "145926606000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x0133a5910fcce0eccda9bf1776ae6a6333e4c343"}, {name: "value", type: "uint256", value: "282714320000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x7a463015082fa60c6f36577f7f2dafe0ed5a1f19"}, {name: "value", type: "uint256", value: "105853845411638800000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xb1199f11d4268ca35d9b69da5d16e750a5a5b541"}, {name: "value", type: "uint256", value: "302908200000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x211ef2bbeba52ec094cd3c4d895cc359c4aa83c9"}, {name: "value", type: "uint256", value: "403877600000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xd70659a8d15ec42ce7f2dc3ec45ca89745840652"}, {name: "value", type: "uint256", value: "218090180000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x3021cb64eafa2d280463e861ddb148ba6eedd002"}, {name: "value", type: "uint256", value: "192471244368061700000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xcbc8259f61b27d285d51a0682b5f3b4d1cd1ddd9"}, {name: "value", type: "uint256", value: "203616922600000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xdb846c52efe54ba3870a6c196feceab3f8050cd3"}, {name: "value", type: "uint256", value: "101312801800000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x870672caa319170d8ff25d01811e820d23c1784e"}, {name: "value", type: "uint256", value: "108985800000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xa717626cf32466a1b7ae2116122f6666bc7af994"}, {name: "value", type: "uint256", value: "108985800000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x85ee64a1ebfac5077acd113c7f4cce78cf9569b4"}, {name: "value", type: "uint256", value: "124243812000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x6840e8cebe0b99fd6c3ce09cf77fb46e9f1e995d"}, {name: "value", type: "uint256", value: "148220688000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xe96f21c53345c310a91d2251549a54090b74196c"}, {name: "value", type: "uint256", value: "121768136000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xfee5f1c0a70d5ed7831f3f1c42566ffa686a0e71"}, {name: "value", type: "uint256", value: "468922199200000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xbf98608d3e9f852506c96d31243663e409f5c61a"}, {name: "value", type: "uint256", value: "133999320000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xace55c42c2aacd7a93982e1c2019c9ad505c9ec3"}, {name: "value", type: "uint256", value: "223332200000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x0f490d87110ecd5c82142dab69565250b138a77b"}, {name: "value", type: "uint256", value: "139359292800000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x06ec97feaeb0f4b9a75f9671d6b62bfadaf18ddd"}, {name: "value", type: "uint256", value: "92002400000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xa25da51e6eb7ad8c69bdc3bd71dc5632cea45faa"}, {name: "value", type: "uint256", value: "110402880000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xe5c9a36c5db935e85881a1a7753f8d390ea72c54"}, {name: "value", type: "uint256", value: "184859206232276800000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x264fa15214ae7e3e0e4ec60d5b77112a422f81a4"}, {name: "value", type: "uint256", value: "220805760000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x7b9d698589a76170ce200c4f440550ab58385a3d"}, {name: "value", type: "uint256", value: "100969400000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xdc4682ae040147f3f13d671009f4f23befa3b500"}, {name: "value", type: "uint256", value: "102988788000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x0abe3681d83c91b0d7dab32ddf9bd5a1ef42f45b"}, {name: "value", type: "uint256", value: "199919412000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x837c3ee06e8f85e62c2df921e18fbdf0cd72d763"}, {name: "value", type: "uint256", value: "29831431660000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xe4c7db913f86c4ef18ccd5ae22279459e490f61f"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[2,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "25118034424451178970" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[3] )", async function( ) {
		const txOriginal = {blockNumber: "6594007", timeStamp: "1540655998", hash: "0x69bdb371425794dc55f566243c21c485090c29ebdee9570023fb6e67fcd4875a", nonce: "46", blockHash: "0x1b2aa1feee4f50ad658e4304c4168b980fb728795e946b3f633b706ccdb2edf6", transactionIndex: "50", from: "0xedc3b6301d849f1080bf11e31de7eef96d8ff94e", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "46899", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b00000000000000000000000073d5f035b8cb58b4af065d6ce49fc8e7288536f3", contractAddress: "", cumulativeGasUsed: "4510235", gasUsed: "31266", confirmations: "1141203"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newOwner", value: addressList[3]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540655998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "previousOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[3,15] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0xedc3b6301d849f1080bf11e31de7eef96d8ff94e"}, {name: "newOwner", type: "address", value: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[3,15] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "25118034424451178970" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setNewPrice( \"19728\" )", async function( ) {
		const txOriginal = {blockNumber: "6601832", timeStamp: "1540766543", hash: "0x0c3bc473fc6cfb39421093efb1eb09e16d7593db33b409ea9eaaccfb53aeb071", nonce: "226", blockHash: "0x1cecb33c3e72b4c5eab231305ca2fe0685b18f2aa24aba5548fd1fd7397406f0", transactionIndex: "5", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "43501", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xee8cdd4e0000000000000000000000000000000000000000000000000000000000004d10", contractAddress: "", cumulativeGasUsed: "212182", gasUsed: "29001", confirmations: "1133378"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ethPerToken", value: "19728"}], name: "setNewPrice", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setNewPrice(uint256)" ]( "19728", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540766543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewTokenPrice", events: [{name: "tokenPrice", type: "uint256", value: "19728"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setNewPrice( \"19728\" )", async function( ) {
		const txOriginal = {blockNumber: "6601848", timeStamp: "1540766835", hash: "0x9f0f8cecf6fe2c915a09700ae57534c821806742333a1aae919262a6e8b5a8a6", nonce: "227", blockHash: "0x985849d7b09c989ec5c26ae17875c7df0e652e1eb0834a363864e4b9a307e557", transactionIndex: "14", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "43501", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xee8cdd4e0000000000000000000000000000000000000000000000000000000000004d10", contractAddress: "", cumulativeGasUsed: "439341", gasUsed: "29001", confirmations: "1133362"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ethPerToken", value: "19728"}], name: "setNewPrice", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setNewPrice(uint256)" ]( "19728", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540766835 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewTokenPrice", events: [{name: "tokenPrice", type: "uint256", value: "19728"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: newInvestWallet( addressList[62] )", async function( ) {
		const txOriginal = {blockNumber: "6601859", timeStamp: "1540766981", hash: "0x846f7d6230b65a8451ccb33d14d054870fd2b5bd614e19e4142851a766b79e8f", nonce: "229", blockHash: "0xd21de7ac0f73aaf74f334e389496f83247c615622390764d9e2a9ce45bc29018", transactionIndex: "5", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "44827", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x4e5f87510000000000000000000000001cbef3676ef0f4d7efb786d2bda33e5e22b6a313", contractAddress: "", cumulativeGasUsed: "146773", gasUsed: "29885", confirmations: "1133351"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_investWallet", value: addressList[62]}], name: "newInvestWallet", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInvestWallet(address)" ]( addressList[62], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540766981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "invest", type: "address"}], name: "InvestWallet", type: "event"} ;
		console.error( "eventCallOriginal[6,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestWallet", events: [{name: "invest", type: "address", value: "0x1cbef3676ef0f4d7efb786d2bda33e5e22b6a313"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[6,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6604600", timeStamp: "1540806005", hash: "0x662e674c5e92df0457c6e24ddd3aa40cdbd21555338e282640530346a4734397", nonce: "2", blockHash: "0xaa94bad6216f6767b4db2b1050d91056f55b140653f19426f531b7377c40978a", transactionIndex: "36", from: "0x1b2ea4e00392eeccbb51d41913d976f1cc53cdf2", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1700000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1154058", gasUsed: "100000", confirmations: "1130610"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[63], to: addressList[2], value: "1700000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[63], balance: "295860018000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[63], balance: ( await web3.eth.getBalance( addressList[63], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6604608", timeStamp: "1540806131", hash: "0x4c853f432cfe4e130d84b5c3f63172173232bb8bd7abce134976e27707a3b4f2", nonce: "3", blockHash: "0x6fff6bbc1c779b86fd31fbeb840d3969ebacffa7a0f77ce7d9b65491468d00b8", transactionIndex: "16", from: "0x1b2ea4e00392eeccbb51d41913d976f1cc53cdf2", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1700000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "648367", gasUsed: "100000", confirmations: "1130602"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[63], to: addressList[2], value: "1700000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[63], balance: "295860018000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[63], balance: ( await web3.eth.getBalance( addressList[63], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6604616", timeStamp: "1540806273", hash: "0x9a65ad0e23e3e392d52928dd5584d717c84cd164244d7e89a1f0d2d3a4d524f9", nonce: "4", blockHash: "0x049f3675bed9bfcc14fd3fe8c97d9c6b75dfae62992c3b48e1a766ba338ab950", transactionIndex: "18", from: "0x1b2ea4e00392eeccbb51d41913d976f1cc53cdf2", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1600000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "726236", gasUsed: "100000", confirmations: "1130594"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[63], to: addressList[2], value: "1600000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[63], balance: "295860018000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[63], balance: ( await web3.eth.getBalance( addressList[63], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6604650", timeStamp: "1540806805", hash: "0xb618b403a06dedf1736acd91527dcec5e2da390b4bb6f66707ddc8d3dff00993", nonce: "5", blockHash: "0x34285c0553454723bed72146c212ab42220f2c8e9cf08dfc0740d6bac882df2f", transactionIndex: "91", from: "0x1b2ea4e00392eeccbb51d41913d976f1cc53cdf2", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1650000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3178138", gasUsed: "100000", confirmations: "1130560"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[63], to: addressList[2], value: "1650000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[63], balance: "295860018000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[63], balance: ( await web3.eth.getBalance( addressList[63], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6604660", timeStamp: "1540807002", hash: "0x3ccbc3a1815bcafad6ffae9ccad3c7203bc604481dfbeb8488bc8d6812ad7b7f", nonce: "6", blockHash: "0x94821eff4b7dac310677689fcf2e18b86794e41a445db396e4f705422d811ec9", transactionIndex: "133", from: "0x1b2ea4e00392eeccbb51d41913d976f1cc53cdf2", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1650000000000000000", gas: "200000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4321214", gasUsed: "123949", confirmations: "1130550"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[63], to: addressList[2], value: "1650000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540807002 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[11,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x1b2ea4e00392eeccbb51d41913d976f1cc53cdf2"}, {name: "weiAmount", type: "uint256", value: "1650000000000000000"}, {name: "tokensAmount", type: "uint256", value: "325512000000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[11,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x1b2ea4e00392eeccbb51d41913d976f1cc53cdf2"}, {name: "value", type: "uint256", value: "325512000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[11,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[63], balance: "295860018000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[63], balance: ( await web3.eth.getBalance( addressList[63], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6606863", timeStamp: "1540838011", hash: "0x65a53df09de106fe5b056641d4691974a4daac3d5c5fbfa85bf1f136dbab07d3", nonce: "3", blockHash: "0x0e71a6c4d65255c2a20482e3fa939ab68406d4ee0b4527e7f5518d4b5cce61ef", transactionIndex: "16", from: "0x1398740b2a181f35037d90185e48a105164cbc88", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1000000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "795387", gasUsed: "100000", confirmations: "1128347"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[64], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[64], balance: "42276627233875824" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[64], balance: ( await web3.eth.getBalance( addressList[64], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6606913", timeStamp: "1540838786", hash: "0x81eb877e633bbfb336fe48658aff25dcd2dae4396a31d2b3917a963a0e98f6be", nonce: "4", blockHash: "0x3e0daf719d50d4684b4597b2445c0bcec182986b2fa546ffb1c1ad6e237fdb9e", transactionIndex: "5", from: "0x1398740b2a181f35037d90185e48a105164cbc88", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1000000000000000000", gas: "123949", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "241654", gasUsed: "123949", confirmations: "1128297"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[64], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540838786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[13,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x1398740b2a181f35037d90185e48a105164cbc88"}, {name: "weiAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensAmount", type: "uint256", value: "197280000000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[13,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x1398740b2a181f35037d90185e48a105164cbc88"}, {name: "value", type: "uint256", value: "197280000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[13,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[64], balance: "42276627233875824" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[64], balance: ( await web3.eth.getBalance( addressList[64], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6612333", timeStamp: "1540914991", hash: "0xe0d43e806c9f413b1e4ea93469bc147bda7cdbcf3085b0b5ed56f86abce69fa1", nonce: "5", blockHash: "0x8db1a7a1ab374b90266bbd8eee9c525e9d8843db47e34bc89414f828e4c358aa", transactionIndex: "27", from: "0x7077c35f70c1c0a522720eee883e1e78e2be131d", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "560000000000000000", gas: "123949", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "944201", gasUsed: "123949", confirmations: "1122877"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[65], to: addressList[2], value: "560000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540914991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[14,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x7077c35f70c1c0a522720eee883e1e78e2be131d"}, {name: "weiAmount", type: "uint256", value: "560000000000000000"}, {name: "tokensAmount", type: "uint256", value: "110476800000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[14,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x7077c35f70c1c0a522720eee883e1e78e2be131d"}, {name: "value", type: "uint256", value: "110476800000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[14,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[65], balance: "11383358000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[65], balance: ( await web3.eth.getBalance( addressList[65], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6617781", timeStamp: "1540992482", hash: "0x43d263202ffd72cd224856541b8ce4a7e1cc3f0f4b973ffd1bf065c8e0c3ea76", nonce: "0", blockHash: "0xefdd3a242b435577b25a5218a2f365275817c87f3036defd580c6eb3e3ab6abe", transactionIndex: "50", from: "0xfdafd1adc63cf681b8325ab005d29232f2037131", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "70000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1655133", gasUsed: "70000", confirmations: "1117429"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "362252012000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6617805", timeStamp: "1540992871", hash: "0x9bb712fdd462165b92b9117b73550b294a394616bffbedb47433f7bfddf333a2", nonce: "1", blockHash: "0xe77aa65ea498e95c39cca0eb991b9653600824a96674fb48df67412407ee2c8c", transactionIndex: "6", from: "0xfdafd1adc63cf681b8325ab005d29232f2037131", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "226000", gasUsed: "100000", confirmations: "1117405"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "362252012000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6617943", timeStamp: "1540994592", hash: "0xf6214576fb75ea4eb65603fc005d204d59cb20206bffea6a38f348c6a532b79a", nonce: "2", blockHash: "0x37486754a881121d8ae589db9adc68fdaa6aa3294b5b0f38157a18c1a14f26a9", transactionIndex: "23", from: "0xfdafd1adc63cf681b8325ab005d29232f2037131", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "101000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "679111", gasUsed: "101000", confirmations: "1117267"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "362252012000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6617965", timeStamp: "1540995004", hash: "0xec402914f26784c459bde4efd17bb7ff3ec6ecdb0781451a093aec88f18399a1", nonce: "3", blockHash: "0xb91244353ae42d3b448bad821c8fcfa6ba3e872185a44683f0638a82871b2194", transactionIndex: "26", from: "0xfdafd1adc63cf681b8325ab005d29232f2037131", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "110000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "752062", gasUsed: "110000", confirmations: "1117245"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "362252012000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6617975", timeStamp: "1540995213", hash: "0x1440ba1420257851bb6cb70d7f525e24400c44acc116b29f6b78b44fef36095d", nonce: "4", blockHash: "0x66117c83294c505fef1b47be44e114cdb6072ecb185bdf1f8dd89c98fcee0489", transactionIndex: "49", from: "0xfdafd1adc63cf681b8325ab005d29232f2037131", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "550000000000000000", gas: "123654", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1508087", gasUsed: "123654", confirmations: "1117235"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "550000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "362252012000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6617985", timeStamp: "1540995380", hash: "0xc6f079439cc56a5319847d94e092c9472806e2e93c5a8c0af981cc91c602ad14", nonce: "5", blockHash: "0x30f7e6cdf0d30d076d2f01e0107ee253b5ecae801c0029e0530fde3e2f6d2244", transactionIndex: "22", from: "0xfdafd1adc63cf681b8325ab005d29232f2037131", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "550000000000000000", gas: "125000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "683391", gasUsed: "123949", confirmations: "1117225"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "550000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540995380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[20,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0xfdafd1adc63cf681b8325ab005d29232f2037131"}, {name: "weiAmount", type: "uint256", value: "550000000000000000"}, {name: "tokensAmount", type: "uint256", value: "108504000000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[20,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xfdafd1adc63cf681b8325ab005d29232f2037131"}, {name: "value", type: "uint256", value: "108504000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[20,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "362252012000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6624206", timeStamp: "1541083891", hash: "0xa15bfc764db5665d7a5f28f31ae74eeefb2a28c5e15b61cd765f6a11769ed7a6", nonce: "230", blockHash: "0xb79d46e1ff931d85391231ba03960878bd30a98736d7f3be42e69b75a31aee16", transactionIndex: "36", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "4090000000000000000", gas: "34861", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x8894dd2b", contractAddress: "", cumulativeGasUsed: "1429845", gasUsed: "23241", confirmations: "1111004"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "4090000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "addEther", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541083891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "weiAmount", type: "uint256"}], name: "AddWei", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddWei", events: [{name: "weiAmount", type: "uint256", value: "4090000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6625576", timeStamp: "1541103004", hash: "0x68883b3b2d856e762ec14e86280e1ac27f83186dfc75bd43830c1686ee87d333", nonce: "1", blockHash: "0x810008f4b9e1939d8340caa18a71ef5dc6e927d20aa356d9cf9ae2091ee9900f", transactionIndex: "1", from: "0xe5c9a36c5db935e85881a1a7753f8d390ea72c54", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1095616651000000000", gas: "108949", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "129949", gasUsed: "108949", confirmations: "1109634"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "1095616651000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541103004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[22,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0xe5c9a36c5db935e85881a1a7753f8d390ea72c54"}, {name: "weiAmount", type: "uint256", value: "1095616651000000000"}, {name: "tokensAmount", type: "uint256", value: "216143252909280000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[22,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xe5c9a36c5db935e85881a1a7753f8d390ea72c54"}, {name: "value", type: "uint256", value: "216143252909280000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[22,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[2], \"253000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6628290", timeStamp: "1541142380", hash: "0xc06408dc254969fdcf0d8d82444ce69eeec11a821a3bc1b6e1964cb9a76db0b2", nonce: "105", blockHash: "0xbfc756397248206d0f4c570b19d067544c3df501e0f0ea1342e9db1434589227", transactionIndex: "48", from: "0x5ad09914ce092a737e4a97416714854c99118c7a", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "150000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000c79d4c81f87c152ba604017a7b4747232ae3028000000000000000000000000000000000000000000000000db7148f8c6dd40000", contractAddress: "", cumulativeGasUsed: "7793954", gasUsed: "51653", confirmations: "1106920"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[2]}, {type: "uint256", name: "_value", value: "253000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[2], "253000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541142380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[23,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "buyer", type: "address", value: "0x5ad09914ce092a737e4a97416714854c99118c7a"}, {name: "weiAmount", type: "uint256", value: "1282441200324412003"}, {name: "tokensAmount", type: "uint256", value: "253000000000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[23,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x5ad09914ce092a737e4a97416714854c99118c7a"}, {name: "to", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "value", type: "uint256", value: "253000000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[23,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "15496960881156450" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[2], \"45833800000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6629921", timeStamp: "1541165288", hash: "0xf46254b4a72c7d04e7ef80621930001a6021093c2d9a4c3994262b4b222aede5", nonce: "27", blockHash: "0x086402098f480ce18731fba09df315ef8d129a41b499f931b27dcf75d41ea5ed", transactionIndex: "19", from: "0x216b223979337673493724f03b44bda84bc4fb51", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "100000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000c79d4c81f87c152ba604017a7b4747232ae302800000000000000000000000000000000000000000000000027c125e431a4c8000", contractAddress: "", cumulativeGasUsed: "656434", gasUsed: "51717", confirmations: "1105289"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[2]}, {type: "uint256", name: "_value", value: "45833800000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[2], "45833800000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541165288 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Withdraw", type: "event"} ;
		console.error( "eventCallOriginal[24,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Withdraw", events: [{name: "buyer", type: "address", value: "0x216b223979337673493724f03b44bda84bc4fb51"}, {name: "weiAmount", type: "uint256", value: "232328669910786699"}, {name: "tokensAmount", type: "uint256", value: "45833800000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[24,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x216b223979337673493724f03b44bda84bc4fb51"}, {name: "to", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "value", type: "uint256", value: "45833800000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[24,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "607425513699585113" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6638061", timeStamp: "1541279651", hash: "0x2ee219082658f98dbb38b0fb67462e7d4a8cdc0dd3ef37c8fff3544236435581", nonce: "0", blockHash: "0xbd747d507d11d925ba28ee2a30aa54890ea4d13407ba73a5e59cfc03aa4ac616", transactionIndex: "1", from: "0x4c45fe5afca6fac6c516de6106fc75f511983b04", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "121000", gasUsed: "100000", confirmations: "1097149"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[67], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[67], balance: "13618091000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[67], balance: ( await web3.eth.getBalance( addressList[67], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6638070", timeStamp: "1541279869", hash: "0x0933a0e354f92219ac7be800bc2cf2e6e499a7c27b04afd21b576fcba8355e84", nonce: "1", blockHash: "0x05809db498b9fefd0ed15d436005ab7872de3a92e3e589086d9791bc9f64e611", transactionIndex: "73", from: "0x4c45fe5afca6fac6c516de6106fc75f511983b04", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "200000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1742377", gasUsed: "123949", confirmations: "1097140"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[67], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541279869 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[26,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x4c45fe5afca6fac6c516de6106fc75f511983b04"}, {name: "weiAmount", type: "uint256", value: "500000000000000000"}, {name: "tokensAmount", type: "uint256", value: "98640000000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[26,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x4c45fe5afca6fac6c516de6106fc75f511983b04"}, {name: "value", type: "uint256", value: "98640000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[26,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[67], balance: "13618091000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[67], balance: ( await web3.eth.getBalance( addressList[67], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6643676", timeStamp: "1541359620", hash: "0x10630170b88b86c935075331606ab392c9e1d0dec80f1a1379c80ac9b19cc379", nonce: "1", blockHash: "0x66b5f7f0ed3adc86cea108e894c70ccd6685d1d02b6c30ca9d28bed2a97a6bea", transactionIndex: "34", from: "0xef419272f03e1aadaa56c1ab48da81d48f9ac8af", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "1000000000000000000", gas: "123949", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1189288", gasUsed: "123949", confirmations: "1091534"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[68], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541359620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[27,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0xef419272f03e1aadaa56c1ab48da81d48f9ac8af"}, {name: "weiAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensAmount", type: "uint256", value: "197280000000000000000"}, {name: "tokenPrice", type: "uint256", value: "19728"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[27,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0xef419272f03e1aadaa56c1ab48da81d48f9ac8af"}, {name: "value", type: "uint256", value: "197280000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[27,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[68], balance: "35594708000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[68], balance: ( await web3.eth.getBalance( addressList[68], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setNewPrice( \"19759\" )", async function( ) {
		const txOriginal = {blockNumber: "6644191", timeStamp: "1541366368", hash: "0xa56a6c8b618ffa03fca78d355f65211794e4d61891b79533a3afc250ac564127", nonce: "233", blockHash: "0x882f2ba44d61556971ff1515ecc57e8740c8998c09715e7a5351ad1e37bedb0e", transactionIndex: "8", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "43501", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xee8cdd4e0000000000000000000000000000000000000000000000000000000000004d2f", contractAddress: "", cumulativeGasUsed: "351235", gasUsed: "29001", confirmations: "1091019"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ethPerToken", value: "19759"}], name: "setNewPrice", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setNewPrice(uint256)" ]( "19759", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541366368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewTokenPrice", events: [{name: "tokenPrice", type: "uint256", value: "19759"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: lockUp( true )", async function( ) {
		const txOriginal = {blockNumber: "6668685", timeStamp: "1541714239", hash: "0xcafcb5ab464410866abbf091f755ce10036c6dbb47f7490195006d2371128476", nonce: "237", blockHash: "0x7642aed269f3ed5b69390296cd13d2b96f266065b80b82c0add73434863fe62e", transactionIndex: "3", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "43696", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd6a39db00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "116911", gasUsed: "29131", confirmations: "1066525"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "_lock", value: true}], name: "lockUp", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "lockUp(bool)" ]( true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541714239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "lockStatus", type: "bool"}], name: "Lock", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Lock", events: [{name: "lockStatus", type: "bool", value: true}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6689439", timeStamp: "1542008025", hash: "0x14d352cc68b4fdba00f0b61cf8caf126e3672bb712306cc1dcc365a741772169", nonce: "0", blockHash: "0x34fc22ddf3eaa68594f8144f29c6e83338e994f0a86ab547b669c4211ca647b9", transactionIndex: "18", from: "0x86a971f5a7a465bc7550472487b0a23ec73c222d", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "543000000000000000", gas: "123949", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "602514", gasUsed: "123949", confirmations: "1045771"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[69], to: addressList[2], value: "543000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542008025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[30,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x86a971f5a7a465bc7550472487b0a23ec73c222d"}, {name: "weiAmount", type: "uint256", value: "543000000000000000"}, {name: "tokensAmount", type: "uint256", value: "107291370000000000000"}, {name: "tokenPrice", type: "uint256", value: "19759"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[30,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x86a971f5a7a465bc7550472487b0a23ec73c222d"}, {name: "value", type: "uint256", value: "107291370000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[30,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[69], balance: "497834530000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[69], balance: ( await web3.eth.getBalance( addressList[69], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setNewPrice( \"21717\" )", async function( ) {
		const txOriginal = {blockNumber: "6691974", timeStamp: "1542043600", hash: "0x6429120df88ee24b16eb46e9b734316f54da6e128389d3c607488a24f5bcdd05", nonce: "243", blockHash: "0xce93e89f714651c835ce5c731a00dd012b0583b88df93615a09f7614b4fcbd03", transactionIndex: "22", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "43501", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xee8cdd4e00000000000000000000000000000000000000000000000000000000000054d5", contractAddress: "", cumulativeGasUsed: "1590313", gasUsed: "29001", confirmations: "1043236"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ethPerToken", value: "21717"}], name: "setNewPrice", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setNewPrice(uint256)" ]( "21717", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542043600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewTokenPrice", events: [{name: "tokenPrice", type: "uint256", value: "21717"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6702951", timeStamp: "1542199417", hash: "0x6c9eb24672075b5b39e9cfcca9b3b34bcb1a42d1d29ad1cf17ebd0d5b3bd00c5", nonce: "2", blockHash: "0x9358c8a1819b5d31e6487e5c2ee846f53c0fd5f04955ce9c99bf7edbccd39f82", transactionIndex: "205", from: "0x826cbb6552f39b055f6aec1844046a5dcbe260b3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "490000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7777659", gasUsed: "21579", confirmations: "1032259"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[70], to: addressList[2], value: "490000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542199417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[70], balance: "51865120000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[70], balance: ( await web3.eth.getBalance( addressList[70], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6702971", timeStamp: "1542199675", hash: "0x9441df45f7de6ac41a63e85e85c4ff500fd937609cb04c38e0b75e20fed353be", nonce: "3", blockHash: "0x13e898516a854dad5a1c1856e5dc168e690f2e45080aaf8f9a909835a3695bd9", transactionIndex: "3", from: "0x826cbb6552f39b055f6aec1844046a5dcbe260b3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "200000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "250888", gasUsed: "21579", confirmations: "1032239"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[70], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542199675 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[70], balance: "51865120000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[70], balance: ( await web3.eth.getBalance( addressList[70], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6702989", timeStamp: "1542199890", hash: "0xfa6352475fbff225ca9ae539d4a97a1227b5d3bc84d4d97ed6045a171f95fa29", nonce: "4", blockHash: "0x6eecfd2048607ab6c9fa996b523f0e00170c6e7cbd005097f38d515b02abaa5f", transactionIndex: "23", from: "0x826cbb6552f39b055f6aec1844046a5dcbe260b3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "742586282000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1972865", gasUsed: "100000", confirmations: "1032221"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[70], to: addressList[2], value: "742586282000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[70], balance: "51865120000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[70], balance: ( await web3.eth.getBalance( addressList[70], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6703010", timeStamp: "1542200193", hash: "0x56cd38cb9defdeb74001db723c5091ca48913770bff6726516d387a780ab98f4", nonce: "5", blockHash: "0xd9e49835309877e7c485cd6af84a10cff73345d95205482b77c9e98d19e905a7", transactionIndex: "82", from: "0x826cbb6552f39b055f6aec1844046a5dcbe260b3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "741656667000000000", gas: "185923", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6729260", gasUsed: "123949", confirmations: "1032200"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[70], to: addressList[2], value: "741656667000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542200193 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[35,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x826cbb6552f39b055f6aec1844046a5dcbe260b3"}, {name: "weiAmount", type: "uint256", value: "741656667000000000"}, {name: "tokensAmount", type: "uint256", value: "161065578372390000000"}, {name: "tokenPrice", type: "uint256", value: "21717"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[35,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x826cbb6552f39b055f6aec1844046a5dcbe260b3"}, {name: "value", type: "uint256", value: "161065578372390000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[35,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[70], balance: "51865120000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[70], balance: ( await web3.eth.getBalance( addressList[70], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6703265", timeStamp: "1542203714", hash: "0x8cf1566722c09839316fec2abd4c3a65dbb082e69f6a25bc77fa678f787fbdb4", nonce: "25", blockHash: "0xc7ee1f6ee01428c0808d94223e3b65c987e0269abb1aa6dc4f8b3af7d9eea0cc", transactionIndex: "33", from: "0x9053814df305d3169ca701f199d0ea8c1e3d2e14", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "710000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2669158", gasUsed: "100000", confirmations: "1031945"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[71], to: addressList[2], value: "710000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[71], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[71], balance: ( await web3.eth.getBalance( addressList[71], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6703295", timeStamp: "1542204080", hash: "0x48e5c89e62cd5a381207dae54bdc0d9d1906a9919d1312a312258762cf58dc23", nonce: "26", blockHash: "0x7d4d95ef590ec5b1ce23c26f224d9d6f77ee45bd55e976bfd7924385a4a08286", transactionIndex: "36", from: "0x9053814df305d3169ca701f199d0ea8c1e3d2e14", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "710000000000000000", gas: "150000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1743113", gasUsed: "123949", confirmations: "1031915"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[71], to: addressList[2], value: "710000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542204080 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[37,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x9053814df305d3169ca701f199d0ea8c1e3d2e14"}, {name: "weiAmount", type: "uint256", value: "710000000000000000"}, {name: "tokensAmount", type: "uint256", value: "154190700000000000000"}, {name: "tokenPrice", type: "uint256", value: "21717"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[37,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x9053814df305d3169ca701f199d0ea8c1e3d2e14"}, {name: "value", type: "uint256", value: "154190700000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[37,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[71], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[71], balance: ( await web3.eth.getBalance( addressList[71], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6724922", timeStamp: "1542509686", hash: "0x5d9b4d6df404d09edd26b66f47f5243aae00d2361a47b478123cb5337ce01d7d", nonce: "7", blockHash: "0x814d43582f712620fad311a31f7ac902b0722aecfbcefa56375bf112478d04e0", transactionIndex: "23", from: "0x41bbb7719b599cc2d73c85486885975d473b6bb1", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "123949", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1356237", gasUsed: "123949", confirmations: "1010288"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[72], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542509686 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[38,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x41bbb7719b599cc2d73c85486885975d473b6bb1"}, {name: "weiAmount", type: "uint256", value: "500000000000000000"}, {name: "tokensAmount", type: "uint256", value: "108585000000000000000"}, {name: "tokenPrice", type: "uint256", value: "21717"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[38,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x41bbb7719b599cc2d73c85486885975d473b6bb1"}, {name: "value", type: "uint256", value: "108585000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[38,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[72], balance: "101878479951016522" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[72], balance: ( await web3.eth.getBalance( addressList[72], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setNewPrice( \"17797\" )", async function( ) {
		const txOriginal = {blockNumber: "6732672", timeStamp: "1542618807", hash: "0x3b311926680871a77afea7edfc9cc67b5099ae55653f08d4138d5695631e123d", nonce: "246", blockHash: "0x13e04cdd40453eb43fbc36f6185d0d2168c4c454b81db15073d66df852e8c98a", transactionIndex: "80", from: "0x73d5f035b8cb58b4af065d6ce49fc8e7288536f3", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "0", gas: "43501", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xee8cdd4e0000000000000000000000000000000000000000000000000000000000004585", contractAddress: "", cumulativeGasUsed: "3172634", gasUsed: "29001", confirmations: "1002538"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_ethPerToken", value: "17797"}], name: "setNewPrice", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setNewPrice(uint256)" ]( "17797", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542618807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenPrice", type: "uint256"}], name: "NewTokenPrice", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewTokenPrice", events: [{name: "tokenPrice", type: "uint256", value: "17797"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "6415159454535651379" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6744741", timeStamp: "1542791473", hash: "0xf6eda86bc4ae3d94c2bf63749627a972edb6e74adeb7448b3e27bd703f6fdd61", nonce: "113", blockHash: "0x54a81c7917527387a2a9acd0487f03688e51655e262e9d24f88bff64745f34b9", transactionIndex: "92", from: "0x737be443d4bbaafedfc29b68d98d7da4a93dc512", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "500000000000000000", gas: "200000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3266090", gasUsed: "123949", confirmations: "990469"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[73], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542791473 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[40,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x737be443d4bbaafedfc29b68d98d7da4a93dc512"}, {name: "weiAmount", type: "uint256", value: "500000000000000000"}, {name: "tokensAmount", type: "uint256", value: "88985000000000000000"}, {name: "tokenPrice", type: "uint256", value: "17797"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[40,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x737be443d4bbaafedfc29b68d98d7da4a93dc512"}, {name: "value", type: "uint256", value: "88985000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[40,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[73], balance: "669935699054830645" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[73], balance: ( await web3.eth.getBalance( addressList[73], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6750670", timeStamp: "1542876105", hash: "0xd9f68c3954a9a4eb1a5b7dd8f66ab5c998fa20a2e441ff08a9293dfd6c12ec66", nonce: "12", blockHash: "0x3d4bdc8af99c5636bad5d98b8c6ad6770cf8062cb175fd43f847b146683d2246", transactionIndex: "55", from: "0x1251b9d368169df7129d73371b662ae13496c338", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "4300000000000000000", gas: "123949", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3482978", gasUsed: "123949", confirmations: "984540"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[74], to: addressList[2], value: "4300000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542876105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[41,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x1251b9d368169df7129d73371b662ae13496c338"}, {name: "weiAmount", type: "uint256", value: "4300000000000000000"}, {name: "tokensAmount", type: "uint256", value: "765271000000000000000"}, {name: "tokenPrice", type: "uint256", value: "17797"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[41,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x1251b9d368169df7129d73371b662ae13496c338"}, {name: "value", type: "uint256", value: "765271000000000000000"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[41,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[74], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[74], balance: ( await web3.eth.getBalance( addressList[74], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6758670", timeStamp: "1542989052", hash: "0xf3e611d4e385e68678133cd6cc4d1dcc627c8bffee0ad5ef10aa3ca3d419aeaf", nonce: "4", blockHash: "0x2e0e2cfe3c72dd80bb53ba08ed12877c44a1b440cf82ec1589607b555dbc5d63", transactionIndex: "2", from: "0x237eea7441d27ee00b90916a77401e0078ce29c8", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "135000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "95382", gasUsed: "21579", confirmations: "976540"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[75], to: addressList[2], value: "135000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542989052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[75], balance: "36547772000010000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[75], balance: ( await web3.eth.getBalance( addressList[75], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6758686", timeStamp: "1542989343", hash: "0xe1abf15d4875c81abdf2d321ea55f917af7bcee1044914dc0485538f122f8dda", nonce: "5", blockHash: "0xc0996c874b97a6c8be419409c9914612c112e762a29f78f752b023b6d73db795", transactionIndex: "8", from: "0x237eea7441d27ee00b90916a77401e0078ce29c8", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "130000000000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "391405", gasUsed: "21579", confirmations: "976524"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[75], to: addressList[2], value: "130000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542989343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[75], balance: "36547772000010000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[75], balance: ( await web3.eth.getBalance( addressList[75], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6758736", timeStamp: "1542989972", hash: "0x2d7b2ac82c87f3d82c58f6f669154548454fe513dd6304e37dd1a5d8959f893a", nonce: "3", blockHash: "0x0c2af3c4d36707442cae704d2ba9cee547c8ab0512133b47fd71c6b5004d57c5", transactionIndex: "6", from: "0x08dfcd1f0d8465d795873fb6f8c897f4aa38472f", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "674327095370370360", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "242132", gasUsed: "100000", confirmations: "976474"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[76], to: addressList[2], value: "674327095370370360" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[76], balance: "148053000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[76], balance: ( await web3.eth.getBalance( addressList[76], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6758743", timeStamp: "1542990111", hash: "0xacb7bf4a9b56f8e59d016f99d9659d1ce3334beb87997b7344a82e264a729dcf", nonce: "4", blockHash: "0xea9e4ebe8e76aa7090b7a335d44fd754f40fb1e838273c1357d9c0790f9c4329", transactionIndex: "139", from: "0x08dfcd1f0d8465d795873fb6f8c897f4aa38472f", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "673727095370370360", gas: "100000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "6647547", gasUsed: "100000", confirmations: "976467"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[76], to: addressList[2], value: "673727095370370360" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[76], balance: "148053000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[76], balance: ( await web3.eth.getBalance( addressList[76], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6758754", timeStamp: "1542990233", hash: "0x8a733f857d69f2bef4eded8e2c8412c362a456e80cd3817e4d7fb1afae435ea6", nonce: "5", blockHash: "0x3ec630e53ce6b4675220164b687a730f295615e1179f3082d2b7d4b6601fd603", transactionIndex: "19", from: "0x08dfcd1f0d8465d795873fb6f8c897f4aa38472f", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "669627095370370360", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "883715", gasUsed: "100000", confirmations: "976456"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[76], to: addressList[2], value: "669627095370370360" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[76], balance: "148053000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[76], balance: ( await web3.eth.getBalance( addressList[76], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6758761", timeStamp: "1542990359", hash: "0xbf2cdc4bb489bc3c7f54e5f9aee4cf771e2ed8df0a444dfa0fd8faee0b974655", nonce: "6", blockHash: "0x7214d2e45963d5e6ae9e636830acf7230af26040754334f8ba74ee055903d2a0", transactionIndex: "20", from: "0x08dfcd1f0d8465d795873fb6f8c897f4aa38472f", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "663477095370370360", gas: "150000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "922000", gasUsed: "123949", confirmations: "976449"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[76], to: addressList[2], value: "663477095370370360" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542990359 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "buyer", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokensAmount", type: "uint256"}, {indexed: false, name: "tokenPrice", type: "uint256"}, {indexed: false, name: "commission", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[47,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "buyer", type: "address", value: "0x08dfcd1f0d8465d795873fb6f8c897f4aa38472f"}, {name: "weiAmount", type: "uint256", value: "663477095370370360"}, {name: "tokensAmount", type: "uint256", value: "118079018663064812969"}, {name: "tokenPrice", type: "uint256", value: "17797"}, {name: "commission", type: "uint256", value: "100"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[47,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,17] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}, {name: "to", type: "address", value: "0x08dfcd1f0d8465d795873fb6f8c897f4aa38472f"}, {name: "value", type: "uint256", value: "118079018663064812969"}], address: "0xc79d4c81f87c152ba604017a7b4747232ae30280"}] ;
		console.error( "eventResultOriginal[47,17] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[76], balance: "148053000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[76], balance: ( await web3.eth.getBalance( addressList[76], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6764239", timeStamp: "1543067103", hash: "0xd74fc7b158b31d2c88f4c4553c3a8e6c4f830977ac29af660b748a9b8f2ee56c", nonce: "21", blockHash: "0xd321d9fea75017fb6e985fc9a4fa57c374b2da5a48a3d977ce269005298bb31a", transactionIndex: "13", from: "0x4f915c31aeb71456ec26dbb1cc87c6ad32e23171", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "847408040000000000", gas: "100000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "917077", gasUsed: "100000", confirmations: "970971"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[77], to: addressList[2], value: "847408040000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[77], balance: "16944700502063273" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[77], balance: ( await web3.eth.getBalance( addressList[77], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6764251", timeStamp: "1543067322", hash: "0xbe5d7c025e3181892f8e0ad82668b664918ec268e2c3e18d64eb3e6a34decfc3", nonce: "22", blockHash: "0x7235e988f0731ad95a83759d7d5cabd36f7d99754a670e3c6b225d821f7cc9eb", transactionIndex: "8", from: "0x4f915c31aeb71456ec26dbb1cc87c6ad32e23171", to: "0xc79d4c81f87c152ba604017a7b4747232ae30280", value: "847408040000000000", gas: "110000", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "812112", gasUsed: "110000", confirmations: "970959"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[77], to: addressList[2], value: "847408040000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[77], balance: "16944700502063273" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "11251501776113719767" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[77], balance: ( await web3.eth.getBalance( addressList[77], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
